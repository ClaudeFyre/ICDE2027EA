"""Run the WWW-only equal-budget fidelity--storage--latency benchmark.

The benchmark compares three executions of one learned-hidden Gaussian target:

* full-world Monte Carlo encoding;
* scope-exact local Monte Carlo for the same two-layer normalized GCN;
* a validation-selected low-rank-plus-diagonal serving artifact.

The low-rank method's offline construction and online serving times are reported
separately.  This prevents cached serving from being presented as a first-query
end-to-end speedup.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import os
import platform
import statistics
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Sequence

import numpy as np
import torch
from torch.nn import functional


ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT / "src", ROOT / "scripts" / "backbones"):
    if str(search_path) not in sys.path:
        sys.path.insert(0, str(search_path))

from pkgea.contracts import dataset_revision_digest
from pkgea.distributional import low_rank_plus_diagonal
from pkgea.samplers import monte_carlo_worlds
from pkgea.www_fsl import (
    TwoLayerGCNScope,
    apply_entity_adaptive_ranks,
    apply_entity_representations,
    approximate_covariance_batch,
    build_two_layer_gcn_scope,
    empirical_gaussian,
    gaussian_distance_matrix,
    mean_relative_distance_error,
    stored_scalars_per_entity,
    slack_diagnostics,
    select_entity_adaptive_ranks,
    select_margin_aware_representations,
    serving_workload_digest,
    truth_preserving_candidate_subset,
    winner_agreement,
    winner_indices,
)
from torch_gcn_align import GCNAlign
from www_encoder_adapters import load_distributional_encoder


FORMAT = "pkgea-www-equal-budget-fsl-v2"
RESUME_FORMAT = "pkgea-www-resume-v1"


def process_rss_bytes() -> int:
    try:
        import psutil

        return int(psutil.Process(os.getpid()).memory_info().rss)
    except ImportError:
        return 0


def resource_snapshot() -> dict[str, int]:
    return {
        "rss_bytes": process_rss_bytes(),
        "cuda_peak_allocated_bytes": (
            int(torch.cuda.max_memory_allocated()) if torch.cuda.is_available() else 0
        ),
        "cuda_peak_reserved_bytes": (
            int(torch.cuda.max_memory_reserved()) if torch.cuda.is_available() else 0
        ),
    }


def format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def format_gib(value: int) -> str:
    return f"{value / (1024 ** 3):.1f}GiB"


class ProgressReporter:
    """Synchronous progress reporting; never starts a polling thread."""

    def __init__(self, total_units: int, *, heartbeat_seconds: float = 60.0) -> None:
        self.total_units = total_units
        self.heartbeat_seconds = heartbeat_seconds
        self.started = time.perf_counter()
        self.last_report = self.started
        self.completed = 0
        self.unit_seconds: list[float] = []
        self.peak = resource_snapshot()

    def _sample(self) -> dict[str, int]:
        current = resource_snapshot()
        for key, value in current.items():
            self.peak[key] = max(self.peak.get(key, 0), value)
        return current

    def report(
        self,
        *,
        cell: str,
        world_budget: int,
        method: str,
        completed_unit_seconds: float | None = None,
        force: bool = False,
    ) -> float:
        """Print outside measured work and return telemetry overhead seconds."""
        overhead_started = time.perf_counter()
        now = overhead_started
        if completed_unit_seconds is not None:
            self.completed += 1
            self.unit_seconds.append(completed_unit_seconds)
        elif not force and now - self.last_report < self.heartbeat_seconds:
            return 0.0
        snapshot = self._sample()
        typical = statistics.median(self.unit_seconds) if self.unit_seconds else 0.0
        eta = typical * max(0, self.total_units - self.completed)
        print(
            f"[www] {self.completed}/{self.total_units} cell={cell} "
            f"wb={world_budget} method={method} "
            f"elapsed={format_duration(now - self.started)} eta={format_duration(eta)} "
            f"rss={format_gib(snapshot['rss_bytes'])} "
            f"vram_alloc={format_gib(snapshot['cuda_peak_allocated_bytes'])} "
            f"vram_reserved={format_gib(snapshot['cuda_peak_reserved_bytes'])}",
            flush=True,
        )
        self.last_report = time.perf_counter()
        return self.last_report - overhead_started


def atomic_write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".partial.tmp")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def resume_unit_key(profile: str, seed: int, budget: int) -> str:
    return f"{profile}|{seed}|{budget}"


def load_resume_state(
    path: Path,
    *,
    expected_identity: dict[str, object],
) -> dict[str, object]:
    if not path.exists():
        return {
            "schema_version": RESUME_FORMAT,
            **expected_identity,
            "completed_units": {},
        }
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != RESUME_FORMAT:
        raise ValueError(f"resume schema mismatch in {path}")
    mismatches = [
        key
        for key, expected in expected_identity.items()
        if payload.get(key) != expected
    ]
    if mismatches:
        raise ValueError(
            "resume identity mismatch; refusing mixed-revision continuation: "
            + ", ".join(mismatches)
        )
    if not isinstance(payload.get("completed_units"), dict):
        raise ValueError("resume completed_units must be an object")
    return payload


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_profile(raw: str) -> tuple[str, Path]:
    if "=" not in raw:
        raise argparse.ArgumentTypeError("profile must be NAME=PATH")
    name, path = raw.split("=", 1)
    if not name.strip():
        raise argparse.ArgumentTypeError("profile name must not be empty")
    return name.strip(), Path(path).resolve()


def parse_profile_rank(raw: str) -> tuple[str, int]:
    if "=" not in raw:
        raise argparse.ArgumentTypeError("profile rank must be NAME=RANK")
    name, rank = raw.split("=", 1)
    try:
        value = int(rank)
    except ValueError as error:
        raise argparse.ArgumentTypeError("profile rank must be an integer") from error
    if not name.strip() or value <= 0:
        raise argparse.ArgumentTypeError("profile name/rank must be positive")
    return name.strip(), value


@dataclass
class ProfileData:
    name: str
    root: Path
    triples: list[dict[str, str]]
    alignments: list[dict[str, str]]
    probabilities: list[float]
    groups: list[str]
    common_shock_probability: float
    dependence_assumption: str


class PreparedLocalGCN:
    """Vectorized exact row-restricted forward pass for the frozen GCN."""

    def __init__(
        self,
        model: GCNAlign,
        features: torch.Tensor,
        heads: Sequence[int],
        tails: Sequence[int],
        query_positions: Sequence[int],
        scope: TwoLayerGCNScope,
    ) -> None:
        self.model = model
        self.features = features
        self.node_count = features.shape[0]
        self.heads = torch.tensor(heads, dtype=torch.long)
        self.tails = torch.tensor(tails, dtype=torch.long)
        self.query_positions = tuple(int(value) for value in query_positions)
        self.scope = scope
        self.scope_edges = torch.tensor(
            scope.sampled_edge_indices, dtype=torch.long
        )
        self.layer1_positions = torch.tensor(
            scope.layer1_positions, dtype=torch.long
        )
        self.query_tensor = torch.tensor(
            self.query_positions, dtype=torch.long
        )
        layer1_map = {
            entity: position
            for position, entity in enumerate(scope.layer1_positions)
        }
        output_map = {
            entity: position
            for position, entity in enumerate(self.query_positions)
        }

        layer1_rows: list[int] = []
        layer1_columns: list[int] = []
        layer1_edge_slots: list[int] = []
        for edge_index in scope.layer1_edge_indices:
            head = int(heads[edge_index])
            tail = int(tails[edge_index])
            if head in layer1_map:
                layer1_rows.append(layer1_map[head])
                layer1_columns.append(tail)
                layer1_edge_slots.append(edge_index)
            if tail in layer1_map:
                layer1_rows.append(layer1_map[tail])
                layer1_columns.append(head)
                layer1_edge_slots.append(edge_index)
        self.layer1_rows = torch.tensor(layer1_rows, dtype=torch.long)
        self.layer1_columns = torch.tensor(
            layer1_columns, dtype=torch.long
        )
        self.layer1_edge_slots = torch.tensor(
            layer1_edge_slots, dtype=torch.long
        )

        layer2_rows: list[int] = []
        layer2_columns: list[int] = []
        layer2_edge_slots: list[int] = []
        for edge_index in scope.layer2_edge_indices:
            head = int(heads[edge_index])
            tail = int(tails[edge_index])
            if head in output_map:
                layer2_rows.append(output_map[head])
                layer2_columns.append(layer1_map[tail])
                layer2_edge_slots.append(edge_index)
            if tail in output_map:
                layer2_rows.append(output_map[tail])
                layer2_columns.append(layer1_map[head])
                layer2_edge_slots.append(edge_index)
        self.layer2_rows = torch.tensor(layer2_rows, dtype=torch.long)
        self.layer2_columns = torch.tensor(
            layer2_columns, dtype=torch.long
        )
        self.layer2_edge_slots = torch.tensor(
            layer2_edge_slots, dtype=torch.long
        )

    def __call__(self, weights: torch.Tensor) -> torch.Tensor:
        degree = torch.ones(self.node_count, dtype=torch.float32)
        selected_weights = weights[self.scope_edges]
        degree.index_add_(0, self.heads[self.scope_edges], selected_weights)
        degree.index_add_(0, self.tails[self.scope_edges], selected_weights)
        scale = degree.clamp_min(1e-12).rsqrt()

        layer1_loop_rows = torch.arange(len(self.layer1_positions))
        layer1_indices = torch.stack(
            (
                torch.cat((self.layer1_rows, layer1_loop_rows)),
                torch.cat((self.layer1_columns, self.layer1_positions)),
            )
        )
        layer1_edge_values = (
            weights[self.layer1_edge_slots]
            * scale[self.layer1_positions[self.layer1_rows]]
            * scale[self.layer1_columns]
        )
        layer1_loop_values = degree[self.layer1_positions].reciprocal()
        layer1_adjacency = torch.sparse_coo_tensor(
            layer1_indices,
            torch.cat((layer1_edge_values, layer1_loop_values)),
            (len(self.layer1_positions), self.node_count),
        ).coalesce()
        neighbor_features = torch.sparse.mm(
            layer1_adjacency, self.features
        )
        layer1_features = self.features[self.layer1_positions]
        hidden = functional.relu(
            self.model.layer1(
                torch.cat((layer1_features, neighbor_features), dim=1)
            )
        )

        layer2_loop_rows = torch.arange(len(self.query_positions))
        layer2_loop_columns = torch.tensor(
            [
                {
                    entity: position
                    for position, entity in enumerate(
                        self.scope.layer1_positions
                    )
                }[entity]
                for entity in self.query_positions
            ],
            dtype=torch.long,
        )
        layer2_indices = torch.stack(
            (
                torch.cat((self.layer2_rows, layer2_loop_rows)),
                torch.cat((self.layer2_columns, layer2_loop_columns)),
            )
        )
        output_positions = torch.tensor(self.query_positions, dtype=torch.long)
        layer2_edge_values = (
            weights[self.layer2_edge_slots]
            * scale[output_positions[self.layer2_rows]]
            * scale[
                self.layer1_positions[self.layer2_columns]
            ]
        )
        layer2_loop_values = degree[output_positions].reciprocal()
        layer2_adjacency = torch.sparse_coo_tensor(
            layer2_indices,
            torch.cat((layer2_edge_values, layer2_loop_values)),
            (len(self.query_positions), len(self.layer1_positions)),
        ).coalesce()
        neighbor_hidden = torch.sparse.mm(layer2_adjacency, hidden)
        output_hidden = hidden[layer2_loop_columns]
        return functional.normalize(
            self.model.layer2(
                torch.cat((output_hidden, neighbor_hidden), dim=1)
            ),
            dim=1,
        )


def load_profile(name: str, root: Path) -> ProfileData:
    triples = read_rows(root / "triples.tsv")
    alignments = read_rows(root / "alignments.tsv")
    metadata = json.loads(
        (root / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    dependence = metadata.get("edge_dependence", {})
    groups = [row["dependency_group"] for row in triples]
    common_shock_probability = (
        float(metadata.get("generation", {}).get("shared_strength", 0.0))
        if dependence.get("assumption") == "grouped_shared_latent"
        and any(groups)
        else 0.0
    )
    return ProfileData(
        name=name,
        root=root,
        triples=triples,
        alignments=alignments,
        probabilities=[float(row["confidence"]) for row in triples],
        groups=groups,
        common_shock_probability=common_shock_probability,
        dependence_assumption=str(
            dependence.get("assumption", "unspecified")
        ),
    )


def time_world_generation(
    profile: ProfileData,
    sample_count: int,
    seed: int,
    *,
    local_edge_indices: set[int] | None = None,
) -> tuple[list[object], float]:
    started = time.perf_counter()
    worlds = monte_carlo_worlds(
        profile.probabilities,
        sample_count,
        seed,
        dependency_groups=profile.groups,
        common_shock_probability=profile.common_shock_probability,
        local_edge_indices=local_edge_indices,
    )
    return worlds, time.perf_counter() - started


def encode_worlds(
    worlds: Sequence[object],
    forward: Callable[[torch.Tensor], torch.Tensor],
    *,
    heartbeat: Callable[[], float] | None = None,
) -> tuple[np.ndarray, float]:
    if not worlds:
        raise ValueError("at least one world is required")
    memmap_root = ROOT / ".runtime" / "www_memmaps"
    memmap_root.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        dir=memmap_root, prefix=f"hidden-{os.getpid()}-", suffix=".f32"
    )
    os.close(descriptor)
    samples: np.memmap | None = None
    started = time.perf_counter()
    telemetry_overhead = 0.0
    try:
        with torch.no_grad():
            for index, world in enumerate(worlds):
                weights = torch.tensor(world.state, dtype=torch.float32)
                encoded = np.asarray(forward(weights).numpy(), dtype=np.float32)
                if samples is None:
                    samples = np.memmap(
                        temporary, dtype=np.float32, mode="w+",
                        shape=(len(worlds), *encoded.shape),
                    )
                samples[index] = encoded
                if heartbeat is not None:
                    telemetry_overhead += heartbeat()
        assert samples is not None
        samples.flush()
        return samples, time.perf_counter() - started - telemetry_overhead
    except BaseException:
        if samples is not None:
            samples._mmap.close()
        Path(temporary).unlink(missing_ok=True)
        raise


def release_hidden_samples(samples: np.ndarray) -> None:
    """Close and remove a runner-owned hidden-state memmap."""
    if isinstance(samples, np.memmap):
        path = Path(samples.filename)
        samples._mmap.close()
        path.unlink(missing_ok=True)


def project_and_summarize(
    hidden_samples: np.ndarray,
    projection: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, float]:
    started = time.perf_counter()
    if hidden_samples.ndim != 3 or hidden_samples.shape[0] < 3:
        raise ValueError("hidden samples must have shape (world, entity, dimension)")
    count, entity_count, _ = hidden_samples.shape
    dimension = projection.shape[1]
    sums = np.zeros((entity_count, dimension), dtype=np.float64)
    chunk_size = 16
    for start in range(0, count, chunk_size):
        projected = np.asarray(
            hidden_samples[start : start + chunk_size], dtype=np.float64
        ) @ projection
        sums += projected.sum(axis=0)
    means = sums / count
    covariances = np.zeros(
        (entity_count, dimension, dimension), dtype=np.float64
    )
    for start in range(0, count, chunk_size):
        projected = np.asarray(
            hidden_samples[start : start + chunk_size], dtype=np.float64
        ) @ projection
        centered = projected - means[None, :, :]
        covariances += np.einsum(
            "wed,wef->edf", centered, centered, optimize=True
        )
    covariances /= count - 1
    return means, covariances, time.perf_counter() - started


def timed_distances(
    means: np.ndarray,
    covariances: np.ndarray,
    source_count: int,
    repeats: int,
) -> tuple[np.ndarray, float]:
    timings = []
    result = None
    for _ in range(repeats):
        started = time.perf_counter()
        result = gaussian_distance_matrix(means, covariances, source_count)
        timings.append(time.perf_counter() - started)
    assert result is not None
    return result, statistics.median(timings)


def low_rank_payload(
    means: np.ndarray,
    covariances: np.ndarray,
    rank: int,
    metadata: dict[str, object],
) -> tuple[bytes, np.ndarray, np.ndarray, float]:
    started = time.perf_counter()
    factors = []
    residuals = []
    for covariance in covariances:
        factor, residual = low_rank_plus_diagonal(covariance, rank=rank)
        factors.append(factor)
        residuals.append(residual)
    factor_values = np.stack(factors)
    residual_values = np.stack(residuals)
    buffer = io.BytesIO()
    np.savez_compressed(
        buffer,
        means=np.asarray(means, dtype=np.float32),
        factors=np.asarray(factor_values, dtype=np.float32),
        diagonal_residuals=np.asarray(residual_values, dtype=np.float32),
        metadata=np.asarray(json.dumps(metadata, sort_keys=True)),
    )
    return (
        buffer.getvalue(),
        factor_values,
        residual_values,
        time.perf_counter() - started,
    )


def full_payload(
    means: np.ndarray,
    covariances: np.ndarray,
    *,
    dtype: np.dtype = np.dtype(np.float32),
    metadata: dict[str, object] | None = None,
) -> bytes:
    """Serialize full symmetric covariance with an explicit scalar dtype."""

    dimension = covariances.shape[1]
    upper = np.triu_indices(dimension)
    buffer = io.BytesIO()
    fields: dict[str, np.ndarray] = {
        "means": np.asarray(means, dtype=dtype),
        "covariance_upper": np.asarray(
            covariances[:, upper[0], upper[1]], dtype=dtype
        ),
        "scalar_dtype": np.asarray(np.dtype(dtype).name),
    }
    if metadata is not None:
        fields["metadata_json"] = np.asarray(json.dumps(metadata, sort_keys=True))
    np.savez_compressed(buffer, **fields)
    return buffer.getvalue()


def full_payload_bytes(
    means: np.ndarray, covariances: np.ndarray
) -> int:
    return len(full_payload(means, covariances))


def load_full_payload(payload: bytes) -> tuple[np.ndarray, np.ndarray]:
    """Load a full-covariance payload, expanding its symmetric upper half."""

    with np.load(io.BytesIO(payload), allow_pickle=False) as artifact:
        means = np.asarray(artifact["means"], dtype=np.float64)
        upper_values = np.asarray(artifact["covariance_upper"], dtype=np.float64)
    dimension = means.shape[1]
    upper = np.triu_indices(dimension)
    covariances = np.zeros((len(means), dimension, dimension), dtype=np.float64)
    covariances[:, upper[0], upper[1]] = upper_values
    covariances[:, upper[1], upper[0]] = upper_values
    return means, covariances


def representation_payload(
    means: np.ndarray,
    covariances: np.ndarray,
    representations: Sequence[str],
    metadata: dict[str, object],
    *,
    dtype: np.dtype = np.dtype(np.float32),
) -> tuple[bytes, float]:
    """Serialize a diagonal/rank-1/2/4/full mixed representation."""

    started = time.perf_counter()
    values = np.asarray(covariances, dtype=np.float64)
    names = tuple(str(value) for value in representations)
    if len(names) != len(values):
        raise ValueError("representation map length must match entity count")
    supported = {"diagonal", "rank_1", "rank_2", "rank_4", "full"}
    if not set(names).issubset(supported):
        raise ValueError("unsupported mixed representation")
    codes = {"diagonal": 0, "rank_1": 1, "rank_2": 2, "rank_4": 4, "full": 8}
    encoded = np.asarray([codes[name] for name in names], dtype=np.int8)
    dimension = values.shape[1]
    upper = np.triu_indices(dimension)
    fields: dict[str, np.ndarray] = {
        "means": np.asarray(means, dtype=dtype),
        "representation_codes": encoded,
        "scalar_dtype": np.asarray(np.dtype(dtype).name),
        "metadata_json": np.asarray(json.dumps(metadata, sort_keys=True)),
    }
    diagonal_indices = np.flatnonzero(encoded == codes["diagonal"])
    fields["diagonal_indices"] = diagonal_indices.astype(np.int32)
    fields["diagonal_values"] = np.asarray(
        np.diagonal(values[diagonal_indices], axis1=1, axis2=2), dtype=dtype
    )
    full_indices = np.flatnonzero(encoded == codes["full"])
    fields["full_indices"] = full_indices.astype(np.int32)
    fields["full_upper"] = np.asarray(
        values[full_indices][:, upper[0], upper[1]], dtype=dtype
    )
    for rank in (1, 2, 4):
        indices = np.flatnonzero(encoded == rank)
        factors, residuals = [], []
        for index in indices:
            factor, residual = low_rank_plus_diagonal(values[index], rank=rank)
            factors.append(factor)
            residuals.append(residual)
        fields[f"rank{rank}_indices"] = indices.astype(np.int32)
        fields[f"rank{rank}_factors"] = np.asarray(
            factors, dtype=dtype
        ).reshape(len(indices), dimension, rank)
        fields[f"rank{rank}_residuals"] = np.asarray(
            residuals, dtype=dtype
        ).reshape(len(indices), dimension)
    buffer = io.BytesIO()
    np.savez_compressed(buffer, **fields)
    return buffer.getvalue(), time.perf_counter() - started


def load_representation_payload(payload: bytes) -> tuple[np.ndarray, np.ndarray]:
    """Load a mixed representation payload as dense float64 covariance."""

    with np.load(io.BytesIO(payload), allow_pickle=False) as artifact:
        means = np.asarray(artifact["means"], dtype=np.float64)
        codes = np.asarray(artifact["representation_codes"], dtype=np.int8)
        dimension = means.shape[1]
        covariances = np.zeros((len(means), dimension, dimension), dtype=np.float64)
        diagonal_indices = np.asarray(artifact["diagonal_indices"], dtype=np.int64)
        diagonal_values = np.asarray(artifact["diagonal_values"], dtype=np.float64)
        for row, index in enumerate(diagonal_indices):
            covariances[index].flat[:: dimension + 1] = diagonal_values[row]
        upper = np.triu_indices(dimension)
        full_indices = np.asarray(artifact["full_indices"], dtype=np.int64)
        full_upper = np.asarray(artifact["full_upper"], dtype=np.float64)
        for row, index in enumerate(full_indices):
            covariances[index][upper] = full_upper[row]
            covariances[index][(upper[1], upper[0])] = full_upper[row]
        for rank in (1, 2, 4):
            indices = np.asarray(artifact[f"rank{rank}_indices"], dtype=np.int64)
            factors = np.asarray(artifact[f"rank{rank}_factors"], dtype=np.float64)
            residuals = np.asarray(artifact[f"rank{rank}_residuals"], dtype=np.float64)
            for row, index in enumerate(indices):
                covariances[index] = factors[row] @ factors[row].T
                covariances[index].flat[:: dimension + 1] += residuals[row]
    return means, covariances


def time_cold_operator(
    payload: bytes,
    source_count: int,
    repeats: int,
) -> float:
    timings = []
    for _ in range(repeats):
        started = time.perf_counter()
        with np.load(io.BytesIO(payload), allow_pickle=False) as artifact:
            means = np.asarray(artifact["means"], dtype=np.float64)
            factors = np.asarray(artifact["factors"], dtype=np.float64)
            residuals = np.asarray(
                artifact["diagonal_residuals"], dtype=np.float64
            )
        covariances = np.einsum(
            "edr,efr->edf", factors, factors, optimize=True
        )
        diagonal = np.arange(covariances.shape[1])
        covariances[:, diagonal, diagonal] += residuals
        gaussian_distance_matrix(means, covariances, source_count)
        timings.append(time.perf_counter() - started)
    return statistics.median(timings)


def adaptive_payload(
    means: np.ndarray,
    covariances: np.ndarray,
    selected_ranks: Sequence[int | None],
    metadata: dict[str, object],
) -> tuple[bytes, float]:
    """Serialize a mixed full/rank-1/2/4 representation with explicit ranks."""
    started = time.perf_counter()
    values = np.asarray(covariances, dtype=np.float64)
    ranks = np.asarray(selected_ranks, dtype=np.int8)
    if np.any(ranks < 0) or len(ranks) != len(values):
        raise ValueError("adaptive payload requires a complete authorized rank map")
    upper = np.triu_indices(values.shape[1])
    fields: dict[str, np.ndarray] = {
        "means": np.asarray(means, dtype=np.float32),
        "ranks": ranks,
        "metadata_json": np.asarray(json.dumps(metadata, sort_keys=True)),
    }
    full_indices = np.flatnonzero(ranks == 0)
    fields["full_indices"] = full_indices.astype(np.int32)
    fields["full_upper"] = np.asarray(values[full_indices][:, upper[0], upper[1]], dtype=np.float32)
    for rank in (1, 2, 4):
        indices = np.flatnonzero(ranks == rank)
        factors, residuals = [], []
        for index in indices:
            factor, residual = low_rank_plus_diagonal(values[index], rank=rank)
            factors.append(factor); residuals.append(residual)
        fields[f"rank{rank}_indices"] = indices.astype(np.int32)
        fields[f"rank{rank}_factors"] = np.asarray(factors, dtype=np.float32).reshape(len(indices), values.shape[1], rank)
        fields[f"rank{rank}_residuals"] = np.asarray(residuals, dtype=np.float32).reshape(len(indices), values.shape[1])
    buffer = io.BytesIO()
    np.savez_compressed(buffer, **fields)
    return buffer.getvalue(), time.perf_counter() - started


def load_adaptive_payload(payload: bytes) -> tuple[np.ndarray, np.ndarray]:
    with np.load(io.BytesIO(payload), allow_pickle=False) as artifact:
        means = np.asarray(artifact["means"], dtype=np.float64)
        ranks = np.asarray(artifact["ranks"], dtype=np.int8)
        dimension = means.shape[1]
        covariances = np.zeros((len(means), dimension, dimension), dtype=np.float64)
        upper = np.triu_indices(dimension)
        full_indices = np.asarray(artifact["full_indices"], dtype=np.int64)
        full_upper = np.asarray(artifact["full_upper"], dtype=np.float64)
        for row, index in enumerate(full_indices):
            covariances[index][upper] = full_upper[row]
            covariances[index][(upper[1], upper[0])] = full_upper[row]
        for rank in (1, 2, 4):
            indices = np.asarray(artifact[f"rank{rank}_indices"], dtype=np.int64)
            factors = np.asarray(artifact[f"rank{rank}_factors"], dtype=np.float64)
            residuals = np.asarray(artifact[f"rank{rank}_residuals"], dtype=np.float64)
            for row, index in enumerate(indices):
                covariances[index] = factors[row] @ factors[row].T
                covariances[index].flat[:: dimension + 1] += residuals[row]
    if np.any(ranks < 0):
        raise ValueError("adaptive artifact contains anomalous rank")
    return means, covariances


def time_adaptive_operator(
    payload: bytes, source_count: int, repeats: int
) -> dict[str, float]:
    reloads=[]; first_uses=[]; colds=[]
    for _ in range(repeats):
        cold_started=time.perf_counter(); reload_started=cold_started
        means, covariances=load_adaptive_payload(payload)
        reload_done=time.perf_counter()
        gaussian_distance_matrix(means, covariances, source_count)
        first_done=time.perf_counter()
        reloads.append(reload_done-reload_started); first_uses.append(first_done-reload_done); colds.append(first_done-cold_started)
    means, covariances=load_adaptive_payload(payload)
    warms=[]
    for _ in range(repeats):
        started=time.perf_counter(); gaussian_distance_matrix(means,covariances,source_count); warms.append(time.perf_counter()-started)
    return {"reload_seconds":statistics.median(reloads),"first_use_seconds":statistics.median(first_uses),"cold_seconds":statistics.median(colds),"warm_seconds":statistics.median(warms)}


def truth_accuracy(
    distances: np.ndarray, truth_target_positions: np.ndarray
) -> float:
    return float(np.mean(winner_indices(distances) == truth_target_positions))


def truth_mrr(
    distances: np.ndarray, truth_target_positions: np.ndarray
) -> float:
    """Mean reciprocal rank with frozen target order as the tie breaker."""
    values = np.asarray(distances, dtype=np.float64)
    truth = np.asarray(truth_target_positions, dtype=np.int64)
    if values.ndim != 2 or truth.shape != (values.shape[0],):
        raise ValueError("truth positions must match the distance rows")
    truth_values = values[np.arange(len(truth)), truth]
    less = np.sum(values < truth_values[:, None], axis=1)
    positions = np.arange(values.shape[1])[None, :]
    tied_before = np.sum(
        (values == truth_values[:, None]) & (positions < truth[:, None]), axis=1
    )
    ranks = 1 + less + tied_before
    return float(np.mean(1.0 / ranks))


def metric_row(
    *,
    profile: ProfileData,
    seed: int,
    budget: int,
    method: str,
    distances: np.ndarray,
    reference_distances: np.ndarray,
    truth_positions: np.ndarray,
    stored_scalars: int,
    actual_artifact_bytes: int,
    world_generation_seconds: float,
    encoder_seconds: float,
    moment_seconds: float,
    compression_seconds: float,
    online_warm_seconds: float,
    online_cold_seconds: float,
    sampled_edges_per_world: int,
    encoder_rows_per_world: int,
    compression_agreement: float | None = None,
    compression_distance_error: float | None = None,
    selected_rank: int | None = None,
) -> dict[str, object]:
    offline_seconds = (
        world_generation_seconds
        + encoder_seconds
        + moment_seconds
        + compression_seconds
    )
    fresh_seconds = offline_seconds + online_warm_seconds
    return {
        "profile": profile.name,
        "seed": seed,
        "world_budget": budget,
        "method": method,
        "selected_rank": selected_rank,
        "winner_agreement_with_reference": winner_agreement(
            distances, reference_distances
        ),
        "mean_relative_distance_error_with_reference": (
            mean_relative_distance_error(distances, reference_distances)
        ),
        "top1_accuracy": truth_accuracy(distances, truth_positions),
        "mrr": truth_mrr(distances, truth_positions),
        "compression_winner_agreement": compression_agreement,
        "compression_mean_relative_distance_error": (
            compression_distance_error
        ),
        "stored_scalars_per_entity_including_mean": stored_scalars,
        "logical_index_bytes_float32": stored_scalars
        * distances.shape[0]
        * 0
        + stored_scalars,
        "actual_compressed_artifact_bytes": actual_artifact_bytes,
        "world_generation_seconds": world_generation_seconds,
        "encoder_seconds": encoder_seconds,
        "moment_construction_seconds": moment_seconds,
        "compression_serialization_seconds": compression_seconds,
        "offline_build_seconds": offline_seconds,
        "online_warm_query_seconds": online_warm_seconds,
        "online_cold_query_seconds": online_cold_seconds,
        "fresh_end_to_end_seconds": fresh_seconds,
        "sampled_edges_per_world": sampled_edges_per_world,
        "sampled_edge_draws": sampled_edges_per_world * budget,
        "encoder_rows_per_world": encoder_rows_per_world,
        "encoder_row_updates": encoder_rows_per_world * budget,
    }


def aggregate_headline(
    rows: list[dict[str, object]], gate_budget: int, entity_count: int
) -> dict[str, object]:
    selected = [
        row
        for row in rows
        if int(row["world_budget"]) == gate_budget
    ]
    methods = sorted({str(row["method"]) for row in selected})
    by_method = {}
    for method in methods:
        group = [row for row in selected if row["method"] == method]
        by_method[method] = {
            "cells": len(group),
            "mean_winner_agreement_with_reference": statistics.mean(
                float(row["winner_agreement_with_reference"])
                for row in group
            ),
            "mean_relative_distance_error_with_reference": statistics.mean(
                float(row["mean_relative_distance_error_with_reference"])
                for row in group
            ),
            "mean_top1_accuracy": statistics.mean(
                float(row["top1_accuracy"]) for row in group
            ),
            "mean_mrr": statistics.mean(float(row["mrr"]) for row in group),
            "mean_fresh_end_to_end_seconds": statistics.mean(
                float(row["fresh_end_to_end_seconds"]) for row in group
            ),
            "mean_online_warm_query_seconds": statistics.mean(
                float(row["online_warm_query_seconds"]) for row in group
            ),
            "mean_stored_scalars_per_entity_including_mean": statistics.mean(
                int(row["stored_scalars_per_entity_including_mean"])
                for row in group
            ),
            "mean_logical_index_kib_float32": statistics.mean(
                int(row["stored_scalars_per_entity_including_mean"])
                * entity_count
                * 4
                / 1024.0
                for row in group
            ),
            "mean_actual_compressed_artifact_kib": statistics.mean(
                int(row["actual_compressed_artifact_bytes"]) / 1024.0
                for row in group
            ),
            "mean_sampled_edge_draws": statistics.mean(
                int(row["sampled_edge_draws"]) for row in group
            ),
            "mean_encoder_row_updates": statistics.mean(
                int(row["encoder_row_updates"]) for row in group
            ),
        }
    full = by_method["full_world_mc"]
    local = by_method["scope_exact_local_mc"]
    operator = by_method["low_rank_operator"]
    operator["storage_reduction_vs_full_fraction"] = 1.0 - (
        operator["mean_stored_scalars_per_entity_including_mean"]
        / full["mean_stored_scalars_per_entity_including_mean"]
    )
    operator["warm_speedup_vs_full_fresh"] = (
        full["mean_fresh_end_to_end_seconds"]
        / operator["mean_online_warm_query_seconds"]
    )
    operator["warm_speedup_vs_local_fresh"] = (
        local["mean_fresh_end_to_end_seconds"]
        / operator["mean_online_warm_query_seconds"]
    )
    operator["first_use_speedup_vs_full"] = (
        full["mean_fresh_end_to_end_seconds"]
        / operator["mean_fresh_end_to_end_seconds"]
    )
    return {
        "gate_budget": gate_budget,
        "by_method": by_method,
    }


def write_markdown(result: dict[str, object], output: Path) -> None:
    headline = result["headline"]["by_method"]
    full = headline["full_world_mc"]
    local = headline["scope_exact_local_mc"]
    operator = headline["low_rank_operator"]
    lines = [
        "# WWW equal-budget fidelity--storage--latency result",
        "",
        "## Frozen protocol",
        "",
        f"- Gate budget: {result['headline']['gate_budget']} worlds.",
        f"- Test seeds: {result['protocol']['test_seeds']}; selection seed: "
        f"{result['protocol']['selection_seed']}; reference seed: "
        f"{result['protocol']['reference_seed']}.",
        "- Target: PCA-projected learned-GCN hidden-state Gaussian W2 top-1; "
        "all methods use the same queries, candidates, checkpoint and world "
        "count in each cell.",
        "- Low-rank offline construction and online serving are timed "
        "separately.",
        "",
        "## Gate-budget mean over profiles and held-out seeds",
        "",
        "| method | winner agreement | distance error | stored scalars/entity "
        "| logical KiB | fresh s | warm query s |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for label, row in (
        ("full-world MC", full),
        ("scope-exact local MC", local),
        ("authorized low-rank operator", operator),
    ):
        lines.append(
            f"| {label} | {row['mean_winner_agreement_with_reference']:.4f} "
            f"| {row['mean_relative_distance_error_with_reference']:.4f} "
            f"| {row['mean_stored_scalars_per_entity_including_mean']:.1f} "
            f"| {row['mean_logical_index_kib_float32']:.2f} "
            f"| {row['mean_fresh_end_to_end_seconds']:.4f} "
            f"| {row['mean_online_warm_query_seconds']:.4f} |"
        )
    lines.extend(
        [
            "",
            "## Evidence-backed conclusion",
            "",
            f"The selected operator reduces logical index storage by "
            f"{100.0 * operator['storage_reduction_vs_full_fraction']:.1f}% "
            f"and its warm serving path is "
            f"{operator['warm_speedup_vs_full_fresh']:.1f}x faster than "
            "fresh full-world construction. Its first-use speedup is only "
            f"{operator['first_use_speedup_vs_full']:.2f}x once offline "
            "construction is charged, so the result supports amortized "
            "serving rather than zero-cost end-to-end replacement.",
            "",
            "The exact local baseline samples fewer edges and updates fewer "
            "GCN rows, but wall time is reported independently because sparse "
            "row construction can offset the arithmetic reduction on this "
            "small CPU probe.",
            "",
            "## Validation",
            "",
            f"- Exact local equivalence gate: "
            f"{result['validation']['all_local_exactness_checks_pass']}.",
            f"- Held-out compression gate: "
            f"{result['validation']['all_held_out_gate_checks_pass']}.",
            "- The guarantee is empirical and revision/checkpoint-bound; it "
            "is not an anytime statistical certificate and not a universal "
            "rank claim.",
            "",
        ]
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--markdown-output", type=Path)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument(
        "--profile", action="append", type=parse_profile, required=True
    )
    parser.add_argument(
        "--budgets", nargs="+", type=int, default=[16, 32, 64, 128, 256]
    )
    parser.add_argument("--gate-budget", type=int, default=64)
    parser.add_argument("--selection-seed", type=int, default=17)
    parser.add_argument("--test-seeds", nargs="+", type=int, default=[11, 23])
    parser.add_argument("--reference-seed", type=int, default=1017)
    parser.add_argument("--reference-samples", type=int, default=2048)
    parser.add_argument("--projection-dimension", type=int, default=16)
    parser.add_argument("--candidate-ranks", nargs="+", type=int, default=[1, 2, 4])
    parser.add_argument(
        "--margin-aware-experiment",
        action="store_true",
        help=(
            "Evaluate the preregistered storage-neutral margin-aware and "
            "diagonal policies on the same held-out world stream"
        ),
    )
    parser.add_argument(
        "--profile-rank",
        action="append",
        type=parse_profile_rank,
        default=[],
        help=(
            "Use a revisioned, predeclared rank for one profile (NAME=RANK); "
            "the rank must still pass the selection-seed gate."
        ),
    )
    parser.add_argument("--max-compression-distance-error", type=float, default=0.0025)
    parser.add_argument("--min-compression-winner-agreement", type=float, default=1.0)
    parser.add_argument("--timing-repeats", type=int, default=5)
    parser.add_argument("--exactness-worlds", type=int, default=3)
    parser.add_argument("--exactness-tolerance", type=float, default=2e-6)
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume only units whose checkpoint/profile/protocol digests match",
    )
    parser.add_argument("--resume-path", type=Path)
    parser.add_argument("--heartbeat-seconds", type=float, default=60.0)
    parser.add_argument(
        "--query-limit",
        type=int,
        help=(
            "Use the first N test sources in frozen alignment order while "
            "retaining the full candidate set and checkpoint topology"
        ),
    )
    parser.add_argument(
        "--candidate-limit",
        type=int,
        help=(
            "Retain exactly K targets while preserving every retained source "
            "truth and the frozen relative target order"
        ),
    )
    parser.add_argument(
        "--cell-label",
        default="auto",
        help="Human-readable graph/checkpoint label used in progress lines",
    )
    args = parser.parse_args()

    output = args.output.resolve()
    markdown_output = (
        args.markdown_output.resolve() if args.markdown_output else None
    )
    if output.exists() or (
        markdown_output is not None and markdown_output.exists()
    ):
        raise ValueError("output already exists; refusing to overwrite")
    if args.heartbeat_seconds <= 0:
        raise ValueError("heartbeat seconds must be positive")
    if args.query_limit is not None and args.query_limit <= 0:
        raise ValueError("query limit must be positive")
    if args.candidate_limit is not None and args.candidate_limit <= 0:
        raise ValueError("candidate limit must be positive")
    budgets = sorted(set(args.budgets))
    if args.gate_budget not in budgets:
        raise ValueError("gate budget must be included in budgets")
    if min(budgets) < 3:
        raise ValueError("all budgets must be at least three")
    if args.reference_samples <= max(budgets):
        raise ValueError("reference samples must exceed every test budget")
    disjoint = {
        args.selection_seed,
        args.reference_seed,
        *args.test_seeds,
    }
    if len(disjoint) != 2 + len(set(args.test_seeds)):
        raise ValueError("selection, reference and test seeds must be disjoint")
    if args.timing_repeats <= 0 or args.exactness_worlds <= 0:
        raise ValueError("timing/exactness repeats must be positive")

    torch.set_num_threads(1)
    checkpoint_path = args.checkpoint.resolve()
    checkpoint = torch.load(
        checkpoint_path, map_location="cpu", weights_only=False
    )
    adapter = load_distributional_encoder(checkpoint)
    entity_ids = adapter.entity_ids()
    entity_index = {
        entity: position for position, entity in enumerate(entity_ids)
    }
    heads, tails = adapter.edge_endpoints()

    profiles = [load_profile(name, path) for name, path in args.profile]
    protocol_identity_payload = {
        "budgets": budgets,
        "gate_budget": args.gate_budget,
        "selection_seed": args.selection_seed,
        "test_seeds": list(args.test_seeds),
        "reference_seed": args.reference_seed,
        "reference_samples": args.reference_samples,
        "projection_dimension": args.projection_dimension,
        "candidate_ranks": sorted(set(args.candidate_ranks)),
        "timing_repeats": args.timing_repeats,
        "exactness_worlds": args.exactness_worlds,
        "exactness_tolerance": args.exactness_tolerance,
        "query_limit": args.query_limit,
        "candidate_limit": args.candidate_limit,
    }
    if args.margin_aware_experiment:
        protocol_identity_payload["margin_aware_experiment"] = True
        protocol_identity_payload["margin_aware_implementation_sha256"] = {
            str(path.relative_to(ROOT)): sha256(path)
            for path in (
                Path(__file__).resolve(),
                ROOT / "src/pkgea/www_fsl.py",
                ROOT / "scripts/run_www_margin_selection.py",
            )
        }
    protocol_digest = hashlib.sha256(
        json.dumps(protocol_identity_payload, sort_keys=True).encode("utf-8")
    ).hexdigest()
    profile_revisions = {
        profile.name: dataset_revision_digest(profile.root) for profile in profiles
    }
    resume_path = (
        args.resume_path.resolve()
        if args.resume_path is not None
        else output.with_name(output.name + ".resume.json")
    )
    resume_identity = {
        "checkpoint_sha256": sha256(checkpoint_path),
        "dataset_revisions": profile_revisions,
        "adapter_format_id": adapter.descriptor_adapter_id,
        "checkpoint_execution_format": adapter.format_id,
        "protocol_digest": protocol_digest,
    }
    resume_state = (
        load_resume_state(resume_path, expected_identity=resume_identity)
        if args.resume
        else {
            "schema_version": RESUME_FORMAT,
            **resume_identity,
            "completed_units": {},
        }
    )
    reporter = ProgressReporter(
        len(profiles) * (2 + len(args.test_seeds) * len(budgets) * 3),
        heartbeat_seconds=args.heartbeat_seconds,
    )
    current_progress = {
        "cell": args.cell_label,
        "world_budget": 0,
        "method": "setup",
    }

    def heartbeat() -> float:
        return reporter.report(
            cell=str(current_progress["cell"]),
            world_budget=int(current_progress["world_budget"]),
            method=str(current_progress["method"]),
        )
    profile_rank_overrides = dict(args.profile_rank)
    unknown_rank_profiles = sorted(
        set(profile_rank_overrides) - {profile.name for profile in profiles}
    )
    if unknown_rank_profiles:
        raise ValueError(
            "profile-rank names not present in --profile: "
            + ", ".join(unknown_rank_profiles)
        )
    all_rows: list[dict[str, object]] = []
    profile_reports = []
    local_checks = []
    gate_checks = []
    query_entity_count = None

    for profile in profiles:
        if len(profile.triples) != len(heads):
            raise ValueError(f"{profile.name}: dataset/checkpoint edge count mismatch")
        for edge_index, row in enumerate(profile.triples):
            if (
                entity_ids[heads[edge_index]] != row["head_id"]
                or entity_ids[tails[edge_index]] != row["tail_id"]
            ):
                raise ValueError(
                    f"{profile.name}: topology mismatch at edge {edge_index}"
                )
        sources = tuple(
            dict.fromkeys(
                row["source_entity_id"]
                for row in profile.alignments
                if row["split"] == "test"
            )
        )
        available_source_count = len(sources)
        if args.query_limit is not None:
            if args.query_limit > available_source_count:
                raise ValueError(
                    f"{profile.name}: query limit {args.query_limit} exceeds "
                    f"{available_source_count} available test sources"
                )
            sources = sources[: args.query_limit]
        full_targets = tuple(
            dict.fromkeys(
                row["target_entity_id"] for row in profile.alignments
            )
        )
        if not sources or not full_targets:
            raise ValueError(f"{profile.name}: missing test sources or targets")
        truth = {
            row["source_entity_id"]: row["target_entity_id"]
            for row in profile.alignments
            if row["split"] == "test"
        }
        targets = truth_preserving_candidate_subset(
            full_targets, sources, truth, args.candidate_limit
        )
        workload_digest = serving_workload_digest(sources, targets)
        truth_retention = sum(
            int(truth[source] in targets) for source in sources
        ) / len(sources)
        if truth_retention != 1.0:
            raise AssertionError("candidate construction lost a truth target")
        full_target_positions = {
            target: index for index, target in enumerate(full_targets)
        }
        retained_positions = [
            full_target_positions[target] for target in targets
        ]
        candidate_order_preserved = all(
            left < right
            for left, right in zip(
                retained_positions, retained_positions[1:]
            )
        )
        if not candidate_order_preserved:
            raise AssertionError("candidate relative order was not preserved")
        target_index = {target: index for index, target in enumerate(targets)}
        truth_positions = np.asarray(
            [target_index[truth[source]] for source in sources], dtype=np.int64
        )
        query_entities = (*sources, *targets)
        query_positions = tuple(entity_index[entity] for entity in query_entities)
        query_tensor = torch.tensor(query_positions, dtype=torch.long)
        query_entity_count = len(query_entities)
        scope = build_two_layer_gcn_scope(
            len(entity_ids), heads, tails, query_positions
        )
        def full_forward(weights: torch.Tensor) -> torch.Tensor:
            return adapter.encode(weights)[query_tensor]

        if adapter.format_id == "pkgea-torch-gcn-align-v1":
            local_forward = PreparedLocalGCN(
                adapter.model,
                adapter.features,
                heads,
                tails,
                query_positions,
                scope,
            )
            local_encoder_rows_per_world = (
                len(scope.layer1_positions) + len(query_positions)
            )
            local_execution_mode = "row_restricted_exact"
        else:
            scope_edge_tensor = torch.tensor(
                scope.sampled_edge_indices, dtype=torch.long
            )

            def local_forward(weights: torch.Tensor) -> torch.Tensor:
                # The relation-aware implementation currently validates local
                # edge semantics by masking non-scope edges while retaining the
                # frozen full-node feature tensor. It is exact for requested
                # rows but does not claim row-computation reduction.
                scoped = torch.zeros(len(heads), dtype=torch.float32)
                values = weights.to(dtype=torch.float32)
                if len(values) == len(heads):
                    values = values[scope_edge_tensor]
                elif len(values) != len(scope_edge_tensor):
                    raise ValueError(
                        "relation local state length must equal full edges or "
                        "certified scope edges"
                    )
                scoped[scope_edge_tensor] = values
                return adapter.encode(scoped)[query_tensor]

            local_encoder_rows_per_world = 2 * len(entity_ids)
            local_execution_mode = "full_row_edge_masked_exact"

        threshold_weights = torch.tensor(
            [value >= 0.5 for value in profile.probabilities],
            dtype=torch.float32,
        )
        with torch.no_grad():
            full_forward(threshold_weights)
            local_forward(threshold_weights)

        reference_worlds, reference_generation_seconds = time_world_generation(
            profile, args.reference_samples, args.reference_seed
        )
        current_progress.update(
            cell=f"{args.cell_label}/{profile.name}",
            world_budget=args.reference_samples,
            method="reference_full_world",
        )
        reference_hidden, reference_encoder_seconds = encode_worlds(
            reference_worlds, full_forward, heartbeat=heartbeat
        )
        reference_entity_means = reference_hidden.mean(axis=0)
        centered_means = reference_entity_means - reference_entity_means.mean(
            axis=0, keepdims=True
        )
        _, _, right = np.linalg.svd(centered_means, full_matrices=False)
        projection_dimension = min(
            args.projection_dimension, right.shape[0], right.shape[1]
        )
        if projection_dimension < 2:
            raise ValueError("projection must retain at least two dimensions")
        projection = right[:projection_dimension].T
        reference_means, reference_covariances, reference_moment_seconds = (
            project_and_summarize(reference_hidden, projection)
        )
        reference_distances, reference_matching_seconds = timed_distances(
            reference_means,
            reference_covariances,
            len(sources),
            args.timing_repeats,
        )
        release_hidden_samples(reference_hidden)
        reporter.report(
            cell=str(current_progress["cell"]),
            world_budget=args.reference_samples,
            method="reference_full_world",
            completed_unit_seconds=(
                reference_generation_seconds
                + reference_encoder_seconds
                + reference_moment_seconds
                + reference_matching_seconds
            ),
        )

        selection_worlds, selection_generation_seconds = time_world_generation(
            profile, args.gate_budget, args.selection_seed
        )
        current_progress.update(
            cell=f"{args.cell_label}/{profile.name}",
            world_budget=args.gate_budget,
            method="selection_full_covariance",
        )
        selection_hidden, selection_encoder_seconds = encode_worlds(
            selection_worlds, full_forward, heartbeat=heartbeat
        )
        selection_means, selection_covariances, selection_moment_seconds = (
            project_and_summarize(selection_hidden, projection)
        )
        release_hidden_samples(selection_hidden)
        selection_full_distances, _ = timed_distances(
            selection_means,
            selection_covariances,
            len(sources),
            args.timing_repeats,
        )
        rank_results = []
        for rank in sorted(set(args.candidate_ranks)):
            approximated = approximate_covariance_batch(
                selection_covariances, "low_rank", rank=rank
            )
            rank_distances, _ = timed_distances(
                selection_means,
                approximated,
                len(sources),
                args.timing_repeats,
            )
            rank_results.append(
                {
                    "rank": rank,
                    "winner_agreement_with_full_budget_covariance": (
                        winner_agreement(
                            rank_distances, selection_full_distances
                        )
                    ),
                    "mean_relative_distance_error_with_full_budget_covariance": (
                        mean_relative_distance_error(
                            rank_distances, selection_full_distances
                        )
                    ),
                    "stored_scalars_per_entity_including_mean": (
                        stored_scalars_per_entity(
                            projection_dimension, "low_rank", rank=rank
                        )
                    ),
                    "storage_mode": (
                        "rank_8_not_compression"
                        if projection_dimension == 16 and rank == 8
                        else "low_rank"
                    ),
                    "slack_diagnostics": slack_diagnostics(
                        selection_full_distances, rank_distances
                    ),
                }
            )
        adaptive_selection = select_entity_adaptive_ranks(
            selection_covariances,
            candidate_ranks=(1, 2, 4),
            residual_threshold=0.0025,
            zero_tolerance=1e-12,
        )
        adaptive_rank_map = adaptive_selection["selected_ranks"]
        adaptive_full_scalars = stored_scalars_per_entity(
            projection_dimension, "full"
        )
        adaptive_scalar_counts = [
            adaptive_full_scalars
            if rank in (None, 0)
            else stored_scalars_per_entity(
                projection_dimension, "low_rank", rank=int(rank)
            )
            for rank in adaptive_rank_map
        ]
        degenerate_indices = {
            int(row["entity_index"])
            for row in adaptive_selection["entities"]
            if any(
                residual["status"] == "degenerate"
                for residual in row["residuals"]
            )
        }
        nondegenerate_counts = [
            count
            for index, count in enumerate(adaptive_scalar_counts)
            if index not in degenerate_indices
        ]
        adaptive_selection["storage_ratio_including_degenerate"] = (
            sum(adaptive_scalar_counts)
            / (len(adaptive_scalar_counts) * adaptive_full_scalars)
        )
        adaptive_selection["storage_ratio_excluding_degenerate"] = (
            sum(nondegenerate_counts)
            / (len(nondegenerate_counts) * adaptive_full_scalars)
            if nondegenerate_counts
            else None
        )
        margin_selection = None
        if args.margin_aware_experiment:
            current_storage_target = int(sum(adaptive_scalar_counts))
            margin_selection = select_margin_aware_representations(
                selection_covariances,
                selection_full_distances,
                source_count=len(sources),
                target_storage_scalars=current_storage_target,
                storage_tolerance=0.005,
            )
            if not margin_selection["selection_paused"]:
                margin_selection_covariances = apply_entity_representations(
                    selection_covariances,
                    margin_selection["selected_representations"],
                )
                margin_selection_distances, _ = timed_distances(
                    selection_means,
                    margin_selection_covariances,
                    len(sources),
                    args.timing_repeats,
                )
                margin_selection["selection_stream_gate"] = {
                    "winner_agreement": winner_agreement(
                        margin_selection_distances, selection_full_distances
                    ),
                    "mean_relative_distance_error": (
                        mean_relative_distance_error(
                            margin_selection_distances,
                            selection_full_distances,
                        )
                    ),
                    "slack_diagnostics": slack_diagnostics(
                        selection_full_distances,
                        margin_selection_distances,
                    ),
                }
            else:
                margin_selection["selection_stream_gate"] = None
        full_scalars = stored_scalars_per_entity(
            projection_dimension, "full"
        )
        passing_ranks = [
            row
            for row in rank_results
            if row["winner_agreement_with_full_budget_covariance"]
            >= args.min_compression_winner_agreement
            and row[
                "mean_relative_distance_error_with_full_budget_covariance"
            ]
            <= args.max_compression_distance_error
            and row["stored_scalars_per_entity_including_mean"] < full_scalars
        ]
        if profile.name in profile_rank_overrides:
            override = profile_rank_overrides[profile.name]
            selected_rank_row = next(
                (row for row in passing_ranks if row["rank"] == override),
                None,
            )
            if selected_rank_row is None:
                raise ValueError(
                    f"{profile.name}: predeclared rank {override} does not "
                    "pass the selection gate"
                )
        else:
            selected_rank_row = min(
                passing_ranks or rank_results,
                key=lambda row: (
                    row["stored_scalars_per_entity_including_mean"],
                    row["rank"],
                ),
            )
        selected_rank = int(selected_rank_row["rank"])
        gate_authorized = bool(passing_ranks)
        reporter.report(
            cell=str(current_progress["cell"]),
            world_budget=args.gate_budget,
            method="selection_full_covariance",
            completed_unit_seconds=(
                selection_generation_seconds
                + selection_encoder_seconds
                + selection_moment_seconds
            ),
        )

        exactness_worlds, _ = time_world_generation(
            profile,
            args.exactness_worlds,
            args.selection_seed + 10000,
        )
        exactness_errors = []
        with torch.no_grad():
            for world in exactness_worlds:
                weights = torch.tensor(world.state, dtype=torch.float32)
                exactness_errors.append(
                    float(
                        torch.max(
                            torch.abs(
                                full_forward(weights) - local_forward(weights)
                            )
                        ).item()
                    )
                )
        max_exactness_error = max(exactness_errors)
        local_check = {
            "profile": profile.name,
            "worlds": args.exactness_worlds,
            "max_embedding_absolute_error": max_exactness_error,
            "tolerance": args.exactness_tolerance,
            "passes": max_exactness_error <= args.exactness_tolerance,
        }
        local_checks.append(local_check)

        for seed in args.test_seeds:
            for budget in budgets:
                unit_key = resume_unit_key(profile.name, seed, budget)
                saved_unit = resume_state["completed_units"].get(unit_key)
                if saved_unit is not None:
                    saved_rows = saved_unit.get("rows")
                    if not isinstance(saved_rows, list) or len(saved_rows) != 3:
                        raise ValueError(f"resume unit {unit_key} has invalid rows")
                    all_rows.extend(saved_rows)
                    saved_gate = saved_unit.get("gate_check")
                    if saved_gate is not None:
                        gate_checks.append(saved_gate)
                    for saved_row in saved_rows:
                        reporter.report(
                            cell=f"{args.cell_label}/{profile.name}",
                            world_budget=budget,
                            method=f"resume:{saved_row['method']}",
                            completed_unit_seconds=0.0,
                        )
                    continue
                full_worlds, full_generation_seconds = time_world_generation(
                    profile, budget, seed
                )
                local_worlds, local_generation_seconds = time_world_generation(
                    profile,
                    budget,
                    seed,
                    local_edge_indices=set(scope.sampled_edge_indices),
                )
                current_progress.update(
                    cell=f"{args.cell_label}/{profile.name}",
                    world_budget=budget,
                    method="full_world_mc",
                )
                full_hidden, full_encoder_seconds = encode_worlds(
                    full_worlds, full_forward, heartbeat=heartbeat
                )
                current_progress["method"] = "scope_exact_local_mc"
                local_hidden, local_encoder_seconds = encode_worlds(
                    local_worlds, local_forward, heartbeat=heartbeat
                )
                full_means, full_covariances, full_moment_seconds = (
                    project_and_summarize(full_hidden, projection)
                )
                local_means, local_covariances, local_moment_seconds = (
                    project_and_summarize(local_hidden, projection)
                )
                full_distances, full_matching_seconds = timed_distances(
                    full_means,
                    full_covariances,
                    len(sources),
                    args.timing_repeats,
                )
                local_distances, local_matching_seconds = timed_distances(
                    local_means,
                    local_covariances,
                    len(sources),
                    args.timing_repeats,
                )
                full_bytes = full_payload_bytes(
                    full_means, full_covariances
                )
                local_bytes = full_payload_bytes(
                    local_means, local_covariances
                )

                operator_metadata = {
                    "format": "pkgea-www-equal-budget-low-rank-v1",
                    "dataset_revision": dataset_revision_digest(profile.root),
                    "checkpoint_sha256": sha256(checkpoint_path),
                    "profile": profile.name,
                    "sample_count": budget,
                    "seed": seed,
                    "projection_dimension": projection_dimension,
                    "rank": selected_rank,
                    "selection_seed": args.selection_seed,
                    "gate_budget": args.gate_budget,
                    "workload_digest": workload_digest,
                }
                (
                    payload,
                    factors,
                    residuals,
                    operator_construction_seconds,
                ) = low_rank_payload(
                    local_means,
                    local_covariances,
                    selected_rank,
                    operator_metadata,
                )
                operator_covariances = np.einsum(
                    "edr,efr->edf", factors, factors, optimize=True
                )
                diagonal = np.arange(projection_dimension)
                operator_covariances[:, diagonal, diagonal] += residuals
                operator_distances, operator_matching_seconds = timed_distances(
                    local_means,
                    operator_covariances,
                    len(sources),
                    args.timing_repeats,
                )
                operator_cold_seconds = time_cold_operator(
                    payload, len(sources), args.timing_repeats
                )
                compression_agreement = winner_agreement(
                    operator_distances, local_distances
                )
                compression_distance_error = mean_relative_distance_error(
                    operator_distances, local_distances
                )

                full_row = metric_row(
                    profile=profile,
                    seed=seed,
                    budget=budget,
                    method="full_world_mc",
                    distances=full_distances,
                    reference_distances=reference_distances,
                    truth_positions=truth_positions,
                    stored_scalars=full_scalars,
                    actual_artifact_bytes=full_bytes,
                    world_generation_seconds=full_generation_seconds,
                    encoder_seconds=full_encoder_seconds,
                    moment_seconds=full_moment_seconds,
                    compression_seconds=0.0,
                    online_warm_seconds=full_matching_seconds,
                    online_cold_seconds=full_matching_seconds,
                    sampled_edges_per_world=len(heads),
                    encoder_rows_per_world=2 * len(entity_ids),
                )
                local_row = metric_row(
                    profile=profile,
                    seed=seed,
                    budget=budget,
                    method="scope_exact_local_mc",
                    distances=local_distances,
                    reference_distances=reference_distances,
                    truth_positions=truth_positions,
                    stored_scalars=full_scalars,
                    actual_artifact_bytes=local_bytes,
                    world_generation_seconds=local_generation_seconds,
                    encoder_seconds=local_encoder_seconds,
                    moment_seconds=local_moment_seconds,
                    compression_seconds=0.0,
                    online_warm_seconds=local_matching_seconds,
                    online_cold_seconds=local_matching_seconds,
                    sampled_edges_per_world=len(scope.sampled_edge_indices),
                    encoder_rows_per_world=local_encoder_rows_per_world,
                )
                operator_row = metric_row(
                    profile=profile,
                    seed=seed,
                    budget=budget,
                    method="low_rank_operator",
                    distances=operator_distances,
                    reference_distances=reference_distances,
                    truth_positions=truth_positions,
                    stored_scalars=stored_scalars_per_entity(
                        projection_dimension,
                        "low_rank",
                        rank=selected_rank,
                    ),
                    actual_artifact_bytes=len(payload),
                    world_generation_seconds=local_generation_seconds,
                    encoder_seconds=local_encoder_seconds,
                    moment_seconds=local_moment_seconds,
                    compression_seconds=operator_construction_seconds,
                    online_warm_seconds=operator_matching_seconds,
                    online_cold_seconds=operator_cold_seconds,
                    sampled_edges_per_world=len(scope.sampled_edge_indices),
                    encoder_rows_per_world=local_encoder_rows_per_world,
                    compression_agreement=compression_agreement,
                    compression_distance_error=compression_distance_error,
                    selected_rank=selected_rank,
                )
                logical_entity_count = len(query_entities)
                for row in (full_row, local_row, operator_row):
                    row["logical_index_bytes_float32"] = (
                        int(row["stored_scalars_per_entity_including_mean"])
                        * logical_entity_count
                        * 4
                    )
                    all_rows.append(row)
                reporter.report(
                    cell=f"{args.cell_label}/{profile.name}",
                    world_budget=budget,
                    method="full_world_mc",
                    completed_unit_seconds=float(full_row["fresh_end_to_end_seconds"]),
                )
                reporter.report(
                    cell=f"{args.cell_label}/{profile.name}",
                    world_budget=budget,
                    method="scope_exact_local_mc",
                    completed_unit_seconds=float(local_row["fresh_end_to_end_seconds"]),
                )
                reporter.report(
                    cell=f"{args.cell_label}/{profile.name}",
                    world_budget=budget,
                    method=f"lowrank_r{selected_rank}",
                    completed_unit_seconds=float(operator_row["fresh_end_to_end_seconds"]),
                )
                gate_check = None
                if budget == args.gate_budget:
                    adaptive_gate = {
                        "selection_paused": bool(
                            adaptive_selection["selection_paused"]
                        ),
                        "passes": False,
                    }
                    if not adaptive_selection["selection_paused"]:
                        adaptive_covariances = apply_entity_adaptive_ranks(
                            local_covariances, adaptive_rank_map
                        )
                        adaptive_distances, _ = timed_distances(
                            local_means,
                            adaptive_covariances,
                            len(sources),
                            args.timing_repeats,
                        )
                        adaptive_agreement = winner_agreement(
                            adaptive_distances, local_distances
                        )
                        adaptive_error = mean_relative_distance_error(
                            adaptive_distances, local_distances
                        )
                        adaptive_gate = {
                            "selection_paused": False,
                            "winner_agreement": adaptive_agreement,
                            "mean_relative_distance_error": adaptive_error,
                            "slack_diagnostics": slack_diagnostics(
                                local_distances, adaptive_distances
                            ),
                            "passes": (
                                adaptive_agreement
                                >= args.min_compression_winner_agreement
                                and adaptive_error
                                <= args.max_compression_distance_error
                                and adaptive_selection[
                                    "storage_ratio_including_degenerate"
                                ]
                                < 1.0
                            ),
                        }
                        adaptive_metadata = {
                            "format": "pkgea-www-entity-adaptive-v1",
                            "dataset_revision": dataset_revision_digest(profile.root),
                            "checkpoint_sha256": sha256(checkpoint_path),
                            "profile": profile.name,
                            "sample_count": budget,
                            "seed": seed,
                            "projection_dimension": projection_dimension,
                            "selection_seed": args.selection_seed,
                            "gate_budget": args.gate_budget,
                            "workload_digest": workload_digest,
                        }
                        adaptive_bytes, adaptive_serialization_seconds = adaptive_payload(
                            local_means, local_covariances, adaptive_rank_map,
                            adaptive_metadata,
                        )
                        adaptive_timing = time_adaptive_operator(
                            adaptive_bytes, len(sources), args.timing_repeats
                        )
                        effective_gain = float(full_row["fresh_end_to_end_seconds"]) - adaptive_timing["warm_seconds"]
                        adaptive_offline = (
                            local_generation_seconds + local_encoder_seconds
                            + local_moment_seconds + adaptive_serialization_seconds
                        )
                        break_even = (
                            math.ceil(adaptive_offline / effective_gain)
                            if adaptive_gate["passes"] and effective_gain > 0
                            else None
                        )
                        adaptive_gate["serving_measurement"] = {
                            "diagnostic_artifact_even_if_gate_fails": True,
                            "effective_policy": (
                                "entity_adaptive_mixed_rank"
                                if adaptive_gate["passes"]
                                else "full_covariance_fallback"
                            ),
                            "serialized_bytes": len(adaptive_bytes),
                            "serialization_seconds": adaptive_serialization_seconds,
                            **adaptive_timing,
                            "offline_build_seconds": adaptive_offline,
                            "break_even_query_batches": break_even,
                            "vram": "structurally_inapplicable",
                        }
                    margin_aware_gate = None
                    diagonal_gate = None
                    if args.margin_aware_experiment:
                        if margin_selection is None:
                            raise AssertionError(
                                "margin experiment missing selection-only map"
                            )
                        margin_aware_gate = {
                            "selection_paused": bool(
                                margin_selection["selection_paused"]
                            ),
                            "selection_data_contract": margin_selection[
                                "selection_data_contract"
                            ],
                            "storage_neutrality_passes": margin_selection[
                                "storage_neutrality_passes"
                            ],
                            "storage_relative_deviation": margin_selection[
                                "storage_relative_deviation"
                            ],
                            "logical_storage_scalars": margin_selection[
                                "selected_storage_scalars"
                            ],
                            "passes": False,
                        }
                        if not margin_selection["selection_paused"]:
                            margin_covariances = apply_entity_representations(
                                local_covariances,
                                margin_selection["selected_representations"],
                            )
                            margin_distances, _ = timed_distances(
                                local_means,
                                margin_covariances,
                                len(sources),
                                args.timing_repeats,
                            )
                            margin_agreement = winner_agreement(
                                margin_distances, local_distances
                            )
                            margin_error = mean_relative_distance_error(
                                margin_distances, local_distances
                            )
                            margin_aware_gate.update(
                                {
                                    "winner_agreement": margin_agreement,
                                    "mean_relative_distance_error": margin_error,
                                    "slack_diagnostics": slack_diagnostics(
                                        local_distances, margin_distances
                                    ),
                                    "passes": (
                                        margin_agreement
                                        >= args.min_compression_winner_agreement
                                        and margin_error
                                        <= args.max_compression_distance_error
                                        and margin_selection[
                                            "storage_neutrality_passes"
                                        ]
                                        and margin_selection[
                                            "selected_storage_scalars"
                                        ]
                                        < len(query_entities) * full_scalars
                                    ),
                                }
                            )
                        diagonal_covariances = approximate_covariance_batch(
                            local_covariances, "diagonal"
                        )
                        diagonal_distances, _ = timed_distances(
                            local_means,
                            diagonal_covariances,
                            len(sources),
                            args.timing_repeats,
                        )
                        diagonal_agreement = winner_agreement(
                            diagonal_distances, local_distances
                        )
                        diagonal_error = mean_relative_distance_error(
                            diagonal_distances, local_distances
                        )
                        diagonal_scalar_total = (
                            len(query_entities)
                            * stored_scalars_per_entity(
                                projection_dimension, "diagonal"
                            )
                        )
                        diagonal_gate = {
                            "winner_agreement": diagonal_agreement,
                            "mean_relative_distance_error": diagonal_error,
                            "slack_diagnostics": slack_diagnostics(
                                local_distances, diagonal_distances
                            ),
                            "logical_storage_scalars": diagonal_scalar_total,
                            "logical_storage_ratio": (
                                diagonal_scalar_total
                                / (len(query_entities) * full_scalars)
                            ),
                            "stored_scalars_per_entity": (
                                stored_scalars_per_entity(
                                    projection_dimension, "diagonal"
                                )
                            ),
                            "passes": (
                                diagonal_agreement
                                >= args.min_compression_winner_agreement
                                and diagonal_error
                                <= args.max_compression_distance_error
                            ),
                        }
                    gate_check = {
                            "profile": profile.name,
                            "seed": seed,
                            "budget": budget,
                            "rank": selected_rank,
                            "compression_winner_agreement": (
                                compression_agreement
                            ),
                            "compression_mean_relative_distance_error": (
                                compression_distance_error
                            ),
                            "passes": gate_authorized
                            and compression_agreement
                            >= args.min_compression_winner_agreement
                            and compression_distance_error
                            <= args.max_compression_distance_error,
                            "entity_adaptive_rank_gate": adaptive_gate,
                        }
                    if args.margin_aware_experiment:
                        gate_check["margin_aware_rank_gate"] = margin_aware_gate
                        gate_check["diagonal_only_gate"] = diagonal_gate
                    gate_checks.append(gate_check)
                resume_state["completed_units"][unit_key] = {
                    "cell": args.cell_label,
                    "profile": profile.name,
                    "seed": seed,
                    "world_budget": budget,
                    "rows": [full_row, local_row, operator_row],
                    "gate_check": gate_check,
                }
                atomic_write_json(resume_path, resume_state)
                release_hidden_samples(full_hidden)
                release_hidden_samples(local_hidden)

        profile_reports.append(
            {
                "profile": profile.name,
                "dataset_dir": str(profile.root),
                "dataset_revision": dataset_revision_digest(profile.root),
                "edge_dependence_assumption": profile.dependence_assumption,
                "common_shock_probability": profile.common_shock_probability,
                "query_count": len(sources),
                "available_test_query_count": available_source_count,
                "candidate_count": len(targets),
                "candidate_limit": args.candidate_limit,
                "candidate_pool_source": (
                    "full"
                    if args.candidate_limit is None
                    else "truth_preserving_prefix"
                ),
                "workload_digest": workload_digest,
                "covariance_entity_count": len(query_entities),
                "truth_retention": truth_retention,
                "candidate_order_preserved": candidate_order_preserved,
                "query_entity_count": len(query_entities),
                "scope": {
                    **scope.as_dict(),
                    "message_passing_steps": adapter.message_passing_steps,
                    "normalization_family": adapter.normalization_family,
                    "local_execution_mode": local_execution_mode,
                    "row_reduction_claimed": local_execution_mode
                    == "row_restricted_exact",
                },
                "scope_edge_fraction": len(scope.sampled_edge_indices)
                / len(heads),
                "scope_encoder_row_fraction": local_encoder_rows_per_world
                / (2 * len(entity_ids)),
                "reference": {
                    "sample_count": args.reference_samples,
                    "seed": args.reference_seed,
                    "world_generation_seconds": reference_generation_seconds,
                    "encoder_seconds": reference_encoder_seconds,
                    "moment_construction_seconds": reference_moment_seconds,
                    "matching_seconds": reference_matching_seconds,
                    "top1_accuracy": truth_accuracy(
                        reference_distances, truth_positions
                    ),
                    "mrr": truth_mrr(reference_distances, truth_positions),
                },
                "rank_gate": {
                    "selection_seed": args.selection_seed,
                    "sample_count": args.gate_budget,
                    "thresholds": {
                        "max_compression_distance_error": (
                            args.max_compression_distance_error
                        ),
                        "min_compression_winner_agreement": (
                            args.min_compression_winner_agreement
                        ),
                        "compression_required": True,
                    },
                    "candidate_results": rank_results,
                    "entity_adaptive_selection": adaptive_selection,
                    "selected_rank": selected_rank,
                    "rank_override": profile_rank_overrides.get(profile.name),
                    "authorized_on_selection": gate_authorized,
                    "selection_world_generation_seconds": (
                        selection_generation_seconds
                    ),
                    "selection_encoder_seconds": selection_encoder_seconds,
                    "selection_moment_seconds": selection_moment_seconds,
                },
                "local_exactness": local_check,
            }
        )
        if args.margin_aware_experiment:
            profile_reports[-1]["rank_gate"][
                "margin_aware_selection"
            ] = margin_selection

    assert query_entity_count is not None
    profile_authorization = {
        profile.name: bool(
            [row for row in gate_checks if row["profile"] == profile.name]
        )
        and all(
            row["passes"]
            for row in gate_checks
            if row["profile"] == profile.name
        )
        for profile in profiles
    }
    for row in all_rows:
        row["held_out_authorized"] = (
            profile_authorization[str(row["profile"])]
            if row["method"] == "low_rank_operator"
            and int(row["world_budget"]) == args.gate_budget
            else None
        )
    for report in profile_reports:
        report["rank_gate"]["authorized_on_held_out"] = (
            profile_authorization[str(report["profile"])]
        )
    headline = aggregate_headline(all_rows, args.gate_budget, query_entity_count)
    headline["operator_authorization"] = {
        "by_profile": profile_authorization,
        "all_profiles_authorized": all(profile_authorization.values()),
    }
    effective_profiles: dict[str, dict[str, object]] = {}
    for profile in profiles:
        profile_rows = [
            row
            for row in all_rows
            if row["profile"] == profile.name
            and int(row["world_budget"]) == args.gate_budget
        ]
        effective_method = (
            "low_rank_operator"
            if profile_authorization[profile.name]
            else "scope_exact_local_mc"
        )
        effective_rows = [
            row for row in profile_rows if row["method"] == effective_method
        ]
        effective_profiles[profile.name] = {
            "authorized_compression": profile_authorization[profile.name],
            "effective_method": (
                effective_method
                if profile_authorization[profile.name]
                else "full_covariance_fallback"
            ),
            "mean_stored_scalars_per_entity": statistics.mean(
                int(row["stored_scalars_per_entity_including_mean"])
                for row in effective_rows
            ),
            "mean_actual_artifact_bytes": statistics.mean(
                int(row["actual_compressed_artifact_bytes"])
                for row in effective_rows
            ),
            "diagnostic_low_rank_must_not_be_served": not profile_authorization[
                profile.name
            ],
        }
    headline["effective_serving_policy"] = {
        "by_profile": effective_profiles,
        "mean_stored_scalars_per_entity": statistics.mean(
            float(row["mean_stored_scalars_per_entity"])
            for row in effective_profiles.values()
        ),
        "mean_actual_artifact_bytes": statistics.mean(
            float(row["mean_actual_artifact_bytes"])
            for row in effective_profiles.values()
        ),
    }
    result = {
        "format": FORMAT,
        "created_on": time.strftime("%Y-%m-%d"),
        "protocol": {
            "estimand": (
                "top-1 candidate under Gaussian W2 distances between "
                "PCA-projected learned-GCN hidden-state distributions"
            ),
            "budgets": budgets,
            "gate_budget": args.gate_budget,
            "selection_seed": args.selection_seed,
            "test_seeds": list(args.test_seeds),
            "reference_seed": args.reference_seed,
            "reference_samples": args.reference_samples,
            "projection_dimension": args.projection_dimension,
            "timing_repeats": args.timing_repeats,
            "profile_rank_overrides": profile_rank_overrides,
            "query_limit": args.query_limit,
            "candidate_limit": args.candidate_limit,
            "hardware_contract": (
                "single process, PyTorch CPU, torch.set_num_threads(1); all "
                "methods executed sequentially on the same machine"
            ),
            "accounting_contract": (
                "fresh end-to-end includes world generation, encoder, moment "
                "construction/compression and one query batch; low-rank cold "
                "and warm online latency are additionally reported; the "
                "high-budget reference is excluded from method latency"
            ),
            "scope_baseline_boundary": (
                "The local baseline inherits the scorer-scope idea only. It "
                "estimates the WWW Gaussian target and does not reuse WSDM "
                "confidence sequences, stopping, scheduling, tables or figures."
            ),
        },
        "inputs": {
            "checkpoint_path": str(checkpoint_path),
            "checkpoint_sha256": sha256(checkpoint_path),
            "checkpoint_format": checkpoint["format"],
            "adapter_format_id": adapter.descriptor_adapter_id,
            "checkpoint_execution_format": adapter.format_id,
            "normalization_family": adapter.normalization_family,
            "message_passing_steps": adapter.message_passing_steps,
            "checkpoint_hidden_dimension": int(checkpoint["dimension"]),
            "entity_count": len(entity_ids),
            "edge_count": len(heads),
        },
        "runtime": {
            "python": sys.version.split()[0],
            "numpy": np.__version__,
            "torch": torch.__version__,
            "torch_cuda_build": torch.version.cuda,
            "cuda_available": torch.cuda.is_available(),
            "platform": platform.platform(),
            "processor": platform.processor(),
            "process_id": os.getpid(),
            "resource_peaks": reporter.peak,
            "telemetry_contract": (
                "synchronous batch-boundary sampling; no polling thread; "
                "telemetry overhead excluded from encoder timing"
            ),
        },
        "resume": {
            "schema_version": RESUME_FORMAT,
            "path": str(resume_path),
            "enabled": bool(args.resume),
            "protocol_digest": protocol_digest,
            "completed_unit_count": len(resume_state["completed_units"]),
        },
        "profiles": profile_reports,
        "rows": all_rows,
        "headline": headline,
        "validation": {
            "local_exactness_checks": local_checks,
            "all_local_exactness_checks_pass": bool(local_checks)
            and all(row["passes"] for row in local_checks),
            "held_out_gate_checks": gate_checks,
            "all_held_out_gate_checks_pass": bool(gate_checks)
            and all(row["passes"] for row in gate_checks),
            "selection_reference_test_disjoint": True,
            "equal_budget_row_contract": True,
        },
        "claim_boundary": (
            "The low-rank branch is an empirically authorized, workload-bound "
            "serving artifact. "
            "Its warm latency excludes offline world encoding, which is reported "
            "separately. The result does not prove a universal covariance rank, "
            "an anytime winner guarantee, or full analytic propagation through "
            "an arbitrary nonlinear GNN."
        ),
    }
    if args.margin_aware_experiment:
        result["protocol"]["margin_aware_experiment"] = True
        result["protocol"]["margin_aware_contract"] = (
            "selection-seed-only W2 self-distortion allocation; lambda is "
            "calibrated to the current selector's logical storage within "
            "0.5%; held-out winner and error gates are unchanged"
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(
            result, ensure_ascii=False, indent=2, allow_nan=False
        ) + "\n",
        encoding="utf-8",
    )
    if markdown_output is not None:
        write_markdown(result, markdown_output)
    print(
        json.dumps(
            result["headline"], ensure_ascii=False, indent=2, allow_nan=False
        )
    )


if __name__ == "__main__":
    main()
