"""Package all artifacts generated in this round (4090D consolidated sync +
CPU acceptance archival) into a single zip with a SHA256 manifest, per user
preference: package all generated materials into ONE file."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

REPO = Path(r"E:\pkgea")
OUT_ZIP = REPO / "icde_consolidated_sync_20261009.zip"

ENTRIES: list[tuple[Path, str]] = []


def add(p: Path, arc: str | None = None) -> None:
    if not p.exists():
        raise FileNotFoundError(p)
    ENTRIES.append((p, arc or p.relative_to(REPO).as_posix()))


def add_dir(d: Path, arc_prefix: str) -> None:
    if not d.is_dir():
        raise FileNotFoundError(d)
    for p in sorted(d.rglob("*")):
        if p.is_file():
            ENTRIES.append((p, arc_prefix + "/" + p.relative_to(d).as_posix()))


# 1) sync record + newly archived docs
add(REPO / "papers/icde/CONSOLIDATED_SYNC_20261009.md")
add(REPO / "papers/icde/FULL_RETURN_V2_REVIEW_20261009.md")
add(REPO / "papers/icde/HANDOFF_CONSOLIDATED_20261009.md")

# 2) comparison/sync scripts and logs
add(REPO / "scripts/check_full_bundle_vs_repo.py")
add(REPO / "scripts/sync_icde_bundle_to_repo.py")
add(REPO / "output/full_bundle_vs_repo_20261009.log")
add(REPO / "output/sync_diff_20261009.log")

# 3) updated status.toml
add(REPO / "nodes/05_icde_query_engine/status.toml")

# 4) archived CPU acceptance evidence (38 files + handoff kit)
add_dir(
    REPO / "nodes/05_icde_query_engine/results/consolidated_cpu_acceptance_20261009",
    "nodes/05_icde_query_engine/results/consolidated_cpu_acceptance_20261009",
)
# 5) archived Mac repair verification
add_dir(
    REPO / "nodes/05_icde_query_engine/results/local_repair_mac_verified_20261009",
    "nodes/05_icde_query_engine/results/local_repair_mac_verified_20261009",
)


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


manifest: dict[str, str] = {}
if OUT_ZIP.exists():
    OUT_ZIP.unlink()
with zipfile.ZipFile(OUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zf:
    for p, arc in ENTRIES:
        zf.write(p, arc)
        manifest[arc] = sha256(p)
    zf.writestr("BUILT_MANIFEST.json", json.dumps({
        "format": "icde-consolidated-sync-bundle-v1",
        "date": "2026-10-09",
        "host": "Windows 11 / Python 3.14.5 / numpy (no torch)",
        "consolidated_package": "icde_4090d_consolidated_20261009.zip (sha256 26a483538cfccae1c6f2819aa87b403c2d21da3ab43477abeb8c88e8ca9de250)",
        "cpu_acceptance_package": "icde_cpu_acceptance_20261009.zip",
        "key_facts": {
            "python_123_scope": "0 missing / 0 byte-different / 0 newline-only (repo == consolidated bundle)",
            "full_manifest_596": "45 missing (bundle-specific) / 4 byte-diff (E6 Windows re-run kept) / 547 newline-only (content identical)",
            "research_acceptance": "false",
            "target_host_inventory_pending": ["OS", "Python", "GPU/CUDA/driver", "CPU/RAM/NVMe", "thread/resource budget"],
        },
        "files": manifest,
    }, ensure_ascii=False, indent=2))

with zipfile.ZipFile(OUT_ZIP) as zf:
    total = sum(1 for n in zf.namelist() if not n.endswith("/"))
    crc = zf.testzip()
zip_sha = sha256(OUT_ZIP)
print(f"wrote {OUT_ZIP}")
print(f"entries: {total} (crc errors: {crc})")
print(f"zip sha256: {zip_sha}")
