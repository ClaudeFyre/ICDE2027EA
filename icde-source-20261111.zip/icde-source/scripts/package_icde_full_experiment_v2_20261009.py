"""Build/verify the 2026-10-09 v2 full-experiment handoff bundle (post-review).

Whitelist-only expansion of scripts/package_icde_full_experiment_20261009.py:
- all of src/pkgea (exclude __pycache__ / compiled)
- the 9 ICDE test files
- all ICDE-related scripts (incl. backbones/torch_gcn_*)
- papers/icde round docs + review docs
- whole nodes/05/experiments tree
- enumerated results subtrees (v1 traces 24, v2 traces 48, e0..e6, p1, oaei_v2,
  full_return_audit, local_pilot approved products)
- toy + derived probe data (digest noted in manifest)
- root README.md / pyproject.toml / status.toml

Exclude OAEI raw dumps, checkpoints, SQLite/WAL, WWW/WSDM result dumps, venv/.runtime/__pycache__.
"""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# --- src/pkgea all (exclude __pycache__ / bytecode) -------------------------
def src_pkgea_files():
    out = []
    for p in sorted((ROOT / "src/pkgea").rglob("*")):
        if not p.is_file():
            continue
        if "__pycache__" in p.parts or p.suffix in (".pyc", ".pyo"):
            continue
        out.append(p)
    return out

# --- the 9 ICDE test files ---------------------------------------------------
TESTS = [
    "test_modal_query.py",
    "test_icde_oaei_intake.py",
    "test_query.py",
    "test_certified.py",
    "test_certified_clock.py",
    "test_extensions.py",
    "test_scope.py",
    "test_sampler_factor_law.py",
    "test_revision_stopping_cost.py",
]

# --- ICDE-related scripts (root + backbones) --------------------------------
SCRIPTS_ROOT = [
    "icde_paths.py",
    "run_icde_local_pilot.py",
    "verify_icde_local_replay.py",
    "icde_host_preflight.py",
    "audit_icde_oaei_intake.py",
    "audit_icde_oaei_v2_intake.py",
    "audit_icde_gcn_winners.py",
    "audit_icde_full_return.py",
    "package_icde_local_pilot.py",
    "package_icde_full_experiment_20261009.py",
    "icde_baseline_suite.py",
    "icde_exp_common.py",
    "icde_e5_planner_harness.py",
    "icde_e5_official_eval.py",
    "icde_e5_rebuild_v2.py",
    "icde_system_figure.py",
    "icde_contract_smoke.py",
    "build_icde_p1_traces.py",
    "build_icde_p1_traces_v2.py",
    "validate_icde_p1_traces.py",
    "validate_icde_p1_traces_v2.py",
    "run_icde_p1_update_loop.py",
    "run_icde_p1_baseline_compare.py",
    "stream_worker_crash_audit.py",
    "verify_recovery.py",
]
SCRIPTS_BACKBONES = [
    "torch_gcn_align.py",
    "torch_gcn_local_recompute.py",
]

# --- papers/icde: all round + review docs ------------------------------------
PAPERS_DIR = ROOT / "papers/icde"

# --- results subtrees (relative to nodes/05/results) -------------------------
N05 = Path("nodes/05_icde_query_engine")
RESULTS = ROOT / N05 / "results"
RESULTS_WHOLE = [
    "icde_e0_20261009",
    "icde_e1_20261009",
    "icde_e2_20261009",
    "icde_e3_20261009",
    "icde_e4_20261009",
    "icde_e5_20261009",
    "icde_e6_20261009",
    "icde_oaei_v2_20261009",
    "icde_p1_20261009",
    "icde_traces_20261009",
    "icde_traces_v2_20261009",
    "full_return_audit_20261009",
    "local_pilot_20261009",
]
RESULTS_EXTRA_FILES = [
    RESULTS / "icde_full_acceptance_20261009.json",
    RESULTS / "icde_full_acceptance_v2_20261009.json",
]

# --- derived data ------------------------------------------------------------
DATA_TOY = ROOT / "data/toy/exact_world_minimal"
DATA_PROBE = ROOT / "data/interim/openea-d-w-probe-q32-a64-attributes-independent-s17"


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _is_excluded(p: Path) -> bool:
    low = p.as_posix().lower()
    if "__pycache__" in low or p.suffix in (".pyc", ".pyo"):
        return True
    if low.endswith((".sqlite", ".db", ".wal", ".ckpt", ".pt", ".pth")):
        return True
    # OAEI raw dumps / references excluded; only the audit+frozen manifest ship
    if "data/raw/" in low:
        return True
    return False


def collect_files():
    files = set()

    # src/pkgea all
    for p in src_pkgea_files():
        files.add(p)

    # tests (the 9 ICDE files)
    for rel in TESTS:
        files.add(ROOT / "tests" / rel)

    # scripts
    for rel in SCRIPTS_ROOT:
        files.add(ROOT / "scripts" / rel)
    for rel in SCRIPTS_BACKBONES:
        files.add(ROOT / "scripts/backbones" / rel)

    # papers/icde all markdown this round + review docs
    for p in sorted(PAPERS_DIR.glob("*.md")):
        files.add(p)

    # experiments whole tree
    exp = ROOT / N05 / "experiments"
    for p in sorted(exp.rglob("*")):
        if p.is_file() and not _is_excluded(p):
            files.add(p)

    # results whole subtrees
    for sub in RESULTS_WHOLE:
        d = RESULTS / sub
        for p in sorted(d.rglob("*")):
            if p.is_file() and not _is_excluded(p):
                files.add(p)
    for p in RESULTS_EXTRA_FILES:
        if p.is_file():
            files.add(p)

    # derived data
    for base in (DATA_TOY, DATA_PROBE):
        if base.is_dir():
            for p in sorted(base.rglob("*")):
                if p.is_file() and not _is_excluded(p):
                    files.add(p)

    # node + root handoff files
    files.add(ROOT / N05 / "status.toml")
    files.add(ROOT / N05 / "README.md")
    files.add(ROOT / "README.md")
    files.add(ROOT / "pyproject.toml")

    existing = sorted(p for p in files if p.is_file())
    return existing


def _manifest(files):
    data_digests = {}
    for base in (DATA_TOY, DATA_PROBE):
        if base.is_dir():
            for p in sorted(base.rglob("*")):
                if p.is_file():
                    data_digests[p.relative_to(ROOT).as_posix()] = _sha(p)
    return {
        "format": "icde-full-experiment-bundle-v2",
        "created": "2026-10-09",
        "files": {p.relative_to(ROOT).as_posix(): _sha(p) for p in files},
        "data_digests_note": "data/toy/exact_world_minimal 与 data/interim/...s17 为派生数据，digest 见下。",
        "data_digests": data_digests,
        "traces_v1_note": "v1 24 traces 原样保留（含 controlled_synthetic__seed17__b64 本地验证产物）。",
        "traces_v2_note": '[说明文本已清理]',
        "excluded": [
            "OAEI raw KG dumps (data/raw/...; license unconfirmed)",
            "all checkpoints / model weights (.ckpt/.pt/.pth)",
            "SQLite / WAL (.sqlite/.db/.wal)",
            "WWW/WSDM result dumps",
            "venv / .runtime / __pycache__ bytecode",
            "E:/fresh_host_v2_20261009 预演目录（仓库之外，不入包）",
        ],
        "boundary": "复核后可执行交接包；research_acceptance=false（价值门槛与 C1/C2/C3 未闭合）。计数类为硬证据，墙钟 informal。",
    }


def verify(path):
    with zipfile.ZipFile(path) as bundle:
        bad = bundle.testzip()
        if bad is not None:
            raise ValueError(f"CRC failure on {bad}")
        manifest = json.loads(bundle.read("BUNDLE_MANIFEST.json"))
        on_disk = set(bundle.namelist())
        declared = set(manifest["files"]) | {"BUNDLE_MANIFEST.json"}
        if on_disk != declared:
            raise ValueError(
                f"inventory mismatch: only-in-zip={on_disk - declared} only-in-manifest={declared - on_disk}"
            )
        for name, checksum in manifest["files"].items():
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError(f"unsafe bundle path: {name}")
            if hashlib.sha256(bundle.read(name)).hexdigest() != checksum:
                raise ValueError(f"checksum mismatch: {name}")
        # leak guards
        for name in bundle.namelist():
            low = name.lower()
            if low.endswith((".sqlite", ".db", ".wal", ".ckpt", ".pt", ".pth")):
                raise ValueError(f"excluded artifact leaked: {name}")
            if "data/raw/" in low:
                raise ValueError(f"raw dump leaked: {name}")
    return {
        "verified": True,
        "crc_testzip_passed": True,
        "files": len(manifest["files"]),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path)
    ap.add_argument("--verify", type=Path)
    args = ap.parse_args()
    if args.verify:
        print(json.dumps(verify(args.verify), indent=2))
        return
    if args.output is None or args.output.exists():
        raise ValueError("choose a fresh bundle output")
    files = collect_files()
    manifest = _manifest(files)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED) as bundle:
        for path in files:
            bundle.write(path, path.relative_to(ROOT).as_posix())
        bundle.writestr("BUNDLE_MANIFEST.json", json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    result = verify(args.output)
    out_manifest = {**manifest, "verification": result}
    args.output.with_suffix(".manifest.json").write_text(
        json.dumps(out_manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
