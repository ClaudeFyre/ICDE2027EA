"""Independent arithmetic and action audit of the controlled exact-review gate.

No original exact-reference routine is imported. Vertex distributions are
recomputed with reverse-axis, out-of-place Fraction contraction. Stored minimum
vertices, independently located maxima and unsafe witnesses are also checked by
direct product-mass enumeration. The scorer and RNG are not rerun.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import struct
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
SALT = "vldb-v0-20261104"
PURPOSE = "icde-exact-review-20261105"
TAUS = (.001, .01, .05, .1, .25, 1.)
MC_POLICIES = ("ppr_nominal", "normal_scope", "normal_event", "normal_hybrid")
POINT_POLICIES = ("point_all_present", "point_margin_gt_0.01", "point_margin_gt_0.05",
                  "point_margin_gt_0.1", "point_margin_gt_0.2")
FLAGS = ("approved", "uniform_safe", "false_clear", "reviewed", "avoidable_review",
         "exists_uniform_winner", "exact_ambiguous")


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def inside(path, parent=ROOT):
    path = Path(str(path).replace("\\", "/"))
    path = path.resolve() if path.is_absolute() else (ROOT / path).resolve()
    path.relative_to(Path(parent).resolve())
    return path


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


class Checks:
    def __init__(self):
        self.counts, self.errors = Counter(), Counter()
        self.examples = []

    def require(self, condition, name, context):
        self.counts[name] += 1
        if not condition:
            self.errors[name] += 1
            if len(self.examples) < 100:
                self.examples.append({"check": name, "context": context})

    def close(self, left, right, name, context):
        self.require(math.isclose(left, right, rel_tol=1e-10, abs_tol=1e-8), name, context)


def direct_distribution(winners, k, probabilities):
    """Independent sum of exact masses of all original Boolean assignments."""
    result = [F(0) for _ in range(k)]
    for assignment, winner in enumerate(winners):
        factors = [probability if (assignment // (2 ** edge)) % 2 else 1 - probability
                   for edge, probability in enumerate(probabilities)]
        mass = F(1)
        for factor in factors:
            mass *= factor
        result[winner] += mass
    return result


def reverse_vertex_distributions(winners, k, low, high):
    """Reverse coordinate order and separate output buffers from the generator."""
    width = len(low)
    distributions = []
    for candidate in range(k):
        current = [F(winner == candidate) for winner in winners]
        for axis in range(width - 1, -1, -1):
            stride = 2 ** axis
            output = [F(0)] * len(current)
            for block in range(0, len(current), 2 * stride):
                for offset in range(stride):
                    zero, one = block + offset, block + offset + stride
                    output[zero] = current[zero] + low[axis] * (current[one] - current[zero])
                    output[one] = current[zero] + high[axis] * (current[one] - current[zero])
            current = output
        distributions.append(current)
    return distributions


def bits(index, m):
    return [(index // (2 ** edge)) % 2 for edge in range(m)]


def vertex_index(vector):
    return sum(value * (2 ** edge) for edge, value in enumerate(vector))


def array_sha(values):
    return hashlib.sha256(struct.pack("<" + "d" * len(values), *values)).hexdigest()


def product_coupling(q, low, high, positions=None):
    agreement = F(1)
    for edge in (range(len(q)) if positions is None else positions):
        agreement *= 1 - max(q[edge] - low[edge], high[edge] - q[edge])
    return 1 - agreement


def addition_upper(left, right):
    exact = F.from_float(left) + F.from_float(right)
    if exact >= 1:
        return 1.
    rounded = float(exact)
    return math.nextafter(rounded, math.inf) if F.from_float(rounded) < exact else rounded


class ExactAudit:
    def __init__(self, folder):
        self.folder = folder
        self.check = Checks()
        self.protocol, self.original_summary = load(folder / "protocol_freeze.json"), load(folder / "summary.json")
        self.hashes = {}
        self.properties, self.setups, self.triples = {}, {}, {}
        self.maps, self.references, self.results = {}, {}, []
        self.prefixes, self.point_margins = {}, {}

    def file_hash(self, path):
        path = Path(path).resolve()
        if path not in self.hashes:
            self.hashes[path] = sha(path)
        return self.hashes[path]

    def identities_and_selection(self):
        p, c = self.protocol, self.check
        c.require(self.original_summary["status"] == "COMPLETE" and self.original_summary["cases"] == 1728,
                  "completed_1728_case_capture", str(self.folder))
        c.require(p["tau_grid"] == list(TAUS) and p["seed"] == 151 and p["seed_purpose"] == PURPOSE
                  and p["policies"] == list(MC_POLICIES) and p["max_scope"] == 8
                  and p["MC_outcomes_used_for_selection"] is False,
                  "frozen_study_contract", "protocol")
        for relative, expected in p["source_sha256"].items():
            path = inside(relative)
            c.require(self.file_hash(path) == expected, "frozen_runtime_and_input_hash", relative)
        for inventory in p["inventory_files"]:
            path = inside(inventory["path"])
            c.require(self.file_hash(path) == inventory["sha256"], "input_property_inventory_hash", str(path))
            report = load(path)
            for metadata in report["query_setup"]:
                key = report["graph"], metadata["query_id"]
                properties = {name: metadata[name] for name in (
                    "candidate_count", "scope_edge_count", "candidate_ids", "scope_edge_indices")}
                if key in self.properties:
                    c.require(self.properties[key] == properties, "repeat_input_properties", str(key))
                self.properties[key] = properties
        for profile in p["config"]["profiles"]:
            graph = profile["graph"]
            dataset = inside(profile["dataset_path"])
            with (dataset / "alignments.tsv").open(encoding="utf-8-sig", newline="") as handle:
                pool = [row["source_entity_id"] for row in csv.DictReader(handle, delimiter="\t") if row["split"] == "test"]
            ordered = sorted(pool, key=lambda source: (hashlib.sha256(f"{SALT}|{source}".encode()).digest(), source))
            selected = p["selection"][graph]
            c.require(len(pool) == len(set(pool)) == 500 and ordered == selected["full500_source_order"],
                      "original500_label_independent_order", graph)
            eligible = [source for source in ordered if self.properties[graph, source]["candidate_count"] > 1
                        and self.properties[graph, source]["scope_edge_count"] <= 8]
            c.require(selected["selected_query_ids"] == eligible[:16]
                and selected["eligible_count"] == len(eligible) and selected["actual_count"] == 16,
                "first16_input_property_only_selection", graph)
            for source in selected["selected_query_ids"]:
                c.require(selected["selected_properties"][source] == self.properties[graph, source],
                          "frozen_selected_property_binding", f"{graph}:{source}")
            with (dataset / "triples.tsv").open(encoding="utf-8-sig", newline="") as handle:
                self.triples[graph] = list(csv.DictReader(handle, delimiter="\t"))
            path = self.folder / ("setup_" + hashlib.sha256(graph.encode()).hexdigest()[:12] + ".json")
            setup = load(path)
            self.file_hash(path)
            c.require(setup["query_selection"]["query_ids"] == selected["selected_query_ids"]
                and setup["dataset_revision"] == selected["input_profile"]["dataset_revision"]
                and setup["input_sha256"] == selected["input_profile"]["input_sha256"], "rebuilt_setup_identity", graph)
            for metadata in setup["query_setup"]:
                key = graph, metadata["query_id"]
                c.require(all(metadata[name] == self.properties[key][name] for name in (
                    "candidate_count", "scope_edge_count", "candidate_ids", "scope_edge_indices")),
                    "rebuilt_scorer_and_scope_properties", str(key))
                c.require(metadata["candidate_audit"]["status"] == metadata["coupled_audit"]["status"] == "PASS"
                    and metadata["scope_certificate"]["exact"] is True, "recorded_scope_and_candidate_proofs", str(key))
                self.setups[key] = metadata
        c.require(len(self.setups) == 32, "exact32_query_grid", "setups")

    def winner_maps(self):
        expected = set()
        for (graph, source), metadata in self.setups.items():
            path = self.folder / "winner_maps" / (
                hashlib.sha256(graph.encode()).hexdigest()[:12] + "_" + hashlib.sha256(source.encode()).hexdigest()[:16] + ".json")
            expected.add(path.resolve())
            record = load(path)
            m, k = metadata["scope_edge_count"], metadata["candidate_count"]
            winners = record["world_index_to_winner"]
            q = [F.from_float(float(self.triples[graph][edge]["confidence"])) for edge in metadata["scope_edge_indices"]]
            self.check.require(record["graph"] == graph and record["query_id"] == source
                and record["candidate_ids"] == metadata["candidate_ids"]
                and record["scope_edge_indices"] == metadata["scope_edge_indices"] and record["m"] == m
                and 0 <= m <= 8 and k > 1 and record["all_worlds"] == len(winners) == 2 ** m
                and all(type(winner) is int and 0 <= winner < k for winner in winners), "complete_world_map_identity", str(path))
            self.check.require(record["q_exact"] == list(map(str, q)), "world_map_actual_float_q", str(path))
            self.check.require(len(record["enumerated_score_sha256"]) == 64
                and record["distinct_world_winner_categories"] == len(set(winners)), "recorded_scorer_map_digest", str(path))
            self.maps[graph, source] = {"record": record, "q": q, "winners": winners, "k": k, "m": m,
                                       "path": path, "sha256": self.file_hash(path)}
        self.check.require({path.resolve() for path in (self.folder / "winner_maps").glob("*.json")} == expected,
                           "exact32_winner_map_files", "winner_maps")

    def reference(self, path, world_map, graph, source, tau):
        reference = load(path)
        c, m, k = self.check, world_map["m"], world_map["k"]
        winners = world_map["winners"]
        q, low, high = (list(map(F, reference[name])) for name in ("q_exact", "low_exact", "high_exact"))
        c.require(q == world_map["q"] and len(low) == len(high) == m
            and all(0 <= left <= p <= right <= 1 for p, left, right in zip(q, low, high)), "reference_probability_box", str(path))
        # Reconstruct the generator's outward binary endpoints without using its helper.
        expected_low = [F.from_float(max(0., math.nextafter(float(p) - tau, -math.inf))) for p in q]
        expected_high = [F.from_float(min(1., math.nextafter(float(p) + tau, math.inf))) for p in q]
        c.require(low == expected_low and high == expected_high, "actual_outward_endpoint_definition", str(path))
        nominal = direct_distribution(winners, k, q)
        vertices = reverse_vertex_distributions(winners, k, low, high)
        lex = sorted(range(2 ** m), key=lambda index: bits(index, m))
        direct_cache = {}

        def direct_at(index):
            if index not in direct_cache:
                parameters = [high[edge] if bits(index, m)[edge] else low[edge] for edge in range(m)]
                direct_cache[index] = direct_distribution(winners, k, parameters)
            return direct_cache[index]

        c.require(sum(nominal) == 1 and all(sum(vertices[candidate][index] for candidate in range(k)) == 1
            for index in range(2 ** m)), "exact_probability_normalization", str(path))
        c.require(reference["nominal_probabilities_exact"] == list(map(str, nominal))
            and reference["nominal_modes"] == [candidate for candidate in range(k) if nominal[candidate] == max(nominal)],
            "independent_direct_nominal_distribution", str(path))
        c.require(reference["world_count"] == reference["parameter_vertex_count"] == 2 ** m
            and reference["candidate_ids"] == world_map["record"]["candidate_ids"] and reference["tau"] == tau,
            "reference_world_candidate_identity", str(path))
        uniform = []
        for candidate in range(k):
            result = reference["candidate_results"][candidate]
            pairs = {item["competitor_index"]: item for item in result["pair_gap_ranges"]}
            c.require(result["candidate_index"] == candidate and set(pairs) == set(range(k)) - {candidate},
                      "every_candidate_every_competitor", str(path))
            safe = True
            for competitor, stored in pairs.items():
                gaps = [vertices[candidate][index] - vertices[competitor][index] for index in range(2 ** m)]
                minimum, maximum = min(gaps), max(gaps)
                safe = safe and minimum > 0
                min_index = next(index for index in lex if gaps[index] == minimum)
                max_index = next(index for index in lex if gaps[index] == maximum)
                c.require(F(stored["minimum_gap"]) == minimum and F(stored["maximum_gap"]) == maximum
                    and stored["minimum_vertex_bits"] == bits(min_index, m), "reverse_axis_all_vertex_gap_extrema", str(path))
                min_direct, max_direct = direct_at(min_index), direct_at(max_index)
                c.require(min_direct[candidate] - min_direct[competitor] == minimum,
                          "direct_product_mass_stored_minimum", str(path))
                c.require(max_direct[candidate] - max_direct[competitor] == maximum,
                          "direct_product_mass_independent_maximum", str(path))
            c.require(result["uniformly_unique_mode"] == safe, "strict_whole_box_unique_mode", str(path))
            if safe:
                uniform.append(candidate)
                c.require(result["unsafe_witness"] is None, "safe_has_no_unsafe_witness", str(path))
            else:
                first = next((index, competitor) for index in lex for competitor in range(k)
                             if competitor != candidate and vertices[candidate][index] <= vertices[competitor][index])
                index, competitor = first
                witness = result["unsafe_witness"]
                distribution = direct_at(index)
                parameters = [high[edge] if bits(index, m)[edge] else low[edge] for edge in range(m)]
                c.require(witness["vertex_bits"] == bits(index, m) and witness["competitor_index"] == competitor
                    and list(map(F, witness["parameter_values_exact"])) == parameters,
                    "lexicographic_first_unsafe_vertex", str(path))
                c.require(F(witness["candidate_probability_exact"]) == distribution[candidate]
                    and F(witness["competitor_probability_exact"]) == distribution[competitor]
                    and F(witness["gap_exact"]) == distribution[candidate] - distribution[competitor] <= 0,
                    "direct_product_mass_unsafe_witness", str(path))
        c.require(reference["uniform_winners"] == uniform and reference["exact_ambiguous"] == (not uniform),
                  "independent_uniform_answer_set", str(path))
        return {"uniform": uniform, "nominal_modes": [candidate for candidate in range(k) if nominal[candidate] == max(nominal)],
            "q": q, "low": low, "high": high, "sha256": self.file_hash(path), "path": path,
            "reference_seconds": reference["seconds"], "coupling_exact": product_coupling(q, low, high)}

    def all_references(self):
        expected = set()
        for (graph, source), world_map in self.maps.items():
            stem = hashlib.sha256(graph.encode()).hexdigest()[:12] + "_" + hashlib.sha256(source.encode()).hexdigest()[:16]
            for index, tau in enumerate(TAUS):
                path = self.folder / "exact" / f"{stem}_t{index}.json"
                expected.add(path.resolve())
                self.references[graph, source, tau] = self.reference(path, world_map, graph, source, tau)
        self.check.require({path.resolve() for path in (self.folder / "exact").glob("*.json")} == expected
            and len(self.references) == 192, "all192_complete_family_references", "exact")

    def method_row(self, row, metadata, reference, context, inference, event_bounds):
        c, config = self.check, self.protocol["config"]
        policy, n, k, m = row["policy"], row["samples_used"], row["candidate_count"], row["scope_edge_count"]
        event = policy in ("normal_event", "normal_hybrid")
        delta = .025 if event else .05
        c.require(row["seed"] == 151 and row["seed_purpose"] == PURPOSE and row["nominal_delta"] == delta
            and row["event_beta_total"] == (.025 if event else 0.), "method_seed_and_risk_contract", context)
        c.require(row["objective"] == ("nominal" if policy == "ppr_nominal" else "robust")
            and row["robust_certified"] == (row["certified"] and policy != "ppr_nominal"),
            "nominal_shortcut_and_robust_objectives_separated", context)
        payload = f"{SALT}|{row['graph']}|{row['dataset_revision']}|{row['query_id']}|151|{PURPOSE}"
        c.require(row["rng_seed_hex"] == hex(int.from_bytes(hashlib.sha256(payload.encode()).digest()[:16], "big")),
                  "actual_stream_seed", context)
        winners = row["winner_indices"]
        c.require(k == metadata["candidate_count"] and m == metadata["scope_edge_count"]
            and n == row["worlds_generated"] == row["nominal_score_rows"] == len(winners)
            and n <= 4096 and row["random_uniform_draws"] == n * m and row["event_extra_random_draws"] == 0,
            "method_counts_draws_scope", context)
        protected = config["event_checkpoints"]
        checks = sorted({*range(config["nominal"]["minimum_samples"], 4097, config["nominal"]["check_every"]),
                         4096, int(4096 * config["budget_fraction"]), *protected} - {0})
        c.require(row["actual_nominal_checkpoints"] == checks, "method_all_checkpoints_frozen", context)
        c.require(row["event_rows_computed"] == row["event_samples_used"] <= n
            and 0 <= row["event_count"] <= row["event_free_rows"] <= row["event_samples_used"], "paid_complete_event_prefix", context)
        c.require(F.from_float(row["scope_epsilon_upper"]) >= reference["coupling_exact"], "outward_scope_coupling_bound", context)
        model = metadata["cost_model"]
        units = config["work_model"]
        unit = max(1, m + model["original_incidence_entries"] + units["nominal_candidate_units"] * k)
        worst = 2 * m + 2 * model["interval_incidence_entries"] + units["interval_candidate_units"] * k
        budget = (int(4096 * config["budget_fraction"]) + 1) * unit
        work = float(unit)
        counts, winner_hash = [0] * k, hashlib.sha256()
        previous_n = previous_event = 0
        first_nominal = first_candidate = None
        source_epsilon = 0.
        if policy == "normal_hybrid":
            scope = metadata["scope_edge_indices"]
            source = row["query_id"]
            source_positions = [position for position, edge in enumerate(scope)
                if self.triples[row["graph"]][edge]["head_id"] == source or self.triples[row["graph"]][edge]["tail_id"] == source]
            meta = row["hybrid_metadata"]
            c.require(meta["source_positions"] == source_positions
                and meta["partition_chosen_from_observed_worlds"] is False
                and meta["generic_and_hybrid_observed_minimum_without_extra_risk_allocation"] is False,
                "fixed_source_partition_no_data_selected_minimum", context)
            q, low, high = [list(map(float, reference[name])) for name in ("q", "low", "high")]
            low_t, high_t = low.copy(), high.copy()
            for position in source_positions:
                low_t[position] = high_t[position] = q[position]
            c.require(meta["nominal_probability_sha256"] == array_sha(q)
                and meta["original_low_sha256"] == array_sha(low) and meta["original_high_sha256"] == array_sha(high)
                and meta["hybrid_low_sha256"] == array_sha(low_t) and meta["hybrid_high_sha256"] == array_sha(high_t),
                "hybrid_original_and_partition_box_hashes", context)
            source_epsilon = row["epsilon_source_upper"]
            c.require(meta["epsilon_source_upper"] == source_epsilon
                and meta["epsilon_scope_upper"] == row["scope_epsilon_upper"], "hybrid_metadata_bound_binding", context)
            c.require(F.from_float(source_epsilon) >= product_coupling(reference["q"], reference["low"], reference["high"], source_positions),
                      "outward_source_coupling_bound", context)
        for point in row["trace"]:
            tn, en = point["nominal_samples"], point["event_samples"]
            c.require(previous_n < tn <= n and tn in checks and previous_event <= en <= tn,
                      "method_monotone_protected_prefixes", context)
            segment = winners[previous_n:tn]
            for winner in segment:
                if not 0 <= winner < k:
                    raise ValueError("winner outside frozen candidate set")
                counts[winner] += 1
            winner_hash.update(struct.pack("<" + "q" * len(segment), *segment))
            c.require(winner_hash.hexdigest() == point["winner_prefix_sha256"], "raw_categorical_prefix_hash", context)
            key = row["graph"], row["dataset_revision"], row["query_id"], 151, PURPOSE, tn
            hashes = point["uniform_prefix_sha256"], point["winner_prefix_sha256"]
            if key in self.prefixes:
                c.require(self.prefixes[key] == hashes, "paired_stream_across_policies_and_families", context)
            else:
                self.prefixes[key] = hashes
            leader = max(range(k), key=lambda index: (counts[index], -index))
            if policy == "ppr_nominal":
                nominal_now = inference.ppr_certified(counts, tn, delta, prior="uniform", allocation="jain_mode")
                c.require(point["lower_gap"] is None, "PPR_no_positive_gap_claim", context)
            else:
                lower = inference.numerical_gap_bound(counts, tn, delta, {"name": "normal_mixture", "rho": config["nominal"]["rho"]})
                c.require(point["lower_gap"] == lower, "recomputed_protected_lower_gap", context)
                nominal_now = lower > 0
            if nominal_now and first_nominal is None:
                first_nominal, first_candidate = tn, leader
            if "nominal_certified_now" in point:
                c.require(point["nominal_certified_now"] == nominal_now, "nominal_decision_at_prefix", context)
            c.require(point["leader_index"] == leader, "fixed_candidate_tie_order", context)
            if policy == "normal_hybrid":
                effective = min(row["scope_epsilon_upper"], addition_upper(source_epsilon, point["event_upper"]), 1.)
                c.require(point["effective_epsilon_upper"] == effective, "hybrid_safe_composition", context)
            base = work + (tn - previous_n) * unit
            selected = point["event_upgrade_to"]
            fee = point["actual_event_fee"]
            if selected is not None:
                c.require(selected in protected and previous_event < selected <= tn, "event_prefix_identity", context)
                c.close(point["static_event_fee"], (selected - previous_event) * worst * config["interval_work_weight"], "static_event_fee", context)
            admission = point["event_admission"]
            if admission == "approved":
                c.require(event and en == selected and base + point["static_event_fee"] <= budget
                    and 0 <= fee <= point["static_event_fee"], "admit_before_event_evidence", context)
            elif admission == "rejected_budget":
                c.require(en == previous_event and fee == 0 and base + point["static_event_fee"] > budget,
                          "rejected_event_evidence_unchanged", context)
            else:
                c.require(admission == "not_requested" and en == previous_event and fee == 0, "unrequested_event_evidence_unchanged", context)
            work = base + fee
            c.close(work, point["work_used"], "trace_work_reconstruction", context)
            c.require(work <= budget, "strict_trace_work_budget", context)
            previous_n, previous_event = tn, en
        c.require(counts == row["winner_counts"] and sum(counts) == n
            and first_nominal == row["nominal_certificate_samples"] and first_candidate == row["nominal_candidate_index"]
            and row["nominal_certified"] == (first_nominal is not None),
            "exact_counts_and_first_nominal_certificate", context)
        c.require(winner_hash.hexdigest() == row["winner_prefix_sha256"], "final_winner_hash", context)
        c.require(previous_n == n and previous_event == row["event_samples_used"], "final_complete_trace_prefix", context)
        if row["trace"]:
            c.require(row["uniform_prefix_sha256"] == row["trace"][-1]["uniform_prefix_sha256"]
                and row["final_lower_gap"] == row["trace"][-1]["lower_gap"], "final_trace_hash_and_gap_binding", context)
        expected_work = (n + 1) * unit + config["interval_work_weight"] * (
            2 * m * row["event_samples_used"] + (2 * model["interval_incidence_entries"]
                + units["interval_candidate_units"] * k) * row["event_free_rows"])
        c.close(row["work_used"], expected_work, "final_nominal_and_paid_event_fee", context)
        c.require(row["work_used"] <= row["work_budget"] == budget and row["work_overshoot"] == 0,
                  "strict_final_work_budget", context)
        if row["event_samples_used"]:
            risk = event_bounds.validate_risk_plan({**config, "tau_grid": [.001], "sample_count": 4096})
            bound = event_bounds.fixed_n_binomial_upper(row["event_count"], row["event_samples_used"], risk["alpha_per_checkpoint"])
            c.require(row["event_upper"] == bound, "guarded_final_binomial_upper", context)
        if row["certified"] and policy != "ppr_nominal":
            effective = (min(row["scope_epsilon_upper"], addition_upper(source_epsilon, row["event_upper"]), 1.)
                         if policy == "normal_hybrid" else min(row["scope_epsilon_upper"], row["event_upper"]))
            c.require(row["final_lower_gap"] > 2 * effective, "returned_robust_threshold", context)
        c.require(all(isinstance(value, (int, float)) and math.isfinite(value) and value >= 0
            for value in row["seconds"].values()), "nonnegative_method_timing", context)

    def cases(self):
        import icde_gate_inference as inference
        import vldb_event_bound_v2 as event_bounds
        observed, expected = set(), set()
        for graph, source in self.maps:
            expected.update((graph, source, tau, policy) for tau in TAUS for policy in (*MC_POLICIES, *POINT_POLICIES))
        for path in sorted((self.folder / "cases").glob("*.json")):
            case = load(path)
            self.file_hash(path)
            graph, source, tau, policy = (case[name] for name in ("graph", "query_id", "tau", "policy"))
            key = graph, source, tau, policy
            self.check.require(key in expected and key not in observed, "complete_case_identity", str(path))
            observed.add(key)
            reference = self.references[graph, source, tau]
            linked = inside(self.folder / case["exact_reference_path"], self.folder)
            self.check.require(linked == reference["path"].resolve() and case["exact_reference_sha256"] == reference["sha256"],
                               "case_exact_reference_hash_binding", str(path))
            candidate = case["returned_candidate_index"]
            approved = candidate is not None
            if approved and not (type(candidate) is int and 0 <= candidate < self.maps[graph, source]["k"]):
                raise ValueError("returned candidate outside exact reference universe")
            safe = approved and candidate in reference["uniform"]
            exists = bool(reference["uniform"])
            flags = {"approved": approved, "uniform_safe": safe, "false_clear": approved and not safe,
                "reviewed": not approved, "avoidable_review": not approved and exists,
                "exists_uniform_winner": exists, "exact_ambiguous": not exists}
            self.check.require(all(case[name] == value for name, value in flags.items()), "independent_action_reclassification", str(path))
            nominal_exception = False
            if policy in MC_POLICIES:
                row = case["row"]
                self.check.require(row["graph"] == graph and row["query_id"] == source and row["tau"] == tau
                    and row["policy"] == policy and case["samples_used"] == row["samples_used"]
                    and case["method_serving_seconds"] == row["seconds"]["query_serving_total"]
                    and approved == row["certified"] and candidate == row["certified_candidate_index"],
                    "case_method_return_binding", str(path))
                if approved:
                    self.check.require(row["certified_candidate"] == self.maps[graph, source]["record"]["candidate_ids"][candidate],
                                       "returned_candidate_name_and_position", str(path))
                self.method_row(row, self.setups[graph, source], reference, str(path), inference, event_bounds)
                if row["nominal_certified"]:
                    nominal_exception = len(reference["nominal_modes"]) != 1 or row["nominal_candidate_index"] not in reference["nominal_modes"]
            else:
                self.check.require(case["samples_used"] == 0 and case["deterministic_scorer_rows"] == 1,
                                   "point_baseline_no_random_samples", str(path))
                margin = case["point_score_margin"]
                threshold = None if policy == "point_all_present" else float(policy.removeprefix("point_margin_gt_"))
                self.check.require(case["threshold"] == threshold and approved == (threshold is None or margin > threshold)
                    and math.isfinite(margin) and margin >= 0, "predeclared_point_threshold", str(path))
                point_key = graph, source
                if point_key in self.point_margins:
                    self.check.require(self.point_margins[point_key] == margin, "point_margin_constant_across_families", str(path))
                self.point_margins[point_key] = margin
                if approved:
                    self.check.require(candidate == self.maps[graph, source]["winners"][-1], "all_present_world_baseline_identity", str(path))
            self.results.append({"graph": graph, "query_id": source, "tau": tau, "policy": policy,
                **flags, "samples_used": case["samples_used"], "serving_seconds": case["method_serving_seconds"],
                "observed_nominal_exception": nominal_exception,
                "observed_robust_false_clear": flags["false_clear"] and policy in ("normal_scope", "normal_event", "normal_hybrid")})
        self.check.require(observed == expected and len(observed) == 1728, "exact32_times6_times9_case_grid", "cases")

    def finish(self):
        groups = defaultdict(list)
        for case in self.results:
            for graph in ("ALL", case["graph"]):
                groups[graph, case["tau"], case["policy"]].append(case)
        table = []
        for (graph, tau, policy), cases in sorted(groups.items()):
            table.append({"graph": graph, "tau": tau, "policy": policy, "cases": len(cases),
                "distinct_queries": len({(case["graph"], case["query_id"]) for case in cases}),
                **{name: sum(case[name] for case in cases) for name in (*FLAGS, "observed_nominal_exception", "observed_robust_false_clear")},
                "random_worlds_generated": sum(case["samples_used"] for case in cases),
                "method_serving_seconds": sum(case["serving_seconds"] for case in cases)})
        stored = {(item["graph"], item["tau"], item["policy"]): item for item in self.original_summary["review_table"]}
        for item in table:
            if item["graph"] == "ALL":
                continue
            original = stored[item["graph"], item["tau"], item["policy"]]
            self.check.require(all(item[name] == original[name] for name in (
                "cases", "approved", "uniform_safe", "false_clear", "reviewed", "avoidable_review", "exact_ambiguous", "random_worlds_generated")),
                "stored_summary_independent_reaggregation", str((item["graph"], item["tau"], item["policy"])))
            self.check.close(item["method_serving_seconds"], original["method_serving_seconds"], "summary_serving_time", str(item["policy"]))
        validation = {"status": "PASS" if not self.check.errors else "FAIL", "checks": dict(self.check.counts),
            "error_counts": dict(self.check.errors), "error_examples": self.check.examples,
            "paired_prefixes": len(self.prefixes),
            "observed_robust_false_clears": sum(case["observed_robust_false_clear"] for case in self.results),
            "observed_nominal_exceptions": sum(case["observed_nominal_exception"] for case in self.results),
            "observation_is_not_zero_risk_guarantee": True,
            "no_rejection_merely_because_a_statistical_certificate_has_an_observed_error": True}
        return validation, {"schema": "independent-exact-review-audit-v1", "validation": validation,
            "cases": len(self.results), "distinct_queries": len(self.maps), "families": len(self.references),
            "review_table": table, "original_graph_timings": self.original_summary["graph_timings"],
            "original_elapsed_seconds": self.original_summary["elapsed_seconds"],
            "provenance": {"study_path": str(self.folder.relative_to(ROOT)),
                "protocol_sha256": self.file_hash(self.folder / "protocol_freeze.json"),
                "study_summary_sha256": self.file_hash(self.folder / "summary.json"),
                "audit_source_sha256": sha(Path(__file__)),
                "study_file_sha256": {str(path.relative_to(self.folder)): digest for path, digest in self.hashes.items()
                                      if path.is_relative_to(self.folder)},
                "arithmetic": "reverse-axis out-of-place Fraction vertex contraction plus independent direct product-mass extrema/witness checks",
                "original_reference_implementation_imported": False,
                "scorer_or_RNG_reexecuted": False,
                "scope": "record identity closure binds the saved exhaustive winner map to frozen input/scorer metadata; no new scorer-equivalence proof is claimed",
                "unit": "32 selected query sources times6 declared families; repeated policies/families are not independent sources",
                "risk": "per policy/query/family0.05; an observed zero is not a dataset-wide zero-error theorem",
                "shortcut": "PPR is tested as an unchecked update-clearance shortcut; false clear does not mean its nominal-mode guarantee failed",
                "usecase": "controlled model/retention-parameter review only; no industrial deployment, actual human savings or calibrated fact-probability evidence",
                "timing": "exact reference/setup charged separately; serving excludes durable research-output overhead",
                "still_open": ["formal full predecessor overlap and novelty audit", "independently supported real deployment need"]}}


def chinese_draft(summary):
    validation = summary["validation"]
    lines = ["# 条件维护审查：独立exact核验", "",
        f"核验状态：**{validation['status']}**。32个按输入/评分器属性选择的不同query，六个预定参数family，九种审批策略，共1728个case。", "",
        "独立核验采用反向轴Fraction张量收缩重算整个box的所有顶点；对最小间隔顶点、独立找出的最大间隔顶点及unsafe见证，另用逐world乘积质量求和交叉检查。未重新运行scorer或生成随机world。", "",
        "| τ | 策略 | cases | 审批 | 全family安全审批 | false clear | 送审 | 可避免送审 | 无统一唯一答案 | serving秒 |",
        "| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for item in summary["review_table"]:
        if item["graph"] == "ALL":
            lines.append(f"| {item['tau']:g} | {item['policy']} | {item['cases']} | {item['approved']} | {item['uniform_safe']} | {item['false_clear']} | {item['reviewed']} | {item['avoidable_review']} | {item['exact_ambiguous']} | {item['method_serving_seconds']:.5f} |")
    lines += ["", f"本轮鲁棒策略观察到的false clear为{validation['observed_robust_false_clears']}；这只是这批固定case的独立观测，不是把每case的0.05风险改写成数据集零错误保证。", "",
        "PPR是有效的名义mode方法；本对照把名义证书直接用于参数更新审批，因此false clear表示该未经鲁棒保护的快捷审批不满足全family目标，不能解释成PPR的名义保证失效。", "",
        "可避免送审指exact参考存在全family唯一mode，而策略未审批；它是受控条件决策量，不是已测量的人力节省。无统一唯一答案包含参数box边界上的mode并列，不必然证明存在两个不同的严格mode。", "",
        f"实验记录总时间{summary['original_elapsed_seconds']:.3f}秒；setup、exact参考及各方法serving分别记录，差额包含研究归档、hash、序列化和fsync等未分解开销。不得把参考计算免费计入算法，或将serving计时称为完整部署延迟。", "",
        "这些query来自旧数据，且因精确枚举而预先限制完整scope≤8、候选数>1；不代表整个500-query工作负载。真实部署需求、真实事实概率校准及正式前序全文/原创性审计仍未因此闭合。"]
    if validation["status"] != "PASS":
        lines += ["", "**核验失败：修复列出的记录或算术不一致后，才能把表格作为已核验证据。**"]
    return "\n".join(lines) + "\n"


def main():
    started = time.perf_counter()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    folder, output = inside(args.input_dir), inside(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    try:
        auditor = ExactAudit(folder)
        auditor.identities_and_selection()
        auditor.winner_maps()
        auditor.all_references()
        auditor.cases()
        validation, summary = auditor.finish()
        summary["audit_elapsed_seconds"] = time.perf_counter() - started
        write(output / "validation.json", validation)
        write(output / "summary.json", summary)
        with (output / "RESULTS_ZH.md").open("x", encoding="utf-8") as handle:
            handle.write(chinese_draft(summary))
        print(json.dumps({"status": validation["status"], "cases": summary["cases"],
                          "families": summary["families"], "output": str(output.relative_to(ROOT))}))
        if validation["status"] != "PASS":
            raise SystemExit(1)
    except Exception as error:
        write(output / "audit_failure.json", {"status": "FAILED", "error": str(error),
            "traceback": traceback.format_exc(), "no_publication_validation": True})
        raise


if __name__ == "__main__":
    main()
