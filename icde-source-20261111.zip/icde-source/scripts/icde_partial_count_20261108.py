"""Sound partial count-space compilation with exact parameter-coupled bounds.

Box pruning, best-first refinement, and sum-product interval propagation are
standard ingredients. Both refinement schedules share all bounds and caches;
the certificate schedule is not asserted to be an independently novel rule.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as Q
import math
import time
import numpy as np

from icde_grouped_exact_20261108 import groups_for_box, endpoint_matrix, compile_counts, solve_counts


@dataclass
class Region:
    low: tuple
    high: tuple
    mask: int
    mass: object
    max_mass: int
    serial: int

    @property
    def volume(self):
        return math.prod(b-a+1 for a, b in zip(self.low, self.high))


class CountOracle:
    def __init__(self, kernel, low, high, state_cap=32768):
        self.kernel, self.k = kernel, len(kernel.candidates)
        self.groups = groups_for_box(kernel, low, high)
        self.shape = tuple(len(edges)+1 for sig, edges, endpoint in self.groups)
        self.size = math.prod(self.shape)
        if self.size > state_cap:
            raise ValueError("parameter representative state budget exceeded")
        self.coeff = np.zeros((len(self.groups), 2*self.k), dtype=np.int64)
        for g, (signature, edges, endpoint) in enumerate(self.groups):
            for direction in range(2):
                for c in range(self.k):
                    self.coeff[g, direction*self.k+c] = int(direction in signature) - int(2+2*c+direction in signature)
        self.positive = np.maximum(self.coeff, 0)
        self.negative = np.minimum(self.coeff, 0)
        self.cdfs = []
        self.denominator = 1
        self.bound_calls = self.point_scores = 0

    def scores(self, count):
        degree = np.zeros(len(self.kernel.incidence_positions), dtype=np.int64)
        for value, (signature, edges, endpoint) in zip(count, self.groups):
            degree[list(signature)] += value
        degree = degree.astype(np.float64)
        distance = np.abs(degree[0]-degree[2::2])+np.abs(degree[1]-degree[3::2])
        dynamic = 1.0/(1.0+distance)
        structural = .6*self.kernel.lexical+.4*dynamic
        weight = self.kernel.attribute_weight
        return weight*self.kernel.attribute+(1.0-weight)*structural

    def possible(self, low, high, parent_mask=None):
        self.bound_calls += 1
        if low == high:
            self.point_scores += 1
            mask = 1 << int(np.argmax(self.scores(low)))
        else:
            lo, hi = np.asarray(low, dtype=np.int64), np.asarray(high, dtype=np.int64)
            a = lo@self.positive+hi@self.negative
            b = hi@self.positive+lo@self.negative
            minimum = np.where((a <= 0) & (b >= 0), 0, np.minimum(np.abs(a), np.abs(b)))
            maximum = np.maximum(np.abs(a), np.abs(b))
            dmin, dmax = minimum.reshape(2,self.k).sum(axis=0)[None,:], maximum.reshape(2,self.k).sum(axis=0)[None,:]
            lower, upper = self.kernel.score_bounds_from_distances(dmin, dmax)
            mask = sum(1 << c for c in range(self.k) if upper[0,c] >= np.max(lower[0]))
        if parent_mask is not None:
            mask &= parent_mask
        if not mask:
            raise AssertionError("sound region bounds removed every candidate")
        return mask

    def prepare_probabilities(self):
        for signature, edges, endpoint in self.groups:
            matrix, scale = endpoint_matrix(len(edges), *endpoint)
            cumulative = np.zeros((matrix.shape[0], matrix.shape[1]+1), dtype=object)
            cumulative[:,1:] = np.cumsum(matrix, axis=1, dtype=object)
            self.cdfs.append(cumulative)
            self.denominator *= scale

    def region_vectors(self, low, high):
        return [cdf[:,b+1]-cdf[:,a] for cdf,a,b in zip(self.cdfs,low,high)]

    def mass(self, low, high):
        vectors = self.region_vectors(low, high)
        result = np.asarray(1, dtype=object)
        for vector in vectors:
            result = np.multiply.outer(result, vector)
        return result, math.prod(max(map(int, v)) for v in vectors)

    def maximum_mass(self, low, high):
        return math.prod(max(map(int, v)) for v in self.region_vectors(low, high))


def assess(lower, upper, bad):
    """Robust approval OR one sound exclusion witness per candidate."""
    k = len(lower)
    leaders = []
    for w in range(k):
        if w in bad:
            continue
        worst, worst_d, worst_at = None, None, None
        for d in range(k):
            if w == d:
                continue
            high_gap = upper[w]-lower[d]
            at = int(np.argmin(high_gap))
            if int(high_gap.flat[at]) <= 0:
                bad[w] = {"candidate": w, "competitor": d, "parameter_index": at,
                          "upper_gap_numerator": str(int(high_gap.flat[at]))}
                break
            low_gap = lower[w]-upper[d]
            at = int(np.argmin(low_gap))
            value = int(low_gap.flat[at])
            if worst is None or value < worst:
                worst,worst_d,worst_at = value,d,at
        if w in bad:
            continue
        if worst > 0:
            return "stable",w,(w,worst_d,worst_at)
        leaders.append((worst,-w,worst_d,worst_at))
    if not leaders:
        return "nonuniform",None,None
    value,negw,d,at = max(leaders)
    return "unresolved",None,(-negw,d,at)


def execute(kernel, low, high, policy, settings):
    started = time.perf_counter()
    oracle = CountOracle(kernel, low, high, settings["state_cap"])
    rootlow = (0,)*len(oracle.shape)
    roothigh = tuple(n-1 for n in oracle.shape)
    rootmask = oracle.possible(rootlow, roothigh)
    timings = {"setup_and_root": time.perf_counter()-started}
    if rootmask & (rootmask-1) == 0:
        return {"status":"stable", "winner":rootmask.bit_length()-1, "kind":"common_root_bound",
                "compute_seconds":time.perf_counter()-started, "splits":0, "bound_calls":oracle.bound_calls,
                "point_score_states":oracle.point_scores, "count_states":oracle.size, "leaf_records":[],
                "witnesses":[], "trace":[], "probability_states_allocated":0}
    if policy == "dense_exact":
        compiled = compile_counts(kernel, low, high, settings["state_cap"])
        unique = np.unique(compiled["winners"])
        if len(unique) == 1:
            return {"status":"stable", "winner":int(unique[0]), "kind":"common_count_constant",
                    "compute_seconds":time.perf_counter()-started, "splits":0, "bound_calls":oracle.bound_calls,
                    "point_score_states":oracle.size, "count_states":oracle.size, "leaf_records":[],
                    "witnesses":[], "trace":[], "probability_states_allocated":0}
        result = solve_counts(compiled, oracle.k)
        return {"status":"stable" if result["uniform_winners"] else "nonuniform",
                "winner":result["uniform_winners"][0] if result["uniform_winners"] else None,
                "kind":"complete_tensor", "compute_seconds":time.perf_counter()-started,
                "splits":0,"bound_calls":oracle.bound_calls,"point_score_states":oracle.size,
                "count_states":oracle.size,"leaf_records":[],"witnesses":[],"trace":[],
                "probability_states_allocated":oracle.size}

    before = time.perf_counter()
    oracle.prepare_probabilities()
    timings["probability_setup"] = time.perf_counter()-before
    denominator = oracle.denominator
    lower = [np.zeros(oracle.shape, dtype=object) for _ in range(oracle.k)]
    upper = [np.zeros(oracle.shape, dtype=object) for _ in range(oracle.k)]
    unknown, leaves = {}, {}
    bad, trace = {}, []

    def contribute(region, sign):
        for c in range(oracle.k):
            if region.mask & (1 << c):
                if sign == 1:
                    upper[c] += region.mass
                else:
                    upper[c] -= region.mass
            if region.mask == 1 << c:
                if sign == 1:
                    lower[c] += region.mass
                else:
                    lower[c] -= region.mass

    def add(region):
        contribute(region,1)
        leaves[region.serial] = {"low":list(region.low),"high":list(region.high),"mask":region.mask}
        if region.mask & (region.mask-1):
            unknown[region.serial] = region

    rootmass = np.full(oracle.shape,denominator,dtype=object)
    add(Region(rootlow,roothigh,rootmask,rootmass,denominator,0))
    serial,splits = 1,0
    probability_update_seconds = bound_seconds = inference_seconds = selection_seconds = 0.
    status,winner,bottleneck = "unresolved",None,None
    while True:
        before = time.perf_counter()
        status,winner,bottleneck = assess(lower,upper,bad)
        inference_seconds += time.perf_counter()-before
        trace.append({"splits":splits,"leaves":len(leaves),"unknown":len(unknown),"status":status,
                      "bad_candidates":sorted(bad),"bottleneck":list(bottleneck) if bottleneck else None})
        if status != "unresolved" or not unknown or splits >= settings["max_splits"]:
            break
        before = time.perf_counter()
        if policy == "standard_mass":
            parent = max(unknown.values(),key=lambda r:(r.max_mass,r.volume,-r.serial))
        else:
            w,d,at = bottleneck
            def priority(region):
                lo = int(region.mask == 1 << w)-int(bool(region.mask & (1 << d)))
                hi = int(bool(region.mask & (1 << w)))-int(region.mask == 1 << d)
                return (int(region.mass.flat[at])*(hi-lo),region.max_mass,region.volume,-region.serial)
            parent = max(unknown.values(),key=priority)
        axis = max(range(len(oracle.shape)),key=lambda g:(parent.high[g]-parent.low[g],-g))
        if parent.high[axis] == parent.low[axis]:
            raise AssertionError("an unresolved point should have been scored exactly")
        middle = (parent.high[axis]+parent.low[axis])//2
        left_hi,right_lo = list(parent.high),list(parent.low)
        left_hi[axis],right_lo[axis] = middle,middle+1
        left_hi,right_lo = tuple(left_hi),tuple(right_lo)
        selection_seconds += time.perf_counter()-before
        before = time.perf_counter()
        lm = oracle.possible(parent.low,left_hi,parent.mask)
        rm = oracle.possible(right_lo,parent.high,parent.mask)
        bound_seconds += time.perf_counter()-before
        before = time.perf_counter()
        leftmass,leftmax = oracle.mass(parent.low,left_hi)
        rightmass = parent.mass-leftmass
        rightmax = oracle.maximum_mass(right_lo,parent.high)
        contribute(parent,-1)
        unknown.pop(parent.serial)
        leaves.pop(parent.serial)
        add(Region(parent.low,left_hi,lm,leftmass,leftmax,serial))
        add(Region(right_lo,parent.high,rm,rightmass,rightmax,serial+1))
        serial += 2
        splits += 1
        probability_update_seconds += time.perf_counter()-before
    if status == "unresolved" and not unknown:
        raise AssertionError("a fully classified count partition must be decidable")
    elapsed = time.perf_counter()-started
    witnesses = []
    for w, proof in sorted(bad.items()):
        witnesses.append({**proof,"high_endpoint_counts":list(map(int,np.unravel_index(proof["parameter_index"],oracle.shape)))})
    timings.update({"region_bounds":bound_seconds,"probability_updates":probability_update_seconds,
                    "inference":inference_seconds,"selection":selection_seconds})
    return {"status":status,"winner":winner,"kind":"partial_count_regions",
            "compute_seconds":elapsed,"splits":splits,"bound_calls":oracle.bound_calls,
            "point_score_states":oracle.point_scores,"count_states":oracle.size,
            "leaf_records":[leaves[j] for j in sorted(leaves)],"witnesses":witnesses,
            "denominator_exact":str(denominator),"trace":trace,"times":timings,
            "probability_states_allocated":oracle.size,
            "unresolved_count_state_volume":sum(r.volume for r in unknown.values())}
