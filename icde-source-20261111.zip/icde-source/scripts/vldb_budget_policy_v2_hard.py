"""Replay V2 evidence with conservative preexecution work admission.

An event upgrade is admitted using only static dimensions, the declared source
partition cap and the requested prefix length.  Saved flags and work counters
are revealed only after that worst-case charge fits.  A rejected upgrade leaves
the last paid event prefix unchanged and nominal sampling can continue.

The statistical contract and logical-work units are inherited from frozen V2;
this module generates no worlds and makes no elapsed-time claim.
"""

from __future__ import annotations

import math

from vldb_budget_policy_v2 import POLICIES, _upper
from vldb_event_bound_v2 import validate_risk_plan
from vldb_stream_frontier_v0 import normal_radius


ADMISSION = "conservative_preexecution"
EVENT_FIELDS = ("h_difference", "h_source_conditioned", "free_flags",
                "conditioning_degree_rows", "conditioning_assignment_counts")


def _integer(value, name, *, minimum=0, maximum=None):
    if (type(value) is not int or value < minimum
            or (maximum is not None and value > maximum)):
        raise ValueError(f"invalid {name}: expected integer >= {minimum}"
                         + (f" and <= {maximum}" if maximum is not None else ""))
    return value


def _paid_slice(record, name, start, stop):
    """Reveal exactly one already-admitted contiguous block, never its tail."""
    values = record[name][start:stop]
    if len(values) != stop - start:
        raise ValueError("event and nominal prefixes differ in length")
    return values


def _binary_values(record, name, start, stop):
    values = _paid_slice(record, name, start, stop)
    if any(type(value) not in (bool, int) or value not in (0, 1) for value in values):
        raise ValueError(f"{name} must contain binary flags")
    return values


def _paid_event_block(record, policy, start, stop, *, k, m, incidences,
                      interval_incidence, source_incidence, interval_units,
                      conditioned_units, maximum_assignments):
    """Validate and price observed counters only after static admission."""
    difference = _binary_values(record, "h_difference", start, stop)
    free = _binary_values(record, "free_flags", start, stop)
    event_flags = difference
    units = 2 * m * (stop - start)
    units += (2 * interval_incidence + interval_units * k) * sum(free)
    if policy == "source_conditioned_lazy":
        event_flags = _binary_values(record, "h_source_conditioned", start, stop)
        if any(new and not old for new, old in zip(event_flags, difference)):
            raise ValueError("conditioning flags must refine the strong baseline")
        degree_rows = _paid_slice(record, "conditioning_degree_rows", start, stop)
        assignments = _paid_slice(record, "conditioning_assignment_counts", start, stop)
        for value in degree_rows:
            _integer(value, "conditioning degree row", maximum=1)
        for value in assignments:
            _integer(value, "conditioning assignment count", maximum=maximum_assignments)
        units += 2 * source_incidence * (stop - start)
        units += 2 * incidences * sum(degree_rows)
        units += conditioned_units * k * sum(assignments)
    return sum(event_flags), units


def _run(query, tau_record, settings, plan, policy, fraction, interval_weight):
    k, m = query["candidate_count"], query["scope_edge_count"]
    cost = query["cost_model"]
    incidences = cost["original_incidence_entries"]
    interval_incidence = cost["interval_incidence_entries"]
    source_incidence = cost["source_incidence_entries"]
    model = settings["work_model"]
    interval_units = model["interval_candidate_units"]
    conditioned_units = model["conditioned_candidate_units"]
    maximum_assignments = settings.get("max_source_assignments", 4)
    nominal_unit = max(1, m + incidences + model["nominal_candidate_units"] * k)
    cap = len(query["winner_indices"])
    equivalent_worlds = int(cap * fraction)
    budget = (equivalent_worlds + 1) * nominal_unit
    work = float(nominal_unit)
    # Every pending row is treated as free and every eligible source row as
    # requiring the maximum declared partition.  No saved row is consulted.
    event_upper_unit = 2 * m + 2 * interval_incidence + interval_units * k
    if policy == "source_conditioned_lazy":
        event_upper_unit += (2 * source_incidence + 2 * incidences
                             + conditioned_units * k * maximum_assignments)
    protected = tuple(plan["event_checkpoints"])
    alpha = plan["alpha_per_checkpoint"]
    nominal_risk = (settings["delta_total"] if policy == "scope_full_risk"
                    else settings["delta_nominal"])
    alpha_nominal = nominal_risk / max(k * (k - 1) // 2, 1)
    nominal = settings["nominal"]
    checks = set(range(nominal["minimum_samples"], cap + 1, nominal["check_every"]))
    checks.update((cap, equivalent_worlds))
    checks.update(value for value in protected if value <= cap)
    checks = sorted(value for value in checks if 0 < value <= cap)
    counts = [0] * k
    n, event_n, event_count, event_upper = 0, 0, 0, 1.0
    lower = None
    leader = 0
    status = "unresolved_world_cap"
    trace = []
    certified = False
    rejected = admitted = 0
    scope_epsilon = float(tau_record["epsilon_scope_upper"])
    if k == 1:
        certified, status = True, "structurally_single_candidate"
    else:
        for next_n in checks:
            nominal_charge = (next_n - n) * nominal_unit
            if work + nominal_charge > budget:
                status = "nominal_work_budget"
                break
            for winner in query["winner_indices"][n:next_n]:
                counts[winner] += 1
            work += nominal_charge
            n = next_n
            leader = max(range(k), key=lambda index: (counts[index], -index))
            competitor = max(counts[index] for index in range(k) if index != leader)
            lower = max(-1.0, (counts[leader] - competitor) / n
                        - normal_radius(n, alpha_nominal, nominal["rho"]))
            epsilon = min(scope_epsilon, event_upper)
            admission = "not_requested"
            selected = None
            upper_charge = None
            actual_charge = 0.0
            if lower > 2 * epsilon:
                certified, status = True, "certified"
            elif policy not in ("scope_full_risk", "scope_matched_risk"):
                eligible = [value for value in protected if event_n < value <= n]
                if policy.endswith("lazy"):
                    eligible = [value for value in eligible
                                if lower > 0 and 2 * _upper(0, value, alpha) < lower]
                if eligible:
                    # Retain protected prefix order; never search pending
                    # outcomes or costs for a cheaper observed block.
                    selected = eligible[0]
                    upper_charge = (selected - event_n) * event_upper_unit * interval_weight
                    if work + upper_charge > budget:
                        rejected += 1
                        admission = "rejected_budget"
                    else:
                        admission = "approved"
                        added_events, units = _paid_event_block(
                            tau_record, policy, event_n, selected, k=k, m=m,
                            incidences=incidences, interval_incidence=interval_incidence,
                            source_incidence=source_incidence, interval_units=interval_units,
                            conditioned_units=conditioned_units,
                            maximum_assignments=maximum_assignments,
                        )
                        actual_charge = units * interval_weight
                        assert actual_charge <= upper_charge, "static event bound failed"
                        work += actual_charge
                        assert work <= budget, "admitted event block exceeded hard budget"
                        event_n = selected
                        event_count += added_events
                        admitted += 1
                        event_upper = _upper(event_count, event_n, alpha)
                        epsilon = min(scope_epsilon, event_upper)
                        if lower > 2 * epsilon:
                            certified, status = True, "certified"
            trace.append({
                "nominal_samples": n, "event_samples": event_n,
                "work_completed": work, "lower_gap": lower,
                "event_upper": event_upper, "status": status,
                "event_upgrade_to": selected, "event_admission": admission,
                "event_upper_charge": upper_charge, "event_actual_charge": actual_charge,
            })
            if certified:
                break
    assert work <= budget, "hard budget invariant failed"
    return {
        "graph": query["graph"], "query_id": query["query_id"],
        "nominal_seed": query["nominal_seed"], "tau": tau_record["tau"],
        "policy": policy, "budget_fraction": fraction,
        "interval_work_weight": interval_weight, "admission": ADMISSION,
        "candidate_count": k, "nontrivial_query": k > 1,
        "stable": certified, "status": status,
        "certified_candidate_index": leader if certified else None,
        "samples_used": n, "event_samples_used": event_n,
        "work_used": work, "work_budget": budget, "work_overshoot": 0.0,
        "nominal_unit_work": nominal_unit,
        "event_bernoulli_uniforms_added": 0,
        "event_ambiguity_upper": event_upper,
        "scope_epsilon_upper": scope_epsilon,
        "final_lower_gap": lower, "nominal_delta": nominal_risk,
        "event_admission_rejections": rejected, "event_upgrades_admitted": admitted,
        "trace": trace,
    }


def run_hard_budget_policy(query_record: dict, settings: dict) -> list[dict]:
    """Replay every fixed V2 policy without reading unadmitted event data.

    Validation of event values is deliberately deferred to admitted slices;
    only their lengths can be checked before a block is paid for.  Frozen raw
    capture identity and full-file validation remain the replay driver's job.
    """
    plan = validate_risk_plan(settings)
    k = _integer(query_record["candidate_count"], "candidate count", minimum=1)
    winners = query_record["winner_indices"]
    if not winners or any(type(value) is not int or not 0 <= value < k for value in winners):
        raise ValueError("invalid complete nominal winner prefix")
    _integer(query_record["scope_edge_count"], "scope edge count")
    for key in ("original_incidence_entries", "interval_incidence_entries",
                "source_incidence_entries"):
        _integer(query_record["cost_model"][key], key)
    for key in ("nominal_candidate_units", "interval_candidate_units",
                "conditioned_candidate_units"):
        _integer(settings["work_model"][key], key)
    _integer(settings.get("max_source_assignments", 4), "source partition cap",
             minimum=1, maximum=256)
    for key in ("minimum_samples", "check_every"):
        _integer(settings["nominal"][key], key, minimum=1)
    rho = settings["nominal"]["rho"]
    if not math.isfinite(rho) or rho <= 0:
        raise ValueError("rho must be positive and finite")
    for row in query_record["tau_records"]:
        if row["tau"] not in settings["tau_grid"]:
            raise ValueError("undeclared box")
        scope = float(row["epsilon_scope_upper"])
        if not math.isfinite(scope) or not 0 <= scope <= 1:
            raise ValueError("scope upper bound must lie in [0,1]")
        for key in EVENT_FIELDS:
            if len(row[key]) != len(winners):
                raise ValueError("event and nominal prefixes differ in length")
    for fraction in settings["budget_fractions"]:
        if isinstance(fraction, bool) or not math.isfinite(fraction) or not 0 < fraction <= 1:
            raise ValueError("budget fractions must lie in (0,1]")
    for weight in settings["interval_work_weights"]:
        if isinstance(weight, bool) or not math.isfinite(weight) or weight <= 0:
            raise ValueError("interval work weights must be positive")
    return [_run(query_record, row, settings, plan, policy, fraction, weight)
            for row in query_record["tau_records"]
            for fraction in settings["budget_fractions"]
            for weight in settings["interval_work_weights"]
            for policy in POLICIES]
