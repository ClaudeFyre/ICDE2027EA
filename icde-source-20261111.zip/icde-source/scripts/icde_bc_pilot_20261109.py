"""Frozen historical B/C pilots. No new solver or prospective confirmation.

Independent exact recounts validate reuse; prepared counting work is a standard
baseline, not asserted to be a new sensitivity/region certification method.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import statistics
import time
import zipfile

import numpy as np

import icde_prospective_20261107 as old
from icde_grouped_exact_20261108 import (
    compile_counts, solve_counts, endpoint_matrix, direct_representative_probabilities,
)
from icde_grouped_inventory_20261108 import ROOT, load, sha, save, incidence_groups
from run_vldb_interval_gate_v1 import clipped_box

RESULTS = ROOT / 'nodes/09_vldb_query_certification/results'
OUT = RESULTS / 'icde_bc_pilot_20261109/attempt1'
PARENT = RESULTS / 'icde_portfolio_headroom_20261108/attempt1'
RULES = ROOT / 'papers/icde/regular2027/BC_PILOT_RULES_20261109.md'
AMPLITUDES = [1 / 256, 1 / 128, 1 / 64, 1 / 32, 1 / 16]
METHODS = ['all', 'scope', 'containment', 'margin_incremental']


def freeze(out):
    if out.exists():
        raise FileExistsError(out)
    source = load(PARENT / 'summary.json')
    references = sorted(source['references'], key=lambda r: (r['graph'], r['rank']))
    if len(references) != 148 or sum(bool(r['uniform_winners']) for r in references) != 101:
        raise AssertionError('historical reference population changed')
    inputs = [PARENT / 'summary.json', PARENT / 'protocol.json', RULES]
    for row in references:
        path = old.BASE / 'prepared' / row['graph'] / f"q{row['rank']:03d}.json"
        inputs.extend([path, path.with_suffix('.npz')])
    inputs += [old.DATA / graph / 'triples.tsv' for graph in ('dw', 'enfr')]
    code = dict(load(PARENT / 'protocol.json')['code_sha256'])
    for path in (Path(__file__), ROOT / 'scripts/test_icde_bc_pilot_20261109.py',
                 ROOT / 'scripts/safe_run.py'):
        code[path.relative_to(ROOT).as_posix()] = sha(path)
    # Bind the actual code that will run; historical parent records remain intact.
    code = {name: sha(ROOT / name) for name in code}
    protocol = {
        'kind': 'historical_BC_pilot_not_confirmation',
        'frozen_at_unix': time.time(), 'timezone': 'Asia/Shanghai',
        'rules': RULES.relative_to(ROOT).as_posix(),
        'c_cases': references,
        'b_cases': [r for r in references if r['uniform_winners']],
        'thresholds': {'C_theory': .20, 'C_measured': .15, 'B_cost': .20,
                       'B_paired_interval_lower_strictly_positive': True,
                       'reuse_errors': 0, 'unverified_reuse': 0},
        'nominal': .9, 'tau': .25, 'state_cap': 32768,
        'amplitudes': AMPLITUDES, 'updates_per_graph': 40, 'repeats': 5,
        'bootstrap_repeats': 10000, 'bootstrap_seed': 2026110921,
        'c_batch': 'one complete batch per graph, same degree scorer',
        'c_work_unit': 'edge RNG + incidence edge additions + 10 per candidate',
        'code_sha256': code,
        'input_sha256': {p.relative_to(ROOT).as_posix(): sha(p) for p in inputs},
        'limits': 'safe_run local16; one task; per phase runtime guard; no training',
    }
    save(out / 'protocol.json', protocol)
    print('FROZEN C=148 B=101 before pilot measurements', flush=True)


def identities(p, crc=False):
    checks = 0
    for category in ('code_sha256', 'input_sha256'):
        for name, expected in p[category].items():
            path = ROOT / name
            if sha(path) != expected:
                raise AssertionError(f'frozen identity changed: {name}')
            checks += 1
            if crc and name.endswith('.npz'):
                with zipfile.ZipFile(path) as archive:
                    if archive.testzip() is not None:
                        raise AssertionError(f'CRC failure: {name}')
                checks += 1
    return checks


def preflight(out):
    p = load(out / 'protocol.json')
    checks = identities(p, crc=True)
    save(out / 'recovery.json', {'status': 'PASS', 'checks': checks,
         'scope': 'all consumed inputs/code, prepared ZIP CRC; no whole-repository scan'})
    print(f'recovery PASS checks={checks}', flush=True)


def checked(out):
    p = load(out / 'protocol.json')
    if load(out / 'recovery.json')['status'] != 'PASS':
        raise AssertionError('scoped recovery required')
    identities(p)
    return p


def triples(graph):
    with (old.DATA / graph / 'triples.tsv').open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f, delimiter='\t'))


def describe_batch(cases):
    scopes, supports, groups, candidate_cost = [], [], [], 0
    for row in cases:
        kernel, meta = old.read_query(row['graph'], row['rank'])
        edges = kernel.edge_indices
        scopes.append(set(edges))
        supports.extend(tuple(sorted(edges[int(i)] for i in indices))
                        for indices in kernel.incidence_positions if len(indices))
        groups.extend(tuple(sorted(edges[i] for i in indices))
                      for signature, indices in incidence_groups(kernel.incidence_positions, len(edges)))
        candidate_cost += 10 * len(kernel.candidates)
    independent_edges = sum(map(len, scopes))
    unique_edges = len(set().union(*scopes))
    independent_reductions = sum(map(len, supports))
    unique_reductions = sum(map(len, set(supports)))
    jaccards = [len(a & b) / len(a | b) for i, a in enumerate(scopes)
                for b in scopes[i + 1:] if a | b]
    independent = independent_edges + independent_reductions + candidate_cost
    shared = unique_edges + unique_reductions + candidate_cost
    return {'queries': len(cases), 'independent_work': independent,
            'shared_ideal_work': shared, 'theoretical_saving': 1 - shared / independent,
            'independent_edge_draws': independent_edges, 'unique_edge_draws': unique_edges,
            'independent_degree_additions': independent_reductions,
            'unique_degree_additions': unique_reductions, 'candidate_work': candidate_cost,
            'count_groups': len(groups), 'unique_group_supports': len(set(groups)),
            'count_group_share_fraction': 1 - len(set(groups)) / len(groups),
            'jaccard_all_pairs': jaccards,
            'jaccard_quantiles': dict(zip(['min', 'p25', 'median', 'p75', 'p95', 'max'],
                  map(float, np.quantile(jaccards, [0, .25, .5, .75, .95, 1])))),
            'overlapping_pair_fraction': sum(x > 0 for x in jaccards) / len(jaccards)}


def c_static(out):
    p = checked(out)
    graphs = {g: describe_batch([r for r in p['c_cases'] if r['graph'] == g])
              for g in ('dw', 'enfr')}
    independent = sum(r['independent_work'] for r in graphs.values())
    shared = sum(r['shared_ideal_work'] for r in graphs.values())
    ratio = 1 - shared / independent
    save(out / 'c_static.json', {'status': 'PASS', 'graphs': graphs,
         'theoretical_saving': ratio, 'threshold': p['thresholds']['C_theory'],
         'theory_pass': ratio >= p['thresholds']['C_theory'],
         'next': 'simple_implementation' if ratio >= .20 else 'STOP_C_no_implementation',
         'limitations': ['logical unit work, not runtime or theorem of maximal sharing',
                        'only historical exact-reference degree queries',
                        'matrix/static caches equally available to baseline']})
    print(f'C theoretical saving={ratio:.6%}; pass={ratio >= .20}', flush=True)


def shifted_box(kernel, labels, change, p):
    low, high = clipped_box(np.full(len(kernel.edge_indices), p['nominal']), p['tau'])
    changed = np.asarray([labels[e][change['field']] == change['value']
                          for e in kernel.edge_indices], dtype=bool)
    a = change['amplitude']
    if change['kind'] == 'tighten':
        low[changed] += a
        high[changed] -= a
    elif change['kind'] == 'shift':
        low[changed] -= a
        high[changed] -= a
    elif change['kind'] in ('widen', 'relation'):
        low[changed] -= a
    else:
        raise ValueError(change)
    return np.clip(low, 0, 1), np.clip(high, 0, 1), changed


def update_manifest(out):
    p = checked(out)
    manifests = {}
    for graph in ('dw', 'enfr'):
        records = triples(graph)
        relation_counts = Counter(r['relation_id'] for r in records)
        top = sorted(relation_counts, key=lambda r: (-relation_counts[r], r))[:10]
        if len(top) != 10:
            raise AssertionError('insufficient relationship types')
        changes = []
        for kind in ('tighten', 'shift', 'widen', 'relation'):
            for j in range(10):
                changes.append({'index': len(changes), 'kind': kind,
                    'amplitude': p['amplitudes'][j % 5],
                    'field': 'relation_id' if kind == 'relation' else 'graph_id',
                    'value': top[j] if kind == 'relation' else ['source', 'target'][j % 2]})
        manifests[graph] = {'changes': changes,
            'top_relations': [{'relation_id': r, 'edges': relation_counts[r]} for r in top]}
    save(out / 'updates.json', {'status': 'FROZEN_BEFORE_BOX_EVALUATION', 'graphs': manifests})
    print('40 structural configuration changes per graph frozen', flush=True)


def updated_compiled(base, kernel, low, high, cap):
    """Reuse score tensor only if the exact exchange classes survive."""
    groups = []
    for signature, edges, endpoint in base['groups']:
        l = low[list(edges)]
        h = high[list(edges)]
        if not (np.all(l == l[0]) and np.all(h == h[0])):
            return compile_counts(kernel, low, high, cap), False
        groups.append((signature, edges, (float(l[0]), float(h[0]))))
    return {**base, 'groups': tuple(groups)}, True


def matrices_for(compiled, cache):
    matrices, denominator = [], 1
    for signature, edges, endpoint in compiled['groups']:
        key = (len(edges), *endpoint)
        if key not in cache:
            cache[key] = endpoint_matrix(*key)
        matrix, scale = cache[key]
        matrices.append(matrix)
        denominator *= scale
    return matrices, denominator


def contract(values, matrix, axis):
    return np.moveaxis(np.tensordot(matrix, values, axes=(1, axis)), 0, axis)


def exact_fast(compiled, k, cache, prior=None, partials=None):
    matrices, denominator = matrices_for(compiled, cache)
    numerators = []
    if prior is None:
        changed = tuple(range(len(matrices)))
    else:
        changed = tuple(i for i, (new, prev) in enumerate(zip(compiled['groups'], prior['groups']))
                        if new[2] != prev[2])
        if len(prior['groups']) != len(compiled['groups']):
            raise AssertionError('incompatible partial contraction')
    for candidate in range(k):
        if prior is not None and partials is not None:
            key = (candidate, changed)
            if key not in partials:
                previous, _ = matrices_for(prior, cache)
                values = (prior['winners'] == candidate).astype(object)
                for axis in range(len(matrices)):
                    if axis not in changed:
                        values = contract(values, previous[axis], axis)
                partials[key] = values
            values = partials[key].copy()
        else:
            values = (compiled['winners'] == candidate).astype(object)
        for axis in changed:
            values = contract(values, matrices[axis], axis)
        numerators.append(values)
    if any(int(x) != denominator for x in sum(numerators).flat):
        raise AssertionError('exact probability normalization')
    return [w for w in range(k) if all(bool(np.all(numerators[w] > numerators[d]))
                                     for d in range(k) if w != d)]


def common_constant(base):
    unique = np.unique(base['winners'])
    return [int(unique[0])] if len(unique) == 1 else None


def measure_method(method, kernel, case, base, labels, changes, p):
    k = len(kernel.candidates)
    winner = case['uniform_winners']
    cache, partials = {}, {}
    # Shared historical matrices are existing assets, equally available.
    matrices_for(base, cache)
    constant = common_constant(base)
    base_low, base_high = clipped_box(np.full(len(kernel.edge_indices), p['nominal']), p['tau'])
    prep_started = time.perf_counter()
    radius, prep_trials = 0., []
    if method == 'margin_incremental' and constant is None:
        for amplitude in p['amplitudes']:
            expanded_low = np.clip(base_low - amplitude, 0, 1)
            expanded, compatible = updated_compiled(base, kernel, expanded_low, base_high, p['state_cap'])
            if not compatible:
                raise AssertionError('uniform expansion broke initial symmetry')
            answers = exact_fast(expanded, k, cache)
            prep_trials.append({'amplitude': amplitude, 'winners': answers})
            if answers != winner:
                break
            radius = amplitude
    preparation_seconds = time.perf_counter() - prep_started
    rows = []
    total_start = time.perf_counter()
    for change in changes:
        start = time.perf_counter()
        low, high, touched = shifted_box(kernel, labels, change, p)
        reused, recomputed, status, answers = False, False, '', None
        if constant is not None:
            reused, status, answers = True, 'common_constant', constant
        elif method != 'all' and not bool(np.any(touched)):
            reused, status, answers = True, 'scope_unaffected', winner
        elif method in ('containment', 'margin_incremental') and bool(np.all(low >= base_low) and np.all(high <= base_high)):
            reused, status, answers = True, 'contained', winner
        elif method == 'margin_incremental' and bool(np.all(low >= np.clip(base_low - radius, 0, 1)) and np.all(high <= base_high)):
            reused, status, answers = True, 'certified_margin', winner
        else:
            recomputed = True
            try:
                compiled, compatible = updated_compiled(base, kernel, low, high, p['state_cap'])
                incremental = method == 'margin_incremental' and compatible
                answers = exact_fast(compiled, k, cache, base if incremental else None,
                                     partials if incremental else None)
                status = 'incremental' if incremental else 'exact_recompute'
            except ValueError as error:
                if 'count state cap' not in str(error):
                    raise
                status = 'unknown_state_cap'
        rows.append({'change': change['index'], 'kind': change['kind'], 'method': method,
                     'seconds': time.perf_counter() - start, 'reused': reused,
                     'recomputed': recomputed, 'status': status, 'winners': answers})
    maintenance_seconds = time.perf_counter() - total_start
    return {'method': method, 'preparation_seconds': preparation_seconds,
            'maintenance_seconds': maintenance_seconds,
            'total_seconds': preparation_seconds + maintenance_seconds,
            'radius': radius, 'radius_trials': prep_trials, 'rows': rows,
            'partial_cache_entries': len(partials)}


def b_run(out):
    p = checked(out)
    updates = load(out / 'updates.json')
    records = {g: triples(g) for g in ('dw', 'enfr')}
    all_rows, loads = [], []
    began = time.perf_counter()
    for i, case in enumerate(p['b_cases']):
        started = time.perf_counter()
        kernel, meta = old.read_query(case['graph'], case['rank'])
        low, high = clipped_box(np.full(len(kernel.edge_indices), p['nominal']), p['tau'])
        compiled = compile_counts(kernel, low, high, p['state_cap'])
        # Check historical strict-winner certificate against a complete initial solve.
        exact = solve_counts(compiled, len(kernel.candidates))
        if exact['uniform_winners'] != case['uniform_winners']:
            raise AssertionError('historical certificate mismatch')
        loads.append({'graph': case['graph'], 'rank': case['rank'],
                      'initial_load_compile_validate_seconds': time.perf_counter() - started})
        changes = updates['graphs'][case['graph']]['changes']
        runs = []
        for repeat in range(p['repeats']):
            offset = (i + repeat) % len(METHODS)
            order = METHODS[offset:] + METHODS[:offset]
            for method in order:
                runs.append({'repeat': repeat, **measure_method(method, kernel, case, compiled,
                            records[case['graph']], changes, p)})
        save(out / 'b_queries' / f"{case['graph']}_q{case['rank']:03d}.json",
             {'case': case, 'runs': runs})
        all_rows.append({'graph': case['graph'], 'rank': case['rank'],
             'costs': {method: statistics.median(r['total_seconds'] for r in runs if r['method'] == method)
                       for method in METHODS},
             'constant': common_constant(compiled) is not None})
        print(f"B completed {i+1}/{len(p['b_cases'])} {case['graph']} q{case['rank']:03d}", flush=True)
    save(out / 'b_timing.json', {'status': 'PASS', 'rows': all_rows, 'loading': loads,
          'elapsed_seconds': time.perf_counter() - began, 'protocol_sha256': sha(out / 'protocol.json')})


def b_validate(out):
    p = checked(out)
    updates = load(out / 'updates.json')
    labels = {g: triples(g) for g in ('dw', 'enfr')}
    checks, reused, errors, unverified, statuses = 0, 0, [], [], Counter()
    validation_rows = []
    began = time.perf_counter()
    for index, case in enumerate(p['b_cases']):
        kernel, meta = old.read_query(case['graph'], case['rank'])
        k = len(kernel.candidates)
        observed = load(out / 'b_queries' / f"{case['graph']}_q{case['rank']:03d}.json")
        changes = updates['graphs'][case['graph']]['changes']
        by_change = {}
        for run in observed['runs']:
            for row in run['rows']:
                by_change.setdefault(row['change'], []).append(row)
                statuses[run['method'] + ':' + row['status']] += 1
        for change in changes:
            low, high, touched = shifted_box(kernel, labels[case['graph']], change, p)
            reference, error, scalar_checks = None, None, 0
            try:
                # Reconstruct score tensor from raw kernel, not the maintained tensor.
                compiled = compile_counts(kernel, low, high, p['state_cap'])
                exact = solve_counts(compiled, k)
                reference = exact['uniform_winners']
                points = {tuple(pair['minimizing_high_endpoint_counts']) for pair in exact['pairs']
                          if pair['candidate'] in case['uniform_winners']}
                for point in sorted(points):
                    scalar = direct_representative_probabilities(compiled, exact['matrices'], point, k)
                    if scalar != [int(v[point]) for v in exact['numerators']]:
                        raise AssertionError('independent scalar extremum mismatch')
                    scalar_checks += 1
            except ValueError as exc:
                if 'count state cap' not in str(exc):
                    raise
                error = str(exc)
            for row in by_change[change['index']]:
                checks += 1
                if row['reused']:
                    reused += 1
                    if reference is None:
                        unverified.append({'graph': case['graph'], 'rank': case['rank'],
                                           'change': change['index'], 'method': row['method']})
                if reference is not None and row['winners'] is not None and row['winners'] != reference:
                    errors.append({'graph': case['graph'], 'rank': case['rank'],
                                   'change': change['index'], 'method': row['method'],
                                   'observed': row['winners'], 'reference': reference})
            checks += scalar_checks
            validation_rows.append({'graph': case['graph'], 'rank': case['rank'],
                'change': change['index'], 'kind': change['kind'], 'winners': reference,
                'reference_error': error, 'scalar_checks': scalar_checks})
        print(f"B validated {index+1}/{len(p['b_cases'])}", flush=True)
    save(out / 'b_validation.json', {'status': 'PASS' if not errors and not unverified else 'FAIL',
         'checks': checks, 'reuse_observations_all_methods_and_repeats': reused,
         'errors': errors, 'unverified_reuse': unverified, 'status_counts': dict(statuses),
         'references': validation_rows, 'elapsed_seconds': time.perf_counter() - began,
         'protocol_sha256': sha(out / 'protocol.json')})


def b_analyze(out):
    p = checked(out)
    timing = load(out / 'b_timing.json')
    validation = load(out / 'b_validation.json')
    rows = timing['rows']
    base = np.array([r['costs']['containment'] for r in rows])
    method = np.array([r['costs']['margin_incremental'] for r in rows])
    ratio = 1 - method.sum() / base.sum()
    rng = np.random.default_rng(p['bootstrap_seed'])
    strata = [np.array([i for i, r in enumerate(rows) if r['graph'] == g]) for g in ('dw', 'enfr')]
    bootstrap = []
    for _ in range(p['bootstrap_repeats']):
        idx = np.concatenate([rng.choice(s, len(s), replace=True) for s in strata])
        bootstrap.append(1 - method[idx].sum() / base[idx].sum())
    interval = list(map(float, np.quantile(bootstrap, [.025, .975])))
    passed = bool(ratio >= p['thresholds']['B_cost'] and interval[0] > 0
                  and validation['status'] == 'PASS')
    by_graph = {}
    for g, s in zip(('dw', 'enfr'), strata):
        by_graph[g] = {'queries': len(s), 'base_seconds': float(base[s].sum()),
            'method_seconds': float(method[s].sum()), 'saving': float(1 - method[s].sum() / base[s].sum())}
    by_kind = {}
    aggregates = {m: {'recomputed': 0, 'reused': 0, 'unknown': 0, 'total': 0} for m in METHODS}
    for case in p['b_cases']:
        record = load(out / 'b_queries' / f"{case['graph']}_q{case['rank']:03d}.json")
        for run in record['runs']:
            for row in run['rows']:
                bucket = aggregates[run['method']]
                bucket['total'] += 1
                bucket['recomputed'] += int(row['recomputed'])
                bucket['reused'] += int(row['reused'])
                bucket['unknown'] += int(row['winners'] is None)
        for kind in ('tighten', 'shift', 'widen', 'relation'):
            bucket = by_kind.setdefault(kind, {m: 0. for m in METHODS})
            for m in METHODS:
                bucket[m] += statistics.median(sum(r['seconds'] for r in run['rows'] if r['kind'] == kind)
                                               for run in record['runs'] if run['method'] == m)
    save(out / 'b_analysis.json', {'status': 'PASS', 'B_pass': passed,
        'saving': float(ratio), 'paired_descriptive_95pct': interval,
        'threshold': p['thresholds']['B_cost'], 'R': 40,
        'cost_seconds_sum_query_medians': {m: sum(r['costs'][m] for r in rows) for m in METHODS},
        'by_graph': by_graph, 'maintenance_only_by_kind_not_gates': by_kind,
        'observations_including_5_repeats': aggregates,
        'validation_status': validation['status'], 'error_count': len(validation['errors']),
        'unverified_reuse_count': len(validation['unverified_reuse']),
        'constant_queries': sum(r['constant'] for r in rows),
        'limitations': ['known selected exact-reference degree queries only',
            'descriptive query-block bootstrap on two shared graphs, not population inference',
            'standard expanded-box synthesis and cached tensor contraction; novelty not established',
            'cannot extrapolate to GCN-Align/SEU or new datasets',
            'failing validation including resource-unknown reuse prevents acceptance']})
    print(f'B saving={ratio:.6%}, CI={interval}, pass={passed}', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', required=True,
        choices=['freeze', 'preflight', 'c_static', 'updates', 'b_run', 'b_validate', 'b_analyze'])
    parser.add_argument('--output', type=Path, default=OUT)
    args = parser.parse_args()
    phases = {'freeze': freeze, 'preflight': preflight, 'c_static': c_static,
              'updates': update_manifest, 'b_run': b_run, 'b_validate': b_validate, 'b_analyze': b_analyze}
    phases[args.phase](args.output.resolve())
