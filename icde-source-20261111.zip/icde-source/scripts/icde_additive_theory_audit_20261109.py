"""Finite structural audit of the ten historical quantifier omissions.

Reuse frozen scorers and exact count inference. No sampling or new queries.
Counterfactual two-candidate comparisons retain the original two scores.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as Q
import json
from pathlib import Path
import zipfile

import numpy as np

import icde_prospective_20261107 as old
from icde_grouped_exact_20261108 import compile_counts, solve_counts
from icde_parameter_association_20261108 import pointwise_population
from run_vldb_interval_gate_v1 import clipped_box


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_additive_theory_20261109/attempt1"
CENSUS = ROOT / "nodes/09_vldb_query_certification/results/icde_parameter_association_20261108/attempt1/quantifier_census.json"


def identities(protocol):
    for name, digest in protocol["input_sha256"].items():
        if old.sha(ROOT / name) != digest:
            raise AssertionError(f"Frozen input changed: {name}")
    return len(protocol["input_sha256"])


def freeze():
    rows = [row for row in old.load(CENSUS)["rows"] if row["quantifier_omission"]]
    if len(rows) != 10:
        raise AssertionError("Expected the ten pre-existing omissions")
    files = [CENSUS, Path(__file__)]
    for name in ("icde_prospective_20261107.py", "icde_grouped_exact_20261108.py",
                 "icde_grouped_inventory_20261108.py", "icde_parameter_association_20261108.py",
                 "vldb_capture_attribute_v0.py", "vldb_difference_envelope_v2.py",
                 "vldb_interval_envelope_v1.py", "run_vldb_interval_gate_v1.py"):
        files.append(ROOT / "scripts" / name)
    for row in rows:
        metadata = old.BASE / "prepared" / row["graph"] / f"q{row['rank']:03d}.json"
        files.extend((metadata, metadata.with_suffix(".npz")))
    old.save(BASE / "protocol.json", {
        "scope": "all ten historical omissions, exhaustive grouped states, no sampling",
        "cases": [{"graph": row["graph"], "rank": row["rank"]} for row in rows],
        "nominal": .9, "tau": .25, "state_cap": 32768,
        "comparison": "minimum pointwise-gap competitor for the original robust winner",
        "nonlinearity_test": "remove all other candidates, retain original scores, recompute exact robust and pointwise gaps",
        "monotonicity_test": "all adjacent group-count transitions, both signs on one axis, strict-winner witnesses",
        "third_candidate_test": "full D changes on a transition where reduced binary D is unchanged",
        "tie_test": "all-state float64 and exact-rational score ties, plus reversed tie order if needed",
        "rational_semantics": "exact expression on frozen binary64 input constants, compared with original rounded operation order",
        "gates": {
            "fixed_K_B_T": "exact polynomial upper bound G <= T*(B+1)^K stops hardness search in this class",
            "lower_bound": "explicit scorer syntax, growing resource, fixed interior epsilon and constant two-sided gap, polynomial construction, soundness for every independent parameter choice",
            "prior_art": "transfer must preserve independence, scoring syntax, interval restrictions, gap and reduction size",
            "outcome": "only basic lemmas or unmatched general hardness do not establish a standalone theory paper",
        },
        "input_sha256": {path.relative_to(ROOT).as_posix(): old.sha(path) for path in files},
    })
    print("FROZEN ten historical cases and decision gates", flush=True)


def recover():
    protocol = old.load(BASE / "protocol.json")
    checks = identities(protocol)
    archives = 0
    for name in protocol["input_sha256"]:
        if name.endswith(".npz"):
            with zipfile.ZipFile(ROOT / name) as archive:
                if archive.testzip() is not None:
                    raise AssertionError(f"NPZ CRC failed: {name}")
            archives += 1
    if (BASE / "audit.json").exists():
        raise FileExistsError("Audit result already exists")
    old.save(BASE / "recovery.json", {"status": "PASS", "hash_checks": checks,
        "npz_crc_checks": archives, "protocol_sha256": old.sha(BASE / "protocol.json")})
    print(f"Recovery PASS hashes={checks} archives={archives}", flush=True)


def score_table(kernel, compiled):
    counts = np.indices(compiled["shape"], dtype=np.int64).reshape(len(compiled["shape"]), -1).T
    states = np.zeros((len(counts), len(kernel.edge_indices)), dtype=np.bool_)
    for axis, (signature, edges, endpoint) in enumerate(compiled["groups"]):
        states[:, list(edges)] = np.arange(len(edges))[None, :] < counts[:, axis, None]
    scores = kernel.scores(states)
    winners = np.argmax(scores, axis=1)
    if not np.array_equal(winners.reshape(compiled["shape"]), compiled["winners"]):
        raise AssertionError("Count mapping differs from original scorer")
    degrees = np.column_stack([np.sum(states[:, positions], axis=1) for positions in kernel.incidence_positions])
    distances = np.abs(degrees[:, 0, None] - degrees[:, 2::2]) + np.abs(degrees[:, 1, None] - degrees[:, 3::2])
    weight = Q.from_float(kernel.attribute_weight)
    attributes = list(map(Q.from_float, map(float, kernel.attribute)))
    lexical = list(map(Q.from_float, map(float, kernel.lexical)))
    rational = []
    for row in distances:
        rational.append([weight * attribute + (1 - weight) *
            (Q.from_float(.6) * lex + Q.from_float(.4) / (1 + int(distance)))
            for attribute, lex, distance in zip(attributes, lexical, row)])
    rational = np.asarray(rational, dtype=object)
    exact_winners = np.argmax(rational, axis=1)
    float_ties = np.sum(scores == np.max(scores, axis=1)[:, None], axis=1) > 1
    exact_ties = np.sum(rational == np.max(rational, axis=1)[:, None], axis=1) > 1
    return counts, scores, rational, degrees, distances, {
        "all_state_original_scorer_checks": len(counts),
        "float_top_tie_states": int(np.sum(float_ties)),
        "rational_top_tie_states": int(np.sum(exact_ties)),
        "rational_winner_disagreements": int(np.sum(winners != exact_winners)),
    }


def transition_witnesses(values, strict, compiled):
    result = []
    for axis, (signature, edges, endpoint) in enumerate(compiled["groups"]):
        before = [slice(None)] * values.ndim
        after = before.copy()
        before[axis], after[axis] = slice(None, -1), slice(1, None)
        differences = values[tuple(after)] - values[tuple(before)]
        strict_both = strict[tuple(before)] & strict[tuple(after)]
        witnesses = {}
        for name, mask in (("increase", differences > 0), ("decrease", differences < 0)):
            locations = np.argwhere(mask & strict_both)
            if len(locations):
                lower = locations[0].astype(int)
                upper = lower.copy()
                upper[axis] += 1
                witnesses[name] = {"before": lower.tolist(), "after": upper.tolist(),
                    "D_before": int(values[tuple(lower)]), "D_after": int(values[tuple(upper)])}
        if len(witnesses) == 2:
            result.append({"axis": axis, "signature": list(signature),
                "edge_local": int(edges[-1]), "group_size": len(edges), **witnesses})
    return result


def equality_face(winners, strict, compiled, w, d):
    shape = winners.shape
    for state in np.ndindex(shape):
        for first in range(len(shape)):
            for second in range(first, len(shape)):
                increments = np.zeros(len(shape), dtype=int)
                increments[first] += 1
                increments[second] += 1
                if any(state[axis] + increments[axis] >= shape[axis] for axis in range(len(shape))):
                    continue
                left, right, both = list(state), list(state), list(state)
                left[first] += 1
                right[second] += 1
                both[first] += 1
                both[second] += 1
                corners = [state, tuple(left), tuple(right), tuple(both)]
                labels = [int(winners[at]) for at in corners]
                if labels in ([w, d, d, w], [d, w, w, d]) and all(strict[at] for at in corners):
                    return {"axes": [first, second], "counts_00_10_01_11": list(map(list, corners)),
                        "winners_00_10_01_11": labels}
    return None


def audit_case(row):
    kernel, metadata = old.read_query(row["graph"], row["rank"])
    k, m = len(kernel.candidates), len(kernel.edge_indices)
    low, high = clipped_box(np.full(m, .9), .25)
    compiled = compile_counts(kernel, low, high)
    full = solve_counts(compiled, k)
    population, masks = pointwise_population(compiled, full, k)
    if full["uniform_winners"] != row["uniform_winners"] or population["minimum_gaps_exact"] != row["minimum_gaps_exact"]:
        raise AssertionError("Historical exact result changed")
    w = row["uniform_winners"][0]
    pair = min((pair for pair in row["pairs"] if pair["candidate"] == w), key=lambda pair: Q(pair["gap_exact"]))
    d = pair["competitor"]
    counts, scores, rational, degrees, distances, tie_checks = score_table(kernel, compiled)
    shape = compiled["shape"]
    full_winners = compiled["winners"]
    full_D = (full_winners == w).astype(int) - (full_winners == d).astype(int)
    binary_wins = (scores[:, w] > scores[:, d]) | ((scores[:, w] == scores[:, d]) & (w < d))
    binary_winners = np.where(binary_wins, 0, 1).reshape(shape)
    binary = {**compiled, "winners": binary_winners}
    binary_result = solve_counts(binary, 2)
    binary_population, _ = pointwise_population(binary, binary_result, 2)
    binary_gap = next(pair["minimum_gap_exact"] for pair in binary_result["pairs"] if pair["candidate"] == 0)
    binary_pointwise = binary_population["minimum_gaps_exact"][0]
    exact_binary_wins = (rational[:, w] > rational[:, d]) | ((rational[:, w] == rational[:, d]) & (w < d))
    tie_checks["binary_float_tie_states"] = int(np.sum(scores[:, w] == scores[:, d]))
    tie_checks["binary_rational_tie_states"] = int(np.sum(rational[:, w] == rational[:, d]))
    tie_checks["binary_rational_winner_disagreements"] = int(np.sum(binary_wins != exact_binary_wins))
    full_strict = (np.sum(scores == np.max(scores, axis=1)[:, None], axis=1) == 1).reshape(shape)
    full_strict &= (np.sum(rational == np.max(rational, axis=1)[:, None], axis=1) == 1).reshape(shape)
    binary_strict = ((scores[:, w] != scores[:, d]) & (rational[:, w] != rational[:, d])).reshape(shape)
    binary_D = 1 - 2 * binary_winners
    binary_witnesses = transition_witnesses(binary_D, binary_strict, compiled)
    for witness in binary_witnesses:
        witness["edge_id"] = int(kernel.edge_indices[witness["edge_local"]])
        for direction in ("increase", "decrease"):
            for side in ("before", "after"):
                at = tuple(witness[direction][side])
                index = int(np.ravel_multi_index(at, shape))
                witness[direction][side + "_degrees"] = degrees[index].astype(int).tolist()
                witness[direction][side + "_scores"] = scores[index, [w, d]].tolist()
                witness[direction][side + "_exact_score_difference"] = str(rational[index, w] - rational[index, d])
    third_transitions = 0
    for axis in range(len(shape)):
        before, after = [slice(None)] * len(shape), [slice(None)] * len(shape)
        before[axis], after[axis] = slice(None, -1), slice(1, None)
        third_transitions += int(np.sum((np.diff(full_D, axis=axis) != 0) &
            (np.diff(binary_D, axis=axis) == 0) & full_strict[tuple(before)] & full_strict[tuple(after)]))
    face = equality_face(full_winners, full_strict, compiled, w, d)
    if face:
        indices = [int(np.ravel_multi_index(tuple(at), shape)) for at in face["counts_00_10_01_11"]]
        face["degrees_00_10_01_11"] = degrees[indices].astype(int).tolist()
        face["distances_00_10_01_11"] = distances[indices].astype(int).tolist()
        face["scores_00_10_01_11"] = scores[indices].tolist()
    reversed_gap = reversed_pointwise = None
    if tie_checks["float_top_tie_states"]:
        reversed_winners = (k - 1 - np.argmax(scores[:, ::-1], axis=1)).reshape(shape)
        reversed_compiled = {**compiled, "winners": reversed_winners}
        reversed_result = solve_counts(reversed_compiled, k)
        reversed_population, _ = pointwise_population(reversed_compiled, reversed_result, k)
        reversed_gap = min(Q(pair["minimum_gap_exact"]) for pair in reversed_result["pairs"] if pair["candidate"] == w)
        reversed_pointwise = Q(reversed_population["minimum_gaps_exact"][w])
    return {"graph": row["graph"], "rank": row["rank"], "K": k, "scope_edges": m,
        "count_states": compiled["count_states"], "winner": w, "competitor": d,
        "original_robust_gap": row["true_minimum_gaps_exact"][w],
        "original_pointwise_gap": row["minimum_gaps_exact"][w],
        "binary_robust_gap": binary_gap, "binary_pointwise_gap": binary_pointwise,
        "binary_omission_survives": Q(binary_gap) > 0 and Q(binary_pointwise) <= 0,
        "binary_strict_nonunate_axes": binary_witnesses,
        "full_strict_nonunate_axes": transition_witnesses(full_D, full_strict, compiled),
        "third_candidate_only_transition_count": third_transitions,
        "strict_equality_face": face, "tie_checks": tie_checks,
        "reversed_tie_robust_gap": str(reversed_gap) if reversed_gap is not None else None,
        "reversed_tie_pointwise_gap": str(reversed_pointwise) if reversed_pointwise is not None else None}


def run():
    protocol = old.load(BASE / "protocol.json")
    recovery = old.load(BASE / "recovery.json")
    if recovery["status"] != "PASS" or recovery["protocol_sha256"] != old.sha(BASE / "protocol.json"):
        raise AssertionError("Recovery does not match protocol")
    identities(protocol)
    rows = [row for row in old.load(CENSUS)["rows"] if row["quantifier_omission"]]
    results = []
    for row in rows:
        result = audit_case(row)
        results.append(result)
        print(f"Audited {row['graph']} q{row['rank']:03d}: binary omission={result['binary_omission_survives']}", flush=True)
    old.save(BASE / "audit.json", {"protocol_sha256": old.sha(BASE / "protocol.json"),
        "cases": results, "summary": {
            "queries": len(results), "original_K2": sum(row["K"] == 2 for row in results),
            "binary_omissions": sum(row["binary_omission_survives"] for row in results),
            "binary_strict_nonunate": sum(bool(row["binary_strict_nonunate_axes"]) for row in results),
            "with_third_candidate_transitions": sum(row["third_candidate_only_transition_count"] > 0 for row in results),
            "all_state_scorer_checks": sum(row["tie_checks"]["all_state_original_scorer_checks"] for row in results),
            "rational_winner_disagreements": sum(row["tie_checks"]["rational_winner_disagreements"] for row in results),
        }})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("freeze", "recover", "run"))
    mode = parser.parse_args().mode
    {"freeze": freeze, "recover": recover, "run": run}[mode]()
