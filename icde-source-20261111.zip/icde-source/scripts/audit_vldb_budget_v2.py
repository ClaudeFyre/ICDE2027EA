"""Final read-only integrity and hard-work-budget audit for the V2 follow-up."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from audit_vldb_validation_20261104 import run as audit_earlier
from run_vldb_budget_validation_v2 import verify as verify_v2
from run_vldb_hard_budget_v2 import verify as verify_hard, read, write_new

ROOT = Path(__file__).resolve().parents[1]


def run():
    earlier = audit_earlier()
    failures = list(earlier["failures"])
    protocol = ROOT / "configs/vldb_budget_v2_20261104.json"
    config = read(protocol)
    folder = ROOT / config["result_root"]
    verify_v2(config, protocol, folder, False)
    hard_protocol = ROOT / "configs/vldb_hard_budget_v2_20261104.json"
    hard_config = read(hard_protocol)
    hard_folder = ROOT / hard_config["result_root"]
    parent = verify_hard(hard_config, hard_protocol, hard_folder, False)
    worlds = removed = 0
    for specification in parent["raw_paired_stream_files"]:
        record = read(ROOT / specification["path"])
        n = len(record["winner_indices"])
        worlds += n
        for row in record["tau_records"]:
            arrays = [row[key] for key in ("h_difference", "h_source_conditioned", "free_flags",
                                           "conditioning_degree_rows", "conditioning_assignment_counts")]
            if any(len(array) != n for array in arrays):
                failures.append("incomplete_paired_prefix")
            for base, conditioned, free, degree, assignments in zip(*arrays):
                if conditioned and not base or base and not free:
                    failures.append("invalid_event_refinement")
                if degree not in (0, 1) or not 0 <= assignments <= config["max_source_assignments"]:
                    failures.append("invalid_work_cap")
                if bool(assignments) != bool(degree):
                    failures.append("invalid_conditioning_accounting")
                removed += bool(base and not conditioned)
    hard = read(hard_folder / "hard_budget_gate.json")
    if hard["status"] != "PASS" or hard["new_worlds_generated"]:
        failures.append("hard_replay_failed_or_generated_worlds")
    violations = sum(row["work_used"] > row["work_budget"] for row in hard["policy_rows"])
    if violations:
        failures.append("hard_work_budget_exceeded")
    if parent["additional_event_random_draws"] != 0:
        failures.append("unexpected_added_event_draws")
    return {"status": "PASS" if not failures else "FAIL", "failures": failures,
            "earlier_audit": earlier["status"], "V2_raw_streams_checked": len(parent["raw_paired_stream_files"]),
            "fresh_nominal_winners_checked": worlds,
            "source_refinement_flags_removed": removed,
            "hard_policy_rows_checked": len(hard["policy_rows"]),
            "hard_work_budget_violations": violations,
            "all_parent_freezes_and_archive_preserved": True,
            "same_walltime_advantage_established": False,
            "major_algorithm_novelty_established": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run()
    write_new(args.output, result)
    print(json.dumps(result, ensure_ascii=True))
    raise SystemExit(0 if result["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
