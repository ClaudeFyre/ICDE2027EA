"""Frozen all-259 comparison with a common sparse kernel and block-event prototype."""
import argparse
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path
import time
import numpy as np

import icde_prospective_20261107 as old
import icde_grouped_exact_20261108 as exact_module
import icde_partial_count_20261108 as partial_module
import icde_large_event_screen_20261108 as screen
from icde_sparse_degree_20261108 import read_graph,read_query
from icde_block_events_20261108 import execute as block_execute
from icde_grouped_inventory_20261108 import ROOT,load,save,sha,identities
from icde_portfolio_budget_20261108 import budgeted_call,REAL_COUNTER

BASE=ROOT/'nodes/09_vldb_query_certification/results/icde_block_comparison_20261109/attempt1'
POLICIES=('direct_transport','generic_eager','factor_event','block_event2')
ORIGINAL_ENDPOINT=exact_module.endpoint_matrix


def freeze(out):
    if out.exists():raise FileExistsError(out)
    parent=load(screen.BASE/'protocol.json')
    code=dict(parent['code_sha256'])
    for name in ('icde_sparse_degree_20261108.py','icde_block_events_20261108.py',
                 'test_icde_sparse_block_events_20261108.py','icde_block_comparison_20261109.py'):
        code['scripts/'+name]=sha(ROOT/'scripts'/name)
    inputs=dict(parent['input_sha256'])
    for path in (screen.BASE/'protocol.json',screen.BASE/'summary.json'):
        inputs[path.relative_to(ROOT).as_posix()]=sha(path)
    audits=[{'graph':'dw','rank':113},{'graph':'enfr','rank':120}]
    for graph in ('dw','enfr'):
        largest=min((r for r in parent['cases'] if r['graph']==graph),
                    key=lambda r:(-r['retained_candidates'],r['rank']))
        audits.append({'graph':graph,'rank':largest['rank']})
    save(out/'protocol.json',{'kind':'historical_common_sparse_execution_block_event_feasibility',
        'cases':parent['cases'],'policies':list(POLICIES),'nominal':.9,'tau':.25,'seed':1063,
        'budget_seconds':.2,'repeats':1,'max_splits':127,'max_parameter_splits':31,
        'block_size':2,'block_state_cap':32768,'block_work_cap':2000000,
        'kernel_equivalence_audits':audits,'audit_seed':20261109,
        'physical_kernel':'integer sparse degree aggregation; original float64 score order and outward score-bound functions; identical kernel for all four methods',
        'shared_rules':'same paid all-present anchor and global interval frontend; per-method local endpoint-matrix cache, cleared at every method boundary and available equally to factor/block controls',
        'block_bound':'exact restricted categorical events on disjoint rival blocks; standard union upper bound on anchor losing, exact upper bounds on local rival wins; resource failures/late results remain unresolved',
        'comparison_scope':'[说明文本已清理]',
        'reference':'19 prior structurally selected exact frontier queries; never passed to methods',
        'risk':'same per-query .05 MC contracts as prior screen; factor and block deterministic',
        'timing':'graph index construction and shared prepared-query loading separate; all method-specific initialization, matrix caching and evidence included; 200ms cooperative deadline, late result discarded',
        'code_sha256':code,'input_sha256':inputs,'frozen_at_unix':time.time()})
    print('Frozen 259 x 4 same-kernel methods; block=2; 200ms cap; no new blind queries',flush=True)


def preflight(out):
    p=load(out/'protocol.json');checks=identities(p,False)
    if (out/'summary.json').exists() or (out/'cases').exists():raise FileExistsError('new attempt required')
    save(out/'recovery.json',{'status':'PASS','checks':checks})
    print('Preflight PASS',checks,flush=True)


def execute(kernel,meta,case,policy,p):
    cache={};calls=0
    def cached(n,low,high):
        nonlocal calls
        calls+=1;key=n,float(low),float(high)
        if key not in cache:cache[key]=ORIGINAL_ENDPOINT(n,low,high)
        return cache[key]
    previous_exact,previous_partial=exact_module.endpoint_matrix,partial_module.endpoint_matrix
    try:
        exact_module.endpoint_matrix=cached;partial_module.endpoint_matrix=cached
        raw=block_execute(kernel,p) if policy=='block_event2' else screen.execute(kernel,meta,case,policy,p)
    finally:
        exact_module.endpoint_matrix=previous_exact;partial_module.endpoint_matrix=previous_partial
    raw['endpoint_cache_entries']=len(cache);raw['endpoint_matrix_calls']=calls
    return raw


def run(out):
    p=load(out/'protocol.json')
    if load(out/'recovery.json')['status']!='PASS':raise AssertionError('preflight required')
    checks=identities(p,False);indexes={};index_times={}
    for graph in ('dw','enfr'):
        before=REAL_COUNTER();indexes[graph]=read_graph(graph);index_times[graph]=REAL_COUNTER()-before
    audits=[];rng=np.random.default_rng(p['audit_seed'])
    for case in p['kernel_equivalence_audits']:
        kernel,meta=read_query(case['graph'],case['rank'],indexes[case['graph']])
        original,_=old.read_query(case['graph'],case['rank'])
        m=len(kernel.edge_indices)
        states=np.vstack((np.zeros(m,dtype=bool),np.ones(m,dtype=bool),rng.random(m)<.9))
        np.testing.assert_array_equal(kernel.scores(states),original.scores(states))
        low=rng.random((2,m))<.65;high=np.ones_like(low)
        a,b=kernel.score_intervals(low,high);c,d=original.score_intervals(low,high)
        np.testing.assert_array_equal(a,c);np.testing.assert_array_equal(b,d)
        audits.append({**case,'K':len(kernel.candidates),'m':m,'scores':'bitwise_equal','bounds':'bitwise_equal'})
        checks+=3
    save(out/'kernel_audit.json',{'status':'PASS','cases':audits,'new_unit_tests':3})
    warm_case=next(r for r in load(screen.STATIC)['rows'] if r['graph']=='enfr' and r['rank']==175)
    kernel,meta=read_query('enfr',175,indexes['enfr']);warm=[]
    for policy in POLICIES:
        result=budgeted_call(lambda:execute(kernel,meta,warm_case,policy,p),p['budget_seconds'])
        result.pop('raw');warm.append({'policy':policy,**result})
    save(out/'warmup.json',warm)
    references={(r['graph'],r['rank']):r for r in load(screen.PARENT/'summary.json')['rows'] if r['role']=='frontier'}
    rows=[];loading=[]
    for index,case in enumerate(p['cases']):
        before=REAL_COUNTER();kernel,meta=read_query(case['graph'],case['rank'],indexes[case['graph']])
        loading.append({'graph':case['graph'],'rank':case['rank'],'seconds':REAL_COUNTER()-before})
        if kernel.shared_source_candidate_edge:raise AssertionError('released fastpath assumption changed')
        offset=index%len(POLICIES)
        for policy in POLICIES[offset:]+POLICIES[:offset]:
            result=budgeted_call(lambda:execute(kernel,meta,case,policy,p),p['budget_seconds'])
            raw=result.pop('raw')
            if (time.perf_counter is not REAL_COUNTER or exact_module.endpoint_matrix is not ORIGINAL_ENDPOINT
                or partial_module.endpoint_matrix is not ORIGINAL_ENDPOINT
                or screen.factor.probability_bounds is not screen.ORIGINAL_FACTOR_BOUNDS):
                raise AssertionError('runtime instrumentation leaked')
            if raw is None:raw={'status':'timeout','winner':None,'focus':None,'kind':'timeout','lower_gap':-1.,'upper_gap':1.}
            if raw['status']=='stable' and raw['winner']!=raw['focus']:
                raise AssertionError('robust answer contradicts included all-present law')
            reference=references.get((case['graph'],case['rank']));audit='reference_unknown'
            if reference:
                if raw['status']=='stable' and raw['winner'] not in reference['uniform_winners']:
                    raise AssertionError('certificate disagrees with exact reference')
                if raw['status']=='nonuniform' and reference['uniform_winners']:
                    raise AssertionError('negative proof disagrees with exact reference')
                if raw['focus'] is not None:
                    truth=min(Q(r['pair_gap_exact']) for r in reference['pairs'] if r['candidate']==raw['focus'])
                    valid=Q.from_float(raw['lower_gap'])<=truth<=Q.from_float(raw['upper_gap'])
                    if policy in ('factor_event','block_event2') and not valid:
                        raise AssertionError('deterministic bound misses true robust gap')
                    audit='reference_interval_consistent' if valid else 'observed_statistical_interval_failure'
                else:audit='reference_available_no_evidence'
            details={k:v for k,v in raw.items() if k not in ('trace','divergence_bounds','leaf_records','parameter_cells','compute_seconds')}
            row={'graph':case['graph'],'rank':case['rank'],'query_id':case['query_id'],'policy':policy,
                 'K':case['retained_candidates'],'G':case['reconstructed_group_count'],
                 'scope_edges':case['scope_edges'],**result,'details':details,'reference_audit':audit}
            save(out/'cases'/f"{case['graph']}_q{case['rank']:03d}_{policy}.json",row)
            rows.append(row);checks+=1
        if (index+1)%20==0 or index+1==len(p['cases']):print(f'Completed {index+1}/259, {len(rows)} runs',flush=True)
    checks+=identities(p,False)
    aggregates={}
    for policy in POLICIES:
        selected=[r for r in rows if r['policy']==policy]
        aggregates[policy]={'queries':len(selected),'statuses':dict(Counter(r['details']['status'] for r in selected)),
            'actual_compute_seconds':sum(r['compute_seconds'] for r in selected),
            'max_overrun_seconds':max(r['overrun_seconds'] for r in selected),
            'mean_gap_interval_width':float(np.mean([r['details']['upper_gap']-r['details']['lower_gap'] for r in selected])),
            'reference_stable_delivered':sum(r['details']['status']=='stable' and (r['graph'],r['rank']) in references for r in selected),
            'reference_audits':dict(Counter(r['reference_audit'] for r in selected))}
    save(out/'summary.json',{'status':'PASS','checks':checks,'protocol_sha256':sha(out/'protocol.json'),
        'rows':rows,'aggregates':aggregates,'loading':loading,'graph_index_seconds':index_times,
        'reference_queries':19,'unknown_reference_queries':240,'historical_inputs_unchanged':True})
    print(aggregates,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=('freeze','preflight','run'),required=True)
    parser.add_argument('--output',type=Path,default=BASE);args=parser.parse_args()
    {'freeze':freeze,'preflight':preflight,'run':run}[args.phase](args.output.resolve())
