import unittest
import numpy as np
from icde_alignment_signal_20261108 import metrics,fit_predict


class SignalTest(unittest.TestCase):
    def test_tied_ranking_does_not_depend_on_label_order(self):
        a=metrics([1,0,1,0],[.5]*4)
        b=metrics([0,1,0,1],[.5]*4)
        self.assertAlmostEqual(a['aurc'],.5)
        self.assertAlmostEqual(a['auroc'],.5)
        self.assertEqual(a,b)
        self.assertAlmostEqual(metrics([1,0],[1,0])['aurc'],.25)

    def test_ridge_handles_collinear_covariates_and_keeps_order(self):
        x=np.asarray([[-2,-2],[-1,-1],[1,1],[2,2]],dtype=float)
        p,fit=fit_predict(x,np.asarray([0,0,1,1]),x)
        self.assertTrue(np.all(np.diff(p)>0))
        self.assertTrue(p[0]<.5<p[-1])
        self.assertTrue(np.isfinite(fit['coefficients']).all())


if __name__=='__main__':unittest.main()
