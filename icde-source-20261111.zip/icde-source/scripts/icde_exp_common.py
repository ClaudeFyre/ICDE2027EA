"""Shared helpers for ICDE E2/E3/E4/E5 runners.

Delegates the *fixed* output/verification schema to the parallel agents'
canonical ``experiments/_common/exp_common.py`` so every runner emits
byte-compatible ``icde-experiment-output-v1`` / ``icde-experiment-verification-v1``
structures. Adds only experiment-side conveniences (latency percentiles, input
digest maps). All wall-clock values are tagged informal.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Iterable, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC = REPO_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

_COMMON = REPO_ROOT / "nodes" / "05_icde_query_engine" / "experiments" / "_common"
if str(_COMMON) not in sys.path:
    sys.path.insert(0, str(_COMMON))

import exp_common as ec  # noqa: E402  (canonical schema provider)

# Re-export the canonical schema builders so runners use one import surface.
utc_now_iso = ec.utc_now_iso
sha256_file = ec.sha256_file
sha256_bytes = ec.sha256_bytes
write_json = ec.write_json
write_text = ec.write_text
host_info = ec.host_info
build_output = ec.build_output
build_verification = ec.build_verification
check = ec.check

INFORMAL_NOTE = (
    "Wall-clock on this host is INFORMAL: parallel subagent experiments may run "
    "concurrently. Only counting/identity metrics (scorer calls, candidate "
    "evals, winner labels, cache hit/miss/evictions, bytes) are evidence. "
    "Formal timing is reserved for the dedicated 4090D target host."
)


def record_inputs(paths: Iterable[str | Path]) -> dict[str, str]:
    out: dict[str, str] = {}
    for p in paths:
        pp = Path(p)
        try:
            out[str(pp)] = sha256_file(pp)
        except FileNotFoundError:
            out[str(pp)] = "MISSING"
    return out


def percentile(sorted_values: Sequence[float], q: float) -> float:
    if not sorted_values:
        return float("nan")
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    pos = (q / 100.0) * (len(sorted_values) - 1)
    lo = int(pos)
    hi = min(lo + 1, len(sorted_values) - 1)
    frac = pos - lo
    return float(sorted_values[lo] * (1 - frac) + sorted_values[hi] * frac)


def latency_percentiles(samples: Sequence[float]) -> dict[str, float]:
    vals = sorted(float(x) for x in samples)
    return {
        "p50_informal_seconds": percentile(vals, 50),
        "p95_informal_seconds": percentile(vals, 95),
        "p99_informal_seconds": percentile(vals, 99),
        "n": len(vals),
    }
