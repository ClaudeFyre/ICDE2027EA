"""Dispatch one explicit finite experiment phase, one guarded job at a time."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from icde_prospective_20261107 import BASE,load,sha


def launch(graph,start,count,seeds,taus,deadline,tag):
    out=BASE/"confirmation"/tag
    if (out/"summary.json").exists():
        previous=load(out/"protocol_before_runs.json")
        if previous["script_sha256"]!=sha(ROOT/"scripts/icde_prospective_20261107.py"):
            raise ValueError("existing run has different scoring/execution code")
        print(f"verified completed {tag}",flush=True)
        return
    if out.exists():
        raise RuntimeError(f"incomplete attempt retained, explicit recovery needed: {tag}")
    task=f"icde-prospective-{tag.replace('_','-')}-20261107-v1"
    expected=(out/"summary.json").relative_to(ROOT).as_posix()
    command=[sys.executable,"scripts/safe_run.py","--task-id",task,"--profile","local16",
        "--max-runtime-minutes","12","--expected-output",expected,"--",sys.executable,
        "scripts/icde_prospective_20261107.py","run","--stage","confirmation","--graph",graph,
        "--start",str(start),"--count",str(count),"--seeds",seeds,"--taus",taus,
        "--deadline",repr(deadline),"--tag",tag]
    print(f"starting {tag}, queries={count}, seeds={seeds}, deadline={deadline:.6f}s",flush=True)
    completed=subprocess.run(command,cwd=ROOT,env={**os.environ,"PYTHONHASHSEED":"0"},capture_output=True,text=True)
    if completed.returncode:
        print(completed.stdout[-5000:],flush=True)
        print(completed.stderr[-5000:],flush=True)
        raise RuntimeError(f"guarded task failed: {tag}")
    summary=load(out/"summary.json")
    print(f"completed {tag}, cases={summary['complete_cases']}, measured={summary['elapsed_seconds']:.2f}s",flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("phase",choices=("primary","curves","sensitivity"))
    args=parser.parse_args()
    protocol=load(BASE/"confirmation_protocol.json")
    for name,expected in protocol["code_sha256"].items():
        if sha(ROOT/name)!=expected:
            raise ValueError(f"frozen numerical code changed: {name}")
    if args.phase=="primary":
        for graph in ("dw","enfr"):
            for shard in range(4):
                launch(graph,32+64*shard,64,"211,223,227","0.25",protocol["budgets"][graph]["primary_deadline_seconds"],f"primary_{graph}_s{shard}")
    elif args.phase=="curves":
        for graph in ("dw","enfr"):
            for index,deadline in enumerate(protocol["budgets"][graph]["budget_curve_seconds"]):
                launch(graph,32,64,"211","0.25",deadline,f"curve_{graph}_b{index}")
    else:
        for graph in ("dw","enfr"):
            launch(graph,32,64,"211","0.001,0.01,0.05,0.1,0.25,1.0",protocol["budgets"][graph]["primary_deadline_seconds"],f"sensitivity_{graph}")


if __name__=="__main__":main()
