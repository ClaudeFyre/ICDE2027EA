"""Scientific correctness checks independent of the historical pilot outputs."""
import unittest
from types import SimpleNamespace
import numpy as np

from icde_bc_pilot_20261109 import updated_compiled, exact_fast, matrices_for
from icde_grouped_exact_20261108 import compile_counts, solve_counts


def kernel():
    return SimpleNamespace(edge_indices=(11, 12, 20),
        incidence_positions=(np.array([0, 1]), np.array([], dtype=int),
                             np.array([2]), np.array([], dtype=int),
                             np.array([], dtype=int), np.array([], dtype=int)),
        lexical=np.array([.5, .5]), attribute=np.array([.5, .5]), attribute_weight=.8)


class CertificationTests(unittest.TestCase):
    def test_joint_changes_and_partial_cache_equal_full_recount(self):
        k = kernel()
        lo, hi = np.full(3, .65), np.ones(3)
        base = compile_counts(k, lo, hi)
        cache, partials = {}, {}
        matrices_for(base, cache)
        for lows, highs in [([.6, .6, .65], [1, 1, 1]),
                            ([.55, .55, .6], [.9, .9, .95]),
                            ([.8, .8, .9], [.95, .95, 1]),
                            ([0, 0, 0], [1, 1, 1]),
                            ([.65, .65, .65], [1, 1, 1])]:
            low, high = np.array(lows), np.array(highs)
            updated, compatible = updated_compiled(base, k, low, high, 32768)
            self.assertTrue(compatible)
            truth = solve_counts(compile_counts(k, low, high), 2)['uniform_winners']
            self.assertEqual(exact_fast(updated, 2, cache, base, partials), truth)
            self.assertEqual(exact_fast(updated, 2, {}), truth)

    def test_relation_change_splits_exchange_class(self):
        k = kernel()
        base = compile_counts(k, np.full(3, .65), np.ones(3))
        low, high = np.array([.5, .65, .65]), np.ones(3)
        changed, compatible = updated_compiled(base, k, low, high, 32768)
        self.assertFalse(compatible)
        self.assertGreater(len(changed['groups']), len(base['groups']))
        truth = solve_counts(compile_counts(k, low, high), 2)['uniform_winners']
        self.assertEqual(exact_fast(changed, 2, {}), truth)

    def test_scalar_uniform_winner_under_simultaneous_changes(self):
        k = kernel()
        for lo, hi in [(0., 1.), (.2, .4), (.8, .9)]:
            compiled = compile_counts(k, np.full(3, lo), np.full(3, hi))
            exact = solve_counts(compiled, 2)
            self.assertEqual(exact_fast(compiled, 2, {}), exact['uniform_winners'])


if __name__ == '__main__':
    unittest.main()
