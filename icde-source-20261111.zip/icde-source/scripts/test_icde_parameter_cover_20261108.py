"""Independent finite tests of coverage, projection and adaptive global checks."""
from fractions import Fraction as Q
from itertools import product
import unittest
import numpy as np

from icde_parameter_cover_20261108 import BinaryLookup, Cell, cover_status, partition
from icde_refinable_evidence_20261107 import Evidence


class CoverTests(unittest.TestCase):
    def test_lookup_matches_direct_boolean_enumeration(self):
        full = [int(((z >> 0) & 1) == ((z >> 2) & 1)) for z in range(16)]
        lookup = BinaryLookup(full, 4)
        self.assertEqual(lookup.active, (0, 2))
        for digits in product(range(3), repeat=2):
            allowed = [bits for bits in product((0, 1), repeat=2)
                       if all(d == 2 or b == d for b, d in zip(bits, digits))]
            truth = sum({1 << int(b[0] == b[1]) for b in allowed})
            index = sum(d * 3**e for e, d in enumerate(digits))
            self.assertEqual(int(lookup.table[index]), truth)

    def test_split_covers_parent_with_exact_midpoint(self):
        parent = Cell((.65, .65), (1., 1.))
        for cell in partition(parent, 4):
            self.assertTrue(all(a <= b for a, b in zip(cell.low, cell.high)))
        volume = lambda c: Q.from_float(c.high[0]) - Q.from_float(c.low[0])
        left, right, e = parent.split()
        self.assertEqual(e, 0)
        self.assertEqual(left.high[0], right.low[0])
        self.assertEqual(volume(left) + volume(right), volume(parent))

    def test_known_quantifier_gap_improves_after_partition(self):
        # fixed Bernoulli gate .6 guarantees w; uncertain switch selects w/d
        # in a second branch with complementary events. The main test here
        # independently integrates the projected ternary regions via midpoints.
        full = [0, 1, 1, 0]
        lookup = BinaryLookup(full, 2)
        cell = Cell((.75, .5), (1., .5))
        exact = lookup.population(cell)
        intervals = [[(0., a, 1), (a, b, 3), (b, 1., 2)] for a, b in zip(cell.low, cell.high)]
        means = [Q(0), Q(0)]
        for region in product(*intervals):
            mass = Q(1)
            u = []
            for a, b, _ in region:
                mass *= Q.from_float(b) - Q.from_float(a)
                u.append((a+b)/2)
            if not mass:
                continue
            mask = int(lookup.masks(np.asarray([u]), cell)[0])
            for w in (0, 1):
                means[w] += mass * (1 if mask == 1 << w else -1)
        self.assertEqual(tuple(means), exact)

    def test_same_answer_must_pass_every_cell(self):
        ev = Evidence(2)
        self.assertFalse(cover_status([[100, 0], [0, 100]], 100, ev)[1])
        self.assertTrue(cover_status([[100, 0], [100, 0]], 100, ev)[1])

    def test_constant_map_removes_all_coordinates(self):
        lookup = BinaryLookup([1] * 8, 3)
        self.assertEqual(lookup.r, 0)
        self.assertEqual(lookup.population(Cell((), ())), (Q(-1), Q(1)))
        self.assertTrue(np.all(lookup.masks(np.empty((5, 0)), Cell((), ())) == 2))


if __name__ == "__main__":
    unittest.main(verbosity=2)
