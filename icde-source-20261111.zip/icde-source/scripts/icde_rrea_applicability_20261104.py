"""Bounded, no-training RREA applicability capture. Launch through safe_run.

This is full-graph batched inference, not a local-execution or accuracy study.
All identities are persisted before world draws. A watchdog preserves the last
completed-world progress files and exits at the total deadline, even if a native
inference operation has not returned. No existing result directory is reused.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import threading
import time
import traceback


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def watchdog(output, finished, seconds, started):
    if not finished.wait(max(0.0, seconds - (time.monotonic() - started))):
        try:
            write_json(output / "deadline.json", {
                "status": "TOTAL_DEADLINE_EXCEEDED", "limit_seconds": seconds,
                "elapsed_seconds": time.monotonic() - started,
                "partial_results": "Each graph/progress.json contains completed worlds only.",
                "late_or_incomplete_world_is_not_evidence": True})
            print("Total deadline reached; completed-world partial results retained.", flush=True)
        finally:
            os._exit(124)


def resources(tf=None):
    result = {"process_rss_bytes": None, "tf_allocator_current_bytes": None,
              "tf_allocator_peak_bytes": None}
    try:
        import psutil
        result["process_rss_bytes"] = int(psutil.Process().memory_info().rss)
    except (ImportError, OSError):
        pass
    if tf is not None:
        try:
            memory = tf.config.experimental.get_memory_info("GPU:0")
            result["tf_allocator_current_bytes"] = int(memory["current"])
            result["tf_allocator_peak_bytes"] = int(memory["peak"])
        except (AttributeError, RuntimeError, ValueError):
            pass
    return result


def selected_sources(g, key, np):
    # Membership comes from the test split; target identity labels are unused.
    sources = set(int(pair[0]) for pair in g["pairs"]["test"])
    ordered = sorted(sources, key=lambda source: hashlib.sha256(
        f"ICDE-20261104|rrea-applicability|{key}|test|{g['entity_ids'][source]}".encode()
    ).hexdigest())
    if len(ordered) < 32:
        raise ValueError("fewer than 32 distinct test sources")
    return np.asarray(ordered[:32], dtype=np.int64)


def run_graph(output, key, ordinal, g, query_sources, checkpoint, worlds,
              global_started, seconds, np, core):
    graph_started = time.perf_counter()
    graph_out = output / key
    graph_out.mkdir()
    costs = {name: 0.0 for name in (
        "runtime_setup_seconds", "input_build_seconds", "model_build_load_seconds",
        "equivalence_audit_seconds", "reference_encode_seconds", "density_seconds",
        "point_retrieval_seconds", "draw_seconds", "world_input_build_seconds",
        "world_encode_seconds", "world_retrieval_seconds", "aggregation_seconds",
        "progress_serialization_seconds")}
    progress = {"status": "PREPARING", "graph": key, "completed_worlds": 0,
                "requested_worlds": worlds, "training_calls": 0,
                "scope": "full graph; no locality claim", "costs": costs}
    write_json(graph_out / "progress.json", progress)
    session = None
    try:
        t = time.perf_counter()
        tf, keras, session, official, dynamic, utils = core.setup(17)
        costs["runtime_setup_seconds"] += time.perf_counter() - t
        write_json(graph_out / "runtime.json", {
            "python": sys.version, "platform": platform.platform(),
            "tensorflow": tf.__version__, "keras": keras.__version__,
            "gpu": [str(device) for device in tf.config.list_physical_devices("GPU")],
            "numerical_placement": "G1 CPU sparse products/segment sums; other operations may use GPU",
            "model_seed": 17, "world_seed_sequence_entropy": [107, ordinal]})
        from www_quality_recovery_v13_worker import matrices as author_matrices

        t = time.perf_counter()
        fast = core.GraphInputs(g)
        full = fast.build()
        costs["input_build_seconds"] += time.perf_counter() - t
        t = time.perf_counter()
        _, model = core.build_model(g, full, dynamic)
        frozen_weights = core.weights(checkpoint)
        model.set_weights(frozen_weights)
        costs["model_build_load_seconds"] += time.perf_counter() - t
        t = time.perf_counter()
        point_raw = core.embed(model, full)
        costs["reference_encode_seconds"] += time.perf_counter() - t

        # Recheck the original/full matrix and forward contracts without training.
        t = time.perf_counter()
        original_full, _ = author_matrices(g, utils)
        if not all(np.array_equal(a, b) for a, b in zip(full, original_full)):
            raise ValueError("original/full matrix equivalence failed")
        _, reference_model = core.build_model(g, original_full, official)
        reference_model.set_weights(frozen_weights)
        reference_raw = core.embed(reference_model, original_full)
        full_error = float(np.max(np.abs(point_raw - reference_raw)))
        if full_error > 1e-6:
            raise ValueError(f"original/dynamic full forward error {full_error}")
        costs["equivalence_audit_seconds"] += time.perf_counter() - t

        retrieval = core.Retrieval(tf, session)
        point_vectors = core.normalized(point_raw)
        correction, costs["density_seconds"] = retrieval.density(point_vectors, g)
        t = time.perf_counter()
        point_scores = retrieval.scores(point_vectors, query_sources, g["targets"], correction)
        point_winner = np.argmax(point_scores, axis=1)
        point_top = np.partition(point_scores, -2, axis=1)[:, -2:]
        point_margin = point_top.max(1) - point_top.min(1)
        costs["point_retrieval_seconds"] += time.perf_counter() - t
        k = len(g["targets"])
        if k != 15000 or len(query_sources) != 32:
            raise ValueError("the frozen 32-query/full15000-candidate contract changed")
        optional = int((~fast.pinned).sum())
        audit = {"full_matrices_exact": True, "full_forward_max_abs_error": full_error,
                 "sampled_matrix_exact": None, "sampled_forward_max_abs_error": None,
                 "restore_max_abs_error": None, "restore_winner_changes": None}
        write_json(graph_out / "before_draws.json", {
            "status": "READY_BEFORE_ANY_WORLD_DRAW", "queries": len(query_sources),
            "candidates": k, "pinned_edges": int(fast.pinned.sum()),
            "optional_edges": optional, "full_graph_edges": len(fast.pinned),
            "fixed_density_sha256": hashlib.sha256(correction.tobytes()).hexdigest(),
            "point_winner": point_winner.tolist(), "point_score_margin": point_margin.tolist(),
            "audit": audit, "costs_before_draws": dict(costs),
            "full_scope_tv": {
                "half_width": 0.001, "optional_coordinates": optional,
                "product_bound_expression": "1-(1-d)^m, d=max(q-l,u-q), m=optional_edges",
                "product_numeric_approximation": -math.expm1(optional * math.log1p(-0.001)),
                "conservative_bound_used": 1.0,
                "meaning": "A TV upper bound, not exact TV; trivial bound 1 is numerically safe.",
                "robust_certificate_by_this_condition": False},
            "external_labels_evaluated": False})

        rng = np.random.default_rng(np.random.SeedSequence([107, ordinal]))
        counts = np.zeros((32, k), dtype=np.uint16)
        score_sum = np.zeros((32, k), dtype=np.float64)
        first_step = np.zeros(32, dtype=np.int32)
        first_winner = np.full(32, -1, dtype=np.int32)
        trace, margin_trace = [], []
        stream_hash = hashlib.sha256()
        peak_rss = 0
        n = 0
        for n_next in range(1, worlds + 1):
            if time.monotonic() - global_started >= seconds:
                raise TimeoutError("deadline before next world")
            t = time.perf_counter()
            mask = fast.mask(rng)  # Draws all triple coordinates, then pins fixed edges.
            stream_hash.update(mask.tobytes())
            costs["draw_seconds"] += time.perf_counter() - t
            t = time.perf_counter()
            sampled = fast.build(mask)
            costs["world_input_build_seconds"] += time.perf_counter() - t
            t = time.perf_counter()
            vectors_raw = core.embed(model, sampled)  # Exactly one shared forward/world.
            costs["world_encode_seconds"] += time.perf_counter() - t
            if n_next == 1:
                t = time.perf_counter()
                slow, _ = author_matrices(g, utils, mask)
                if not all(np.array_equal(a, b) for a, b in zip(sampled, slow)):
                    raise ValueError("sampled matrix equivalence failed")
                _, sample_reference = core.build_model(g, slow, official)
                sample_reference.set_weights(frozen_weights)
                sample_raw = core.embed(sample_reference, slow)
                sample_error = float(np.max(np.abs(vectors_raw - sample_raw)))
                audit["sampled_matrix_exact"] = True
                audit["sampled_forward_max_abs_error"] = sample_error
                if sample_error > 1e-6:
                    raise ValueError(f"sampled original/dynamic forward error {sample_error}")
                costs["equivalence_audit_seconds"] += time.perf_counter() - t
            t = time.perf_counter()
            scores = retrieval.scores(core.normalized(vectors_raw), query_sources,
                                      g["targets"], correction)
            if not np.isfinite(scores).all():
                raise ValueError("nonfinite world scores")
            costs["world_retrieval_seconds"] += time.perf_counter() - t
            # Late native operations never produce an accepted certificate.
            if time.monotonic() - global_started >= seconds:
                raise TimeoutError("deadline after world; late world excluded")
            t = time.perf_counter()
            winners = np.argmax(scores, axis=1)
            top = np.partition(scores, -2, axis=1)[:, -2:]
            margin_trace.append(top.max(1) - top.min(1))
            trace.append(winners.astype(np.int32))
            counts[np.arange(32), winners] += 1
            score_sum += scores
            n = n_next
            leader = np.argmax(counts, axis=1)
            top_counts = np.partition(counts, -2, axis=1)[:, -2:].astype(np.float64)
            gap = (top_counts.max(1) - top_counts.min(1)) / n
            radius = core.radius(n, k)
            if n % 32 == 0 or n == worlds:
                newly = (first_step == 0) & (gap > radius)
                first_step[newly] = n
                first_winner[newly] = leader[newly]
            costs["aggregation_seconds"] += time.perf_counter() - t
            resource = resources(tf)
            peak_rss = max(peak_rss, resource["process_rss_bytes"] or 0)
            progress.update({
                "status": "RUNNING", "completed_worlds": n,
                "nominal_certificates": int(np.sum(first_step > 0)),
                "first_certificate_world": first_step.tolist(),
                "certified_winner_position": first_winner.tolist(),
                "modal_winner_position": leader.tolist(),
                "modal_frequency_gap": gap.tolist(), "all_pairs_radius": radius,
                "point_winner_position": point_winner.tolist(),
                "point_score_margin": point_margin.tolist(),
                "winner_trace": [row.tolist() for row in trace],
                "world_score_margin_trace": [row.tolist() for row in margin_trace],
                "world_mask_stream_sha256": stream_hash.hexdigest(),
                "rng_coordinate_draws": n * len(fast.pinned),
                "effective_optional_coordinate_draws": n * optional,
                "world_encoder_calls": n, "diagnostic_reference_encoder_calls": 2,
                "point_encoder_calls": 1, "peak_observed_process_rss_bytes": peak_rss,
                "resources": resource, "audit": dict(audit),
                "elapsed_total_seconds": time.monotonic() - global_started})
            t = time.perf_counter()
            write_json(graph_out / "progress.json", progress)
            costs["progress_serialization_seconds"] += time.perf_counter() - t
            print(json.dumps({"graph": key, "worlds": n,
                              "certified": progress["nominal_certificates"]}), flush=True)

        t = time.perf_counter()
        restored = core.embed(model, full)
        audit["restore_max_abs_error"] = float(np.max(np.abs(restored - point_raw)))
        restored_scores = retrieval.scores(core.normalized(restored), query_sources,
                                          g["targets"], correction)
        audit["restore_winner_changes"] = int(np.sum(
            np.argmax(restored_scores, axis=1) != point_winner))
        if audit["restore_max_abs_error"] > 1e-6 or audit["restore_winner_changes"]:
            raise ValueError("full-graph restore audit failed")
        if not all(np.array_equal(a, b) for a, b in zip(frozen_weights, model.get_weights())):
            raise ValueError("model weights changed without training")
        costs["equivalence_audit_seconds"] += time.perf_counter() - t
        with (graph_out / "categorical_capture.npz").open("xb") as handle:
            np.savez_compressed(handle, counts=counts, winners=np.asarray(trace),
                                mean_scores=score_sum / n, sources=query_sources,
                                target_order=g["targets"], first_certificate=first_step,
                                first_winner=first_winner)
        progress.update({"status": "COMPLETE", "audit": dict(audit),
                         "weights_unchanged": True, "restore_encoder_calls": 1,
                         "graph_total_seconds": time.perf_counter() - graph_started,
                         "timed_stage_sum_seconds": sum(costs.values())})
        write_json(graph_out / "progress.json", progress)
        return progress
    except BaseException as error:
        progress.update({"status": "PARTIAL_OR_FAILED", "error_type": type(error).__name__,
                         "error": str(error), "elapsed_total_seconds": time.monotonic() - global_started})
        write_json(graph_out / "progress.json", progress)
        raise
    finally:
        if session is not None:
            session.close()


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--worlds", type=int, default=64)
    parser.add_argument("--seconds", type=float, default=900.0)
    args = parser.parse_args()
    if not 1 <= args.worlds <= 64 or not 0 < args.seconds <= 900:
        parser.error("worlds must be in [1,64], seconds in (0,900]")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    finished = threading.Event()
    threading.Thread(target=watchdog, args=(output, finished, args.seconds, started),
                     daemon=True).start()
    try:
        import numpy as np
        import g1_value_core as core
        t = time.perf_counter()
        bundle = core.verify_bundle()
        configuration = core.load(core.ROOT / "papers/www/quality_recovery_v13_config.json")
        graphs, identities = {}, {}
        for key in ("dw", "enfr"):
            g = core.graph(key)
            sources = selected_sources(g, key, np)
            checkpoint = core.ROOT / (
                "nodes/04_www_distributional/results/quality_recovery_v13/"
                f"windows_attempt1/training/{key}_s17/checkpoint.weights.npz")
            checkpoint_hash = core.sha(checkpoint)
            if checkpoint_hash != core.load(checkpoint.parent / "training_complete.json")["checkpoint_sha256"]:
                raise ValueError("checkpoint identity differs from frozen training record")
            data_path = core.ROOT / configuration["datasets"][key]
            data_hashes = {path.name: core.sha(path) for path in sorted(data_path.iterdir())
                           if path.is_file()}
            gate = core.load(core.ROOT / (
                "nodes/02_sampling_diagnosis/results/pw_value_20261028/attempt3/"
                f"g0/{key}/host_input_model_gate.json"))
            if (gate["status"] != "G0_SCOPED_PASS" or checkpoint_hash != gate["checkpoint_sha256"]
                    or data_hashes != gate["input_hashes"]):
                raise ValueError("current checkpoint/data differ from scoped G1 gate")
            graphs[key] = (g, sources, checkpoint)
            identities[key] = {"checkpoint": str(checkpoint), "checkpoint_sha256": checkpoint_hash,
                "data_directory": str(data_path), "data_sha256": data_hashes,
                "query_source_indices": sources.tolist(),
                "query_source_ids": [g["entity_ids"][source] for source in sources],
                "target_order_sha256": hashlib.sha256(g["targets"].tobytes()).hexdigest(),
                "statistics": g["statistics"]}
        source_paths = [Path(__file__), core.ROOT / "scripts/g1_value_core.py",
                        core.ROOT / "scripts/www_quality_recovery_v13_common.py",
                        core.ROOT / "scripts/www_quality_recovery_v13_worker.py",
                        core.ROOT / "papers/www/quality_recovery_v13_config.json"]
        vendor_hashes = {str(path.relative_to(core.ROOT)): core.sha(path)
                         for path in sorted(core.VENDOR.rglob("*"))
                         if path.is_file() and "__pycache__" not in path.parts
                         and path.suffix != ".pyc"}
        write_json(output / "protocol_before_draws.json", {
            "format": "icde-rrea-applicability-20261104-v1", "status": "FROZEN_BEFORE_DRAWS",
            "graphs": identities, "bundle": bundle, "vendor_sha256": vendor_hashes,
            "code_sha256": {str(path.relative_to(core.ROOT)): core.sha(path) for path in source_paths},
            "worlds_per_graph": args.worlds, "queries_per_graph": 32,
            "world_seed": 107, "graph_seed_derivation": "SeedSequence([107, graph_ordinal]); dw=0,enfr=1",
            "world_law": "G1 pinned triples always present; all other triples independent Bernoulli(0.9)",
            "query_selection": "first32 test source IDs ordered by sha256(ICDE-20261104|rrea-applicability|graph|test|source_id)",
            "scorer": "600d RREA; frozen full-pool target-density correction; deterministic target-position ties",
            "numerical_contract": "G1 dynamic relation shape; CPU sparse products/segment sums",
            "certificate": {"delta_per_query": 0.05, "rho": 64, "union": "all unordered pairs",
                            "looks": "every32 worlds and final requested prefix", "family_wise_claim": False},
            "training": False, "accuracy_evaluation": False, "real_probability_calibration": False,
            "new_source_blind_confirmation": False, "local_scope_claim": False,
            "timing_interpretation": "fixed-cap applicability capture, not measured adaptive stopping savings",
            "total_deadline_seconds": args.seconds, "identity_freeze_seconds": time.perf_counter() - t})
        summaries = {}
        for ordinal, key in enumerate(("dw", "enfr")):
            g, sources, checkpoint = graphs[key]
            result = run_graph(output, key, ordinal, g, sources, checkpoint, args.worlds,
                               started, args.seconds, np, core)
            summaries[key] = {"completed_worlds": result["completed_worlds"],
                              "nominal_certificates": result["nominal_certificates"],
                              "progress": f"{key}/progress.json"}
        write_json(output / "summary.json", {"status": "COMPLETE", "graphs": summaries,
            "elapsed_seconds": time.monotonic() - started, "training_calls": 0,
            "interpretation": "full-graph batched applicability only; no new accuracy or deployment claim"})
    except BaseException as error:
        write_json(output / "failure.json", {"status": "FAILED_OR_PARTIAL", "error": str(error),
            "error_type": type(error).__name__, "traceback": traceback.format_exc(),
            "elapsed_seconds": time.monotonic() - started,
            "partial_results": "Consult existing graph/progress.json files; only completed prefixes count."})
        raise
    finally:
        finished.set()


if __name__ == "__main__":
    main()
