"""Factor bounds versus exact joint probabilities on a complete synthetic map."""
from itertools import product
import unittest
import numpy as np
from icde_factor_partial_20261108 import execute,FactorRegion,probability_bounds
from icde_partial_count_20261108 import CountOracle
from icde_grouped_exact_20261108 import compile_counts,solve_counts
from test_icde_partial_count_20261108 import competing


class FactorTests(unittest.TestCase):
    def test_interval_relaxation_contains_all_joint_probabilities(self):
        model = competing()
        low,high = np.full(6,.25),np.full(6,.75)
        oracle = CountOracle(model,low,high)
        oracle.prepare_probabilities()
        compiled = compile_counts(model,low,high)
        exact = solve_counts(compiled,3)
        nodes = []
        for serial,state in enumerate(product(*(range(n) for n in oracle.shape))):
            mask = 1 << int(compiled["winners"][state])
            nodes.append(FactorRegion(state,state,mask,oracle.region_vectors(state,state),serial,0))
        pa,pb = (0,)*len(oracle.shape),tuple(n-1 for n in oracle.shape)
        l,u = probability_bounds(nodes,pa,pb,3,oracle.denominator)
        for w in range(3):
            self.assertLessEqual(l[w],min(map(int,exact["numerators"][w].flat)))
            self.assertGreaterEqual(u[w],max(map(int,exact["numerators"][w].flat)))
        for t in product(*(range(n) for n in oracle.shape)):
            l,u = probability_bounds(nodes,t,t,3,oracle.denominator)
            self.assertEqual(l,u)
            self.assertEqual(l,[int(v[t]) for v in exact["numerators"]])

    def test_completion_and_parameter_witnesses_match_reference(self):
        model = competing()
        low,high = np.full(6,.25),np.full(6,.75)
        compiled = compile_counts(model,low,high)
        exact = solve_counts(compiled,3)
        for policy in ("factor_mass","factor_certificate"):
            row = execute(model,low,high,policy,{"state_cap":32768,"max_splits":1000,"max_parameter_splits":1000})
            self.assertEqual(row["status"],"stable" if exact["uniform_winners"] else "nonuniform")
            self.assertEqual(row["probability_states_allocated"],0)
            coverage = np.zeros(compiled["shape"],dtype=np.int16)
            for cell in row["parameter_cells"]:
                coverage[tuple(slice(a,b+1) for a,b in zip(cell["low"],cell["high"]))] += 1
            self.assertTrue(np.all(coverage==1))
            for proof in row["witnesses"]:
                t = tuple(proof["high_endpoint_counts"])
                gap = int(exact["numerators"][proof["candidate"]][t])-int(exact["numerators"][proof["competitor"]][t])
                self.assertLessEqual(gap,int(proof["upper_gap_numerator"]))
                self.assertLessEqual(int(proof["upper_gap_numerator"]),0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
