"""Small-scope binary-query parameter-cover prototype.

All cover cells must certify the SAME answer at a shared input prefix.
Intersection-union testing, abstract interpretation, and exact Boolean lookup
are standard ingredients, not claimed here as novel general methods.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import product
import math
import numpy as np

from icde_refinable_evidence_20261107 import Evidence, exact_mask


@dataclass(frozen=True)
class Cell:
    low: tuple
    high: tuple
    path: str = ""

    def split(self):
        if not self.low or max(h - l for l, h in zip(self.low, self.high)) <= 0:
            raise ValueError("cell has no splittable coordinate")
        e = max(range(len(self.low)), key=lambda j: (self.high[j] - self.low[j], -j))
        middle = float((self.low[e] + self.high[e]) / 2)
        if not self.low[e] < middle < self.high[e]:
            raise ValueError("no representable interior midpoint")
        hi, lo = list(self.high), list(self.low)
        hi[e] = lo[e] = middle
        return (Cell(self.low, tuple(hi), self.path + "0"),
                Cell(tuple(lo), self.high, self.path + "1"), e)


def partition(root, depth):
    cells = [root]
    for _ in range(depth):
        cells = [child for cell in cells for child in cell.split()[:2]]
    return cells


class BinaryLookup:
    def __init__(self, full_winners, full_dimension):
        winners = tuple(map(int, full_winners))
        if len(winners) != 1 << full_dimension or not set(winners) <= {0, 1}:
            raise ValueError("need a complete binary-winner map")
        self.full_dimension = full_dimension
        self.active = tuple(e for e in range(full_dimension)
                            if any(winners[z] != winners[z ^ (1 << e)] for z in range(len(winners))))
        self.r = len(self.active)
        self.winners = tuple(winners[sum(((z >> j) & 1) << e for j, e in enumerate(self.active))]
                             for z in range(1 << self.r))
        for z, value in enumerate(winners):
            projected = sum(((z >> e) & 1) << j for j, e in enumerate(self.active))
            if self.winners[projected] != value:
                raise AssertionError("essential-variable projection failed")
        self.powers = 3 ** np.arange(self.r, dtype=np.int64)
        table = []
        for code in range(3 ** self.r):
            digits = [(code // 3**e) % 3 for e in range(self.r)]
            low = np.asarray([d == 1 for d in digits], dtype=np.bool_)
            high = np.asarray([d != 0 for d in digits], dtype=np.bool_)
            table.append(exact_mask(self.winners, low, high))
        self.table = np.asarray(table, dtype=np.uint8)

    def project_cell(self, low, high):
        return Cell(tuple(float(low[e]) for e in self.active), tuple(float(high[e]) for e in self.active))

    def masks(self, uniforms, cell):
        if uniforms.shape[1] != self.r:
            raise ValueError("uniform dimension mismatch")
        lower = uniforms < np.asarray(cell.low)
        upper = uniforms < np.asarray(cell.high)
        codes = (lower.astype(np.int64) + 2 * (upper & ~lower).astype(np.int64)) @ self.powers
        return self.table[codes]

    def population(self, cell):
        # Exact dyadic integer weights for each uniform-space region.
        weights, denominator = [], 1
        for low, high in zip(cell.low, cell.high):
            l, h = Q.from_float(low), Q.from_float(high)
            den = math.lcm(l.denominator, h.denominator)
            li, hi = int(l * den), int(h * den)
            weights.append((den - hi, li, hi - li))
            denominator *= den
        must = [0, 0]
        total = 0
        for code, digits in enumerate(product(range(3), repeat=self.r)):
            # product's first coordinate varies slowest; encode explicitly.
            mass = math.prod(weights[e][d] for e, d in enumerate(digits))
            if mass == 0:
                continue
            index = sum(d * 3**e for e, d in enumerate(digits))
            mask = int(self.table[index])
            if mask in (1, 2):
                must[mask.bit_length() - 1] += mass
            total += mass
        if total != denominator:
            raise AssertionError("exact uniform-region weights fail to sum to one")
        return tuple(Q(2 * count - denominator, denominator) for count in must)


def cover_status(counter, n, evidence):
    """Binary same-prefix case: hardest cell is the smallest singleton count.

    The standard fixed-cover controls use exactly this same optimization and
    threshold K/delta. There is NO extra factor equal to the number of cells.
    """
    minimum = [min(counts[w] for counts in counter) for w in (0, 1)]
    w = max((0, 1), key=lambda c: (minimum[c], -c))
    a = minimum[w]
    value = evidence.wealth(a, n - a)
    return w, value >= Q(2) / evidence.delta, minimum


def execute(lookup, root, uniforms, policy, settings):
    import time
    started = time.perf_counter()
    evidence = Evidence(2, Q(settings["delta_exact"]))
    cells = partition(root, int(policy.split("_")[-1])) if policy.startswith("fixed_") else [root]
    counter = [[0, 0] for _ in cells]
    nprev, evaluations, splits, winner = 0, 0, [], None
    trace = []
    for n in settings["looks"]:
        for j, cell in enumerate(cells):
            masks = lookup.masks(uniforms[nprev:n], cell)
            counter[j][0] += int(np.sum(masks == 1))
            counter[j][1] += int(np.sum(masks == 2))
            evaluations += n - nprev
        w, good, minimum = cover_status(counter, n, evidence)
        if policy == "adaptive" and not good:
            for _ in range(settings["splits_per_look"]):
                available = [j for j, cell in enumerate(cells) if len(cell.path) < settings["max_depth"]]
                if len(cells) >= settings["max_leaves"] or not available:
                    break
                j = min(available, key=lambda j: (counter[j][w], cells[j].path))
                parent = cells[j]
                left, right, coordinate = parent.split()
                children = []
                for child in (left, right):
                    masks = lookup.masks(uniforms[:n], child)
                    children.append([int(np.sum(masks == 1)), int(np.sum(masks == 2))])
                    evaluations += n
                splits.append({"n": n, "parent": parent.path, "coordinate": coordinate,
                               "parent_low": list(parent.low), "parent_high": list(parent.high),
                               "middle": left.high[coordinate]})
                cells[j:j+1] = [left, right]
                counter[j:j+1] = children
                w, good, minimum = cover_status(counter, n, evidence)
                if good:
                    break
        trace.append({"n": n, "leaves": len(cells), "candidate": w,
                      "minimum_singleton_counts": minimum, "certified": good})
        if good:
            winner = w
            break
        nprev = n
    return {"policy": policy, "winner": winner, "worlds": n, "leaves": len(cells),
            "sample_cell_evaluations": evaluations, "compute_seconds": time.perf_counter() - started,
            "scalar_evaluations": evidence.scalar_evaluations,
            "trace": trace, "splits": splits,
            "final_cells": [{"low": list(c.low), "high": list(c.high), "path": c.path} for c in cells]}
