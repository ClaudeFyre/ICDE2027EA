"""Meaningful deadline, restoration and non-budget-error propagation tests."""
import time
import unittest
from icde_portfolio_budget_20261108 import budgeted_call


class BudgetTests(unittest.TestCase):
    def test_early_valid_result_and_original_clock_restored(self):
        original = time.perf_counter
        result = budgeted_call(lambda:(time.perf_counter(),{"proof":True})[1],1.)
        self.assertEqual(result["raw"],{"proof":True})
        self.assertFalse(result["timed_out"])
        self.assertIs(time.perf_counter,original)

    def test_existing_clock_checkpoint_aborts_work(self):
        original = time.perf_counter
        def loop():
            while True:
                time.perf_counter()
        result = budgeted_call(loop,.001)
        self.assertTrue(result["timed_out"])
        self.assertIsNone(result["raw"])
        self.assertGreater(result["clock_checkpoints"],0)
        self.assertIs(time.perf_counter,original)

    def test_late_native_like_result_is_discarded(self):
        def no_checkpoint():
            time.sleep(.004)
            return {"proof":True}
        result = budgeted_call(no_checkpoint,.001)
        self.assertTrue(result["timed_out"])
        self.assertIsNone(result["raw"])
        self.assertGreater(result["overrun_seconds"],0)

    def test_real_solver_errors_are_not_hidden(self):
        original = time.perf_counter
        def broken():
            raise ValueError("real bug")
        with self.assertRaisesRegex(ValueError,"real bug"):
            budgeted_call(broken,1.)
        self.assertIs(time.perf_counter,original)


if __name__=="__main__":
    unittest.main(verbosity=2)
