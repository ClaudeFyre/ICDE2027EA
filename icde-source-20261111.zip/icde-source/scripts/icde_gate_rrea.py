"""Frozen 256-primary/512-diagnostic RREA inference and policy-drift gate.

Mao et al., Relational Reflection Entity Alignment, CIKM 2020,
doi:10.1145/3340531.3412001. Source-backed G1 interfaces and seed17 weights
are reused without training. One full-graph forward serves all 32 queries per
world. This fixed-cap capture does not measure adaptive encoder savings.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import threading
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
LOOKS = (32, 64, 128, 256, 512)
RULES = ("normal", "ppr_uniform_jain", "empirical_bernstein")
FAMILIES = ("A_full_edge_box", "B_maintenance128")
MAINTENANCE_SALT = "icde-gate-maintenance-20261104"
PRIOR64 = ROOT / "nodes/09_vldb_query_certification/results/icde_rrea_applicability_20261104_attempt1"


def atomic_npz(path, np, **arrays):
    path = Path(path)
    if path.exists():
        raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("xb") as handle:
        np.savez_compressed(handle, **arrays)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def maintenance_coordinates(pinned, graph, np):
    optional = np.flatnonzero(~pinned)
    if len(optional) < 128:
        raise ValueError("the maintenance family requires 128 optional coordinates")
    selected = sorted((int(index) for index in optional), key=lambda index: (
        hashlib.sha256(f"{MAINTENANCE_SALT}|{graph}|{index}".encode("utf-8")).digest(), index))[:128]
    return optional, np.asarray(selected, dtype=np.int64)


def new_state():
    return {"first_world": [0] * 32, "candidate_position": [None] * 32,
            "elapsed_seconds": [None] * 32}


def freeze_first(state, flags, leaders, n, elapsed):
    for index, flag in enumerate(flags):
        if flag and state["first_world"][index] == 0:
            state["first_world"][index] = n
            state["candidate_position"][index] = int(leaders[index])
            state["elapsed_seconds"][index] = elapsed


def state_counts(nominal, robust):
    return {"nominal": {rule: sum(value > 0 for value in state["first_world"])
                        for rule, state in nominal.items()},
            "robust": {rule: {family: sum(value > 0 for value in state["first_world"])
                              for family, state in families.items()}
                       for rule, families in robust.items()}}


def inference_snapshot(counts, n, inference, np):
    leaders = np.argmax(counts, axis=1)
    lower = {"normal": [], "empirical_bernstein": []}
    nominal_flags = {rule: [] for rule in RULES}
    ppr_diagnostics = []
    timing = {"normal_inference_seconds": 0., "ppr_inference_seconds": 0., "eb_inference_seconds": 0.}
    for row_index, row in enumerate(counts):
        t = time.perf_counter()
        normal = inference.numerical_gap_details(row, n, .05, {"name": "normal_mixture", "rho": 64})
        timing["normal_inference_seconds"] += time.perf_counter() - t
        t = time.perf_counter()
        bernstein = inference.numerical_gap_details(row, n, .05,
            {"name": "empirical_bernstein", "checkpoints": list(LOOKS)})
        timing["eb_inference_seconds"] += time.perf_counter() - t
        t = time.perf_counter()
        ppr = inference.ppr_details(row, n, .05, prior="uniform", allocation="jain_mode")
        timing["ppr_inference_seconds"] += time.perf_counter() - t
        if not (normal["leader_index"] == bernstein["leader_index"] == ppr["empirical_leader_index"]
                == int(leaders[row_index])):
            raise ValueError("inference rules disagree on deterministic empirical leader")
        lower["normal"].append(normal["lower_gap"])
        lower["empirical_bernstein"].append(bernstein["lower_gap"])
        nominal_flags["normal"].append(normal["lower_gap"] > 0)
        nominal_flags["empirical_bernstein"].append(bernstein["lower_gap"] > 0)
        nominal_flags["ppr_uniform_jain"].append(ppr["certified"])
        ppr_diagnostics.append({key: ppr[key] for key in (
            "leader_count", "competitor_count", "pair_samples", "alpha_exact", "log_ppr_at_half_diagnostic")})
    return leaders, lower, nominal_flags, ppr_diagnostics, timing


def prepare_protocol(output, worlds, seconds, np, core, prior, box_helpers):
    clipped_box, conservative_scope_tv = box_helpers
    started = time.perf_counter()
    bundle = core.verify_bundle()
    configuration = core.load(ROOT / "papers/www/quality_recovery_v13_config.json")
    old_protocol_path = PRIOR64 / "protocol_before_draws.json"
    old_protocol = core.load(old_protocol_path) if old_protocol_path.is_file() else None
    graphs, identities = {}, {}
    guarded = {Path(__file__).resolve(), ROOT / "scripts/icde_gate_inference.py",
               ROOT / "scripts/icde_rrea_applicability_20261104.py", ROOT / "scripts/g1_value_core.py",
               ROOT / "scripts/www_quality_recovery_v13_common.py", ROOT / "scripts/www_quality_recovery_v13_worker.py",
               ROOT / "papers/www/quality_recovery_v13_config.json", ROOT / "papers/www/quality_recovery_v13_bundle_r2.json"}
    guarded.update((ROOT / "scripts").glob("*vldb*.py"))
    guarded.update((ROOT / "src/pkgea").rglob("*.py"))
    for ordinal, key in enumerate(("dw", "enfr")):
        g = core.graph(key)
        sources = prior.selected_sources(g, key, np)
        checkpoint = ROOT / ("nodes/04_www_distributional/results/quality_recovery_v13/"
                             f"windows_attempt1/training/{key}_s17/checkpoint.weights.npz")
        checkpoint_sha = core.sha(checkpoint)
        if checkpoint_sha != core.load(checkpoint.parent / "training_complete.json")["checkpoint_sha256"]:
            raise ValueError("seed17 checkpoint differs from its frozen training record")
        data_path = ROOT / configuration["datasets"][key]
        data_hashes = {path.name: core.sha(path) for path in sorted(data_path.iterdir()) if path.is_file()}
        gate = core.load(ROOT / ("nodes/02_sampling_diagnosis/results/pw_value_20261028/attempt3/"
                                 f"g0/{key}/host_input_model_gate.json"))
        if (gate["status"] != "G0_SCOPED_PASS" or checkpoint_sha != gate["checkpoint_sha256"]
                or data_hashes != gate["input_hashes"]):
            raise ValueError("checkpoint/data differ from the validated G1 scoped inputs")
        fast = core.GraphInputs(g)
        optional, maintenance = maintenance_coordinates(fast.pinned, key, np)
        q_optional = np.full(len(optional), .9, dtype=np.float64)
        low_a, high_a = clipped_box(q_optional, .001)
        epsilon_a, audit_a = conservative_scope_tv(q_optional, low_a, high_a)
        q_batch = np.full(128, .9, dtype=np.float64)
        low_b, high_b = clipped_box(q_batch, .001)
        epsilon_b, audit_b = conservative_scope_tv(q_batch, low_b, high_b)
        if not 0 < epsilon_b < .5:
            raise ValueError("maintenance bound is unexpectedly vacuous or invalid")
        graph_out = output / key
        graph_out.mkdir()
        mask_path = graph_out / "law_masks_before_draws.npz"
        atomic_npz(mask_path, np, pinned=fast.pinned, optional_original_indices=optional,
                   maintenance_original_indices=maintenance, nominal_optional=q_optional,
                   full_box_low_optional=low_a, full_box_high_optional=high_a,
                   maintenance_low=low_b, maintenance_high=high_b)
        family = {
            FAMILIES[0]: {"varied_coordinates": int(len(optional)), "half_width": .001,
                "definition": "All optional original triples have independent parameters in the outward box; pinned triples stay at probability1.",
                "scope_epsilon_upper": epsilon_a, "bound_audit": audit_a},
            FAMILIES[1]: {"varied_coordinates": 128, "half_width": .001,
                "definition": "Only the frozen128 optional triple coordinates vary independently in the outward box; every other optional coordinate stays at0.9 and pinned triples at1.",
                "coordinate_selection": "first128 optional zero-based original triple row indices by SHA256(salt|graph_key|index), digest then index ties",
                "selection_salt": MAINTENANCE_SALT, "graph_key": key,
                "original_triple_indices": maintenance.tolist(), "scope_epsilon_upper": epsilon_b,
                "bound_audit": audit_b,
                "interpretation": "controlled retention-policy maintenance; not inferred real-fact uncertainty"}}
        old_reference = None
        if old_protocol is not None:
            old_identity = old_protocol["graphs"][key]
            if (old_identity["checkpoint_sha256"] != checkpoint_sha
                    or old_identity["data_sha256"] != data_hashes
                    or old_identity["query_source_indices"] != sources.tolist()
                    or old_identity["target_order_sha256"] != hashlib.sha256(g["targets"].tobytes()).hexdigest()
                    or old_protocol["world_seed"] != 107):
                raise ValueError("old64 protocol does not describe the same query/scorer/stream prefix")
            old_path = PRIOR64 / key / "progress.json"
            old = core.load(old_path)
            if old["status"] != "COMPLETE" or old["completed_worlds"] != 64:
                raise ValueError("old64 reference is incomplete")
            old_reference = {"protocol_path": str(old_protocol_path.relative_to(ROOT)),
                "protocol_sha256": core.sha(old_protocol_path), "progress_path": str(old_path.relative_to(ROOT)),
                "progress_sha256": core.sha(old_path), "mask_prefix_sha256": old["world_mask_stream_sha256"],
                "winner_trace": old["winner_trace"]}
            guarded.update((old_protocol_path, old_path))
        guarded.add(checkpoint)
        guarded.update(path for path in data_path.iterdir() if path.is_file())
        identity = {"checkpoint": str(checkpoint.relative_to(ROOT)), "checkpoint_sha256": checkpoint_sha,
            "data_directory": str(data_path.relative_to(ROOT)), "data_sha256": data_hashes,
            "query_source_indices": sources.tolist(),
            "query_source_ids": [g["entity_ids"][source] for source in sources],
            "target_order_sha256": hashlib.sha256(g["targets"].tobytes()).hexdigest(),
            "statistics": g["statistics"], "pinned_edges": int(fast.pinned.sum()),
            "optional_edges": int(len(optional)), "law_masks_path": str(mask_path.relative_to(output)),
            "law_masks_sha256": core.sha(mask_path), "families": family,
            "old64_reference": old_reference}
        identities[key] = identity
        graphs[key] = (g, sources, checkpoint, fast, family, old_reference)
    vendor_hashes = {str(path.relative_to(ROOT)): core.sha(path) for path in sorted(core.VENDOR.rglob("*"))
                     if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
    guards = {str(path.relative_to(ROOT)): core.sha(path) for path in sorted(guarded)}
    protocol = {
        "schema": "icde-rrea-policy-gate-20261104-v1", "status": "FROZEN_BEFORE_WORLD_DRAWS",
        "graphs": identities, "bundle": bundle, "guarded_source_and_input_sha256": guards,
        "vendor_sha256": vendor_hashes, "requested_worlds": worlds, "primary_worlds": 256,
        "diagnostic_worlds": 512, "primary_and_diagnostic_fixed_before_outcomes": True,
        "looks": list(LOOKS), "checkpoint_interval_worlds": 16,
        "queries_per_graph": 32, "candidate_pool": "all15000 original ordered targets",
        "model_seed": 17, "world_seed": 107,
        "seed_derivation": "SeedSequence([107, graph_ordinal]); dw=0,enfr=1; unchanged from old64 capture",
        "query_selection": "unchanged old64 source-ID hash selection; labels unused",
        "world_law": "G1 lowest-index-incident pinned triples always active; optional triples independent Bernoulli(0.9)",
        "scorer": "600d RREA plus target CSLS-k10 density frozen on unperturbed full source/target pools; not native per-world CSLS",
        "model_reference": {"key": "mao2020rrea", "authors": "Xin Mao et al.",
            "title": "Relational Reflection Entity Alignment", "venue": "CIKM2020",
            "doi": "10.1145/3340531.3412001", "author_paper": "https://arxiv.org/abs/2008.07962"},
        "inference": {
            "normal": {"delta": .05, "rule": "normal_mixture", "rho": 64, "allocation": "all unordered pairs", "positive_gap": True},
            "ppr_uniform_jain": {"delta": .05, "prior": "uniform", "allocation": "jain_mode", "positive_gap": False},
            "empirical_bernstein": {"delta": .05, "checkpoints": list(LOOKS), "allocation": "2*C*5 direction/pair/checkpoint union", "positive_gap": True}},
        "robust_rule": "Only normal/EB numerical lower_gap>2*deterministic scope_epsilon; no event evidence or beta; same valid lower-gap event protects both frozen families within each rule.",
        "risk_scope": "per query, nominal stream and separately evaluated inference rule; no joint best-rule or workload guarantee",
        "scope": "full graph for both families; localized parameter changes do not imply a local neural execution scope",
        "timing_scope": "fixed-cap capture continues after first certificates for same-world controls; no adaptive encoder saving claim",
        "timing_hierarchy": "all_inference_seconds includes normal/ppr/eb child timers; do not add parent and child timers",
        "maintenance_usecase": "exploratory controlled retention-policy review; not verified deployment need or calibrated fact-existence law",
        "training": False, "truth_accuracy_evaluated": False, "blind_new_source_confirmation": False,
        "total_deadline_seconds": seconds, "identity_freeze_seconds": time.perf_counter() - started,
        "python": sys.version, "platform": platform.platform()}
    prior.write_json(output / "protocol_before_draws.json", protocol)
    return graphs, protocol


def run_graph(output, key, ordinal, g, sources, checkpoint, fast, family, old_reference,
              worlds, seconds, global_started, np, core, prior, inference):
    graph_started = time.perf_counter()
    graph_out = output / key
    costs = {name: 0. for name in ("runtime_setup_seconds", "full_input_build_seconds", "model_build_load_seconds",
        "point_encode_seconds", "equivalence_audit_seconds", "density_seconds", "point_retrieval_seconds",
        "draw_seconds", "world_input_build_seconds", "world_encode_seconds", "world_retrieval_seconds",
        "aggregation_seconds", "normal_inference_seconds", "ppr_inference_seconds", "eb_inference_seconds",
        "all_inference_seconds", "checkpoint_io_seconds", "resource_measurement_seconds")}
    nominal = {rule: new_state() for rule in RULES}
    robust = {rule: {name: new_state() for name in FAMILIES} for rule in ("normal", "empirical_bernstein")}
    snapshots = {}
    progress = {"status": "PREPARING", "graph": key, "completed_worlds": 0,
                "requested_worlds": worlds, "costs": costs, "first_nominal": nominal,
                "first_robust": robust, "snapshots": snapshots, "training_calls": 0}
    prior.write_json(graph_out / "progress.json", progress)
    session = None
    try:
        t = time.perf_counter()
        tf, keras, session, official, dynamic, utils = core.setup(17)
        costs["runtime_setup_seconds"] += time.perf_counter() - t
        prior.write_json(graph_out / "runtime.json", {
            "python": sys.version, "tensorflow": tf.__version__, "keras": keras.__version__,
            "gpu": [str(device) for device in tf.config.list_physical_devices("GPU")],
            "numerical_placement": "G1 dynamic relation shapes; CPU sparse products/segment sums",
            "world_seed_sequence_entropy": [107, ordinal]})
        from www_quality_recovery_v13_worker import matrices as author_matrices
        t = time.perf_counter()
        full = fast.build()
        costs["full_input_build_seconds"] += time.perf_counter() - t
        t = time.perf_counter()
        _, model = core.build_model(g, full, dynamic)
        frozen_weights = core.weights(checkpoint)
        model.set_weights(frozen_weights)
        costs["model_build_load_seconds"] += time.perf_counter() - t
        t = time.perf_counter()
        point_raw = core.embed(model, full)
        costs["point_encode_seconds"] += time.perf_counter() - t
        t = time.perf_counter()
        original_full, _ = author_matrices(g, utils)
        if not all(np.array_equal(a, b) for a, b in zip(full, original_full)):
            raise ValueError("original/full graph matrices differ")
        _, reference_model = core.build_model(g, original_full, official)
        reference_model.set_weights(frozen_weights)
        reference_raw = core.embed(reference_model, original_full)
        full_error = float(np.max(np.abs(point_raw - reference_raw)))
        if full_error > 1e-6:
            raise ValueError("original/dynamic full-graph forward audit failed")
        costs["equivalence_audit_seconds"] += time.perf_counter() - t
        retrieval = core.Retrieval(tf, session)
        point_vectors = core.normalized(point_raw)
        correction, costs["density_seconds"] = retrieval.density(point_vectors, g)
        t = time.perf_counter()
        point_scores = retrieval.scores(point_vectors, sources, g["targets"], correction)
        point_winner = np.argmax(point_scores, axis=1)
        point_top = np.partition(point_scores, -2, axis=1)[:, -2:]
        point_margin = point_top.max(1) - point_top.min(1)
        costs["point_retrieval_seconds"] += time.perf_counter() - t
        if len(sources) != 32 or len(g["targets"]) != 15000:
            raise ValueError("32-source/full15000-target contract changed")
        atomic_npz(graph_out / "point_before_draws.npz", np, scores=point_scores,
                   source_indices=sources, target_order=g["targets"], fixed_target_density=correction)
        audit = {"full_matrices_exact": True, "full_forward_max_abs_error": full_error,
                 "sampled_matrices_exact": None, "sampled_forward_max_abs_error": None,
                 "old64_mask_prefix_equal": None, "old64_winner_prefix_equal": None,
                 "restore_max_abs_error": None, "restore_winner_changes": None}
        prior.write_json(graph_out / "before_draws.json", {
            "status": "READY_BEFORE_FIRST_WORLD", "families": family,
            "fixed_target_density_sha256": hashlib.sha256(correction.tobytes()).hexdigest(),
            "point_winner": point_winner.tolist(), "point_margin": point_margin.tolist(),
            "point_archive_sha256": core.sha(graph_out / "point_before_draws.npz"),
            "audit": audit, "costs": dict(costs), "resources": prior.resources(tf)})
        counts = np.zeros((32, 15000), dtype=np.uint16)
        score_sum = np.zeros((32, 15000), dtype=np.float64)
        winners_trace, margin_trace = [], []
        rng = np.random.default_rng(np.random.SeedSequence([107, ordinal]))
        mask_hash = hashlib.sha256()
        winner_hash = hashlib.sha256()
        peak_rss = 0
        for n in range(1, worlds + 1):
            if time.monotonic() - global_started >= seconds:
                raise TimeoutError("deadline before next world")
            t = time.perf_counter()
            mask = fast.mask(rng)
            mask_hash.update(mask.tobytes())
            costs["draw_seconds"] += time.perf_counter() - t
            t = time.perf_counter()
            sampled = fast.build(mask)
            costs["world_input_build_seconds"] += time.perf_counter() - t
            t = time.perf_counter()
            raw = core.embed(model, sampled)
            costs["world_encode_seconds"] += time.perf_counter() - t
            if n == 1:
                t = time.perf_counter()
                original_sampled, _ = author_matrices(g, utils, mask)
                if not all(np.array_equal(a, b) for a, b in zip(sampled, original_sampled)):
                    raise ValueError("sampled graph matrix audit failed")
                _, sample_reference = core.build_model(g, original_sampled, official)
                sample_reference.set_weights(frozen_weights)
                sample_error = float(np.max(np.abs(raw - core.embed(sample_reference, original_sampled))))
                if sample_error > 1e-6:
                    raise ValueError("sampled original/dynamic forward audit failed")
                audit["sampled_matrices_exact"], audit["sampled_forward_max_abs_error"] = True, sample_error
                costs["equivalence_audit_seconds"] += time.perf_counter() - t
            t = time.perf_counter()
            scores = retrieval.scores(core.normalized(raw), sources, g["targets"], correction)
            if not np.isfinite(scores).all():
                raise ValueError("nonfinite world scores")
            costs["world_retrieval_seconds"] += time.perf_counter() - t
            if time.monotonic() - global_started >= seconds:
                raise TimeoutError("late world is not recorded")
            t = time.perf_counter()
            winners = np.argmax(scores, axis=1).astype(np.int32)
            counts[np.arange(32), winners] += 1
            score_sum += scores
            winners_trace.append(winners)
            top = np.partition(scores, -2, axis=1)[:, -2:]
            margin_trace.append(top.max(1) - top.min(1))
            winner_hash.update(winners.tobytes())
            costs["aggregation_seconds"] += time.perf_counter() - t
            if n == 64 and old_reference is not None:
                audit["old64_mask_prefix_equal"] = mask_hash.hexdigest() == old_reference["mask_prefix_sha256"]
                audit["old64_winner_prefix_equal"] = np.array_equal(np.asarray(winners_trace),
                    np.asarray(old_reference["winner_trace"], dtype=np.int32))
                if not audit["old64_mask_prefix_equal"] or not audit["old64_winner_prefix_equal"]:
                    raise ValueError("the old64 paired stream prefix changed")
            if n in LOOKS:
                t = time.perf_counter()
                leaders, lower, flags, ppr_diagnostics, inference_times = inference_snapshot(counts, n, inference, np)
                costs["all_inference_seconds"] += time.perf_counter() - t
                for name, value in inference_times.items():
                    costs[name] += value
                if time.monotonic() - global_started >= seconds:
                    raise TimeoutError("late inference result is not a certificate")
                elapsed = time.monotonic() - global_started
                for rule in RULES:
                    freeze_first(nominal[rule], flags[rule], leaders, n, elapsed)
                for rule in robust:
                    for name in FAMILIES:
                        robust_flags = [gap > 2 * family[name]["scope_epsilon_upper"] for gap in lower[rule]]
                        freeze_first(robust[rule][name], robust_flags, leaders, n, elapsed)
                top_counts = np.partition(counts, -2, axis=1)[:, -2:].astype(np.float64)
                mean_scores = score_sum / n
                mean_top = np.partition(mean_scores, -2, axis=1)[:, -2:]
                snapshots[str(n)] = {
                    "worlds": n, "role": "primary" if n == 256 else "prespecified_diagnostic_or_earlier_look",
                    "certificate_counts": state_counts(nominal, robust),
                    "instantaneous_nominal_counts": {rule: sum(values) for rule, values in flags.items()},
                    "numerical_lower_gaps": lower, "empirical_mode_position": leaders.tolist(),
                    "empirical_mode_probability": (top_counts.max(1) / n).tolist(),
                    "empirical_mode_gap": ((top_counts.max(1) - top_counts.min(1)) / n).tolist(),
                    "mean_score_winner_position": np.argmax(mean_scores, axis=1).tolist(),
                    "mean_score_margin": (mean_top.max(1) - mean_top.min(1)).tolist(),
                    "ppr_diagnostics": ppr_diagnostics, "mask_prefix_sha256": mask_hash.hexdigest(),
                    "winner_prefix_sha256": winner_hash.hexdigest(), "elapsed_seconds": elapsed}
            if n % 16 == 0 or n in LOOKS:
                t = time.perf_counter()
                resource = prior.resources(tf)
                peak_rss = max(peak_rss, resource["process_rss_bytes"] or 0)
                costs["resource_measurement_seconds"] += time.perf_counter() - t
                t = time.perf_counter()
                checkpoint_path = graph_out / "prefixes" / f"prefix_{n:04d}.npz"
                atomic_npz(checkpoint_path, np, counts=counts, winners=np.asarray(winners_trace),
                    mean_scores=score_sum / n, world_score_margins=np.asarray(margin_trace),
                    source_indices=sources, target_order=g["targets"])
                progress.update({"status": "RUNNING", "completed_worlds": n,
                    "nominal_and_robust_counts": state_counts(nominal, robust),
                    "latest_prefix_archive": str(checkpoint_path.relative_to(output)),
                    "latest_prefix_sha256": core.sha(checkpoint_path),
                    "rng_coordinate_draws": n * len(fast.pinned),
                    "effective_optional_draws": n * int((~fast.pinned).sum()),
                    "world_encoder_calls": n, "audit_reference_encoder_calls": 2,
                    "point_encoder_calls": 1, "mask_prefix_sha256": mask_hash.hexdigest(),
                    "winner_prefix_sha256": winner_hash.hexdigest(),
                    "resources": resource, "peak_observed_process_rss_bytes": peak_rss,
                    "audit": dict(audit), "elapsed_total_seconds": time.monotonic() - global_started,
                    "fixed_cap_continues_after_first_certificate": True})
                costs["checkpoint_io_seconds"] += time.perf_counter() - t
                prior.write_json(graph_out / "progress.json", progress)
                print(json.dumps({"graph": key, "worlds": n, **state_counts(nominal, robust)}), flush=True)
        t = time.perf_counter()
        restored = core.embed(model, full)
        restored_scores = retrieval.scores(core.normalized(restored), sources, g["targets"], correction)
        audit["restore_max_abs_error"] = float(np.max(np.abs(restored - point_raw)))
        audit["restore_winner_changes"] = int(np.sum(np.argmax(restored_scores, axis=1) != point_winner))
        if audit["restore_max_abs_error"] > 1e-6 or audit["restore_winner_changes"]:
            raise ValueError("full-graph restore audit failed")
        if not all(np.array_equal(a, b) for a, b in zip(frozen_weights, model.get_weights())):
            raise ValueError("weights changed during no-training capture")
        costs["equivalence_audit_seconds"] += time.perf_counter() - t
        progress.update({"status": "COMPLETE", "weights_unchanged": True, "audit": dict(audit),
                         "restore_encoder_calls": 1, "graph_total_seconds": time.perf_counter() - graph_started,
                         "primary": snapshots.get("256"), "diagnostic512": snapshots.get("512")})
        prior.write_json(graph_out / "progress.json", progress)
        return {"completed_worlds": worlds, "primary256": snapshots["256"]["certificate_counts"],
                "diagnostic512": snapshots.get("512", {}).get("certificate_counts"),
                "families": family, "progress": f"{key}/progress.json",
                "graph_total_seconds": progress["graph_total_seconds"]}
    except BaseException as error:
        # Do not overwrite durable prefix metadata with in-memory, later states.
        prior.write_json(graph_out / "failure.json", {"status": "PARTIAL_OR_FAILED",
            "error_type": type(error).__name__, "error": str(error),
            "latest_durable_progress": f"{key}/progress.json"})
        raise
    finally:
        if session is not None:
            session.close()


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--worlds", type=int, choices=(256, 512), default=512)
    parser.add_argument("--seconds", type=float, default=840.)
    args = parser.parse_args()
    if not math.isfinite(args.seconds) or not 0 < args.seconds <= 840:
        parser.error("deadline must be positive and no larger than840 seconds")
    output = args.output.resolve()
    output.relative_to(ROOT)
    output.mkdir(parents=True, exist_ok=False)
    # Reusing these helpers preserves the old source selection and resource semantics.
    from icde_rrea_applicability_20261104 import watchdog
    finished = threading.Event()
    threading.Thread(target=watchdog, args=(output, finished, args.seconds, started), daemon=True).start()
    try:
        import numpy as np
        import g1_value_core as core
        import icde_rrea_applicability_20261104 as prior
        import icde_gate_inference as inference
        from run_vldb_interval_gate_v1 import clipped_box, conservative_scope_tv
        graphs, protocol = prepare_protocol(output, args.worlds, args.seconds, np, core, prior,
                                             (clipped_box, conservative_scope_tv))
        summaries = {}
        for ordinal, key in enumerate(("dw", "enfr")):
            g, sources, checkpoint, fast, families, reference = graphs[key]
            summaries[key] = run_graph(output, key, ordinal, g, sources, checkpoint, fast, families, reference,
                args.worlds, args.seconds, started, np, core, prior, inference)
        for relative, expected in protocol["guarded_source_and_input_sha256"].items():
            if core.sha(ROOT / relative) != expected:
                raise ValueError("guarded source/input changed during capture: " + relative)
        for relative, expected in protocol["vendor_sha256"].items():
            if core.sha(ROOT / relative) != expected:
                raise ValueError("vendor source changed during capture: " + relative)
        for identity in protocol["graphs"].values():
            if core.sha(output / identity["law_masks_path"]) != identity["law_masks_sha256"]:
                raise ValueError("frozen family mask archive changed during capture")
        prior.write_json(output / "summary.json", {
            "status": "COMPLETE", "graphs": summaries, "elapsed_seconds": time.monotonic() - started,
            "primary_worlds": 256, "diagnostic_worlds": 512, "training_calls": 0,
            "timing_interpretation": "fixed-cap paired capture; no adaptive encoder savings",
            "usecase_interpretation": "controlled retention-policy sensitivity, full-graph inference; not calibrated fact probabilities"})
    except BaseException as error:
        # Imports may fail before prior is available; keep a simple standalone failure artifact.
        failure = {"status": "FAILED_OR_PARTIAL", "error_type": type(error).__name__, "error": str(error),
                   "traceback": traceback.format_exc(), "elapsed_seconds": time.monotonic() - started,
                   "completed_durable_prefixes_preserved": True}
        temporary = output / "failure.json.tmp"
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(failure, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, output / "failure.json")
        raise
    finally:
        finished.set()


if __name__ == "__main__":
    main()
