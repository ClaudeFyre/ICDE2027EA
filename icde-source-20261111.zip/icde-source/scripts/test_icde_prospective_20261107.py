"""Soundness regressions for the new online experiment orchestration."""
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import icde_prospective_20261107 as study
from vldb_capture_attribute_v0 import DegreeScoreKernel
from vldb_difference_envelope_v2 import compile_difference_kernel


def query(stable=True):
    empty, one = np.array([], dtype=np.intp), np.array([0], dtype=np.intp)
    # For the unstable query: at edge=0 both candidates tie, at edge=1
    # candidate b matches the source degree and wins. Both endpoint laws
    # belong to tau=1, hence no uniform modal winner exists.
    kernel = DegreeScoreKernel("s", ("a", "b"), (0,),
        (one, empty, empty, empty, one, empty),
        np.array([1., 0.]) if stable else np.array([0., 0.]), np.array([0., 0.]), .8)
    metadata = {"graph": "test", "rank": 0, "query_id": "s", "partition": "pilot", "full_candidate_count": 2}
    return compile_difference_kernel(kernel), metadata


class OnlineSoundness(unittest.TestCase):
    def run_case(self, stable, policy, deadline=None):
        kernel, metadata = query(stable)
        with patch.object(study, "LOOKS", (32, 64)):
            return study.execute_case(kernel, metadata, 1., 211, policy, deadline)

    def test_paid_evidence_certifies_invariant_query_on_full_cube(self):
        for policy in ("eager", "lazy"):
            row = self.run_case(True, policy)
            self.assertTrue(row["certified"])
            self.assertEqual(row["candidate"], "a")
            self.assertEqual(row["event_count"], 0)
            self.assertIn(row["event_worlds"], (32, 64))
            self.assertEqual(row["event_worlds"], row["worlds"])

    def test_cheap_bound_can_be_vacuous_for_an_invariant_query(self):
        row = self.run_case(True, "cheap")
        self.assertFalse(row["certified"])
        self.assertEqual(row["event_worlds"], 0)

    def test_direct_interval_is_a_strong_zero_sampling_control(self):
        row = self.run_case(True, "direct")
        self.assertTrue(row["certified"])
        self.assertEqual(row["candidate"], "a")
        self.assertEqual(row["worlds"], 0)

    def test_no_method_certifies_endpoint_disagreement(self):
        for policy in study.POLICIES:
            row = self.run_case(False, policy)
            self.assertFalse(row["certified"])
            self.assertEqual(sum(row["winner_counts"]), row["worlds"])
            self.assertLessEqual(row["event_worlds"], row["worlds"])

    def test_expired_budget_does_not_release_certificate(self):
        row = self.run_case(True, "eager", 1e-12)
        self.assertFalse(row["certified"])
        self.assertEqual(row["worlds"], 0)

    def test_policies_share_identical_observed_random_prefix(self):
        eager, lazy = self.run_case(True, "eager"), self.run_case(True, "lazy")
        self.assertEqual(eager["worlds"], lazy["worlds"])
        self.assertEqual(eager["winner_prefix_sha256"], lazy["winner_prefix_sha256"])
        self.assertEqual(eager["rng_seed_hex"], lazy["rng_seed_hex"])


if __name__ == "__main__":
    unittest.main()
