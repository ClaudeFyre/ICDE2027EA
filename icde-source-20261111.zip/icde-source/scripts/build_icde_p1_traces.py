"""Build the P1 controlled-synthetic query/update traces for ModalTop1.

Output layout (fixed, aligned with the E3/E5 framework and the baseline suite):

    <output_root>/<group>__seed<seed>__b<budget>/trace.jsonl
    <output_root>/<group>__seed<seed>__b<budget>/manifest.json

Four groups x three independent seeds (17/23/31) x two budgets (64/256) = 24
traces. Each trace carries 100-300 query events (length determined by the seed
and recorded in the manifest). Groups 1-3 run on the regression anchor probe
graph; group 4 (hub_factor_updates) runs on the hand-specified toy graph and
interleaves update_probability / update_factor / add / delete events.

These traces are a *synthetic arrival/update request log* (``controlled_synthetic``).
They are NOT factual ICEWS timestamps and NOT a sequence of independent repeated
requests: the statistical unit is the whole independent trace/process. The
snapshot digest is built byte-for-byte as ``scripts/icde_baseline_suite.py``
builds it, so the traces are directly replayable by that suite.

Reproducibility: every random decision is driven by ``random.Random(seed)`` with
a fixed call order; the graph pool selection uses a separate fixed seed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC = REPO_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones.toy import ToyStructuralBackbone  # noqa: E402
from pkgea.contracts import dataset_content_digest  # noqa: E402
from pkgea.query.modal import ModalSnapshot, identity  # noqa: E402

# Snapshot identity components must match scripts/icde_baseline_suite.py exactly.
CODE_ID = "icde_baseline_suite-v1"
SCORER_ID = "toy-degree-lexical-original-float"
MODEL_ID = "no-trained-model"
SCHEMA_ID = "canonical-v1"

PROBE_DIR = REPO_ROOT / "data" / "interim" / "openea-d-w-probe-q32-a64-attributes-independent-s17"
TOY_DIR = REPO_ROOT / "data" / "toy" / "exact_world_minimal"

SEEDS = (17, 23, 31)
BUDGETS = (64, 256)
GROUPS = ("nonrepeated_overlap", "hotspot_partial", "disjoint_scopes", "hub_factor_updates")
POOL_SELECT_SEED = 20261009
DELTA = 0.05
PROBE_POOL_SIZE = 32
PROBE_N_CLUSTERS = 4

# Trace length (query-event count) per seed, in [100, 300].
QUERY_LENGTH_BY_SEED = {17: 140, 23: 180, 31: 220}

# Fixed trace epoch (CST). arrival_ns is a synthetic offset from this epoch,
# NOT a wall-clock measurement.
EPOCH = datetime(2026, 10, 9, 0, 0, 0, tzinfo=timezone(timedelta(hours=8)))


def iso_from_ns(ns: int) -> str:
    """Render a synthetic arrival offset (ns since EPOCH) as ISO8601."""
    moment = EPOCH + timedelta(microseconds=ns / 1000.0)
    return moment.isoformat()


def snapshot_digest_for(graph_dir: Path, confidences: list[float], factors: str) -> tuple[str, dict]:
    """Build the ModalSnapshot exactly as the baseline suite does; return digest + components."""
    components = {
        "graph": dataset_content_digest(graph_dir),
        "model": MODEL_ID,
        "probability": identity(list(confidences)),
        "factors": factors,
        "schema": SCHEMA_ID,
        "code": CODE_ID,
        "scorer": SCORER_ID,
    }
    snap = ModalSnapshot(**components)
    return snap.digest, components


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ---------------------------------------------------------------------------
# Pool / cluster selection (fixed across all traces)
# ---------------------------------------------------------------------------
def select_pools(source_entities, target_entities):
    rng = random.Random(POOL_SELECT_SEED)
    sources = list(source_entities)
    targets = list(target_entities)
    rng.shuffle(sources)
    rng.shuffle(targets)
    shared_pool = tuple(targets[:PROBE_POOL_SIZE])
    hotspot = tuple(sources[:4])
    # Disjoint cluster target pools: 4 disjoint 24-target pools from the 96.
    n = len(targets)
    cluster_targets = tuple(tuple(targets[k * (n // PROBE_N_CLUSTERS):(k + 1) * (n // PROBE_N_CLUSTERS)])
                           for k in range(PROBE_N_CLUSTERS))
    # Source clusters: contiguous slices of the shuffled source list.
    m = len(sources)
    cluster_sources = tuple(tuple(sources[k * (m // PROBE_N_CLUSTERS):(k + 1) * (m // PROBE_N_CLUSTERS)])
                            for k in range(PROBE_N_CLUSTERS))
    return {
        "sources_shuffled": tuple(sources),
        "targets_shuffled": tuple(targets),
        "shared_pool": shared_pool,
        "hotspot": hotspot,
        "cluster_sources": cluster_sources,
        "cluster_targets": cluster_targets,
    }


def rotate(seq, n):
    return tuple(seq[n % len(seq):] + seq[: n % len(seq)])


# ---------------------------------------------------------------------------
# Event builders
# ---------------------------------------------------------------------------
class EventWriter:
    def __init__(self, trace_id: str):
        self.trace_id = trace_id
        self.events: list[dict] = []
        self._seq = 0
        self._arrival = 0
        self._rng = random.Random()  # reset per-trace before use

    def _next(self, kind: str, payload: dict) -> dict:
        self._seq += 1
        # Synthetic inter-arrival: base 0.8s + jitter up to 0.6s (ns).
        self._arrival += int(800_000_000 + self._rng.random() * 600_000_000)
        ev = {
            "trace_id": self.trace_id,
            "event_id": f"{self.trace_id}-e{self._seq:05d}",
            "sequence": self._seq,
            "kind": kind,
            "arrival_ns": self._arrival,
            "event_time": iso_from_ns(self._arrival - 50_000_000),
            "observation_time": iso_from_ns(self._arrival),
        }
        ev.update(payload)
        self.events.append(ev)
        return ev

    def query(self, query_id: str, source: str, candidates: tuple, snapshot: str, budget: int) -> dict:
        return self._next("query", {
            "query_id": query_id,
            "source": source,
            "ordered_candidates": list(candidates),
            "requested_snapshot": snapshot,
            "delta": DELTA,
            "world_budget": budget,
        })

    def update_probability(self, base_snapshot, edge_id, old_p, new_p, resulting):
        return self._next("update_probability", {
            "base_snapshot": base_snapshot,
            "edge_id": edge_id,
            "old_p": old_p,
            "new_p": new_p,
            "resulting_snapshot": resulting,
        })

    def add(self, base_snapshot, fact_id, fact_payload, resulting):
        return self._next("add", {
            "base_snapshot": base_snapshot,
            "stable_fact_id": fact_id,
            "fact_payload": fact_payload,
            "resulting_snapshot": resulting,
        })

    def delete(self, base_snapshot, fact_id, fact_payload, resulting):
        return self._next("delete", {
            "base_snapshot": base_snapshot,
            "stable_fact_id": fact_id,
            "fact_payload": fact_payload,
            "resulting_snapshot": resulting,
        })

    def update_factor(self, base_snapshot, factor_id, old_params, new_params, members, resulting):
        return self._next("update_factor", {
            "base_snapshot": base_snapshot,
            "factor_id": factor_id,
            "old_factor_parameters": old_params,
            "new_factor_parameters": new_params,
            "member_set_change": members,
            "resulting_snapshot": resulting,
        })


# ---------------------------------------------------------------------------
# Probe-group trace generation
# ---------------------------------------------------------------------------
def gen_probe_group(group: str, seed: int, budget: int, pools, probe_snapshot: str, n_queries: int, trace_id: str):
    rng = random.Random(f"icde-p1::{group}::{seed}::{budget}")
    writer = EventWriter(trace_id)
    writer._rng = rng
    sources = pools["sources_shuffled"]
    shared_pool = pools["shared_pool"]
    hotspot = pools["hotspot"]
    cluster_sources = pools["cluster_sources"]
    cluster_targets = pools["cluster_targets"]
    n_sources = len(sources)

    recent: list[tuple[str, tuple]] = []  # for partial repeats in hotspot group

    for i in range(n_queries):
        qid = f"q-{group}-{seed}-{budget}-{i:04d}"
        if group == "nonrepeated_overlap":
            source = sources[i % n_sources]
            candidates = rotate(shared_pool, i)
        elif group == "hotspot_partial":
            # ~30% exact partial repeat of a recent (source, candidates) pair.
            if recent and rng.random() < 0.30:
                source, candidates = recent[rng.randrange(len(recent))]
            else:
                r = rng.random()
                if r < 0.40:
                    source = hotspot[0]
                elif r < 0.60:
                    source = hotspot[1]
                elif r < 0.80:
                    source = hotspot[2]
                else:
                    source = hotspot[3]
                candidates = rotate(shared_pool, i)
            recent.append((source, candidates))
            if len(recent) > 12:
                recent.pop(0)
        elif group == "disjoint_scopes":
            k = i % PROBE_N_CLUSTERS
            source = cluster_sources[k][i % len(cluster_sources[k])]
            candidates = rotate(cluster_targets[k], i)
        else:
            raise ValueError(group)
        writer.query(qid, source, candidates, probe_snapshot, budget)
    return writer.events


# ---------------------------------------------------------------------------
# Toy hub/factor update group
# ---------------------------------------------------------------------------
def gen_update_group(seed: int, budget: int, toy_confidences: list[float], toy_graph_digest: str, n_queries: int, trace_id: str):
    rng = random.Random(f"icde-p1::hub_factor_updates::{seed}::{budget}")
    writer = EventWriter(trace_id)
    writer._rng = rng

    def snap_for(conf, factors):
        comp = {
            "graph": toy_graph_digest,
            "model": MODEL_ID,
            "probability": identity(list(conf)),
            "factors": factors,
            "schema": SCHEMA_ID,
            "code": CODE_ID,
            "scorer": SCORER_ID,
        }
        return ModalSnapshot(**comp).digest, comp

    conf = list(toy_confidences)
    factors = "independent"
    base_digest, _ = snap_for(conf, factors)
    sources = ("s:alice", "s:bob", "s:city")
    targets = ("t:alice", "t:bob", "t:city")

    # Deterministic update schedule interleaved with queries.
    # edge ids correspond to triple order: 0 alice-lives, 1 bob-lives, 2 alice-resides, 3 bob-resides.
    edge_labels = {0: "edge:s:alice/s:city", 1: "edge:s:bob/s:city", 2: "edge:t:alice/t:city", 3: "edge:t:bob/t:city"}
    schedule = []
    # (kind, spec) list; applied every 7 queries.
    flips = [(0, 0.80, 0.10), (0, 0.10, 0.90), (3, 0.55, 0.15)]
    fi = 0
    for i in range(n_queries):
        qid = f"q-hub-{seed}-{budget}-{i:04d}"
        source = sources[i % len(sources)]
        candidates = rotate(targets, i)
        writer.query(qid, source, candidates, base_digest, budget)
        if (i + 1) % 7 == 0 and fi < len(flips):
            edge, old, new = flips[fi]
            conf[edge] = new
            new_digest, _ = snap_for(conf, factors)
            writer.update_probability(base_digest, edge_labels[edge], old, new, new_digest)
            base_digest = new_digest
            fi += 1
        elif (i + 1) % 7 == 0:
            # after the three flips, do one add, one delete, one factor update cycle.
            stage = (i + 1) // 7
            if stage % 3 == 1:
                fact = {"head": "s:alice", "relation": "s:knows", "tail": "s:bob", "confidence": 0.7}
                new_digest, _ = snap_for(conf, "independent+add:s:alice-s:bob")
                writer.add(base_digest, "fact:add:1", fact, new_digest)
                base_digest = new_digest
            elif stage % 3 == 2:
                fact = {"edge_id": edge_labels[1]}
                new_digest, _ = snap_for(conf, "independent+del:edge:s:bob/s:city")
                writer.delete(base_digest, "fact:del:1", fact, new_digest)
                base_digest = new_digest
            else:
                new_factors = "factor:city_hub=0.5"
                new_digest, _ = snap_for(conf, new_factors)
                writer.update_factor(
                    base_digest, "factor:city_hub",
                    {"members": [], "weight": 0.0},
                    {"members": ["s:city", "t:city"], "weight": 0.5},
                    "add-members", new_digest,
                )
                base_digest = new_digest
    return writer.events, base_digest


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=REPO_ROOT / "nodes" / "05_icde_query_engine" / "results" / "icde_traces_20261009")
    args = parser.parse_args(argv)
    out_root = args.output

    probe_backbone = ToyStructuralBackbone.from_dataset(PROBE_DIR)
    toy_backbone = ToyStructuralBackbone.from_dataset(TOY_DIR)
    probe_conf = [float(r["confidence"]) for r in probe_backbone.triples]
    toy_conf = [float(r["confidence"]) for r in toy_backbone.triples]

    probe_digest, probe_comp = snapshot_digest_for(PROBE_DIR, probe_conf, "independent")
    toy_digest, toy_comp = snapshot_digest_for(TOY_DIR, toy_conf, "independent")

    pools = select_pools(probe_backbone.source_entities, probe_backbone.target_entities)

    probe_graph_sha = dataset_content_digest(PROBE_DIR)
    toy_graph_sha = dataset_content_digest(TOY_DIR)
    script_sha = sha256_file(Path(__file__))

    summary = {"format": "icde-p1-traces-v1",
               "output_root": "nodes/05_icde_query_engine/results/icde_traces_20261009",
               "windows_origin": str(out_root),
               "traces": []}

    # Portable graph-reference blocks: repo-relative `ref` + content digest +
    # windows_origin provenance. The absolute Windows path is recorded only as
    # provenance; it is never used as a migration execution path.
    probe_graph_ref = {"kind": "probe",
                       "ref": "data/interim/openea-d-w-probe-q32-a64-attributes-independent-s17",
                       "content_sha256": probe_graph_sha,
                       "content_digest": probe_graph_sha,
                       "windows_origin": str(PROBE_DIR),
                       "snapshot_digest": probe_digest}
    toy_graph_ref = {"kind": "toy",
                     "ref": "data/toy/exact_world_minimal",
                     "content_sha256": toy_graph_sha,
                     "content_digest": toy_graph_sha,
                     "windows_origin": str(TOY_DIR),
                     "snapshot_digest": toy_digest}

    for group in GROUPS:
        for seed in SEEDS:
            budget_query_count = QUERY_LENGTH_BY_SEED[seed]
            for budget in BUDGETS:
                trace_id = f"icde-p1::{group}::seed{seed}::b{budget}"
                if group == "hub_factor_updates":
                    events, final_digest = gen_update_group(
                        seed, budget, toy_conf, toy_comp["graph"], budget_query_count, trace_id)
                    graph_ref = dict(toy_graph_ref)
                else:
                    events = gen_probe_group(
                        group, seed, budget, pools, probe_digest, budget_query_count, trace_id)
                    final_digest = probe_digest
                    graph_ref = dict(probe_graph_ref)

                n_query = sum(1 for e in events if e["kind"] == "query")
                n_update = len(events) - n_query

                tdir = out_root / f"{group}__seed{seed}__b{budget}"
                tdir.mkdir(parents=True, exist_ok=True)
                trace_path = tdir / "trace.jsonl"
                with trace_path.open("w", encoding="utf-8", newline="\n") as fh:
                    for ev in events:
                        fh.write(json.dumps(ev, ensure_ascii=False, sort_keys=True) + "\n")

                manifest = {
                    "format": "icde-p1-trace-manifest-v1",
                    "trace_id": trace_id,
                    "group": group,
                    "seed": seed,
                    "budget": budget,
                    "trace_origin": "controlled_synthetic",
                    "license": "No third-party rows redistributed in this trace log; "
                                "the payload is synthetic request descriptors.",
                    "graph_reference": graph_ref,
                    "input_sha256": {
                        "graph_content_digest": graph_ref["content_sha256"],
                        "generator_script_sha256": script_sha,
                    },
                    "probability_mechanism": "Injected Bernoulli edge probabilities are controlled-synthetic; "
                                              "the trace log itself carries only request descriptors, "
                                              "not factual timestamps.",
                    "pool_selection": {
                        "pool_select_seed": POOL_SELECT_SEED,
                        "probe_pool_size": PROBE_POOL_SIZE,
                        "shared_pool_digest": identity(list(pools["shared_pool"])),
                        "hotspot_sources": list(pools["hotspot"]),
                    },
                    "split_source_cluster": {
                        "probe_sources": len(probe_backbone.source_entities),
                        "probe_targets": len(probe_backbone.target_entities),
                        "clusters": PROBE_N_CLUSTERS,
                    },
                    "epoch": EPOCH.isoformat(),
                    "trace_partition": {"n_events": len(events), "n_query_events": n_query,
                                        "n_update_events": n_update},
                    "risk_config": {"delta_per_query": DELTA,
                                    "revision_delta": "per-revision, no global delta assumed",
                                    "union_bound": "all_pairs", "clock": "all_worlds"},
                    "snapshot_components": graph_ref and (probe_comp if group != "hub_factor_updates" else toy_comp),
                    "final_revision_digest": final_digest,
                    "statistical_unit": "whole independent trace/process; requests within a trace are not "
                                        "independent repetitions",
                }
                mpath = tdir / "manifest.json"
                with mpath.open("w", encoding="utf-8", newline="\n") as fh:
                    fh.write(json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True) + "\n")

                summary["traces"].append({
                    "trace_id": trace_id, "dir": tdir.name, "n_events": len(events),
                    "n_query": n_query, "n_update": n_update,
                })

    summary_path = out_root / "build_summary.json"
    with summary_path.open("w", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(summary, indent=2, ensure_ascii=False, sort_keys=True) + "\n")
    print(json.dumps({"wrote": len(summary["traces"]), "out_root": str(out_root),
                      "probe_snapshot": probe_digest, "toy_snapshot": toy_digest}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
