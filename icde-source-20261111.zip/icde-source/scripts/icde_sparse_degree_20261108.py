"""Same frozen degree scoring map, integer sparse physical execution.

Only integer degree summation changes. Float64 score operation order and
outward distance-to-score operations are delegated to frozen source code.
All controls in the new comparison receive this same execution kernel.
"""
from dataclasses import dataclass
from collections import defaultdict
import numpy as np
from scipy import sparse
import icde_prospective_20261107 as old
from vldb_difference_envelope_v2 import CompiledDifferenceKernel
from vldb_interval_envelope_v1 import _l1_degree_intervals


@dataclass
class GraphIndex:
    edges:list
    incidence:dict


def read_graph(graph):
    triples=old.tsv(old.DATA/graph/'triples.tsv')
    edges=[(r['head_id'],r['tail_id']) for r in triples]
    incidence=defaultdict(list)
    for e,(head,tail) in enumerate(edges):
        incidence[head,0].append(e);incidence[tail,1].append(e)
    return GraphIndex(edges,{k:np.asarray(v,dtype=np.int64) for k,v in incidence.items()})


class SparseDegreeKernel:
    attribute_weight=.8

    def __init__(self,source,candidates,attribute,lexical,edges,index):
        self.source=source;self.candidates=tuple(candidates)
        self.attribute=np.asarray(attribute,dtype=np.float64)
        self.lexical=np.asarray(lexical,dtype=np.float64)
        self.edge_indices=tuple(map(int,edges));self.index=index
        coordinates={entity:2*j for j,entity in enumerate((source,)+self.candidates)}
        rr=[];cc=[]
        self.shared_source_candidate_edge=False
        for local,e in enumerate(self.edge_indices):
            head,tail=index.edges[e]
            signature=[]
            if head in coordinates:signature.append(coordinates[head])
            if tail in coordinates:signature.append(coordinates[tail]+1)
            if not signature:raise AssertionError('invisible scope edge')
            if any(c<2 for c in signature) and any(c>=2 for c in signature):
                self.shared_source_candidate_edge=True
            rr.extend([local]*len(signature));cc.extend(signature)
        self.incidence=sparse.csr_matrix((np.ones(len(rr),dtype=np.int64),(rr,cc)),
                 shape=(len(self.edge_indices),2*(len(self.candidates)+1)),dtype=np.int64)
        self.degree_totals=np.asarray(self.incidence.sum(axis=0)).ravel()
        self._positions=None

    @property
    def incidence_positions(self):
        if self._positions is None:
            matrix=self.incidence.tocsc()
            self._positions=tuple(matrix.indices[matrix.indptr[c]:matrix.indptr[c+1]].astype(np.intp,copy=True)
                                  for c in range(matrix.shape[1]))
        return self._positions

    def _degrees(self,states):
        states=np.asarray(states)
        if states.dtype!=np.bool_ or states.ndim!=2 or states.shape[1]!=len(self.edge_indices):
            raise ValueError('states must be full Boolean scope rows')
        return np.asarray(states.astype(np.int64)@self.incidence,dtype=np.int64)

    def scores(self,states):
        degrees=self._degrees(states).astype(np.float64)
        distance=np.abs(degrees[:,0,None]-degrees[:,2::2])+np.abs(degrees[:,1,None]-degrees[:,3::2])
        dynamic=1./(1.+distance)
        structural=.6*self.lexical[None,:]+.4*dynamic
        return self.attribute_weight*self.attribute[None,:]+(1.-self.attribute_weight)*structural

    def score_bounds_from_distances(self,minimum,maximum):
        return CompiledDifferenceKernel.score_bounds_from_distances(self,minimum,maximum)

    def score_intervals(self,low_states,high_states):
        if np.any(low_states & ~high_states):raise ValueError('invalid state box')
        low=self._degrees(low_states);high=self._degrees(high_states)
        # Coordinate boxes remain sound with shared incidence. The existing
        # released cross-KG cases have disjoint source/candidate supports.
        minimum,maximum=_l1_degree_intervals(low,high)
        return self.score_bounds_from_distances(minimum,maximum)

    def ambiguity_indicators(self,q,low,high,uniforms,nominal_scores=None):
        return CompiledDifferenceKernel.ambiguity_indicators(self,q,low,high,uniforms,nominal_scores)


def read_query(graph,rank,index):
    path=old.BASE/'prepared'/graph/f'q{rank:03d}.npz'
    meta=old.load(path.with_suffix('.json'))
    if old.sha(path)!=meta['kernel_sha256']:raise AssertionError('prepared source changed')
    with np.load(path,allow_pickle=False) as arrays:
        kernel=SparseDegreeKernel(meta['query_id'],meta['candidates'],arrays['attribute'].copy(),
                   arrays['lexical'].copy(),arrays['edges'].copy(),index)
    return kernel,meta


def restrict(kernel,selected):
    selected=tuple(sorted(selected))
    entities=(kernel.source,)+tuple(kernel.candidates[c] for c in selected)
    incident=[kernel.index.incidence.get((entity,d),np.empty(0,dtype=np.int64))
              for entity in entities for d in (0,1)]
    edges=np.unique(np.concatenate(incident))
    if not set(map(int,edges)).issubset(kernel.edge_indices):
        raise AssertionError('restricted scope not contained in full frozen scope')
    return SparseDegreeKernel(kernel.source,[kernel.candidates[c] for c in selected],
              kernel.attribute[list(selected)],kernel.lexical[list(selected)],edges,kernel.index),selected
