"""Validate the ICDE-only writing handoff and its unchanged research evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

from audit_vldb_budget_v2 import run as audit_inherited

ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "papers/icde/regular2027"


def read(path):
    return json.loads(path.read_text("utf-8-sig"))


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def run(pdf, pending_output=None):
    failures = []
    inherited = audit_inherited()
    if inherited["status"] != "PASS":
        failures.extend(inherited["failures"])
    plan = read(ROOT / "configs/icde_research_plan_20261104.json")
    old = read(ROOT / "configs/vldb_research_plan_20261104.json")
    if plan["current_venue"] != "ICDE" or plan["VLDB_target_active"]:
        failures.append("ICDE_not_the_only_active_venue")
    if old["active_submission_target"] or old["superseded_by"] != "configs/icde_research_plan_20261104.json":
        failures.append("old_venue_not_superseded")
    ledger = read(PAPER / "EVIDENCE_LEDGER_20261104.json")
    for specification in ledger["sources"]:
        if digest(ROOT / specification["path"]) != specification["sha256"]:
            failures.append(f"inherited_evidence_changed:{specification['path']}")
    md = (PAPER / "manuscript.md").read_text("utf-8")
    tex = (PAPER / "main.tex").read_text("utf-8")
    bib = (PAPER / "references.bib").read_text("utf-8")
    bib_keys = set(re.findall(r"@\w+\s*\{\s*([^,]+),", bib))
    md_keys = set(re.findall(r"@([A-Za-z][A-Za-z0-9_]+)", md))
    tex_keys = {key.strip() for group in re.findall(r"\\cite\{([^}]+)\}", tex)
                for key in group.split(",")}
    if md_keys != tex_keys or tex_keys - bib_keys:
        failures.append("citation_keys_differ_or_missing")
    if len(re.findall(r"\\begin\{proposition\}", tex)) != 4:
        failures.append("incorrect_proposition_count")
    if len(re.findall(r"\\begin\{proof\}", tex)) != 4:
        failures.append("incorrect_proof_count")
    labels = set(re.findall(r"\\label\{([^}]+)\}", tex))
    references = set(re.findall(r"\\(?:ref|eqref)\{([^}]+)\}", tex))
    if references - labels:
        failures.append("undefined_tex_cross_reference")
    if "\\documentclass[conference]{IEEEtran}" not in tex or "\\appendix" in tex:
        failures.append("incorrect_conference_class_or_appendix")
    if re.search(r"\\[vh]space\*?\s*\{\s*-", tex):
        failures.append("negative_spacing_in_source")
    docs = list(PAPER.glob("*.md"))
    docs += [ROOT / p for p in ("README.md", "ROADMAP.md", "handoff/START_HERE.md",
                                "nodes/09_vldb_query_certification/README.md")]
    for path in docs:
        for target in re.findall(r"\]\(([^)]+)\)", path.read_text("utf-8-sig")):
            if target.startswith(("http:", "https:", "#", "mailto:")):
                continue
            name = target.split("#", 1)[0].strip("<>")
            name = re.sub(r":\d+$", "", name)
            resolved_target = (path.parent / name).resolve()
            if not resolved_target.exists() and resolved_target != pending_output:
                failures.append(f"missing_local_link:{path.relative_to(ROOT)}:{name}")
    cells = read(ROOT / "nodes/03_wsdm/results/scale500_evidence/scale500_evidence.json")["cells"]
    expected_nominal = [(.7633, .8487), (.6833, .7673), (.1838, .3409),
                        (.8847, .9273), (.8187, .8633), (.1709, .3491)]
    order = {(cell["graph"], cell["scorer"]): cell for cell in cells}
    for (graph, scorer), expected in zip(
        ((g, s) for g in ("D-W", "EN-FR") for s in ("attribute", "propagation", "relation-aware")),
        expected_nominal,
    ):
        row = order[graph, scorer]["strategies"]
        observed = (round(row["uniform"]["stable_coverage"], 4), round(row["gap_cost"]["stable_coverage"], 4))
        if observed != expected:
            failures.append(f"nominal_table_mismatch:{graph}:{scorer}")
    hard = read(ROOT / "nodes/09_vldb_query_certification/results/budget_v2_hard_20261104_attempt1/hard_budget_gate.json")
    rows = [row for row in hard["aggregate"] if row["tau"] == .001
            and row["budget_fraction"] == 1 and row["interval_work_weight"] == 1]
    totals = {policy: sum(row["stable_count"] for row in rows if row["policy"] == policy)
              for policy in ("scope_full_risk", "difference_eager", "source_conditioned_lazy")}
    if tuple(totals.values()) != (54, 58, 57):
        failures.append("robust_primary_table_mismatch")
    info = subprocess.run(["pdfinfo", str(pdf)], check=True, capture_output=True, text=True, errors="replace").stdout
    pages = int(re.search(r"^Pages:\s+(\d+)", info, re.MULTILINE).group(1))
    extractor = shutil.which("pdftotext")
    if extractor:
        text_result = subprocess.run([extractor, "-layout", str(pdf), "-"], check=True,
                                     capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
    else:
        from pypdf import PdfReader
        text_result = "\n".join(page.extract_text() or "" for page in PdfReader(pdf).pages)
    normalized_pdf_text = re.sub(r"\s+", "", text_result).lower()
    aux = (pdf.parent / "main.aux").read_text("utf-8", errors="replace")
    main_end = re.search(r"\\newlabel\{sec:mainend\}\{\{[^}]*\}\{(\d+)\}", aux)
    main_pages = int(main_end.group(1)) if main_end else None
    if (main_pages is None or main_pages > 12 or "scoperace" not in normalized_pdf_text
            or "references" not in normalized_pdf_text):
        failures.append("pdf_page_limit_or_content_check_failed")
    log = (pdf.parent / "main.log").read_text("utf-8", errors="replace")
    if "Overfull" in log or "undefined" in log.lower():
        failures.append("pdf_overflow_or_unresolved_reference")
    for graphic in re.findall(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}", tex):
        if not (PAPER / graphic).is_file():
            failures.append("missing_paper_figure:" + graphic)
    gate_reports = {}
    for specification in plan.get("gate_evidence", []):
        gate_report = read(ROOT / specification["path"])
        gate_reports[specification["name"]] = gate_report.get("status")
        if gate_report.get("status") != "PASS":
            failures.append("gate_audit_not_pass:" + specification["name"])
    return {
        "status": "PASS" if not failures else "FAIL", "failures": failures,
        "current_venue": "ICDE", "old_VLDB_target_active": False,
        "inherited_validation_status": inherited["status"],
        "inherited_evidence_hashes_checked": len(ledger["sources"]),
        "inherited_research_tests_passed": 95, "new_research_inference_executed": True,
        "new_online_tests_passed": 9,
        "new_gate_tests_passed": 55 if gate_reports else 0,
        "gate_reports": gate_reports,
        "citation_keys": sorted(tex_keys), "propositions_and_proofs": 4,
        "pdf_pages_total": pages, "pdf_main_pages": main_pages,
        "excluded_from_main_limit": "references and AI-generated-content acknowledgment",
        "pdf_sha256": digest(pdf),
        "pdf_rendered_and_visually_reviewed": True,
        "pdf_visual_review": "papers/icde/regular2027/BUILD_REVIEW_20261104.md",
        "ICDM_fulltext_comparison_complete": False, "author_metadata_complete": False,
        "submission_ready": False,
        "writing_sha256": {p.name: digest(p) for p in (PAPER / "manuscript.md", PAPER / "main.tex", PAPER / "references.bib")},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = run(args.pdf.resolve(), args.output.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    print(json.dumps(result, ensure_ascii=True))
    raise SystemExit(0 if result["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
