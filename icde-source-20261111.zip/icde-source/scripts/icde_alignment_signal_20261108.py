"""Historical source-grouped OOF diagnostics, not calibrated risk guarantees."""
import hashlib
import math
import numpy as np


def sigmoid(x):
    return 1/(1+np.exp(-np.clip(x,-40,40)))


def fit_predict(train_x,train_y,test_x):
    # Fixed ridge=1 on standardized covariates, sum log likelihood; train-only
    # centering, no label-based hyperparameter search or threshold selection.
    center=train_x.mean(axis=0)
    scale=train_x.std(axis=0)
    scale=np.where(scale>1e-12,scale,1.)
    x=np.column_stack((np.ones(len(train_x)),(train_x-center)/scale))
    test=np.column_stack((np.ones(len(test_x)),(test_x-center)/scale))
    beta=np.zeros(x.shape[1])
    penalty=np.eye(x.shape[1]);penalty[0,0]=0.
    for iteration in range(80):
        p=sigmoid(x@beta)
        gradient=x.T@(p-train_y)+penalty@beta
        hessian=(x.T*np.maximum(p*(1-p),1e-9))@x+penalty
        step=np.linalg.solve(hessian+np.eye(len(beta))*1e-10,gradient)
        def loss(b):
            v=x@b
            return np.sum(np.logaddexp(0,v)-train_y*v)+.5*b@penalty@b
        rate=1.
        oldloss=loss(beta)
        while rate>1e-6 and loss(beta-rate*step)>oldloss:
            rate*=.5
        beta-=rate*step
        if np.max(np.abs(rate*step))<1e-8:
            break
    if not np.isfinite(beta).all():
        raise AssertionError('nonfinite logistic fit')
    return sigmoid(test@beta),{'iterations':iteration+1,'coefficients':beta.tolist(),
                              'train_center':center.tolist(),'train_scale':scale.tolist()}


def metrics(y,confidence):
    y=np.asarray(y,dtype=float)
    confidence=np.asarray(confidence,dtype=float)
    n=len(y)
    order=np.argsort(-confidence,kind='stable')
    y,c=y[order],confidence[order]
    # Expected cumulative error within a tied score block: prevents source ID
    # ordering from creating an artificial advantage for binary stability.
    risks=np.empty(n)
    preceding_errors=0.
    a=0
    while a<n:
        b=a+1
        while b<n and c[b]==c[a]:b+=1
        error_rate=1.-float(y[a:b].mean())
        j=np.arange(1,b-a+1)
        risks[a:b]=(preceding_errors+j*error_rate)/(a+j)
        preceding_errors+=(b-a)*error_rate
        a=b
    # AUROC by pair counts, allowing ties.
    positive=float(y.sum());negative=n-positive
    pair_wins=0.;higher_positive=0.;a=0
    while a<n:
        b=a+1
        while b<n and c[b]==c[a]:b+=1
        p=float(y[a:b].sum());q=b-a-p
        pair_wins+=higher_positive*q+.5*p*q
        higher_positive+=p;a=b
    clipped=np.clip(confidence,1e-12,1-1e-12)
    return {'accuracy':float(y.mean()),'aurc':float(risks.mean()),
            'auroc':pair_wins/(positive*negative) if positive and negative else None,
            'brier':float(np.mean((confidence-y)**2)),
            'logloss':float(-np.mean(y*np.log(clipped)+(1-y)*np.log1p(-clipped))),
            'risk_at_coverage':{str(f):float(risks[max(0,math.ceil(f*n)-1)]) for f in (.1,.25,.5,.75,1.)}}


def diagnose(rows,bootstrap_repeats=1000):
    feature_names=['signed_expected_margin','retained_softmax','mc_frequency','log_candidates','log_worlds','is_enfr']
    x=np.asarray([[r['features'][name] for name in feature_names] for r in rows])
    y=np.asarray([r['correct'] for r in rows],dtype=float)
    stable=np.asarray([r['stable'] for r in rows],dtype=float)
    extended=np.column_stack((x,stable))
    folds=np.asarray([int(hashlib.sha256(f"association-signal-v1|{r['graph']}|{r['query_id']}".encode()).hexdigest()[:16],16)%5 for r in rows])
    predictions={name:np.zeros(len(rows)) for name in ('baseline','baseline_plus_stability')}
    fits=[]
    for fold in range(5):
        training=folds!=fold;testing=~training
        for name,features in [('baseline',x),('baseline_plus_stability',extended)]:
            pred,fit=fit_predict(features[training],y[training],features[testing])
            predictions[name][testing]=pred
            fits.append({'model':name,'fold':fold,'train_rows':int(training.sum()),
                         'test_rows':int(testing.sum()),**fit})
    subgroups={}
    for name,include in [('all',lambda r:True),('competitive',lambda r:r['retained_candidates']>1),
                         ('dw',lambda r:r['graph']=='dw'),('enfr',lambda r:r['graph']=='enfr')]:
        ix=np.asarray([i for i,r in enumerate(rows) if include(r)],dtype=int)
        group={model:metrics(y[ix],pred[ix]) for model,pred in predictions.items()}
        def ranking(values):
            values=metrics(y[ix],values)
            return {key:values[key] for key in ('accuracy','aurc','auroc','risk_at_coverage')}
        group['raw_rankings']={f:ranking(np.asarray([rows[i]['features'][f] for i in ix]))
                               for f in ('signed_expected_margin','retained_softmax','mc_frequency')}
        group['raw_rankings']['stable']=ranking(stable[ix])
        group['strata']={}
        for flag in (0,1):
            selected=[rows[i] for i in ix if rows[i]['stable']==bool(flag)]
            group['strata'][str(flag)]={'query_seed_cases':len(selected),
                'distinct_queries':len({(r['graph'],r['rank']) for r in selected}),
                'accuracy':sum(r['correct'] for r in selected)/len(selected) if selected else None}
        group['query_seed_cases']=len(ix)
        group['distinct_queries']=len({(rows[i]['graph'],rows[i]['rank']) for i in ix})
        subgroups[name]=group
    # Descriptive source bootstrap, preserving all three seeds per source and
    # separately resampling each graph. Fits remain fixed, so these intervals
    # do not include refitting uncertainty or graph-wide dependence.
    clusters={}
    for i,r in enumerate(rows):clusters.setdefault((r['graph'],r['rank']),[]).append(i)
    rng=np.random.default_rng(20261108)
    deltas={name:[] for name in ('aurc','brier','logloss')}
    for b in range(bootstrap_repeats):
        indices=[]
        for graph in ('dw','enfr'):
            keys=[key for key in clusters if key[0]==graph]
            for draw in rng.integers(0,len(keys),size=len(keys)):
                indices.extend(clusters[keys[int(draw)]])
        stats={model:metrics(y[indices],pred[indices]) for model,pred in predictions.items()}
        for name in deltas:
            deltas[name].append(stats['baseline_plus_stability'][name]-stats['baseline'][name])
    intervals={name:{'difference':subgroups['all']['baseline_plus_stability'][name]-subgroups['all']['baseline'][name],
                     'descriptive_source_bootstrap_95pct':np.quantile(values,[.025,.975]).tolist()}
               for name,values in deltas.items()}
    return {'status':'PASS','feature_names':feature_names,'added_feature':'raw robust stable flag',
            'subgroups':subgroups,'differences':intervals,'fits':fits,
            'oof_rows':[{**r,'fold':int(folds[i]),'baseline_probability':float(predictions['baseline'][i]),
                         'extended_probability':float(predictions['baseline_plus_stability'][i])} for i,r in enumerate(rows)],
            'limitations':['historical development diagnostics, not new prospective confirmation',
                           'same degree scorer and configured retention; no other backbones',
                           'MC frequencies use old adaptively stopped prefixes, not equal fixed-budget draws',
                           'retained-candidate softmax is uncalibrated and not full-15K softmax',
                           'source folds prevent seed leakage; graph-wide dependencies remain',
                           'bootstrap conditions on fixed OOF predictions; no model-refit uncertainty',
                           'no finite-sample selective-risk or fact-calibration guarantee']}
