"""One bounded, durable shard of the original 500-source ICDE online protocol.

The frozen online setup/scoring/inference functions are reused unchanged.
Only source selection is injected during setup to prepare a deterministic
slice of the original 500-source hash order, with the complete TF-IDF corpus.
Launch one finite shard through safe_run; use --resume for its existing output.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import threading
import time
import traceback
import uuid

ROOT = Path(__file__).resolve().parents[1]
METHODS = ("scope_full_risk", "difference_eager", "difference_lazy")
SALT = "vldb-v0-20261104"
PURPOSE = "icde_online_worlds_v1"
CANONICAL = ("entities.tsv", "relations.tsv", "triples.tsv", "alignments.tsv",
             "attributes.tsv", "confidence_metadata.json")


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def canonical_digest(value):
    payload = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def file_sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path, value, *, new_only=False):
    path = Path(path)
    if new_only and path.exists():
        raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    with temporary.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def repo_path(path):
    path = Path(path)
    path = path.resolve() if path.is_absolute() else (ROOT / path).resolve()
    path.relative_to(ROOT)
    return path


def parse_methods(value):
    methods = tuple(value.split(",")) if value else METHODS
    if not methods or len(set(methods)) != len(methods) or any(item not in METHODS for item in methods):
        raise ValueError("methods must be distinct original method names separated by commas")
    return methods


def parse_seeds(values):
    pieces = [piece for value in values for piece in str(value).split(",")]
    seeds = tuple(int(piece) for piece in pieces)
    if not seeds or len(set(seeds)) != len(seeds) or any(seed < 0 for seed in seeds):
        raise ValueError("seeds must be distinct nonnegative integers")
    return seeds


def select_shard(pool, shard, shard_size, salt=SALT):
    if len(pool) != 500 or len(set(pool)) != 500:
        raise ValueError("the source universe must contain exactly 500 distinct test sources")
    if salt != SALT:
        raise ValueError("preserve the original V0 hash ordering")
    if type(shard_size) is not int or not 1 <= shard_size <= 500:
        raise ValueError("shard_size must be in [1,500]")
    shard_count = math.ceil(500 / shard_size)
    if type(shard) is not int or not 0 <= shard < shard_count:
        raise ValueError(f"shard must be in [0,{shard_count - 1}]")
    ordered = tuple(sorted(pool, key=lambda source: (
        hashlib.sha256(f"{salt}|{source}".encode("utf-8")).digest(), source)))
    start = shard * shard_size
    return ordered, ordered[start:start + shard_size]


@contextmanager
def selected_query_setup(engine, full_order, selected, salt=SALT):
    """Inject only a verified source slice; restore the frozen module binding."""
    original = engine.select_queries

    def choose(pool, count, requested_salt):
        if requested_salt != salt or count != len(selected):
            raise ValueError("setup source-selection arguments changed")
        if tuple(original(pool, 500, requested_salt)) != tuple(full_order):
            raise ValueError("setup source universe differs from pre-draw manifest")
        return tuple(selected)

    engine.select_queries = choose
    try:
        yield
    finally:
        engine.select_queries = original


def query_identity(prepared):
    metadata = prepared.metadata
    proof = {key: value for key, value in metadata["candidate_audit"].items() if key != "seconds"}
    return {
        "graph": prepared.graph, "query_id": prepared.query_id,
        "dataset_revision": prepared.dataset_revision,
        "candidate_ids": metadata["candidate_ids"],
        "candidate_tie_order": metadata["candidate_tie_order"],
        "candidate_preservation": proof,
        "scope_certificate": metadata["scope_certificate"],
        "scope_edge_indices": metadata["scope_edge_indices"],
        "scope_edge_count": metadata["scope_edge_count"],
        "candidate_count": metadata["candidate_count"],
        "cost_model": metadata["cost_model"], "box_audit": metadata["box_audit"],
        "scope_epsilon_upper": prepared.scope_epsilon,
    }


def case_key(graph, rank, seed, method):
    graph_token = hashlib.sha256(graph.encode("utf-8")).hexdigest()[:12]
    return f"{graph_token}/q{rank:03d}_s{seed}_{method}.json"


def validate_result(row, expected):
    for key in ("graph", "query_id", "dataset_revision", "seed", "method", "candidate_count", "scope_edge_count"):
        if row.get(key) != expected[key]:
            raise ValueError(f"completed case has a different {key}")
    n, m, k = row["samples_used"], row["scope_edge_count"], row["candidate_count"]
    counts = row["winner_counts"]
    if not (type(n) is int and n >= 0 and len(counts) == k
            and all(type(count) is int and count >= 0 for count in counts) and sum(counts) == n
            and row["worlds_generated"] == row["nominal_score_rows"] == n
            and row["random_uniform_draws"] == n * m and row["event_extra_random_draws"] == 0):
        raise ValueError("completed case has inconsistent nominal evidence")
    if not (row["event_rows_computed"] == row["event_samples_used"] <= n
            and 0 <= row["event_count"] <= row["event_free_rows"] <= row["event_samples_used"]):
        raise ValueError("completed case has incomplete event evidence")
    if not (math.isfinite(row["work_used"]) and 0 <= row["work_used"] <= row["work_budget"]
            and row["work_overshoot"] == 0):
        raise ValueError("completed case exceeds modeled work budget")
    if not all(isinstance(value, (int, float)) and math.isfinite(value) and value >= 0
               for value in row["seconds"].values()):
        raise ValueError("completed case has invalid timing")


def load_verified_case(path, manifest_digest, identity_digest, expected, expected_sha=None):
    if expected_sha is not None and file_sha(path) != expected_sha:
        raise ValueError("checkpointed case bytes changed")
    envelope = load_json(path)
    if (envelope.get("status") != "COMPLETE"
            or envelope.get("manifest_sha256") != manifest_digest
            or envelope.get("query_identity_sha256") != identity_digest):
        raise ValueError("case belongs to a different/incomplete protocol or query contract")
    validate_result(envelope["row"], expected)
    return envelope


def freeze_inputs(config, shard, shard_size):
    profiles = []
    for profile in config["profiles"]:
        path = repo_path(profile["dataset_path"])
        revision = hashlib.sha256(b"pkgea-dataset-revision-v1\0")
        hashes = {}
        for name in CANONICAL:
            item = path / name
            if item.is_file():
                payload = item.read_bytes()
                hashes[name] = hashlib.sha256(payload).hexdigest()
                revision.update(name.encode("utf-8") + b"\0" + payload + b"\0")
        actual_revision = revision.hexdigest()
        if profile.get("expected_revision", actual_revision) != actual_revision:
            raise ValueError("input revision differs from configured profile")
        with (path / "alignments.tsv").open(encoding="utf-8-sig", newline="") as handle:
            pool = [row["source_entity_id"] for row in csv.DictReader(handle, delimiter="\t")
                    if row["split"] == "test"]
        ordered, selected = select_shard(pool, shard, shard_size, config["selection_salt"])
        profiles.append({"graph": profile["graph"], "dataset_path": profile["dataset_path"],
            "dataset_revision": actual_revision, "input_sha256": hashes,
            "full500_source_order": list(ordered), "selected_source_ids": list(selected),
            "global_rank_start": shard * shard_size})
    if len({item["graph"] for item in profiles}) != len(profiles):
        raise ValueError("graph names must be unique")
    return profiles


def runtime_sources(config_path):
    paths = {Path(__file__).resolve(), config_path, ROOT / "scripts/icde_online_execution.py"}
    paths.update((ROOT / "scripts").glob("*vldb*.py"))
    paths.update((ROOT / "src/pkgea").rglob("*.py"))
    return {path.relative_to(ROOT).as_posix(): file_sha(path) for path in sorted(paths)}


@contextmanager
def output_lock(output):
    handle = (output / ".runner.lock").open("a+b")
    if handle.tell() == 0:
        handle.write(b"0")
        handle.flush()
    handle.seek(0)
    locked = False
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        locked = True
        yield
    finally:
        if locked:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def deadline_watch(output, attempt, finished, started, limit):
    if not finished.wait(max(0., limit - (time.monotonic() - started))):
        try:
            atomic_json(output / "attempts" / attempt / "deadline.json", {
                "status": "JOB_DEADLINE", "elapsed_seconds": time.monotonic() - started,
                "limit_seconds": limit, "partial_cases_preserved": True,
                "incomplete_current_case_is_not_completed_evidence": True})
            print("Shard time limit reached; durable completed cases preserved.", flush=True)
        finally:
            os._exit(124)


def execute(args, output, started, attempt):
    config_path = repo_path(args.config)
    original_config = load_json(config_path)
    config = {**original_config, "query_count": 500, "expected_query_pool": 500,
              "selection_salt": original_config.get("selection_salt", SALT)}
    methods = parse_methods(args.methods) if args.methods else parse_methods(",".join(config.get("methods", METHODS)))
    seeds = parse_seeds(args.seeds if args.seeds is not None else config["seeds"])
    config["seeds"] = list(seeds)
    config["methods"] = list(methods)
    profiles = freeze_inputs(config, args.shard, args.shard_size)
    manifest = {
        "schema": "icde-gate-durable-shard-v1", "original_config": original_config,
        "effective_config": config, "config_path": config_path.relative_to(ROOT).as_posix(),
        "source_sha256": runtime_sources(config_path), "profiles": profiles,
        "shard": args.shard, "shard_size": args.shard_size,
        "shard_count": math.ceil(500 / args.shard_size), "methods": list(methods), "seeds": list(seeds),
        "inference": "normal", "inference_source": "frozen icde_online_execution.run_query unchanged",
        "actual_seed_purpose": PURPOSE, "actual_seed_salt": SALT,
        "risk_scope": "one box; per query, nominal run and separately evaluated policy",
        "selection_adapter": "verified fixed slice of original500 source hash order; full corpus unchanged",
        "timing_scope": "per-shard fresh setup plus durable writes; not unsharded cold pipeline latency",
        "CP_cache_scope": "fresh process starts empty; retained across completed cases within this attempt; no prewarm",
        "resume_rule": "reverify code/input/config and rebuilt query contract before skipping a complete durable case",
        "python": sys.version, "platform": platform.platform(), "no_training": True,
    }
    manifest_digest = canonical_digest(manifest)
    manifest_path = output / "protocol_freeze.json"
    if args.resume:
        old = load_json(manifest_path)
        if old != manifest or canonical_digest(old) != manifest_digest:
            raise ValueError("resume refused: code, input, config, shard or interpreter identity changed")
    else:
        atomic_json(manifest_path, manifest, new_only=True)
    checkpoint_path = output / "checkpoint.json"
    checkpoint = load_json(checkpoint_path) if checkpoint_path.exists() else {
        "schema": "icde-gate-durable-checkpoint-v1", "manifest_sha256": manifest_digest,
        "completed": {}, "attempts": []}
    if checkpoint["manifest_sha256"] != manifest_digest:
        raise ValueError("checkpoint protocol identity changed")
    expected_files = set()
    for profile in profiles:
        for offset, source in enumerate(profile["selected_source_ids"]):
            rank = profile["global_rank_start"] + offset
            for seed in seeds:
                for method in methods:
                    expected_files.add(case_key(profile["graph"], rank, seed, method))
    if not set(checkpoint["completed"]).issubset(expected_files):
        raise ValueError("checkpoint contains a case outside this shard protocol")
    for key, record in checkpoint["completed"].items():
        path = output / "cases" / key
        if not path.is_file() or file_sha(path) != record["sha256"]:
            raise ValueError("completed checkpoint case is missing or corrupted")
    if (output / "cases").exists():
        present = {path.relative_to(output / "cases").as_posix() for path in (output / "cases").rglob("*.json")}
        if not present.issubset(expected_files):
            raise ValueError("unexpected durable case file in output")
    checkpoint["expected_cases"] = len(expected_files)
    checkpoint["attempts"].append(attempt)
    checkpoint["status"] = "PREPARING"
    atomic_json(checkpoint_path, checkpoint)
    attempt_out = output / "attempts" / attempt
    atomic_json(attempt_out / "attempt.json", {
        "resume": args.resume, "job_limit_seconds": args.seconds,
        "manifest_sha256": manifest_digest, "already_checkpointed_cases": len(checkpoint["completed"]),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})

    # This import cannot generate nominal worlds. The manifest precedes setup's
    # explicitly charged coupled-audit draws as well as every run_query draw.
    before = time.perf_counter()
    import icde_online_execution as engine
    settings = engine.settings_from_config(config)
    if settings["required_pythonhashseed"] is not None and os.environ.get("PYTHONHASHSEED") != str(settings["required_pythonhashseed"]):
        raise ValueError("launch with frozen PYTHONHASHSEED before importing scorer helpers")
    import_seconds = time.perf_counter() - before
    graph_setup_seconds = 0.
    completed_this_attempt = skipped = 0
    for graph_index, (profile, frozen) in enumerate(zip(config["profiles"], profiles)):
        selected = tuple(frozen["selected_source_ids"])
        shard_settings = {**settings, "query_count": len(selected)}
        shard_profile = {**profile, "expected_query_ids": list(selected)}
        before = time.perf_counter()
        with selected_query_setup(engine, frozen["full500_source_order"], selected):
            prepared, report = engine.setup_graph(shard_profile, shard_settings)
        setup_seconds = time.perf_counter() - before
        graph_setup_seconds += setup_seconds
        if (report["dataset_revision"] != frozen["dataset_revision"] or report["input_sha256"] != frozen["input_sha256"]
                or report["query_selection"]["query_ids"] != list(selected)):
            raise ValueError("prepared shard differs from frozen input and query identities")
        graph_token = hashlib.sha256(profile["graph"].encode("utf-8")).hexdigest()[:12]
        atomic_json(attempt_out / f"setup_{graph_token}.json", report, new_only=True)
        for seed_index, seed in enumerate(seeds):
            for offset, query in enumerate(prepared):
                rank = frozen["global_rank_start"] + offset
                identity = query_identity(query)
                identity_digest = canonical_digest(identity)
                rotation = (graph_index + seed_index + rank) % len(methods)
                ordered_methods = methods[rotation:] + methods[:rotation]
                for method in ordered_methods:
                    key = case_key(query.graph, rank, seed, method)
                    path = output / "cases" / key
                    expected = {"graph": query.graph, "query_id": query.query_id,
                        "dataset_revision": query.dataset_revision, "seed": seed, "method": method,
                        "candidate_count": query.metadata["candidate_count"],
                        "scope_edge_count": query.metadata["scope_edge_count"]}
                    if path.exists():
                        if not args.resume:
                            raise FileExistsError(path)
                        prior = checkpoint["completed"].get(key)
                        load_verified_case(path, manifest_digest, identity_digest, expected,
                                           prior["sha256"] if prior else None)
                        skipped += 1
                    else:
                        if time.monotonic() - started >= args.seconds:
                            raise TimeoutError("job deadline before next case")
                        row = engine.run_query(query, shard_settings, method, seed)
                        if time.monotonic() - started >= args.seconds:
                            raise TimeoutError("case finished after job deadline; not recorded as complete")
                        validate_result(row, expected)
                        atomic_json(path, {
                            "schema": "icde-gate-complete-case-v1", "status": "COMPLETE",
                            "manifest_sha256": manifest_digest, "query_identity_sha256": identity_digest,
                            "query_identity": identity, "global_query_rank": rank, "shard": args.shard,
                            "attempt": attempt, "row": row}, new_only=True)
                        completed_this_attempt += 1
                    checkpoint["completed"][key] = {
                        "sha256": file_sha(path), "query_identity_sha256": identity_digest,
                        "graph": query.graph, "query_id": query.query_id, "seed": seed, "method": method}
                    checkpoint.update({"status": "RUNNING", "last_case": key,
                        "last_attempt": attempt, "completed_cases": len(checkpoint["completed"]),
                        "attempt_elapsed_seconds": time.monotonic() - started})
                    atomic_json(checkpoint_path, checkpoint)
                    atomic_json(output / "progress.json", {
                        "status": "RUNNING", "manifest_sha256": manifest_digest,
                        "completed_cases": len(checkpoint["completed"]), "expected_cases": len(expected_files),
                        "completed_this_attempt": completed_this_attempt, "verified_skips_this_attempt": skipped,
                        "attempt": attempt, "elapsed_seconds": time.monotonic() - started})
                    print(json.dumps({"shard": args.shard, "completed": len(checkpoint["completed"]),
                                      "expected": len(expected_files), "case": key}), flush=True)
    if runtime_sources(config_path) != manifest["source_sha256"] or freeze_inputs(config, args.shard, args.shard_size) != profiles:
        raise ValueError("sources or inputs changed during shard execution")
    if set(checkpoint["completed"]) != expected_files:
        raise ValueError("shard ended without its complete expected case grid")
    checkpoint.update({"status": "COMPLETE", "completed_cases": len(expected_files)})
    atomic_json(checkpoint_path, checkpoint)
    atomic_json(output / "progress.json", {
        "status": "COMPLETE", "manifest_sha256": manifest_digest,
        "completed_cases": len(expected_files), "expected_cases": len(expected_files),
        "attempt": attempt, "elapsed_seconds": time.monotonic() - started})
    atomic_json(attempt_out / "complete.json", {
        "status": "COMPLETE", "elapsed_seconds": time.monotonic() - started,
        "completed_this_attempt": completed_this_attempt, "verified_skips_this_attempt": skipped,
        "engine_import_seconds": import_seconds, "graph_setup_seconds": graph_setup_seconds,
        "timing_scope": "this shard/attempt includes its own full-corpus setup and durable output overhead",
        "unsharded_pipeline_cold_latency_claim": False}, new_only=True)


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--shard", required=True, type=int)
    parser.add_argument("--shard-size", type=int, default=64)
    parser.add_argument("--methods", help="comma-separated original methods")
    parser.add_argument("--seeds", nargs="+", help="space- or comma-separated base seeds")
    parser.add_argument("--inference", choices=("normal",), default="normal")
    parser.add_argument("--seconds", type=float, default=840.)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if not math.isfinite(args.seconds) or not 0 < args.seconds <= 900:
        parser.error("each job must have a positive deadline no larger than 900 seconds")
    if not 1 <= args.shard_size <= 500 or not 0 <= args.shard < math.ceil(500 / args.shard_size):
        parser.error("invalid finite shard index or size")
    output = repo_path(args.output_dir)
    if args.resume:
        if not (output / "protocol_freeze.json").is_file():
            parser.error("--resume requires a previously frozen shard output")
    else:
        output.mkdir(parents=True, exist_ok=False)
    attempt = time.strftime("%Y%m%dT%H%M%S", time.gmtime()) + "_" + uuid.uuid4().hex[:12]
    finished = threading.Event()
    with output_lock(output):
        threading.Thread(target=deadline_watch, args=(output, attempt, finished, started, args.seconds),
                         daemon=True).start()
        try:
            execute(args, output, started, attempt)
        except BaseException as error:
            atomic_json(output / "attempts" / attempt / "failure.json", {
                "status": "PARTIAL_OR_FAILED", "error": str(error), "traceback": traceback.format_exc(),
                "elapsed_seconds": time.monotonic() - started, "durable_complete_cases_preserved": True})
            raise
        finally:
            finished.set()


if __name__ == "__main__":
    main()
