"""Refine a winner-event enclosure by retaining the common source degree.

This is a bounded partition of a standard abstract-Monte-Carlo enclosure.
Every possible source in/out degree is kept common to all candidates.  The
candidate degree boxes remain conservative, including when edges are shared.
The score mapping and outward arithmetic are inherited without reassociation.
"""

from __future__ import annotations

from itertools import product

import numpy as np


def source_conditioned_indicators(
    compiled, q, low, high, uniforms, nominal_scores=None,
    difference_flags=None, max_source_assignments=4,
):
    """Return h and per-row counters for an optional source partition.

    Cached scores and difference flags, when supplied, must come from this
    same compiled mapping, box, and ordered uniforms.  The data driver binds
    those identities.  No independent or observed-flip interpretation of h is
    implied.  The cap changes precision, never soundness.
    """
    m, k = len(compiled.edge_indices), len(compiled.candidates)
    for value, name, dimensions in ((q, "q", 1), (low, "low", 1),
                                     (high, "high", 1), (uniforms, "uniforms", 2)):
        if not isinstance(value, np.ndarray) or value.dtype != np.float64 or value.ndim != dimensions:
            raise ValueError(f"{name} requires a float64 array of dimension {dimensions}")
        if not np.isfinite(value).all():
            raise ValueError(f"nonfinite {name}")
    if q.shape != (m,) or low.shape != q.shape or high.shape != q.shape or uniforms.shape[1] != m:
        raise ValueError("box or uniform shape differs from compiled edge order")
    if np.any(low < 0) or np.any(high > 1) or np.any(low > q) or np.any(q > high):
        raise ValueError("box must lie in [0,1] and contain q")
    if np.any(uniforms < 0) or np.any(uniforms >= 1):
        raise ValueError("uniforms must lie in [0,1)")
    if type(max_source_assignments) is not int or not 1 <= max_source_assignments <= 256:
        raise ValueError("source partition cap must be an integer in [1,256]")
    n = len(uniforms)
    if nominal_scores is not None:
        if (not isinstance(nominal_scores, np.ndarray) or nominal_scores.dtype != np.float64
                or nominal_scores.shape != (n, k) or not np.isfinite(nominal_scores).all()):
            raise ValueError("cached nominal scores require finite float64 (n,k)")
    if difference_flags is None:
        difference_flags = compiled.ambiguity_indicators(q, low, high, uniforms, nominal_scores)
    if (not isinstance(difference_flags, np.ndarray) or difference_flags.dtype != np.bool_
            or difference_flags.shape != (n,)):
        raise ValueError("cached difference flags require Boolean shape (n,)")
    lower_states, upper_states = uniforms < low, uniforms < high
    free = np.any(lower_states != upper_states, axis=1)
    if np.any(difference_flags & ~free):
        raise ValueError("an all-fixed world cannot have a valid ambiguity flag")
    source_low = np.column_stack([
        np.sum(lower_states[:, positions], axis=1, dtype=np.int64)
        for positions in compiled.incidence_positions[:2]
    ])
    source_high = np.column_stack([
        np.sum(upper_states[:, positions], axis=1, dtype=np.int64)
        for positions in compiled.incidence_positions[:2]
    ])
    sizes = np.prod(source_high - source_low + 1, axis=1, dtype=np.int64)
    eligible = difference_flags & (sizes > 1) & (sizes <= max_source_assignments)
    flags = difference_flags.copy()
    assignments = np.zeros(n, dtype=np.int64)
    degree_rows = np.zeros(n, dtype=np.int64)
    indices = np.flatnonzero(eligible)
    if len(indices):
        degree_low, degree_high = compiled.degree_intervals(lower_states[indices], upper_states[indices])
        scores = (compiled.scores(uniforms[indices] < q) if nominal_scores is None
                  else nominal_scores[indices])
        for local_row, original_row in enumerate(indices):
            possibilities = np.asarray(list(product(
                range(int(source_low[original_row, 0]), int(source_high[original_row, 0]) + 1),
                range(int(source_low[original_row, 1]), int(source_high[original_row, 1]) + 1),
            )), dtype=np.int64)
            assignments[original_row] = len(possibilities)
            degree_rows[original_row] = 1
            target_low = degree_low[local_row, 2:].reshape(k, 2).T
            target_high = degree_high[local_row, 2:].reshape(k, 2).T
            source = possibilities[:, :, None]
            minimum = np.maximum(0, np.maximum(source - target_high, target_low - source))
            maximum = np.maximum(np.abs(source - target_low), np.abs(source - target_high))
            score_low, score_high = compiled.score_bounds_from_distances(
                np.sum(minimum, axis=1, dtype=np.int64),
                np.sum(maximum, axis=1, dtype=np.int64),
            )
            winner = int(np.argmax(scores[local_row]))
            competitor_high = score_high.copy()
            competitor_high[:, winner] = -np.inf
            if np.all(score_low[:, winner] > np.max(competitor_high, axis=1)):
                flags[original_row] = False
    if np.any(flags & ~difference_flags):
        raise AssertionError("a refinement cannot add ambiguity flags")
    return flags, {
        "free_flags": free,
        "conditioning_assignment_counts": assignments,
        "conditioning_degree_rows": degree_rows,
        "source_interval_reads_per_row": 2 * sum(map(len, compiled.incidence_positions[:2])),
        "maximum_source_assignments": max_source_assignments,
        "source_assignment_box_is_conservative": True,
    }
