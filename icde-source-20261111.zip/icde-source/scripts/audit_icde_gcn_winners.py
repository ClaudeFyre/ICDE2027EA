"""Check actual cosine winners after normalized-GCN local refresh (CPU pilot)."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path

import torch
from torch.nn import functional as F

sys.path.insert(0, str(Path(__file__).resolve().parent / "backbones"))
from torch_gcn_align import GCNAlign, normalized_adjacency

from pkgea.contracts import dataset_content_digest
from pkgea.query.modal import world_winner
from pkgea.streaming import PropagationDependencyIndex


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", type=Path)
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--edges", type=int, default=16)
    args = parser.parse_args()
    if args.output.exists() or args.edges <= 0:
        raise ValueError("fresh output and positive edge count required")
    torch.set_num_threads(1)
    cp = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if cp.get("format") != "pkgea-torch-gcn-align-v1":
        raise ValueError("unexpected checkpoint")
    triples = read(args.dataset / "triples.tsv")
    ids, heads, tails = cp["entity_ids"], cp["heads"], cp["tails"]
    if len(triples) != len(heads) or any(
        (row["head_id"], row["tail_id"]) != (ids[h], ids[t])
        for row, h, t in zip(triples, heads, tails, strict=True)
    ):
        raise ValueError("checkpoint topology mismatch")
    index = {entity: i for i, entity in enumerate(ids)}
    alignments = [r for r in read(args.dataset / "alignments.tsv") if r["split"] == "test"]
    sources = tuple(dict.fromkeys(r["source_entity_id"] for r in alignments))
    targets = tuple(dict.fromkeys(r["target_entity_id"] for r in alignments))
    if not sources or not targets or any(e not in index for e in sources + targets):
        raise ValueError("missing query entities")
    h, t = torch.tensor(heads), torch.tensor(tails)
    features = cp["features"]
    model = GCNAlign(cp["feature_dimension"], cp["dimension"])
    model.load_state_dict(cp["model_state"])
    model.eval()
    probs = [float(r["confidence"]) for r in triples]
    base = torch.tensor([p >= 0.5 for p in probs], dtype=torch.float32)
    uncertain = [i for i, p in enumerate(probs) if 0 < p < 1]
    if not uncertain:
        raise ValueError("no uncertain edges")
    selected = (
        uncertain
        if len(uncertain) <= args.edges
        else [uncertain[i * len(uncertain) // args.edges] for i in range(args.edges)]
    )
    dependencies = PropagationDependencyIndex([(r["head_id"], r["tail_id"]) for r in triples])
    incident = [[] for _ in ids]
    for slot, (left, right) in enumerate(zip(heads, tails, strict=True)):
        incident[left].append((slot, right))
        incident[right].append((slot, left))

    def full(weights):
        adj = normalized_adjacency(len(ids), h, t, weights, torch.device("cpu"))
        hidden = F.relu(model.layer1(torch.cat((features, torch.sparse.mm(adj, features)), dim=1)))
        emb = F.normalize(
            model.layer2(torch.cat((hidden, torch.sparse.mm(adj, hidden)), dim=1)), dim=1
        )
        return hidden, emb

    def aggregate(matrix, positions, weights, degree):
        rows = []
        for pos in positions:
            row = matrix[pos] / degree[pos]
            for slot, neighbor in incident[pos]:
                if weights[slot].item() != 0:
                    row = (
                        row
                        + weights[slot]
                        * degree[pos].rsqrt()
                        * degree[neighbor].rsqrt()
                        * matrix[neighbor]
                    )
            rows.append(row)
        return torch.stack(rows)

    def scalar_winners(emb):
        return {
            s: world_winner(
                {c: float(torch.dot(emb[index[s]], emb[index[c]])) for c in targets}, targets
            )
            for s in sources
        }

    with torch.no_grad():
        hidden, emb = full(base)
        base_winners = scalar_winners(emb)
        rows = []
        for slot in selected:
            weights = base.clone()
            weights[slot] = 1 - weights[slot]
            _, reference = full(weights)
            p1 = sorted(
                index[e] for e in dependencies.affected_entities((slot,), 1, normalization_hops=1)
            )
            p2 = sorted(
                index[e] for e in dependencies.affected_entities((slot,), 2, normalization_hops=1)
            )
            degree = torch.ones(len(ids))
            degree.scatter_add_(0, h, weights)
            degree.scatter_add_(0, t, weights)
            local_hidden = hidden.clone()
            local_hidden[p1] = F.relu(
                model.layer1(
                    torch.cat((features[p1], aggregate(features, p1, weights, degree)), dim=1)
                )
            )
            local_emb = emb.clone()
            local_emb[p2] = F.normalize(
                model.layer2(
                    torch.cat(
                        (local_hidden[p2], aggregate(local_hidden, p2, weights, degree)), dim=1
                    )
                ),
                dim=1,
            )
            ref_winners, local_winners = scalar_winners(reference), scalar_winners(local_emb)
            # Matmul is a separate physical score path; compare exact labels too.
            scores = (
                reference[[index[s] for s in sources]] @ reference[[index[c] for c in targets]].T
            )
            batch_winners = {
                s: world_winner({c: float(scores[i, j]) for j, c in enumerate(targets)}, targets)
                for i, s in enumerate(sources)
            }
            rows.append(
                {
                    "edge": slot,
                    "affected_layer2": len(p2),
                    "embedding_max_error": float((local_emb - reference).abs().max()),
                    "full_scalar_winners": ref_winners,
                    "local_scalar_winners": local_winners,
                    "full_batch_winners": batch_winners,
                    "local_disagreements": sum(ref_winners[s] != local_winners[s] for s in sources),
                    "batch_disagreements": sum(ref_winners[s] != batch_winners[s] for s in sources),
                    "changed_from_base": sum(ref_winners[s] != base_winners[s] for s in sources),
                }
            )
    result = {
        "format": "icde-gcn-winner-audit-v1",
        "dataset": str(args.dataset),
        "dataset_content_digest": dataset_content_digest(args.dataset),
        "checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "torch_version": torch.__version__,
        "threads": 1,
        "source_count": len(sources),
        "candidate_count": len(targets),
        "edges": rows,
        "winner_comparisons": len(rows) * len(sources),
        "local_winner_disagreements": sum(r["local_disagreements"] for r in rows),
        "batch_winner_disagreements": sum(r["batch_disagreements"] for r in rows),
        "changed_winners": sum(r["changed_from_base"] for r in rows),
        "claim_boundary": "Old 32-candidate probe, threshold base world plus selected single-edge flips; finite winner equality check, no general numerical or new-domain quality guarantee.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "edges"}, indent=2))
    if result["local_winner_disagreements"] or result["batch_winner_disagreements"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
