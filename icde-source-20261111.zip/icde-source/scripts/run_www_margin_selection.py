"""Run the preregistered R2 margin-aware selection stages with visible progress."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "nodes/04_www_distributional/results/margin_selection"
RUNTIME = ROOT / ".runtime"
PYTHON = Path(r"D:\miniconda\envs\baokai\python.exe")
CELLS = (
    ("dw", "relation", "independent"),
    ("enfr", "relation", "structural"),
    ("dw", "gcn", "structural"),
    ("enfr", "gcn", "independent"),
    ("enfr", "relation", "independent"),
    ("dw", "gcn", "independent"),
    ("enfr", "gcn", "structural"),
    ("dw", "relation", "structural"),
)
STAGE_SEEDS = {"a": (59, 71), "b": (83, 97, 103)}


def digest(path: Path) -> str | None:
    """SHA-256 of a checkpoint, or None when the weights are absent.

    Model weights are untracked by design, so a clean clone must still be able
    to build and inspect the task plan.  Preflight keeps refusing to run when a
    checkpoint is missing, so nothing executes without real weights; this only
    stops plan construction from depending on the machine that holds them.
    Mirrors the same guard in ``run_www_main_matrix.py``.
    """

    if not path.is_file():
        return None
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temporary, path)
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def checkpoint(graph: str, family: str) -> Path:
    if family == "relation":
        return ROOT / (
            f"nodes/03_wsdm/checkpoints/scale500/"
            f"relation_align_{graph}_scale500_s17.pt"
        )
    return ROOT / (
        f"nodes/04_www_distributional/checkpoints/scale500/"
        f"gcn_align_{graph}_scale500_s17.pt"
    )


def profile(graph: str, dependence: str) -> Path:
    graph_name = "d-w" if graph == "dw" else "en-fr"
    suffix = (
        "independent-s17"
        if dependence == "independent"
        else "structural-c55-s17"
    )
    return ROOT / (
        f"data/interim/openea-{graph_name}-probe-q500-a512-attributes-{suffix}"
    )


def task(stage: str, graph: str, family: str, dependence: str) -> dict[str, object]:
    seeds = STAGE_SEEDS[stage]
    slug = f"{graph}_{family}_{dependence}"
    output = RESULTS / f"stage_{stage}" / f"www_margin_{slug}_v1.json"
    markdown = output.with_suffix(".md")
    task_id = f"www-margin-{stage}-{graph}-{family}-{dependence}"
    checkpoint_path = checkpoint(graph, family)
    profile_path = profile(graph, dependence)
    command = [
        str(PYTHON),
        "scripts/run_www_equal_budget.py",
        str(output.relative_to(ROOT)),
        "--markdown-output",
        str(markdown.relative_to(ROOT)),
        "--checkpoint",
        str(checkpoint_path.relative_to(ROOT)),
        "--profile",
        f"{dependence}={profile_path.relative_to(ROOT)}",
        "--gate-budget",
        "2048",
        "--budgets",
        "2048",
        "--reference-samples",
        "4096",
        "--selection-seed",
        "17",
        "--test-seeds",
        *map(str, seeds),
        "--reference-seed",
        "1017",
        "--candidate-ranks",
        "1",
        "2",
        "4",
        "8",
        "--query-limit",
        "500",
        "--candidate-limit",
        "1012",
        "--cell-label",
        f"margin-{stage}/{graph}/{family}/{dependence}",
        "--margin-aware-experiment",
        "--resume",
        "--heartbeat-seconds",
        "60",
    ]
    safe_command = [
        str(PYTHON),
        "scripts/safe_run.py",
        "--task-id",
        task_id,
        "--profile",
        "cpu64",
        "--max-runtime-minutes",
        "120",
        "--expected-output",
        str(output.relative_to(ROOT)),
        "--",
        *command,
    ]
    return {
        "task_id": task_id,
        "stage": stage,
        "cell": [graph, family, dependence],
        "selection_seed": 17,
        "test_seeds": list(seeds),
        "reference_seed": 1017,
        "checkpoint": str(checkpoint_path),
        "checkpoint_sha256": digest(checkpoint_path),
        "profile": str(profile_path),
        "output": str(output),
        "command": command,
        "safe_command": safe_command,
    }


def preflight(tasks: list[dict[str, object]]) -> dict[str, object]:
    if (RUNTIME / "safe-run.lock").exists():
        raise RuntimeError("single-task lock already exists")
    if not PYTHON.is_file():
        raise FileNotFoundError(PYTHON)
    for item in tasks:
        if not Path(str(item["checkpoint"])).is_file():
            raise FileNotFoundError(item["checkpoint"])
        if not Path(str(item["profile"])).is_dir():
            raise FileNotFoundError(item["profile"])
    free = shutil.disk_usage(ROOT).free
    if free < 100 * 1024**3:
        raise RuntimeError("less than 100 GiB free disk")
    return {
        "status": "pass",
        "task_count": len(tasks),
        "test_seeds_explicit": sorted(
            {seed for item in tasks for seed in item["test_seeds"]}
        ),
        "free_disk_gib": free / 1024**3,
        "single_task_lock_absent": True,
    }


def run_and_echo(item: dict[str, object]) -> int:
    log = RUNTIME / "logs" / f"{item['task_id']}.log"
    print(
        f"\n=== START {item['task_id']} seeds={item['test_seeds']} ===",
        flush=True,
    )
    process = subprocess.Popen(item["safe_command"], cwd=ROOT)
    position = 0
    while process.poll() is None:
        if log.exists():
            with log.open("r", encoding="utf-8", errors="replace") as handle:
                handle.seek(position)
                chunk = handle.read()
                position = handle.tell()
            if chunk:
                print(chunk, end="", flush=True)
        time.sleep(2)
    if log.exists():
        with log.open("r", encoding="utf-8", errors="replace") as handle:
            handle.seek(position)
            print(handle.read(), end="", flush=True)
    print(f"=== END {item['task_id']} exit={process.returncode} ===", flush=True)
    return int(process.returncode or 0)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("a", "b"), required=True)
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    tasks = [task(args.stage, *cell) for cell in CELLS]
    manifest = RESULTS / f"stage_{args.stage}" / "task_manifest_v1.json"
    frozen = {
        "schema_version": "pkgea-www-margin-aware-r2-v1",
        "specification": "papers/www/MARGIN_AWARE_SELECTION_SPEC_R2.md",
        "stage": args.stage,
        "preflight": preflight(tasks),
        "tasks": tasks,
    }
    if manifest.exists():
        existing = json.loads(manifest.read_text(encoding="utf-8"))
        if {
            key: existing.get(key)
            for key in ("schema_version", "specification", "stage", "tasks")
        } != {
            key: frozen[key]
            for key in ("schema_version", "specification", "stage", "tasks")
        }:
            raise RuntimeError("existing manifest differs from frozen plan")
    else:
        atomic_json(manifest, frozen)
    print(json.dumps(frozen["preflight"], indent=2), flush=True)
    if args.preflight_only:
        return 0
    for item in tasks:
        code = run_and_echo(item)
        if code:
            return code
    print(f"WWW MARGIN-AWARE STAGE {args.stage.upper()} COMPLETE", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
