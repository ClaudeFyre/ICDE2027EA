from itertools import product
from fractions import Fraction as Q
import unittest
import numpy as np
from icde_sparse_degree_20261108 import SparseDegreeKernel,GraphIndex,restrict
from icde_block_events_20261108 import execute
from icde_grouped_exact_20261108 import compile_counts,solve_counts
from vldb_capture_attribute_v0 import DegreeScoreKernel
from vldb_difference_envelope_v2 import compile_difference_kernel


class SparseBlockTest(unittest.TestCase):
    def make(self):
        edges=[('s','x'),('s','x'),('a','b'),('b','c'),('c','a')]
        inc={}
        for e,(h,t) in enumerate(edges):
            inc.setdefault((h,0),[]).append(e);inc.setdefault((t,1),[]).append(e)
        index=GraphIndex(edges,{k:np.asarray(v,dtype=np.int64) for k,v in inc.items()})
        return SparseDegreeKernel('s',['a','b','c'],[.8,.79,.77],[.5,.5,.5],range(5),index)

    def test_sparse_scores_equal_original_for_all_worlds(self):
        k=self.make();states=np.asarray(list(product((False,True),repeat=5)))
        raw=DegreeScoreKernel(k.source,k.candidates,k.edge_indices,k.incidence_positions,k.attribute,k.lexical,.8)
        original=compile_difference_kernel(raw)
        np.testing.assert_array_equal(k.scores(states),original.scores(states))
        lo=np.zeros((1,5),dtype=bool);hi=np.ones((1,5),dtype=bool)
        a,b=k.score_intervals(lo,hi);c,d=original.score_intervals(lo,hi)
        np.testing.assert_array_equal(a,c);np.testing.assert_array_equal(b,d)

    def test_restricted_scores_preserve_selected_columns(self):
        k=self.make();sub,selected=restrict(k,[0,2])
        states=np.asarray(list(product((False,True),repeat=5)))
        local=states[:,list(sub.edge_indices)]
        np.testing.assert_array_equal(sub.scores(local),k.scores(states)[:,list(selected)])

    def test_block_bound_does_not_exceed_exact_full_query_gap(self):
        k=self.make();low=np.full(5,.65);high=np.ones(5)
        exact=solve_counts(compile_counts(k,low,high),3)
        settings={'nominal':.9,'tau':.25,'block_size':1,'block_state_cap':32768,'block_work_cap':2000000}
        result=execute(k,settings)
        focus=result['focus'];gap=min(Q(p['minimum_gap_exact']) for p in exact['pairs'] if p['candidate']==focus)
        self.assertLessEqual(Q.from_float(result['lower_gap']),gap)
        if result['status']=='stable':self.assertIn(focus,exact['uniform_winners'])


if __name__=='__main__':unittest.main()
