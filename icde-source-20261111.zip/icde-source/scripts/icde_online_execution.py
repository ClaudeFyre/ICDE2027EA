"""Incremental, paired-world ICDE modal-query execution.

No full winner/event stream is captured before policy execution. Saved U and
scores cover only already-generated nominal rows; event evidence is evaluated
only after static admission and always completes a protected prefix.
"""

from __future__ import annotations

import time
MODULE_STARTED = time.perf_counter()
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys
from dataclasses import dataclass
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from pkgea.contracts import dataset_revision_digest
from pkgea.query.index import CandidateBound, StaticCandidateIndex
from pkgea.scope import build_incident_degree_certificate
from run_vldb_interval_gate_v1 import (
    _inside, _read_tsv, audit_candidate_preservation, build_selected_backbone,
    clipped_box, conservative_scope_tv,
)
from vldb_capture_attribute_v0 import (
    CANONICAL_FILES, DEFAULT_PROFILES, SALT, audit_coupled_scores,
    build_degree_kernel, file_sha256, select_queries, stream_seed,
)
from vldb_difference_envelope_v2 import compile_difference_kernel
import vldb_event_bound_v2 as event_bounds
from vldb_stream_frontier_v0 import normal_radius

IMPORT_SECONDS = time.perf_counter() - MODULE_STARTED
METHODS = ("scope_full_risk", "difference_eager", "difference_lazy")
CHECKPOINTS = (96, 224, 480, 992, 2016, 4096)
SCHEMA = "icde-incremental-modal-execution-v1"


@dataclass(frozen=True)
class PreparedQuery:
    graph: str
    query_id: str
    dataset_revision: str
    kernel: Any
    q: np.ndarray
    low: np.ndarray
    high: np.ndarray
    scope_epsilon: float
    metadata: dict


def settings_from_config(config: dict) -> dict:
    result = {
        "profiles": list(DEFAULT_PROFILES), "query_count": 16,
        "expected_query_pool": 500, "selection_salt": SALT,
        "seeds": [61, 73, 89], "sample_count": 4096, "tau": .001,
        "attribute_weight": .8, "delta_total": .05,
        "delta_nominal": .025, "beta_total": .025,
        "event_checkpoints": list(CHECKPOINTS),
        "nominal": {"rho": 64., "minimum_samples": 32, "check_every": 64},
        "work_model": {"nominal_candidate_units": 16, "interval_candidate_units": 64},
        "budget_fraction": 1., "interval_work_weight": 1.,
        "deadline_seconds": None, "audit_worlds": 2,
        "required_pythonhashseed": "0", **config,
    }
    for key in ("query_count", "expected_query_pool", "sample_count", "audit_worlds"):
        if type(result[key]) is not int or result[key] < 1:
            raise ValueError(f"{key} must be a positive integer")
    if result["sample_count"] > 4096 or result["query_count"] > result["expected_query_pool"]:
        raise ValueError("sample or query cap exceeded")
    for key in ("minimum_samples", "check_every"):
        if type(result["nominal"][key]) is not int or result["nominal"][key] <= 0:
            raise ValueError("invalid nominal checkpoints")
    for key in ("nominal_candidate_units", "interval_candidate_units"):
        if type(result["work_model"][key]) is not int or result["work_model"][key] < 0:
            raise ValueError("work coefficients must be nonnegative integers")
    if not math.isfinite(result["nominal"]["rho"]) or result["nominal"]["rho"] <= 0:
        raise ValueError("invalid normal-mixture tuning")
    for key in ("budget_fraction", "tau"):
        if not math.isfinite(result[key]) or not 0 < result[key] <= 1:
            raise ValueError(f"invalid {key}")
    if not math.isfinite(result["interval_work_weight"]) or result["interval_work_weight"] <= 0:
        raise ValueError("invalid interval weight")
    deadline = result["deadline_seconds"]
    if deadline is not None and (not math.isfinite(deadline) or deadline <= 0):
        raise ValueError("deadline must be positive or null")
    seeds = result["seeds"]
    if (not seeds or len(set(seeds)) != len(seeds)
            or any(type(seed) is not int or seed < 0 for seed in seeds)):
        raise ValueError("seeds must be distinct nonnegative integers")
    result["risk_plan"] = event_bounds.validate_risk_plan({
        **result, "tau_grid": [result["tau"]], "max_samples_per_query": 4096,
    })
    return result


def setup_graph(profile: dict, settings: dict, root: Path = ROOT):
    """Build all-corpus TF-IDF once; prepare only label-independent test IDs."""
    started = time.perf_counter()
    dataset = _inside(root, profile["dataset_path"])
    graph = str(profile["graph"])
    before = time.perf_counter()
    revision = dataset_revision_digest(dataset)
    if profile.get("expected_revision", revision) != revision:
        raise ValueError("frozen dataset revision changed")
    hashes = {name: file_sha256(dataset / name) for name in CANONICAL_FILES
              if (dataset / name).is_file()}
    metadata = json.loads((dataset / "confidence_metadata.json").read_text("utf-8-sig"))
    if metadata.get("edge_dependence", {}).get("assumption") != "independent":
        raise ValueError("online degree implementation requires declared independent edges")
    alignments = _read_tsv(dataset / "alignments.tsv")
    pool = [row["source_entity_id"] for row in alignments if row["split"] == "test"]
    if len(pool) != settings["expected_query_pool"] or len(set(pool)) != len(pool):
        raise ValueError("test-source universe differs from the frozen 500-query pool")
    selected = select_queries(pool, settings["query_count"], settings["selection_salt"])
    if "expected_query_ids" in profile and tuple(profile["expected_query_ids"]) != selected:
        raise ValueError("selected query identity differs from protocol")
    identity_seconds = time.perf_counter() - before
    backbone, reconstruction = build_selected_backbone(
        dataset, selected, attribute_weight=settings["attribute_weight"])
    probabilities = np.asarray([float(row["confidence"]) for row in backbone.triples], dtype=np.float64)
    if (not len(probabilities) or not np.isfinite(probabilities).all()
            or np.any((probabilities < 0) | (probabilities > 1))
            or any(row.get("dependency_group", "") for row in backbone.triples)):
        raise ValueError("invalid independent world specification")
    # The original index formula is evaluated only for selected sources. The
    # corpus itself remains complete; no gold target enters query selection.
    before = time.perf_counter()
    weight = backbone.attribute_weight
    bounds = {}
    for source in selected:
        items = []
        for target in backbone.target_entities:
            lower = (weight * backbone.attribute_scores[source, target]
                     + (1. - weight) * .6 * backbone.structural.lexical_scores[source, target])
            items.append(CandidateBound(target, lower, lower + (1. - weight) * .4))
        bounds[source] = items
    index = StaticCandidateIndex(bounds)
    index_seconds = time.perf_counter() - before
    prepared, query_setup = [], []
    for source in selected:
        query_started = time.perf_counter()
        before = time.perf_counter()
        selection = index.select(source, 1)
        candidates = tuple(sorted(map(str, selection.candidates)))
        candidate_audit = audit_candidate_preservation(backbone, source, candidates)
        fallback = candidate_audit["status"] != "PASS"
        if fallback:
            candidates = tuple(sorted(map(str, backbone.target_entities)))
            candidate_audit = audit_candidate_preservation(backbone, source, candidates)
        candidate_seconds = time.perf_counter() - before
        before = time.perf_counter()
        certificate, scoped = build_incident_degree_certificate(
            backbone.triples, dataset_revision=revision, query_id=source,
            candidates=candidates, scorer_id="pkgea/attribute-structural", scorer_version="1.0")
        edge_indices = tuple(sorted(scoped))
        original = build_degree_kernel(backbone, source, candidates, edge_indices)
        scope_seconds = time.perf_counter() - before
        before = time.perf_counter()
        compiled = compile_difference_kernel(original)
        compile_seconds = time.perf_counter() - before
        before = time.perf_counter()
        q = probabilities[list(edge_indices)].copy()
        low, high = clipped_box(q, settings["tau"])
        epsilon, box_audit = conservative_scope_tv(q, low, high)
        box_seconds = time.perf_counter() - before
        before = time.perf_counter()
        audit_seed = stream_seed(graph, revision, source, 0, "icde_online_coupled_audit")
        full_states = np.random.default_rng(audit_seed).random(
            (settings["audit_worlds"], len(probabilities)), dtype=np.float64) < probabilities
        coupled = audit_coupled_scores(backbone, original, full_states)
        compiled_scores = compiled.scores(full_states[:, edge_indices])
        if not np.array_equal(compiled_scores, original.scores(full_states[:, edge_indices])):
            raise AssertionError("compiled scorer changed original arithmetic")
        audit_seconds = time.perf_counter() - before
        for array in (q, low, high):
            array.setflags(write=False)
        info = {
            "query_id": source, "candidate_ids": list(candidates),
            "candidate_tie_order": "lexicographic_unicode_first",
            "candidate_count_before_pruning": len(backbone.target_entities),
            "candidate_pruning_fell_back_to_full_pool": fallback,
            "candidate_audit": candidate_audit, "scope_certificate": certificate.as_dict(),
            "scope_edge_indices": list(edge_indices), "scope_edge_count": len(edge_indices),
            "candidate_count": len(candidates), "cost_model": compiled.compilation_summary,
            "scope_epsilon_upper": epsilon, "box_audit": box_audit,
            "coupled_audit": coupled, "audit_random_draws": full_states.size,
            "setup_seconds": {"candidate": candidate_seconds, "scope_kernel": scope_seconds,
                              "compile": compile_seconds, "box": box_seconds,
                              "coupled_audit": audit_seconds,
                              "total": time.perf_counter() - query_started},
        }
        prepared.append(PreparedQuery(graph, source, revision, compiled, q, low, high, epsilon, info))
        query_setup.append(info)
    if dataset_revision_digest(dataset) != revision:
        raise ValueError("input changed during graph setup")
    report = {
        "graph": graph, "dataset_path": dataset.relative_to(root).as_posix(),
        "dataset_revision": revision, "input_sha256": hashes,
        "query_selection": {"pool": "alignments.tsv:split==test:source_entity_id",
                            "pool_size": len(pool), "count": len(selected),
                            "salt": settings["selection_salt"], "query_ids": list(selected),
                            "gold_targets_used_for_selection": False},
        "full_edge_count": len(probabilities), "reconstruction": reconstruction,
        "query_setup": query_setup,
        "seconds": {"identity_loading_selection": identity_seconds,
                    "static_candidate_index": index_seconds,
                    "graph_total_including_audits": time.perf_counter() - started},
    }
    return prepared, report


def _segments(blocks, start, stop):
    """Views only, avoiding a second complete U allocation for lazy replay."""
    covered = start
    for begin, uniforms, scores in blocks:
        end = begin + len(uniforms)
        left, right = max(start, begin), min(stop, end)
        if left < right:
            if left != covered:
                raise AssertionError("missing event-prefix observations")
            yield uniforms[left - begin:right - begin], scores[left - begin:right - begin]
            covered = right
    if covered != stop:
        raise AssertionError("incomplete paid event prefix")


def run_query(prepared: PreparedQuery, settings: dict, method: str, base_seed: int,
              *, clock=time.perf_counter, rng_factory=np.random.default_rng) -> dict:
    """Execute until a certificate, work cap, world cap or wall deadline."""
    if method not in METHODS:
        raise ValueError("unknown online method")
    started = clock()
    timers = {key: 0. for key in ("rng", "scoring", "event", "ci", "policy", "identity_hashing")}
    kernel, q = prepared.kernel, prepared.q
    k, m = len(kernel.candidates), len(q)
    if k < 1 or len(kernel.edge_indices) != m:
        raise ValueError("invalid prepared query shape")
    model = prepared.metadata["cost_model"]
    original_entries = model["original_incidence_entries"]
    interval_entries = model["interval_incidence_entries"]
    nominal_unit = max(1, m + original_entries + settings["work_model"]["nominal_candidate_units"] * k)
    cap = settings["sample_count"]
    equivalent = int(cap * settings["budget_fraction"])
    budget = (equivalent + 1) * nominal_unit
    work = float(nominal_unit)
    interval_weight = settings["interval_work_weight"]
    worst_event_unit = 2 * m + 2 * interval_entries + settings["work_model"]["interval_candidate_units"] * k
    plan = settings["risk_plan"]
    protected = plan["event_checkpoints"]
    alpha = plan["alpha_per_checkpoint"]
    nominal_delta = settings["delta_total"] if method == "scope_full_risk" else settings["delta_nominal"]
    pair_alpha = nominal_delta / max(k * (k - 1) // 2, 1)
    nominal = settings["nominal"]
    checks = set(range(nominal["minimum_samples"], cap + 1, nominal["check_every"]))
    checks.update((cap, equivalent))
    checks.update(value for value in protected if value <= cap)
    seed = stream_seed(prepared.graph, prepared.dataset_revision, prepared.query_id,
                       base_seed, "icde_online_worlds_v1")
    before = clock()
    rng = rng_factory(seed)
    timers["rng"] += clock() - before
    uniforms_hash, winner_hash = hashlib.sha256(), hashlib.sha256()
    counts = np.zeros(k, dtype=np.int64)
    blocks = []
    n = event_n = event_count = event_rows_computed = event_free_rows = 0
    event_calls = score_calls = rejected = 0
    event_upper = 1.
    lower = None
    leader = 0
    robust = False
    nominal_certificate = None
    nominal_certificate_n = None
    nominal_certificate_seconds = None
    status = "world_cap"
    trace = []
    deadline = settings["deadline_seconds"]

    def elapsed():
        return clock() - started

    def expired():
        return deadline is not None and elapsed() > deadline

    if k == 1:
        robust = not expired()
        nominal_certificate = 0 if robust else None
        nominal_certificate_n = 0 if robust else None
        nominal_certificate_seconds = elapsed() if robust else None
        status = "structurally_single_candidate" if robust else "deadline_postblock"
    else:
        for next_n in sorted(value for value in checks if 0 < value <= cap):
            if expired():
                status = "deadline_before_block"
                break
            nominal_charge = (next_n - n) * nominal_unit
            if work + nominal_charge > budget:
                status = "nominal_work_budget"
                break
            before = clock()
            uniforms = rng.random((next_n - n, m), dtype=np.float64)
            states = uniforms < q[None, :]
            timers["rng"] += clock() - before
            before = clock()
            scores = kernel.scores(states)
            if scores.shape != (len(uniforms), k) or not np.isfinite(scores).all():
                raise ValueError("invalid nominal scorer output")
            winners = np.argmax(scores, axis=1)
            counts += np.bincount(winners, minlength=k)
            score_calls += 1
            timers["scoring"] += clock() - before
            if method != "scope_full_risk":
                blocks.append((n, uniforms, scores))
            work += nominal_charge
            n = next_n
            before = clock()
            uniforms_hash.update(uniforms.tobytes(order="C"))
            winner_hash.update(winners.astype(np.int64, copy=False).tobytes(order="C"))
            timers["identity_hashing"] += clock() - before
            if expired():
                status = "deadline_postblock"
                break
            before = clock()
            leader = int(np.argmax(counts))
            competitor = max(int(counts[index]) for index in range(k) if index != leader)
            lower = max(-1., (int(counts[leader]) - competitor) / n
                        - normal_radius(n, pair_alpha, nominal["rho"]))
            timers["ci"] += clock() - before
            if lower > 0 and nominal_certificate is None and not expired():
                nominal_certificate, nominal_certificate_n = leader, n
                nominal_certificate_seconds = elapsed()
            before = clock()
            epsilon = min(prepared.scope_epsilon, event_upper)
            could_certify = lower > 2 * epsilon
            admission = "not_requested"
            selected = None
            upper_fee = actual_fee = 0.
            timers["policy"] += clock() - before
            if not could_certify and method != "scope_full_risk":
                before = clock()
                eligible = [value for value in protected if event_n < value <= n]
                timers["policy"] += clock() - before
                if method == "difference_lazy":
                    before = clock()
                    eligible = [value for value in eligible if lower > 0 and
                                2 * event_bounds.fixed_n_binomial_upper(0, value, alpha) < lower]
                    timers["ci"] += clock() - before
                if eligible and not expired():
                    selected = eligible[0]
                    upper_fee = (selected - event_n) * worst_event_unit * interval_weight
                    if work + upper_fee > budget:
                        admission = "rejected_budget"
                        rejected += 1
                    else:
                        admission = "approved"
                        before = clock()
                        new_events = new_free = 0
                        for old_u, old_scores in _segments(blocks, event_n, selected):
                            flags = kernel.ambiguity_indicators(
                                q, prepared.low, prepared.high, old_u, nominal_scores=old_scores)
                            if flags.dtype != np.bool_ or flags.shape != (len(old_u),):
                                raise ValueError("invalid event indicator output")
                            free = np.any((old_u < prepared.low[None, :])
                                          != (old_u < prepared.high[None, :]), axis=1)
                            new_events += int(np.count_nonzero(flags))
                            new_free += int(np.count_nonzero(free))
                            event_calls += 1
                            event_rows_computed += len(old_u)
                        units = (2 * m * (selected - event_n)
                                 + (2 * interval_entries + settings["work_model"]["interval_candidate_units"] * k) * new_free)
                        actual_fee = units * interval_weight
                        if actual_fee > upper_fee or work + actual_fee > budget:
                            raise AssertionError("static work admission failed")
                        work += actual_fee
                        event_count += new_events
                        event_free_rows += new_free
                        event_n = selected
                        timers["event"] += clock() - before
                        before = clock()
                        event_upper = event_bounds.fixed_n_binomial_upper(event_count, event_n, alpha)
                        timers["ci"] += clock() - before
                        could_certify = lower > 2 * min(prepared.scope_epsilon, event_upper)
            late = expired()
            if late:
                status = "deadline_postblock"
            elif could_certify:
                robust, status = True, "certified"
            trace.append({
                "nominal_samples": n, "event_samples": event_n,
                "elapsed_seconds": elapsed(), "work_completed": work,
                "lower_gap": lower, "event_upper": event_upper,
                "scope_epsilon_upper": prepared.scope_epsilon,
                "leader_index": leader, "event_upgrade_to": selected,
                "event_admission": admission, "event_upper_fee": upper_fee,
                "event_actual_fee": actual_fee, "status": status,
                "certificate_discarded_after_deadline": bool(late and could_certify),
                "uniform_prefix_sha256": uniforms_hash.hexdigest(),
                "winner_prefix_sha256": winner_hash.hexdigest(),
            })
            if robust or late:
                break
    seconds = elapsed()
    if robust and deadline is not None and seconds > deadline:
        robust, status = False, "deadline_postblock"
        if trace:
            trace[-1]["status"] = status
            trace[-1]["certificate_discarded_after_deadline"] = True
    if work > budget:
        raise AssertionError("hard modeled-variable-work budget exceeded")
    return {
        "graph": prepared.graph, "query_id": prepared.query_id,
        "dataset_revision": prepared.dataset_revision, "seed": base_seed,
        "rng_seed_hex": hex(seed), "method": method, "policy": method, "tau": settings["tau"],
        "candidate_count": k, "scope_edge_count": m,
        "stable": robust, "status": status,
        "certified_candidate_index": leader if robust else None,
        "certified_candidate": str(kernel.candidates[leader]) if robust else None,
        "nominal_certified": nominal_certificate is not None,
        "nominal_candidate_index": nominal_certificate,
        "nominal_certificate_samples": nominal_certificate_n,
        "nominal_certificate_seconds": nominal_certificate_seconds,
        "nominal_delta": nominal_delta, "event_beta_total": 0. if method == "scope_full_risk" else settings["beta_total"],
        "samples_used": n, "worlds_generated": n, "nominal_score_rows": n,
        "random_uniform_draws": n * m, "event_extra_random_draws": 0,
        "nominal_score_calls": score_calls, "event_calls": event_calls,
        "event_samples_used": event_n, "event_rows_computed": event_rows_computed,
        "event_count": event_count, "event_free_rows": event_free_rows,
        "event_ambiguity_upper": event_upper, "scope_epsilon_upper": prepared.scope_epsilon,
        "final_lower_gap": lower, "event_admission_rejections": rejected,
        "work_used": work, "work_budget": budget, "work_overshoot": 0.,
        "work_semantics": "modeled_variable_work_only_excludes_build_CP_policy_and_hashing",
        "nominal_unit_work": nominal_unit,
        "deadline_seconds": deadline,
        "deadline_overrun_seconds": max(0., seconds - deadline) if deadline is not None else 0.,
        "seconds": {**timers, "query_serving_total": seconds,
                    "other_overhead": max(0., seconds - sum(timers.values()))},
        "retained_uniform_values": sum(block[1].size for block in blocks),
        "retained_score_values": sum(block[2].size for block in blocks),
        "uniform_prefix_sha256": uniforms_hash.hexdigest(),
        "winner_prefix_sha256": winner_hash.hexdigest(),
        "winner_counts": counts.tolist(), "trace": trace,
    }


def run_worker(config: dict, *, repeat=0, mode="cold", method="all", root=ROOT):
    started = time.perf_counter()
    settings = settings_from_config(config)
    required = settings["required_pythonhashseed"]
    if required is not None and os.environ.get("PYTHONHASHSEED") != str(required):
        raise ValueError("launch with frozen PYTHONHASHSEED before importing scorer helpers")
    if mode not in ("cold", "warm") or method not in ("all", *METHODS):
        raise ValueError("invalid worker mode or method")
    event_bounds._bound_details.cache_clear()
    before = time.perf_counter()
    if mode == "warm":
        for checkpoint in settings["risk_plan"]["event_checkpoints"]:
            event_bounds.fixed_n_binomial_upper(0, checkpoint, settings["risk_plan"]["alpha_per_checkpoint"])
    cache_prewarm_seconds = time.perf_counter() - before
    setup_reports, rows = [], []
    methods = METHODS if method == "all" else (method,)
    for graph_index, profile in enumerate(settings["profiles"]):
        prepared, report = setup_graph(profile, settings, root)
        setup_reports.append(report)
        for seed_index, seed in enumerate(settings["seeds"]):
            for query_index, query in enumerate(prepared):
                offset = (repeat + graph_index + seed_index + query_index) % len(methods)
                ordered = methods[offset:] + methods[:offset]
                for position, selected_method in enumerate(ordered):
                    row = run_query(query, settings, selected_method, seed)
                    rows.append({"repeat": repeat, "mode": mode,
                                 "method_execution_position": position, **row})
    return {
        "schema_version": SCHEMA, "status": "COMPLETE", "repeat": repeat, "mode": mode,
        "config": config, "risk_plan": settings["risk_plan"],
        "unique_queries": sum(len(report["query_setup"]) for report in setup_reports),
        "query_seed_method_cases": len(rows),
        "world_law": {"dependence": "independent", "semantics": "declared",
                      "probability_column": "triples.tsv:confidence"},
        "numeric_contract": {"scores": "original_float64_operation_order",
                             "candidate_ties": "lexicographic_unicode_first"},
        "graph_setup": setup_reports, "query_policy_rows": rows,
        "timing_contract": {
            "graph_setup_includes_full_corpus_tfidf_candidates_scope_compile_and_coupled_audits": True,
            "graph_setup_shared_between_methods_in_this_worker": len(methods) > 1,
            "query_serving_excludes_shared_graph_setup": True,
            "cold_definition": "fresh_worker_initial_CP_cache_empty_no_OS_cache_eviction",
            "warm_definition": "prepared_static_graph_reuse_and_zero_count_CP_prewarm",
            "CP_cache_within_worker": "retained_across_queries_methods_and_seeds",
            "policy_order": "deterministic_rotation_by_repeat_graph_seed_query",
            "external_process_wall_required_for_complete_cold_comparison": True,
            "no_full_stream_precapture": True,
        },
        "seconds": {"module_import": IMPORT_SECONDS, "CP_prewarm": cache_prewarm_seconds,
                    "worker_before_serialization": time.perf_counter() - started},
        "new_training": False, "real_probability_calibration_claim": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--repeat", type=int, default=0, help="repeat identifier, not a seed offset")
    parser.add_argument("--mode", choices=("cold", "warm"), default="cold")
    parser.add_argument("--method", choices=("all", *METHODS), default="all")
    args = parser.parse_args()
    output = _inside(ROOT, args.output)
    if output.exists():
        raise FileExistsError("use a fresh online result path")
    config = json.loads(_inside(ROOT, args.config).read_text("utf-8-sig"))
    result = run_worker(config, repeat=args.repeat, mode=args.mode, method=args.method)
    output.parent.mkdir(parents=True, exist_ok=True)
    before = time.perf_counter()
    payload = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    with output.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(payload)
    print(json.dumps({"output": output.relative_to(ROOT).as_posix(),
                      "rows": len(result["query_policy_rows"]),
                      "serialization_io_seconds": time.perf_counter() - before,
                      "module_to_output_seconds": time.perf_counter() - MODULE_STARTED}))


if __name__ == "__main__":
    main()
