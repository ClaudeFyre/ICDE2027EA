"""Frozen RREA source-backed integration contract; no old evidence imports."""
import csv, hashlib, json, os, sys, time, ast
from pathlib import Path
from fractions import Fraction
ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'scripts/www_quality_recovery_v13_vendor'
CONFIG = ROOT / 'papers/www/quality_recovery_v13_config.json'
BUNDLE = ROOT / 'papers/www/quality_recovery_v13_bundle_r2.json'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8',newline='\n') as f: json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def contained(p):
    p=Path(p);p=(ROOT/p).resolve() if not p.is_absolute() else p.resolve()
    if p!=ROOT and ROOT not in p.parents: raise ValueError('outside repository')
    return p

def verify_source():
    nb=load(VENDOR/'CIKM/RREA.ipynb');cell=''.join(nb['cells'][2]['source']);lines=cell.splitlines(keepends=True)
    nodes=[n for n in ast.parse(cell).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ('TokenEmbedding','get_trgat')]
    if [n.name for n in nodes]!=['TokenEmbedding','get_trgat']: raise ValueError('official extraction differs')
    native=''.join(''.join(lines[n.lineno-1:n.end_lineno])+'\n\n' for n in nodes)
    header='import keras\nimport keras.backend as K\nfrom keras.layers import *\nfrom layer import NR_GraphAttention\nfrom keras.optimizers.optimizer_v1 import RMSprop as RMSprop224Compatible\nimport tensorflow.compat.v1 as tf\n'
    expected=header+native.replace('keras.optimizers.rmsprop(lr)','RMSprop224Compatible(lr=lr)')
    if (VENDOR/'official_model_extracted.py').read_text(encoding='utf-8')!=expected: raise ValueError('model beyond declared patch')
    for name in ['layer.py','utils.py']:
        expected=(VENDOR/'CIKM'/name).read_text(encoding='utf-8').replace('import tensorflow as tf','import tensorflow.compat.v1 as tf')
        if (VENDOR/name).read_text(encoding='utf-8')!=expected: raise ValueError('undeclared source patch '+name)
    return {'status':'RREA_SOURCE_PATCH_PASS','commit':'2271ac33dae0baf53dfa5b7ca1955090a1567a0a','variant':'supervised first round, no pseudo-pairs','official_reproduction_verified':False}

def verify_bundle():
    m=load(BUNDLE)
    for n,h in m['files'].items():
        p=contained(n)
        if not p.is_file() or sha(p)!=h: raise ValueError('frozen hash mismatch '+n)
    verify_source()
    return {'status':'QUALITY_V13_BUNDLE_PASS','files':len(m['files']),'bundle_sha256':sha(BUNDLE)}

def rows(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))

def graph(key):
    import numpy as np
    d=ROOT/load(CONFIG)['datasets'][key]
    e=rows(d/'entities.tsv');rels=rows(d/'relations.tsv');tr=rows(d/'triples.tsv');al=rows(d/'alignments.tsv')
    ids=[r['entity_id'] for r in e];idx={v:i for i,v in enumerate(ids)}
    if len(idx)!=len(ids):raise ValueError('duplicate entity ID')
    rkeys=[(r['graph_id'],r['relation_id']) for r in rels];ri={v:i+1 for i,v in enumerate(rkeys)}
    if len(ri)!=len(rkeys):raise ValueError('duplicate role-specific relation')
    triples=np.array([(idx[t['head_id']],ri[t['graph_id'],t['relation_id']],idx[t['tail_id']]) for t in tr],dtype=np.int64)
    targets=np.array([i for i,r in enumerate(e) if r['graph_id']=='target'],dtype=np.int64)
    sources=np.array([i for i,r in enumerate(e) if r['graph_id']=='source'],dtype=np.int64)
    pairs={split:np.array([(idx[r['source_entity_id']],idx[r['target_entity_id']]) for r in al if r['split']==split],dtype=np.int64) for split in ['train','validation','test']}
    if any(len(set(p[:,0]))!=len(p) or len(set(p[:,1]))!=len(p) for p in pairs.values()):raise ValueError('non one-to-one truth')
    allp=np.concatenate(list(pairs.values()))
    if len(set(allp[:,0]))!=len(allp) or len(set(allp[:,1]))!=len(allp):raise ValueError('split overlap')
    roles=[r['graph_id'] for r in e]
    if any(roles[h]!=r['graph_id'] or roles[t]!=r['graph_id'] for (h,_,t),r in zip(triples,tr)):raise ValueError('cross-graph edge')
    expected=load(CONFIG)['expected_statistics'][key]
    actual={'entities':len(e),'triples':len(tr),'splits':{k:len(v) for k,v in pairs.items()},'full_target_candidates':len(targets)}
    if actual!=expected:raise ValueError('input statistics differ '+key)
    if not np.isfinite(triples).all() or len(ri)==0:raise ValueError('empty graph')
    return {'entity_ids':ids,'triples':triples,'sources':sources,'targets':targets,'pairs':pairs,'relations':rkeys,'statistics':actual}

def normalized(raw):
    import numpy as np
    v=np.asarray(raw,dtype=np.float64)
    if v.ndim!=2 or not np.isfinite(v).all():raise ValueError('invalid embedding')
    norms=np.linalg.norm(v,axis=1)
    if (norms==0).any():raise ValueError('zero-norm embedding')
    return v/norms[:,None]

def ranked(scores,pairs,targets,higher=False):
    import numpy as np
    lookup={int(v):i for i,v in enumerate(targets)};pos=np.arange(len(targets));out=[]
    for (s,t),row in zip(pairs,scores):
        if not np.isfinite(row).all():raise ValueError('nonfinite score')
        p=lookup[int(t)];less=row>row[p] if higher else row<row[p]
        winner=int(np.argmax(row) if higher else np.argmin(row))
        rank=1+int(np.sum(less|((row==row[p])&(pos<p))))
        out.append({'source_index':int(s),'truth_position':p,'winner':winner,'rank':rank,'hit':int(winner==p),'reciprocal_rank':1/rank})
    return out

def metrics(records):
    if not records:raise ValueError('empty metric')
    hits=sum(r['hit'] for r in records)
    return {'requests':len(records),'hits':hits,'hits_at_1':hits/len(records),'mrr':sum(r['reciprocal_rank'] for r in records)/len(records),'rows':records}

def point_ranks(v,pairs,targets):
    import numpy as np
    v=np.asarray(v,dtype=np.float64);t=v[targets];tn=np.sum(t*t,axis=1);out=[]
    for start in range(0,len(pairs),32):
        b=pairs[start:start+32];q=v[b[:,0]]
        dist=np.maximum(np.sum(q*q,axis=1)[:,None]+tn-2*(q@t.T),0)
        out.extend(ranked(dist,b,targets))
    return metrics(out)

def csls_ranks(v,pairs,targets,source_pool,k=10):
    # Author-normalized cosine CSLS, explicitly using ALL source/target entities.
    import numpy as np
    v=normalized(v);s=v[source_pool];t=v[targets];k=min(k,len(s),len(t));rr=np.zeros(len(t));ls={}
    tops=np.full((k,len(t)),-np.inf)
    for start in range(0,len(s),64):
        b=s[start:start+64]@t.T
        local=np.partition(b,-k,axis=1)[:,-k:].mean(1)
        ls.update({int(i):float(z) for i,z in zip(source_pool[start:start+64],local)})
        tops=np.partition(np.concatenate([tops,b]),-k,axis=0)[-k:]
    rr=tops.mean(0);out=[]
    for start in range(0,len(pairs),32):
        b=pairs[start:start+32]
        sim=2*(v[b[:,0]]@t.T)-np.array([ls[int(i)] for i in b[:,0]])[:,None]-rr
        out.extend(ranked(sim,b,targets,higher=True))
    return metrics(out)

def choose_dimension(hidden,projected,n,max_loss_pp='2'):
    limit=Fraction(str(max_loss_pp))/100
    return next((d for d in (16,32) if Fraction(hidden-int(projected[str(d)]),n)<=limit),None)

def strength(hits,n):return Fraction(hits,n)>=Fraction('0.25')
def repeat_ok(h1,n1,h2,n2):return Fraction(h2,n2)>=Fraction(h1,n1)-Fraction('0.05')

def capture_projection(raw,g,p):
    import numpy as np
    hidden=normalized(raw);fit=np.concatenate([g['pairs']['train'][:,0],g['targets']]);mean=hidden[fit].mean(0)
    _,singular,right=np.linalg.svd(hidden[fit]-mean,full_matrices=False)
    # Fix signs by the largest absolute loading; all worlds use this saved basis.
    for i in range(len(right)):
        j=int(np.argmax(np.abs(right[i])))
        if right[i,j]<0:right[i]*=-1
    with Path(p).open('xb') as f:np.savez_compressed(f,raw=raw,hidden=hidden,basis=right.T,fit_mean=mean,fit_rows=fit,entity_ids=np.array(g['entity_ids']),target_indices=g['targets'],singular_values=singular)
    val={'hidden':point_ranks(hidden,g['pairs']['validation'],g['targets'])}
    for d in (16,32):val[str(d)]=point_ranks(hidden@right[:d].T,g['pairs']['validation'],g['targets'])
    chosen=choose_dimension(val['hidden']['hits'],{str(d):val[str(d)]['hits'] for d in (16,32)},len(g['pairs']['validation']))
    return {'chosen_dimension':chosen,'validation':val,'selection_uses_test':False,'integer_gate':True,'output_rule':'row-normalize binary64 before frozen linear projection; projected rows not renormalized','fit_scope':'train sources + all target entities, no labels outside training'}

def supervised(command,log_path,seconds,env=None):
    import subprocess,psutil,signal
    start=time.monotonic();peak=0;reason=None
    with Path(log_path).open('x',encoding='utf-8') as log:
        p=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=(os.name!='nt'))
        owned=psutil.Process(p.pid)
        while p.poll() is None:
            try:peak=max(peak,owned.memory_info().rss)
            except psutil.NoSuchProcess:pass
            except (psutil.AccessDenied,PermissionError,OSError):reason='MONITOR_UNAVAILABLE'
            if reason is not None or time.monotonic()-start>=seconds or peak>load(CONFIG)['budgets']['rss_limit_bytes']:
                if reason is None:reason='TIME_LIMIT' if time.monotonic()-start>=seconds else 'RSS_LIMIT'
                # Never enumerate unrelated host processes. POSIX workers own
                # a fresh process group; Windows taskkill targets this PID tree.
                if os.name=='nt':
                    try:
                        kill=subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT,timeout=10)
                        if kill.returncode!=0 and p.poll() is None:reason='TREE_TERMINATION_UNAVAILABLE'
                    except (OSError,subprocess.TimeoutExpired):reason='TREE_TERMINATION_UNAVAILABLE'
                else:
                    try:os.killpg(p.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                if p.poll() is None:p.kill()
                break
            time.sleep(.2)
        code=p.wait()
    return {'status':reason or ('COMPLETED' if code==0 else 'WORKER_FAILED'),'exit_code':code,'wall_seconds':time.monotonic()-start,'peak_rss_bytes':peak,'command':command}
