"""Stored-evidence failure diagnosis; no new solver run or changed protocol."""
from collections import Counter
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'nodes/09_vldb_query_certification/results/icde_block_comparison_20261109'
SOURCE = BASE / 'matched_anchor_pruning_attempt1/summary.json'
OUT = BASE / 'failure_diagnosis_attempt1'


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    rows = json.loads(SOURCE.read_text(encoding='utf-8'))['rows']
    block = {(r['graph'], r['rank']): r for r in rows if r['policy'] == 'block_event2'}
    eager = {(r['graph'], r['rank']): r for r in rows if r['policy'] == 'generic_eager'}
    missed = [block[k] for k in block if eager[k]['details']['status'] == 'stable' and block[k]['details']['status'] != 'stable']
    unresolved = [r for r in block.values() if r['details']['status'] == 'unresolved']
    assert len(missed) == 9 and len(unresolved) == 109
    a = sum(Q(r['details']['sum_block_error_upper_exact']) >= 1 for r in unresolved)
    b = sum(any(Q(t['error_upper_exact']) >= Q(1, 2) for t in r['details']['blocks']) for r in unresolved)
    data = {'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'eager_only_block_statuses': dict(Counter(r['details']['status'] for r in missed)),
            'eager_only_queries': [{'graph': r['graph'], 'rank': r['rank'],
                'failed_block_states': r['details'].get('failed_block_states'),
                'failed_block_estimated_work': r['details'].get('failed_block_estimated_work'),
                'completed_blocks': len(r['details'].get('blocks', []))} for r in missed],
            'unresolved_queries': 109, 'sum_block_errors_at_least_one': a,
            'some_local_error_at_least_half': b,
            'single_block_unresolved': sum(len(r['details']['blocks']) == 1 for r in unresolved),
            'interpretation': 'Resource admission explains all 9 eager-only misses. These aggregate diagnostics do not prove overlap is the cause of unresolved bounds, nor establish global nonuniformity.'}
    assert a == 83 and b == 94
    OUT.mkdir()
    (OUT / 'diagnosis.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    text = '''# 失败诊断：从现有冻结证据可确定的范围

2026-11-09；仅分析匹配剪枝主比较，不再执行或调优方法。

- MC独有的9个成功查询，分块法全部因局部块资源门槛未准入。其余109个算完未决案例不能解释这9次差距。
- 109个算完未决中，83个的Σ e_B≥1，使当前赢家概率下界截断为0；94个至少一个局部e_B≥1/2。
- 后两个集合可能重叠；它们说明界弱，但没有证明跨块事件确实重叠多少。局部大错误、最坏参数错位、重复计费需要分开检验。
- 其中3例只有一个块，仍不能认证；说明并非全部问题都能靠合并块修复。负下界也不证明完整查询非鲁棒。

下一项有针对性的验证先处理这9个查询：固定原候选、参数盒、预算与共同剪枝，检查失败块的静态结构，比较标准消元/部分编译能否避免完整局部张量；不能先扩大分块或堆调度。对未决集合另用有精确参考的查询区分局部事件松弛与组合损失；未知真值的案例不编造原因比例。

这些结果是开发诊断，不是新算法或确认实验。详情与哈希见diagnosis.json。
'''
    (OUT / 'DIAGNOSIS_ZH.md').write_text(text, encoding='utf-8')
    print(json.dumps({k: v for k, v in data.items() if k != 'eager_only_queries'}, indent=2))


if __name__ == '__main__':
    main()
