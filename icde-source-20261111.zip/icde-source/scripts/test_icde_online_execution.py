"""Finite tests for genuinely incremental work and paid complete prefixes."""

from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from icde_online_execution import (
    METHODS, PreparedQuery, _segments, run_query, settings_from_config,
)


class Clock:
    def __init__(self):
        self.value = 0.

    def __call__(self):
        return self.value


class Kernel:
    candidates = ("a", "b")
    edge_indices = (0,)

    def __init__(self, *, clock=None, score_delay=0., event_delay=0., flags=False):
        self.score_rows = []
        self.event_rows = []
        self.clock = clock
        self.score_delay, self.event_delay = score_delay, event_delay
        self.flags = flags

    def scores(self, states):
        self.score_rows.append(len(states))
        if self.clock:
            self.clock.value += self.score_delay
        scores = np.zeros((len(states), 2), dtype=np.float64)
        scores[:, 0] = 1.
        return scores

    def ambiguity_indicators(self, q, low, high, uniforms, nominal_scores=None):
        self.event_rows.append(len(uniforms))
        if nominal_scores is None or len(nominal_scores) != len(uniforms):
            raise AssertionError("event evaluation rescored or lost its paired nominal rows")
        if self.clock:
            self.clock.value += self.event_delay
        return np.full(len(uniforms), self.flags, dtype=np.bool_)


class IncrementalExecutionTests(unittest.TestCase):
    def settings(self, **extra):
        return settings_from_config({
            "sample_count": 256, "audit_worlds": 1,
            "work_model": {"nominal_candidate_units": 16, "interval_candidate_units": 1},
            **extra,
        })

    def prepared(self, *, kernel=None, scope=1.):
        return PreparedQuery(
            "toy", "s", "revision", kernel or Kernel(),
            np.array([.5]), np.array([0.]), np.array([1.]), scope,
            {"cost_model": {"original_incidence_entries": 0,
                            "interval_incidence_entries": 0}},
        )

    def test_stopping_does_not_generate_or_score_the_unused_world_cap(self):
        query = self.prepared()
        row = run_query(query, self.settings(), "difference_eager", 61)
        self.assertTrue(row["stable"])
        self.assertEqual(row["worlds_generated"], 96)
        self.assertEqual(sum(query.kernel.score_rows), 96)
        self.assertEqual(sum(query.kernel.event_rows), 96)
        self.assertEqual(row["event_extra_random_draws"], 0)
        self.assertLess(row["worlds_generated"], 256)

    def test_lazy_completes_past_rows_without_rescoring_or_new_draws(self):
        query = self.prepared()
        row = run_query(query, self.settings(), "difference_lazy", 73)
        self.assertTrue(row["stable"])
        self.assertEqual(row["event_samples_used"], 96)
        self.assertEqual(row["event_rows_computed"], 96)
        self.assertEqual(row["random_uniform_draws"], 96)
        self.assertEqual(row["nominal_score_rows"], sum(query.kernel.score_rows))
        self.assertLessEqual(row["retained_uniform_values"], 256)
        self.assertTrue(all(step["event_samples"] in (0, 96, 224)
                            and step["event_samples"] <= step["nominal_samples"]
                            for step in row["trace"]))

    def test_static_rejection_never_evaluates_hidden_event_flags(self):
        query = self.prepared()
        row = run_query(query, self.settings(interval_work_weight=100000.), "difference_eager", 61)
        self.assertFalse(row["stable"])
        self.assertEqual(query.kernel.event_rows, [])
        self.assertEqual(row["event_samples_used"], 0)
        self.assertEqual(row["worlds_generated"], 256)
        self.assertGreater(row["event_admission_rejections"], 0)
        self.assertLessEqual(row["work_used"], row["work_budget"])

    def test_paired_methods_have_identical_generated_prefixes(self):
        settings = self.settings()
        rows = [run_query(self.prepared(), settings, method, 89) for method in METHODS]
        prefixes = [next(step for step in row["trace"] if step["nominal_samples"] == 96)
                    for row in rows]
        self.assertEqual(len({step["uniform_prefix_sha256"] for step in prefixes}), 1)
        self.assertEqual(len({step["winner_prefix_sha256"] for step in prefixes}), 1)
        self.assertEqual(rows[0]["nominal_delta"], .05)
        self.assertEqual(rows[1]["nominal_delta"], .025)

    def test_late_nominal_block_cannot_publish_a_certificate(self):
        clock = Clock()
        query = self.prepared(kernel=Kernel(clock=clock, score_delay=2.), scope=0.)
        row = run_query(query, self.settings(deadline_seconds=1.), "scope_full_risk", 61, clock=clock)
        self.assertFalse(row["stable"])
        self.assertFalse(row["nominal_certified"])
        self.assertEqual(row["status"], "deadline_postblock")
        self.assertGreater(row["deadline_overrun_seconds"], 0)
        self.assertEqual(row["nominal_score_rows"], 32)

    def test_late_event_block_discards_its_would_be_robust_certificate(self):
        clock = Clock()
        query = self.prepared(kernel=Kernel(clock=clock, event_delay=2.))
        row = run_query(query, self.settings(deadline_seconds=1.), "difference_eager", 61, clock=clock)
        self.assertFalse(row["stable"])
        self.assertEqual(row["status"], "deadline_postblock")
        self.assertTrue(row["trace"][-1]["certificate_discarded_after_deadline"])
        self.assertLessEqual(row["work_used"], row["work_budget"])

    def test_scope_success_pays_no_event_cost_and_retains_no_uniform_buffer(self):
        query = self.prepared(scope=0.)
        row = run_query(query, self.settings(), "scope_full_risk", 61)
        self.assertTrue(row["stable"])
        self.assertEqual(row["event_rows_computed"], 0)
        self.assertEqual(row["retained_uniform_values"], 0)
        self.assertEqual(row["work_used"], (row["samples_used"] + 1) * row["nominal_unit_work"])

    def test_event_segment_reader_fails_on_a_missing_prefix(self):
        blocks = [(32, np.zeros((64, 1)), np.zeros((64, 2)))]
        with self.assertRaisesRegex(AssertionError, "missing"):
            list(_segments(blocks, 0, 96))

    def test_invalid_risk_or_cap_is_rejected(self):
        with self.assertRaises(ValueError):
            self.settings(delta_nominal=.04)
        with self.assertRaises(ValueError):
            self.settings(sample_count=4097)


if __name__ == "__main__":
    unittest.main()
