"""Create a deduplicated research bibliography without changing any old source."""
import hashlib
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'papers/icde/regular2027'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    priority=['references.bib','references_design_extra_20261107.bib',
              'references_followup_extra_20261108.bib','references_grouped_extra_20261108.bib',
              'references_overview_extra_20261108.bib','references_extra.bib',
              'references_gate_extra.bib','references_model_extra.bib']
    entries={}
    sources={}
    for name in priority:
        text=(BASE/name).read_text(encoding='utf-8-sig')
        matches=list(re.finditer(r'(?m)^@(\w+)\s*\{\s*([^,\s]+)\s*,',text))
        for i,match in enumerate(matches):
            end=matches[i+1].start() if i+1<len(matches) else len(text)
            # Scan to the top-level closing brace, excluding subsequent comments.
            level=0
            block=text[match.start():end]
            for j,char in enumerate(block):
                if char=='{':level+=1
                elif char=='}':
                    level-=1
                    if level==0:
                        block=block[:j+1]
                        break
            if level!=0:
                raise AssertionError('unbalanced bibliography entry')
            key=match.group(2)
            sources.setdefault(key,[]).append(name)
            entries.setdefault(key,block)
    target=BASE/'references_overview_merged_20261108.bib'
    result='% Research overview library, not imported into the frozen manuscript.\n'
    result+='% Deduplicated by citation key; source priority and audit limits are in the adjacent JSON.\n\n'
    result+=''.join('% Source: '+sources[key][0]+'\n'+block+'\n\n' for key,block in entries.items())
    if target.exists():
        if target.read_text(encoding='utf-8')!=result:
            raise AssertionError('existing merged bibliography differs; use a new output path')
    else:
        with target.open('x',encoding='utf-8') as out:
            out.write(result)
    doc=BASE/'RESEARCH_ORIGIN_CONTENT_AND_PRIOR_20261108.md'
    for link in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):
        if not link.startswith('https://') and not (doc.parent/link).exists():
            raise AssertionError(f'broken local link {link}')
    focus=doc.read_text(encoding='utf-8').split('## 11. ')[1].split('## 12. ')[0]
    numbered=re.findall(r'(?m)^(\d+)\. .*?\*\*',focus)
    if numbered!=[str(i) for i in range(1,33)]:
        raise AssertionError('focus bibliography numbering is incomplete')
    source_paths=[BASE/name for name in priority]
    local_evidence=[ROOT/'papers/wsdm/submission/main.tex',
                    ROOT/'papers/ijcai/background/wsdm209_reviews_20261103.txt',
                    BASE/'AUTHOR_ICDM_COMPARISON_20261107.md',
                    BASE/'PROSPECTIVE_DECISION_20261107.md',
                    BASE/'REFINABLE_G1_DECISION_20261107.md',
                    BASE/'PARAMETER_COVER_DECISION_20261108.md',
                    BASE/'PARTIAL_COMPILATION_DECISION_20261108.md',
                    BASE/'PORTFOLIO_HEADROOM_DECISION_20261108.md']
    obj={'date':'2026-11-08','kind':'research_overview_and_citation_inventory',
         'main_bibliography_entries':31,'overview_focus_references':32,
         'merged_unique_citation_keys':len(entries),'merged_file':target.name,
         'source_priority':priority,'citation_key_sources':sources,
         'input_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in source_paths+local_evidence},
         'output_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in (doc,target,Path(__file__))},
         'verification_scope':[
             'Current turn: WSDM authoritative source and full user-provided reviews; current manuscript and dated decisions read',
             'Primary pages rechecked for PAC mode, bounded-vector CS, smoothing, ENFrame, partial compilation, sensitivity, counting/lifted inference and credal robustness',
             'PCMEA methods and UPL-EA methods/conclusion inspected; SATzilla author abstract and formal publication record checked',
             'Calibration and Knowledge Vault primary records checked; Rice formal metadata surfaced but publisher full text unavailable',
             f'{len(entries)}-entry merged library is an inventory, not a claim that all full papers were freshly read',
             'Older primary-reading notes supply remaining context; 2026 design preprints retain preprint status; no exhaustive literature-coverage claim',
             'Author-provided ICDM non-overlap conclusion accepted; no claim assistant acquired the formal full text',
             'No new numerical experiments; old manuscript, bibliography and numerical sources not modified'],
         'validation':{'balanced_bibtex_blocks':True,'unique_keys':True,
                       'focus_numbering_1_to_32':True,'new_document_local_links':True}}
    with (BASE/'RESEARCH_OVERVIEW_SOURCES_20261108.json').open('x',encoding='utf-8') as out:
        json.dump(obj,out,ensure_ascii=False,indent=2)
        out.write('\n')
    print(json.dumps({'status':'PASS','main_entries':31,'focus_references':32,
                      'merged_unique_keys':len(entries),'local_links':'PASS'},ensure_ascii=False))


if __name__=='__main__':main()
