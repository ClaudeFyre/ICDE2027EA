"""Rebuild every decisive deterministic reference and verify audit accounting."""
from collections import Counter
from fractions import Fraction as Q
import math
from pathlib import Path
import random

import numpy as np

from icde_final_random_audit_20261109_v2 import BASE,PARENT,load,save,sha,identities,finite_interval
from icde_sparse_degree_20261108 import read_graph,read_query,restrict
from icde_pruned_block_comparison_20261109 import prune
from icde_grouped_exact_20261108 import compile_counts,solve_counts
from icde_partial_count_20261108 import CountOracle
from icde_factor_partial_20261108 import FactorRegion,probability_bounds
from run_vldb_interval_gate_v1 import clipped_box


def partition(cells,shape):
    """Check complete disjoint coverage against the solver's dyadic box tree."""
    leaves={(tuple(a),tuple(b)) for a,b in cells}
    if len(leaves)!=len(cells):raise AssertionError('duplicate cells')
    seen=set()
    def visit(a,b):
        if (a,b) in leaves:seen.add((a,b));return
        if a==b:raise AssertionError('missing singleton cell')
        axis=max(range(len(a)),key=lambda g:(b[g]-a[g],-g));middle=(a[axis]+b[axis])//2
        left=list(b);right=list(a);left[axis]=middle;right[axis]=middle+1
        visit(a,tuple(left));visit(tuple(right),b)
    visit((0,)*len(shape),tuple(n-1 for n in shape))
    if seen!=leaves:raise AssertionError('invalid or overlapping cells')


def main():
    p=load(BASE/'protocol.json');s=load(BASE/'summary.json');checks=identities(p,False)
    assert p['sample']==random.Random(p['seed']).sample(p['population'],40)
    assert p['sample']==load(BASE.parent/'attempt1/protocol.json')['sample']
    assert s['protocol_sha256']==sha(BASE/'protocol.json')
    indexes={g:read_graph(g) for g in ('dw','enfr')}
    exact_count=factor_count=prune_count=0;reference_sources={}
    for i,(case,row) in enumerate(zip(p['sample'],s['rows'])):
        assert (case['graph'],case['rank'],case['query_id'])==(row['graph'],row['rank'],row['query_id'])
        path=BASE/'cases'/f"{i:02d}_{case['graph']}_q{case['rank']:03d}.json"
        assert row==load(path);reference_sources[path.relative_to(BASE).as_posix()]=sha(path)
        assert row['classification'] in ('robust','nonrobust','unknown')
        checks+=3
        if row['classification']=='unknown':continue
        assert row['fast_within_1s']==(row['reference_seconds']<=1.)
        kernel,meta=read_query(case['graph'],case['rank'],indexes[case['graph']])
        focus,selected=prune(kernel);assert selected==row['mapping']
        checks+=2
        if len(selected)==1:
            assert row['classification']=='robust';prune_count+=1;continue
        reduced,mapping=restrict(kernel,selected);k=len(selected)
        low,high=clipped_box(np.full(len(reduced.edge_indices),p['nominal']),p['tau'])
        if row['reference_kind']=='full_exact_tensor':
            c=compile_counts(reduced,low,high,p['state_cap']);e=solve_counts(c,k)
            assert e['pairs']==row['pairs']
            assert ('robust' if e['uniform_winners'] else 'nonrobust')==row['classification']
            if 'pointwise_population' in row:
                from icde_parameter_association_20261108 import pointwise_population,audit_masks
                d,masks=pointwise_population(c,e,k);assert d==row['pointwise_population']
                checks+=audit_masks(c,masks)
            checks+=3;exact_count+=1
        elif row['reference_kind']=='deterministic_factor_certificate':
            raw=row['factor_evidence'];oracle=CountOracle(reduced,low,high,row['S'])
            a=(0,)*len(oracle.shape);b=tuple(n-1 for n in oracle.shape)
            if raw['kind']=='common_root_bound':
                assert oracle.possible(a,b)==1<<raw['winner'];assert row['classification']=='robust'
                checks+=2;factor_count+=1;continue
            partition([(r['low'],r['high']) for r in raw['leaf_records']],oracle.shape)
            partition([(r['low'],r['high']) for r in raw['parameter_cells']],oracle.shape)
            oracle.prepare_probabilities();den=oracle.denominator;assert str(den)==raw['denominator_exact']
            regions=[]
            for j,leaf in enumerate(raw['leaf_records']):
                a,b=tuple(leaf['low']),tuple(leaf['high']);mask=oracle.possible(a,b)
                # A child's stored mask may be tightened by ancestor masks.
                # The basic outward bound alone must include all actual winners;
                # recompute ancestor intersections on the same dyadic path.
                pa=(0,)*len(a);pb=tuple(n-1 for n in oracle.shape);allowed=oracle.possible(pa,pb)
                while (pa,pb)!=(a,b):
                    axis=max(range(len(a)),key=lambda g:(pb[g]-pa[g],-g));middle=(pa[axis]+pb[axis])//2
                    if b[axis]<=middle:
                        z=list(pb);z[axis]=middle;pb=tuple(z)
                    elif a[axis]>middle:
                        z=list(pa);z[axis]=middle+1;pa=tuple(z)
                    else:raise AssertionError('leaf straddles required ancestor cut')
                    allowed&=oracle.possible(pa,pb)
                assert allowed==leaf['mask'] and allowed
                vectors=oracle.region_vectors(a,b)
                regions.append(FactorRegion(a,b,allowed,vectors,j,math.prod(max(map(int,v)) for v in vectors)))
                checks+=1
            if row['classification']=='robust':
                w=raw['winner']
                for cell in raw['parameter_cells']:
                    lo,hi=probability_bounds(regions,cell['low'],cell['high'],k,den)
                    assert all(lo[w]>hi[d] for d in range(k) if d!=w)
                    checks+=1
            else:
                witnesses={r['candidate']:r for r in raw['witnesses']}
                assert set(witnesses)==set(range(k))
                for w,witness in witnesses.items():
                    at=tuple(witness['high_endpoint_counts']);lo,hi=probability_bounds(regions,at,at,k,den)
                    assert hi[w]-lo[witness['competitor']]<=0;checks+=1
            factor_count+=1
        else:raise AssertionError('unsupported decisive reference')
    assert len(s['rows'])==40
    counters=Counter(r['classification'] for r in s['rows'])
    assert counters['robust']==s['sample_counts']['robust'] and counters['unknown']==s['sample_counts']['unknown']
    N=259;n=40;r=counters['robust'];u=counters['unknown']
    mc={(x['graph'],x['rank']) for x in load(PARENT/'summary.json')['rows'] if x['policy']=='generic_eager' and x['details']['status']=='stable'}
    a=sum(x['classification']=='robust' and (x['graph'],x['rank']) not in mc for x in s['rows'])
    au=sum(x['classification']=='unknown' and (x['graph'],x['rank']) not in mc for x in s['rows'])
    f=sum(x['fast_within_1s'] for x in s['rows'])
    expected={'robust_R':finite_interval(N,n,r,r+u),'additional_A':finite_interval(N,n,a,a+au),'tested_portfolio_fast_F':finite_interval(N,n,f,f)}
    assert expected==s['simultaneous95_intervals_population_counts']
    if expected['additional_A'][1]<20:decision,reason='STOP','insufficient_opportunity_upper_bound'
    elif expected['tested_portfolio_fast_F'][0]>=130:decision,reason='STOP','most_fast_reference_decisions'
    elif n-u>=32 and expected['additional_A'][0]>=20 and expected['tested_portfolio_fast_F'][1]<130:
        decision,reason='PROCEED_ONCE','all_prespecified_audit_requirements_met'
    else:decision,reason='STOP','insufficient_evidence_under_fixed_audit_budget'
    assert (decision,reason)==(s['decision'],s['reason'])
    save(BASE/'validation.json',{'status':'PASS','checks':checks,'sample_queries':40,
        'recomputed_tensor_references':exact_count,'recomputed_factor_certificates':factor_count,
        'recomputed_pruning_references':prune_count,'same_sample_as_failed_attempt':True,
        'source_sha256':reference_sources,'summary_sha256':sha(BASE/'summary.json'),
        'validator_sha256':sha(Path(__file__)),'decision':decision,'reason':reason,
        'limitation':'Factor certificate validation reuses the previously proved outward count bounds, checks complete dyadic coverage and recomputes all decisive bounds; not an independently implemented generic inference engine.'})
    print({'status':'PASS','decision':decision,'reason':reason,'references':exact_count+factor_count+prune_count,'checks':checks},flush=True)


if __name__=='__main__':main()
