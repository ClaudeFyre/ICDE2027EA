"""Independent accounting audit and terminal research report for the pilot."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "nodes/10_icde_incremental_matching/results/pilot_20261109/attempt1"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1048576), b""):
            value.update(chunk)
    return value.hexdigest()


def write(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def main():
    protocol = read(OUT / "protocol.json")
    data = read(OUT / "p1_results.json")
    decision = read(OUT / "decision.json")
    checks = 0
    for category in ("input_sha256", "code_sha256"):
        for name, expected in protocol[category].items():
            assert digest(ROOT / name) == expected, name
            checks += 1
    assert digest(ROOT / "papers/icde/INCREMENTAL_MATCHING_PROTOCOL_20261109.md") == protocol["rules_sha256"]
    checks += 1
    records = data["records"]
    methods = ["dense_recompute", "dense_cache"] + [f"{family}_{size}" for family, size in protocol["configurations"]]
    unique = Counter((r["graph"], r["sources"], r["update"], r["method"], r["repeat"]) for r in records)
    expected = {(g, n, update, method, repeat) for g in protocol["graphs"]
        for n in protocol["source_sizes"] for update in protocol["fixtures"]
        for method in methods for repeat in range(protocol["repeats"])}
    assert set(unique) == expected and all(count == 1 for count in unique.values())
    assert len(records) == 384
    checks += len(expected)
    for path in sorted((OUT / "cases").glob("*.json")):
        case = read(path)
        corresponding = [r for r in records if (r["graph"], r["sources"], r["update"]) ==
                         (case["graph"], case["sources"], case["update"])]
        assert case["records"] == corresponding
        checks += len(corresponding)
    for row in records:
        assert row["status"] == "PASS"
        assert 0 <= row["exact_pairs"] <= row["sources"] * 15000
        assert row["seconds"] > 0
        assert row["checks"] >= row["sources"]
        if row["method"] == "dense_cache":
            assert row["exact_pairs"] == row["changed_sources"] * 15000 + (
                row["sources"] - row["changed_sources"]) * row["changed_targets"]
        if row["update"] == "unchanged":
            assert row["changed_sources"] == row["changed_targets"] == 0
            assert row["violating_rows"] == 0
        checks += 6
    setups = {(r["graph"], r["sources"], r["method"]): r["seconds"] for r in data["setups"]}
    medians = {}
    for g, n, update, method, _ in sorted(expected):
        key = g, n, update, method
        if key not in medians:
            medians[key] = statistics.median(r["seconds"] for r in records
                if (r["graph"], r["sources"], r["update"], r["method"]) == key)
    eligible = []
    for item in decision["comparisons"]:
        method = item["method"]
        paired = {}
        for graph in protocol["graphs"]:
            costs = []
            pairs = 0
            for n in protocol["source_sizes"]:
                for update in protocol["fixtures"][1:]:
                    base = medians[graph, n, update, "dense_cache"]
                    proposal = medians[graph, n, update, method] + setups[graph, n, method] / 8
                    costs.append((base, proposal))
                    entry = next(r for r in records if (r["graph"], r["sources"], r["update"], r["method"]) == (graph, n, update, method))
                    pairs += entry["exact_pairs"]
            base_total, proposal_total = map(sum, zip(*costs))
            reported = item["by_graph"][graph]
            assert abs(reported["baseline_seconds"] - base_total) < 1e-12
            assert abs(reported["method_seconds_with_setup"] - proposal_total) < 1e-12
            assert abs(reported["cost_saving"] - (1 - proposal_total / base_total)) < 1e-12
            universe = sum(protocol["source_sizes"]) * 15000 * 3
            assert abs(reported["pair_saving"] - (1 - pairs / universe)) < 1e-12
            paired[graph] = np.asarray(costs)
            checks += 4
        rng = np.random.default_rng(2026110923)
        base_sample = np.zeros(10000)
        proposed_sample = np.zeros(10000)
        for graph in protocol["graphs"]:
            costs = paired[graph]
            sampled = rng.integers(0, len(costs), size=(10000, len(costs)))
            base_sample += costs[sampled, 0].sum(1)
            proposed_sample += costs[sampled, 1].sum(1)
        ci = np.quantile(1 - proposed_sample / base_sample, [.025, .975])
        assert np.max(abs(ci - item["paired_descriptive_95pct_saving"])) < 1e-12
        passed = all(row["pair_saving"] >= .2 and row["cost_saving"] >= .2
                     for row in item["by_graph"].values()) and ci[0] > 0
        assert passed == item["pass"]
        if passed:
            eligible.append(item["method"])
        checks += 2
    assert bool(eligible) == (decision["status"] == "P1_PASS_REQUIRES_P2")
    checks += 1
    for ref in data["references"]:
        assert abs(ref["objective"] - ref["independent_objective"]) < 1e-8
        assert ref["global_dual_max_violation"] <= 1e-9
        losses = [ref["topk"][str(k)]["loss"] for k in (1, 4, 16, 64)]
        assert all(losses[i] + 1e-8 >= losses[i + 1] for i in range(3))
        checks += 3
    audit = {"status": "PASS", "accounting_and_structure_checks": checks,
        "pricing_runs": len(records), "distinct_graph_size_update_cases": 16,
        "full_assignment_references": len(data["references"]),
        "pricing_runtime_checks": sum(r["checks"] for r in records),
        "tiny_case_checks": read(OUT / "self_check.json")["checks"],
        "recomputed_costs_and_bootstrap": True,
        "separate_independent_solver_used_in_pilot": "SciPy full linear_sum_assignment vs sparse LP dual",
        "reporter_sha256": digest(Path(__file__)),
        "metadata_clarification": {
            "superseded_field": "p1_results.inputs[].confirmation_sources_accessed",
            "whole_entity_vector_arrays_loaded": True,
            "confirmation_source_queries_evaluated": False,
            "confirmation_labels_read": False,
            "meaning": "the old field refers to query evaluation, not physical NPZ array reads"}}
    write(OUT / "accounting_audit.json", audit)

    def pct(value):
        return f"{100 * value:.2f}%"

    text = ["# 增量实体匹配首轮实验结果", "", "2026 年 11 月 9 日，北京时间。", "",
        f"**冻结门槛决策为 {decision['status']}。**", "",
        "## 实际完成范围", "",
        "两张 OpenEA 图、各15000个完整目标、600维冻结RREA表示，源规模256与1024。"
        "每个图—规模组合包含无变化、1%源混合、1%目标混合及历史受控删边快照，"
        "共16种图—规模—负载情况。六个块配置和两条dense基线，各3次计时，共384次运行。", "",
        "输入与代码身份及4个NPZ CRC核验通过。16组微型向量检查、非局部换配链和空匹配检查通过。"
        "四组初始全图最优参照均由稀疏LP和完整分配算法交叉核对。"
        "计时内核处理更新向量与旧最优对偶，逐行用全候选定价核验。", "",
        f"微型检查{audit['tiny_case_checks']:,}项，定价运行时检查{audit['pricing_runtime_checks']:,}项，"
        f"独立费用与结构检查{checks:,}项通过。检查计数描述实现核验规模。", "",
        "## 主费用与剪枝", "",
        "主表合计两种源规模和后三种更新，无变化诊断不参与主门槛。"
        "费用为3次计时中位数，另加每请求1/8的新增索引与源—中心缓存构造费用。"
        "dense_cache保留完整历史分数，只重算变化行列并完整扫描。", "",
        "| 配置 | D–W 精确点积节省 | D–W 费用节省 | EN–FR 精确点积节省 | EN–FR 费用节省 | 门槛 |",
        "| --- | --- | --- | --- | --- | --- |"]
    for item in decision["comparisons"]:
        dw, en = item["by_graph"]["dw"], item["by_graph"]["enfr"]
        text.append(f"| {item['method']} | {pct(dw['pair_saving'])} | {pct(dw['cost_saving'])} | "
                    f"{pct(en['pair_saving'])} | {pct(en['cost_saving'])} | {'通过' if item['pass'] else '未通过'} |")
    text += ["", "点积节省的分母是每个查询的完整源—目标笛卡尔积。"
        "费用节省的基线则是能够复用历史分数的dense_cache。负值表示候选方法更慢。"
        "索引方法的界计算和维护费用已包含在时间中，不能将点积减少直接解释为加速。", "",
        "## 固定候选与匹配机会", "",
        "| 图 | 源数 | 独立top1冲突余量 | 匹配行数 | top1目标损失 | top4损失 | top16损失 | top64损失 |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for ref in data["references"]:
        losses = [f"{ref['topk'][str(k)]['loss']:.9g}" for k in (1, 4, 16, 64)]
        text.append(f"| {ref['graph']} | {ref['sources']} | {ref['independent_top1_collisions']} | "
                    f"{ref['matched_rows']} | " + " | ".join(losses) + " |")
    text += ["", "这些是给定评分规则下的目标损失，实体标签准确率没有在本轮评价。", "",
        "## 负载分层", "",
        "| 图 | 源数 | 负载 | 变化源 | 变化目标 | 违反旧对偶约束的源数 |",
        "| --- | --- | --- | --- | --- | --- |"]
    for row in records:
        if row["method"] == "dense_cache" and row["repeat"] == 0:
            text.append(f"| {row['graph']} | {row['sources']} | {row['update']} | "
                        f"{row['changed_sources']} | {row['changed_targets']} | {row['violating_rows']} |")
    text += ["", "历史删边快照中变化向量接近全图。变化按binary64标准化表示是否相同判定，"
        "未按距离大小删去微小变化。此负载作为历史传播压力情况，不能解释为1%向量变化。", "",
        "## 解释与停止出口", ""]
    if not eligible:
        text += ["六个配置均未满足预先要求的双图20%点积节省、双图20%含构造费用降低及描述性区间下端为正。"
            "按协议在P1停止，该轮未进入联合匹配修复开发或确认查询。", "",
            "本结果说明固定球面帽与投影余量块界在这些负载上没有形成所需的经济定价能力。"
            "它约束这两种表示及本轮规模，增量匹配问题的其他表示和更大规模仍未由本实验判定。"]
    else:
        text += [f"P1选中{decision['selected']}，按冻结协议继续P2。本文只记录已完成内核结果。"]
    text += ["", "## 限制与记录澄清", "",
        '[说明文本已清理]',
        "- 当前计时覆盖定价维护内核，匹配LP修复和编码器推理不在该计时内。报告中的费用比较不代表完整服务加速。",
        "- 原始JSON中的confirmation_sources_accessed=false表示没有运行确认源查询。NPZ按完整实体向量数组读取和标准化，其中包含确认池向量。物理向量访问与查询确认使用已在accounting_audit.json中澄清。",
        "- 源规模共享前缀、两图内共享目标和更新，bootstrap区间仅为当前配对负载的描述。三次计时不是三份独立查询数据。",
        "- 初始完整分数与对偶属于共同历史资产。候选方法仅从向量及索引计算，参考矩阵未传入块定价路径。",
        "", "## 复现入口", "",
        "协议位于papers/icde/INCREMENTAL_MATCHING_PROTOCOL_20261109.md。主脚本为"
        "scripts/icde_incremental_matching_pilot_20261109.py，阶段依次为freeze、recover、self_check、p1、analyze。"
        "全部数值阶段通过scripts/safe_run.py按local16顺序运行。冻结输出须保留，复现时使用新输出目录和新协议绑定。", "",
        f"P1数值阶段墙钟为{data['seconds']:.3f}秒。进程树内存和阶段总费用另见.runtime/runs中的本轮运行记录。", ""]
    with (OUT / "RESULTS_ZH.md").open("x", encoding="utf-8") as handle:
        handle.write("\n".join(text))
    files = sorted(p for p in OUT.rglob("*") if p.is_file())
    write(OUT / "asset_manifest.json", {"status": decision["status"],
        "files": {p.relative_to(ROOT).as_posix(): digest(p) for p in files},
        "input_sha256": protocol["input_sha256"], "code_sha256": protocol["code_sha256"],
        "reporter_sha256": digest(Path(__file__)), "protocol_sha256": digest(OUT / "protocol.json")})
    print(json.dumps(audit, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
