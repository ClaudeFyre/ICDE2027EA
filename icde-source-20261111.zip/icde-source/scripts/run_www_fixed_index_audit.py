"""Audit workload transfer and practical storage baselines for one WWW cell.

The original authorization matrix changes possible-world streams while holding
500 queries fixed.  This audit partitions those queries in frozen order into
300 selector queries, 100 authorization queries, and 100 untouched final-test
queries.  Only the target-side representation map transfers: unseen query
Gaussians stay full, matching a materialized candidate index with transient
query-side state.

The audit also materializes actual target-index bytes for margin-aware FP32,
margin-aware FP16, full FP32, and full FP16 artifacts; evaluates every global
low-rank-plus-diagonal rank 0..7 (rank 0 is diagonal); and compares the full
Gaussian estimator with a mean-only estimator.  It deliberately does not
replace the frozen main matrix.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT / "src", ROOT / "scripts", ROOT / "scripts/backbones"):
    if str(search_path) not in __import__("sys").path:
        __import__("sys").path.insert(0, str(search_path))

from pkgea.contracts import dataset_content_digest, dataset_revision_digest
from pkgea.www_fsl import (
    apply_entity_representations,
    approximate_covariance_batch,
    gaussian_distance_matrix,
    mean_relative_distance_error,
    select_entity_adaptive_ranks,
    select_margin_aware_representations,
    serving_workload_digest,
    stored_scalars_per_entity,
    truth_preserving_candidate_subset,
    winner_agreement,
    winner_indices,
)
from run_www_equal_budget import (
    atomic_write_json,
    encode_worlds,
    full_payload,
    load_full_payload,
    load_representation_payload,
    load_profile,
    low_rank_payload,
    project_and_summarize,
    read_rows,
    release_hidden_samples,
    representation_payload,
    sha256,
    time_world_generation,
    truth_accuracy,
    truth_mrr,
)
from www_encoder_adapters import load_distributional_encoder


FORMAT = "pkgea-www-fixed-index-audit-v1"
RANKS = tuple(range(8))


def elapsed(started: float) -> float:
    return time.perf_counter() - started


def stage_indices(selection: int, authorization: int, final_test: int) -> dict[str, slice]:
    if min(selection, authorization, final_test) <= 0:
        raise ValueError("all query split sizes must be positive")
    return {
        "selection": slice(0, selection),
        "authorization": slice(selection, selection + authorization),
        "final_test": slice(selection + authorization, selection + authorization + final_test),
    }


def projection_fit_rows(selection_queries: int, source_count: int,
                        fit_target_count: int) -> np.ndarray:
    """Fit PCA on selection sources and the frozen aligned-target baseline."""
    return np.concatenate((
        np.arange(selection_queries),
        np.arange(source_count, source_count + fit_target_count),
    ))


def project_pool_moments(
    hidden: np.ndarray, projection: np.ndarray, baseline_rows: int
) -> tuple[np.ndarray, np.ndarray, float]:
    """Keep the frozen 1,012-target moment reduction at its original shape.

    Summing a wider entity axis can change the final floating-point bits even
    for unchanged leading rows. The compressed byte budget is sensitive to
    those bits, so compute the original source/aligned-target prefix separately
    and append moments for new distractors afterwards.
    """

    if baseline_rows <= 0 or baseline_rows > hidden.shape[1]:
        raise ValueError("baseline row count must fit the encoded entity array")
    means, covariances, seconds = project_and_summarize(
        hidden[:, :baseline_rows, :], projection
    )
    if baseline_rows == hidden.shape[1]:
        return means, covariances, seconds
    extra_means, extra_covariances, extra_seconds = project_and_summarize(
        hidden[:, baseline_rows:, :], projection
    )
    return (
        np.concatenate((means, extra_means)),
        np.concatenate((covariances, extra_covariances)),
        seconds + extra_seconds,
    )


def target_with_query_covariances(
    query_covariances: np.ndarray, target_covariances: np.ndarray
) -> np.ndarray:
    return np.concatenate((query_covariances, target_covariances), axis=0)


def split_metrics(
    reference: np.ndarray,
    estimate: np.ndarray,
    truth_positions: np.ndarray,
    source_ids: tuple[str, ...],
) -> dict[str, object]:
    reference_winners = winner_indices(reference)
    estimate_winners = winner_indices(estimate)
    flips = reference_winners != estimate_winners
    return {
        "query_count": len(reference),
        "winner_agreement": winner_agreement(estimate, reference),
        "mean_relative_distance_error": mean_relative_distance_error(estimate, reference),
        "reference_hits_at_1": truth_accuracy(reference, truth_positions),
        "estimate_hits_at_1": truth_accuracy(estimate, truth_positions),
        "reference_mrr": truth_mrr(reference, truth_positions),
        "estimate_mrr": truth_mrr(estimate, truth_positions),
        "flipped_query_count": int(flips.sum()),
        "flipped_source_ids": [
            source for source, flipped in zip(source_ids, flips, strict=True) if flipped
        ],
    }


def rank_approximation(covariances: np.ndarray, rank: int) -> np.ndarray:
    if rank == 0:
        return approximate_covariance_batch(covariances, "diagonal")
    return approximate_covariance_batch(covariances, "low_rank", rank=rank)


def global_rank_bytes(
    means: np.ndarray,
    covariances: np.ndarray,
    rank: int,
    metadata: dict[str, object],
) -> int:
    if rank == 0:
        payload, _ = representation_payload(
            means, covariances, ["diagonal"] * len(means), metadata
        )
        return len(payload)
    payload, _, _, _ = low_rank_payload(means, covariances, rank, metadata)
    return len(payload)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--cell", required=True)
    parser.add_argument("--selection-queries", type=int, default=300)
    parser.add_argument("--authorization-queries", type=int, default=100)
    parser.add_argument("--final-test-queries", type=int, default=100)
    parser.add_argument("--candidate-limit", type=int, default=1012)
    parser.add_argument(
        "--candidate-pool", choices=("aligned", "graph"), default="aligned",
        help="'graph' admits non-aligned target entities as distractors",
    )
    parser.add_argument(
        "--candidate-limits", nargs="+", type=int,
        help="sweep these pool sizes, reusing one set of full-pool moments",
    )
    parser.add_argument("--worlds", type=int, default=2048)
    parser.add_argument("--selection-seed", type=int, default=17)
    parser.add_argument("--authorization-seed", type=int, default=59)
    parser.add_argument("--final-test-seed", type=int, default=71)
    parser.add_argument("--projection-dimension", type=int, default=16)
    parser.add_argument("--max-distance-error", type=float, default=0.0025)
    parser.add_argument(
        "--certify-queries", action="store_true",
        help="record the per-query soundness certificate alongside the sweep",
    )
    parser.add_argument(
        "--budget-fractions", nargs="+", type=float,
        help=(
            "sweep these serialized-byte budgets instead of the frozen single "
            "0.8 audit; writes the budget-frontier schema to its own namespace"
        ),
    )
    args = parser.parse_args()

    output = args.output.resolve()
    if output.exists():
        raise ValueError("output already exists; refusing to overwrite")
    if args.worlds < 3:
        raise ValueError("at least three worlds are required")
    seeds = (args.selection_seed, args.authorization_seed, args.final_test_seed)
    if len(set(seeds)) != 3:
        raise ValueError("selection, authorization, and final-test seeds must differ")

    checkpoint_path = args.checkpoint.resolve()
    profile_path = args.profile.resolve()
    profile = load_profile(args.cell, profile_path)
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    adapter = load_distributional_encoder(checkpoint)
    entity_ids = adapter.entity_ids()
    entity_index = {entity: index for index, entity in enumerate(entity_ids)}

    all_sources = tuple(dict.fromkeys(
        row["source_entity_id"] for row in profile.alignments if row["split"] == "test"
    ))
    split_total = args.selection_queries + args.authorization_queries + args.final_test_queries
    if len(all_sources) != split_total:
        raise ValueError(
            f"query split consumes {split_total} sources but profile has {len(all_sources)}"
        )
    full_targets = tuple(dict.fromkeys(
        row["target_entity_id"] for row in profile.alignments
    ))
    aligned_target_count = len(full_targets)
    if args.candidate_pool == "graph":
        # Realistic EA ranks against every target entity, not only those known
        # to be aligned.  Appending the non-aligned ones after the aligned ones
        # keeps the order frozen, so any limit <= 1012 reproduces the pool the
        # earlier runs used exactly.
        known = set(full_targets)
        extra = tuple(
            row["entity_id"]
            for row in read_rows(profile_path / "entities.tsv")
            if row["graph_id"] == "target"
            and row["entity_id"] not in known
            and row["entity_id"] in entity_index
        )
        full_targets = full_targets + extra
    truth = {
        row["source_entity_id"]: row["target_entity_id"]
        for row in profile.alignments if row["split"] == "test"
    }
    targets = truth_preserving_candidate_subset(
        full_targets, all_sources, truth, args.candidate_limit
    )
    truth_retention = sum(truth[source] in targets for source in all_sources) / len(all_sources)
    if truth_retention != 1.0:
        raise AssertionError("candidate pool lost a test truth")
    target_index = {target: index for index, target in enumerate(targets)}
    truth_positions = np.asarray(
        [target_index[truth[source]] for source in all_sources], dtype=np.int64
    )
    query_entities = (*all_sources, *targets)
    query_tensor = torch.tensor(
        [entity_index[entity] for entity in query_entities], dtype=torch.long
    )

    def forward(weights: torch.Tensor) -> torch.Tensor:
        return adapter.encode(weights)[query_tensor]

    torch.set_num_threads(1)
    threshold = torch.tensor(
        [value >= 0.5 for value in profile.probabilities], dtype=torch.float32
    )
    with torch.no_grad():
        threshold_hidden = np.asarray(forward(threshold).numpy(), dtype=np.float64)
    # In a pool sweep, newly admitted distractors must not refit the PCA basis.
    # The 1,012-target point is a strict reproduction of the earlier experiment,
    # and every larger pool uses that same basis and checkpoint.
    if args.candidate_limits and aligned_target_count != 1012:
        raise RuntimeError(
            f"pool sweep expected 1,012 aligned targets, found {aligned_target_count}"
        )
    fit_target_count = aligned_target_count if args.candidate_limits else len(targets)
    fit_rows = projection_fit_rows(args.selection_queries, len(all_sources),
                                   fit_target_count)
    centered = threshold_hidden[fit_rows] - threshold_hidden[fit_rows].mean(axis=0)
    _, _, right = np.linalg.svd(centered, full_matrices=False)
    dimension = min(args.projection_dimension, right.shape[0], right.shape[1])
    if dimension < 2:
        raise ValueError("projection must retain at least two dimensions")
    projection = right[:dimension].T

    split_slices = stage_indices(
        args.selection_queries, args.authorization_queries, args.final_test_queries
    )
    split_sources = {
        name: all_sources[section] for name, section in split_slices.items()
    }
    workload_digests = {
        name: serving_workload_digest(sources, targets)
        for name, sources in split_sources.items()
    }
    common_metadata = {
        "schema_version": FORMAT,
        "cell": args.cell,
        "dataset_content_digest": dataset_content_digest(profile_path),
        "checkpoint_sha256": sha256(checkpoint_path),
        "worlds": args.worlds,
        "projection_dimension": dimension,
        "candidate_count": len(targets),
    }

    def moments(seed: int, label: str) -> tuple[np.ndarray, np.ndarray, dict[str, float]]:
        print(f"[workload-audit] {args.cell} {label} seed={seed} worlds={args.worlds}", flush=True)
        started = time.perf_counter()
        worlds, generation_seconds = time_world_generation(profile, args.worlds, seed)
        hidden, encoder_seconds = encode_worlds(worlds, forward)
        if args.candidate_limits:
            means, covariances, moment_seconds = project_pool_moments(
                hidden, projection, len(all_sources) + fit_target_count
            )
        else:
            means, covariances, moment_seconds = project_and_summarize(
                hidden, projection
            )
        release_hidden_samples(hidden)
        timings = {
            "world_generation_seconds": generation_seconds,
            "encoder_seconds": encoder_seconds,
            "moment_seconds": moment_seconds,
            "total_seconds": elapsed(started),
        }
        print(
            f"[workload-audit] {args.cell} {label} moments complete "
            f"in {timings['total_seconds']:.1f}s",
            flush=True,
        )
        return means, covariances, timings

    selection_means, selection_covariances, selection_timing = moments(
        args.selection_seed, "selection"
    )

    shared = dict(
        output=output, cell=args.cell, means=selection_means,
        covariances=selection_covariances, selection_timing=selection_timing,
        moments=moments, splits=split_slices, sources=all_sources,
        targets=targets, truth_positions=truth_positions, metadata=common_metadata,
        max_error=args.max_distance_error,
    )
    if args.candidate_limits:
        from www_pool_frontier import run_pool_frontier
        run_pool_frontier(
            output=output, cell=args.cell, means=selection_means,
            covariances=selection_covariances, selection_timing=selection_timing,
            moments=moments, splits=split_slices, sources=all_sources,
            full_targets=targets, truth=truth, metadata=common_metadata,
            max_error=args.max_distance_error,
            budget_fraction=(args.budget_fractions or [0.8])[0],
            candidate_limits=args.candidate_limits,
        )
        return 0
    if args.budget_fractions:
        fractions = sorted({round(float(value), 6) for value in args.budget_fractions})
        if not all(0.0 < value <= 1.0 for value in fractions):
            raise ValueError("budget fractions must lie in (0, 1]")
        from www_budget_frontier import run_frontier
        run_frontier(**shared, budget_fractions=tuple(fractions),
                     certify_queries=bool(args.certify_queries))
        return 0
    from www_fixed_index_audit import run_audit
    run_audit(**shared)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
