"""One prespecified SRS audit; unknown references remain unknown.

Standard tensor and existing factor-region solver only. No method repair here.
"""
import argparse
from collections import Counter
from fractions import Fraction as Q
import json
import math
from pathlib import Path
import random
import subprocess
import sys
import time

import numpy as np
from scipy.stats import hypergeom

from icde_grouped_inventory_20261108 import ROOT, load, sha, identities
from icde_grouped_exact_20261108 import groups_for_box, compile_counts, solve_counts
from icde_sparse_degree_20261108 import read_graph, read_query, restrict
from icde_pruned_block_comparison_20261109 import prune
from icde_portfolio_budget_20261108 import budgeted_call
from icde_large_event_screen_20261108 import admission
import icde_factor_partial_20261108 as factor
from run_vldb_interval_gate_v1 import clipped_box

PARENT = ROOT/'nodes/09_vldb_query_certification/results/icde_block_comparison_20261109/matched_anchor_pruning_attempt1'
BASE = ROOT/'nodes/09_vldb_query_certification/results/icde_final_random_audit_20261109/attempt2'
RULES = ROOT/'papers/icde/regular2027/FINAL_ROUND_RULES_20261109.md'

# Some resource-excluded queries have thousands of count axes. Their state
# count is a valid large integer, not a tensor allocation request. Preserve it
# without Python's decimal-printing guard truncating a JSON record midway.
if hasattr(sys, 'set_int_max_str_digits'):
    sys.set_int_max_str_digits(0)


def save(path, value):
    path=Path(path)
    if path.exists():raise FileExistsError(path)
    # Serialize before opening a destination and atomically publish only a
    # complete record. No numeric/scientific or selection rules are changed.
    def scalar(obj):
        if isinstance(obj,np.generic):return obj.item()
        if isinstance(obj,np.ndarray):return obj.tolist()
        raise TypeError(type(obj).__name__)
    encoded=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=scalar)+'\n'
    path.parent.mkdir(parents=True,exist_ok=True)
    pending=path.with_suffix(path.suffix+'.pending')
    with pending.open('x',encoding='utf-8') as stream:stream.write(encoded)
    pending.replace(path)


def finite_interval(N, n, successes_low, successes_high, alpha=.05/3):
    """Conservative outer interval when the SRS success total is censored.

    Invert both hypergeometric tails. Union over all unobserved completions
    is attained at the low/high observed success endpoints, by monotonicity.
    """
    if not 0 <= successes_low <= successes_high <= n <= N:
        raise ValueError('invalid finite sample counts')
    accepted = [M for M in range(N+1)
                if hypergeom.sf(successes_low-1, N, M, n) > alpha/2
                and hypergeom.cdf(successes_high, N, M, n) > alpha/2]
    if not accepted:
        raise AssertionError('empty outer confidence set')
    return [min(accepted), max(accepted)]


def freeze(out):
    if out.exists(): raise FileExistsError(out)
    parent = load(PARENT/'protocol.json')
    cases = sorted(parent['cases'], key=lambda r:(r['graph'], r['rank']))
    assert len(cases) == 259
    selected = random.Random(2026110901).sample(cases, 40)
    inputs = dict(parent['input_sha256'])
    for path in [PARENT/'protocol.json', PARENT/'summary.json', RULES]:
        inputs[path.relative_to(ROOT).as_posix()] = sha(path)
    failed_protocol=BASE.parent/'attempt1/protocol.json'
    inputs[failed_protocol.relative_to(ROOT).as_posix()]=sha(failed_protocol)
    assert selected==load(failed_protocol)['sample']
    code = dict(parent['code_sha256'])
    for path in [Path(__file__), ROOT/'scripts/test_icde_final_random_audit_20261109.py',ROOT/'scripts/test_icde_final_random_audit_20261109_v2.py']:
        code[path.relative_to(ROOT).as_posix()] = sha(path)
    code['scripts/icde_final_random_audit_20261109.py']=sha(ROOT/'scripts/icde_final_random_audit_20261109.py')
    save(out/'protocol.json', {'kind':'final_fixed_SRS_reference_opportunity_audit',
        'frozen_local_date':'2026-11-09 Asia/Shanghai', 'frozen_at_unix':time.time(),
        'rules':RULES.relative_to(ROOT).as_posix(), 'rules_sha256':sha(RULES),
        'population':cases, 'sample':selected, 'seed':2026110901, 'sample_size':40,
        'nominal':.9, 'tau':.25, 'tensor_seconds':10., 'total_solver_seconds':30.,
        'worker_watchdog_seconds':45., 'state_cap':262144, 'tensor_K_max':256,
        'max_group':64, 'tensor_work_max':100000000, 'tensor_bytes_max':536870912,
        'factor_max_splits':4095, 'factor_max_parameter_splits':1023,
        'simultaneous_alpha':.05, 'endpoints':3, 'minimum_resolved':32,
        'opportunity_threshold':20, 'fast_majority_threshold':130,
        'code_sha256':code, 'input_sha256':inputs,
        'unknown_policy':'censored, no replacement; no additional sample or budget after decision',
        'baseline':'fixed historical 39 approvals within .2s; not MC population completeness',
        'exact_scope':'standard full tensor and deterministic factor certificates; not all exact algorithms'})
    print('FROZEN 40 simple random queries; rules and code hashed before execution', flush=True)


def preflight(out):
    p=load(out/'protocol.json');checks=identities(p,False)
    assert p['sample']==random.Random(p['seed']).sample(p['population'],40)
    if (out/'cases').exists() or (out/'summary.json').exists():raise FileExistsError('new attempt required')
    save(out/'recovery.json',{'status':'PASS','checks':checks,'sample_reproduction':True})
    print('PREFLIGHT PASS',checks,flush=True)


def worker(out, index):
    p=load(out/'protocol.json');case=p['sample'][index];graph,rank=case['graph'],case['rank']
    before=time.perf_counter();kernel,meta=read_query(graph,rank,read_graph(graph))
    loading=time.perf_counter()-before;started=time.perf_counter()
    focus,selected=prune(kernel)
    common={'graph':graph,'rank':rank,'query_id':case['query_id'],'loading_seconds':loading,
            'original_K':len(kernel.candidates),'active_K':len(selected),'focus_original':focus,
            'mapping':selected,'classification':'unknown','attempts':[]}
    dest=out/'cases'/f'{index:02d}_{graph}_q{rank:03d}.json'
    if len(selected)==1:
        save(dest,{**common,'classification':'robust','reference_kind':'deterministic_pruning',
             'reference_seconds':time.perf_counter()-started,'full_exact_probabilities':True,'fast_within_1s':time.perf_counter()-started<=1})
        return
    reduced,mapping=restrict(kernel,selected);k=len(selected)
    low,high=clipped_box(np.full(len(reduced.edge_indices),p['nominal']),p['tau'])
    groups=groups_for_box(reduced,low,high);sizes=[len(e) for sig,e,end in groups]
    S=math.prod(n+1 for n in sizes);work=k*S*sum(n+1 for n in sizes)
    # Count/degrees/scores arrays, object-pointer tensors, and integer payloads.
    payload=96+math.ceil(54*len(reduced.edge_indices)/8)
    estimated=S*(8*(len(groups)+5*k+4)+4*k*payload)
    common.update({'active_G':len(groups),'S':S,'estimated_tensor_work':work,'estimated_tensor_bytes':estimated,
                   'maximum_group':max(sizes,default=0)})
    admitted=S<=p['state_cap'] and k<=p['tensor_K_max'] and max(sizes,default=0)<=p['max_group'] and work<=p['tensor_work_max'] and estimated<=p['tensor_bytes_max']
    if admitted:
        holder={}
        def dense():
            c=compile_counts(reduced,low,high,p['state_cap']);e=solve_counts(c,k)
            holder.update({'compiled':c,'exact':e})
            return {'uniform_winners':e['uniform_winners'],'pairs':e['pairs']}
        result=budgeted_call(dense,p['tensor_seconds']);raw=result.pop('raw')
        common['attempts'].append({'engine':'full_tensor','admitted':True,**result})
        if raw is not None:
            seconds=time.perf_counter()-started
            answer={**common,'classification':'robust' if raw['uniform_winners'] else 'nonrobust',
                'reference_kind':'full_exact_tensor','reference_seconds':seconds,'fast_within_1s':seconds<=1,
                'full_exact_probabilities':True,'uniform_winners_original':[mapping[w] for w in raw['uniform_winners']],
                'pairs':raw['pairs']}
            # Reference timing ends before the optional population diagnostic.
            if k<=62:
                from icde_parameter_association_20261108 import pointwise_population,audit_masks
                d,masks=pointwise_population(holder['compiled'],holder['exact'],k)
                answer['pointwise_population']=d
                answer['pointwise_mask_checks']=audit_masks(holder['compiled'],masks)
                answer['pointwise_omission']=bool(raw['uniform_winners']) and not d['pointwise_certifiable_winners']
            save(dest,answer);return
    else:common['attempts'].append({'engine':'full_tensor','admitted':False,'reason':'prespecified_resource_limits'})
    sparse_case={'retained_candidates':k,'reconstructed_group_count':len(groups),
                 'group_size_histogram':dict(Counter(sizes)),'count_states_exact':S}
    allowed=admission(sparse_case);remaining=p['total_solver_seconds']-(time.perf_counter()-started)
    if allowed['admitted'] and remaining>0:
        settings={'state_cap':S,'max_splits':p['factor_max_splits'],'max_parameter_splits':p['factor_max_parameter_splits']}
        result=budgeted_call(lambda:factor.execute(reduced,low,high,'factor_mass',settings),remaining)
        raw=result.pop('raw');common['attempts'].append({'engine':'factor_regions','admission':allowed,**result})
        if raw is not None:
            # Store complete evidence, even if its mathematically valid bounds remain inconclusive.
            common['factor_evidence']=raw
            if raw['status'] in ('stable','nonuniform'):
                seconds=time.perf_counter()-started
                common.update({'classification':'robust' if raw['status']=='stable' else 'nonrobust',
                    'reference_kind':'deterministic_factor_certificate','reference_seconds':seconds,
                    'fast_within_1s':seconds<=1,'full_exact_probabilities':False})
    else:common['attempts'].append({'engine':'factor_regions','admission':allowed,'reason':'admission_or_total_budget'})
    common['total_solver_elapsed_seconds']=time.perf_counter()-started
    common.setdefault('fast_within_1s',False)
    save(dest,common)


def run(out):
    p=load(out/'protocol.json');assert load(out/'recovery.json')['status']=='PASS'
    identities(p,False)
    for index,case in enumerate(p['sample']):
        dest=out/'cases'/f"{index:02d}_{case['graph']}_q{case['rank']:03d}.json"
        if dest.exists():continue
        command=[sys.executable,str(Path(__file__)), '--phase','worker','--output',str(out),'--index',str(index)]
        before=time.perf_counter()
        try:
            process=subprocess.run(command,capture_output=True,text=True,timeout=p['worker_watchdog_seconds'])
            failure='worker_exit' if process.returncode else None
            diagnostic=(process.stderr or process.stdout)[-2000:] if failure else ''
        except subprocess.TimeoutExpired:
            failure='watchdog_timeout';diagnostic='Child stopped at prespecified wall limit.'
        if not dest.exists():
            save(dest,{'graph':case['graph'],'rank':case['rank'],'query_id':case['query_id'],
                'classification':'unknown','reference_kind':failure or 'missing_output',
                'worker_wall_seconds':time.perf_counter()-before,'diagnostic':diagnostic,
                'fast_within_1s':False,'full_exact_probabilities':False})
        row=load(dest)
        print(f"{index+1}/40 {case['graph']} q{case['rank']} {row['classification']} {row.get('reference_kind','unresolved')} wall={time.perf_counter()-before:.2f}s",flush=True)
    identities(p,False)
    print('All 40 sampled IDs retained; ready for independent verification and decision.',flush=True)


def summarize(out):
    p=load(out/'protocol.json');rows=[load(out/'cases'/f"{i:02d}_{c['graph']}_q{c['rank']:03d}.json") for i,c in enumerate(p['sample'])]
    old=load(PARENT/'summary.json')['rows'];mc={(r['graph'],r['rank']) for r in old if r['policy']=='generic_eager' and r['details']['status']=='stable'}
    r=sum(x['classification']=='robust' for x in rows);u=sum(x['classification']=='unknown' for x in rows)
    a=sum(x['classification']=='robust' and (x['graph'],x['rank']) not in mc for x in rows)
    au=sum(x['classification']=='unknown' and (x['graph'],x['rank']) not in mc for x in rows)
    f=sum(x['fast_within_1s'] for x in rows)
    intervals={'robust_R':finite_interval(259,40,r,r+u), 'additional_A':finite_interval(259,40,a,a+au),
               'tested_portfolio_fast_F':finite_interval(259,40,f,f)}
    if intervals['additional_A'][1]<20:decision,reason='STOP','insufficient_opportunity_upper_bound'
    elif intervals['tested_portfolio_fast_F'][0]>=130:decision,reason='STOP','most_fast_reference_decisions'
    elif 40-u>=32 and intervals['additional_A'][0]>=20 and intervals['tested_portfolio_fast_F'][1]<130:
        decision,reason='PROCEED_ONCE','all_prespecified_audit_requirements_met'
    else:decision,reason='STOP','insufficient_evidence_under_fixed_audit_budget'
    stats={'status':'AWAITING_INDEPENDENT_REFERENCE_VALIDATION','protocol_sha256':sha(out/'protocol.json'),
           'sample_counts':{'robust':r,'nonrobust':40-r-u,'unknown':u,'additional_robust':a,'additional_unknown':au,'fast_1s':f,
               'full_exact_probabilities':sum(bool(x.get('full_exact_probabilities')) for x in rows)},
           'simultaneous95_intervals_population_counts':intervals,'decision':decision,'reason':reason,
           'logical_sample_bounds':{'robust_sample':[r,r+u],'additional_sample':[a,a+au]},
           'pointwise_diagnostic_subset':{'available':sum('pointwise_omission' in x for x in rows),
               'robust':sum(x['classification']=='robust' and 'pointwise_omission' in x for x in rows),
               'omitted':sum(x.get('pointwise_omission',False) for x in rows)},
           'rows':rows,'limitations':['unknown references are not nonrobust','40 SRS old queries, not blind confirmation',
             'reference runtimes cover this tested portfolio only','MC finite-budget misses are not population incompleteness',
             'no resolved-only proportion extrapolation','sample inference is conditional on the frozen finite workload, not new graphs']}
    save(out/'summary.json',stats)
    print(json.dumps({k:v for k,v in stats.items() if k!='rows'},ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['freeze','preflight','worker','run','summarize'],required=True)
    parser.add_argument('--output',type=Path,default=BASE);parser.add_argument('--index',type=int)
    args=parser.parse_args();out=args.output.resolve()
    if args.phase=='worker':worker(out,args.index)
    else:{'freeze':freeze,'preflight':preflight,'run':run,'summarize':summarize}[args.phase](out)
