"""Fetch two small OAEI references for intake auditing, never full graph dumps."""

import argparse
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path


def parse_reference(raw):
    tree = ET.fromstring(raw)
    namespaces = {e.tag.rsplit("}", 1)[0][1:] for e in tree.iter() if e.tag.endswith("}Cell")}
    allowed = {
        "http://knowledgeweb.semanticweb.org/heterogeneity/alignment",
        "http://knowledgeweb.semanticweb.org/heterogeneity/alignment#",
    }
    if len(namespaces) != 1 or not namespaces <= allowed:
        raise ValueError("missing cells or unsupported Alignment namespace")
    ns = {"a": namespaces.pop()}
    resource = "{http://www.w3.org/1999/02/22-rdf-syntax-ns#}resource"
    cells = tree.findall(".//a:Cell", ns)
    if any(
        c.find("a:entity1", ns) is None
        or c.find("a:entity2", ns) is None
        or not c.findtext("a:relation", namespaces=ns)
        for c in cells
    ):
        raise ValueError("missing alignment entities or relation")
    pairs = [
        (c.find("a:entity1", ns).get(resource), c.find("a:entity2", ns).get(resource))
        for c in cells
    ]
    if any(not left or not right for left, right in pairs):
        raise ValueError("missing entity resource")
    schema = [p for p in pairs if any("/class/" in x or "/property/" in x for x in p)]
    return {
        "alignment_namespace": ns["a"],
        "cells": len(cells),
        "unique_pairs": len(set(pairs)),
        "schema_uri_cells": len(schema),
        "other_cells_not_yet_type_verified": len(cells) - len(schema),
        "relations": sorted({c.findtext("a:relation", namespaces=ns) for c in cells}),
        "source_entities": len({p[0] for p in pairs}),
        "target_entities": len({p[1] for p in pairs}),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--raw", type=Path, required=True)
    parser.add_argument("--reuse-raw", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("output already exists")
    rows = []
    for pair in ("starwars-swtor", "marvelcinematicuniverse-marvel"):
        url = f"https://oaei.webdatacommons.org/tdrs/testdata/persistent/knowledgegraph/v3/suite/{pair}/component/reference.xml"
        try:
            args.raw.mkdir(parents=True, exist_ok=True)
            raw_path = args.raw / f"{pair}.xml"
            if raw_path.exists() and not args.reuse_raw:
                raise ValueError("raw reference exists; choose a fresh raw directory")
            # curl uses the host's verified certificate store (macOS Python's
            # separate certificate bundle may be absent). Never disable TLS.
            response = None
            if not args.reuse_raw:
                response = subprocess.run(
                    [
                        "curl",
                        "--fail",
                        "--location",
                        "--silent",
                        "--show-error",
                        "--max-time",
                        "25",
                        "--max-filesize",
                        "2000000",
                        "--output",
                        str(raw_path),
                        "--write-out",
                        "%{url_effective}",
                        url,
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
            raw = raw_path.read_bytes()
            final_url = response.stdout if response is not None else None
            statistics = parse_reference(raw)
            rows.append(
                {
                    "pair": pair,
                    "url": url,
                    "final_url": final_url,
                    "bytes": len(raw),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                    **statistics,
                    "status": "reference_fetched_graphs_not_fetched",
                }
            )
        except (OSError, subprocess.SubprocessError, ET.ParseError, ValueError) as error:
            rows.append({"pair": pair, "url": url, "status": "fetch_failed", "error": str(error)})
    payload = {
        "rows": rows,
        "source_page": "https://oaei.ontologymatching.org/2025/knowledgegraph/index.html",
        "license_status": "unconfirmed; no explicit dump redistribution license on track page",
        "version_warning": "2025 page says v4 but linked downloads resolve to v3; resolve before formal intake",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(rows, indent=2))
    if any(row["status"] == "fetch_failed" for row in rows):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
