"""Build the P1 *v2* controlled-synthetic traces with mutually-exclusive train/blind
source partitions and a factor-law-aware update chain.

Differences from v1 (``build_icde_p1_traces.py``), driven by the review:

* **Real source isolation.** v1 was a seed holdout: every seed drew from the same
  shuffled 96-source pool, so "train" and "blind" overlapped 100%. v2 partitions
  the source space into a *train* set and a *blind* set that are disjoint within
  each group; train traces only query train sources, blind traces only query blind
  sources. The candidate (target) pool may be shared -- the other side -- and that
  boundary is recorded. ``train ∩ blind = ∅`` is asserted by the validator.
* **request_id / world_seed / graph hash frozen separately.** Each query event
  carries a stable ``request_id``; the manifest records ``world_seed`` (the MC seed
  a replayer must use), ``arrival_seed`` (the synthetic inter-arrival RNG seed) and
  the graph content hash as *distinct* fields.
* **The hub update chain really mutates law.** ``update_probability`` changes a real
  edge probability and rebinds the probability digest; ``update_factor`` changes the
  shared ``dependency_groups``/``common_shock_probability`` through the FactorLaw
  extension and rebinds the factor digest; ``add``/``delete`` add/remove a real
  triple and rebind the digest of the *actual modified triple set* (never the base
  toy file digest).

Output: ``<out_root>/<group>__<split>__seed<seed>__b<budget>/{trace.jsonl,manifest.json}``
plus ``build_summary.json``. Fixed seeds, fully reproducible. The 24 frozen v1
traces are left untouched (they document seed-holdout, not source isolation).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC = REPO_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones.toy import ToyStructuralBackbone  # noqa: E402
from pkgea.contracts import dataset_content_digest  # noqa: E402
from pkgea.query.modal import ModalSnapshot, identity  # noqa: E402
from pkgea.samplers import FactorLaw  # noqa: E402

# Snapshot identity components -- kept aligned with the baseline suite.
CODE_ID = "icde_baseline_suite-v1"
SCORER_ID = "toy-degree-lexical-original-float"
MODEL_ID = "no-trained-model"
SCHEMA_ID = "canonical-v1"

PROBE_DIR = REPO_ROOT / "data" / "interim" / "openea-d-w-probe-q32-a64-attributes-independent-s17"
TOY_DIR = REPO_ROOT / "data" / "toy" / "exact_world_minimal"

SEEDS = (17, 23, 31)
BUDGETS = (64, 256)
SPLITS = ("train", "blind")
GROUPS = ("nonrepeated_overlap", "hotspot_partial", "disjoint_scopes", "hub_factor_updates")
SPLIT_SELECT_SEED = 20261009
DELTA = 0.05
PROBE_POOL_SIZE = 32
N_CLUSTERS_TRAIN = 2
N_CLUSTERS_BLIND = 2

# Trace length (query-event count) per seed, in [100, 300].
QUERY_LENGTH_BY_SEED = {17: 140, 23: 180, 31: 220}

EPOCH = datetime(2026, 10, 9, 0, 0, 0, tzinfo=timezone(timedelta(hours=8)))


def iso_from_ns(ns: int) -> str:
    return (EPOCH + timedelta(microseconds=ns / 1000.0)).isoformat()


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ---------------------------------------------------------------------------
# Source partition: disjoint train / blind sets
# ---------------------------------------------------------------------------
def partition_sources(source_entities):
    """Shuffle once with a fixed seed and split into disjoint train/blind halves."""

    rng = random.Random(SPLIT_SELECT_SEED)
    sources = list(source_entities)
    rng.shuffle(sources)
    half = len(sources) // 2
    return {
        "train": tuple(sources[:half]),
        "blind": tuple(sources[half:]),
        "order": tuple(sources),
    }


def select_target_pool(target_entities):
    rng = random.Random(SPLIT_SELECT_SEED + 1)
    targets = list(target_entities)
    rng.shuffle(targets)
    return tuple(targets[:PROBE_POOL_SIZE])


# ---------------------------------------------------------------------------
# Event writer
# ---------------------------------------------------------------------------
class EventWriter:
    def __init__(self, trace_id: str):
        self.trace_id = trace_id
        self.events: list[dict] = []
        self._seq = 0
        self._arrival = 0
        self._arr_rng = random.Random()  # arrival seed reset per trace

    def _next(self, kind: str, payload: dict) -> dict:
        self._seq += 1
        self._arrival += int(800_000_000 + self._arr_rng.random() * 600_000_000)
        ev = {
            "trace_id": self.trace_id,
            "event_id": f"{self.trace_id}-e{self._seq:05d}",
            "sequence": self._seq,
            "kind": kind,
            "arrival_ns": self._arrival,
            "event_time": iso_from_ns(self._arrival - 50_000_000),
            "observation_time": iso_from_ns(self._arrival),
        }
        ev.update(payload)
        self.events.append(ev)
        return ev

    def query(self, request_id, source, candidates, requested_snapshot, budget, not_ready_expected):
        return self._next("query", {
            "request_id": request_id,
            "source": source,
            "ordered_candidates": list(candidates),
            "requested_snapshot": requested_snapshot,
            "delta": DELTA,
            "world_budget": budget,
            "expected_serving": "not_ready" if not_ready_expected else "served",
        })

    def update_probability(self, base_snapshot, edge_id, old_p, new_p, resulting, world_seed):
        return self._next("update_probability", {
            "base_snapshot": base_snapshot,
            "edge_id": edge_id,
            "old_p": old_p,
            "new_p": new_p,
            "resulting_snapshot": resulting,
            "world_seed": world_seed,
            "event_time": iso_from_ns(self._arrival),
            "observation_time": iso_from_ns(self._arrival),
        })

    def add(self, base_snapshot, fact_id, fact_payload, resulting, world_seed):
        return self._next("add", {
            "base_snapshot": base_snapshot,
            "stable_fact_id": fact_id,
            "fact_payload": fact_payload,
            "resulting_snapshot": resulting,
            "world_seed": world_seed,
            "event_time": iso_from_ns(self._arrival),
            "observation_time": iso_from_ns(self._arrival),
        })

    def delete(self, base_snapshot, fact_id, fact_payload, resulting, world_seed):
        return self._next("delete", {
            "base_snapshot": base_snapshot,
            "stable_fact_id": fact_id,
            "fact_payload": fact_payload,
            "resulting_snapshot": resulting,
            "world_seed": world_seed,
            "event_time": iso_from_ns(self._arrival),
            "observation_time": iso_from_ns(self._arrival),
        })

    def update_factor(self, base_snapshot, factor_id, old_params, new_params, members, resulting, world_seed):
        return self._next("update_factor", {
            "base_snapshot": base_snapshot,
            "factor_id": factor_id,
            "old_factor_parameters": old_params,
            "new_factor_parameters": new_params,
            "member_set_change": members,
            "resulting_snapshot": resulting,
            "world_seed": world_seed,
            "event_time": iso_from_ns(self._arrival),
            "observation_time": iso_from_ns(self._arrival),
        })


def rotate(seq, n):
    return tuple(seq[n % len(seq):] + seq[: n % len(seq)])


# ---------------------------------------------------------------------------
# Mutable toy graph state (hub_factor_updates) -- real triple / probability / law
# ---------------------------------------------------------------------------
class ToyGraphState:
    """The mutable toy triple set; digests bind the ACTUAL current content."""

    def __init__(self, backbone):
        # ordered triples of (head, relation, tail) + parallel probs + group labels
        self.triples = [(r["head_id"], r["relation_id"], r["tail_id"]) for r in backbone.triples]
        self.probs = [float(r["confidence"]) for r in backbone.triples]
        self.groups = [""] * len(self.triples)
        self.rho = 0.0
        self.next_fact_no = 1

    def graph_digest(self):
        return "graph-v1:" + identity([list(t) for t in self.triples])

    def factor_law(self):
        return FactorLaw(tuple(self.groups), self.rho)

    def snapshot(self):
        return ModalSnapshot(
            self.graph_digest(), MODEL_ID, identity(list(self.probs)),
            self.factor_law().identity(), SCHEMA_ID, CODE_ID, SCORER_ID,
        )

    def apply_update_probability(self, edge_index, new_p):
        old = self.probs[edge_index]
        self.probs[edge_index] = new_p
        return old, new_p

    def apply_add(self, head, relation, tail, conf):
        fact_id = f"fact:add:{self.next_fact_no}"
        self.next_fact_no += 1
        self.triples.append((head, relation, tail))
        self.probs.append(conf)
        self.groups.append("")
        return fact_id

    def apply_delete(self, edge_index):
        head, relation, tail = self.triples[edge_index]
        fact_id = f"fact:del:{self.next_fact_no}"
        self.next_fact_no += 1
        del self.triples[edge_index]
        del self.probs[edge_index]
        del self.groups[edge_index]
        return fact_id, (head, relation, tail)

    def apply_update_factor(self, group_labels, rho):
        old = {"dependency_groups": list(self.groups), "common_shock_probability": self.rho}
        self.groups = list(group_labels)
        self.rho = rho
        return old


# ---------------------------------------------------------------------------
# Probe-group trace generation (source-isolated)
# ---------------------------------------------------------------------------
def gen_probe_group(group, split, seed, budget, parts, target_pool, probe_snapshot,
                    n_queries, trace_id):
    # world_seed drives replay MC; arrival_seed drives synthetic inter-arrival.
    # They are independent and recorded separately.
    world_seed = seed
    arrival_seed = seed * 1000 + (7 if split == "train" else 13) + (1 if budget == 256 else 0)
    rng = random.Random(f"icde-v2::{group}::{split}::{seed}::{budget}")
    writer = EventWriter(trace_id)
    writer._arr_rng = random.Random(arrival_seed)

    split_sources = parts[split]
    if group == "nonrepeated_overlap":
        source_chooser = lambda i: split_sources[i % len(split_sources)]
    elif group == "hotspot_partial":
        # hotspot = the first 2 sources of this split's disjoint set.
        hotspot = split_sources[:2]
        recent = []
        def source_chooser(i):
            if recent and rng.random() < 0.30:
                return recent[rng.randrange(len(recent))][0]
            r = rng.random()
            source = hotspot[0] if r < 0.6 else hotspot[1]
            recent.append((source, None))
            if len(recent) > 12:
                recent.pop(0)
            return source
    elif group == "disjoint_scopes":
        # split's own sources split into 2 disjoint scopes.
        half = len(split_sources) // 2
        scopes = (split_sources[:half], split_sources[half:])
        def source_chooser(i):
            scope = scopes[i % 2]
            return scope[i % len(scope)]
    else:
        raise ValueError(group)

    for i in range(n_queries):
        req_id = f"req-{group}-{split}-{seed}-{budget}-{i:04d}"
        source = source_chooser(i)
        candidates = rotate(target_pool, i)
        writer.query(req_id, source, candidates, probe_snapshot, budget, False)
    return writer.events, world_seed, arrival_seed


# ---------------------------------------------------------------------------
# Toy hub/factor update group (train/blind disjoint sources)
# ---------------------------------------------------------------------------
def gen_update_group(split, seed, budget, backbone, n_queries, trace_id):
    world_seed = seed
    arrival_seed = seed * 1000 + (101 if split == "train" else 202) + (1 if budget == 256 else 0)
    rng = random.Random(f"icde-v2::hub::{split}::{seed}::{budget}")
    writer = EventWriter(trace_id)
    writer._arr_rng = random.Random(arrival_seed)

    # toy sources: s:alice, s:bob, s:city. train={alice,bob}, blind={city}.
    all_sources = tuple(backbone.source_entities)  # ("s:alice","s:bob","s:city")
    if split == "train":
        query_sources = (all_sources[0], all_sources[1])
    else:
        query_sources = (all_sources[2],)
    candidates = tuple(backbone.target_entities)

    state = ToyGraphState(backbone)
    snap = state.snapshot()
    base_digest = snap.digest
    edge_labels = [f"edge:{h}/{t}" for (h, _r, t) in state.triples]

    # Deterministic schedule: probability flip, add, delete, factor law change.
    # Record the resulting digests by actually mutating the graph state.
    schedule = [
        ("update_probability", 0, 0.20),                 # edge0 0.80 -> 0.20
        ("add", None, None),                             # append a real triple
        ("delete", None, None),                          # delete edge index 1
        ("update_factor", None, None),                   # group edges 0,2 with rho=0.6
    ]
    events_out = []
    publish_after = {}  # sequence index -> snapshot digest for forward-reference probe
    for i in range(n_queries):
        req_id = f"req-hub-{split}-{seed}-{budget}-{i:04d}"
        source = query_sources[i % len(query_sources)]
        cand = rotate(candidates, i)
        writer.query(req_id, source, cand, base_digest, budget, False)

        stage = i // 7
        if stage < len(schedule) and (i + 1) % 7 == 0:
            kind, arg, val = schedule[stage]
            if kind == "update_probability":
                old_p, new_p = state.apply_update_probability(arg, val)
                new_snap = state.snapshot()
                writer.update_probability(base_digest, edge_labels[arg], old_p, new_p,
                                          new_snap.digest, world_seed)
                edge_labels = [f"edge:{h}/{t}" for (h, _r, t) in state.triples]
            elif kind == "add":
                fid = state.apply_add("s:alice", "s:knows", "s:bob", 0.70)
                new_snap = state.snapshot()
                fact = {"head": "s:alice", "relation": "s:knows", "tail": "s:bob",
                        "confidence": 0.70}
                writer.add(base_digest, fid, fact, new_snap.digest, world_seed)
                edge_labels = [f"edge:{h}/{t}" for (h, _r, t) in state.triples]
            elif kind == "delete":
                # delete current edge index 1 (s:bob lives in s:city)
                fid, removed = state.apply_delete(1)
                new_snap = state.snapshot()
                writer.delete(base_digest, fid,
                              {"head": removed[0], "relation": removed[1], "tail": removed[2]},
                              new_snap.digest, world_seed)
                edge_labels = [f"edge:{h}/{t}" for (h, _r, t) in state.triples]
            elif kind == "update_factor":
                # after the add/delete the graph has 4 edges again (4-1+1=4).
                # Group edge0 and edge2 into one shared factor with rho=0.6.
                groups = ["hub_life", "", "hub_life", ""]
                old = state.apply_update_factor(groups, 0.6)
                new_snap = state.snapshot()
                writer.update_factor(
                    base_digest, "factor:hub_life", old,
                    {"dependency_groups": groups, "common_shock_probability": 0.6},
                    "set-groups:[0,2];rho:0->0.6", new_snap.digest, world_seed,
                )
            base_digest = new_snap.digest
            publish_after[writer._seq] = base_digest

    # Queries request the currently-published snapshot. The not_ready rule
    # (an unpublished/forward requested_snapshot must NOT be downgraded to a
    # stale success) is enforced by the serving harness and probed explicitly in
    # E3; this trace only carries faithful requested_snapshot descriptors.
    return writer.events, base_digest, world_seed, arrival_seed, state


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=REPO_ROOT / "nodes" / "05_icde_query_engine" / "results" / "icde_traces_v2_20261009")
    args = parser.parse_args(argv)
    out_root = args.output

    probe_backbone = ToyStructuralBackbone.from_dataset(PROBE_DIR)
    toy_backbone = ToyStructuralBackbone.from_dataset(TOY_DIR)

    parts = partition_sources(probe_backbone.source_entities)
    target_pool = select_target_pool(probe_backbone.target_entities)

    probe_conf = [float(r["confidence"]) for r in probe_backbone.triples]
    probe_probe_comp = {
        "graph": dataset_content_digest(PROBE_DIR),
        "model": MODEL_ID, "probability": identity(probe_conf),
        "factors": "independent", "schema": SCHEMA_ID, "code": CODE_ID, "scorer": SCORER_ID,
    }
    probe_snapshot = ModalSnapshot(**probe_probe_comp).digest

    probe_graph_sha = dataset_content_digest(PROBE_DIR)
    script_sha = sha256_file(Path(__file__))

    summary = {"format": "icde-p1-traces-v2", "output_root": str(out_root),
               "split_rule": {
                   "source_partition_seed": SPLIT_SELECT_SEED,
                   "train_sources": list(parts["train"]),
                   "blind_sources": list(parts["blind"]),
                   "note": "probe source space partitioned 48 train / 48 blind, disjoint.",
               },
               "traces": []}

    for group in GROUPS:
        for split in SPLITS:
            for seed in SEEDS:
                n_q = QUERY_LENGTH_BY_SEED[seed]
                for budget in BUDGETS:
                    trace_id = f"icde-p1-v2::{group}::{split}::seed{seed}::b{budget}"
                    if group == "hub_factor_updates":
                        events, final_digest, world_seed, arrival_seed, state = gen_update_group(
                            split, seed, budget, toy_backbone, n_q, trace_id)
                        graph_ref = {"kind": "toy-mutable", "dir": str(TOY_DIR),
                                     "base_content_sha256": dataset_content_digest(TOY_DIR),
                                     "final_graph_digest": state.graph_digest()}
                        split_sources = list(toy_backbone.source_entities[:2] if split == "train"
                                             else toy_backbone.source_entities[2:])
                    else:
                        events, world_seed, arrival_seed = gen_probe_group(
                            group, split, seed, budget, parts, target_pool,
                            probe_snapshot, n_q, trace_id)
                        final_digest = probe_snapshot
                        graph_ref = {"kind": "probe", "dir": str(PROBE_DIR),
                                     "content_sha256": probe_graph_sha,
                                     "snapshot_digest": probe_snapshot}
                        split_sources = list(parts[split])

                    n_query = sum(1 for e in events if e["kind"] == "query")
                    n_update = len(events) - n_query
                    expected_not_ready = sum(1 for e in events
                                            if e["kind"] == "query" and e.get("expected_serving") == "not_ready")

                    tdir = out_root / f"{group}__{split}__seed{seed}__b{budget}"
                    tdir.mkdir(parents=True, exist_ok=True)
                    with (tdir / "trace.jsonl").open("w", encoding="utf-8", newline="\n") as fh:
                        for ev in events:
                            fh.write(json.dumps(ev, ensure_ascii=False, sort_keys=True) + "\n")

                    manifest = {
                        "format": "icde-p1-trace-manifest-v2",
                        "trace_id": trace_id,
                        "group": group,
                        "split": split,
                        "seed": seed,
                        "world_seed": world_seed,
                        "arrival_seed": arrival_seed,
                        "budget": budget,
                        "trace_origin": "controlled_synthetic",
                        "license": "No third-party rows redistributed; payload is synthetic "
                                   "request descriptors.",
                        "graph_reference": graph_ref,
                        "input_sha256": {
                            "graph_content_digest": graph_ref.get("content_sha256")
                                                    or graph_ref.get("base_content_sha256"),
                            "generator_script_sha256": script_sha,
                        },
                        "probability_mechanism": "Injected Bernoulli edge probabilities are "
                                                  "controlled-synthetic; shared-factor groups use the "
                                                  "common-shock law (dependency_groups + "
                                                  "common_shock_probability).",
                        "pool_rule": {
                            "target_pool_size": PROBE_POOL_SIZE,
                            "target_pool_digest": identity(list(target_pool)),
                            "candidates_shared_across_splits": True,
                            "note": "Candidate (target) pool is shared across train/blind; only "
                                    "query SOURCE entities are partitioned disjointly.",
                        },
                        "split_source_cluster": {
                            "group": group,
                            "split": split,
                            "this_split_sources": split_sources,
                            "train_sources_global": list(parts["train"]),
                            "blind_sources_global": list(parts["blind"]),
                            "train_source_count": len(parts["train"]),
                            "blind_source_count": len(parts["blind"]),
                            "disjoint_assertion": "train ∩ blind = ∅ in source entity space",
                        },
                        "freeze_fields": {
                            "request_id": "stable per-request id on every query event",
                            "world_seed": world_seed,
                            "arrival_seed": arrival_seed,
                            "graph_hash": graph_ref.get("content_sha256")
                                          or graph_ref.get("final_graph_digest"),
                        },
                        "epoch": EPOCH.isoformat(),
                        "trace_partition": {"n_events": len(events), "n_query_events": n_query,
                                            "n_update_events": n_update,
                                            "expected_not_ready_queries": expected_not_ready},
                        "risk_config": {"delta_per_query": DELTA,
                                        "revision_delta": "per-revision, no global delta",
                                        "union_bound": "all_pairs", "clock": "all_worlds"},
                        "snapshot_components": probe_probe_comp if group != "hub_factor_updates"
                        else {"note": "mutable toy graph; per-update digests in trace events",
                              "final_revision_digest": final_digest},
                        "final_revision_digest": final_digest,
                        "statistical_unit": "whole independent trace/process; requests within a "
                                            "trace are not independent repetitions",
                    }
                    with (tdir / "manifest.json").open("w", encoding="utf-8", newline="\n") as fh:
                        fh.write(json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True) + "\n")

                    summary["traces"].append({
                        "trace_id": trace_id, "dir": str(tdir), "group": group, "split": split,
                        "seed": seed, "budget": budget, "n_events": len(events),
                        "n_query": n_query, "n_update": n_update,
                        "expected_not_ready": expected_not_ready,
                    })

    summary_path = out_root / "build_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps({"wrote": len(summary["traces"]), "out_root": str(out_root),
                      "train_sources": len(parts["train"]), "blind_sources": len(parts["blind"])},
                     indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
