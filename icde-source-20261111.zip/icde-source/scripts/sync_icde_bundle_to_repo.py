"""Compare repo E:\\pkgea against the 4090D consolidated bundle and report
missing / byte-different / newline-only-different Python files, then sync
missing files and the 3 semantic source differences from bundle -> repo.

Scope (per consolidated CPU acceptance REPORT): src/, scripts/, tests/,
nodes/05_icde_query_engine/experiments/ *.py files.
"""
from __future__ import annotations

import hashlib
import shutil
import sys
from pathlib import Path

BUNDLE = Path(r"E:\pkgea\tmp\icde_4090d_consolidated_20261009")
REPO = Path(r"E:\pkgea")
SCOPE_DIRS = [
    "src",
    "scripts",
    "tests",
    Path("nodes") / "05_icde_query_engine" / "experiments",
]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def norm(p: Path) -> bytes:
    return p.read_bytes().replace(b"\r\n", b"\n").replace(b"\r", b"\n")


def main() -> None:
    bundle_files: list[Path] = []
    for scope in SCOPE_DIRS:
        root = BUNDLE / scope
        if root.is_dir():
            for p in root.rglob("*.py"):
                bundle_files.append(p)
    bundle_files = sorted(bundle_files)

    missing, diff_byte, diff_nl = [], [], []
    for b in bundle_files:
        rel = b.relative_to(BUNDLE)
        r = REPO / rel
        if not r.exists():
            missing.append(rel)
        elif sha256(b) != sha256(r):
            if norm(b) == norm(r):
                diff_nl.append(rel)
            else:
                diff_byte.append(rel)

    print(f"bundle python files in scope: {len(bundle_files)}")
    print(f"missing in repo: {len(missing)}")
    print(f"byte-different (semantic): {len(diff_byte)}")
    print(f"newline-only different: {len(diff_nl)}")
    print("\n--- MISSING ---")
    for rel in missing:
        print(rel)
    print("\n--- BYTE DIFFERENT ---")
    for rel in diff_byte:
        print(rel, sha256(BUNDLE / rel), sha256(REPO / rel))
    print("\n--- NEWLINE ONLY ---")
    for rel in diff_nl:
        print(rel)

    if len(sys.argv) > 1 and sys.argv[1] == "--sync":
        backup = Path(r"E:\pkgea\tmp\icde_sync_backup_20261009")
        for rel in diff_byte:
            dst = REPO / rel
            bk = backup / rel
            bk.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst, bk)
            shutil.copy2(BUNDLE / rel, dst)
        for rel in missing:
            dst = REPO / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(BUNDLE / rel, dst)
        print(f"\nsynced {len(missing)} missing + {len(diff_byte)} byte-different "
              f"(backups in {backup})")


if __name__ == "__main__":
    main()
