"""Frozen pair-versus-separate-event tightness census and near-frontier exact audit."""
import argparse
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path
import time
import numpy as np

import icde_prospective_20261107 as old
from icde_grouped_inventory_20261108 import ROOT,load,save,sha,identities
from icde_grouped_exact_20261108 import compile_counts,solve_counts
from icde_association_followup_20261108 import population_controls
from icde_portfolio_budget_20261108 import budgeted_call
from run_vldb_interval_gate_v1 import clipped_box

PARENT=ROOT/'nodes/09_vldb_query_certification/results/icde_parameter_association_20261108'
BASE=ROOT/'nodes/09_vldb_query_certification/results/icde_pair_event_tightness_20261108/attempt1'


def freeze(out):
    if out.exists():raise FileExistsError(out)
    parent=load(PARENT/'strong_control_and_signal_correction_attempt1/protocol.json')
    known=load(PARENT/'strong_control_and_signal_correction_attempt1/strong_population_controls.json')['rows']
    inventory=load(PARENT/'attempt1/static_diagnosis.json')['rows']
    frontier=[r for r in inventory if r['retained_candidates']>1 and not r['prototype_eligible']
              and r['count_states_exact'] is not None and r['count_states_exact']<=65536]
    frontier.sort(key=lambda r:(r['count_states_exact'],r['retained_candidates'],r['graph'],r['rank']))
    if (len(known),len(frontier))!=(148,19):raise AssertionError('static selection changed')
    code=dict(parent['code_sha256']);code['scripts/icde_pair_event_tightness_20261108.py']=sha(Path(__file__))
    inputs=dict(parent['input_sha256'])
    for path in (PARENT/'strong_control_and_signal_correction_attempt1/strong_population_controls.json',PARENT/'attempt1/static_diagnosis.json'):
        inputs[path.relative_to(ROOT).as_posix()]=sha(path)
    save(out/'protocol.json',{'kind':'pair_event_gap_tightness_not_algorithm_novelty',
         'known_cases':known,'frontier_cases':frontier,'state_cap':65536,'nominal':.9,'tau':.25,
         'frontier_selection':'all 19 resource-excluded competitive queries with S<=65536; static-only, no outcome filtering',
         'reference_soft_seconds':5.,'frontier_wall_scope':'prepared compute including compilation and exact solve; loading separate; cooperative cap can overrun native calls',
         'primary_gap':'nominal winner w: min_d min_p(pi_w-pi_d) minus min_pi_w-max_d max_pi_d',
         'secondary':'nominal-winner per-rival differences and all-candidate pairs, explicitly separate from bottleneck',
         'groups':['all','robust','K2','Kge3','G3_4','G5_6','G7_8','Gge9'],
         'trend':'Spearman with tied ranks; descriptive within known graphs, no claim of growth outside observed G',
         'no_new_confirmation':True,'code_sha256':code,'input_sha256':inputs,'frozen_at_unix':time.time()})
    print('Frozen 148 known exact queries and 19 static near-frontier exact attempts',flush=True)


def preflight(out):
    p=load(out/'protocol.json');checks=identities(p,False)
    if (out/'summary.json').exists() or (out/'cases').exists():raise FileExistsError('new attempt needed')
    save(out/'recovery.json',{'status':'PASS','checks':checks})
    print('Preflight PASS',checks,flush=True)


def paired_stats(case,exact,controls,groups):
    k=case['retained_candidates'];nominal=list(map(Q,controls['nominal_probabilities_exact']))
    w=max(range(k),key=lambda c:(nominal[c],-c))
    lo=list(map(Q,controls['candidate_probability_minima_exact']))
    hi=list(map(Q,controls['candidate_probability_maxima_exact']))
    pairs=[]
    for r in exact['pairs']:
        a,d=r['candidate'],r['competitor'];true=Q(r['minimum_gap_exact']);separate=lo[a]-hi[d]
        gain=true-separate
        if gain<0:raise AssertionError('pair association made the lower bound worse')
        pairs.append({'candidate':a,'competitor':d,'pair_gap_exact':str(true),'separate_gap_exact':str(separate),
                      'tightness_gain_exact':str(gain),'tightness_gain':float(gain)})
    chosen=[r for r in pairs if r['candidate']==w]
    pair_gap=min(Q(r['pair_gap_exact']) for r in chosen)
    separate_gap=min(Q(r['separate_gap_exact']) for r in chosen)
    gain=pair_gap-separate_gap
    return {'graph':case['graph'],'rank':case['rank'],'query_id':case['query_id'],
         'retained_candidates':k,'scope_edges':case['scope_edges'],'group_count':groups,
         'count_states':case.get('count_states',case.get('count_states_exact')),
         'nominal_winner':w,'uniform_winners':exact['uniform_winners'],
         'pair_gap_exact':str(pair_gap),'separate_gap_exact':str(separate_gap),
         'bottleneck_gain_exact':str(gain),'bottleneck_gain':float(gain),
         'max_chosen_rival_gain':max(r['tightness_gain'] for r in chosen),
         'mean_chosen_rival_gain':float(sum(Q(r['tightness_gain_exact']) for r in chosen)/(k-1)),
         'pairs':pairs}


def rank_average(values):
    values=np.asarray(values);order=np.argsort(values,kind='stable');ranks=np.empty(len(values));i=0
    while i<len(order):
        j=i+1
        while j<len(order) and values[order[j]]==values[order[i]]:j+=1
        ranks[order[i:j]]=(i+j-1)/2;i=j
    return ranks


def summarize(rows):
    out={}
    for name,keep in [('all',lambda r:True),('robust',lambda r:bool(r['uniform_winners'])),
         ('K2',lambda r:r['retained_candidates']==2),('Kge3',lambda r:r['retained_candidates']>=3),
         ('G3_4',lambda r:3<=r['group_count']<=4),('G5_6',lambda r:5<=r['group_count']<=6),
         ('G7_8',lambda r:7<=r['group_count']<=8),('Gge9',lambda r:r['group_count']>=9)]:
        selected=[r for r in rows if keep(r)]
        if not selected:continue
        v=np.asarray([r['bottleneck_gain'] for r in selected]);g=np.asarray([r['group_count'] for r in selected])
        rv,rg=rank_average(v),rank_average(g)
        rho=float(np.corrcoef(rv,rg)[0,1]) if np.std(rv)>0 and np.std(rg)>0 else None
        out[name]={'queries':len(selected),'nonzero_exact':sum(Q(r['bottleneck_gain_exact'])>0 for r in selected),
            'gain_gt_1e_12':int((v>1e-12).sum()),'mean':float(v.mean()),
            'quantiles':dict(zip(['min','p25','median','p75','p90','p95','max'],map(float,np.quantile(v,[0,.25,.5,.75,.9,.95,1])))),
            'spearman_G_gain':rho,'group_range':[int(g.min()),int(g.max())],
            'queries_with_any_chosen_rival_gain':sum(r['max_chosen_rival_gain']>1e-12 for r in selected)}
    return out


def run(out):
    p=load(out/'protocol.json')
    if load(out/'recovery.json')['status']!='PASS':raise AssertionError('preflight required')
    checks=identities(p,False);rows=[];references=[]
    for role,cases in [('known',p['known_cases']),('frontier',p['frontier_cases'])]:
        for index,case in enumerate(cases):
            before=time.perf_counter();kernel,meta=old.read_query(case['graph'],case['rank']);loading=time.perf_counter()-before
            low,high=clipped_box(np.full(case['scope_edges'],p['nominal']),p['tau'])
            def exact_call():
                compiled=compile_counts(kernel,low,high,p['state_cap'])
                exact=solve_counts(compiled,len(kernel.candidates))
                controls=population_controls(compiled,exact,len(kernel.candidates),p['nominal'])
                return paired_stats(case,exact,controls,len(compiled['groups']))
            result=budgeted_call(exact_call,p['reference_soft_seconds'])
            raw=result.pop('raw')
            if raw is not None:
                raw.update({'role':role,**result,'prepared_load_seconds':loading})
                rows.append(raw)
                save(out/'cases'/f"{role}_{case['graph']}_q{case['rank']:03d}.json",raw)
            references.append({'graph':case['graph'],'rank':case['rank'],'role':role,
                               'reference_status':'timeout' if raw is None else 'exact_complete',**result,
                               'prepared_load_seconds':loading})
            checks+=1
            if (index+1)%25==0 or index+1==len(cases):print(f'{role} {index+1}/{len(cases)} complete',flush=True)
    checks+=identities(p,False)
    known=[r for r in rows if r['role']=='known'];frontier=[r for r in rows if r['role']=='frontier']
    summary={'status':'PASS','checks':checks,'protocol_sha256':sha(out/'protocol.json'),
         'known':summarize(known),'frontier':summarize(frontier),'combined':summarize(rows),
         'reference_outcomes':dict(Counter(r['reference_status'] for r in references)),
         'references':references,'rows':rows,
         'frontier_prepared_compute_seconds':sum(r['compute_seconds'] for r in references if r['role']=='frontier'),
         'historical_inputs_unchanged':True,
         'limitations':['historical development queries; easy frontier selected structurally',
                        'correlation is descriptive, confounded by candidate count and group sizes',
                        'exact reference timeout is unknown, not nonrobust or infinite cost',
                        'no full credal-circuit system or new scalable solver benchmark in this phase']}
    save(out/'summary.json',summary)
    print({'known':summary['known'],'frontier':summary['frontier'],'reference_outcomes':summary['reference_outcomes']},flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=('freeze','preflight','run'),required=True)
    parser.add_argument('--output',type=Path,default=BASE);args=parser.parse_args()
    {'freeze':freeze,'preflight':preflight,'run':run}[args.phase](args.output.resolve())
