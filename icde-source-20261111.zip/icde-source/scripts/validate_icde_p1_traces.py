"""Validate the P1 controlled-synthetic traces against trace_schema_v1.

Checks, per trace:
  * every event carries trace_id, event_id, sequence, kind, arrival_ns;
  * event_id is unique within the trace; sequence is 1..N monotone;
  * kind is in the allowed set; arrival_ns is non-decreasing;
  * event_time / observation_time parse as ISO8601 and event_time <= observation_time;
  * query events carry their required payload; update events carry theirs;
  * the sidecar manifest matches the trace (trace_id, group, seed, budget, event count).

Writes a validation_report.json into the output root and exits non-zero on any failure.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))
import icde_paths  # noqa: E402  (portable path resolver; single source of truth)

ALLOWED_KINDS = {
    "query", "update_probability", "add", "delete", "update_factor",
    "update_attribute", "model", "pool", "schema", "rollback", "fault",
}
REQUIRED_EVENT = {"trace_id", "event_id", "sequence", "kind", "arrival_ns"}
QUERY_PAYLOAD = {"query_id", "source", "ordered_candidates", "requested_snapshot", "delta", "world_budget"}
UPDATE_PROB_PAYLOAD = {"base_snapshot", "edge_id", "old_p", "new_p", "event_time", "observation_time"}
ADD_DELETE_PAYLOAD = {"base_snapshot", "stable_fact_id", "fact_payload", "event_time", "observation_time"}
UPDATE_FACTOR_PAYLOAD = {"base_snapshot", "factor_id", "event_time", "observation_time"}


def parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value)


def validate_trace_dir(tdir: Path) -> dict:
    report = {"dir": str(tdir), "errors": [], "n_events": 0, "kinds": {}}
    trace_path = tdir / "trace.jsonl"
    manifest_path = tdir / "manifest.json"
    if not trace_path.is_file():
        report["errors"].append("missing trace.jsonl")
        return report
    if not manifest_path.is_file():
        report["errors"].append("missing manifest.json")
        return report

    events = []
    with trace_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                events.append(json.loads(line))

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    report["n_events"] = len(events)

    seen_ids: set[str] = set()
    expected_seq = 0
    prev_arrival = -1
    prev_trace_id = None

    for ev in events:
        missing = REQUIRED_EVENT - set(ev)
        if missing:
            report["errors"].append(f"event missing fields {sorted(missing)}: {ev.get('event_id')}")
        eid = ev.get("event_id")
        if eid in seen_ids:
            report["errors"].append(f"duplicate event_id {eid}")
        seen_ids.add(eid)

        expected_seq += 1
        if ev.get("sequence") != expected_seq:
            report["errors"].append(f"sequence mismatch at {eid}: got {ev.get('sequence')}, expected {expected_seq}")

        kind = ev.get("kind")
        report["kinds"][kind] = report["kinds"].get(kind, 0) + 1
        if kind not in ALLOWED_KINDS:
            report["errors"].append(f"{eid}: disallowed kind {kind!r}")

        arr = ev.get("arrival_ns", -1)
        if arr < prev_arrival:
            report["errors"].append(f"{eid}: arrival_ns not non-decreasing ({arr} < {prev_arrival})")
        prev_arrival = arr

        if prev_trace_id is not None and ev.get("trace_id") != prev_trace_id:
            report["errors"].append(f"{eid}: trace_id changed within trace")
        prev_trace_id = ev.get("trace_id")

        # time fields
        for tfield in ("event_time", "observation_time"):
            if tfield not in ev:
                report["errors"].append(f"{eid}: missing {tfield}")
            else:
                try:
                    parse_iso(ev[tfield])
                except Exception:
                    report["errors"].append(f"{eid}: unparseable {tfield}={ev[tfield]!r}")
        if "event_time" in ev and "observation_time" in ev:
            try:
                if parse_iso(ev["event_time"]) > parse_iso(ev["observation_time"]):
                    report["errors"].append(f"{eid}: event_time after observation_time")
            except Exception:
                pass

        # payload by kind
        if kind == "query":
            miss = QUERY_PAYLOAD - set(ev)
            if miss:
                report["errors"].append(f"{eid}: query missing {sorted(miss)}")
            cands = ev.get("ordered_candidates")
            if isinstance(cands, list) and len(set(cands)) != len(cands):
                report["errors"].append(f"{eid}: duplicate candidates")
        elif kind == "update_probability":
            miss = UPDATE_PROB_PAYLOAD - set(ev)
            if miss:
                report["errors"].append(f"{eid}: update_probability missing {sorted(miss)}")
        elif kind in ("add", "delete"):
            miss = ADD_DELETE_PAYLOAD - set(ev)
            if miss:
                report["errors"].append(f"{eid}: {kind} missing {sorted(miss)}")
        elif kind == "update_factor":
            miss = UPDATE_FACTOR_PAYLOAD - set(ev)
            if miss:
                report["errors"].append(f"{eid}: update_factor missing {sorted(miss)}")

    # manifest correspondence
    if manifest.get("trace_id") != prev_trace_id:
        report["errors"].append(f"manifest trace_id {manifest.get('trace_id')} != trace {prev_trace_id}")
    if manifest.get("trace_partition", {}).get("n_events") != len(events):
        report["errors"].append("manifest n_events != actual")
    if not tdir.name.startswith(str(manifest.get("group", ""))):
        report["errors"].append("manifest group != directory group")

    report["ok"] = not report["errors"]
    return report


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path,
                        default=REPO_ROOT / "nodes" / "05_icde_query_engine" / "results" / "icde_traces_20261009")
    args = parser.parse_args(argv)

    # Scope validation to exactly the traces this task's generator produced
    # (recorded in build_summary.json), so parallel agents' sibling traces are
    # neither touched nor falsely reported as failures.
    summary_path = args.root / "build_summary.json"
    if summary_path.is_file():
        # build_summary now stores repo-relative dir names; resolve them against
        # the summary's own location via the portable resolver (never trust a
        # legacy absolute Windows path blindly).
        trace_dirs = sorted(icde_paths.trace_dirs_from_summary(summary_path))
    else:
        trace_dirs = sorted(p for p in args.root.iterdir() if p.is_dir() and (p / "trace.jsonl").is_file())
    reports = [validate_trace_dir(td) for td in trace_dirs]
    n_ok = sum(1 for r in reports if r["ok"])
    out = {
        "format": "icde-p1-trace-validation-v1",
        "root": str(args.root),
        "n_traces": len(reports),
        "n_ok": n_ok,
        "n_failed": len(reports) - n_ok,
        "reports": reports,
    }
    (args.root / "validation_report.json").write_text(
        json.dumps(out, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"n_traces": len(reports), "n_ok": n_ok, "n_failed": len(reports) - n_ok}))
    return 0 if n_ok == len(reports) else 1


if __name__ == "__main__":
    sys.exit(main())
