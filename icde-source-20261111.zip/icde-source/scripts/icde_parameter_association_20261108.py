"""Exact population gap of pointwise abstraction for boxes with upper endpoint 1.

Independent uniforms induce fixed-one counts A_g ~ Binomial(n_g, low_g).
Every count vector s >= A is then realizable. A multidimensional suffix OR
computes its EXACT possible-winner set, without sampling or interval relaxation.
This diagnoses one coupling and one pointwise sufficient condition, not all AMC.
"""
from fractions import Fraction as Q
from itertools import product
import numpy as np


def suffix_masks(winners, k):
    if not 1 <= k <= 62:
        raise ValueError('bitmask domain exceeded')
    masks = np.left_shift(np.int64(1), winners.astype(np.int64))
    for axis in range(masks.ndim):
        masks = np.flip(np.bitwise_or.accumulate(np.flip(masks,axis),axis=axis),axis)
    return masks


def pointwise_population(compiled, exact, k):
    if any(endpoint[1] != 1. for signature,edges,endpoint in compiled['groups']):
        raise ValueError('suffix shortcut requires every high endpoint exactly one')
    masks = suffix_masks(compiled['winners'],k)
    weights = np.asarray(1,dtype=object)
    for matrix in exact['matrices']:
        weights = np.multiply.outer(weights,matrix[0,:])
    den = exact['denominator']
    if weights.shape != masks.shape or sum(map(int,weights.flat)) != den:
        raise AssertionError('fixed-one count weights do not normalize')
    forced = [sum(map(int,weights[masks == 1 << c])) for c in range(k)]
    possible = [sum(map(int,weights[(masks & (1 << c)) != 0])) for c in range(k)]
    pairs=[]
    for w in range(k):
        for d in range(k):
            if w!=d:
                value=Q(forced[w]-possible[d],den)
                pairs.append({'candidate':w,'competitor':d,'gap_exact':str(value),'gap':float(value)})
    minimum=[min(Q(r['gap_exact']) for r in pairs if r['candidate']==w) for w in range(k)]
    return {'minimum_gaps_exact':list(map(str,minimum)),
            'minimum_gaps':list(map(float,minimum)),
            'pointwise_certifiable_winners':[w for w,gap in enumerate(minimum) if gap>0],
            'pairs':pairs,'denominator_exact':str(den)},masks


def audit_masks(compiled,masks):
    # Independent full rectangular reduction at all small states, otherwise
    # deterministic endpoint and interior probes; no suffix recurrence reused.
    shape=compiled['shape']
    if compiled['count_states']<=128:
        probes=list(product(*(range(n) for n in shape)))
    else:
        probes=[tuple(0 for n in shape),tuple(n-1 for n in shape)]
        probes += [tuple((j*(i+3))%n for i,n in enumerate(shape)) for j in range(1,9)]
    for at in probes:
        observed=compiled['winners'][tuple(slice(a,None) for a in at)]
        truth=0
        for winner in np.unique(observed):
            truth |= 1 << int(winner)
        if int(masks[at])!=truth:
            raise AssertionError('suffix winner mask is not the full attainable set')
    return len(probes)
