"""A conservative winner-event envelope for the frozen float64 degree scorer.

The kernel must use the exact operation order of DegreeScoreKernel in the V0
capture: a*A + (1-a)*(.6*L + .4*(1/(1+L1_degree))).  No sampling or file I/O
occurs here.  For a fixed uniform vector U and a declared independent-parameter
box, the returned Boolean h bounds every mismatch with the nominal winner.
Intervals deliberately ignore dependencies among degrees, so can be loose.

NumPy IEEE float64 primitive operations are evaluated separately, with one
nextafter step toward the exterior after each arithmetic operation.  Degree
and L1 operations are integer-exact below the explicitly checked size limit.
No float32 kernel, fused arithmetic, reassociation or arbitrary scorer is
covered by this implementation contract.
"""

from __future__ import annotations

from decimal import Context, Decimal, ROUND_CEILING
import math
from typing import Any

import numpy as np


SCHEMA = "vldb-float64-interval-event-envelope-v1"


def _float64_array(value: Any, name: str, ndim: int) -> np.ndarray:
    if not isinstance(value, np.ndarray) or value.dtype != np.dtype("float64") or value.ndim != ndim:
        raise ValueError(f"{name} must be a {ndim}-dimensional numpy float64 array")
    if not np.isfinite(value).all():
        raise ValueError(f"{name} must contain finite values")
    return value


def _kernel_inputs(kernel):
    candidates = tuple(kernel.candidates)
    if not candidates or len(set(candidates)) != len(candidates):
        raise ValueError("kernel candidates must be unique and nonempty")
    attribute = _float64_array(kernel.attribute, "attribute", 1)
    lexical = _float64_array(kernel.lexical, "lexical", 1)
    if attribute.shape != (len(candidates),) or lexical.shape != attribute.shape:
        raise ValueError("static score lengths differ from candidate order")
    weight = kernel.attribute_weight
    if isinstance(weight, (bool, np.bool_, np.float32)) or not isinstance(weight, (float, np.float64)):
        raise ValueError("attribute_weight must be a Python float or float64")
    weight = np.float64(weight)
    if not np.isfinite(weight) or not 0 <= weight <= 1:
        raise ValueError("attribute_weight must lie in [0, 1]")
    m = len(kernel.edge_indices)
    if len(set(kernel.edge_indices)) != m:
        raise ValueError("kernel edge order must be unique")
    incidence = tuple(kernel.incidence_positions)
    if len(incidence) != 2 * (len(candidates) + 1):
        raise ValueError("need source out/in followed by candidate out/in incidence")
    for positions in incidence:
        if not isinstance(positions, np.ndarray) or positions.ndim != 1 or positions.dtype.kind not in "iu":
            raise ValueError("incidence positions must be one-dimensional integer arrays")
        if len(positions) and (np.any(positions < 0) or np.any(positions >= m)):
            raise ValueError("incidence position is outside the frozen edge order")
        if len(np.unique(positions)) != len(positions):
            raise ValueError("incidence lists cannot count the same edge twice")
    # Every degree <=m; two absolute differences and their sum remain exact
    # integers in float64.  The subsequent +1 is enclosed by outward arithmetic.
    if m >= 2 ** 51:
        raise ValueError("edge count exceeds the exact integer-degree contract")
    return attribute, lexical, weight, incidence, m, len(candidates)


def _states(value, name: str, width: int) -> np.ndarray:
    if not isinstance(value, np.ndarray) or value.dtype != np.bool_ or value.ndim != 2:
        raise ValueError(f"{name} must be a two-dimensional Boolean numpy array")
    if value.shape[1] != width:
        raise ValueError(f"{name} width differs from the frozen edge order")
    return value


def _down(value):
    return np.nextafter(np.asarray(value, dtype=np.float64), -np.inf)


def _up(value):
    return np.nextafter(np.asarray(value, dtype=np.float64), np.inf)


def _add(left, right):
    return _down(np.add(left[0], right[0])), _up(np.add(left[1], right[1]))


def _multiply_nonnegative(left, right):
    """General signed interval product; coefficients may enclose signed zero."""
    products = np.stack(np.broadcast_arrays(
        np.multiply(left[0], right[0]), np.multiply(left[0], right[1]),
        np.multiply(left[1], right[0]), np.multiply(left[1], right[1]),
    ))
    return _down(np.min(products, axis=0)), _up(np.max(products, axis=0))


def _l1_degree_intervals(low_degrees, high_degrees):
    source_low = low_degrees[:, :2, None]
    source_high = high_degrees[:, :2, None]
    target_low = np.stack((low_degrees[:, 2::2], low_degrees[:, 3::2]), axis=1)
    target_high = np.stack((high_degrees[:, 2::2], high_degrees[:, 3::2]), axis=1)
    minimum = np.maximum(0, np.maximum(source_low - target_high, target_low - source_high))
    maximum = np.maximum(np.abs(source_low - target_high), np.abs(source_high - target_low))
    # Integer extrema enclose every consistent shared-edge assignment, even
    # when independently attained degree endpoints are jointly impossible.
    return np.sum(minimum, axis=1, dtype=np.int64), np.sum(maximum, axis=1, dtype=np.int64)


def score_intervals(kernel, low_states: np.ndarray, high_states: np.ndarray):
    """Outward float64 score bounds for every Boolean state in [low, high]."""
    attribute, lexical, weight, incidence, m, _ = _kernel_inputs(kernel)
    low_states = _states(low_states, "low_states", m)
    high_states = _states(high_states, "high_states", m)
    if low_states.shape != high_states.shape or np.any(low_states & ~high_states):
        raise ValueError("state intervals must have equal shapes and low<=high")
    n = len(low_states)
    lower_degrees = np.empty((n, len(incidence)), dtype=np.int64)
    upper_degrees = np.empty_like(lower_degrees)
    for column, positions in enumerate(incidence):
        lower_degrees[:, column] = np.sum(low_states[:, positions], axis=1, dtype=np.int64)
        upper_degrees[:, column] = np.sum(high_states[:, positions], axis=1, dtype=np.int64)
    dmin, dmax = _l1_degree_intervals(lower_degrees, upper_degrees)
    denominator = _add((np.float64(1), np.float64(1)),
                       (dmin.astype(np.float64), dmax.astype(np.float64)))
    if np.any(denominator[0] <= 0):
        raise AssertionError("positive structural denominator contract failed")
    dynamic = (_down(np.divide(np.float64(1), denominator[1])),
               _up(np.divide(np.float64(1), denominator[0])))
    lexical_term = _multiply_nonnegative((np.float64(.6), np.float64(.6)),
                                         (lexical[None, :], lexical[None, :]))
    dynamic_term = _multiply_nonnegative((np.float64(.4), np.float64(.4)), dynamic)
    structural = _add(lexical_term, dynamic_term)
    # (1-a) is itself an operation in the actual scorer.  Enclose that
    # subtraction too rather than substituting an exact real-valued weight.
    complement = (_down(np.subtract(np.float64(1), weight)),
                  _up(np.subtract(np.float64(1), weight)))
    attribute_term = _multiply_nonnegative((weight, weight),
                                           (attribute[None, :], attribute[None, :]))
    result = _add(attribute_term, _multiply_nonnegative(complement, structural))
    lower, upper = np.broadcast_arrays(result[0], result[1])
    lower, upper = lower.copy(), upper.copy()
    if not np.isfinite(lower).all() or not np.isfinite(upper).all():
        raise ValueError("nonfinite outward score interval")
    if np.any(lower > upper):
        raise AssertionError("invalid outward score interval")
    return lower, upper


def ambiguity_indicators(kernel, q: np.ndarray, low: np.ndarray, high: np.ndarray,
                         uniforms: np.ndarray) -> np.ndarray:
    """Return h(U) dominating all counterfactual winner mismatches in the box.

    The nominal winner uses kernel.scores(U<q), first-column ties, exactly as
    the capture kernel.  All-fixed rows have the same state and therefore the
    same winner, including score ties; they need no strict score separation.
    On other rows only a strictly separated nominal-winner score interval
    yields h=0.  h=1 means unresolved possibility, not an observed flip.
    """
    _, _, _, _, m, k = _kernel_inputs(kernel)
    q, low, high = (_float64_array(value, name, 1)
                    for value, name in ((q, "q"), (low, "low"), (high, "high")))
    uniforms = _float64_array(uniforms, "uniforms", 2)
    if q.shape != (m,) or low.shape != q.shape or high.shape != q.shape or uniforms.shape[1] != m:
        raise ValueError("probability/uniform shapes differ from the frozen edge order")
    if np.any(low < 0) or np.any(high > 1) or np.any(low > q) or np.any(q > high):
        raise ValueError("declared box must lie in [0,1] and contain q")
    if np.any(uniforms < 0) or np.any(uniforms >= 1):
        raise ValueError("uniform draws must lie in [0,1)")
    n = len(uniforms)
    if k == 1:
        return np.zeros(n, dtype=np.bool_)
    lower_states = uniforms < low[None, :]
    upper_states = uniforms < high[None, :]
    free = np.any(lower_states != upper_states, axis=1)
    result = np.zeros(n, dtype=np.bool_)
    if not np.any(free):
        return result
    selected_uniforms = uniforms[free]
    nominal_scores = kernel.scores(selected_uniforms < q[None, :])
    nominal_scores = _float64_array(nominal_scores, "nominal scores", 2)
    if nominal_scores.shape != (len(selected_uniforms), k):
        raise ValueError("kernel returned an unexpected score shape")
    winners = np.argmax(nominal_scores, axis=1)
    lower_scores, upper_scores = score_intervals(kernel, lower_states[free], upper_states[free])
    row_indices = np.arange(len(winners))
    winner_lower = lower_scores[row_indices, winners]
    competitor_upper = upper_scores.copy()
    competitor_upper[row_indices, winners] = -np.inf
    separated = winner_lower > np.max(competitor_upper, axis=1)
    result[free] = ~separated
    return result


def confidence_upper(count: int, n: int, beta: float) -> float:
    """Fixed-N Hoeffding UCB; the caller allocates beta across selected boxes.

    No optional stopping or data-dependent choice of N is protected.  Decimal
    ln/sqrt are correctly rounded; taking adjacent Decimal values outwards
    before final float64 nextafter avoids assuming a platform libm error bound.
    """
    if type(count) is not int or type(n) is not int or n < 1 or not 0 <= count <= n:
        raise ValueError("need integer 0<=count<=n with n positive")
    if isinstance(beta, bool) or not isinstance(beta, (float, np.float64)):
        raise ValueError("beta must be a float64-compatible floating value")
    beta = float(beta)
    if not math.isfinite(beta) or not 0 < beta < 1:
        raise ValueError("beta must lie strictly in (0,1)")
    if count == n:
        return 1.0
    context = Context(prec=80, rounding=ROUND_CEILING)
    log_beta = context.ln(Decimal.from_float(beta))
    log_inverse_upper = context.minus(context.next_minus(log_beta))
    variance_upper = context.divide(log_inverse_upper, Decimal(2 * n))
    radius_upper = context.next_plus(context.sqrt(variance_upper))
    mean_upper = context.divide(Decimal(count), Decimal(n))
    upper = context.add(mean_upper, radius_upper)
    if upper >= Decimal(1):
        return 1.0
    return min(1.0, float(np.nextafter(np.float64(float(upper)), np.inf)))
