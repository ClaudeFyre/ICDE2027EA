"""Freeze the budget after pilot, then report all completed confirmation runs."""
from __future__ import annotations
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from icde_prospective_20261107 import BASE, DATA, POLICIES, load, save, sha


def freeze():
    pilot_paths = sorted((BASE / "pilot").glob("*/summary.json"))
    rows = [row for path in pilot_paths for row in load(path)["rows"]]
    result = {}
    for graph in ("dw", "enfr"):
        selected = [r for r in rows if r["graph"] == graph and r["tau"] == .25 and r["policy"] == "cheap" and r["retained_candidates"] > 1]
        if not selected:
            raise ValueError("pilot has no competitive query for budget scale")
        b0 = max(.01, statistics.median(r["response_seconds_including_persistence"] for r in selected))
        result[graph] = {"B0_seconds": b0, "primary_deadline_seconds": 2*b0,
            "budget_curve_seconds": [x*b0 for x in (.5, 1., 2., 4.)], "pilot_competitive_rows": len(selected)}
    guarded = [ROOT / "scripts/icde_prospective_20261107.py", ROOT / "scripts/icde_strong_bounds_20261106.py",
        ROOT / "scripts/vldb_event_bound_v2.py", ROOT / "scripts/vldb_difference_envelope_v2.py"]
    save(BASE / "confirmation_protocol.json", {"status": "FROZEN_AFTER_PILOT_BEFORE_CONFIRMATION",
        "budgets": result, "primary_tau": .25, "seeds": [211,223,227],
        "primary_ranks": [32,288], "sensitivity_ranks": [32,96],
        "budget_scale": "median complete response time of pilot cheap competitive queries at tau=.25, minimum B0=.01s; all completed cap runs included regardless of certification",
        "primary_endpoint": "delivered certificates within warm per-query budget; static construction and artifact loading reported separately and amortized explicitly",
        "direct_control": "global all-state outward score intervals, then strong cheap inference if unresolved; no sampling needed when the global interval already separates a winner",
        "pilot_inputs": {p.relative_to(ROOT).as_posix(): sha(p) for p in pilot_paths},
        "code_sha256": {p.relative_to(ROOT).as_posix(): sha(p) for p in guarded},
        "policy_change_after_confirmation_requires_new_confirmation_ids": True})
    print(json.dumps(result), flush=True)


def cluster_interval(rows, graph, policy, endpoint, reference="cheap"):
    by_query = defaultdict(dict)
    for row in rows:
        if row["graph"] == graph:
            by_query[(row["rank"], row["seed"])][row["policy"]] = row
    differences = defaultdict(list)
    for (rank, seed), pair in by_query.items():
        if reference in pair and policy in pair:
            differences[rank].append(float(pair[policy][endpoint])-float(pair[reference][endpoint]))
    vector = np.asarray([np.mean(values) for values in differences.values()])
    if not len(vector):
        return None
    rng = np.random.default_rng(20261107)
    replicates = vector[rng.integers(0,len(vector),size=(5000,len(vector)))].mean(axis=1)
    return {"query_count": len(vector), "difference_mean": float(vector.mean()),
        ("difference_seconds" if endpoint.endswith("seconds_including_persistence") else "difference_fraction"):float(vector.mean()),
        "paired_source_bootstrap_95pct": list(map(float,np.quantile(replicates,[.025,.975]))),
        "scope": "descriptive paired query bootstrap within this known graph; seeds nested; not a cross-graph generalization guarantee"}


def summarize():
    protocol = load(BASE / "confirmation_protocol.json")
    paths = sorted((BASE / "confirmation").glob("*/summary.json"))
    rows, consumed, checks = [], [], []
    for path in paths:
        summary = load(path)
        consumed.append({"path": path.relative_to(ROOT).as_posix(), "sha256": sha(path)})
        for row in summary["rows"]:
            if sha(ROOT / row["case"]) != row["case_sha256"]:
                raise ValueError("completed case changed")
            row = dict(row)
            row["run_tag"] = path.parent.name
            row["deadline_seconds"] = summary["deadline_seconds"]
            rows.append(row)
    primary = [r for r in rows if r["run_tag"].startswith("primary_") and r["tau"] == .25]
    table = []
    load_once = {}
    for row in primary:
        key = row["graph"],row["rank"]
        if key not in load_once:
            load_once[key] = load(ROOT/row["case"])["shared_static_query_load_seconds"]
    for graph in ("dw", "enfr"):
        for policy in POLICIES:
            selected = [r for r in primary if r["graph"] == graph and r["policy"] == policy]
            unique = {(r["rank"],r["seed"]) for r in selected}
            if len(unique) != len(selected):
                raise ValueError("duplicate primary query/seed/policy")
            if not selected:
                continue
            nontrivial = [r for r in selected if r["retained_candidates"] > 1]
            table.append({"graph": graph, "policy": policy, "query_seed_cases": len(selected),
                "distinct_queries": len({r["rank"] for r in selected}),
                "delivered_certificates": sum(r["delivered_within_budget"] for r in selected),
                "competitive_cases": len(nontrivial), "competitive_delivered": sum(r["delivered_within_budget"] for r in nontrivial),
                "mean_worlds": statistics.mean(r["worlds"] for r in selected),
                "mean_event_worlds": statistics.mean(r["event_worlds"] for r in selected),
                "total_response_seconds": sum(r["response_seconds_including_persistence"] for r in selected),
                "prepared_query_load_seconds_once_each":sum(v for (g,rank),v in load_once.items() if g==graph),
                "p50_response_seconds": float(np.quantile([r["response_seconds_including_persistence"] for r in selected],.5)),
                "p95_response_seconds": float(np.quantile([r["response_seconds_including_persistence"] for r in selected],.95)),
                "deadline_overrun_cases": sum(r["response_seconds_including_persistence"]>r["deadline_seconds"] for r in selected)})
    contrasts = {g: {p: cluster_interval(primary,g,p,"delivered_within_budget") for p in ("direct","eager","lazy")} for g in ("dw","enfr")}
    direct_contrasts = {g: {p: cluster_interval(primary,g,p,"delivered_within_budget", "direct") for p in ("eager","lazy")} for g in ("dw","enfr")}
    runtime_contrasts = {g:cluster_interval(primary,g,"lazy","response_seconds_including_persistence","eager") for g in ("dw","enfr")}
    # Shared random-prefix identity is checked at every common observed look.
    groups = defaultdict(list)
    for row in primary:
        groups[(row["graph"],row["rank"],row["seed"])].append(row)
    prefix_checks = 0
    for group in groups.values():
        look_hashes = defaultdict(set)
        for row in group:
            raw = load(ROOT / row["case"])
            if sum(raw["winner_counts"]) != raw["worlds"] or raw["event_worlds"] > raw["worlds"]:
                raise AssertionError("inconsistent evidence prefix")
            for point in raw["trace"]:
                look_hashes[point["n"]].add(point["winner_prefix_sha256"])
        for hashes in look_hashes.values():
            if len(hashes) > 1:
                raise AssertionError("paired policies did not use the same random prefix")
            prefix_checks += 1
    curve_groups = defaultdict(list)
    for row in rows:
        if row["run_tag"].startswith("curve_"):
            curve_groups[(row["graph"],row["deadline_seconds"],row["policy"])].append(row)
    curves = [{"graph":g,"budget_seconds":b,"policy":p,"cases":len(items),
        "delivered":sum(r["delivered_within_budget"] for r in items),
        "competitive_cases":sum(r["retained_candidates"]>1 for r in items),
        "competitive_delivered":sum(r["retained_candidates"]>1 and r["delivered_within_budget"] for r in items)}
        for (g,b,p),items in sorted(curve_groups.items())]
    sensitivity_groups = defaultdict(list)
    for row in rows:
        if row["run_tag"].startswith("sensitivity_"):
            sensitivity_groups[(row["graph"],row["tau"],row["policy"])].append(row)
    sensitivity = [{"graph":g,"tau":t,"policy":p,"cases":len(items),
        "delivered":sum(r["delivered_within_budget"] for r in items)}
        for (g,t,p),items in sorted(sensitivity_groups.items())]
    preparation = {g: load(BASE/"prepared"/g/"summary.json") for g in ("dw","enfr")}
    job_records=[]
    for job_path in sorted((ROOT/".runtime/runs").glob("icde-prospective-*.json")):
        record=load(job_path)
        job_records.append({"task_id":record["task_id"],"status":record["status"],"elapsed_seconds":record["elapsed_seconds"],
            "peak_job_memory_gb":record.get("peak_job_memory_gb"),"record_sha256":sha(job_path)})
    exact=load(BASE/"new_exact_reference/summary.json")
    cold=load(BASE/"prepared_service_cold/summary.json")
    witnesses=load(BASE/"full_cube_witnesses/summary.json")
    outcome = {"status": "COMPLETE_FROZEN_CONFIRMATION_AND_DIAGNOSTICS", "protocol_sha256": sha(BASE/"confirmation_protocol.json"),
        "primary": table, "paired_contrasts": contrasts, "contrasts_vs_direct_control":direct_contrasts,
        "runtime_contrasts_lazy_minus_eager_seconds":runtime_contrasts,"curves":curves,"sensitivity":sensitivity,
        "primary_case_rows":len(primary), "distinct_primary_queries":len({(r["graph"],r["rank"]) for r in primary}),
        "paired_prefix_look_checks":prefix_checks,"case_hash_checks":len(rows),"consumed":consumed,
        "construction_seconds":{g:preparation[g]["full_construction_seconds"] for g in preparation},
        "prepared_load_seconds_once_per_query":{g:sum(v for (graph,rank),v in load_once.items() if graph==g) for g in preparation},
        "guarded_research_jobs":job_records,
        "exact_reference_queries":exact["distinct_confirmation_queries"],"exact_audited_primary_actions":exact["audited_primary_actions"],
        "exact_false_clear":exact["false_clear"],"cold_process_runs":cold["process_runs"],"raw_cold_process_runs":cold["raw_process_runs"],
        "full_cube_witnesses":witnesses["witnesses"],"primary_increment_diagnostic":witnesses["primary_increment_diagnostic"],
        "additional_inputs":{name:sha(BASE/name) for name in ("new_exact_reference/summary.json","prepared_service_cold/summary.json","full_cube_witnesses/summary.json")},
        "limits":["known graph sources; new IDs relative to certification workload", "configured retention law, not fact calibration", "warm budgets exclude one-off construction and loading, separately exposed", "no strong-neural paid-envelope validation", "bootstrap intervals are descriptive"]}
    save(BASE/"final_summary.json",outcome)
    # Audit consumer: only certificates delivered within the budget approve
    # retaining the declared modal answer across the proposed parameter box.
    actions=[]
    requests=[]
    for row in primary:
        raw=load(ROOT/row["case"])
        prepared_identity=load(BASE/"prepared"/row["graph"]/f"q{row['rank']:03d}.json")
        actions.append({"graph":row["graph"],"query_id":row["query_id"],"seed":row["seed"],"policy":row["policy"],
            "action":"reuse_modal_answer_across_declared_box" if row["delivered_within_budget"] else "defer_range_approval",
            "answer":raw["candidate"] if row["delivered_within_budget"] else None,
            "nominal_retention":.9,"tau":row["tau"],"certificate_case_sha256":row["case_sha256"],
            "prepared_kernel_sha256":prepared_identity["kernel_sha256"],
            "scope":"prototype maintenance consumer; defer does not assert instability; not measured industrial labor savings"})
        # Concrete service requests consume only this policy/seed's certificate.
        # Scalar updates are a subset of the certified full-coordinate box.
        # An outside-box update must never inherit the old certificate.
        for proposed in (.775,1.,.5):
            inside=max(0.,.9-row["tau"])<=proposed<=min(1.,.9+row["tau"])
            reusable=inside and row["delivered_within_budget"]
            requests.append({"graph":row["graph"],"query_id":row["query_id"],"seed":row["seed"],"policy":row["policy"],
                "proposed_uniform_retention":proposed,"inside_approved_family":inside,
                "response":"reuse_certified_modal_answer" if reusable else "require_new_evidence",
                "answer":raw["candidate"] if reusable else None,"certificate_case_sha256":row["case_sha256"] if reusable else None})
    save(BASE/"maintenance_actions.json",{"actions":actions,"action_count":len(actions),"requests":requests,
        "request_count":len(requests),"outside_family_reuses":sum(not r["inside_approved_family"] and r["response"]=="reuse_certified_modal_answer" for r in requests),
        "confirmation_protocol_sha256":sha(BASE/"confirmation_protocol.json"),"selection_protocol_sha256":sha(BASE/"selection_protocol.json"),"new_scorer_calls":0,
        "interpretation":"application consumes the same confirmation certificates; not a second independent experiment"})
    lines=["# 新查询前瞻确认与成本结果","","本报告自动汇总实际完成文件，未完成范围不补值。","",
        "## 主比较：tau=0.25，同暖运行时间预算","","| 图 | 策略 | 不同查询 | 查询×种子 | 预算内认证 | 非单候选认证/案例 | 响应总秒 | 超时案例 |",
        "|---|---|---:|---:|---:|---:|---:|---:|"]
    for r in table:
        lines.append(f"| {r['graph']} | {r['policy']} | {r['distinct_queries']} | {r['query_seed_cases']} | {r['delivered_certificates']} | {r['competitive_delivered']}/{r['competitive_cases']} | {r['total_response_seconds']:.3f} | {r['deadline_overrun_cases']} |")
    lines.extend(["","## 配对认证率差（按source聚类；相对cheap）",""])
    for g in contrasts:
        for p,c in contrasts[g].items():
            if c:
                lo,hi=c["paired_source_bootstrap_95pct"]
                lines.append(f"- {g} {p}: {100*c['difference_fraction']:.2f} 个百分点，描述性95%区间 [{100*lo:.2f}, {100*hi:.2f}]。")
    lines.extend(["","相对更强direct控制的增量：",""])
    for g in direct_contrasts:
        for p,c in direct_contrasts[g].items():
            lo,hi=c["paired_source_bootstrap_95pct"]
            lines.append(f"- {g} {p}: {100*c['difference_fraction']:.2f} 个百分点，描述性95%区间 [{100*lo:.2f}, {100*hi:.2f}]。")
    lines.extend(["","## 六种宽度敏感性（每格64个确认查询、一个种子）","",
        "| 图 | tau | cheap | direct | eager | lazy |","|---|---:|---:|---:|---:|---:|"])
    for g in ("dw","enfr"):
        for tau in (.001,.01,.05,.1,.25,1.):
            values={r["policy"]:r["delivered"] for r in sensitivity if r["graph"]==g and r["tau"]==tau}
            lines.append(f"| {g} | {tau:g} | "+" | ".join(str(values[p]) for p in POLICIES)+" |")
    lines.extend(["","## 完整成本与冷启动",""])
    for g in ("dw","enfr"):
        lines.append(f"- {g}: 288查询静态构建 {outcome['construction_seconds'][g]:.2f} 秒；主比较256查询的准备对象恢复另计 {outcome['prepared_load_seconds_once_per_query'][g]:.2f} 秒（对象在策略间共享，不重复相加）。")
        runtime=runtime_contrasts[g]
        lo,hi=runtime["paired_source_bootstrap_95pct"]
        lines.append(f"- {g}: lazy-eager每查询响应均值差 {runtime['difference_seconds']:.6f} 秒，按source配对描述性95%区间 [{lo:.6f}, {hi:.6f}]。")
    lines.extend(["","| 图 | 策略 | 准备对象进程冷启动均值/秒（三次） | 原始数据完整冷启动/秒（一次） |",
        "|---|---|---:|---:|"])
    for g in ("dw","enfr"):
        for p in POLICIES:
            prepared=statistics.mean(r["parent_observed_process_to_exit_seconds"] for r in cold["records"] if r["graph"]==g and r["policy"]==p)
            raw=next(r["parent_observed_full_raw_cold_seconds"] for r in cold["raw_records"] if r["graph"]==g and r["policy"]==p)
            lines.append(f"| {g} | {p} | {prepared:.3f} | {raw:.3f} |")
    lines.extend(["","冷启动诊断只选择每图一个输入属性限定的pilot查询，不能估计全体查询尾延迟。原始冷启动包含完整语料/图准备；计算阶段期限不等于整次冷启动期限。统计边界每case重新构建，未实现所有不可能通过的预检查或跨查询缓存；这些程序耗时不能宣称最优加速比。",
        "","## 精确参考与歧义诊断", "",
        f"新确认查询中有 {exact['distinct_confirmation_queries']} 个满足非单候选且完整scope≤8，共 {exact['full_box_references']} 个连续参数族精确参考；{exact['audited_primary_actions']} 个主比较动作经两套独立Fraction计算核验，观测到的错误审批为 {exact['false_clear']}。这不证明未枚举大图的零错误率。",
        "",f"对全部512查询，八个固定确定世界找到了 {witnesses['witnesses']} 个完整[0,1]参数族没有统一众数的有效见证。未找到见证不代表稳定。该诊断在主比较后设计，属于探索性机制分析。"])
    for g in ("dw","enfr"):
        for p in ("eager","lazy"):
            diagnostic=witnesses["primary_increment_diagnostic"][g][p]
            lines.append(f"- {g} {p}: 相对direct新增 {diagnostic['paid_only_cases_vs_direct']} 个查询×种子认证，其中 {diagnostic['paid_only_cases_with_proven_nonconstant_world_winner']} 个有确定世界赢家变化见证。后者不能由任何全世界固定赢家证明替代；这不否定其tau=.25受限族的众数稳定证书。")
    lines.extend(["",'[说明文本已清理]', "",
        "结构证据是否仍有价值，以相对强direct控制的新查询净增益及成本共同判断。按需门控的独立贡献必须相对标准generic eager判断，不能把全部结构证据增益归给它。完整立方体上直接区间的作用单列，不再把旧tau=1付费增益当作采样方法新意。",
        "","概率依据已明确落实为程序实际执行的独立保留机制；这支持声明模型内的条件查询保证。真实事实概率校准、真实对齐准确率改善、工业需求以及strong-neural付费包络并未由这组degree实验建立。",
        "",'[说明文本已清理]'])
    lines.extend(["","## 概率与成本边界","","使用完整15K候选并进行世界一致的候选裁剪；图和scorer的静态构建成本分别为 "+", ".join(f"{g}: {outcome['construction_seconds'][g]:.2f} 秒" for g in preparation)+"。这些成本未隐藏在暖运行加速中。",
        "","概率来自明确配置的独立边保留机制。维护消费日志只展示如何使用证书，不代表真实工业部署，也不产生事实概率校准或真实对齐准确率保证。",
        "","当前查询来自已知OpenEA来源，按历史认证ID排除后前瞻冻结；不是未见来源。确认集之后不允许按结果修改方法并继续称为同一次确认。",
        "","候选保留、精确小scope参考、冷启动与完整摊销另见相应文件；大图有限采样不能作完整参数族真值。"])
    (BASE/"RESULTS_ZH.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({"primary_rows":len(primary),"table":table,"contrasts":contrasts}),flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("freeze","summarize"))
    args=parser.parse_args()
    (freeze if args.command=="freeze" else summarize)()


if __name__=="__main__":
    main()
