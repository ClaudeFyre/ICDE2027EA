"""60-digit W2 with exact binary float inputs and high-precision winner choice."""
from __future__ import annotations
import mpmath as mp

DIGITS = 60


def scalar(value):
    # mp.mpf(float) at >=53 bits preserves the binary float exactly.
    return mp.mpf(float(value))


def psd_sqrt(matrix):
    eigenvalues, vectors = mp.eigsy(matrix)
    if min(eigenvalues) < -mp.mpf("1e-40"):
        raise ValueError("high-precision input is not PSD")
    return vectors * mp.diag([mp.sqrt(max(v, 0)) for v in eigenvalues]) * vectors.T


def w2(mean_a, cov_a, mean_b, cov_b):
    with mp.workdps(DIGITS):
        n = len(mean_a)
        # Subtraction happens after conversion, not in float64.
        dm = sum((scalar(a) - scalar(b)) ** 2 for a, b in zip(mean_a, mean_b))
        a = mp.matrix([[scalar(cov_a[i][j]) for j in range(n)] for i in range(n)])
        b = mp.matrix([[scalar(cov_b[i][j]) for j in range(n)] for i in range(n)])
        # Stress diagonals allow a simpler independent exact expression.
        diagonal = all(a[i, j] == b[i, j] == 0 for i in range(n) for j in range(n) if i != j)
        if diagonal:
            covariance = sum((mp.sqrt(a[i, i]) - mp.sqrt(b[i, i])) ** 2 for i in range(n))
        else:
            root = psd_sqrt(a)
            middle = root * b * root
            middle = (middle + middle.T) / 2
            vals = mp.eigsy(middle, eigvals_only=True)
            if min(vals) < -mp.mpf("1e-40"):
                raise ValueError("high-precision Bures middle is not PSD")
            covariance = sum(a[i, i] + b[i, i] for i in range(n)) - 2 * sum(mp.sqrt(max(v, 0)) for v in vals)
        squared = dm + covariance
        if squared < -mp.mpf("1e-40"):
            raise ValueError("negative high-precision W2 squared")
        return mp.sqrt(max(squared, 0))


def distances_and_winner(qm, qc, means, covariances):
    with mp.workdps(DIGITS):
        distances = [w2(qm, qc, m, c) for m, c in zip(means, covariances)]
        order = sorted(range(len(distances)), key=lambda i: (distances[i], i))
        gap = distances[order[1]] - distances[order[0]] if len(order) > 1 else mp.inf
        return distances, order[0], gap
