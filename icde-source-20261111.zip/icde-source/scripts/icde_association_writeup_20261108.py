"""Produce consolidated tables from frozen mechanism and corrected signal data."""
from pathlib import Path
from icde_grouped_inventory_20261108 import ROOT,load,save,sha
from icde_association_study_20261108 import BASE as INITIAL
from icde_association_followup_20261108 import BASE as FOLLOWUP,corrected_metrics


def main():
    base=INITIAL.parent
    q=load(INITIAL/'quantifier_census.json');d=load(INITIAL/'static_diagnosis.json')
    c=load(FOLLOWUP/'strong_population_controls.json');a=load(FOLLOWUP/'alignment_signal_corrected.json')
    validation=load(base/'validation.json')
    assert validation['status']=='PASS'
    lines=['# 参数一致性路线的首轮实测与强对照（2026-11-08）','',
        '已完成三项有限工作：全部148个可行历史query的精确量词遗漏统计、全部576个历史query的结构与准入重建、'
        '512个历史source×3种子的真实标签增量诊断。另补标准精确事件与最优scalar总体控制。没有增加随机世界、新前瞻query或新选择器。','',
        '[说明文本已清理]','',
        '## 1. 冻结协议与口径','',
        '- 独立保留q=.9、τ=.25，使用原clipped_box的向外舍入区间；所有高端点为1。固定原degree scorer、完整候选保留合同与tie。',
        '- 148是原静态prototype_eligible全体，未按本轮结果筛选；包含15个旧pilot、133个旧confirmation，均已是历史资产。',
        '- 真值来自计数张量、独立端点轨道与任意精度整数概率求值；与前轮148个精确参考相符。',
        '- 逐输入总体量：suffix OR精确求每个固定-one计数下的完整可实现赢家集合，再用Binomial(low)精确加权。'
        '因此负gap不是抽象实现太松或MC样本不足造成的。捷径不自动适用于高端点小于1的盒。',
        '- 标准scalar控制用精确名义概率与全族最优候选事件漂移；分别事件控制用精确min π_w和max π_d。'
        '它们是付费完整参考上的总体审查，不是免费的在线策略或完整发表系统复现。','',
        '## 2. 量词遗漏率','',
        '| 子组 | query数 | 真正鲁棒 | 逐输入遗漏 | 占全体 | 占鲁棒 |',
        '| --- | ---: | ---: | ---: | ---: | ---: |']
    for name,r in q['summary'].items():
        lines.append(f"| {name} | {r['queries']} | {r['robust_queries']} | {r['pointwise_omissions']} | {100*r['fraction_of_all']:.2f}% | {100*r['fraction_of_robust']:.2f}% |")
    lines+=['','| 查询 | 候选K | scope边 | 计数状态S | 真正最小gap | 逐输入最小gap |',
            '| --- | ---: | ---: | ---: | ---: | ---: |']
    for r in q['rows']:
        if r['quantifier_omission']:
            w=r['uniform_winners'][0]
            lines.append(f"| {r['graph']} q{r['rank']:03d} | {r['retained_candidates']} | {r['scope_edges']} | {r['count_states']} | {r['true_minimum_gaps'][w]:.6f} | {r['minimum_gaps'][w]:.6f} |")
    lines+=['','所有10个遗漏的逐输入总体gap都严格负，不是仅恰好等于0。4个scope≥20，'
        '所以现象超出原两个小例子；但全部来自同一degree类与配置机制，不能推为任意EA模型上的比例。','',
        '## 3. 新增的标准强对照改变了什么','',
        '| 条件 | 可认证query数 |', '| --- | ---: |',
        '| 精确逐输入方向条件 | 91 |','| 最优候选事件漂移＋标准2ε scalar条件 | 99 |',
        '| 分别精确事件界min π_w−max π_d | 101 |','| 精确成对gap参考 | 101 |','',
        '10个遗漏中，最优scalar恢复8个；剩余D–W q052/q285也被分别事件界恢复。'
        '本批没有“真实鲁棒但分别精确事件界仍无法认证”的query。'
        '据此可以反驳逐输入充分条件的完备性，不能反驳所有Monniaux框架、credal networks或概率电路。'
        '当前原型本身已计算完整候选概率张量，分别事件界可以从同一张量得到；'
        '尚未建立新pair机制的独有判定能力。','',
        '下一技术比较必须转到scorer编码、编译表示、求值费用与可支持查询类。'
        '本轮未测完整Wijk/C-FOVE/SPROUT系统，不声称它们更慢、更大或更松。','',
        '## 4. 全部576个query的准入诊断','',
        '| 类别 | 数量 |', '| --- | ---: |']
    for name,count in d['categories'].items():lines.append(f'| {name} | {count} |')
    lines+=['','148之外的428个包含169个平凡单候选、198个已有结构盘点但超原型门槛的竞争query、'
        '61个旧盘点跳过的query；本轮从原始triples和冻结edge ID重建了全部576个作用签名，'
        '原346个非单候选结构盘点均一致。','',
        '| 259个超限竞争query的失败条件（重叠） | 数量 |','| --- | ---: |']
    for name,count in d['excluded_resource_overlap'].items():lines.append(f'| {name} | {count} |')
    lines+=['','组合失败条件：','', '| 组合 | 数量 |','| --- | ---: |']
    for name,count in d['excluded_filter_combinations'].items():lines.append(f'| {name} | {count} |')
    lines+=['','其中10个query没有超过计数状态上限，但超过估计算术工作门槛。'
        '可行竞争组G中位5，超资源组G中位26；log2 S中位分别8.755和47.487。'
        '这些是实现资源门槛，不是不可解或困难性证明；全部数据也没有覆盖第二种scorer。','',
        '## 5. 稳定性是否提供真实准确率增量','',
        '使用已保存的eager预测，每个query×seed的答案固定为原MC领先者。'
        '原512个source全部纳入，三seed作为重复；无MC证据的竞争案例数为0。'
        '基线：有符号期望分数margin、保留候选softmax、MC频率、log候选数、log采样数及图标记；'
        '扩展只加robust stable标记。五折source哈希、同source的seed同折、训练内标准化、固定ridge=1。','',
        '| 全体OOF指标（低为好） | 基线 | +稳定性 | 差值 | 描述性95%区间 |',
        '| --- | ---: | ---: | ---: | --- |']
    for key,r in a['differences'].items():
        old=a['subgroups']['all']['baseline'][key];new=a['subgroups']['all']['baseline_plus_stability'][key]
        lo,hi=r['descriptive_source_bootstrap_95pct']
        lines.append(f'| {key} | {old:.6f} | {new:.6f} | {new-old:+.6f} | [{lo:+.6f}, {hi:+.6f}] |')
    lines+=['','1000次按图分层source bootstrap固定OOF拟合，未覆盖重拟合不确定性与图内全局依赖。'
        '结果未显示可靠的正增量，不等于稳定性在所有模型下无信息或条件互信息为零。','',
        '| 子组 | query数 | query×seed数 | 基线AURC | +稳定性AURC | 基线Brier | +稳定性Brier |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for name,r in a['subgroups'].items():
        lines.append(f"| {name} | {r['distinct_queries']} | {r['query_seed_cases']} | {r['baseline']['aurc']:.6f} | {r['baseline_plus_stability']['aurc']:.6f} | {r['baseline']['brier']:.6f} | {r['baseline_plus_stability']['brier']:.6f} |")
    lines+=['','| 全体状态 | query×seed | 不同source（跨seed可能重叠） | 真实准确率 |',
        '| --- | ---: | ---: | ---: |']
    for flag,r in a['subgroups']['all']['strata'].items():
        lines.append(f"| stable={flag} | {r['query_seed_cases']} | {r['distinct_queries']} | {100*r['accuracy']:.2f}% |")
    lines+=['','stable与正确性有边际关联，但未在现有特征之外建立可靠增量。'
        'WSDM效用下降不意味着稳定集合一定比弃权集合更差：U=正确−错误下，新增批准准确率低于1/2即可使U下降，'
        '即使其准确率高于弃权集合。本轮准确率不能外推WSDM其他backbone。','',
        '本degree程序整体预测准确率28.39%、候选真值保留率44.53%；竞争query的真值保留率33.43%。'
        '候选保留的是固定scorer的世界winner语义，不保证真实标签候选召回。'
        '保留候选softmax不等于完整15K softmax，MC频率来自自适应停止前缀；本轮不宣称标签风险已校准。','',
        '## 6. 报告修正与审计','',
        '初版proper score计算误配了排序后的标签与未排序的概率。旧文件冻结保留，'
        '此报告只使用strong_control_and_signal_correction_attempt1中的修正结果；'
        '折分、拟合、OOF概率、预测、AURC和AUROC逐项保持不变。'
        '详见[修正说明](attempt1/REPORTING_CORRECTION.md)。','',
        f"独立核验通过{validation['checks']:,}项检查；七项新增单元测试通过。"
        '来源包括全部输入/代码哈希、精确结果与逐query文件、标准充分界重算、完整矩阵、真实标签、source折分和proper score独立复算。'
        '核验共享既有精确数值参考，不等于第二套独立推断实现。','',
        '## 7. 研究决策与产物','',
        '主线调整为候选“成本有效的结构化全族求值”；方法选择降为组件，generic eager按标准强基线归属。'
        '下一比较是同一scorer的计数/事件/credal表示和实际编译费用，不能只继续增加小调度。'
        '准确率动机收窄，保留配置维护作为尚需实际需求支持的场景。','',
        '- [研究决策](../../../../papers/icde/regular2027/PARAMETER_ASSOCIATION_DECISION_20261108.md)',
        '- [充分查询类与证明](../../../../papers/icde/regular2027/COUNTABLE_SCORER_CLASS_THEORY_20261108.md)',
        '- [英文引言候选段落](../../../../papers/icde/regular2027/INTRO_PARAMETER_ASSOCIATION_DRAFT_20261108.md)',
        '- [最终四面板PDF](figures_publication/association_diagnostics.pdf) / [PNG](figures_publication/association_diagnostics.png)',
        '- [精确量词统计](attempt1/quantifier_census.json)、[576结构诊断](attempt1/static_diagnosis.json)',
        '- [标准强对照](strong_control_and_signal_correction_attempt1/strong_population_controls.json)',
        '- [修正后的标签增量](strong_control_and_signal_correction_attempt1/alignment_signal_corrected.json)、[独立核验](validation.json)','']
    target=base/'RESULTS_ZH.md'
    with target.open('x',encoding='utf-8') as f:f.write('\n'.join(lines))
    sources=[target,base/'validation.json',INITIAL/'protocol.json',FOLLOWUP/'protocol.json',
             INITIAL/'quantifier_census.json',INITIAL/'static_diagnosis.json',FOLLOWUP/'strong_population_controls.json',
             FOLLOWUP/'alignment_signal_corrected.json',base/'figures_publication/association_diagnostics.pdf',
             base/'figures_publication/association_diagnostics.png']
    sources+=[ROOT/'papers/icde/regular2027'/name for name in ('PARAMETER_ASSOCIATION_DECISION_20261108.md',
              'COUNTABLE_SCORER_CLASS_THEORY_20261108.md','INTRO_PARAMETER_ASSOCIATION_DRAFT_20261108.md')]
    sources+=[ROOT/'scripts'/name for name in ('icde_association_validate_20261108.py',
               'icde_association_figures_20261108.py','icde_association_writeup_20261108.py')]
    save(base/'artifact_manifest.json',{'sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in sources},
         'primary_signal_file':'strong_control_and_signal_correction_attempt1/alignment_signal_corrected.json',
         'initial_proper_scores_superseded':True})
    print(target)


if __name__=='__main__':main()
