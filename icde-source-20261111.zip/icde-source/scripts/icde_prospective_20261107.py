"""Prospective configured-retention queries: audit, construct, serve, summarize.

New query IDs relative to the archived certification study, on known OpenEA
sources. Full 15K target corpus; sparse TF-IDF is a NEW frozen numerical scorer
revision (not an asserted bitwise replacement of the old Python cosine).
Standard mixture/event/transport tools remain attributed controls.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from difflib import SequenceMatcher
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import numpy as np

BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_prospective_20261107"
DATA = ROOT / ".runtime/www_quality_recovery_v13_data"
TAUS = (.001, .01, .05, .1, .25, 1.)
LOOKS = (32, 64, 128, 256, 512, 1024)
POLICIES = ("cheap", "direct", "eager", "lazy")
TRANSPORTS = ("tv", "chi2_pair", "chi2_event", "hellinger_event")
SALT = "icde-prospective-confirmation-20261107-v1"


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    pending = path.with_suffix(path.suffix + ".pending")
    with pending.open("x", encoding="utf-8") as stream:
        json.dump(json_safe(value), stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(pending, path)


def json_safe(value):
    # Infinite divergence is a legitimate vacuous bound, not a JSON number.
    if isinstance(value, float) and math.isinf(value):
        return "Infinity" if value > 0 else "-Infinity"
    if isinstance(value, dict):
        return {key: json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    return value


def tsv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def historical_ids(value, found):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ("query_id", "source_entity_id") and isinstance(item, str):
                found.add(item)
            elif key in ("query_ids", "query_source_ids", "selected_source_ids", "selected_sources") and isinstance(item, list):
                found.update(x for x in item if isinstance(x, str))
            else:
                historical_ids(item, found)
    elif isinstance(value, list):
        for item in value:
            historical_ids(item, found)


def audit():
    BASE.mkdir(parents=True, exist_ok=True)
    found, files, failures = set(), [], []
    results = ROOT / "nodes/09_vldb_query_certification/results"
    # Setup/protocol records contain all evaluated IDs, including shard slices.
    for path in sorted(results.rglob("*.json")):
        if BASE in path.parents or not (path.name.startswith(("setup", "protocol"))):
            continue
        try:
            historical_ids(load(path), found)
            files.append({"path": path.relative_to(ROOT).as_posix(), "sha256": sha(path)})
        except (ValueError, OSError) as error:
            failures.append({"path": str(path), "error": str(error)})
    for graph in ("d-w", "en-fr"):
        path = ROOT / f"data/interim/openea-{graph}-probe-q500-a512-attributes-independent-s17/alignments.tsv"
        found.update(row["source_entity_id"] for row in tsv(path))
        files.append({"path": path.relative_to(ROOT).as_posix(), "sha256": sha(path)})
    if failures:
        raise ValueError(f"historical identity audit could not read {len(failures)} records")
    graphs = {}
    for graph in ("dw", "enfr"):
        folder = DATA / graph
        records = tsv(folder / "alignments.tsv")
        test = [row["source_entity_id"] for row in records if row["split"] == "test"]
        available = sorted(set(test) - found, key=lambda x: (hashlib.sha256(f"{SALT}|{graph}|{x}".encode()).digest(), x))
        if len(available) < 288:
            raise ValueError(f"{graph}: insufficient certification-unseen IDs: {len(available)}")
        graphs[graph] = {"known_test_pool": len(test), "excluded_from_test": len(set(test) & found),
            "available_certification_unseen": len(available), "pilot": available[:32],
            "confirmation": available[32:288],
            "input_sha256": {p.name: sha(p) for p in sorted(folder.glob("*.tsv"))},
            "metadata_sha256": sha(folder / "confidence_metadata.json")}
    report = {"status": "FROZEN_BEFORE_NEW_QUERY_RESULTS", "graphs": graphs,
        "salt": SALT, "history_files": files, "history_parse_failures": failures,
        "scope": "new IDs relative to current certification experiments and old probe alignment universes; known sources previously used for model/data studies, not new-source blind data",
        "selection_uses": "source test membership and source ID hashes only; no target identity, scores, degree, scope or certification outcome",
        "probability_law": "configured independent Bernoulli edge retention q=0.9, on released full graph; not fact truth",
        "scorer_revision": "full-corpus sparse char2/3/4 TFIDF float64 + fixed lexical/degree kernel, attribute weight 0.8",
        "primary_tau": .25, "sensitivity_taus": list(TAUS), "looks": list(LOOKS),
        "primary_seed": 211, "confirmation_seeds": [211, 223, 227],
        "risk": "cheap total 1/20; paid nominal 1/40 + event 1/40; per query/method/run, no workload guarantee",
        "icdm_overlap": "author reports having compared formal ICDM article and found no coverage; accepted as author-provided comparison, not independently repeated here",
        "script_sha256_at_selection": sha(__file__), "frozen_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    save(BASE / "selection_protocol.json", report)
    print(json.dumps({g: {k: v for k, v in r.items() if k in ("known_test_pool", "excluded_from_test", "available_certification_unseen")} for g, r in graphs.items()}), flush=True)


def prepare(graph):
    from scipy import sparse
    from pkgea.backbones.attribute import _character_ngrams, normalize_attribute_value, AttributeStructuralBackbone
    from pkgea.backbones.toy import ToyStructuralBackbone
    from pkgea.query.index import CandidateBound, StaticCandidateIndex
    from run_vldb_interval_gate_v1 import audit_candidate_preservation
    from vldb_capture_attribute_v0 import DegreeScoreKernel
    from vldb_difference_envelope_v2 import compile_difference_kernel
    from pkgea.scope import build_incident_degree_certificate

    started = time.perf_counter()
    protocol = load(BASE / "selection_protocol.json")
    frozen = protocol["graphs"][graph]
    folder = DATA / graph
    for name, expected in frozen["input_sha256"].items():
        if sha(folder / name) != expected:
            raise ValueError("input changed after selection")
    out = BASE / "prepared" / graph
    out.mkdir(parents=True, exist_ok=False)
    entities = tsv(folder / "entities.tsv")
    triples = tsv(folder / "triples.tsv")
    source_ids = tuple(row["entity_id"] for row in entities if row["graph_id"] == "source")
    targets = tuple(sorted(row["entity_id"] for row in entities if row["graph_id"] == "target"))
    if len(source_ids) != 15000 or len(targets) != 15000:
        raise ValueError("expected 15K entities on each side")
    corpus = source_ids + targets
    positions = {entity: index for index, entity in enumerate(corpus)}
    labels = {row["entity_id"]: row["label"] for row in entities}
    values = defaultdict(list)
    for row in tsv(folder / "attributes.tsv"):
        value = normalize_attribute_value(row["value"])
        if value:
            values[row["entity_id"]].append(value)
    vocabulary, indptr, indices, data = {}, [0], [], []
    for entity in corpus:
        counter = _character_ngrams(values.pop(entity, []))
        for feature, count in sorted(counter.items()):
            index = vocabulary.setdefault(feature, len(vocabulary))
            indices.append(index)
            data.append(count)
        indptr.append(len(data))
    matrix = sparse.csr_matrix((np.asarray(data, dtype=np.float64), np.asarray(indices, dtype=np.int32),
                               np.asarray(indptr, dtype=np.int64)), shape=(len(corpus), len(vocabulary)))
    del indices, data, indptr, values, vocabulary
    matrix.sort_indices()
    frequency = np.asarray(matrix.getnnz(axis=0)).ravel()
    idf = np.log((len(corpus) + 1) / (frequency + 1)) + 1
    matrix = matrix.multiply(idf).tocsr()
    norms = np.sqrt(np.asarray(matrix.multiply(matrix).sum(axis=1)).ravel())
    matrix = sparse.diags(np.divide(1., norms, out=np.zeros_like(norms), where=norms != 0)) @ matrix
    target_matrix = matrix[len(source_ids):].T.tocsr()
    corpus_seconds = time.perf_counter() - started
    incidence = defaultdict(list)
    for edge, row in enumerate(triples):
        incidence[row["head_id"], 0].append(edge)
        incidence[row["tail_id"], 1].append(edge)
    records = []
    selected = frozen["pilot"] + frozen["confirmation"]
    for rank, source in enumerate(selected):
        before = time.perf_counter()
        attrs = np.asarray((matrix[positions[source]] @ target_matrix).toarray()).ravel()
        attrs = np.clip(attrs, 0., 1.)
        lexical = np.asarray([SequenceMatcher(None, labels[source].casefold(), labels[t].casefold()).ratio() for t in targets])
        attr_dict = {(source, t): float(a) for t, a in zip(targets, attrs)}
        lex_dict = {(source, t): float(a) for t, a in zip(targets, lexical)}
        backbone = AttributeStructuralBackbone(ToyStructuralBackbone(triples, (source,), targets, corpus, labels, lex_dict), attr_dict, .8)
        bounds = [CandidateBound(t, .8 * attr_dict[source, t] + .2 * .6 * lex_dict[source, t],
                                  .8 * attr_dict[source, t] + .2 * .6 * lex_dict[source, t] + .2 * .4) for t in targets]
        candidates = tuple(sorted(StaticCandidateIndex({source: bounds}).select(source, 1).candidates))
        preservation = audit_candidate_preservation(backbone, source, candidates)
        if preservation["status"] != "PASS":
            candidates = targets
            preservation = audit_candidate_preservation(backbone, source, candidates)
            if preservation["status"] != "PASS":
                raise AssertionError("full pool preservation failed")
        relevant = (source,) + candidates
        edges = tuple(sorted({edge for entity in relevant for d in (0, 1) for edge in incidence[entity, d]}))
        local = {edge: index for index, edge in enumerate(edges)}
        inc = tuple(np.asarray([local[e] for e in incidence[entity, d]], dtype=np.intp) for entity in relevant for d in (0, 1))
        attrs_kept = np.asarray([attr_dict[source, t] for t in candidates], dtype=np.float64)
        lex_kept = np.asarray([lex_dict[source, t] for t in candidates], dtype=np.float64)
        kernel = DegreeScoreKernel(source, candidates, edges, inc, attrs_kept, lex_kept, .8)
        compiled = compile_difference_kernel(kernel)
        # Independently form full directed degrees for a deterministic audit world.
        audit_rng = np.random.default_rng(int.from_bytes(hashlib.sha256(f"audit|{graph}|{source}".encode()).digest()[:8], "big"))
        state = audit_rng.random(len(triples)) < .9
        degrees = defaultdict(lambda: [0, 0])
        for active, triple in zip(state, triples):
            if active:
                degrees[triple["head_id"]][0] += 1
                degrees[triple["tail_id"]][1] += 1
        distance = np.asarray([abs(degrees[source][0]-degrees[t][0])+abs(degrees[source][1]-degrees[t][1]) for t in candidates], dtype=np.float64)
        full_scores = .8 * attrs_kept + (1. - .8) * (.6 * lex_kept + .4 * (1. / (1. + distance)))
        local_scores = compiled.scores(state[np.asarray(edges, dtype=np.intp)][None, :])[0]
        if not np.array_equal(full_scores, local_scores):
            raise AssertionError("full/local fixed score arithmetic differs")
        arrays = {"attribute": attrs_kept, "lexical": lex_kept, "edges": np.asarray(edges, dtype=np.int64)}
        arrays.update({f"inc_{i}": a for i, a in enumerate(inc)})
        path = out / f"q{rank:03d}.npz"
        with path.open("xb") as handle:
            np.savez_compressed(handle, **arrays)
        metadata = {"graph": graph, "rank": rank, "query_id": source, "candidates": list(candidates),
            "full_candidate_count": len(targets), "scope_edges": len(edges), "retained_candidates": len(candidates),
            "candidate_preservation": preservation, "full_local_audit": "PASS_ONE_COUPLED_WORLD",
            "scope_argument": "all incident edges of source and all retained candidates; static lexical and sparse TFIDF scores bound to corpus hashes",
            "kernel_sha256": sha(path), "preparation_seconds": time.perf_counter() - before,
            "partition": "pilot" if rank < 32 else "confirmation", "cost_model": compiled.compilation_summary}
        save(path.with_suffix(".json"), metadata)
        records.append({k: metadata[k] for k in ("rank", "query_id", "retained_candidates", "scope_edges", "preparation_seconds", "partition")})
        if (rank+1) % 32 == 0:
            print(f"{graph}: prepared {rank+1}/{len(selected)} (no certification outcomes)", flush=True)
    import psutil
    save(out / "summary.json", {"graph": graph, "records": records, "full_target_count": len(targets),
        "triples": len(triples), "corpus_construction_seconds": corpus_seconds,
        "full_construction_seconds": time.perf_counter()-started, "rss_bytes_at_finish": psutil.Process().memory_info().rss,
        "numerical_scorer_revision": protocol["scorer_revision"], "selection_protocol_sha256": sha(BASE / "selection_protocol.json"),
        "script_sha256": sha(__file__), "no_certification_outcomes_computed": True})


def read_query(graph, rank):
    from vldb_capture_attribute_v0 import DegreeScoreKernel
    from vldb_difference_envelope_v2 import compile_difference_kernel
    path = BASE / "prepared" / graph / f"q{rank:03d}.npz"
    metadata = load(path.with_suffix(".json"))
    if sha(path) != metadata["kernel_sha256"]:
        raise ValueError("prepared scorer changed")
    with np.load(path, allow_pickle=False) as arrays:
        k = len(metadata["candidates"])
        kernel = DegreeScoreKernel(metadata["query_id"], tuple(metadata["candidates"]), tuple(map(int, arrays["edges"])),
            tuple(arrays[f"inc_{i}"].copy() for i in range(2*(k+1))), arrays["attribute"].copy(), arrays["lexical"].copy(), .8)
    return compile_difference_kernel(kernel), metadata


def deterministic_gap(snapshot, divergences):
    import icde_strong_bounds_20261106 as strong
    best = -1.
    used = []
    for method in TRANSPORTS:
        bound = strong.transport_mode_intervals(snapshot["lower"], snapshot["upper"], snapshot["leader_index"], divergences, method=method)
        best = max(best, bound["lower_gap"])
        used.append(method)
        if best > 0:
            break
    return best, used


def execute_case(kernel, metadata, tau, seed, policy, deadline=None):
    import icde_strong_bounds_20261106 as strong
    import vldb_event_bound_v2 as event
    from run_vldb_interval_gate_v1 import clipped_box
    started = time.perf_counter()
    # Each policy pays its own numerical construction; no cache prepared by a
    # competing method is borrowed. Reuse within the case remains permitted.
    strong._mixture_interval_cached.cache_clear()
    strong.mixture_marginal.cache_clear()
    event._bound_details.cache_clear()
    times = defaultdict(float)
    k, m = len(kernel.candidates), len(kernel.edge_indices)
    q = np.full(m, .9, dtype=np.float64)
    low, high = clipped_box(q, tau)
    total_risk = Fraction(1, 20)
    event_policy = policy in ("eager", "lazy")
    nominal_risk = Fraction(1, 40) if event_policy else total_risk
    beta = Fraction(1, 40)
    alpha_event = event._float_down(beta / len(LOOKS))
    before = time.perf_counter()
    divergences = strong.product_divergence_bounds(q, low, high) if k > 1 else None
    times["divergence"] += time.perf_counter()-before
    rng_seed = int.from_bytes(hashlib.sha256(f"{SALT}|{metadata['graph']}|{metadata['query_id']}|{seed}".encode()).digest()[:16], "big")
    rng = np.random.default_rng(rng_seed)
    counts = np.zeros(k, dtype=np.int64)
    n = event_n = event_count = event_calls = 0
    blocks, trace = [], []
    prefix = hashlib.sha256()
    certified = k == 1
    nominal_certified = certified
    leader, cheap_gap, gap, event_upper = 0, 1. if certified else -1., 1. if certified else -1., 1.
    status = "structural_single_candidate" if certified else "world_cap"

    def expired():
        return deadline is not None and time.perf_counter()-started > deadline

    if policy == "direct" and not certified and not expired():
        before = time.perf_counter()
        global_lower, global_upper = kernel.score_intervals(np.zeros((1,m), dtype=np.bool_), np.ones((1,m), dtype=np.bool_))
        leader = int(np.argmax(global_lower[0]))
        competitors = global_upper[0].copy()
        competitors[leader] = -np.inf
        certified = bool(global_lower[0,leader] > np.max(competitors)) and not expired()
        nominal_certified = certified
        if certified:
            status = "direct_global_interval_certificate"
        times["direct_global_interval"] += time.perf_counter()-before

    if not certified:
        for target_n in LOOKS:
            if expired():
                status = "deadline_before_block"
                break
            before = time.perf_counter()
            u = rng.random((target_n-n, m), dtype=np.float64)
            states = u < q[None, :]
            times["rng"] += time.perf_counter()-before
            before = time.perf_counter()
            scores = kernel.scores(states)
            winners = np.argmax(scores, axis=1)
            counts += np.bincount(winners, minlength=k)
            prefix.update(winners.astype(np.int64).tobytes())
            blocks.append((n, u, scores))
            n = target_n
            times["scoring_hashing"] += time.perf_counter()-before
            before = time.perf_counter()
            snapshot = strong.categorical_probability_bounds(counts, n, nominal_risk, method="mixture_jeffreys")
            leader = snapshot["leader_index"]
            gap = snapshot["lower_gap"]
            nominal_certified |= snapshot["nominal_certified"]
            cheap_gap, transports = deterministic_gap(snapshot, divergences)
            times["probability_transport"] += time.perf_counter()-before
            requested = False
            upgrade_would_be_useful = None
            if cheap_gap <= 0 and event_policy and not expired():
                before = time.perf_counter()
                minimum_event_upper = event.fixed_n_binomial_upper(0, n, alpha_event)
                upgrade_would_be_useful = gap > 2 * minimum_event_upper
                requested = policy == "eager" or upgrade_would_be_useful
                times["policy"] += time.perf_counter()-before
                if requested:
                    before = time.perf_counter()
                    for start, past_u, past_scores in blocks:
                        if start >= event_n:
                            flags = kernel.ambiguity_indicators(q, low, high, past_u, nominal_scores=past_scores)
                            event_count += int(np.count_nonzero(flags))
                            event_calls += 1
                    event_n = n
                    times["event"] += time.perf_counter()-before
                    before = time.perf_counter()
                    event_upper = event.fixed_n_binomial_upper(event_count, event_n, alpha_event)
                    times["event_inference"] += time.perf_counter()-before
            paid_gap = math.nextafter(gap - math.nextafter(2 * event_upper, math.inf), -math.inf) if event_n else -1.
            could_certify = max(cheap_gap, paid_gap) > 0
            late = expired()
            trace.append({"n": n, "event_n": event_n, "event_count": event_count,
                "nominal_gap": gap, "deterministic_gap": cheap_gap, "paid_gap": paid_gap,
                "event_upper": event_upper, "transports_evaluated": transports,
                "event_requested": requested, "zero_count_gate": upgrade_would_be_useful,
                "elapsed_seconds": time.perf_counter()-started, "late_discard": bool(late and could_certify),
                "winner_prefix_sha256": prefix.hexdigest()})
            if late:
                status = "deadline_postblock"
                break
            if could_certify:
                certified, status = True, "certified"
                break
    elapsed = time.perf_counter()-started
    if deadline is not None and elapsed > deadline:
        certified = False
        status = "deadline_postblock"
    return {"graph": metadata["graph"], "rank": metadata["rank"], "query_id": metadata["query_id"],
        "partition": metadata["partition"], "tau": tau, "seed": seed, "policy": policy,
        "retained_candidates": k, "full_candidates": metadata["full_candidate_count"], "scope_edges": m,
        "certified": bool(certified), "candidate": kernel.candidates[leader] if certified else None,
        "status": status, "nominal_certified": bool(nominal_certified), "nominal_delta_exact": str(nominal_risk),
        "event_beta_exact": str(beta) if event_policy else "0", "worlds": n, "winner_counts": counts.tolist(),
        "event_worlds": event_n, "event_count": event_count, "event_calls": event_calls,
        "deterministic_gap": cheap_gap, "nominal_gap": gap, "event_upper": event_upper,
        "winner_prefix_sha256": prefix.hexdigest(), "rng_seed_hex": hex(rng_seed),
        "deadline_seconds": deadline, "compute_seconds": elapsed, "seconds": dict(times),
        "divergence_bounds": divergences, "trace": trace,
        "risk_scope": "separate per query/method/seed; deterministic portfolio shares same probability event; event checks union over six predefined looks",
        "no_fact_or_alignment_accuracy_claim": True}


def run(stage, graph, start, count, seeds, taus, deadline, tag):
    if os.environ.get("PYTHONHASHSEED") != "0":
        raise ValueError("PYTHONHASHSEED must be zero before process start")
    ranks = range(start, start+count)
    if stage == "pilot" and (start < 0 or start+count > 32):
        raise ValueError("pilot ranks must lie in [0,32)")
    if stage == "confirmation" and (start < 32 or start+count > 288):
        raise ValueError("confirmation ranks must lie in [32,288)")
    out = BASE / stage / tag
    out.mkdir(parents=True, exist_ok=False)
    save(out / "protocol_before_runs.json", {"stage": stage, "graph": graph, "ranks": list(ranks),
        "seeds": seeds, "taus": taus, "deadline_seconds": deadline, "policies": list(POLICIES),
        "selection_sha256": sha(BASE / "selection_protocol.json"), "script_sha256": sha(__file__),
        "construction": load(BASE / "prepared" / graph / "summary.json"),
        "cost_contract": "warm online compute plus per-case durable serialization; prepared static scorer construction and loading separately reported; not complete raw-input cold latency",
        "no_automatic_workload_guarantee": True})
    started = time.perf_counter()
    completed, rows = 0, []
    for rank in ranks:
        before = time.perf_counter()
        kernel, metadata = read_query(graph, rank)
        loading = time.perf_counter()-before
        for tau_index, tau in enumerate(taus):
            for seed_index, seed in enumerate(seeds):
                offset = (rank + tau_index + seed_index) % len(POLICIES)
                ordered = POLICIES[offset:] + POLICIES[:offset]
                for policy in ordered:
                    before = time.perf_counter()
                    row = execute_case(kernel, metadata, tau, seed, policy, deadline)
                    row["shared_static_query_load_seconds"] = loading
                    path = out / "cases" / f"q{rank:03d}_t{tau}_s{seed}_{policy}.json"
                    save(path, row)
                    response = time.perf_counter()-before
                    rows.append({k: row[k] for k in ("graph", "rank", "query_id", "partition", "tau", "seed", "policy", "retained_candidates", "scope_edges", "certified", "status", "worlds", "event_worlds", "compute_seconds")})
                    rows[-1].update({"response_seconds_including_persistence": response,
                        "delivered_within_budget": bool(row["certified"] and (deadline is None or response <= deadline)),
                        "case": path.relative_to(ROOT).as_posix(), "case_sha256": sha(path)})
                    completed += 1
        print(f"{stage} {graph}: rank {rank} done, {completed} cases", flush=True)
    save(out / "summary.json", {"status": "COMPLETE", "rows": rows, "elapsed_seconds": time.perf_counter()-started,
        "stage": stage, "graph": graph, "deadline_seconds": deadline, "complete_cases": completed})


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("audit")
    preparation = sub.add_parser("prepare")
    preparation.add_argument("--graph", choices=("dw", "enfr"), required=True)
    serving = sub.add_parser("run")
    serving.add_argument("--stage", choices=("pilot", "confirmation"), required=True)
    serving.add_argument("--graph", choices=("dw", "enfr"), required=True)
    serving.add_argument("--start", type=int, required=True)
    serving.add_argument("--count", type=int, required=True)
    serving.add_argument("--seeds", default="211")
    serving.add_argument("--taus", default="0.001,0.01,0.05,0.1,0.25,1.0")
    serving.add_argument("--deadline", type=float)
    serving.add_argument("--tag", required=True)
    args = parser.parse_args()
    if args.command == "audit":
        audit()
    elif args.command == "prepare":
        prepare(args.graph)
    else:
        run(args.stage, args.graph, args.start, args.count, list(map(int, args.seeds.split(","))),
            list(map(float, args.taus.split(","))), args.deadline, args.tag)


if __name__ == "__main__":
    main()
