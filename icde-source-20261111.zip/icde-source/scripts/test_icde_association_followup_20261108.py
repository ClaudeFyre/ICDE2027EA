import unittest
import numpy as np
from icde_association_followup_20261108 import corrected_metrics,population_controls
from icde_grouped_exact_20261108 import solve_counts


class FollowupTest(unittest.TestCase):
    def test_proper_scores_pair_original_observations(self):
        value=corrected_metrics([0,1],[.2,.8])
        self.assertAlmostEqual(value['brier'],.04)
        self.assertAlmostEqual(value['logloss'],-np.log(.8))
        other=corrected_metrics([1,0],[.8,.2])
        for key in ('brier','logloss','aurc','auroc'):
            self.assertAlmostEqual(value[key],other[key])

    def test_separation_is_not_against_all_exact_event_controls(self):
        compiled={'winners':np.asarray([0,1,0]),'shape':(3,),'count_states':3,
                  'groups':(((0,),(0,1),(.65,1.)),)}
        exact=solve_counts(compiled,2)
        result=population_controls(compiled,exact,2,.9)
        self.assertEqual(result['oracle_scalar_winners'],[0])
        self.assertEqual(result['separate_event_winners'],[0])


if __name__=='__main__':unittest.main()
