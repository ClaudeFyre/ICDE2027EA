"""G1 source-backed RREA, dynamic graph inputs and fixed-density retrieval.

The single dynamic-shape patch is audited against original author inputs/models
before use. Original v13 source and frozen results are never edited.
"""
from __future__ import annotations

import contextlib
import hashlib
import importlib
import io
import json
import math
import os
import random
import sys
import time
import types
from pathlib import Path

import numpy as np

from www_quality_recovery_v13_common import ROOT, VENDOR, graph, load, normalized, sha, verify_bundle

CONFIG = ROOT / "configs/g1_value_20261028.json"


def save(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def setup(seed: int):
    prefix = Path(sys.prefix)
    os.environ["PATH"] = str(prefix) + os.pathsep + str(prefix / "Library/bin") + os.pathsep + os.environ["PATH"]
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
    import tensorflow as tensorflow
    import keras
    if tensorflow.__version__ != "2.10.1" or keras.__version__ != "2.10.0":
        raise RuntimeError("G1 expects the validated existing RREA runtime")
    tf = tensorflow.compat.v1
    tf.disable_v2_behavior()
    tf.reset_default_graph()
    random.seed(seed)
    np.random.seed(seed)
    tf.set_random_seed(seed)
    config = tf.ConfigProto(intra_op_parallelism_threads=2, inter_op_parallelism_threads=2)
    config.gpu_options.allow_growth = True
    config.gpu_options.per_process_gpu_memory_fraction = .85
    session = tf.Session(config=config)
    keras.backend.set_session(session)
    if not tensorflow.config.list_physical_devices("GPU"):
        raise RuntimeError("current G1 full graph protocol requires the verified GPU")
    sys.path.insert(0, str(VENDOR))
    original = importlib.import_module("official_model_extracted")
    utils = importlib.import_module("utils")
    layer_source = (VENDOR / "layer.py").read_text(encoding="utf-8")
    old = "dense_shape=(self.triple_size,self.rel_size)"
    new = "dense_shape=(tf.shape(adj.indices)[0],self.rel_size)"
    if layer_source.count(old) != 1:
        raise ValueError("dynamic-shape patch no longer matches frozen author layer")
    dynamic_layer = types.ModuleType("g1_dynamic_relation_layer")
    exec(compile(layer_source.replace(old, new), "g1_dynamic_relation_layer", "exec"), dynamic_layer.__dict__)
    dynamic = types.ModuleType("g1_dynamic_author_model")
    exec(compile((VENDOR / "official_model_extracted.py").read_text(encoding="utf-8"),
                 "g1_dynamic_author_model", "exec"), dynamic.__dict__)
    dynamic.NR_GraphAttention = dynamic_layer.NR_GraphAttention
    class RepeatableReductions:
        def __getattr__(self, name):
            operation = getattr(tf, name)
            if name in ("sparse_tensor_dense_matmul", "segment_sum"):
                def placed(*args, **kwargs):
                    with tf.device("/CPU:0"):
                        return operation(*args, **kwargs)
                return placed
            return operation
    # CUDA sparse reductions differed at ~1e-7 and changed a 1e-9 tie in G0.
    # Explicit placement keeps author equations, avoids changing tie semantics,
    # and is revalidated against author forward results before any G1 cell.
    dynamic_layer.tf = RepeatableReductions()
    dynamic.tf = RepeatableReductions()
    return tf, keras, session, original, dynamic, utils


class GraphInputs:
    def __init__(self, g):
        self.g = g
        self.n = len(g["entity_ids"])
        self.r = len(g["relations"]) + 1
        tr = g["triples"]
        h, r, t = tr.T
        key = np.stack((h * self.n + t, t * self.n + h), axis=1).ravel()
        rel = np.stack((r, r + self.r), axis=1).ravel()
        edge = np.repeat(np.arange(len(tr)), 2)
        order = np.argsort(key, kind="stable")
        self.keys, self.rels, self.edge = key[order], rel[order], edge[order]
        rkey = np.stack((t * (2 * self.r) + r, h * (2 * self.r) + r + self.r), axis=1).ravel()
        order = np.argsort(rkey, kind="stable")
        self.rkeys, self.redge = rkey[order], edge[order]
        first = np.full(self.n, len(tr), dtype=np.int64)
        np.minimum.at(first, h, np.arange(len(tr)))
        np.minimum.at(first, t, np.arange(len(tr)))
        if np.any(first == len(tr)):
            raise ValueError("original graph has isolated entity")
        self.pinned = np.zeros(len(tr), dtype=bool)
        self.pinned[first] = True

    def build(self, mask=None):
        if mask is None:
            mask = np.ones(len(self.g["triples"]), dtype=bool)
        selected = mask[self.edge]
        keys, rels = self.keys[selected], self.rels[selected]
        start = np.r_[True, keys[1:] != keys[:-1]]
        row = np.cumsum(start) - 1
        unique = keys[start]
        counts = np.bincount(row)
        adj = np.c_[unique // self.n, unique % self.n].astype(np.int64)
        ri = np.c_[row, rels].astype(np.int64)
        rv = (1. / counts[row]).astype(np.float32)
        ekeys = np.unique(np.r_[unique, np.arange(self.n) * (self.n + 1)])
        ea = np.c_[ekeys // self.n, ekeys % self.n].astype(np.int64)
        rk = self.rkeys[mask[self.redge]]
        rk = rk[np.r_[True, rk[1:] != rk[:-1]]]
        ra = np.c_[rk // (2 * self.r), rk % (2 * self.r)].astype(np.int64)
        if len(np.unique(adj[:, 0])) != self.n:
            raise ValueError("sampled graph violates pinned-edge no-isolation contract")
        return [adj, ri, rv, ra, ea]

    def mask(self, rng):
        return self.pinned | (rng.random(len(self.pinned)) < .9)


def feed(matrices):
    return [x[None] for x in matrices]


def build_model(g, matrices, module):
    c = load(ROOT / "papers/www/quality_recovery_v13_config.json")["model"]
    module.batch_size = len(g["entity_ids"])
    return module.get_trgat(node_size=len(g["entity_ids"]), rel_size=2 * (len(g["relations"]) + 1),
                            node_hidden=c["node_hidden"], rel_hidden=c["rel_hidden"],
                            triple_size=len(matrices[0]), n_attn_heads=c["attention_heads"],
                            dropout_rate=c["dropout"], gamma=c["margin"],
                            lr=c["learning_rate"], depth=c["depth"])


def embed(model, matrices):
    value = np.asarray(model.predict_on_batch(feed(matrices)))
    if value.shape[1] != 600 or not np.isfinite(value).all():
        raise ValueError("invalid full-dimensional RREA output")
    return value


def weights(path):
    with np.load(path, allow_pickle=False) as value:
        return [value["w" + str(i)] for i in range(len(value.files))]


class Retrieval:
    def __init__(self, tf, session):
        self.session = session
        with tf.device("/GPU:0"):
            self.q = tf.placeholder(tf.float64, [None, 600])
            self.t = tf.placeholder(tf.float64, [None, 600])
            self.dot = tf.matmul(self.q, self.t, transpose_b=True)

    def cosine(self, q, t):
        return self.session.run(self.dot, {self.q: q, self.t: t})

    def density(self, v, g):
        started = time.perf_counter()
        top = np.full((10, len(g["targets"])), -np.inf)
        target = v[g["targets"]]
        for i in range(0, len(g["sources"]), 256):
            scores = self.cosine(v[g["sources"][i:i + 256]], target)
            local = np.partition(scores, -10, axis=0)[-10:]
            top = np.partition(np.r_[top, local], -10, axis=0)[-10:]
        return top.mean(axis=0), time.perf_counter() - started

    def scores(self, v, sources, targets, correction):
        return 2 * self.cosine(v[sources], v[targets]) - correction[None]


def stats(scores):
    winner = np.argmax(scores, axis=1)
    top = np.partition(scores, -2, axis=1)[:, -2:]
    margin = top.max(1) - top.min(1)
    scaled = (scores - scores.max(1, keepdims=True)) / .1
    p = np.exp(scaled)
    p /= p.sum(1, keepdims=True)
    entropy = -np.sum(p * np.log(np.maximum(p, np.finfo(float).tiny)), axis=1)
    return winner, margin, -entropy


def subset(g, key, split, count):
    pairs = list(g["pairs"][split])
    pairs.sort(key=lambda p: hashlib.sha256(f"G1-20261028|{key}|{split}|{g['entity_ids'][p[0]]}".encode()).hexdigest())
    return np.asarray(pairs[:count], dtype=np.int64)


def radius(n, count=15000):
    alpha = .05 / (count * (count - 1) / 2)
    return math.sqrt((n + 64) * math.log((n + 64) / (64 * alpha * alpha))) / n


def selective_risk(predicted, confidence, truth, coverage, allowed=None):
    n = math.ceil(len(truth) * coverage)
    eligible = np.arange(len(truth)) if allowed is None else np.flatnonzero(allowed)
    if len(eligible) < n:
        return {"attainable": False, "eligible": len(eligible), "required": n}
    order = eligible[np.argsort(-confidence[eligible], kind="stable")[:n]]
    return {"attainable": True, "selected": n, "errors": int(np.sum(predicted[order] != truth[order])),
            "risk": float(np.mean(predicted[order] != truth[order])), "indices": order.tolist()}
