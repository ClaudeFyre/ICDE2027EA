"""Independent identity, count, source-fold and corrected-score audit."""
from collections import Counter,defaultdict
from fractions import Fraction as Q
import math
from pathlib import Path
import numpy as np
from icde_grouped_inventory_20261108 import ROOT,load,save,sha,identities
from icde_association_study_20261108 import BASE as INITIAL
from icde_association_followup_20261108 import BASE as FOLLOWUP


def main():
    checks=0
    for out in (INITIAL,FOLLOWUP):
        p,s=load(out/'protocol.json'),load(out/'summary.json')
        checks+=identities(p,False)
        assert s['protocol_sha256']==sha(out/'protocol.json')
        for name,digest in s['outputs_sha256'].items():assert sha(out/name)==digest
        checks+=1+len(s['outputs_sha256'])
    q=load(INITIAL/'quantifier_census.json');d=load(INITIAL/'static_diagnosis.json')
    c=load(FOLLOWUP/'strong_population_controls.json');a=load(FOLLOWUP/'alignment_signal_corrected.json')
    assert len(q['rows'])==148 and len(d['rows'])==576
    assert len({(r['graph'],r['rank']) for r in q['rows']})==148
    assert Counter(r['diagnostic_category'] for r in d['rows'])==d['categories']
    assert sum(d['categories'].values())==576
    checks+=4
    indexed={(r['graph'],r['rank']):r for r in c['rows']}
    for r in q['rows']:
        k=r['retained_candidates'];safe=r['uniform_winners']
        assert r['quantifier_omission']==(bool(safe) and not r['pointwise_certifiable_winners'])
        for w in range(k):
            lower=min(Q(p['gap_exact']) for p in r['pairs'] if p['candidate']==w)
            assert str(lower)==r['minimum_gaps_exact'][w]
            assert lower<=Q(r['true_minimum_gaps_exact'][w])
            checks+=2
        assert load(INITIAL/'mechanisms'/f"{r['graph']}_q{r['rank']:03d}.json")==r
        controls=indexed[r['graph'],r['rank']]
        lo=list(map(Q,controls['candidate_probability_minima_exact']))
        hi=list(map(Q,controls['candidate_probability_maxima_exact']))
        nominal=list(map(Q,controls['nominal_probabilities_exact']))
        eps=max(max(abs(x-y),abs(x-z)) for x,y,z in zip(nominal,lo,hi))
        for w in range(k):
            separate=min(lo[w]-hi[t] for t in range(k) if t!=w)
            scalar=min(nominal[w]-nominal[t] for t in range(k) if t!=w)-2*eps
            assert str(separate)==controls['separate_event_gaps_exact'][w]
            assert str(scalar)==controls['oracle_scalar_gaps_exact'][w]
            if separate>0:assert w in safe
            checks+=3
        checks+=2
    assert sum(r['quantifier_omission'] for r in q['rows'])==10
    assert sum(bool(r['uniform_winners']) for r in q['rows'])==101
    assert c['summary']['separate_event_certifiable']==101
    assert c['summary']['oracle_scalar_certifiable']==99
    checks+=4
    rows=a['oof_rows'];clusters=defaultdict(list);seen=set()
    truth={graph:{r['source_entity_id']:r['target_entity_id'] for r in load_tsv(graph)} for graph in ('dw','enfr')}
    for r in rows:
        key=r['graph'],r['rank'],r['seed']
        assert key not in seen;seen.add(key)
        assert r['correct']==(r['prediction']==truth[r['graph']][r['query_id']])
        clusters[r['graph'],r['rank']].append(r)
        checks+=2
    assert len(clusters)==512 and len(rows)==1536
    for values in clusters.values():
        assert len(values)==3 and len({r['fold'] for r in values})==1
        assert {r['seed'] for r in values}=={211,223,227}
        checks+=2
    for name,predicate in [('all',lambda r:True),('competitive',lambda r:r['retained_candidates']>1),
                           ('dw',lambda r:r['graph']=='dw'),('enfr',lambda r:r['graph']=='enfr')]:
        selected=[r for r in rows if predicate(r)]
        y=np.asarray([r['correct'] for r in selected],dtype=float)
        for model,field in [('baseline','baseline_probability'),('baseline_plus_stability','extended_probability')]:
            prob=np.asarray([r[field] for r in selected]);clipped=np.clip(prob,1e-12,1-1e-12)
            brier=float(np.mean(np.square(prob-y)))
            loss=float(-np.mean(y*np.log(clipped)+(1-y)*np.log(1-clipped)))
            assert math.isclose(brier,a['subgroups'][name][model]['brier'],abs_tol=1e-12)
            assert math.isclose(loss,a['subgroups'][name][model]['logloss'],abs_tol=1e-12)
            checks+=2
    save(FOLLOWUP.parent/'validation.json',{'status':'PASS','checks':checks,
        'queries_exact':148,'queries_static':576,'source_queries_signal':512,'query_seed_cases_signal':1536,
        'inputs_unchanged':True,'source_folds_keep_all_seeds_together':True,
        'corrected_proper_scores_independently_recomputed':True,
        'summary_sha256':{out.name:sha(out/'summary.json') for out in (INITIAL,FOLLOWUP)},
        'validator_sha256':sha(Path(__file__)),
        'limitations':'shared numerical exact oracle; descriptive source bootstrap does not guarantee graph-independent inference'})
    print(f'Independent audit PASS {checks} checks',flush=True)


def load_tsv(graph):
    import icde_prospective_20261107 as old
    return old.tsv(old.DATA/graph/'alignments.tsv')


if __name__=='__main__':main()
