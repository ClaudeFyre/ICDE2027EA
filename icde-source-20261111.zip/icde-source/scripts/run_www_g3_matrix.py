"""Run the WWW third-graph (G3) cells: main sweep plus both margin stages.

The frozen eight-cell matrix and its two margin stages are untouched.  G3 adds
one real cross-KG pair under an identical estimator contract -- same budgets,
ranks, selection/test/reference seeds, query and candidate limits -- and writes
to its own results namespace and its own task manifest, so appending it cannot
perturb or invalidate any frozen artifact.

Stages:
  main     budget sweep 64/128/256/512/2048 on the two representative cells,
           gate-only at 2048 on the rest, test seeds 59/71
  margin-a margin-aware selection, test seeds 59/71
  margin-b margin-aware selection, test seeds 83/97/103

Typical use on the compute host:

    python scripts/run_www_g3_matrix.py --stage main --preflight-only
    python scripts/run_www_g3_matrix.py --stage main
    python scripts/run_www_g3_matrix.py --stage margin-a
    python scripts/run_www_g3_matrix.py --stage margin-b
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from pkgea.contracts import dataset_content_digest


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "nodes/04_www_distributional/results/g3_eventea"
RUNTIME = ROOT / ".runtime"
DATASET_CONFIG = ROOT / "nodes/04_www_distributional/configs/g3_scale500_datasets.json"
SPECIFICATION = "papers/www/G3_THIRD_GRAPH_SPEC.md"
DEFAULT_PYTHON = Path(r"D:\miniconda\envs\baokai\python.exe")

GRAPH = "eventea"
CELLS = (
    ("eventea", "gcn", "independent"),
    ("eventea", "gcn", "structural"),
    ("eventea", "relation", "independent"),
    ("eventea", "relation", "structural"),
)
# The two cells that carry the budget sweep; the rest run gate-only at 2048.
SWEEP_CELLS = {("eventea", "gcn", "structural"), ("eventea", "relation", "independent")}
BUDGET_SWEEP = (64, 128, 256, 512, 2048)
GATE_ONLY = (2048,)
STAGE_SEEDS = {"main": (59, 71), "margin-a": (59, 71), "margin-b": (83, 97, 103)}


def digest(path: Path) -> str | None:
    """SHA-256 of a checkpoint, or None when the weights are not present.

    Model weights are untracked by design, so a clean clone can still build and
    inspect the plan.  ``preflight`` refuses to run without real weights.
    """

    if not path.is_file():
        return None
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temporary, path)
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def dataset_profile() -> dict[str, object]:
    if not DATASET_CONFIG.is_file():
        raise FileNotFoundError(
            f"{DATASET_CONFIG.relative_to(ROOT)} is missing; run "
            "scripts/prepare_www_g3_scale500.py first"
        )
    payload = json.loads(DATASET_CONFIG.read_text(encoding="utf-8"))
    return payload["profiles"][0]


def content_digest_mismatches() -> dict[str, dict[str, str]]:
    """Compare the datasets on this host against the frozen config.

    Uses the portable content digest.  The local revision digest hashes raw
    bytes, so it differs between hosts even when the data is identical and
    cannot be used for this check.
    """

    profile = dataset_profile()
    expected = profile["dataset_content_digests"]
    mismatched = {}
    for key in ("probe", "independent", "shared"):
        built = dataset_content_digest(ROOT / str(profile[key]))
        if built != expected[key]:
            mismatched[key] = {"expected": expected[key], "built": built}
    return mismatched


def checkpoint(family: str) -> Path:
    stem = "relation_align" if family == "relation" else "gcn_align"
    return ROOT / (
        f"nodes/04_www_distributional/checkpoints/scale500/"
        f"{stem}_{GRAPH}_scale500_s17.pt"
    )


def profile_path(dependence: str) -> Path:
    profile = dataset_profile()
    key = "independent" if dependence == "independent" else "shared"
    return ROOT / str(profile[key])


def stage_directory(stage: str) -> Path:
    if stage == "main":
        return RESULTS / "main_matrix"
    return RESULTS / "margin_selection" / f"stage_{stage[-1]}"


def task(stage: str, python: Path, cell: tuple[str, str, str]) -> dict[str, object]:
    graph, family, dependence = cell
    seeds = STAGE_SEEDS[stage]
    sweep = stage == "main" and cell in SWEEP_CELLS
    budgets = BUDGET_SWEEP if sweep else GATE_ONLY
    slug = f"{graph}_{family}_{dependence}"
    # Mirror the frozen matrix's file layout inside the G3 namespace so the
    # existing summarizers read both with only a results-root override.
    prefix = "www_main" if stage == "main" else "www_margin"
    output = stage_directory(stage) / f"{prefix}_{slug}_v1.json"
    markdown = output.with_suffix(".md")
    task_id = f"www-g3-{stage}-{graph}-{family}-{dependence}"
    checkpoint_file = checkpoint(family)
    dataset = profile_path(dependence)

    command = [
        str(python), "scripts/run_www_equal_budget.py",
        str(output.relative_to(ROOT)),
        "--markdown-output", str(markdown.relative_to(ROOT)),
        "--checkpoint", str(checkpoint_file.relative_to(ROOT)),
        "--profile", f"{dependence}={dataset.relative_to(ROOT)}",
        "--gate-budget", "2048",
        "--budgets", *map(str, budgets),
        "--reference-samples", "4096",
        "--selection-seed", "17",
        "--test-seeds", *map(str, seeds),
        "--reference-seed", "1017",
        "--candidate-ranks", "1", "2", "4", "8",
        "--query-limit", "500",
        "--candidate-limit", "1012",
        "--cell-label", f"g3-{stage}/{graph}/{family}/{dependence}",
        "--resume",
        "--heartbeat-seconds", "60",
    ]
    if stage != "main":
        command.insert(-3, "--margin-aware-experiment")

    safe_command = [
        str(python), "scripts/safe_run.py",
        "--task-id", task_id,
        "--profile", "cpu64",
        "--max-runtime-minutes", "180",
        "--expected-output", str(output.relative_to(ROOT)),
        "--", *command,
    ]
    return {
        "task_id": task_id,
        "stage": stage,
        "cell": [graph, family, dependence],
        "representative_budget_sweep": sweep,
        "budgets": list(budgets),
        "selection_seed": 17,
        "test_seeds": list(seeds),
        "reference_seed": 1017,
        "checkpoint": str(checkpoint_file),
        "checkpoint_sha256": digest(checkpoint_file),
        "profile": str(dataset),
        "output": str(output),
        "markdown": str(markdown),
        "command": command,
        "safe_command": safe_command,
    }


def preflight(tasks: list[dict[str, object]], python: Path) -> dict[str, object]:
    if (RUNTIME / "safe-run.lock").exists():
        raise RuntimeError("single-task lock already exists")
    if not python.is_file():
        raise FileNotFoundError(python)
    missing_checkpoints = [
        str(item["checkpoint"])
        for item in tasks
        if not Path(str(item["checkpoint"])).is_file()
    ]
    if missing_checkpoints:
        raise FileNotFoundError(
            "train the G3 checkpoints first: " + ", ".join(sorted(set(missing_checkpoints)))
        )
    for item in tasks:
        if not Path(str(item["profile"])).is_dir():
            raise FileNotFoundError(item["profile"])
    mismatched = content_digest_mismatches()
    if mismatched:
        raise RuntimeError(
            "dataset content digests differ from the frozen config; the two "
            f"hosts are not running the same experiment: {mismatched}"
        )
    free = shutil.disk_usage(ROOT).free
    if free < 100 * 1024**3:
        raise RuntimeError("less than 100 GiB free disk")
    return {
        "status": "pass",
        "task_count": len(tasks),
        "test_seeds_explicit": sorted({s for item in tasks for s in item["test_seeds"]}),
        "dataset_content_digests_match": True,
        "free_disk_gib": free / 1024**3,
        "single_task_lock_absent": True,
    }


def run_and_echo(item: dict[str, object]) -> int:
    log = RUNTIME / "logs" / f"{item['task_id']}.log"
    print(
        f"\n=== START {item['task_id']} budgets={item['budgets']} "
        f"test_seeds={item['test_seeds']} ===",
        flush=True,
    )
    process = subprocess.Popen(item["safe_command"], cwd=ROOT)
    position = 0
    while process.poll() is None:
        if log.exists():
            with log.open("r", encoding="utf-8", errors="replace") as handle:
                handle.seek(position)
                chunk = handle.read()
                position = handle.tell()
            if chunk:
                print(chunk, end="", flush=True)
        time.sleep(2)
    if log.exists():
        with log.open("r", encoding="utf-8", errors="replace") as handle:
            handle.seek(position)
            print(handle.read(), end="", flush=True)
    print(f"=== END {item['task_id']} exit={process.returncode} ===", flush=True)
    return int(process.returncode or 0)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=tuple(STAGE_SEEDS), required=True)
    parser.add_argument("--python", type=Path, default=DEFAULT_PYTHON)
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="print the frozen plan without preflight or execution",
    )
    args = parser.parse_args()

    tasks = [task(args.stage, args.python, cell) for cell in CELLS]
    profile = dataset_profile()
    if args.dry_run:
        print(json.dumps({"stage": args.stage, "dataset": profile, "tasks": tasks}, indent=2))
        return 0

    frozen = {
        "schema_version": "pkgea-www-g3-third-graph-v1",
        "specification": SPECIFICATION,
        "stage": args.stage,
        "dataset_content_digests": profile["dataset_content_digests"],
        "preflight": preflight(tasks, args.python),
        "tasks": tasks,
    }
    manifest = stage_directory(args.stage) / "task_manifest_v1.json"
    comparable = ("schema_version", "specification", "stage", "dataset_content_digests", "tasks")
    if manifest.exists():
        existing = json.loads(manifest.read_text(encoding="utf-8"))
        if {k: existing.get(k) for k in comparable} != {k: frozen[k] for k in comparable}:
            raise RuntimeError("existing task manifest differs from frozen plan")
    else:
        atomic_json(manifest, frozen)

    print(json.dumps(frozen["preflight"], indent=2), flush=True)
    if args.preflight_only:
        return 0
    for item in tasks:
        code = run_and_echo(item)
        if code:
            return code
    print(f"WWW G3 STAGE {args.stage.upper()} COMPLETE", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
