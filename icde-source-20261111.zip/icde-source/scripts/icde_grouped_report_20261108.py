"""Read-only audit and research report for the grouped-query feasibility gate."""
from collections import Counter
from fractions import Fraction as Q
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_grouped_query_20261108"


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, obj):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def report(base):
    inv = load(base / "inventory_attempt1/inventory.json")
    proto = load(base / "prototype_attempt1/summary.json")
    timing = load(base / "timing_attempt1/summary.json")
    checked = 0
    def require(ok, message):
        nonlocal checked
        if not ok:
            raise AssertionError(message)
        checked += 1
    for folder in ("inventory_attempt1", "prototype_attempt1", "timing_attempt1"):
        protocol = load(base / folder / "protocol.json")
        for group in ("code_sha256", "input_sha256"):
            for name, digest in protocol[group].items():
                require(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest,
                        "frozen numerical source/input changed")
    require(len(inv["rows"]) == 576, "incomplete historical inventory")
    require(len({(r["graph"], r["rank"]) for r in inv["rows"]}) == 576, "duplicated inventory query")
    for row in inv["rows"]:
        if row["inventory_status"] == "grouped":
            require(sum(row["group_sizes"]) == row["scope_edges"], "edge grouping loses scope")
            require(math.prod(n+1 for n in row["group_sizes"]) == row["count_states"], "count state product mismatch")
    p = load(base / "prototype_attempt1/protocol.json")
    expected = {(r["graph"], r["rank"]) for r in p["cases"]}
    require({(r["graph"], r["rank"]) for r in proto["cases"]} == expected and len(proto["cases"]) == len(expected), "prototype selection changed")
    exact_lookup = {}
    for row in proto["cases"]:
        reconstructed = [w for w in range(row["candidates"])
                         if all(Q(pair["minimum_gap_exact"]) > 0 for pair in row["pairs"] if pair["candidate"] == w)]
        require(reconstructed == row["uniform_winners"], "invalid exact approval")
        require(len(row["timings"]) == p["exact_repeats"], "missing exact repeats")
        require(all(t["total_seconds"] >= t["compile_seconds"] for t in row["timings"]), "missing compiler cost")
        exact_lookup[row["graph"], row["rank"]] = row
    require(len(proto["generic_mc"]) == len(expected)*len(p["mc_seeds"]), "missing generic controls")
    for row in proto["generic_mc"]:
        exact = exact_lookup[row["graph"], row["rank"]]
        require(not row["certified"] or row["candidate"] in exact["uniform_winners"], "unsafe generic output")
        require(Q(row["nominal_delta_exact"])+Q(row["event_beta_exact"]) <= Q(1,20), "generic risk exceeds declared total")
    large = [r for r in proto["cases"] if r["role"] == "static_large_scope"]
    tiny = [r for r in proto["cases"] if r["role"] == "exact_small_scope_audit"]
    require(len(large) == 8 and len(tiny) == 20, "unexpected prototype scope")
    require(len(timing["rows"]) == 10*3*2, "incomplete warm timing followup")
    cost_rows = []
    for row in large + [r for r in tiny if r["graph"] == "dw" and r["rank"] in (113,244)]:
        timed = {r["method"]: r for r in timing["aggregates"] if r["graph"] == row["graph"] and r["rank"] == row["rank"]}
        require(set(timed) == {"count_exact", "generic_eager"}, "missing timing method")
        singleton_world = bool(row["uniform_winners"]) and all(Q(pair["minimum_gap_exact"]) == 1
            for pair in row["pairs"] if pair["candidate"] == row["uniform_winners"][0])
        cost_rows.append({"graph": row["graph"], "rank": row["rank"], "scope_edges": row["scope_edges"],
            "count_states": row["count_states"], "exact_winners": row["uniform_winners"],
            "exact_ms": 1000*timed["count_exact"]["median_seconds"],
            "mc_ms": 1000*timed["generic_eager"]["median_seconds"],
            "mc_certified_repeats": timed["generic_eager"]["certified_runs"],
            "mc_repeats": timed["generic_eager"]["repeats"],
            "global_winner_constant_provable_from_same_counts": singleton_world})
    # Preserve the negative large-query witness as a concrete, reviewable pair
    # of endpoint choices. Binary probabilities follow exactly from the gap.
    witness_query = exact_lookup["enfr",98]
    require(witness_query["candidates"] == 2 and not witness_query["uniform_winners"], "expected binary nonuniform witness missing")
    witnesses = []
    for pair in witness_query["pairs"]:
        gap = Q(pair["minimum_gap_exact"])
        require(gap < 0, "witness is not a strict winner reversal")
        pw = (1+gap)/2
        probabilities = [None, None]
        probabilities[pair["candidate"]] = str(pw)
        probabilities[pair["competitor"]] = str(1-pw)
        witnesses.append({"tested_candidate": pair["candidate"], "winner": pair["competitor"],
            "high_endpoint_counts_by_group": pair["minimizing_high_endpoint_counts"],
            "candidate_probabilities_exact": probabilities,
            "gap_exact": pair["minimum_gap_exact"]})
    metrics = {"status": "PASS", "checks": checked,
        "inventory": {k: inv[k] for k in ("queries", "status_counts", "eligible_queries", "eligible_large_queries")},
        "large_exact_stable_queries": sum(bool(r["uniform_winners"]) for r in large),
        "large_exact_nonuniform_queries": sum(not r["uniform_winners"] for r in large),
        "all_exact_stable_queries": sum(bool(r["uniform_winners"]) for r in proto["cases"]),
        "mc_certified_runs": sum(r["certified"] for r in proto["generic_mc"]),
        "mc_runs": len(proto["generic_mc"]), "cost_rows": cost_rows,
        "large_nonuniform_witness": {"graph":"enfr", "rank":98, "scope_edges":27,
            "group_sizes": witness_query["group_sizes"], "witnesses":witnesses},
        "gate": {"static_structure": "PASS_FOR_A_RESTRICTED_SUBSET", "exact_implementation": "PASS_ON_AUDITED_CASES",
            "universal_latency_advantage": "NOT_ESTABLISHED", "independent_algorithmic_novelty": "NOT_ESTABLISHED",
            "new_confirmation_expansion": "DEFER_UNTIL_TECHNICAL_INCREMENT_IS_ESTABLISHED"},
        "warning": "counting/tensor solver is an optimized standard baseline; benefits over scalar MC do not establish novelty over lifted/credal inference"}
    save(base / "analysis.json", metrics)
    save(base / "validation.json", {"status": "PASS", "checks": checked,
        "inventory_sha256": hashlib.sha256((base / "inventory_attempt1/inventory.json").read_bytes()).hexdigest(),
        "prototype_sha256": hashlib.sha256((base / "prototype_attempt1/summary.json").read_bytes()).hexdigest(),
        "timing_sha256": hashlib.sha256((base / "timing_attempt1/summary.json").read_bytes()).hexdigest(),
        "note": "finite identity/accounting/reference audit; not a general zero-error or novelty proof"})
    lines = ["# 查询分组与精确计数：可行性门槛结果", "", "日期：2026-11-08。全部输入是已有历史资产；本轮没有新的前瞻确认集。", "",
        '[说明文本已清理]', "",
        '[说明文本已清理]', "",
        "## 静态结构盘点", "",
        "覆盖576个已有准备查询：169个单候选、346个进入精确签名盘点、61个超过预声明静态上限。单候选不作为modal竞争收益。签名盘点限制K≤256、m≤10000，未对被跳过部分推断压缩率。", "",
        "原型进一步限制K≤8、m≤96、计数状态≤32768、预计K倍张量操作≤200万。148个查询满足原型结构预算，其中38个scope至少20。按预声明规则，每图取scope最大的4个可行查询，并加入全部20个既有小scope精确查询，共28个不同开发query。", "",
        "例如D–W q233有42条scope边，逐边状态数2^42=4398046511104；6组大小为33/2/3/1/2/1，计数状态仅4896。表示压缩不等于相同倍数的加速；必须支付计数状态评分、精确权重与张量收缩。", "",
        "本次概率机制为独立边保留q=.9、τ=.25，组内端点相同。唯一异质端点的静态压力情形会退回单边组，这不是已测真实概率数据，只说明不能假设分组永远有效。", "",
        "## 精确原型与对照", "",
        "直接从incidence构造计数赢家张量，没有先枚举Boolean世界。每组通过Bin(t,h)+Bin(n−t,l)计算端点代表的计数分布，普通逐轴张量收缩得到全部参数代表下的候选概率。所有概率计算使用有理数共同分母的整数运算。", "",
        "20个小scope与独立全世界/全参数顶点及原冻结参考核对了全部成对最小gap；相同分组上的逐代表sum-product又核对全部小scope代表。8个较大scope核对预声明评分探针和精确极值代表，未构建其完整Boolean表。5项新单元测试覆盖共享边、端点异质性、极端概率、计数赢家与原评分一致性及资源截断。", "",
        "精确计算在28个query中证明22个全族稳定；优化generic eager在两种子共56次运行中认证40次。新增的稳定query仍是先前已定位的q113/q244；不能说较大scope子组出现了新增稳定覆盖。", "",
        "## 复核后的实际计算时间", "",
        "下表为包含共同直接区间前端、各方法自身编译/统计计算的3次预热观测中位数。准备对象加载、原始语料构造及持久化另计，不是冷启动总服务时间。精确法的‘非稳定’是完成判定，采样的‘未决’不是同一输出。", "",
        "| 查询 | scope边 | 计数状态 | 计数精确法/ms | 精确输出 | generic eager/ms | generic输出 |",
        "| --- | ---: | ---: | ---: | --- | ---: | --- |"]
    for row in cost_rows:
        exact_label = "稳定" if row["exact_winners"] else "非稳定，有反例"
        mc_label = "稳定，3/3" if row["mc_certified_repeats"] == 3 else "未决，3/3"
        lines.append(f"| {row['graph']} q{row['rank']} | {row['scope_edges']} | {row['count_states']} | {row['exact_ms']:.3f} | {exact_label} | {row['mc_ms']:.3f} | {mc_label} |")
    lines += ["", "多数较大查询，generic只用32或64个世界就能认证，而完整计数精确求值付出了额外工作。q181两者的微小差别不作显著优势解读。q36、q267还能由相同计数结构证明全世界winner恒定；适用方法均可在编译后直接停止，不应把这部分归为概率认证新意。", "",
        "首轮EN–FR q175的seed709曾出现约2.626秒异常，原始结果保留。新进程单独记录预热后，3次generic计算约3.36–3.73毫秒；不使用孤立异常构造加速倍数，也未把异常原因确定归结于初始化。", "",
        "## 一个新的可审查结果：27边查询的反例", "",
        "EN–FR q98在τ=.25的族内没有统一唯一众数。3168个计数状态允许精确找到两组端点取值，组大小为2/10/1/11/3：", "",
        "| 各组取高端点的边数 | 候选0概率 | 候选1概率 | 唯一赢家 |", "| --- | ---: | ---: | --- |"]
    for w in witnesses:
        probs = list(map(Q, w["candidate_probabilities_exact"]))
        lines.append(f"| {w['high_endpoint_counts_by_group']} | {float(probs[0]):.6f} | {float(probs[1]):.6f} | {w['winner']} |")
    lines += ["", "组内任意对应数量的边取高端点，其余取低端点即可复现。两组参数都属于原逐边独立盒，没有通过缩小参数族获得结果。generic在1024世界内保持未决；这不构成它的错误，也不证明计数法优于已有精确lifted/credal引擎。", "",
        "## 先行研究与贡献门槛", "",
        "已对照C-FOVE计数公式、lifted compilation、credal-circuit鲁棒事件概率和参数综合。补查PASTA lifted inference发现其也利用聚合和不可区分世界计算概率界；其多answer-set语义与本问题不同，不能简单声称完全覆盖。", "",
        '[说明文本已清理]', "",
        '[说明文本已清理]', "",
        "本轮交付为可复用的强精确基线、真实压缩结构清单、精确反例及方法适用边界。它们使后续差异审查更具体，而不是重复原来的采样/分区修补。", "",
        f"独立汇总核验{checked}项通过；各阶段原始核对数见其summary。冻结历史数值源、输入和参考哈希不变。", "",
        "入口：[静态清单](inventory_attempt1/inventory.json)、[原型结果](prototype_attempt1/summary.json)、[预热计时](timing_attempt1/summary.json)、[分析](analysis.json)、[核验](validation.json)、[图](figures/grouped_feasibility.pdf)。"]
    with (base / "RESULTS_ZH.md").open("x", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    print(json.dumps({"validation": "PASS", "checks": checked, "gate": metrics["gate"]}, ensure_ascii=False))


def figure(base):
    sys.path.insert(0, str(ROOT / ".runtime/icde_plot_site"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    data = load(base / "analysis.json")
    rows = data["cost_rows"]
    destination = base / "figures"
    destination.mkdir(exist_ok=False)
    plt.rcParams.update({"font.size": 9, "pdf.fonttype": 42, "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    labels = [f"{r['graph'].upper()}-{r['rank']}" for r in rows]
    large = rows[:8]
    x = list(range(8))
    axes[0].bar([v-.18 for v in x], [r["scope_edges"] for r in large], .35, color="#566d85", label="Boolean states: log2(2^m)")
    axes[0].bar([v+.18 for v in x], [math.log2(r["count_states"]) for r in large], .35, color="#4a9d9b", label="Count states: log2(S)")
    axes[0].set(xticks=x, xticklabels=labels[:8], ylabel="Binary exponent of state count", ylim=(0, 48),
                title="A. Structural compression on selected larger scopes")
    axes[0].tick_params(axis="x", rotation=50)
    axes[0].legend(frameon=False, loc="upper right", fontsize=8)
    x = list(range(len(rows)))
    axes[1].plot(x, [r["exact_ms"] for r in rows], "o-", color="#277b9b", label="Counting exact: complete decision")
    certified = [i for i, r in enumerate(rows) if r["mc_certified_repeats"] == 3]
    unresolved = [i for i, r in enumerate(rows) if r["mc_certified_repeats"] == 0]
    axes[1].scatter(certified, [rows[i]["mc_ms"] for i in certified], marker="^", color="#cb8744", label="Generic MC: certified")
    axes[1].scatter(unresolved, [rows[i]["mc_ms"] for i in unresolved], marker="x", color="#a24e4e", label="Generic MC: unresolved")
    axes[1].set_yscale("log")
    axes[1].set(xticks=x, xticklabels=labels, ylabel="Warm compute time (ms, log scale)",
                title="B. Different cost regimes; no universal speed advantage")
    axes[1].tick_params(axis="x", rotation=50)
    axes[1].legend(frameon=False, loc="upper left", fontsize=8)
    axes[1].grid(axis="y", color="#e5e8eb", linewidth=.5)
    fig.text(.5, .015, "Known development subset; warm medians of 3 runs. Counting/tensor operations are standard inference techniques.",
             ha="center", fontsize=8, color="#58616b")
    fig.tight_layout(rect=(0, .055, 1, 1), w_pad=2)
    for suffix in ("png", "pdf"):
        fig.savefig(destination / f"grouped_feasibility.{suffix}", dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(str(destination))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("report", "figure"), required=True)
    parser.add_argument("--output", type=Path, default=BASE)
    args = parser.parse_args()
    {"report": report, "figure": figure}[args.phase](args.output.resolve())
