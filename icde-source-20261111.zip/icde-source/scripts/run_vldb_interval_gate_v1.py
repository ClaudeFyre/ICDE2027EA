"""Reconstruct fixed V0 queries and run the explicitly frozen V1 event gate.

The root runner freezes this new driver before execution.  V0 files are read
only.  All new coupling work and static reconstruction are charged separately.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import re
import sys
import time
from collections import Counter, defaultdict
from decimal import Decimal, localcontext, ROUND_CEILING, ROUND_FLOOR
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
if str(REPO / "src") not in sys.path:
    sys.path.insert(0, str(REPO / "src"))

from pkgea.backbones.attribute import (
    AttributeStructuralBackbone, _character_ngrams, _tfidf_cosine,
    normalize_attribute_value,
)
from pkgea.backbones.toy import ToyStructuralBackbone
from pkgea.contracts import dataset_revision_digest
from pkgea.scope import build_incident_degree_certificate
from vldb_capture_attribute_v0 import build_degree_kernel, generate_winner_indices, stream_seed
from vldb_stream_frontier_v0 import _settings, _verify_scope, file_sha256, replay_query


SCHEMA = "vldb-interval-event-gate-result-v1"


def _inside(root: Path, name: str | Path) -> Path:
    candidate = Path(name)
    resolved = (candidate if candidate.is_absolute() else root / candidate).resolve()
    resolved.relative_to(root)
    return resolved


def _read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def _array_hash(value: np.ndarray) -> str:
    return hashlib.sha256(value.tobytes(order="C")).hexdigest()


def _write_new(path: Path, value: dict) -> float:
    started = time.perf_counter()
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    return time.perf_counter() - started


def build_selected_backbone(dataset: Path, selected_sources: tuple[str, ...], *, attribute_weight: float = 0.8) -> tuple[AttributeStructuralBackbone, dict]:
    """Keep the complete original TF-IDF corpus, compute only selected pairs."""
    started = time.perf_counter()
    entities = _read_tsv(dataset / "entities.tsv")
    triples = _read_tsv(dataset / "triples.tsv")
    alignments = _read_tsv(dataset / "alignments.tsv")
    sources = tuple(dict.fromkeys(row["source_entity_id"] for row in alignments))
    targets = tuple(dict.fromkeys(row["target_entity_id"] for row in alignments))
    if not selected_sources or len(set(selected_sources)) != len(selected_sources) or not set(selected_sources) <= set(sources):
        raise ValueError("selected sources must be unique members of the V0 source universe")
    if not math.isfinite(attribute_weight) or not 0 <= attribute_weight <= 1:
        raise ValueError("invalid fixed attribute weight")
    labels = {row["entity_id"]: row["label"] for row in entities}
    values = defaultdict(list)
    if (dataset / "attributes.tsv").is_file():
        for row in _read_tsv(dataset / "attributes.tsv"):
            value = normalize_attribute_value(row["value"])
            if value:
                values[row["entity_id"]].append(value)
    vectors = {entity: _character_ngrams(values[entity]) for entity in (*sources, *targets)}
    frequency = Counter(feature for vector in vectors.values() for feature in vector)
    count = len(vectors)
    attribute = {}
    lexical = {}
    for source in selected_sources:
        for target in targets:
            attribute[source, target] = _tfidf_cosine(vectors[source], vectors[target], frequency, count)
            lexical[source, target] = SequenceMatcher(None, labels[source].casefold(), labels[target].casefold()).ratio()
    structural = ToyStructuralBackbone(
        triples=triples, source_entities=sources, target_entities=targets,
        all_entities=tuple(row["entity_id"] for row in entities), labels=labels,
        lexical_scores=lexical,
    )
    backbone = AttributeStructuralBackbone(structural, attribute, attribute_weight)
    return backbone, {
        "seconds": time.perf_counter() - started,
        "corpus_documents": count, "original_source_count": len(sources),
        "original_target_count": len(targets), "selected_source_count": len(selected_sources),
        "computed_pair_count": len(attribute), "full_pair_matrix_constructed": False,
        "normalization_ngram_and_cosine": "original_private_helpers_unchanged",
        "all_source_and_target_document_frequency_preserved": True,
    }


def _interval_add(left: tuple[float, float], right: tuple[float, float]) -> tuple[float, float]:
    return (float(np.nextafter(left[0] + right[0], -np.inf)), float(np.nextafter(left[1] + right[1], np.inf)))


def _interval_multiply(left: tuple[float, float], right: tuple[float, float]) -> tuple[float, float]:
    products = [a * b for a in left for b in right]
    return float(np.nextafter(min(products), -np.inf)), float(np.nextafter(max(products), np.inf))


def outward_score_range(attribute: float, lexical: float, attribute_weight: float) -> tuple[float, float]:
    """Enclose the original operation tree with structural score in [0, 1]."""
    if not all(math.isfinite(value) for value in (attribute, lexical, attribute_weight)):
        raise ValueError("score inputs must be finite")
    if not 0 <= attribute_weight <= 1:
        raise ValueError("invalid attribute weight")
    a = (attribute_weight, attribute_weight)
    structural_weight = (float(np.nextafter(1.0 - attribute_weight, -np.inf)), float(np.nextafter(1.0 - attribute_weight, np.inf)))
    static = _interval_multiply(a, (attribute, attribute))
    lexical_term = _interval_multiply((0.6, 0.6), (lexical, lexical))
    degree_term = _interval_multiply((0.4, 0.4), (0.0, 1.0))
    mixed = _interval_add(lexical_term, degree_term)
    return _interval_add(static, _interval_multiply(structural_weight, mixed))


def audit_candidate_preservation(backbone: AttributeStructuralBackbone, source: str, retained: tuple[str, ...]) -> dict:
    started = time.perf_counter()
    if not retained or len(set(retained)) != len(retained) or not set(retained) <= set(backbone.target_entities):
        raise ValueError("invalid retained candidate universe")
    ranges = {
        target: outward_score_range(backbone.attribute_scores[source, target], backbone.structural.lexical_scores[source, target], backbone.attribute_weight)
        for target in backbone.target_entities
    }
    witness = max(retained, key=lambda target: (ranges[target][0], target))
    witness_lower = ranges[witness][0]
    removed = [target for target in backbone.target_entities if target not in set(retained)]
    failures = [target for target in removed if not ranges[target][1] < witness_lower]
    return {
        "status": "PASS" if not failures else "FAIL",
        "all_candidate_count": len(ranges), "retained_count": len(retained), "removed_count": len(removed),
        "witness_candidate": witness, "witness_outward_lower": witness_lower,
        "maximum_removed_outward_upper": max((ranges[target][1] for target in removed), default=None),
        "minimum_strict_separation": min((witness_lower - ranges[target][1] for target in removed), default=None),
        "failed_removed_candidates": failures, "seconds": time.perf_counter() - started,
        "criterion": "every removed outward upper is strictly below one retained outward lower",
    }


def clipped_box(q: np.ndarray, tau: float) -> tuple[np.ndarray, np.ndarray]:
    if q.dtype != np.float64 or q.ndim != 1 or not np.isfinite(q).all() or np.any((q < 0) | (q > 1)):
        raise ValueError("q must be a finite one-dimensional float64 probability vector")
    if not math.isfinite(tau) or not 0 <= tau <= 1:
        raise ValueError("invalid box half-width")
    if tau == 0:
        return q.copy(), q.copy()
    return (np.maximum(0.0, np.nextafter(q - tau, -np.inf)), np.minimum(1.0, np.nextafter(q + tau, np.inf)))


def conservative_scope_tv(q: np.ndarray, low: np.ndarray, high: np.ndarray) -> tuple[float, dict]:
    """Round every coordinate radius upward and agreement product downward."""
    if q.dtype != np.float64 or low.dtype != np.float64 or high.dtype != np.float64 or q.shape != low.shape or q.shape != high.shape:
        raise ValueError("box arrays must share float64 dtype and shape")
    if not np.isfinite(q).all() or not np.isfinite(low).all() or not np.isfinite(high).all() or np.any((low < 0) | (low > q) | (q > high) | (high > 1)):
        raise ValueError("invalid box endpoints")
    distance = np.maximum(np.nextafter(q - low, np.inf), np.nextafter(high - q, np.inf))
    distance[(q == low) & (q == high)] = 0
    distance = np.minimum(1.0, distance)
    if not np.any(distance):
        bound = 0.0
    else:
        with localcontext() as context:
            context.prec = 60
            context.rounding = ROUND_FLOOR
            agreement = Decimal(1)
            for value in distance:
                agreement *= Decimal(1) - Decimal.from_float(float(value))
            context.rounding = ROUND_CEILING
            epsilon = Decimal(1) - agreement
            bound = min(1.0, float(np.nextafter(float(epsilon), np.inf)))
    return bound, {
        "actual_outward_radius_sha256": _array_hash(distance),
        "maximum_outward_coordinate_radius": float(np.max(distance)) if len(distance) else 0.0,
        "low_sha256": _array_hash(low), "high_sha256": _array_hash(high), "q_sha256": _array_hash(q),
        "rounding": "float64_upward_coordinate_radii; Decimal60_FLOOR_agreement; CEILING_complement; nextafter_upper_float",
        "is_conservative_upper_bound": True, "bitwise_exact_tv_claim": False,
    }


def _validate_config(config: dict) -> None:
    taus = config["tau_grid"]
    if not taus or len(set(taus)) != len(taus) or any(not math.isfinite(tau) or not 0 < tau < 1 for tau in taus):
        raise ValueError("tau boxes must be fixed, distinct and in (0,1)")
    if config["primary_tau"] not in taus:
        raise ValueError("primary tau is not in the frozen grid")
    if config["sample_count"] < 1 or config["chunk_size"] < 1:
        raise ValueError("event sample and chunk counts must be positive")
    nominal = float(config["delta_nominal"])
    beta = float(config["beta_per_tau"])
    if not 0 < nominal < 1 or not 0 < beta < 1 or nominal + beta * len(taus) > config["delta_total"] + 1e-15:
        raise ValueError("per-query nominal and simultaneous-event risk budgets exceed delta_total")
    if not math.isclose(beta * len(taus), config["beta_total"], rel_tol=0, abs_tol=1e-15):
        raise ValueError("event beta split differs from beta_total")


def _nominal_replay(query: dict, full_edges: int, config: dict, epsilon_values: list[float], delta: float) -> dict[float, dict]:
    settings = _settings({**config["nominal"], "delta": delta, "epsilon_grid": list(dict.fromkeys([0.0, *epsilon_values])), "tau_grid": [0.0]})
    result = replay_query(query, full_edges, settings, independent=False)
    return {row["value"]: row for row in result["normal_mixture_frontier"]}


def run_interval_gate(config: dict, root: str | Path, output_dir: str | Path) -> dict:
    from vldb_interval_envelope_v1 import ambiguity_indicators, confidence_upper

    root = Path(root).resolve()
    output = _inside(root, output_dir)
    _validate_config(config)
    if os.environ.get("PYTHONHASHSEED") != str(config["required_pythonhashseed"]):
        raise ValueError("fixed Python hash seed is required to reproduce original TF-IDF floats")
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("use a fresh V1 artifact directory")
    output.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    manifests = []
    for specification in config["stream_manifests"]:
        path = _inside(root, specification["path"])
        if file_sha256(path) != specification["sha256"]:
            raise ValueError("V0 stream manifest hash mismatch")
        manifest = json.loads(path.read_text(encoding="utf-8"))
        dataset = _inside(root, manifest["dataset_path"])
        if manifest["schema_version"] != "vldb-categorical-stream-v1" or dataset_revision_digest(dataset) != manifest["dataset_revision"]:
            raise ValueError("V0 schema or dataset revision mismatch")
        if manifest["world_law"]["dependence"] != "independent" or manifest["world_law"]["semantics"] != "declared":
            raise ValueError("V1 requires the fixed declared independent law")
        for name, expected in manifest["implementation_sha256"].items():
            if file_sha256(_inside(root, name)) != expected:
                raise ValueError("inherited V0 implementation changed")
        for name, expected in manifest["input_sha256"].items():
            if file_sha256(dataset / name) != expected:
                raise ValueError("V0 canonical input changed")
        manifests.append((specification, manifest))
    if not manifests:
        raise ValueError("at least one explicitly frozen V0 manifest is required")
    input_identity_seconds = time.perf_counter() - started
    groups = defaultdict(list)
    for specification, manifest in manifests:
        groups[(manifest["graph"], manifest["dataset_path"], manifest["dataset_revision"])].append((specification, manifest))
    reconstruction = []
    event_results = []
    comparisons = []
    raw_files = []
    io_seconds = 0.0
    statistical_replay_seconds = 0.0
    for (graph, dataset_path, revision), group in groups.items():
        first = group[0][1]
        query_ids = tuple(row["query_id"] for row in first["queries"])
        if len(set(query_ids)) != len(query_ids):
            raise ValueError("duplicate V0 query identity")
        by_query = {query: [] for query in query_ids}
        for specification, manifest in group:
            if tuple(row["query_id"] for row in manifest["queries"]) != query_ids or manifest["scorer"] != first["scorer"]:
                raise ValueError("nominal seeds do not share the same fixed query/scorer contract")
            for row in manifest["queries"]:
                _verify_scope(row, manifest)
                by_query[row["query_id"]].append((manifest, row))
        dataset = _inside(root, dataset_path)
        backbone, build_cost = build_selected_backbone(dataset, query_ids, attribute_weight=float(first["scorer"]["attribute_weight"]))
        probabilities = np.asarray([float(row["confidence"]) for row in backbone.triples], dtype=np.float64)
        full_edges = len(backbone.triples)
        if full_edges != first["full_edge_count"]:
            raise ValueError("full edge count differs from V0")
        full_bounds = {}
        full_bound_started = time.perf_counter()
        for tau in config["tau_grid"]:
            low, high = clipped_box(probabilities, tau)
            full_bounds[tau] = conservative_scope_tv(probabilities, low, high)
        build_cost["full_graph_bound_seconds"] = time.perf_counter() - full_bound_started
        reconstruction.append({"graph": graph, "dataset_revision": revision, **build_cost})
        for query_id, instances in by_query.items():
            original = instances[0][1]
            candidates = tuple(original["candidate_ids"])
            indices = tuple(original["scope_edge_indices"])
            certificate, scope = build_incident_degree_certificate(
                backbone.triples, dataset_revision=revision, query_id=query_id, candidates=candidates,
                scorer_id=first["scorer"]["id"], scorer_version=first["scorer"]["version"],
            )
            if tuple(sorted(scope)) != indices or certificate.certificate_sha256 != original["scope_certificate"]["certificate_sha256"]:
                raise ValueError("reconstructed dependency scope differs from V0")
            for manifest, row in instances:
                if row["candidate_ids"] != original["candidate_ids"] or row["scope_edge_indices"] != original["scope_edge_indices"]:
                    raise ValueError("nominal seeds changed candidate or scope identities")
            candidate_audit = audit_candidate_preservation(backbone, query_id, candidates)
            if candidate_audit["status"] != "PASS":
                return {"schema_version": SCHEMA, "status": "V1_FAIL_CANDIDATE_PRUNING", "graph": graph, "query_id": query_id, "candidate_audit": candidate_audit, "events_interpreted": False, "wall_seconds": time.perf_counter() - started}
            before = time.perf_counter()
            kernel = build_degree_kernel(backbone, query_id, candidates, indices)
            q = probabilities[list(indices)]
            replay_checks = []
            for manifest, row in instances:
                if len(row["winner_indices"]) != 4096:
                    raise ValueError("V1 requires all 4096 saved V0 winner observations")
                derived = stream_seed(graph, revision, query_id, manifest["stream_seed"], "winner_stream")
                if derived != int(row["rng_seed_hex"], 16):
                    raise ValueError("nominal stream seed does not match V0 identity derivation")
                winners, _ = generate_winner_indices(kernel, q, len(row["winner_indices"]), derived, manifest["chunk_size"])
                if winners != row["winner_indices"]:
                    return {"schema_version": SCHEMA, "status": "V1_FAIL_WINNER_REPLAY", "graph": graph, "query_id": query_id, "nominal_seed": manifest["stream_seed"], "events_interpreted": False, "wall_seconds": time.perf_counter() - started}
                replay_checks.append({"nominal_seed": manifest["stream_seed"], "all_winners_equal": True, "winners_checked": len(winners)})
            replay_seconds = time.perf_counter() - before
            seed = stream_seed(graph, revision, query_id, config["envelope_seed"], config["envelope_seed_purpose"])
            before = time.perf_counter()
            uniforms = np.random.default_rng(seed).random((config["sample_count"], len(q)), dtype=np.float64)
            uniform_hash = _array_hash(uniforms)
            sampling_seconds = time.perf_counter() - before
            tau_records = []
            for tau in config["tau_grid"]:
                before = time.perf_counter()
                low, high = clipped_box(q, tau)
                scope_bound, endpoint_audit = conservative_scope_tv(q, low, high)
                flags = []
                for begin in range(0, len(uniforms), config["chunk_size"]):
                    indicators = ambiguity_indicators(kernel, q, low, high, uniforms[begin:begin + config["chunk_size"]])
                    if indicators.dtype != np.bool_ or indicators.shape != (min(config["chunk_size"], len(uniforms) - begin),):
                        raise ValueError("interval core returned invalid ambiguity indicators")
                    flags.extend(bool(value) for value in indicators)
                count = sum(flags)
                upper = min(1.0, float(np.nextafter(confidence_upper(count, len(flags), config["beta_per_tau"]), np.inf)))
                tau_records.append({
                    "tau": tau, "epsilon_scope_upper": scope_bound,
                    "epsilon_full_graph_upper": full_bounds[tau][0],
                    "ambiguity_count": count, "event_sample_count": len(flags),
                    "event_empirical_rate": count / len(flags), "event_probability_upper": upper,
                    "effective_epsilon_upper": min(scope_bound, upper),
                    "endpoint_audit": endpoint_audit, "full_graph_endpoint_audit": full_bounds[tau][1],
                    "h_flags": flags, "h_flags_sha256": _array_hash(np.asarray(flags, dtype=np.bool_)),
                    "box_interval_and_upper_seconds": time.perf_counter() - before,
                })
            record = {
                "graph": graph, "query_id": query_id, "candidate_count": len(candidates),
                "scope_edge_count": len(indices), "candidate_pruning_audit": candidate_audit,
                "nominal_replay": replay_checks, "nominal_reconstruction_and_replay_seconds": replay_seconds,
                "envelope_seed": config["envelope_seed"], "rng_seed_hex": hex(seed),
                "uniform_array_shape": list(uniforms.shape), "uniform_sha256": uniform_hash,
                "uniform_sampling_seconds": sampling_seconds,
                "event_bernoulli_uniform_draws_charged_once": int(uniforms.size),
                "shared_across_nominal_seeds": [manifest["stream_seed"] for manifest, _ in instances],
                "same_uniforms_across_tau": True, "tau_results": tau_records,
            }
            slug = re.sub(r"[^a-z0-9]+", "_", graph.casefold()).strip("_")
            filename = f"event_{slug}_{hashlib.sha256(query_id.encode()).hexdigest()[:16]}.json"
            path = output / filename
            io_seconds += _write_new(path, record)
            raw_files.append({"path": path.relative_to(root).as_posix(), "sha256": file_sha256(path)})
            event_results.append({key: value for key, value in record.items() if key != "tau_results"} | {"tau_results": [{key: value for key, value in item.items() if key != "h_flags"} for item in tau_records]})
            epsilon_values = [item[key] for item in tau_records for key in ("epsilon_scope_upper", "epsilon_full_graph_upper", "effective_epsilon_upper")]
            for manifest, row in instances:
                replay_started = time.perf_counter()
                matched = _nominal_replay(row, full_edges, config, epsilon_values, config["delta_nominal"])
                full_risk = _nominal_replay(row, full_edges, config, epsilon_values, config["delta_total"])
                statistical_replay_seconds += time.perf_counter() - replay_started
                for item in tau_records:
                    effective, scope_epsilon, full_epsilon = (item[key] for key in ("effective_epsilon_upper", "epsilon_scope_upper", "epsilon_full_graph_upper"))
                    policies = {
                        "interval_event_gate": matched[effective],
                        "scope_matched_delta": matched[scope_epsilon],
                        "scope_full_risk": full_risk[scope_epsilon],
                        "full_graph_full_risk": full_risk[full_epsilon],
                        "nominal_matched_delta": matched[0.0],
                        "nominal_full_risk": full_risk[0.0],
                    }
                    comparisons.append({
                        "graph": graph, "query_id": query_id, "nominal_seed": manifest["stream_seed"],
                        "tau": item["tau"], "nontrivial_query": len(candidates) > 1,
                        "policies": policies,
                        "recovered_vs_matched_scope": policies["interval_event_gate"]["stable"] and not policies["scope_matched_delta"]["stable"],
                        "recovered_vs_full_risk_scope": policies["interval_event_gate"]["stable"] and not policies["scope_full_risk"]["stable"],
                    })
            del uniforms
    aggregation = []
    for graph in sorted({row["graph"] for row in comparisons}):
        for tau in config["tau_grid"]:
            rows = [row for row in comparisons if row["graph"] == graph and row["tau"] == tau]
            aggregation.append({
                "graph": graph, "tau": tau, "query_seed_cases": len(rows),
                "unique_queries": len({row["query_id"] for row in rows}),
                "policies": {name: {
                    "stable_count": sum(row["policies"][name]["stable"] for row in rows),
                    "coverage": sum(row["policies"][name]["stable"] for row in rows) / len(rows),
                    "worlds_used": sum(row["policies"][name]["samples_used"] for row in rows),
                    "logical_scope_edge_cost": sum(row["policies"][name]["logical_scope_edge_cost"] for row in rows),
                } for name in rows[0]["policies"]},
                "nontrivial_recovered_vs_matched_scope": sum(row["nontrivial_query"] and row["recovered_vs_matched_scope"] for row in rows),
                "nontrivial_recovered_vs_full_risk_scope": sum(row["nontrivial_query"] and row["recovered_vs_full_risk_scope"] for row in rows),
            })
    primary_recovery = sum(row["nontrivial_query"] and row["recovered_vs_full_risk_scope"] for row in comparisons if row["tau"] == config["primary_tau"])
    return {
        "schema_version": SCHEMA, "status": "V1_EXECUTION_COMPLETE",
        "all_original_winner_streams_equal": True, "candidate_outward_pruning_pass": True,
        "unique_queries": len(event_results), "nominal_query_seed_cases": len(comparisons) // len(config["tau_grid"]),
        "primary_nontrivial_recovered_vs_full_risk_scope": primary_recovery,
        "primary_opportunity_gate_pass": primary_recovery > 0,
        "delta_accounting": {"nominal": config["delta_nominal"], "events_each_tau": config["beta_per_tau"], "total_per_query_per_nominal_run": config["delta_nominal"] + len(config["tau_grid"]) * config["beta_per_tau"], "dataset_wide_guarantee": False, "union_across_nominal_seed_guarantee": False},
        "reconstruction_costs": reconstruction, "events": event_results,
        "comparisons": comparisons, "aggregate": aggregation, "raw_event_files": raw_files,
        "new_event_uniform_draws": sum(row["event_bernoulli_uniform_draws_charged_once"] for row in event_results),
        "new_event_worlds_charged_once": len(event_results) * config["sample_count"],
        "input_identity_seconds": input_identity_seconds,
        "statistical_cs_replay_seconds": statistical_replay_seconds,
        "io_serialization_seconds": io_seconds, "total_wall_seconds": time.perf_counter() - started,
        "same_total_cost_advantage_claim": False,
        "interpretation": "Fixed-N coupling-event evidence on the existing 32 source queries; event work is charged once per query and reused across nominal seeds. No unseen-data or real-probability calibration claim.",
    }
