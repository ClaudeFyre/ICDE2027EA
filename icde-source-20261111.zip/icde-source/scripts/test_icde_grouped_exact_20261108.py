"""Exact compact solver versus independent complete Boolean/vertex reference."""
from fractions import Fraction as Q
from itertools import product
import unittest

import numpy as np

from icde_gate_exact_review import full_box_reference
from icde_grouped_exact_20261108 import compile_counts, endpoint_matrix, solve_counts, direct_representative_probabilities
from vldb_capture_attribute_v0 import DegreeScoreKernel
from vldb_difference_envelope_v2 import compile_difference_kernel


def kernel(seed, m=6):
    rng = np.random.default_rng(seed)
    # Some edges deliberately repeat an incidence pattern; include shared and
    # self-loop patterns so projection is not just independent entity degrees.
    heads = np.asarray([0, 0, 1, 1, 2, 2])[:m]
    tails = np.asarray([3, 3, 1, 3, 2, 3])[:m]
    incidence = tuple(np.flatnonzero((heads if d == 0 else tails) == entity).astype(np.intp)
                      for entity in range(4) for d in (0, 1))
    raw = DegreeScoreKernel(0, (1, 2, 3), tuple(range(m)), incidence, rng.random(3), rng.random(3), .8)
    return compile_difference_kernel(raw)


class GroupTests(unittest.TestCase):
    def test_compact_winners_and_robust_gaps_match_boolean_reference(self):
        for seed in (3, 7, 13):
            model = kernel(seed)
            low, high, q = np.full(6, .25), np.full(6, .75), np.full(6, .5)
            compiled = compile_counts(model, low, high)
            states = ((np.arange(64)[:, None] >> np.arange(6)) & 1).astype(np.bool_)
            winners = np.argmax(model.scores(states), axis=1).tolist()
            for z, state in enumerate(states):
                counts = tuple(int(sum(state[e] for e in edges)) for sig, edges, ends in compiled["groups"])
                self.assertEqual(int(compiled["winners"][counts]), winners[z])
            solved = solve_counts(compiled, 3)
            reference = full_box_reference(winners, 3, q, low, high)
            self.assertEqual(solved["uniform_winners"], reference["uniform_winners"])
            for pair in solved["pairs"]:
                w, d = pair["candidate"], pair["competitor"]
                oldpair = next(p for p in reference["candidate_results"][w]["pair_gap_ranges"] if p["competitor_index"] == d)
                self.assertEqual(Q(pair["minimum_gap_exact"]), Q(oldpair["minimum_gap"]))

    def test_every_compact_representative_matches_direct_sum_product(self):
        model = kernel(3, 4)
        compiled = compile_counts(model, np.full(4, .5), np.ones(4))
        result = solve_counts(compiled, 3)
        for t in product(*(range(n) for n in compiled["shape"])):
            direct = direct_representative_probabilities(compiled, result["matrices"], t, 3)
            self.assertEqual(direct, [int(v[t]) for v in result["numerators"]])

    def test_endpoint_heterogeneity_splits_groups(self):
        model = kernel(3)
        a = compile_counts(model, np.full(6, .25), np.full(6, .75))
        low = np.asarray([.125, .25, .375, .5, .625, .75])
        b = compile_counts(model, low, np.ones(6))
        self.assertLess(len(a["groups"]), len(b["groups"]))
        self.assertEqual(b["count_states"], 64)

    def test_zero_one_fixed_and_equal_endpoint_matrices(self):
        for low, high in ((0., 1.), (.5, .5), (.25, 1.)):
            matrix, denominator = endpoint_matrix(4, low, high)
            self.assertTrue(all(sum(row) == denominator for row in matrix))
            if low == high:
                self.assertTrue(all(list(row) == list(matrix[0]) for row in matrix))

    def test_budget_fails_before_count_state_materialization(self):
        model = kernel(3)
        with self.assertRaises(ValueError):
            compile_counts(model, np.zeros(6), np.ones(6), state_cap=1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
