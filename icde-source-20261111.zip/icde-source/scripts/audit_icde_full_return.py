"""Independently audit a full ICDE return; do not overwrite its claims or source."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from collections import Counter
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]


def strict_json(raw: bytes):
    def unique(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError(f"duplicate JSON key: {key}")
            out[key] = value
        return out

    def invalid(value):
        raise ValueError(f"nonstandard JSON constant: {value}")

    return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=unique, parse_constant=invalid)


def audit(bundle_path: Path, manifest_path: Path, acceptance_path: Path):
    manifest = strict_json(manifest_path.read_bytes())
    declared = strict_json(acceptance_path.read_bytes())
    archive_sha = hashlib.sha256(bundle_path.read_bytes()).hexdigest()
    with zipfile.ZipFile(bundle_path) as bundle:
        infos = bundle.infolist()
        names = [i.filename for i in infos]
        duplicates = [name for name, count in Counter(names).items() if count > 1]
        unsafe = [
            name
            for name in names
            if PurePosixPath(name).is_absolute()
            or ".." in PurePosixPath(name).parts
            or "\\" in name
        ]
        if duplicates or unsafe or sum(i.file_size for i in infos) > 100_000_000:
            raise ValueError("duplicate/unsafe/oversized return archive")
        actual = {i.filename for i in infos if not i.is_dir()}
        expected = set(manifest["files"])
        mismatch = []
        for name, digest in manifest["files"].items():
            if isinstance(digest, dict):
                digest = digest["sha256"]
            if name not in actual or hashlib.sha256(bundle.read(name)).hexdigest() != digest:
                mismatch.append(name)
        inner = strict_json(bundle.read("BUNDLE_MANIFEST.json"))
        crc_error = bundle.testzip()
        integrity = {
            "archive_sha256": archive_sha,
            "archive_sha_matches": archive_sha == manifest["verification"]["sha256"],
            "entries": len(infos),
            "data_files": len(expected),
            "directories": sum(i.is_dir() for i in infos),
            "missing": sorted(expected - actual),
            "extra": sorted(actual - expected),
            "sha256_mismatches": mismatch,
            "inner_outer_file_manifest_equal": inner["files"] == manifest["files"],
            "crc_error": crc_error,
        }
        integrity["passed"] = (
            integrity["archive_sha_matches"]
            and not mismatch
            and not integrity["missing"]
            and integrity["extra"] == ["BUNDLE_MANIFEST.json"]
            and integrity["inner_outer_file_manifest_equal"]
            and crc_error is None
        )
        windows_roots = []
        for name in actual:
            if name.endswith(".py"):
                source = bundle.read(name).decode("utf-8-sig")
                if 'Path(r"E:\\pkgea")' in source:
                    windows_roots.append(name)
        initializer = bundle.read("src/pkgea/query/__init__.py").decode()
        missing_imports = []
        for module in re.findall(r"from (pkgea\.[\w.]+) import", initializer):
            path = "src/" + module.replace(".", "/") + ".py"
            if path not in actual and not (ROOT / path).is_file():
                missing_imports.append(module)
        prefix = "nodes/05_icde_query_engine/results/icde_traces_20261009/"
        trace_names = sorted(
            name for name in actual if name.startswith(prefix) and name.endswith("/trace.jsonl")
        )
        split_rows = []
        for group in (
            "nonrepeated_overlap",
            "hotspot_partial",
            "disjoint_scopes",
            "hub_factor_updates",
        ):
            sets = {}
            for seed in (17, 23, 31):
                path = f"{prefix}{group}__seed{seed}__b64/trace.jsonl"
                queries = [
                    strict_json(line)
                    for line in bundle.read(path).splitlines()
                    if line and strict_json(line)["kind"] == "query"
                ]
                sets[seed] = {
                    "sources": {q["source"] for q in queries},
                    "queries": {(q["source"], tuple(q["ordered_candidates"])) for q in queries},
                    "n": len(queries),
                    "snapshots": {q["requested_snapshot"] for q in queries},
                }
            train = sets[17]["sources"] | sets[23]["sources"]
            train_q = sets[17]["queries"] | sets[23]["queries"]
            split_rows.append(
                {
                    "group": group,
                    "train_sources": len(train),
                    "blind_sources": len(sets[31]["sources"]),
                    "overlapping_sources": len(train & sets[31]["sources"]),
                    "overlapping_query_signatures": len(train_q & sets[31]["queries"]),
                    "seed17_requests": sets[17]["n"],
                    "seed17_unique_queries": len(sets[17]["queries"]),
                    "seed31_requested_snapshot_count": len(sets[31]["snapshots"]),
                }
            )
        e5_path = "nodes/05_icde_query_engine/results/icde_e5_20261009/official_e5_frozen.json"
        e5 = strict_json(bundle.read(e5_path))
        evidence_paths = [
            path for check in declared["checks"].values() for path in check.get("evidence", [])
        ]
        comparisons = []
        for name in sorted(expected):
            local = ROOT / name
            if local.is_file() and local.read_bytes() != bundle.read(name):
                comparisons.append(name)
        return {
            "format": "icde-full-return-independent-audit-v1",
            "integrity": integrity,
            "acceptance_matches_bundled": declared
            == strict_json(
                bundle.read("nodes/05_icde_query_engine/results/icde_full_acceptance_20261009.json")
            ),
            "missing_declared_evidence": sorted(set(evidence_paths) - actual),
            "different_existing_local_files": comparisons,
            "compatibility": {
                "missing_imports": missing_imports,
                "hardcoded_windows_repo_scripts": sorted(windows_roots),
                "standalone_base_included": "pyproject.toml" in actual
                and "src/pkgea/certified.py" in actual,
                "trace_count": len(trace_names),
                "manifest_graph_paths": sorted(
                    {
                        strict_json(bundle.read(name.replace("trace.jsonl", "manifest.json")))[
                            "graph_reference"
                        ]["dir"]
                        for name in trace_names
                    }
                ),
            },
            "split_audit": split_rows,
            "source_cluster_disjoint": all(r["overlapping_sources"] == 0 for r in split_rows),
            "e5_reported_metrics": {
                key: e5[key]
                for key in (
                    "cost_weights",
                    "blind_naive_cost",
                    "blind_actual_cost_best_fixed",
                    "prediction_error_naive_vs_bestfixed",
                    "hindsight_oracle_cost_blind",
                    "plan_regret_blind",
                )
            },
            "phase_decision": {
                "P0": "intake_artifacts_received_quality_and_raw_revalidation_pending",
                "P1": "finite_same_stream_correctness_supported_service_semantics_pending",
                "E0": "semantic_checks_supported_learned_quality_pending",
                "E2": "offline_batch_count_harness_only",
                "E3": "controlled_revision_harness_partial",
                "E4": "label_payload_grid_only",
                "E5": "source_split_and_cost_protocol_need_repair",
                "E6": "exception_injection_toy_partial",
                "C1_C2_C3": "not_completed",
            },
            "research_acceptance": False,
            "direct_migration_ready": False,
            "boundary": "Archive integrity is distinct from execution compatibility and scientific gate closure. Original return untouched.",
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--acceptance", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("fresh audit output required")
    result = audit(args.bundle, args.manifest, args.acceptance)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(
        json.dumps(
            {
                "integrity": result["integrity"],
                "compatibility": result["compatibility"],
                "source_cluster_disjoint": result["source_cluster_disjoint"],
            },
            indent=2,
        )
    )
    if not result["integrity"]["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
