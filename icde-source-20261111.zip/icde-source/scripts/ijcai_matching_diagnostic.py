"""Validation-only opportunity diagnostic for partial one-to-one alignment.

This module reads only the first 128 G1 validation rows.  Its risk envelopes
use those validation labels and are exploratory, not risk certificates or
independent test results.  It never opens world arrays or parses test pairs.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
import zipfile
from pathlib import Path
from typing import Any

import numpy as np


VALIDATION_ROWS = 128
G1_TOTAL_ROWS = 384
G1_CANDIDATES = 15_000
SCHEMA = "ijcai-matching-validation-diagnostic-v1"
METHODS = ("point_margin", "margin_skip_conflicts", "hungarian_assigned_margin")


def _alphas(values: tuple[float, ...]) -> tuple[float, ...]:
    result = tuple(float(value) for value in values)
    if not result or len(set(result)) != len(result):
        raise ValueError("alphas must be nonempty and unique")
    if any(not math.isfinite(value) or not 0 < value < 1 for value in result):
        raise ValueError("alphas must be finite and strictly between zero and one")
    return result


def read_validation_capture(path: str | Path) -> tuple[dict, np.ndarray, dict]:
    """Parse the recorded pretty-JSON header and exactly 128 leading pairs.

    The unbuffered file is closed at the closing line of pair 128.  In
    particular, this deliberately does not parse the whole JSON document.
    Noncanonical layouts are rejected instead of falling back to json.load.
    """
    path = Path(path)
    metadata: dict[str, Any] = {}
    prefix_hash = hashlib.sha256()
    line_count = 0

    with path.open("rb", buffering=0) as handle:
        def line() -> bytes:
            nonlocal line_count
            raw = handle.readline(4097)
            if not raw or len(raw) > 4096:
                raise ValueError("missing or overlong capture prefix line")
            line_count += 1
            prefix_hash.update(raw)
            return raw.strip()

        if line() != b"{":
            raise ValueError("capture must use the recorded multiline JSON layout")
        while True:
            value = line()
            if value == b'"pairs": [':
                break
            match = re.fullmatch(rb'"([a-zA-Z0-9_]+)": (.*),?', value)
            if match is None:
                raise ValueError("unexpected capture header layout")
            key = match.group(1).decode("ascii")
            if key in metadata:
                raise ValueError("duplicate capture header field")
            payload = match.group(2).removesuffix(b",")
            metadata[key] = json.loads(payload)

        if metadata.get("validation_queries") != VALIDATION_ROWS:
            raise ValueError("G1 diagnostic requires exactly 128 validation queries")
        if metadata.get("test_queries") != G1_TOTAL_ROWS - VALIDATION_ROWS:
            raise ValueError("unexpected G1 test-row count metadata")
        pairs = []
        for _ in range(VALIDATION_ROWS):
            if line() != b"[":
                raise ValueError("expected a multiline validation pair")
            values = []
            for _ in range(2):
                token = line().removesuffix(b",")
                if re.fullmatch(rb"-?[0-9]+", token) is None:
                    raise ValueError("validation entity IDs must be integers")
                values.append(int(token))
            if line() not in (b"],", b"]"):
                raise ValueError("invalid validation pair closing line")
            pairs.append(values)
        bytes_read = handle.tell()

    array = np.asarray(pairs, dtype=np.int64)
    manifest = {
        "path": str(path.resolve()),
        "mode": "unbuffered_prefix_only",
        "parsed_pair_rows": [0, VALIDATION_ROWS],
        "parsed_pair_count": VALIDATION_ROWS,
        "bytes_read": bytes_read,
        "lines_read": line_count,
        "prefix_sha256": prefix_hash.hexdigest(),
        "stopped_after_validation_pair": VALIDATION_ROWS,
        "test_pairs_parsed": 0,
        "whole_document_json_parser_used": False,
    }
    return metadata, array, manifest


def read_npy_prefix(
    archive: zipfile.ZipFile,
    name: str,
    *,
    expected_shape: tuple[int, ...],
    expected_dtype: np.dtype,
    prefix_rows: int | None,
) -> tuple[np.ndarray, dict]:
    """Materialize a C-order NPY prefix, without loading the array's tail."""
    member = name + ".npy"
    if archive.namelist().count(member) != 1:
        raise ValueError(f"missing or duplicate NPZ member: {member}")
    with archive.open(member, "r") as handle:
        version = np.lib.format.read_magic(handle)
        if version == (1, 0):
            shape, fortran_order, dtype = np.lib.format.read_array_header_1_0(handle)
        elif version == (2, 0):
            shape, fortran_order, dtype = np.lib.format.read_array_header_2_0(handle)
        else:
            raise ValueError("only NPY header versions 1 and 2 are supported")
        header_bytes = handle.tell()
        if tuple(shape) != expected_shape:
            raise ValueError(f"unexpected {name} shape: {shape}")
        if fortran_order or dtype != np.dtype(expected_dtype) or dtype.hasobject:
            raise ValueError(f"unexpected {name} dtype or array order")
        if prefix_rows is not None and not 0 < prefix_rows <= shape[0]:
            raise ValueError("invalid requested array prefix")
        output_shape = shape if prefix_rows is None else (prefix_rows, *shape[1:])
        byte_count = math.prod(output_shape) * dtype.itemsize
        payload = handle.read(byte_count)
        if len(payload) != byte_count:
            raise ValueError(f"truncated validation payload: {name}")
        logical_position = handle.tell()
    array = np.frombuffer(payload, dtype=dtype).reshape(output_shape).copy()
    manifest = {
        "member": member,
        "header_shape": list(shape),
        "dtype": str(dtype),
        "fortran_order": False,
        "materialized_shape": list(output_shape),
        "materialized_rows": [0, output_shape[0]],
        "header_bytes": header_bytes,
        "payload_bytes_returned": byte_count,
        "logical_member_position_after_read": logical_position,
        "payload_sha256": hashlib.sha256(payload).hexdigest(),
        "tail_array_elements_materialized": 0,
        "note": "Counts describe logical NPY payload; ZIP decoders may buffer compressed bytes.",
    }
    return array, manifest


def validate_inputs(
    scores: np.ndarray, sources: np.ndarray, targets: np.ndarray, pairs: np.ndarray
) -> np.ndarray:
    """Validate loaded validation rows and return truth candidate columns."""
    if scores.ndim != 2 or scores.shape != (VALIDATION_ROWS, len(targets)):
        raise ValueError("scores must contain exactly the 128 validation rows")
    if sources.shape != (VALIDATION_ROWS,) or pairs.shape != (VALIDATION_ROWS, 2):
        raise ValueError("unexpected source or validation-pair shape")
    if targets.ndim != 1 or len(targets) < VALIDATION_ROWS:
        raise ValueError("not enough target candidates for injective truth")
    if not np.isfinite(scores).all():
        raise ValueError("validation scores must all be finite")
    if len(np.unique(targets)) != len(targets):
        raise ValueError("candidate target IDs must be unique")
    if len(np.unique(sources)) != VALIDATION_ROWS:
        raise ValueError("validation sources must be unique")
    if not np.array_equal(sources, pairs[:, 0]):
        raise ValueError("validation sources do not match capture pair order")
    if len(np.unique(pairs[:, 1])) != VALIDATION_ROWS:
        raise ValueError("validation truth must be injective")
    target_position = {int(target): column for column, target in enumerate(targets)}
    try:
        truth = np.asarray([target_position[int(value)] for value in pairs[:, 1]], dtype=np.int64)
    except KeyError as exc:
        raise ValueError("validation truth is missing from candidate order") from exc
    return truth


def _collisions(prediction: np.ndarray) -> dict:
    count = len(prediction)
    _, sizes = np.unique(prediction, return_counts=True)
    return {
        "rows": count,
        "unique_targets": len(sizes),
        "duplicate_excess_rows": int(count - len(sizes)),
        "duplicate_excess_fraction": float((count - len(sizes)) / count) if count else 0.0,
        "rows_in_conflicts": int(np.sum(sizes[sizes > 1])),
        "rows_in_conflicts_fraction": float(np.sum(sizes[sizes > 1]) / count) if count else 0.0,
        "conflicting_targets": int(np.sum(sizes > 1)),
        "conflicting_row_pairs": int(np.sum(sizes * (sizes - 1) // 2)),
    }


def _summarize_method(
    prediction: np.ndarray,
    confidence: np.ndarray,
    truth: np.ndarray,
    order: np.ndarray,
    alphas: tuple[float, ...],
) -> dict:
    n = len(truth)
    wrong = prediction[order] != truth[order]
    cumulative = np.cumsum(wrong, dtype=np.int64)
    curve = [{"accepted": 0, "coverage": 0.0, "errors": 0, "empirical_risk": None}]
    for position, row in enumerate(order, 1):
        errors = int(cumulative[position - 1])
        curve.append({
            "accepted": position,
            "coverage": position / n,
            "errors": errors,
            "empirical_risk": errors / position,
            "last_confidence": float(confidence[row]),
        })
    envelope = {}
    for alpha in alphas:
        admissible = [entry for entry in curve[1:] if entry["errors"] <= alpha * entry["accepted"] + 1e-12]
        best = max(admissible, key=lambda entry: entry["accepted"]) if admissible else curve[0]
        envelope[format(alpha, ".12g")] = {
            "alpha": alpha,
            "accepted": best["accepted"],
            "coverage": best["coverage"],
            "errors": best["errors"],
            "empirical_risk": best["empirical_risk"],
            "selected_validation_rows": order[:best["accepted"]].tolist(),
            "selection_role": "label-selected exploratory validation prefix; no risk guarantee",
        }
    return {
        "prediction_columns_by_validation_row": prediction.tolist(),
        "prediction_scope": "Only eligible_rows_in_confidence_order are eligible outputs; other row predictions are unserved.",
        "confidence_by_validation_row": confidence.tolist(),
        "eligible_rows_in_confidence_order": order.tolist(),
        "eligible_count": len(order),
        "abstained_before_threshold": n - len(order),
        "eligible_predictions_injective": len(np.unique(prediction[order])) == len(order),
        "curve": curve,
        "empirical_maximum_prefix": envelope,
    }


def analyze_score_matrix(
    scores: np.ndarray, truth: np.ndarray, *, alphas: tuple[float, ...] = (0.05, 0.1)
) -> dict:
    """Compute methods for an already isolated matrix (small fixtures allowed).

    Production isolation and the 128-row requirement are enforced by
    diagnose_cell/validate_inputs.  This pure numerical entrypoint is also
    useful for independent small counterexamples.
    """
    from scipy.optimize import linear_sum_assignment

    alphas = _alphas(alphas)
    scores = np.asarray(scores, dtype=np.float64)
    truth = np.asarray(truth, dtype=np.int64)
    if scores.ndim != 2 or scores.shape[0] < 1 or scores.shape[1] < max(2, scores.shape[0]):
        raise ValueError("need nonempty rows and at least max(2, rows) candidates")
    if truth.shape != (len(scores),) or np.any(truth < 0) or np.any(truth >= scores.shape[1]):
        raise ValueError("truth candidate columns are invalid")
    if not np.isfinite(scores).all():
        raise ValueError("scores must be finite")
    n = len(scores)
    started = time.perf_counter()
    point = np.argmax(scores, axis=1)
    best = scores[np.arange(n), point]
    second = np.partition(scores, -2, axis=1)[:, -2]
    point_margin = best - second
    point_order = np.argsort(-point_margin, kind="stable")
    point_seconds = time.perf_counter() - started

    started = time.perf_counter()
    used: set[int] = set()
    retained = []
    for row in point_order:
        target = int(point[row])
        if target not in used:
            retained.append(int(row))
            used.add(target)
    greedy_order = np.asarray(retained, dtype=np.int64)
    skip_seconds = time.perf_counter() - started

    started = time.perf_counter()
    row_ids, assigned_columns = linear_sum_assignment(scores, maximize=True)
    if not np.array_equal(row_ids, np.arange(n)):
        raise RuntimeError("Hungarian did not assign every validation row")
    assigned = np.asarray(assigned_columns, dtype=np.int64)
    best_other = np.where(assigned == point, second, best)
    assigned_margin = scores[np.arange(n), assigned] - best_other
    assigned_order = np.argsort(-assigned_margin, kind="stable")
    hungarian_seconds = time.perf_counter() - started

    methods = {
        "point_margin": _summarize_method(point, point_margin, truth, point_order, alphas),
        "margin_skip_conflicts": _summarize_method(point, point_margin, truth, greedy_order, alphas),
        "hungarian_assigned_margin": _summarize_method(assigned, assigned_margin, truth, assigned_order, alphas),
    }
    collisions = {"all_validation_rows": _collisions(point)}
    for coverage in (0.1, 0.25, 0.5):
        size = math.ceil(n * coverage)
        collisions["top_" + format(coverage, ".12g")] = {
            "requested_coverage": coverage,
            "actual_coverage": size / n,
            **_collisions(point[point_order[:size]]),
        }
    changed = assigned != point
    point_wrong = point != truth
    assigned_wrong = assigned != truth
    return {
        "validation_rows": n,
        "candidate_count": scores.shape[1],
        "methods": methods,
        "point_target_conflicts": collisions,
        "hungarian_changes_vs_point": {
            "changed_rows": int(np.sum(changed)),
            "corrected_errors": int(np.sum(point_wrong & ~assigned_wrong)),
            "introduced_errors": int(np.sum(~point_wrong & assigned_wrong)),
            "changed_but_still_wrong": int(np.sum(changed & point_wrong & assigned_wrong)),
            "negative_assigned_margin_rows": int(np.sum(assigned_margin < 0)),
        },
        "timing_seconds": {
            "point_argmax_margin_and_order": point_seconds,
            "conflict_skip_additional": skip_seconds,
            "hungarian_assignment_margin_and_order": hungarian_seconds,
        },
        "tie_policy": {
            "point_argmax": "first original candidate column",
            "confidence_order": "stable original validation-row order",
            "hungarian": "SciPy deterministic solver on unchanged row/column order; no score epsilon",
        },
        "partial_matching_definition": "Confidence prefixes of one frozen assignment; no threshold-dependent reoptimization.",
    }


def diagnose_cell(
    cell_dir: str | Path,
    *,
    validation_rows: int = VALIDATION_ROWS,
    alphas: tuple[float, ...] = (0.05, 0.1),
) -> dict:
    """Read and diagnose one fixed G1 cell; never materialize test rows."""
    if validation_rows != VALIDATION_ROWS:
        raise ValueError("only the fixed first 128 validation rows are permitted")
    alphas = _alphas(alphas)
    started = time.perf_counter()
    cell_dir = Path(cell_dir)
    metadata, pairs, capture_access = read_validation_capture(cell_dir / "capture.json")
    if cell_dir.name != f"{metadata.get('graph')}_s{metadata.get('model_seed')}":
        raise ValueError("capture graph/seed does not match the G1 cell directory")
    archive_path = cell_dir / "winner_trace_and_mean_scores.npz"
    accesses = []
    with zipfile.ZipFile(archive_path, "r") as archive:
        scores, access = read_npy_prefix(
            archive, "point_scores", expected_shape=(G1_TOTAL_ROWS, G1_CANDIDATES),
            expected_dtype=np.dtype("float64"), prefix_rows=VALIDATION_ROWS,
        )
        accesses.append(access)
        sources, access = read_npy_prefix(
            archive, "sources", expected_shape=(G1_TOTAL_ROWS,),
            expected_dtype=np.dtype("int64"), prefix_rows=VALIDATION_ROWS,
        )
        accesses.append(access)
        targets, access = read_npy_prefix(
            archive, "targets", expected_shape=(G1_CANDIDATES,),
            expected_dtype=np.dtype("int64"), prefix_rows=None,
        )
        accesses.append(access)
    truth = validate_inputs(scores, sources, targets, pairs)
    load_seconds = time.perf_counter() - started
    result = analyze_score_matrix(scores, truth, alphas=alphas)
    for method in result["methods"].values():
        method["prediction_target_ids_by_validation_row"] = targets[
            method["prediction_columns_by_validation_row"]
        ].tolist()
    return {
        "schema": SCHEMA,
        "cell_id": cell_dir.name,
        "graph": metadata.get("graph"),
        "model_seed": metadata.get("model_seed"),
        "role": "exploratory_existing_validation_only",
        "risk_guarantee": False,
        "test_evaluation_performed": False,
        "validation_source_ids": sources.tolist(),
        "validation_truth_columns": truth.tolist(),
        "candidate_order_sha256": hashlib.sha256(targets.tobytes()).hexdigest(),
        "access_manifest": {
            "capture": capture_access,
            "npz_path": str(archive_path.resolve()),
            "opened_npy_members": [entry["member"] for entry in accesses],
            "arrays": accesses,
            "test_score_rows_materialized": 0,
            "test_labels_parsed": 0,
            "world_arrays_opened": [],
            "source_order_matches_capture": True,
            "candidate_order_preserved": True,
            "candidate_ids_unique": True,
            "validation_truth_injective": True,
        },
        **result,
        "input_load_and_validation_seconds": load_seconds,
        "total_seconds": time.perf_counter() - started,
        "interpretation": [
            "Empirical prefixes are selected using the same observed validation labels.",
            "No finite-sample risk, conformal, or independent-confirmation claim is made.",
            "Only 128 query rows compete for 15000 targets, not the complete source graph.",
            "A low-conflict negative result cannot rule out larger-batch matching opportunities.",
        ],
    }


def aggregate_cells(results: list[dict]) -> dict:
    """Describe paired cell differences; no seed-independence inference."""
    if not results or len({row["cell_id"] for row in results}) != len(results):
        raise ValueError("need nonempty, uniquely identified cell results")

    def summarize(rows: list[dict]) -> dict:
        alpha_keys = list(rows[0]["methods"][METHODS[0]]["empirical_maximum_prefix"])
        summaries = {}
        for method in METHODS:
            summaries[method] = {}
            for alpha in alpha_keys:
                coverage = [row["methods"][method]["empirical_maximum_prefix"][alpha]["coverage"] for row in rows]
                point = [row["methods"]["point_margin"]["empirical_maximum_prefix"][alpha]["coverage"] for row in rows]
                feasible = [row["methods"]["margin_skip_conflicts"]["empirical_maximum_prefix"][alpha]["coverage"] for row in rows]
                summaries[method][alpha] = {
                    "mean_coverage": float(np.mean(coverage)),
                    "min_coverage": min(coverage),
                    "max_coverage": max(coverage),
                    "mean_paired_coverage_gain_vs_point": float(np.mean(np.subtract(coverage, point))),
                    "mean_paired_coverage_gain_vs_conflict_skip": float(np.mean(np.subtract(coverage, feasible))),
                    "cells_better_than_conflict_skip": sum(a > b for a, b in zip(coverage, feasible)),
                    "cells_worse_than_conflict_skip": sum(a < b for a, b in zip(coverage, feasible)),
                }
        return {
            "cell_count": len(rows),
            "cell_ids": [row["cell_id"] for row in rows],
            "methods": summaries,
            "mean_point_duplicate_excess_fraction": float(np.mean([
                row["point_target_conflicts"]["all_validation_rows"]["duplicate_excess_fraction"] for row in rows
            ])),
            "mean_hungarian_changed_rows": float(np.mean([
                row["hungarian_changes_vs_point"]["changed_rows"] for row in rows
            ])),
        }

    graphs = sorted({str(row["graph"]) for row in results})
    return {
        "schema": SCHEMA,
        "role": "descriptive_existing_validation_opportunity_screen",
        "risk_guarantee": False,
        "statistical_unit_note": "Cells share graph sources; seed repeats are not independent datasets. No inferential interval is reported.",
        "overall_unweighted_cells": summarize(results),
        "per_graph": {
            graph: summarize([row for row in results if str(row["graph"]) == graph])
            for graph in graphs
        },
    }
