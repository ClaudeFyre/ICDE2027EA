"""One-command driver for the WWW budget-frontier run.

Designed for a compute host with no interactive assistance: preflight, a single
smoke cell, then the full matrix, each refusing to continue on a mismatch rather
than producing a plausible-looking wrong number.

    python scripts/run_www_budget_frontier_matrix.py --preflight-only
    python scripts/run_www_budget_frontier_matrix.py --smoke
    python scripts/run_www_budget_frontier_matrix.py

Nothing under results/fixed_index_v1 or results/main_matrix is written.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from run_www_workload_audit_matrix import ROOT, CELLS, PYTHON, checkpoint, profile, sha256

sys.path.insert(0, str(ROOT / "src"))
from pkgea.contracts import dataset_content_digest  # noqa: E402

RESULTS = ROOT / "nodes/04_www_distributional/results/certificate_v1"
SPEC = "papers/www/PER_QUERY_CERTIFICATE_SPEC.md"
# The all-diagonal floor at 1,012 targets and d=16 is about 0.211,
# so 0.3 is reachable and sits much nearer the regime where decisions break.
BUDGETS = (0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)
SMOKE_CELL = ("dw", "relation", "independent")
IMPLEMENTATIONS = (
    "scripts/run_www_fixed_index_audit.py",
    "scripts/www_fixed_index_audit.py",
    "scripts/www_budget_frontier.py",
    "scripts/run_www_equal_budget.py",
    "src/pkgea/www_fsl.py",
    SPEC,
)


def slug(cell):
    return "_".join(cell)


def plan(cells, budgets, smoke=False):
    tasks = []
    for cell in cells:
        graph, family, dependence = cell
        checkpoint_path = checkpoint(graph, family)
        profile_path = profile(graph, dependence)
        if not checkpoint_path.is_file():
            raise RuntimeError(f"missing checkpoint {checkpoint_path}")
        if not profile_path.is_dir():
            raise RuntimeError(f"missing profile {profile_path}")
        output = RESULTS / (f"smoke_{slug(cell)}.json" if smoke
                            else f"{slug(cell)}.json")
        tasks.append({
            "cell": slug(cell),
            "checkpoint": str(checkpoint_path.relative_to(ROOT)).replace("\\", "/"),
            "checkpoint_sha256": sha256(checkpoint_path),
            "profile": str(profile_path.relative_to(ROOT)).replace("\\", "/"),
            "content_digest": dataset_content_digest(profile_path),
            "output": str(output.relative_to(ROOT)).replace("\\", "/"),
            "command": [
                str(PYTHON), "scripts/run_www_fixed_index_audit.py",
                str(output.relative_to(ROOT)),
                "--checkpoint", str(checkpoint_path.relative_to(ROOT)),
                "--profile", str(profile_path.relative_to(ROOT)),
                "--cell", slug(cell),
                "--budget-fractions", *[f"{value:g}" for value in budgets],
                "--certify-queries",
            ],
        })
    return tasks


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--smoke", action="store_true",
                        help="run one cell at two budgets to prove the path end to end")
    parser.add_argument("--budgets", nargs="+", type=float, default=list(BUDGETS))
    args = parser.parse_args()

    budgets = tuple(sorted({round(float(v), 6) for v in args.budgets}))
    cells = [SMOKE_CELL] if args.smoke else list(CELLS)
    if args.smoke:
        budgets = (0.5, 0.8)
    RESULTS.mkdir(parents=True, exist_ok=True)

    tasks = plan(cells, budgets, smoke=args.smoke)
    manifest = {
        "schema_version": "pkgea-www-per-query-certificate-v1",
        "specification": SPEC,
        "budgets": list(budgets),
        "smoke": bool(args.smoke),
        "implementations": {
            path: sha256(ROOT / path) for path in IMPLEMENTATIONS
        },
        "tasks": tasks,
    }
    name = "smoke_manifest.json" if args.smoke else "manifest.json"
    path = RESULTS / name
    if path.exists():
        existing = json.loads(path.read_text(encoding="utf-8"))
        if existing != manifest:
            raise RuntimeError(
                f"{name} differs from the frozen plan; inputs or implementation changed"
            )
    else:
        # newline="\n" to match atomic_write_json, which every result file
        # uses.  Without it Windows writes CRLF here and LF there, so the two
        # halves of one run disagree on line endings for no reason.
        with path.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(manifest, indent=2, sort_keys=True) + "\n")

    print(f"PREFLIGHT PASS: {len(tasks)} cells x {len(budgets)} budgets "
          f"{list(budgets)}", flush=True)
    if args.preflight_only:
        return 0

    for index, task in enumerate(tasks, 1):
        print(f"\n=== [{index}/{len(tasks)}] {task['cell']} ===", flush=True)
        existing = ROOT / task["output"]
        if existing.exists():
            try:
                done = json.loads(existing.read_text(encoding="utf-8"))
                recorded = [round(float(v), 6)
                            for v in done["protocol"]["budget_fractions"]]
            except (ValueError, KeyError) as error:
                raise RuntimeError(
                    f"{task['output']} exists but is not a readable frontier "
                    f"result ({error}); delete it and rerun"
                )
            if recorded == list(budgets):
                print(f"SKIP {task['cell']}: already complete for these budgets",
                      flush=True)
                continue
            raise RuntimeError(
                f"{task['output']} holds budgets {recorded}, not {list(budgets)}. "
                "It is from a different plan -- most likely a smoke run. Delete "
                "that one file and rerun; completed cells are skipped."
            )
        code = subprocess.call(task["command"], cwd=ROOT)
        if code:
            print(f"FAILED {task['cell']} exit={code}", flush=True)
            return code
    print("\nCERTIFICATE RUN COMPLETE" + (" (smoke)" if args.smoke else ""), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except RuntimeError as error:
        # The host has no interactive assistance, so a stop must read as an
        # instruction rather than a traceback.
        print(f"\nSTOP: {error}\n\nNothing was written. Report this line and "
              f"the command you ran; see {SPEC} section 6.", flush=True)
        raise SystemExit(2)
