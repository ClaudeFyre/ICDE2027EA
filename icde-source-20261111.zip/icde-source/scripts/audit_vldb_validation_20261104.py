"""Read-only final integrity checks for the isolated VLDB validation artifacts."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote

try:
    import tomllib
except ImportError:
    from pip._vendor import tomli as tomllib

ROOT = Path(__file__).resolve().parents[1]
V0 = ROOT / "nodes/09_vldb_query_certification/results/v0_20261104_attempt1"
V1 = ROOT / "nodes/09_vldb_query_certification/results/interval_v1_20261104_attempt1"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    def invalid(value: str) -> None:
        raise ValueError(f"non-finite JSON value: {value}")
    return json.loads(path.read_text("utf-8-sig"), parse_constant=invalid)


def run() -> dict:
    failures = []
    checks = []
    for folder in (V0, V1):
        frozen = read(folder / "protocol_freeze.json")
        protocol_path = (ROOT / "configs" / (
            "vldb_validation_v0_20261104.json" if folder == V0
            else "vldb_interval_v1_20261104.json"))
        if digest(protocol_path) != frozen["protocol_sha256"]:
            failures.append(f"protocol_changed:{folder.name}")
        if read(folder / "protocol_snapshot.json") != read(protocol_path):
            failures.append(f"protocol_snapshot_changed:{folder.name}")
        for name, expected in frozen["code_sha256"].items():
            if digest(ROOT / name) != expected:
                failures.append(f"frozen_source_changed:{name}")
        for path in folder.rglob("*.json"):
            read(path)
            checks.append(path.relative_to(ROOT).as_posix())
    capture = read(V0 / "capture_report.json")
    if digest(V0 / "preflight.json") != read(V0 / "protocol_freeze.json")["preflight_sha256"]:
        failures.append("V0_preflight_changed")
    for name, expected in capture["manifests_sha256"].items():
        if digest(ROOT / name) != expected:
            failures.append(f"captured_manifest_changed:{name}")
    gate = read(V1 / "interval_gate.json")
    for specification in gate["raw_event_files"]:
        if digest(ROOT / specification["path"]) != specification["sha256"]:
            failures.append(f"event_evidence_changed:{specification['path']}")
    exact = read(V0 / "exact_validation.json")
    if exact["status"] != "PASS" or exact["summary"]["violations"] or exact["common_shock_validation"]["violations"]:
        failures.append("exact_validation_not_passed")
    if gate["status"] != "V1_EXECUTION_COMPLETE" or not gate["all_original_winner_streams_equal"] or not gate["candidate_outward_pruning_pass"]:
        failures.append("V1_contract_not_passed")
    archive_path = ROOT / "papers/ijcai/archive/paused_20261104/manifest.json"
    archived = read(archive_path)
    for record in archived["files"]:
        snapshot = archive_path.parent / record["snapshot"]
        if digest(snapshot) != record["sha256"]:
            failures.append(f"IJCAI_archive_changed:{record['snapshot']}")
    plan = read(ROOT / "configs/ijcai_research_plan_20261103.json")
    if plan["execution_policy"]["execution_allowed"]:
        failures.append("IJCAI_unexpectedly_resumed")
    for path in list((ROOT / "scripts").glob("*vldb*.py")) + list((ROOT / "tests").glob("test_vldb*.py")):
        ast.parse(path.read_text("utf-8-sig"), filename=str(path))
    with (ROOT / "nodes/09_vldb_query_certification/status.toml").open("rb") as handle:
        tomllib.load(handle)
    docs = list((ROOT / "papers/vldb").glob("*.md"))
    docs += [ROOT / "nodes/09_vldb_query_certification/README.md"]
    for path in docs:
        for target in re.findall(r"\]\(([^)]+)\)", path.read_text("utf-8-sig")):
            if target.startswith(("http:", "https:", "#", "mailto:")):
                continue
            name = unquote(target.split("#", 1)[0].strip("<>"))
            if not (path.parent / name).exists():
                failures.append(f"missing_local_link:{path.relative_to(ROOT)}:{name}")
    result = {
        "status": "PASS" if not failures else "FAIL",
        "failures": failures, "result_json_files_parsed": len(checks),
        "frozen_code_and_protocol_identities_checked": True,
        "V1_raw_event_files_checked": len(gate["raw_event_files"]),
        "node_status_toml_parsed": True,
        "IJCAI_archived_files_checked": len(archived["files"]),
        "IJCAI_research_remains_paused": not plan["execution_policy"]["execution_allowed"],
        "V0_exact_status": read(V0 / "exact_validation.json")["status"],
        "V0_capture_status": capture["status"],
        "V0_replay_status": read(V0 / "real_stream_frontier.json")["status"],
        "V1_gate_status": read(V1 / "interval_gate.json")["status"],
        "checks_establish_scientific_novelty": False,
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    arguments = parser.parse_args()
    result = run()
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    with arguments.output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
    print(json.dumps(result, ensure_ascii=True))
    raise SystemExit(0 if result["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
