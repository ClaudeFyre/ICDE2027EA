"""Audit saved WSDM streams and replay explicitly frozen categorical streams.

No scorer, model, sampler, or synthetic stream generator is called here.
Legacy scale-500 summaries do not persist ordered winners and therefore cannot
replay a new stopping rule.  Finite-reference gaps are never used as bounds.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path


SCHEMA = "vldb-stream-frontier-v0"
STREAM_SCHEMA = "vldb-categorical-stream-v1"
DEFAULT_EPSILONS = (0.0, 0.001, 0.005, 0.01, 0.025, 0.05)
DEFAULT_TAUS = (1e-7, 1e-6, 1e-5, 1e-4, 1e-3)
BETTING_FRACTIONS = tuple(2.0 ** (-power) for power in range(1, 11))
CANONICAL_FILES = (
    "entities.tsv", "relations.tsv", "triples.tsv", "alignments.tsv",
    "attributes.tsv", "confidence_metadata.json",
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_digest(value: object) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _has_saved_winner_sequence(value: object) -> bool:
    sequence_keys = {"winner_indices", "winner_sequence", "winner_sequences", "winner_streams", "streams"}
    stack = [value]
    while stack:
        item = stack.pop()
        if isinstance(item, dict):
            if any(key in sequence_keys and isinstance(content, (dict, list)) for key, content in item.items()):
                return True
            stack.extend(content for content in item.values() if isinstance(content, (dict, list)))
        elif isinstance(item, list):
            stack.extend(content for content in item if isinstance(content, (dict, list)))
    return False


def dataset_revision(path: Path) -> str:
    """Same opaque canonical-file digest as pkgea.contracts, without model imports."""
    digest = hashlib.sha256(b"pkgea-dataset-revision-v1\0")
    for name in CANONICAL_FILES:
        source = path / name
        if not source.is_file():
            continue
        digest.update(name.encode())
        digest.update(b"\0")
        with source.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        digest.update(b"\0")
    return digest.hexdigest()


def _relative_path(root: Path, value: str) -> Path:
    path = Path(value.replace("\\", "/"))
    if path.is_absolute() or ":" in str(path):
        raise ValueError("input paths must be repository-relative")
    resolved = (root / path).resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError("input path escapes repository root")
    return resolved


def independent_product_tv_bound(tau: float, variable_count: int) -> float:
    """Coupling upper bound under independent Bernoulli laws in both models.

    tau is an assumed uniform coordinate |dp| bound, not estimated ECE.
    """
    if not math.isfinite(tau) or not 0 <= tau <= 1:
        raise ValueError("tau must be finite and in [0, 1]")
    if isinstance(variable_count, bool) or not isinstance(variable_count, int) or variable_count < 0:
        raise ValueError("variable_count must be a nonnegative integer")
    if variable_count == 0 or tau == 0:
        return 0.0
    if tau == 1:
        return 1.0
    return min(1.0, max(0.0, -math.expm1(variable_count * math.log1p(-tau))))


def normal_radius(n: int, alpha: float, rho: float) -> float:
    if n <= 0 or not 0 < alpha < 1 or not math.isfinite(rho) or rho <= 0:
        raise ValueError("invalid normal-mixture parameters")
    return math.sqrt((n + rho) * math.log((n + rho) / (rho * alpha * alpha))) / n


def _betting_log_evalue(leader_count: int, competitor_count: int) -> float:
    values = [
        leader_count * math.log1p(fraction) + competitor_count * math.log1p(-fraction)
        for fraction in BETTING_FRACTIONS
    ]
    maximum = max(values)
    return maximum + math.log(sum(math.exp(value - maximum) for value in values) / len(values))


def _settings(config: dict) -> dict:
    settings = config.get("stream_frontier", config)
    delta = float(settings.get("delta", 0.05))
    rho = float(settings.get("rho", 64.0))
    minimum = int(settings.get("minimum_samples", 32))
    interval = int(settings.get("check_every", 64))
    union = settings.get("union_bound", "all_pairs")
    epsilon = tuple(float(value) for value in settings.get("epsilon_grid", DEFAULT_EPSILONS))
    tau = tuple(float(value) for value in settings.get("tau_grid", DEFAULT_TAUS))
    if not 0 < delta < 1 or not math.isfinite(rho) or rho <= 0 or minimum <= 0 or interval <= 0:
        raise ValueError("invalid stream frontier configuration")
    if union not in ("all_pairs", "winner_pairs"):
        raise ValueError("unsupported pairwise union bound")
    if not epsilon or any(not math.isfinite(value) or not 0 <= value <= 1 for value in epsilon):
        raise ValueError("invalid epsilon grid")
    if len(set(epsilon)) != len(epsilon) or 0.0 not in epsilon:
        raise ValueError("epsilon grid must include zero without duplicates")
    if not tau or len(set(tau)) != len(tau) or any(not math.isfinite(value) or not 0 <= value <= 1 for value in tau):
        raise ValueError("invalid tau grid")
    return {
        **settings, "delta": delta, "rho": rho, "minimum_samples": minimum,
        "check_every": interval, "union_bound": union,
        "epsilon_grid": epsilon, "tau_grid": tau,
    }


def replay_query(query: dict, full_edge_count: int, settings: dict, *, independent: bool) -> dict:
    """Replay a saved ordered sequence under fixed per-query caps/check times."""
    candidates = query["candidate_ids"]
    stream = query["winner_indices"]
    m = query["scope_edge_count"]
    if not candidates or len(set(candidates)) != len(candidates):
        raise ValueError("candidate identities must be nonempty and unique")
    if not stream or any(isinstance(value, bool) or not isinstance(value, int) or not 0 <= value < len(candidates) for value in stream):
        raise ValueError("winner stream must contain ordered candidate indices")
    if isinstance(m, bool) or not isinstance(m, int) or not 0 <= m <= full_edge_count:
        raise ValueError("invalid exact scope size")
    if full_edge_count < 1:
        raise ValueError("full graph must contain at least one edge")
    cap = min(len(stream), int(settings.get("max_samples_per_query", len(stream))))
    if cap < settings["minimum_samples"]:
        raise ValueError("saved stream is shorter than minimum_samples")
    checkpoints = list(range(settings["minimum_samples"], cap + 1, settings["check_every"]))
    if checkpoints[-1] != cap:
        checkpoints.append(cap)
    k = len(candidates)
    if settings["union_bound"] == "winner_pairs":
        normal_divisor = betting_divisor = max(k - 1, 1)
    else:
        normal_divisor = max(k * (k - 1) // 2, 1)
        betting_divisor = max(k * (k - 1), 1)
    normal_alpha = settings["delta"] / normal_divisor
    betting_alpha = settings["delta"] / betting_divisor
    scenarios = [("epsilon", float(value), float(value)) for value in settings["epsilon_grid"]]
    if independent:
        for tau in settings["tau_grid"]:
            scenarios.append(("tau_scope", float(tau), independent_product_tv_bound(tau, m)))
            scenarios.append(("tau_full_bound_same_budget", float(tau), independent_product_tv_bound(tau, full_edge_count)))
    first = {i: None for i in range(len(scenarios))}
    betting_first = None
    counts = [0] * k
    offset = 0
    final_lower = None
    for stop in checkpoints:
        for winner in stream[offset:stop]:
            counts[winner] += 1
        offset = stop
        leader = max(range(k), key=lambda index: (counts[index], -index))
        competitor_count = max((counts[index] for index in range(k) if index != leader), default=0)
        gap = (counts[leader] - competitor_count) / stop
        lower = 1.0 if k == 1 else max(-1.0, gap - normal_radius(stop, normal_alpha, settings["rho"]))
        final_lower = lower
        for index, (_, _, epsilon) in enumerate(scenarios):
            if first[index] is None and (k == 1 or lower > 2 * epsilon):
                first[index] = {"samples": stop, "winner_column": leader, "lower_gap": lower}
        if betting_first is None and (k == 1 or _betting_log_evalue(counts[leader], competitor_count) >= math.log(1 / betting_alpha)):
            betting_first = {"samples": stop, "winner_column": leader}
    rows = []
    for index, (kind, value, epsilon) in enumerate(scenarios):
        result = first[index]
        used = result["samples"] if result else cap
        rows.append({
            "scenario": kind, "value": value, "assumed_tv_epsilon": epsilon,
            "stable": result is not None, "samples_used": used,
            "certified_winner_column": result["winner_column"] if result else None,
            "lower_gap_at_stop": result["lower_gap"] if result else None,
            "logical_scope_edge_cost": used * max(1, m),
            "full_execution_edge_cost_diagnostic": used * full_edge_count,
        })
    betting_used = betting_first["samples"] if betting_first else cap
    return {
        "query_id": query["query_id"], "candidate_count": k,
        "scope_edge_count": m, "world_cap": cap,
        "normal_pair_alpha": normal_alpha, "betting_pair_alpha": betting_alpha,
        "normal_mixture_frontier": rows,
        "nominal_betting": {
            "stable": betting_first is not None, "samples_used": betting_used,
            "certified_winner_column": betting_first["winner_column"] if betting_first else None,
            "logical_scope_edge_cost": betting_used * max(1, m),
        },
        "final_normal_lower_gap": final_lower,
        "final_certified_tv_radius_supremum": final_lower / 2 if final_lower > 0 else None,
        "radius_boundary_is_strict": True,
    }


def _verify_scope(query: dict, manifest: dict) -> None:
    certificate = query["scope_certificate"]
    payload = {key: value for key, value in certificate.items() if key != "certificate_sha256"}
    if _json_digest(payload) != certificate.get("certificate_sha256"):
        raise ValueError("scope certificate digest mismatch")
    if not certificate.get("exact") or certificate.get("dataset_revision") != manifest["dataset_revision"]:
        raise ValueError("scope certificate is not exact or belongs to a different dataset")
    if str(certificate.get("query_id")) != str(query["query_id"]):
        raise ValueError("scope certificate query identity mismatch")
    if certificate.get("candidate_set_sha256") != _json_digest([str(value) for value in query["candidate_ids"]]):
        raise ValueError("scope certificate candidate order mismatch")
    if certificate.get("scorer_id") != manifest["scorer"]["id"] or certificate.get("scorer_version") != manifest["scorer"]["version"]:
        raise ValueError("scope certificate scorer identity mismatch")
    if certificate.get("checkpoint_sha256") != manifest["scorer"].get("checkpoint_sha256"):
        raise ValueError("scope certificate checkpoint identity mismatch")
    edges = certificate.get("edge_ids", [])
    variables = certificate.get("edge_variable_ids", [])
    if len(set(edges)) != len(edges) or len(set(variables)) != len(variables):
        raise ValueError("scope certificate identities must be unique")
    if len(edges) != query["scope_edge_count"]:
        raise ValueError("scope size is not the saved certificate's edge count")
    if manifest["world_law"]["dependence"] == "independent" and len(variables) != len(edges):
        raise ValueError("independent tau conversion requires one variable per scope edge")


def replay_manifest(specification: dict, root: Path, settings: dict) -> dict:
    path = _relative_path(root, specification["path"])
    observed = file_sha256(path)
    if observed != specification.get("sha256"):
        raise ValueError("stream manifest is not bound to its frozen SHA-256")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != STREAM_SCHEMA:
        raise ValueError("unsupported categorical stream schema")
    dataset = _relative_path(root, manifest["dataset_path"])
    if dataset_revision(dataset) != manifest["dataset_revision"]:
        raise ValueError("stream dataset revision mismatch")
    with (dataset / "triples.tsv").open(encoding="utf-8-sig", newline="") as handle:
        edge_count = sum(1 for _ in csv.DictReader(handle, delimiter="\t"))
    if edge_count != manifest["full_edge_count"]:
        raise ValueError("full graph edge count mismatch")
    if manifest["world_law"].get("semantics") != "declared":
        raise ValueError("world law must be explicitly declared, not claimed validated from ECE")
    queries = manifest["queries"]
    if not queries or len({str(query["query_id"]) for query in queries}) != len(queries):
        raise ValueError("query identities must be nonempty and unique")
    independent = manifest["world_law"]["dependence"] == "independent"
    rows = []
    for query in queries:
        _verify_scope(query, manifest)
        rows.append(replay_query(query, edge_count, settings, independent=independent))
    template = rows[0]["normal_mixture_frontier"]
    aggregate = []
    for index, scenario in enumerate(template):
        selected = [row["normal_mixture_frontier"][index] for row in rows]
        aggregate.append({
            "scenario": scenario["scenario"], "value": scenario["value"],
            "stable_count": sum(row["stable"] for row in selected),
            "coverage": sum(row["stable"] for row in selected) / len(rows),
            "worlds_used": sum(row["samples_used"] for row in selected),
            "logical_scope_edge_cost": sum(row["logical_scope_edge_cost"] for row in selected),
        })
    return {
        "stream_path": specification["path"], "stream_sha256": observed,
        "dataset_revision_verified": True, "query_count": len(rows),
        "world_law": manifest["world_law"], "frontier": aggregate,
        "nominal_betting": {
            "coverage": sum(row["nominal_betting"]["stable"] for row in rows) / len(rows),
            "worlds_used": sum(row["nominal_betting"]["samples_used"] for row in rows),
            "logical_scope_edge_cost": sum(row["nominal_betting"]["logical_scope_edge_cost"] for row in rows),
        },
        "queries": rows,
        "tau_conversion_status": "independent_product_model_only" if independent else "not_applicable_to_correlated_edges",
        "cost_contract": "Same per-query world cap and inspection times; full-bound comparison changes epsilon only, retaining the same local cost model. Not a replay of the frozen global scheduler.",
        "robust_betting_status": "not_implemented; nominal e-values are not numerical gap lower bounds",
    }


def _audit_legacy(root: Path, settings: dict) -> dict:
    profile_path = _relative_path(root, settings.get("profile_config", "nodes/03_wsdm/configs/scale500_datasets.json"))
    profiles = json.loads(profile_path.read_text(encoding="utf-8"))
    profile_sha = file_sha256(profile_path)
    dataset_checks = []
    identities = {}
    for profile in profiles["profiles"]:
        for label, key in (("independent", "independent"), ("shared-latent", "shared")):
            dataset = _relative_path(root, profile[key])
            actual = dataset_revision(dataset)
            expected = profile["dataset_revisions"][key]
            verified = actual == expected
            identities[(profile["graph"], label)] = expected
            dataset_checks.append({
                "graph": profile["graph"], "dependence_profile": label,
                "path": profile[key], "recorded_revision": expected,
                "observed_revision": actual, "verified": verified,
            })
    result_root = root / "nodes/03_wsdm/results"
    partials = sorted((result_root / "scale500_crn/partial_runs").glob("*.json"))
    run_checks = []
    for path in partials:
        saved = json.loads(path.read_text(encoding="utf-8"))
        run = saved["run"]
        expected = identities.get((run["graph"], run["dependence_profile"]))
        contract_ok = _json_digest(saved["contract"]) == saved["contract_sha256"]
        profile_ok = saved["contract"]["profile_config_sha256"] == profile_sha
        run_checks.append({
            "path": path.relative_to(root).as_posix(), "sha256": file_sha256(path),
            "graph": run["graph"], "scorer": run["scorer"],
            "dependence_profile": run["dependence_profile"], "mc_seed": run["mc_seed"],
            "training_seed": run["training_seed"], "query_count": run["query_count"],
            "full_edges": run["full_edges"], "mean_scope_edges": run["mean_scope_edges"],
            "mean_candidate_count": run["candidate_count_mean"],
            "dataset_revision_matches_profile": run["dataset_revision"] == expected,
            "contract_digest_verified": contract_ok, "profile_config_sha256_verified": profile_ok,
            "saved_ordered_winner_stream": _has_saved_winner_sequence(run),
            "saved_per_query_scope_sizes": False,
            "saved_per_query_candidate_order": False,
            "world_state_hash_is_not_a_winner_stream": True,
            "nominal_schedule_summary_count": len(run["schedule_runs"]),
        })
    summary_checks = []
    summary_paths = (
        result_root / "scale500_attribute/real_attribute_frontier.json",
        result_root / "scale500_evidence/scale500_evidence.json",
    )
    expected_hashes = settings.get("summary_sha256", {})
    for path in summary_paths:
        payload = json.loads(path.read_text(encoding="utf-8"))
        relative = path.relative_to(root).as_posix()
        observed = file_sha256(path)
        expected = expected_hashes.get(relative)
        summary_checks.append({
            "path": relative, "sha256": observed, "schema_version": payload.get("schema_version"),
            "current_config_expected_sha256": expected,
            "current_config_sha256_verified": observed == expected if expected else None,
            "saved_ordered_winner_stream": _has_saved_winner_sequence(payload),
        })
    checked = bool(run_checks) and all(item["verified"] for item in dataset_checks)
    checked = checked and all(
        item["dataset_revision_matches_profile"] and item["contract_digest_verified"] and item["profile_config_sha256_verified"]
        for item in run_checks
    )
    checked = checked and all(item["current_config_sha256_verified"] is not False for item in summary_checks)
    inventory = []
    for name in ("scale500_crn", "scale500_attribute", "scale500_evidence"):
        directory = result_root / name
        files = sorted(path for path in directory.rglob("*") if path.is_file())
        inventory.append({
            "directory": directory.relative_to(root).as_posix(), "file_count": len(files),
            "potential_binary_or_line_stream_files": [
                path.relative_to(root).as_posix() for path in files
                if path.suffix.lower() in (".npz", ".npy", ".jsonl")
            ],
        })
    return {
        "profile_config_sha256": profile_sha, "dataset_checks": dataset_checks,
        "crn_partial_run_checks": run_checks, "summary_checks": summary_checks,
        "legacy_directory_inventory": inventory,
        "dataset_and_crn_contract_identity_verified": checked,
        "reference_gaps_used_as_confidence_bounds": False,
        "interpretation": "Hashes establish observed identities, not persistence of unsaved streams or truth of the declared world law.",
    }


def run_stream_frontier(config: dict, root: str | Path) -> dict:
    root = Path(root).resolve()
    settings = _settings(config)
    legacy = _audit_legacy(root, settings)
    specifications = settings.get("stream_manifests", [])
    if not specifications:
        return {
            "schema_version": SCHEMA, "status": "not_replayable",
            "legacy_input_audit": legacy, "frontiers": [],
            "reason": "Legacy scale-500 artifacts contain schedule summaries, sample counts, finite-reference gaps, and hashes; ordered winner streams, exact per-query scopes, and candidate orders were not persisted.",
            "required_stream_schema": STREAM_SCHEMA,
            "nominal_cs_replayed": False, "robust_cs_replayed": False,
            "new_worlds_generated": 0, "models_loaded": 0,
        }
    if not legacy["dataset_and_crn_contract_identity_verified"]:
        raise ValueError("legacy data identity checks failed before stream replay")
    frontiers = [replay_manifest(specification, root, settings) for specification in specifications]
    return {
        "schema_version": SCHEMA, "status": "replayed_explicit_saved_streams",
        "legacy_input_audit": legacy, "frontiers": frontiers,
        "new_worlds_generated": 0, "models_loaded": 0,
        "guarantee_scope": "Conditional on declared i.i.d. world sampling, fixed scorer/candidates/ties, exact dependency scopes and assumed TV bounds; no real-world probability calibration is established.",
    }
