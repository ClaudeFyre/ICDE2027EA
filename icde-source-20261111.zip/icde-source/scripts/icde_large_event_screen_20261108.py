"""All 259 prototype-excluded queries, bounded standard-control feasibility screen.

No new algorithm claim. The factor control reuses existing standard interval
sum-product/count+parameter refinement, admitting large S without joint arrays.
Dense coefficient/local probability tables still have explicit admission caps.
"""
import argparse
from collections import Counter
from fractions import Fraction as Q
import math
from pathlib import Path
import time
import numpy as np

import icde_prospective_20261107 as old
import icde_factor_partial_20261108 as factor
from icde_grouped_inventory_20261108 import ROOT,load,save,sha,identities
from icde_portfolio_budget_20261108 import budgeted_call,REAL_COUNTER
from run_vldb_interval_gate_v1 import clipped_box

PARENT=ROOT/'nodes/09_vldb_query_certification/results/icde_pair_event_tightness_20261108/attempt1'
STATIC=ROOT/'nodes/09_vldb_query_certification/results/icde_parameter_association_20261108/attempt1/static_diagnosis.json'
BASE=ROOT/'nodes/09_vldb_query_certification/results/icde_large_event_screen_20261108/attempt1'
POLICIES=('direct_transport','generic_eager','factor_event')
ORIGINAL_FACTOR_BOUNDS=factor.probability_bounds


def admission(case):
    k,g=case['retained_candidates'],case['reconstructed_group_count']
    hist={int(n):v for n,v in case['group_size_histogram'].items()}
    local_bytes=sum(v*(n+1)*(n+2)*(64+7*n) for n,v in hist.items())
    reasons=[]
    if k>256:reasons.append('K_gt256')
    if g*2*k>1000000:reasons.append('dense_coefficient_entries_gt1000000')
    if max(hist)>64:reasons.append('maximum_group_gt64')
    if local_bytes>128*1024**2:reasons.append('estimated_local_table_bytes_gt128MiB')
    return {'admitted':not reasons,'reasons':reasons,'estimated_local_table_bytes':local_bytes,
            'dense_coefficient_entries':g*2*k}


def down(value):
    result=float(value)
    return math.nextafter(result,-math.inf) if Q.from_float(result)>value else result


def up(value):
    result=float(value)
    return math.nextafter(result,math.inf) if Q.from_float(result)<value else result


def event_gap_interval(cells,winner,denominator):
    low=[];high=[]
    for lower,upper in cells:
        competitors=[d for d in range(len(lower)) if d!=winner]
        low.append(lower[winner]-max(upper[d] for d in competitors))
        high.append(upper[winner]-max(lower[d] for d in competitors))
    a,b=Q(min(low),denominator),Q(min(high),denominator)
    if not -1<=a<=b<=1:raise AssertionError('invalid robust-gap enclosure')
    return {'lower_gap':down(a),'upper_gap':up(b),'lower_gap_exact':str(a),'upper_gap_exact':str(b)}


def freeze(out):
    if out.exists():raise FileExistsError(out)
    parent=load(PARENT/'protocol.json')
    cases=[r for r in load(STATIC)['rows'] if r['retained_candidates']>1 and not r['prototype_eligible']]
    if len(cases)!=259:raise AssertionError('static selection changed')
    code=dict(parent['code_sha256'])
    for name in ('icde_large_event_screen_20261108.py','test_icde_large_event_screen_20261108.py'):
        code['scripts/'+name]=sha(ROOT/'scripts'/name)
    inputs=dict(parent['input_sha256'])
    for path in (PARENT/'summary.json',STATIC):inputs[path.relative_to(ROOT).as_posix()]=sha(path)
    save(out/'protocol.json',{'kind':'historical_all_259_standard_scalable_control_screen',
        'cases':cases,'policies':list(POLICIES),'nominal':.9,'tau':.25,'seed':1063,'repeats':1,
        'budget_seconds':.2,'max_splits':127,'max_parameter_splits':31,
        'comparison':'strong mixture+all deterministic transports, generic paid event MC, existing standard factorized event relaxation; no new method or published full-system comparison',
        'factor_admission':{ 'K_max':256,'dense_coefficient_entries_max':1000000,
                             'max_group_size':64,'estimated_local_table_bytes_max':134217728},
        'factor_state_limit':'actual S used only as integer admission bound; factor control never allocates joint S arrays',
        'focus_candidate':'winner on the all-present world, paid inside every method; any robust answer must equal it because p=1 is in the family',
        'common_frontend':'all-present score and global outward all-world interval; both paid by every method',
        'method_order':'rotate by query index','warmup':'all three methods once on known ENFR q175; separate from query counts',
        'timing':'prepared kernel loading measured once and excluded from per-method budget; all method-specific setup/admission included; cooperative soft cap, late results discarded',
        'intervals':'worst pair gap of the same focus candidate. Completed factor cells yield deterministic intervals; completed MC gives a protected lower bound and upper=1; missing/late states use [-1,1]',
        'risk':'direct_transport .05, generic_eager .025+.025 per query/run; factor deterministic; no workload-wide .05 claim',
        'reference':'19 structurally selected exact frontier queries from prior phase, never passed to solvers; other 240 have unknown truth',
        'limitations':['one timing observation per query; development screen only','resource-not-admitted rows retained in all-259 denominator',
                       'standard factorized bounds are not a faithful reproduction of Wijk CUBmax or other full credal software',
                       'no claim that exact methods must enumerate all parameter vertices or fail on all 259'],
        'code_sha256':code,'input_sha256':inputs,'frozen_at_unix':time.time()})
    print('Frozen 259 x 3 standard controls, 200ms cooperative cap, one run each',flush=True)


def preflight(out):
    p=load(out/'protocol.json');checks=identities(p,False)
    if (out/'summary.json').exists() or (out/'cases').exists():raise FileExistsError('new attempt required')
    save(out/'recovery.json',{'status':'PASS','checks':checks})
    print('Preflight PASS',checks,flush=True)


def execute(kernel,meta,case,policy,p):
    m=len(kernel.edge_indices)
    focus=int(np.argmax(kernel.scores(np.ones((1,m),dtype=np.bool_))[0]))
    lower,upper=kernel.score_intervals(np.zeros((1,m),dtype=np.bool_),np.ones((1,m),dtype=np.bool_))
    competitors=upper[0].copy();competitors[focus]=-np.inf
    if lower[0,focus]>np.max(competitors):
        return {'status':'stable','winner':focus,'focus':focus,'kind':'common_all_world_interval',
                'lower_gap':1.,'upper_gap':1.}
    if policy=='factor_event':
        allowed=admission(case)
        if not allowed['admitted']:
            return {'status':'resource_not_admitted','winner':None,'focus':focus,
                    'kind':'factor_admission','admission':allowed,'lower_gap':-1.,'upper_gap':1.}
        low,high=clipped_box(np.full(m,p['nominal']),p['tau'])
        snapshots={}
        def observed(regions,plow,phigh,k,den):
            result=ORIGINAL_FACTOR_BOUNDS(regions,plow,phigh,k,den)
            snapshots[tuple(plow),tuple(phigh)]=result
            return result
        previous=factor.probability_bounds
        try:
            factor.probability_bounds=observed
            settings={**p,'state_cap':case['count_states_exact']}
            raw=factor.execute(kernel,low,high,'factor_mass',settings)
        finally:
            factor.probability_bounds=previous
        if raw['kind']=='common_root_bound':
            interval={'lower_gap':1.,'upper_gap':1.}
        else:
            cells=[snapshots[tuple(c['low']),tuple(c['high'])] for c in raw['parameter_cells']]
            interval=event_gap_interval(cells,focus,int(raw['denominator_exact']))
        return {**raw,**interval,'focus':focus,'admission':allowed,
                'leaf_records':raw.get('leaf_records',[]),'parameter_cells':raw.get('parameter_cells',[])}
    raw=old.execute_case(kernel,meta,p['tau'],p['seed'],'eager' if policy=='generic_eager' else 'cheap')
    counts=raw['winner_counts'];leader=int(np.argmax(counts))
    lower=-1.
    if leader==focus:
        lower=raw['deterministic_gap']
        if policy=='generic_eager' and raw['event_worlds']:
            paid=math.nextafter(raw['nominal_gap']-math.nextafter(2*raw['event_upper'],math.inf),-math.inf)
            lower=max(lower,paid)
    return {**raw,'native_status':raw['status'],'kind':policy,
            'status':'stable' if raw['certified'] else 'unresolved',
            'winner':kernel.candidates.index(raw['candidate']) if raw['certified'] else None,
            'focus':focus,'lower_gap':max(-1.,lower),'upper_gap':1.}


def run(out):
    p=load(out/'protocol.json')
    if load(out/'recovery.json')['status']!='PASS':raise AssertionError('preflight required')
    checks=identities(p,False);rows=[];loading=[]
    references={(r['graph'],r['rank']):r for r in load(PARENT/'summary.json')['rows'] if r['role']=='frontier'}
    warm_case=next(r for r in load(STATIC)['rows'] if r['graph']=='enfr' and r['rank']==175)
    kernel,meta=old.read_query('enfr',175);warm=[]
    for policy in POLICIES:
        result=budgeted_call(lambda:execute(kernel,meta,warm_case,policy,p),p['budget_seconds'])
        result.pop('raw');warm.append({'policy':policy,**result})
    save(out/'warmup.json',warm)
    for index,case in enumerate(p['cases']):
        before=REAL_COUNTER();kernel,meta=old.read_query(case['graph'],case['rank'])
        loading.append({'graph':case['graph'],'rank':case['rank'],'seconds':REAL_COUNTER()-before})
        offset=index%len(POLICIES)
        for policy in POLICIES[offset:]+POLICIES[:offset]:
            result=budgeted_call(lambda:execute(kernel,meta,case,policy,p),p['budget_seconds'])
            raw=result.pop('raw')
            if time.perf_counter is not REAL_COUNTER or factor.probability_bounds is not ORIGINAL_FACTOR_BOUNDS:
                raise AssertionError('instrumentation not restored')
            if raw is None:
                raw={'status':'timeout','winner':None,'focus':None,'lower_gap':-1.,'upper_gap':1.,'kind':'timeout'}
            reference=references.get((case['graph'],case['rank']))
            audit='reference_unknown'
            if reference:
                if raw['status']=='stable' and raw['winner'] not in reference['uniform_winners']:
                    raise AssertionError('issued certificate disagrees with exact reference')
                if raw['status']=='nonuniform' and reference['uniform_winners']:
                    raise AssertionError('nonuniform proof contradicts exact reference')
                if raw['focus'] is not None:
                    true=min(Q(r['pair_gap_exact']) for r in reference['pairs'] if r['candidate']==raw['focus'])
                    valid=Q.from_float(raw['lower_gap'])<=true<=Q.from_float(raw['upper_gap'])
                    if policy=='factor_event' and not valid:raise AssertionError('deterministic interval misses exact gap')
                    audit='reference_interval_consistent' if valid else 'observed_statistical_interval_failure'
                else:audit='reference_available_no_evidence'
            details={k:v for k,v in raw.items() if k not in ('trace','divergence_bounds','leaf_records','parameter_cells','compute_seconds')}
            row={'graph':case['graph'],'rank':case['rank'],'query_id':case['query_id'],'policy':policy,
                 'K':case['retained_candidates'],'G':case['reconstructed_group_count'],
                 'scope_edges':case['scope_edges'],'count_state_log2':case['reconstructed_count_state_log2'],
                 **result,'details':details,'reference_audit':audit}
            save(out/'cases'/f"{case['graph']}_q{case['rank']:03d}_{policy}.json",row)
            rows.append(row);checks+=1
        if (index+1)%10==0 or index+1==len(p['cases']):
            print(f'Completed {index+1}/259, {len(rows)} method runs',flush=True)
    checks+=identities(p,False)
    aggregates={}
    for policy in POLICIES:
        selected=[r for r in rows if r['policy']==policy]
        aggregates[policy]={'queries':len(selected),'statuses':dict(Counter(r['details']['status'] for r in selected)),
              'actual_compute_seconds':sum(r['compute_seconds'] for r in selected),
              'max_overrun_seconds':max(r['overrun_seconds'] for r in selected),
              'mean_gap_interval_width':float(np.mean([r['details']['upper_gap']-r['details']['lower_gap'] for r in selected])),
              'reference_cases':sum((r['graph'],r['rank']) in references for r in selected),
              'reference_stable_delivered':sum(r['details']['status']=='stable' and (r['graph'],r['rank']) in references for r in selected),
              'reference_audits':dict(Counter(r['reference_audit'] for r in selected))}
    save(out/'summary.json',{'status':'PASS','checks':checks,'protocol_sha256':sha(out/'protocol.json'),
         'aggregates':aggregates,'rows':rows,'loading':loading,'reference_queries':19,
         'unknown_reference_queries':240,'historical_inputs_unchanged':True})
    print(aggregates,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=('freeze','preflight','run'),required=True)
    parser.add_argument('--output',type=Path,default=BASE);args=parser.parse_args()
    {'freeze':freeze,'preflight':preflight,'run':run}[args.phase](args.output.resolve())
