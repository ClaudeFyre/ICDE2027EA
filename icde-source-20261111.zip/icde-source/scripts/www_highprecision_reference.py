"""60-digit Wasserstein-2 references for the E1 stress families (mpmath only).

The identity used is
``W2^2 = |m1-m2|^2 + tr(S1) + tr(S2) - 2 * sum(sqrt(l_i))`` where ``l_i`` are
the eigenvalues of ``S1 @ S2`` (same spectrum as ``S2^(1/2) S1 S2^(1/2)``).
All arithmetic stays scalar mpmath at 60 digits; no matrix square root is
iterated, so there is no uncontrolled convergence path.  scipy is never
imported: the compute environment's scipy is unusable and everything needed
here is closed-form.

This reference is a diagnostic for near-boundary stress inputs.  The primary
comparison target of E1 remains the frozen numeric full-FP32 index; the
high-precision winner is only consulted where its margin is large enough to
be defined.
"""

from __future__ import annotations

import mpmath as mp

DIGITS = 60
IMAG_TOL = mp.mpf(10) ** -40


class ReferenceError(RuntimeError):
    """The high-precision reference is undefined for this input."""


def _mpf(x) -> mp.mpf:
    # repr() of a float is the shortest round-trip decimal, so the exact
    # float64 value -- not a prettified one -- enters the 60-digit domain.
    return mp.mpf(repr(float(x)))


def _matrix(values) -> mp.matrix:
    rows, cols = len(values), len(values[0])
    return mp.matrix([[mp.mpf(0) for _ in range(cols)] for _ in range(rows)])


def _fill(target: mp.matrix, values) -> None:
    for i, row in enumerate(values):
        for j, value in enumerate(row):
            target[i, j] = _mpf(value)


def _trace(matrix: mp.matrix) -> mp.mpf:
    return sum((matrix[i, i] for i in range(matrix.rows)), mp.mpf(0))


def w2_squared(mean_a, cov_a, mean_b, cov_b) -> mp.mpf:
    """W2 squared between two Gaussians given as nested float lists.

    Inputs are taken at their exact float64 values; the result is the exact
    mathematical W2^2 of those float64-representable Gaussians.
    """

    with mp.workdps(DIGITS):
        size = len(mean_a)
        sa = _matrix(cov_a)
        sb = _matrix(cov_b)
        _fill(sa, cov_a)
        _fill(sb, cov_b)
        eigenvalues, _ = mp.eig(sa * sb)
        roots = mp.mpf(0)
        for value in eigenvalues:
            if abs(value.imag) > IMAG_TOL:
                raise ReferenceError(
                    f"complex eigenvalue {value}: input outside the PSD domain")
            roots += mp.sqrt(max(value.real, mp.mpf(0)))
        dm = sum((_mpf(mean_a[i] - mean_b[i]) ** 2 for i in range(size)), mp.mpf(0))
        return dm + _trace(sa) + _trace(sb) - 2 * roots


def w2(mean_a, cov_a, mean_b, cov_b) -> mp.mpf:
    with mp.workdps(DIGITS):
        return mp.sqrt(max(w2_squared(mean_a, cov_a, mean_b, cov_b), mp.mpf(0)))


def reference_winner(query_mean, query_covariance, target_means, target_covariances,
                     *, margin_threshold=None):
    """Exact-domain argmin over targets in the given (frozen) candidate order.

    Returns ``(winner_or_None, gap, distances)``.  ``winner`` is None when the
    best/runner-up gap does not exceed ``margin_threshold``; callers must not
    claim a high-precision winner for defined-margin-excluded ties.
    """

    with mp.workdps(DIGITS):
        distances = [w2(query_mean, query_covariance, mean, covariance)
                     for mean, covariance in zip(target_means, target_covariances)]
        order = sorted(range(len(distances)), key=lambda index: (distances[index], index))
        best = int(order[0])
        gap = (distances[order[1]] - distances[order[0]] if len(order) > 1
               else mp.mpf(0))
        if margin_threshold is not None and gap <= margin_threshold:
            return None, gap, distances
        return best, gap, distances
