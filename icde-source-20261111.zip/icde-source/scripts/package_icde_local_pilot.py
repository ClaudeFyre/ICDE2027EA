"""Build/verify a whitelist-only pilot bundle; omit corpora, weights and SQLite."""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = [
    "RESEARCH_PLAN_20261009.md",
    "query_contract_v1.md",
    "ownership_v1.md",
    "trace_schema_v1.md",
    "OAEI_DATA_CARDS_PILOT_20261009.md",
    "LOCAL_VALIDATION_20261009.md",
    "HANDOFF_4090D_20261009.md",
]
SCRIPTS = [
    "run_icde_local_pilot.py",
    "audit_icde_oaei_intake.py",
    "audit_icde_gcn_winners.py",
    "icde_host_preflight.py",
    "verify_icde_local_replay.py",
    "package_icde_local_pilot.py",
    "backbones/torch_gcn_align.py",
    "backbones/torch_gcn_local_recompute.py",
    "stream_worker_crash_audit.py",
]
TESTS = [
    "test_modal_query.py",
    "test_icde_oaei_intake.py",
    "test_query.py",
    "test_certified.py",
    "test_certified_clock.py",
    "test_extensions.py",
    "test_scope.py",
]
EVIDENCE = "nodes/05_icde_query_engine/results/local_pilot_20261009"


def verify(path):
    with zipfile.ZipFile(path) as bundle:
        manifest = json.loads(bundle.read("BUNDLE_MANIFEST.json"))
        if set(bundle.namelist()) != set(manifest["files"]) | {"BUNDLE_MANIFEST.json"}:
            raise ValueError("bundle inventory mismatch")
        for name, checksum in manifest["files"].items():
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError("unsafe bundle path")
            if hashlib.sha256(bundle.read(name)).hexdigest() != checksum:
                raise ValueError(f"checksum mismatch: {name}")
    return {
        "verified": True,
        "files": len(manifest["files"]),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--verify", type=Path)
    args = parser.parse_args()
    if args.verify:
        print(json.dumps(verify(args.verify), indent=2))
        return
    if args.output is None or args.output.exists():
        raise ValueError("choose a fresh bundle output")
    files = [ROOT / "pyproject.toml", ROOT / "README.md"]
    files += list((ROOT / "src").rglob("*.py"))
    files += [ROOT / "papers/icde" / name for name in DOCS]
    files += [ROOT / "scripts" / name for name in SCRIPTS]
    files += [ROOT / "tests" / name for name in TESTS]
    files += [p for p in (ROOT / "data/toy/exact_world_minimal").iterdir() if p.is_file()]
    files += [
        ROOT / EVIDENCE / name
        for name in (
            "acceptance_tests.log",
            "gcn_local_attempt2.json",
            "gcn_winners_final.json",
            "moment_crash.json",
            "oaei_reference_audit_attempt4.json",
            "local_acceptance.json",
            "host_preflight.json",
            "source_checks.log",
        )
    ]
    files += list((ROOT / EVIDENCE / "modal_final").glob("*.json"))
    files += [ROOT / EVIDENCE / "modal_final/worlds.jsonl"]
    files = sorted(set(files))
    manifest = {
        "format": "icde-portable-pilot-bundle-v1",
        "files": {
            p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in files
        },
        "excluded": [
            "third-party raw/derived data",
            "all checkpoints",
            "SQLite/WAL",
            "WWW/WSDM result dumps",
            "local Python environments",
        ],
        "boundary": "CPU E0/E1 replay kit; target measurement and new-domain P1 not complete.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED) as bundle:
        for path in files:
            bundle.write(path, path.relative_to(ROOT).as_posix())
        bundle.writestr("BUNDLE_MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
    result = verify(args.output)
    args.output.with_suffix(".manifest.json").write_text(
        json.dumps({**manifest, "verification": result}, indent=2) + "\n"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
