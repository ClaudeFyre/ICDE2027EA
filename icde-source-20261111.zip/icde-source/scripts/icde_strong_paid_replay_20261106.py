"""Compare standard cheap controls with charged event evidence at archived states."""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def clean(value):
    if isinstance(value, float) and not np.isfinite(value):
        return "Infinity" if value > 0 else "-Infinity"
    if isinstance(value, dict):
        return {str(key): clean(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(item) for item in value]
    return value


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(clean(value), stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def exact_candidate_is_safe(reference, leader):
    # Reference schemas are read explicitly instead of guessing safety from
    # a nominal certificate. The raw exact reference is retained per record.
    results = reference["candidate_results"]
    record = next(item for item in results if item["candidate_index"] == leader)
    exact_safe = all(Fraction(item["minimum_gap"]) > 0 for item in record["pair_gap_ranges"])
    if exact_safe != record["uniformly_unique_mode"] or exact_safe != (leader in reference["uniform_winners"]):
        raise ValueError("exact reference candidate safety labels disagree with rational gaps")
    return exact_safe


def run(config_path, output, seconds):
    import icde_strong_bounds_20261106 as strong
    import icde_strong_replay_assets_20261106 as assets

    started = time.perf_counter()
    config = read(config_path)
    output.relative_to(ROOT)
    output.mkdir(parents=True, exist_ok=False)
    groups = list(assets.iter_exact_groups(root=ROOT))
    if len(groups) != 192:
        raise ValueError("the 32-query six-width population changed")
    widths = sorted({group["tau"] for group in groups})
    if widths != config["preserve_all_six_original_widths"]:
        raise ValueError("original family widths changed")
    manifest = assets.build_replay_manifest(groups, root=ROOT, verify_sources=True)
    source_files = [Path(__file__), ROOT/"scripts/icde_strong_bounds_20261106.py",
                    ROOT/"scripts/icde_strong_replay_assets_20261106.py", config_path]
    frozen = {"status":"FROZEN_BEFORE_NEW_RULE_EVALUATION_AFTER_HISTORICAL_OUTCOMES_SEEN",
              "config":config, "input_manifest":manifest,
              "code_and_config_sha256":{str(path.relative_to(ROOT)):sha(path) for path in source_files},
              "new_world_draws":0, "new_scorer_calls":0}
    write_new(output/"protocol_before_evaluation.json", frozen)
    rows = []
    timing = defaultdict(float)
    with (output/"cases.jsonl").open("x",encoding="utf-8") as handle:
        for index, group in enumerate(groups):
            if time.perf_counter()-started >= seconds:
                raise TimeoutError("bounded archived-paid-state deadline")
            anchor = group["policies"][config["anchor_policy"]]
            n = anchor["observed_prefix_length"]
            final = anchor["trace"][-1]
            event_n = final["event_samples"]
            if event_n:
                if event_n not in anchor["protected_event_by_n"]:
                    raise ValueError("the chosen paid state lacks its recorded protected event prefix")
                event = anchor["protected_event_by_n"][event_n]
            else:
                # Scope-first completion legitimately buys no event evidence.
                # Keep these cases; an absent event cannot improve any bound.
                event = {"event_upper":1., "cumulative_actual_event_fee":0.,
                         "available_at_nominal_n":0, "no_paid_evidence_available":True}
            if Fraction(str(anchor["nominal_delta"])) != Fraction(config["paid_nominal_delta"]):
                raise ValueError("anchor nominal risk differs from the declared paid risk")
            if Fraction(str(anchor["event_beta_total"])) != Fraction(config["paid_event_beta"]):
                raise ValueError("anchor event risk differs from the declared paid risk")
            family = group["family_identity"]
            q, low, high = [np.asarray([float(Fraction(value)) for value in family[name]])
                            for name in ("q_exact","low_exact","high_exact")]
            # The reference uses exact rational representations of the stored
            # binary64 law. Reject any lossy round-trip before using it.
            for values, name in ((q,"q_exact"),(low,"low_exact"),(high,"high_exact")):
                if any(Fraction.from_float(float(value)) != Fraction(exact)
                       for value, exact in zip(values,family[name])):
                    raise ValueError("exact law is not the unchanged archived binary64 law")
            t=time.perf_counter()
            bounds=strong.product_divergence_bounds(q,low,high)
            transport_bounds=dict(bounds)
            transport_bounds["tv_hellinger_upper"]=min(bounds["tv_hellinger_upper"],float(group["scope_epsilon_upper"]))
            bounds["original_coupling_tv_upper"]=float(group["scope_epsilon_upper"])
            bounds["combined_tv_upper_used"]=transport_bounds["tv_hellinger_upper"]
            timing["divergence_construction"]+=time.perf_counter()-t
            counts=np.bincount(np.asarray(group["winner_indices"][:n],dtype=np.int64),
                               minlength=group["candidate_count"])
            results={}
            evidence_records={}
            for label, risk in (("cheap_full_risk",config["cheap_delta"]),
                                ("same_nominal_risk",config["paid_nominal_delta"])):
                t=time.perf_counter()
                evidence=strong.categorical_probability_bounds(counts,n,Fraction(risk),
                    method=config["probability_method"])
                timing["probability_"+label]+=time.perf_counter()-t
                values=[]
                for transport in config["deterministic_transports"]:
                    t=time.perf_counter()
                    result=strong.transport_mode_intervals(evidence["lower"],evidence["upper"],
                        evidence["leader_index"],transport_bounds,method=transport)
                    timing["transport_"+transport]+=time.perf_counter()-t
                    values.append({"transport":transport,**result})
                best=max(values,key=lambda value:value["lower_gap"])
                results[label]={"certified":best["certified"],"lower_gap":best["lower_gap"],
                    "deterministic_transport":best["transport"],"all_transports":values,
                    "winner":evidence["leader_index"],"nominal_lower_gap":evidence["lower_gap"]}
                evidence_records[label]={"alpha_exact":evidence["alpha_exact"],
                    "delta_exact":evidence["delta_exact"],"lower":evidence["lower"].tolist(),
                    "upper":evidence["upper"].tolist(),"candidate_count":group["candidate_count"]}
                if label=="same_nominal_risk":
                    paid_epsilon=min(float(group["scope_epsilon_upper"]),float(event["event_upper"]))
                    paid_gap=Fraction.from_float(float(evidence["lower_gap"]))-2*Fraction.from_float(paid_epsilon)
                    event_gap=float(paid_gap)
                    combined_gap=max(best["lower_gap"],event_gap)
                    results["paid_combination"]={"certified":combined_gap>0,
                        "lower_gap":combined_gap,"winner":evidence["leader_index"],
                        "event_only_lower_gap":event_gap,"event_epsilon":paid_epsilon,
                        "nominal_delta":risk,"event_beta":config["paid_event_beta"],
                        "same_event_prefix_and_full_original_fee_required":True}
            reference=group["exact_reference"]
            safety=exact_candidate_is_safe(reference,int(np.argmax(counts)))
            row={"graph":group["graph"],"query_id":group["query_id"],"tau":group["tau"],
                "seed":group["seed"],"query_identity_sha256":group["query_identity_sha256"],
                "family_identity_sha256":group["family_identity_sha256"],
                "anchor_path":anchor["source_path"],"anchor_sha256":anchor["source_sha256"],
                "n":n,"event_n":event_n,"capture_cap":group["capture_cap"],
                "no_paid_evidence_available":event_n==0,
                "noncertificate_is_censored":n<group["capture_cap"],
                "original_anchor_robust":anchor["original_policy_robust"],
                "original_anchor_approved":anchor["original_policy_cert"],
                "nominal_counts":counts.tolist(),"bounds":bounds,"evidence":evidence_records,
                "results":results,"candidate_is_uniformly_safe":safety,
                "original_review_labels":anchor["original_review_labels"],
                "charged_event_work":event["cumulative_actual_event_fee"],
                "original_anchor_total_work":anchor["costs"]["original_work_used"],
                "original_cost_model":group["cost_model"],
                "replay_only":True,"new_model_calls":0}
            # Deterministic exact references must not conflict with any observed
            # certificate; discrepancies are retained and reported, not hidden.
            row["observed_false_clear"]={key: value["certified"] and not safety
                                          for key,value in results.items()}
            rows.append(row)
            handle.write(json.dumps(clean(row),ensure_ascii=False,allow_nan=False)+"\n")
            handle.flush()
            if (index+1)%16==0:
                print(json.dumps({"groups":index+1,"of":len(groups),"seconds":time.perf_counter()-started}),flush=True)
    aggregated=[]
    for tau in widths:
        selected=[row for row in rows if row["tau"]==tau]
        item={"tau":tau,"distinct_queries":len(selected),
              "original_anchor_approved":sum(row["original_anchor_approved"] for row in selected),
              "reference_safe_for_empirical_leader":sum(row["candidate_is_uniformly_safe"] for row in selected)}
        for method in ("cheap_full_risk","same_nominal_risk","paid_combination"):
            item[method]={"certificates":sum(row["results"][method]["certified"] for row in selected),
                "observed_false_clear":sum(row["observed_false_clear"][method] for row in selected),
                "noncertificate_censored":sum(not row["results"][method]["certified"] and row["noncertificate_is_censored"] for row in selected)}
        item["paid_only_additional_at_same_risk_split"]=sum(row["results"]["paid_combination"]["certified"] and not row["results"]["same_nominal_risk"]["certified"] for row in selected)
        item["paid_only_additional_vs_full_risk_cheap"]=sum(row["results"]["paid_combination"]["certified"] and not row["results"]["cheap_full_risk"]["certified"] for row in selected)
        aggregated.append(item)
    assets.build_replay_manifest(groups,root=ROOT,verify_sources=True)
    changed=[path for path,digest in frozen["code_and_config_sha256"].items() if sha(ROOT/path)!=digest]
    if changed:
        raise ValueError("replay source changed during execution")
    summary={"status":"COMPLETE_EXPLORATORY_PAIRED_ARCHIVED_PAID_STATES",
        "distinct_queries":32,"query_family_cases":len(rows),"results":aggregated,
        "reclassification_seconds":dict(timing),"elapsed_seconds":time.perf_counter()-started,
        "observed_false_clear_total":sum(sum(row["observed_false_clear"].values()) for row in rows),
        "new_scorer_calls":0,"new_random_draws":0,"cases_sha256":sha(output/"cases.jsonl"),
        "limitations":["same previously inspected queries and streams; exploratory",
            "fixed archived adaptive terminal states, not new adaptive-serving measurements",
            "paid envelope is the established generic abstraction, not a newly invented method",
            "observed zero false clearance does not imply global zero-error guarantee"]}
    write_new(output/"summary.json",summary)
    print(json.dumps(clean(summary),ensure_ascii=False),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--seconds",type=float,default=600.)
    args=parser.parse_args()
    if not 0<args.seconds<=600:
        parser.error("seconds must be in (0,600]")
    run(args.config.resolve(),args.output.resolve(),args.seconds)


if __name__=="__main__":
    main()
