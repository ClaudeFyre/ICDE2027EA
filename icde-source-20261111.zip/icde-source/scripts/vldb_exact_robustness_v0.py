"""Controlled, exact small-world checks of probability-law certificate transfer.

All probabilities are declared rational Bernoulli parameters, not fitted edge
truth probabilities or ECE estimates.  No model training, Monte Carlo, or real
EA effectiveness is evaluated.  The elementary TV inequalities are baselines,
not claims of a new theorem.  A valid old-law gap lower bound is an assumption;
the examples instantiate it from exact enumeration rather than observed gaps.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
from typing import Any, Iterable, Sequence


ZERO = Fraction(0)
ONE = Fraction(1)
MAX_VARIABLES = 10
PATTERNS = ("outside_only", "inside_first_up", "inside_all_up", "inside_all_down", "all_up")


def rational(value: Any) -> Fraction:
    """Interpret decimal configuration values without binary float drift."""
    if isinstance(value, bool):
        raise ValueError("a probability cannot be boolean")
    return value if isinstance(value, Fraction) else Fraction(str(value))


def probabilities(values: Iterable[Any]) -> tuple[Fraction, ...]:
    result = tuple(rational(value) for value in values)
    if len(result) > MAX_VARIABLES or any(not ZERO <= value <= ONE for value in result):
        raise ValueError("need at most ten probabilities in [0, 1]")
    return result


def exact(value: Fraction) -> dict[str, Any]:
    return {"fraction": str(value), "float": float(value)}


@lru_cache(maxsize=8192)
def product_masses(parameters: tuple[Fraction, ...]) -> tuple[Fraction, ...]:
    """Mass of each bit mask, with parameter i belonging to bit i."""
    parameters = probabilities(parameters)
    masses = [ONE]
    for parameter in parameters:
        masses = [mass * (ONE - parameter) for mass in masses] + [
            mass * parameter for mass in masses
        ]
    return tuple(masses)


def _winner_map(mapping: Sequence[int], n: int, candidate_count: int) -> tuple[int, ...]:
    if not 1 <= candidate_count or len(mapping) != 1 << n:
        raise ValueError("winner map must cover exactly all worlds")
    if any(isinstance(value, bool) or not isinstance(value, int)
           or not 0 <= value < candidate_count for value in mapping):
        raise ValueError("winner IDs must be integer candidate positions")
    return tuple(mapping)


def winner_distribution(
    parameters: Sequence[Any], mapping: Sequence[int], candidate_count: int
) -> tuple[Fraction, ...]:
    parameters = probabilities(parameters)
    mapping = _winner_map(mapping, len(parameters), candidate_count)
    result = [ZERO] * candidate_count
    for winner, mass in zip(mapping, product_masses(parameters)):
        result[winner] += mass
    return tuple(result)


def project_mask(mask: int, scope: Sequence[int]) -> int:
    return sum(((mask >> coordinate) & 1) << position
               for position, coordinate in enumerate(scope))


def scope_audit(mapping: Sequence[int], n: int, scope: Sequence[int]) -> dict[str, Any]:
    """Exhaustively check measurability and whether each included bit matters.

    A minimal winner scope can be smaller than a score-vector dependency scope.
    These examples certify winner-event measurability, which is sufficient for
    the TV transfer bound; no generic neural dependency extractor is claimed.
    """
    if not 0 <= n <= MAX_VARIABLES or len(mapping) != 1 << n:
        raise ValueError("invalid world map size")
    scope = tuple(scope)
    if len(set(scope)) != len(scope) or any(type(i) is not int or not 0 <= i < n for i in scope):
        raise ValueError("scope coordinates must be distinct valid integers")
    observed: dict[int, tuple[int, int]] = {}
    witness = None
    for mask, winner in enumerate(mapping):
        local = project_mask(mask, scope)
        if local in observed and observed[local][1] != winner:
            witness = {"world_a": observed[local][0], "world_b": mask,
                       "same_scope_mask": local}
            break
        observed[local] = (mask, winner)
    influential = [i for i in scope if any(mapping[mask] != mapping[mask ^ (1 << i)]
                                          for mask in range(1 << n))]
    return {"complete": witness is None, "minimal": witness is None and len(influential) == len(scope),
            "scope": list(scope), "influential_included_coordinates": influential,
            "omitted_dependency_witness": witness, "worlds_checked": 1 << n}


def local_map(mapping: Sequence[int], scope: Sequence[int]) -> tuple[int, ...]:
    return tuple(mapping[sum(((mask >> j) & 1) << coordinate
                             for j, coordinate in enumerate(scope))]
                 for mask in range(1 << len(scope)))


def tv_from_masses(left: Sequence[Fraction], right: Sequence[Fraction]) -> Fraction:
    if len(left) != len(right):
        raise ValueError("mass vectors must have the same length")
    return sum((abs(a - b) for a, b in zip(left, right)), ZERO) / 2


def product_tv(left: Sequence[Any], right: Sequence[Any]) -> Fraction:
    left, right = probabilities(left), probabilities(right)
    if len(left) != len(right):
        raise ValueError("parameter vectors must have the same length")
    return tv_from_masses(product_masses(left), product_masses(right))


def _vertices(low: tuple[Fraction, ...], high: tuple[Fraction, ...]):
    return product(*(tuple(dict.fromkeys((a, b))) for a, b in zip(low, high)))


def _replace_bit(mask: int, coordinate: int, value: int) -> int:
    lower = mask & ((1 << coordinate) - 1)
    upper = mask >> coordinate
    return lower | (value << coordinate) | (upper << (coordinate + 1))


@lru_cache(maxsize=256)
def _pivotal_events(mapping: tuple[int, ...], dimension: int, candidate_count: int):
    result = []
    for coordinate in range(dimension):
        rows = []
        for mask in range(1 << (dimension - 1)):
            winner0 = mapping[_replace_bit(mask, coordinate, 0)]
            winner1 = mapping[_replace_bit(mask, coordinate, 1)]
            rows.append(tuple(int(winner1 == c) - int(winner0 == c)
                              for c in range(candidate_count)))
        result.append(tuple(rows))
    return tuple(result)


def sensitivity_bounds(
    left: Sequence[Any], right: Sequence[Any], mapping: Sequence[int], candidate_count: int,
    scope: Sequence[int], *, exact_box_scope_limit: int = 6,
) -> dict[str, Any]:
    """Compute two distinct valid event-wise bounds for independent laws.

    PATH: telescope coordinates in the declared scope order.  The signed
    derivative for coordinate i is averaged under (q_<i, p_>i).  Sum the
    absolute coordinate contributions.  This is valid for this fixed p->q
    path, NOT uniformly for other perturbations, and is not old-point influence.

    BOX: for each coordinate, maximize the expected absolute pivotal indicator
    over the other-coordinate parameter box.  Its expectation is multilinear,
    so the exact maximum occurs at a vertex.  Sum width times this supremum.
    Above the explicit computation limit use the universal bound <=1 for each
    potentially pivotal event, honestly marked as a coarse bound.  BOX holds
    uniformly on the coordinate box between p and q, assuming independence.
    """
    left, right = probabilities(left), probabilities(right)
    if len(left) != len(right):
        raise ValueError("parameter vectors must have the same length")
    mapping = _winner_map(mapping, len(left), candidate_count)
    audit = scope_audit(mapping, len(left), scope)
    if not audit["complete"]:
        raise ValueError("incomplete winner scope cannot justify local bounds")
    if type(exact_box_scope_limit) is not int or not 0 <= exact_box_scope_limit <= MAX_VARIABLES:
        raise ValueError("exact_box_scope_limit must be an integer from zero through ten")
    scope = tuple(scope)
    p, q = tuple(left[i] for i in scope), tuple(right[i] for i in scope)
    local = local_map(mapping, scope)
    s = len(scope)
    changes = _pivotal_events(local, s, candidate_count)
    path = [ZERO] * candidate_count
    box = [ZERO] * candidate_count
    low, high = tuple(map(min, p, q)), tuple(map(max, p, q))
    derivative_expectations = []
    suprema = []
    box_law_evaluations = 0
    exact_box = s <= exact_box_scope_limit
    for i in range(s):
        delta = abs(q[i] - p[i])
        path_other = q[:i] + p[i + 1:]
        signed = tuple(sum((mass * row[c] for mass, row in zip(product_masses(path_other), changes[i])), ZERO)
                       for c in range(candidate_count))
        for c in range(candidate_count):
            path[c] += delta * abs(signed[c])
        derivative_expectations.append([exact(value) for value in signed])
        upper = [ZERO] * candidate_count
        if delta:
            if exact_box:
                other_low, other_high = low[:i] + low[i + 1:], high[:i] + high[i + 1:]
                for vertex in _vertices(other_low, other_high):
                    box_law_evaluations += 1
                    mass = product_masses(tuple(vertex))
                    for c in range(candidate_count):
                        upper[c] = max(upper[c], sum((m * abs(row[c]) for m, row in zip(mass, changes[i])), ZERO))
            else:
                upper = [ONE if any(row[c] for row in changes[i]) else ZERO for c in range(candidate_count)]
        for c in range(candidate_count):
            box[c] += delta * upper[c]
        suprema.append([exact(value) for value in upper])
    path = tuple(min(ONE, value) for value in path)
    box = tuple(min(ONE, value) for value in box)
    # Exact box endpoint checks are independently computed from winner events.
    old = winner_distribution(p, local, candidate_count)
    extrema = {"minimum": list(old), "maximum": list(old)}
    all_vertex_distributions = []
    for vertex in _vertices(low, high):
        values = winner_distribution(tuple(vertex), local, candidate_count)
        all_vertex_distributions.append(values)
        for c in range(candidate_count):
            extrema["minimum"][c] = min(extrema["minimum"][c], values[c])
            extrema["maximum"][c] = max(extrema["maximum"][c], values[c])
    return {
        "path": path, "box": box, "box_vertices": tuple(all_vertex_distributions),
        "path_details": {"coordinate_order": list(scope), "signed_derivative_expectations": derivative_expectations,
                         "validity": "fixed_declared_p_to_q_path_only_not_uniform_or_old_point_influence"},
        "box_details": {"low": [exact(x) for x in low], "high": [exact(x) for x in high],
                        "exact_pivotal_supremum": exact_box,
                        "supremum_method": "multilinear_vertex_enumeration" if exact_box else "universal_unit_bound_for_potentially_pivotal_event",
                        "coordinate_suprema": suprema, "pivotal_parameter_vertices_evaluated": box_law_evaluations,
                        "winner_law_vertices_evaluated": len(all_vertex_distributions),
                        "validity": "uniform_on_declared_independent_coordinate_box_only",
                        "candidate_probability_min": [exact(x) for x in extrema["minimum"]],
                        "candidate_probability_max": [exact(x) for x in extrema["maximum"]]},
    }


@dataclass(frozen=True)
class Model:
    name: str
    kind: str
    n: int
    scope: tuple[int, ...]
    mapping: tuple[int, ...]
    base: tuple[Fraction, ...]
    description: str
    candidates: tuple[str, ...] = ("A", "B")


def built_in_models() -> tuple[Model, ...]:
    """Small fixed scorers; bit indices and deterministic score ties are fixed."""
    def bit(mask, i):
        return (mask >> i) & 1

    graph = tuple(0 if Fraction(1, 10) + bit(m, 0) + 2 * bit(m, 0) * bit(m, 1)
                  > bit(m, 2) + 2 * bit(m, 2) * bit(m, 3) else 1 for m in range(256))
    return (
        Model("graph_two_hop", "graph_EA_style", 8, (0, 1, 2, 3), graph,
              probabilities(("0.6", "0.6", "0.4", "0.5", "0.5", "0.5", "0.5", "0.5")),
              "A/B path support: s-u-a and s-v-b; scores .1+x0+2*x0*x1 and x2+2*x2*x3; bits4..7 disconnected."),
        Model("boolean_and_near", "generic_boolean", 8, (0, 1),
              tuple(0 if bit(m, 0) and bit(m, 1) else 1 for m in range(256)),
              probabilities(("0.7", "0.7", "0.5", "0.5", "0.5", "0.5", "0.5", "0.5")),
              "A iff two local facts hold; old mode gap=.02."),
        Model("boolean_global_majority", "generic_boolean_global", 6, tuple(range(6)),
              tuple(0 if m.bit_count() > 3 else 1 for m in range(64)),
              probabilities(("0.6",) * 6), "A iff >3 of 6 facts hold; all variables matter."),
        Model("boolean_global_parity", "generic_boolean_global", 6, tuple(range(6)),
              tuple(m.bit_count() % 2 for m in range(64)), probabilities(("0.65",) * 6),
              "Parity; signed old-point derivatives can cancel and are not uniform bounds."),
        Model("single_bit_near", "generic_boolean_near_boundary", 8, (0,),
              tuple(0 if bit(m, 0) else 1 for m in range(256)),
              probabilities(("0.51",) + ("0.5",) * 7), "A iff x0; old unique mode with gap=.02."),
        Model("single_bit_tie", "generic_boolean_tie", 8, (0,),
              tuple(0 if bit(m, 0) else 1 for m in range(256)), probabilities(("0.5",) * 8),
              "A iff x0; old winner probabilities tie, so no unique-mode transfer allowed."),
    )


def modes(values: Sequence[Fraction]) -> tuple[int, ...]:
    maximum = max(values)
    return tuple(i for i, value in enumerate(values) if value == maximum)


def perturb(model: Model, step: Fraction, pattern: str) -> tuple[Fraction, ...]:
    if pattern not in PATTERNS or not ZERO <= step <= ONE:
        raise ValueError("unknown perturbation pattern or step")
    active = set(model.scope)
    if pattern == "outside_only":
        coordinates, sign = set(range(model.n)) - active, 1
    elif pattern == "inside_first_up":
        coordinates, sign = set(model.scope[:1]), 1
    elif pattern in ("inside_all_up", "inside_all_down"):
        coordinates, sign = active, -1 if pattern.endswith("down") else 1
    else:
        coordinates, sign = set(range(model.n)), 1
    return tuple(min(ONE, max(ZERO, p + sign * step)) if i in coordinates else p
                 for i, p in enumerate(model.base))


def transfer_checks(old: Sequence[Fraction], new: Sequence[Fraction], full_tv: Fraction,
                    scope_tv: Fraction, coupling: Fraction, sensitivities: dict[str, Any],
                    factor: Fraction) -> dict[str, Any]:
    """Transfer valid old gap lower bounds; never turn an empirical gap into one."""
    old_modes, new_modes = modes(old), modes(new)
    names = ("full_TV", "scope_TV", "scope_coupling_upper", "event_path", "event_uniform_box")
    if len(old_modes) != 1:
        return {"old_unique": False, "new_unique": len(new_modes) == 1,
                "certificate_factor": str(factor), "old_gap_lower_bounds": None,
                "certified": {name: False for name in names}, "violations": []}
    winner = old_modes[0]
    lower = {c: factor * (old[winner] - old[c]) for c in range(len(old)) if c != winner}
    certified = {
        "full_TV": all(gap > 2 * full_tv for gap in lower.values()),
        "scope_TV": all(gap > 2 * scope_tv for gap in lower.values()),
        "scope_coupling_upper": all(gap > 2 * coupling for gap in lower.values()),
        "event_path": all(gap > sensitivities["path"][winner] + sensitivities["path"][c]
                          for c, gap in lower.items()),
        "event_uniform_box": all(gap > sensitivities["box"][winner] + sensitivities["box"][c]
                                 for c, gap in lower.items()),
    }
    same_unique = new_modes == (winner,)
    violations = [name for name in names if certified[name] and not same_unique]
    uniform_ok = all(modes(vertex) == (winner,) for vertex in sensitivities["box_vertices"])
    if certified["event_uniform_box"] and not uniform_ok:
        violations.append("event_uniform_box_vertices")
    return {"old_unique": True, "new_unique": len(new_modes) == 1,
            "old_winner": winner, "new_modes": list(new_modes), "same_unique_winner": same_unique,
            "certificate_factor": str(factor),
            "old_gap_lower_bounds": {str(c): exact(value) for c, value in lower.items()},
            "certified": certified, "uniform_box_same_unique_at_all_vertices": uniform_ok,
            "violations": violations}


def counterexamples() -> dict[str, Any]:
    """Exact witnesses against omitted dependence, scope, and point influence."""
    # Both laws have marginals (.5,.5); equality-event modes reverse uniquely.
    dependent_p = (Fraction(2, 5), Fraction(1, 10), Fraction(1, 10), Fraction(2, 5))
    dependent_q = (Fraction(1, 10), Fraction(2, 5), Fraction(2, 5), Fraction(1, 10))
    equality_event = (0, 1, 1, 0)
    def arbitrary_law_distribution(law, mapping):
        return tuple(sum((mass for mass, winner in zip(law, mapping) if winner == c), ZERO)
                     for c in range(2))
    p_dist = arbitrary_law_distribution(dependent_p, equality_event)
    q_dist = arbitrary_law_distribution(dependent_q, equality_event)
    mapping = (0, 0, 1, 1)  # A iff global bit1=0; declared local bit0 misses it.
    p, q = probabilities(("0.5", "0.2")), probabilities(("0.5", "0.8"))
    omitted = scope_audit(mapping, 2, (0,))
    false_local_tv = product_tv((p[0],), (q[0],))
    global_old, global_new = winner_distribution(p, mapping, 2), winner_distribution(q, mapping, 2)
    # XOR at (.5,.5) has zero point derivatives, yet a joint movement changes it.
    xor = (0, 1, 1, 0)
    point_old = winner_distribution(("0.5", "0.5"), xor, 2)
    point_new = winner_distribution(("0.6", "0.6"), xor, 2)
    return {
        "same_marginals_different_dependence": {
            "p_masses": [exact(x) for x in dependent_p], "q_masses": [exact(x) for x in dependent_q],
            "edge_marginals_both": ["1/2", "1/2"], "winner_map": list(equality_event),
            "p_winner_distribution": [exact(x) for x in p_dist], "q_winner_distribution": [exact(x) for x in q_dist],
            "exact_joint_TV": exact(tv_from_masses(dependent_p, dependent_q)),
            "winner_reversed": modes(p_dist) != modes(q_dist),
            "lesson": "matching marginals do not determine a joint law; independent-product bounds cannot be applied here"},
        "omitted_global_dependency": {
            "winner_map": list(mapping), "declared_incomplete_scope": [0], "audit": omitted,
            "false_local_TV": exact(false_local_tv), "true_full_TV": exact(product_tv(p, q)),
            "p_winner_distribution": [exact(x) for x in global_old], "q_winner_distribution": [exact(x) for x in global_new],
            "false_scope_would_certify": global_old[0] - global_old[1] > 2 * false_local_tv,
            "winner_reversed": modes(global_old) != modes(global_new),
            "lesson": "omitting a global scorer dependency invalidates the scope argument"},
        "old_point_influence_not_uniform": {
            "event": "even_parity", "p": ["1/2", "1/2"], "q": ["3/5", "3/5"],
            "old_point_signed_derivatives": ["0", "0"],
            "actual_event_probability_change": exact(abs(point_new[0] - point_old[0])),
            "lesson": "old-point derivative times total parameter movement need not upper-bound a finite perturbation"},
    }


def common_uniform_masses(parameters: Sequence[Any]) -> tuple[Fraction, ...]:
    """Exact law X_i=1{U<=p_i} for one shared U~Uniform[0,1].

    This is one explicit common-shock group's kernel.  It is not an arbitrary
    dependence model, and its masses need not be multilinear in parameters.
    """
    parameters = probabilities(parameters)
    result = []
    for mask in range(1 << len(parameters)):
        active_min = min((p for i, p in enumerate(parameters) if (mask >> i) & 1), default=ONE)
        inactive_max = max((p for i, p in enumerate(parameters) if ((mask >> i) & 1) == 0), default=ZERO)
        result.append(max(ZERO, active_min - inactive_max))
    return tuple(result)


def mixed_common_shock_masses(parameters: Sequence[Any], rho: Any) -> tuple[Fraction, ...]:
    """Mix a shared-uniform kernel with an independent kernel for one group."""
    parameters, rho = probabilities(parameters), rational(rho)
    if not ZERO <= rho <= ONE:
        raise ValueError("rho must lie in [0, 1]")
    return tuple(rho * shared + (ONE - rho) * independent
                 for shared, independent in zip(common_uniform_masses(parameters), product_masses(parameters)))


def _threshold_interval_union(left: Sequence[Fraction], right: Sequence[Fraction]) -> Fraction:
    intervals = sorted((min(p, q), max(p, q)) for p, q in zip(left, right) if p != q)
    if not intervals:
        return ZERO
    total = ZERO
    start, end = intervals[0]
    for following_start, following_end in intervals[1:]:
        if following_start <= end:
            end = max(end, following_end)
        else:
            total += end - start
            start, end = following_start, following_end
    return total + end - start


def common_shock_coupling_bound(left: Sequence[Any], right: Sequence[Any], rho: Any, other_rho: Any) -> dict[str, Any]:
    """Declared-kernel upper bound for a single group; no fitted probabilities."""
    left, right = probabilities(left), probabilities(right)
    rho, other_rho = rational(rho), rational(other_rho)
    if len(left) != len(right) or not ZERO <= rho <= ONE or not ZERO <= other_rho <= ONE:
        raise ValueError("need equal parameter dimensions and rho values in [0, 1]")
    agreement = ONE
    for p, q in zip(left, right):
        agreement *= ONE - abs(p - q)
    d_ind = ONE - agreement
    d_shock = _threshold_interval_union(left, right)
    raw = abs(rho - other_rho) + min(rho, other_rho) * d_shock + min(ONE - rho, ONE - other_rho) * d_ind
    return {"d_ind": exact(d_ind), "d_shock": exact(d_shock),
            "gamma_raw": exact(raw), "gamma": exact(min(ONE, raw))}


def run_common_shock_validation() -> dict[str, Any]:
    """Separate frozen 2-bit kernel checks, not independent-box experiments."""
    pairs = (
        (probabilities(("0.2", "0.7")), probabilities(("0.4", "0.6"))),
        (probabilities(("0.5", "0.5")), probabilities(("0.4", "0.6"))),
        (probabilities((0, 1)), probabilities((1, 0))),
        (probabilities((0, 0)), probabilities((1, 1))),
    )
    rhos = (ZERO, Fraction(11, 20), ONE)
    cases, violations = [], []
    law_checks = 0
    for pair_index, (p, q) in enumerate(pairs):
        for rho in rhos:
            for other_rho in rhos:
                old = mixed_common_shock_masses(p, rho)
                new = mixed_common_shock_masses(q, other_rho)
                case_id = f"pair{pair_index}:rho{rho}:rho_prime{other_rho}"
                for name, parameters, mixture, mixing in (("p", p, old, rho), ("q", q, new, other_rho)):
                    law_checks += 1
                    if sum(mixture, ZERO) != ONE or any(mass < 0 for mass in mixture):
                        violations.append({"case": case_id, "property": "invalid_mass", "law": name})
                    marginals = tuple(sum((mass for mask, mass in enumerate(mixture) if (mask >> i) & 1), ZERO)
                                      for i in range(2))
                    if marginals != parameters:
                        violations.append({"case": case_id, "property": "wrong_marginals", "law": name})
                    if mixing == ZERO and mixture != product_masses(parameters):
                        violations.append({"case": case_id, "property": "rho_zero_kernel", "law": name})
                    if mixing == ONE and mixture != common_uniform_masses(parameters):
                        violations.append({"case": case_id, "property": "rho_one_kernel", "law": name})
                actual_tv = tv_from_masses(old, new)
                bound = common_shock_coupling_bound(p, q, rho, other_rho)
                if actual_tv > rational(bound["gamma"]["fraction"]):
                    violations.append({"case": case_id, "property": "gamma_below_actual_joint_TV"})
                cases.append({"case": case_id, "p": [str(x) for x in p], "q": [str(x) for x in q],
                              "rho": str(rho), "rho_prime": str(other_rho),
                              "p_masses": [exact(x) for x in old], "q_masses": [exact(x) for x in new],
                              "exact_joint_TV": exact(actual_tv), **bound})
    # For pure shared uniforms, Pr[XOR]=|p0-p1|.  The box corners miss
    # the p0=p1 interior minimum, so their minimum is not a uniform lower bound.
    corners = []
    for vertex in product((ZERO, Fraction(3, 5)), (Fraction(2, 5), ONE)):
        masses = mixed_common_shock_masses(vertex, ONE)
        xor_probability = masses[1] + masses[2]
        corners.append({"parameters": [str(x) for x in vertex], "xor_probability": exact(xor_probability)})
    interior = mixed_common_shock_masses((Fraction(1, 2), Fraction(1, 2)), ONE)
    minimum_corner = min(rational(row["xor_probability"]["fraction"]) for row in corners)
    interior_xor = interior[1] + interior[2]
    if minimum_corner != Fraction(1, 5) or interior_xor != ZERO:
        violations.append({"property": "common_shock_internal_breakpoint_witness"})
    return {
        "scope": "controlled_exact_two_bit_single_group_common_shock_validation",
        "kernel": "rho*shared_uniform_threshold_law+(1-rho)*independent_Bernoulli_product",
        "parameter_pair_count": len(pairs), "rho_values": [str(x) for x in rhos],
        "joint_law_pair_checks": len(cases), "mass_and_marginal_law_checks": law_checks,
        "cases": cases,
        "interior_breakpoint_counterexample": {
            "event": "XOR", "rho": "1", "box": [["0", "3/5"], ["2/5", "1"]],
            "corners": corners, "corner_minimum": exact(minimum_corner),
            "interior_parameters": ["1/2", "1/2"], "interior_xor_probability": exact(interior_xor),
            "corner_only_minimum_is_invalid": interior_xor < minimum_corner,
            "lesson": "independent-product multilinear box-corner reasoning does not apply to this kernel"},
        "violations": len(violations), "violation_details": violations,
        "claim_boundaries": ["fixed_single_group_kernel_only", "no_arbitrary_dependence_claim",
                             "no_common_shock_continuous_box_algorithm", "not_real_world_effectiveness"],
    }


def run_exact_validation(config: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return JSON-serializable exact checks; performs no file I/O."""
    config = dict(config or {})
    limit = config.get("max_variables", MAX_VARIABLES)
    if type(limit) is not int or not 1 <= limit <= MAX_VARIABLES:
        raise ValueError("max_variables must be an integer from one through ten")
    box_limit = config.get("exact_box_scope_limit", 6)
    steps = tuple(rational(x) for x in config.get("perturbation_steps", ("0", "0.001", "0.01", "0.05")))
    factors = tuple(rational(x) for x in config.get("certificate_factors", ("1", "0.5")))
    patterns = tuple(config.get("patterns", PATTERNS))
    if not steps or any(not ZERO <= x <= ONE for x in steps):
        raise ValueError("need nonempty perturbation_steps in [0, 1]")
    if not factors or any(not ZERO < x <= ONE for x in factors):
        raise ValueError("need nonempty valid gap-certificate factors in (0, 1]")
    if not patterns or any(pattern not in PATTERNS for pattern in patterns):
        raise ValueError("unknown or empty perturbation pattern")
    models = tuple(m for m in built_in_models() if m.n <= limit)
    requested = config.get("models")
    if requested is not None:
        requested = tuple(requested)
        if set(requested) - {m.name for m in built_in_models()}:
            raise ValueError("unknown model name")
        models = tuple(m for m in models if m.name in requested)
    if not models:
        raise ValueError("configuration selected no built-in models")
    cases, violations, model_summaries = [], [], []
    counts = {name: 0 for name in ("full_TV", "scope_TV", "scope_coupling_upper", "event_path", "event_uniform_box")}
    opportunities = {name: 0 for name in counts}
    opportunities_vs_scope = {name: 0 for name in counts}
    shifted_counts = {name: 0 for name in counts}
    certificate_count = eligible_count = 0
    shifted_certificate_count = 0
    for model in models:
        audit = scope_audit(model.mapping, model.n, model.scope)
        if not audit["complete"] or not audit["minimal"]:
            raise AssertionError("built-in model lacks its declared strict winner scope")
        old = winner_distribution(model.base, model.mapping, len(model.candidates))
        local_old = winner_distribution(tuple(model.base[i] for i in model.scope),
                                        local_map(model.mapping, model.scope), len(model.candidates))
        if old != local_old:
            violations.append({"model": model.name, "property": "full_local_old_distribution"})
        model_summaries.append({"name": model.name, "kind": model.kind, "variables": model.n,
                                "worlds_per_full_law": 1 << model.n, "scope_audit": audit,
                                "description": model.description, "candidates": list(model.candidates),
                                "base_parameters": [exact(x) for x in model.base],
                                "old_distribution": [exact(x) for x in old], "old_modes": list(modes(old))})
        for step in steps:
            for pattern in patterns:
                q = perturb(model, step, pattern)
                shifted = q != model.base
                new = winner_distribution(q, model.mapping, len(model.candidates))
                p_scope, q_scope = tuple(model.base[i] for i in model.scope), tuple(q[i] for i in model.scope)
                full_tv, scoped_tv = product_tv(model.base, q), product_tv(p_scope, q_scope)
                coupling = ONE
                for p_i, q_i in zip(p_scope, q_scope):
                    coupling *= ONE - abs(q_i - p_i)
                coupling = ONE - coupling
                bounds = sensitivity_bounds(model.base, q, model.mapping, len(model.candidates), model.scope,
                                            exact_box_scope_limit=box_limit)
                case_id = f"{model.name}:{step}:{pattern}"
                local_new = winner_distribution(q_scope, local_map(model.mapping, model.scope), len(model.candidates))
                if new != local_new or scoped_tv > full_tv or scoped_tv > coupling:
                    violations.append({"case": case_id, "property": "scope_or_coupling_bound"})
                for c in range(len(old)):
                    change = abs(new[c] - old[c])
                    if change > scoped_tv or change > bounds["path"][c]:
                        violations.append({"case": case_id, "property": "event_TV_or_path_bound", "candidate": c})
                    if any(abs(vertex[c] - old[c]) > bounds["box"][c] for vertex in bounds["box_vertices"]):
                        violations.append({"case": case_id, "property": "uniform_box_event_bound", "candidate": c})
                checks = []
                for factor in factors:
                    checked = transfer_checks(old, new, full_tv, scoped_tv, coupling, bounds, factor)
                    checks.append(checked)
                    certificate_count += 1
                    shifted_certificate_count += int(shifted)
                    eligible_count += int(checked["old_unique"])
                    for name, certified in checked["certified"].items():
                        counts[name] += int(certified)
                        opportunities[name] += int(certified and not checked["certified"]["full_TV"])
                        opportunities_vs_scope[name] += int(certified and not checked["certified"]["scope_TV"])
                        shifted_counts[name] += int(shifted and certified)
                    for violation in checked["violations"]:
                        violations.append({"case": case_id, "factor": str(factor), "property": violation})
                case = {"case": case_id, "model": model.name, "step": str(step), "pattern": pattern,
                        "nonzero_parameter_shift": shifted,
                        "nonzero_scope_parameter_shift": p_scope != q_scope,
                        "new_parameters": [exact(x) for x in q], "new_distribution": [exact(x) for x in new],
                        "new_modes": list(modes(new)), "full_TV": exact(full_tv), "scope_TV": exact(scoped_tv),
                        "declared_scope_coupling_upper": exact(coupling),
                        "event_path_bounds": [exact(x) for x in bounds["path"]],
                        "event_uniform_box_bounds": [exact(x) for x in bounds["box"]],
                        "path_details": bounds["path_details"], "box_details": bounds["box_details"],
                        "certificate_checks": checks}
                cases.append(case)
    examples = counterexamples()
    if not examples["same_marginals_different_dependence"]["winner_reversed"]:
        violations.append({"property": "dependence_counterexample"})
    if examples["omitted_global_dependency"]["audit"]["complete"]:
        violations.append({"property": "scope_counterexample"})
    common_shock = run_common_shock_validation()
    if common_shock["violations"]:
        violations.append({"property": "common_shock_validation", "count": common_shock["violations"]})
    return {
        "format": "vldb-controlled-exact-robustness-v0", "status": "PASS" if not violations else "FAIL",
        "scope": "controlled_exact_small_world_validation_only",
        "claim_boundaries": ["not_real_world_effectiveness", "not_a_novelty_claim", "not_empirical_calibration",
                             "not_a_learned_joint_probability_model", "not_a_new_statistical_certificate"],
        "assumptions": ["fixed categorical winner map and candidate order", "primary cases use independent Bernoulli laws; common-shock kernel checks and dependence counterexamples are separate",
                        "complete winner-event scope verified exhaustively", "valid old-law gap lower certificates supplied as an assumption",
                        "strict transfer inequality excludes ties", "epsilon comes from declared probability laws, never ECE",
                        "path sensitivities protect only the declared endpoint pair", "box bounds require all queried laws to stay independent inside the declared box"],
        "computational_contract": {"hard_variable_limit": MAX_VARIABLES, "exact_arithmetic": "fractions.Fraction",
                                   "max_full_worlds_per_law": max(1 << m.n for m in models),
                                   "box_exact_scope_limit": box_limit,
                                   "exact_box_supremum_cost": "s*2^(s-1) parameter vertices times 2^(s-1) other-world masks, before degenerate-coordinate savings",
                                   "large_box_fallback": "universal <=1 pivotal-probability bound, explicitly marked",
                                   "sampling_or_external_data": False},
        "config": {"perturbation_steps": [str(x) for x in steps], "certificate_factors": [str(x) for x in factors], "patterns": list(patterns)},
        "models": model_summaries, "cases": cases, "counterexamples": examples,
        "common_shock_validation": common_shock,
        "summary": {"models": len(models), "law_pairs": len(cases), "certificate_checks": certificate_count,
                    "old_unique_certificate_checks": eligible_count,
                    "nonempty_transfer_counts": counts,
                    "nonempty_transfer_rates_all_checks": {name: value / certificate_count for name, value in counts.items()},
                    "nonempty_transfer_rates_old_unique": {name: value / eligible_count if eligible_count else None for name, value in counts.items()},
                    "extra_certified_over_full_TV": opportunities,
                    "extra_certified_over_scope_TV": opportunities_vs_scope,
                    "nonzero_shift_certificate_checks": shifted_certificate_count,
                    "nonzero_shift_nonempty_transfer_counts": shifted_counts,
                    "nonzero_shift_nonempty_transfer_rates": {
                        name: value / shifted_certificate_count if shifted_certificate_count else None
                        for name, value in shifted_counts.items()},
                    "rate_denominator_note": "Configured grid cases, not independent real queries; zero-parameter-shift cases are additionally separated.",
                    "violations": len(violations), "violation_details": violations},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8-sig")) if args.config else {}
    report = run_exact_validation(config)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    print(json.dumps(report["summary"], ensure_ascii=False))


if __name__ == "__main__":
    main()
