"""Read-only, manifest-verified comparison of a handoff ZIP/root and a checkout."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from collections import Counter
from pathlib import Path, PurePosixPath


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def expected_hash(entry):
    return entry if isinstance(entry, str) else entry["sha256"]


def safe_path(name):
    p = PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts and "\\" not in name


def classify(expected: bytes, actual: bytes, name: str) -> str:
    if actual == expected:
        return "byte_equal"
    # Newline normalization is diagnostic for text, never a byte-integrity pass.
    if not name.endswith(".bin") and b"\0" not in expected and b"\0" not in actual:
        try:
            a = actual.decode("utf-8")
            b = expected.decode("utf-8")
        except UnicodeDecodeError:
            return "content_different"
        if a.replace("\r\n", "\n").replace("\r", "\n") == b.replace("\r\n", "\n").replace("\r", "\n"):
            return "newline_only"
    return "content_different"


def compare(bundle: Path, repo: Path, scope="all"):
    archive = zipfile.ZipFile(bundle) if bundle.is_file() else None
    try:
        if archive:
            names = archive.namelist()
            if len(names) != len(set(names)) or not all(safe_path(n) for n in names):
                raise ValueError("duplicate or unsafe ZIP member")
            if archive.testzip() is not None:
                raise ValueError("ZIP CRC failed")
            read = archive.read
        else:
            def read(name):
                p = bundle / name
                if not safe_path(name) or not p.resolve().is_relative_to(bundle.resolve()):
                    raise ValueError("bundle path escapes root")
                return p.read_bytes()
        manifest = json.loads(read("HANDOFF_MANIFEST.json"))
        rows = []
        for name, entry in sorted(manifest["files"].items()):
            if not safe_path(name):
                raise ValueError("unsafe manifest path")
            reference = read(name)
            want = expected_hash(entry)
            if sha256(reference) != want:
                raise ValueError(f"bundle differs from its manifest: {name}")
            if scope == "python" and not (name.endswith(".py") and name.startswith(("src/", "scripts/", "tests/", "nodes/05_icde_query_engine/experiments/"))):
                continue
            p = repo / name
            if not p.resolve().is_relative_to(repo.resolve()):
                raise ValueError("checkout path escapes root")
            actual = p.read_bytes() if p.is_file() else None
            state = "missing" if actual is None else classify(reference, actual, name)
            rows.append({"path": name, "state": state, "expected_sha256": want,
                         "actual_sha256": sha256(actual) if actual is not None else None})
        counts = {key: Counter(r["state"] for r in rows)[key] for key in ("byte_equal", "newline_only", "content_different", "missing")}
        return {"format": "icde-handoff-checkout-comparison-v1", "bundle": str(bundle.resolve()),
                "repo": str(repo.resolve()), "scope": scope, "reference_manifest_verified": True,
                "total": len(rows), "counts": counts,
                "all_byte_equal": counts["byte_equal"] == len(rows), "files": rows}
    finally:
        if archive:
            archive.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--bundle", type=Path, required=True)
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--scope", choices=("all", "python"), default="all")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    result = compare(args.bundle, args.repo, args.scope)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "files"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
