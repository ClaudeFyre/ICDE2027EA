"""P1 update -> refresh -> query closed loop on the toy graph.

Runs a controlled revision sequence on ``data/toy/exact_world_minimal``:

  rev0  baseline probabilities
  rev1  edge probability flip down  (s:alice lives_in s:city 0.80 -> 0.10)
  rev2  edge probability flip back  (0.10 -> 0.80)
  rev3  add generation             (add s:alice --s:knows--> s:bob at 0.70)
  rev4  delete generation          (tombstone s:bob lives_in s:city)
  rev5  shared-factor update       (city-hub factor weight 0.0 -> 0.5)

At every revision we:
  * attempt to serve a request bound to the *previous* revision against the new
    snapshot -- it MUST be rejected (conservative invalidation); stale_success=0;
  * refresh (re-sample worlds / rebind the scorer) and re-query;
  * compare the shared-batched answer item-for-item against the independent
    recompute path (winner/status/certified_winner/samples/counts/evidence).

Event-id dedup is exercised by replaying an update event id twice (same payload
-> idempotent skip; conflicting payload -> reject).

The whole run is deterministic (fixed seed). Running the script twice must
produce byte-identical output JSON.
"""

from __future__ import annotations

import argparse
import copy
import json
import sys
from dataclasses import asdict, replace
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC = REPO_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones.toy import ToyStructuralBackbone  # noqa: E402
from pkgea.contracts import dataset_content_digest  # noqa: E402
from pkgea.query.modal import (  # noqa: E402
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    execute_modal_queries,
    identity,
)
from pkgea.samplers import monte_carlo_worlds  # noqa: E402

TOY_DIR = REPO_ROOT / "data" / "toy" / "exact_world_minimal"
CODE_ID = "icde_baseline_suite-v1"
SCORER_ID = "toy-degree-lexical-original-float"
MODEL_ID = "no-trained-model"
SCHEMA_ID = "canonical-v1"
N_WORLDS = 256
SEED = 17
DELTA = 0.05
BUDGET = 64


class RevisionContext:
    def __init__(self, rev_id, backbone, confidences, factors):
        self.rev_id = rev_id
        self.backbone = backbone
        self.confidences = list(confidences)
        self.factors = factors
        graph = dataset_content_digest(TOY_DIR)
        comp = {
            "graph": graph,
            "model": MODEL_ID,
            "probability": identity(list(self.confidences)),
            "factors": factors,
            "schema": SCHEMA_ID,
            "code": CODE_ID,
            "scorer": SCORER_ID,
        }
        self.snapshot = ModalSnapshot(**comp)
        self.components = comp
        worlds = tuple(monte_carlo_worlds(self.confidences, N_WORLDS, SEED))
        self.stream = IIDWorldStream(self.snapshot.digest, SEED, worlds)
        self.scorer = ModalScorer(self.snapshot.digest, backbone.score_subset)


def base_queries(snapshot_digest):
    return [
        ModalQuery("s:alice", ("t:alice", "t:bob", "t:city"), snapshot_digest, BUDGET, DELTA),
        ModalQuery("s:bob", ("t:alice", "t:city", "t:bob"), snapshot_digest, BUDGET, DELTA),
    ]


def fingerprints(result_list):
    return [
        {
            "query_id": r["query_id"],
            "status": r["status"],
            "estimated_winner": r["estimated_winner"],
            "certified_winner": r["certified_winner"],
            "samples_used": r["samples_used"],
            "counts": r["counts"],
            "evidence_digest": r["evidence_digest"],
        }
        for r in result_list
    ]


def run_queries(ctx):
    qs = base_queries(ctx.snapshot.digest)
    independent = execute_modal_queries(
        qs, ctx.snapshot, ctx.stream, ctx.scorer,
        shared=False, cache=None, batch_size=16, minimum_samples=32,
    )
    shared = execute_modal_queries(
        qs, ctx.snapshot, ctx.stream, ctx.scorer,
        shared=True, cache=None, batch_size=16, minimum_samples=32,
    )
    return independent, shared


def attempt_stale_query(new_ctx, old_ctx):
    """Serve old-revision queries against the new snapshot; expect rejection."""
    qs_old = base_queries(old_ctx.snapshot.digest)
    try:
        execute_modal_queries(
            qs_old, new_ctx.snapshot, new_ctx.stream, new_ctx.scorer,
            shared=True, cache=None, batch_size=16, minimum_samples=32,
        )
        return "STALE_SUCCESS"
    except ValueError as exc:
        return f"rejected: {exc}"


class EventLedger:
    """event_id dedup: same payload idempotent, conflicting payload rejected."""

    def __init__(self):
        self._seen = {}

    def apply(self, event_id, payload):
        if event_id in self._seen:
            if self._seen[event_id] == payload:
                return "duplicate_idempotent"
            return "conflict_rejected"
        self._seen[event_id] = payload
        return "applied"


def modified_backone_add(backbone):
    triples = list(backbone.triples)
    triples.append({
        "graph_id": "source", "head_id": "s:alice", "relation_id": "s:knows",
        "tail_id": "s:bob", "confidence": "0.70", "confidence_type": "calibrated_probability",
        "confidence_source": "controlled_update", "normalization_method": "identity",
        "timestamp": "", "dependency_group": "", "evidence_id": "ev:add1",
    })
    return replace(backbone, triples=triples)


def modified_backbone_delete(backbone):
    triples = [
        t for t in backbone.triples
        if not (t["head_id"] == "s:bob" and t["tail_id"] == "s:city")
    ]
    return replace(backbone, triples=triples)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path,
                        default=REPO_ROOT / "nodes" / "05_icde_query_engine" / "results" / "icde_p1_20261009" / "update_loop.json")
    args = parser.parse_args(argv)

    base = ToyStructuralBackbone.from_dataset(TOY_DIR)
    base_conf = [float(r["confidence"]) for r in base.triples]
    ledger = EventLedger()

    revisions = []
    n_stale_rejected = 0
    n_mismatches = 0

    def step(ctx, prev_ctx, label):
        nonlocal n_stale_rejected, n_mismatches
        entry = {"revision": ctx.rev_id, "label": label,
                 "factors": ctx.factors, "confidences": list(ctx.confidences),
                 "snapshot_digest": ctx.snapshot.digest}
        if prev_ctx is not None:
            outcome = attempt_stale_query(ctx, prev_ctx)
            entry["stale_request_vs_new_snapshot"] = outcome
            if outcome == "STALE_SUCCESS":
                entry["stale_success"] = 1
            else:
                entry["stale_success"] = 0
                n_stale_rejected += 1
        else:
            entry["stale_request_vs_new_snapshot"] = "n/a (first revision)"
            entry["stale_success"] = 0
        ind, shared = run_queries(ctx)
        entry["independent_fingerprints"] = fingerprints(ind["results"])
        entry["shared_fingerprints"] = fingerprints(shared["results"])
        match = entry["independent_fingerprints"] == entry["shared_fingerprints"]
        entry["shared_matches_independent"] = match
        if not match:
            n_mismatches += 1
        entry["independent_work"] = ind["work"]
        revisions.append(entry)

    prev_ctx = None
    cur = RevisionContext("rev0", base, base_conf, "independent")
    step(cur, prev_ctx, "baseline"); prev_ctx = cur

    # rev1: flip edge0 0.80 -> 0.10
    c1 = list(base_conf); c1[0] = 0.10
    ledger.apply("ev:flip-down", {"edge": 0, "old": 0.80, "new": 0.10})
    cur = RevisionContext("rev1", base, c1, "independent")
    step(cur, prev_ctx, "edge0 0.80->0.10"); prev_ctx = cur

    # rev2: flip edge0 back 0.10 -> 0.80 (event_id dedup replay test)
    ledger.apply("ev:flip-back", {"edge": 0, "old": 0.10, "new": 0.80})
    dedup_replay = ledger.apply("ev:flip-back", {"edge": 0, "old": 0.10, "new": 0.80})
    conflict_replay = ledger.apply("ev:flip-back", {"edge": 0, "old": 0.10, "new": 0.50})
    cur = RevisionContext("rev2", base, list(base_conf), "independent")
    step(cur, prev_ctx, "edge0 0.10->0.80"); prev_ctx = cur

    # rev3: add generation
    b3 = modified_backone_add(base)
    c3 = list(base_conf) + [0.70]
    ledger.apply("ev:add", {"fact": "s:alice/s:bob"})
    cur = RevisionContext("rev3", b3, c3, "independent")
    step(cur, prev_ctx, "add s:alice knows s:bob"); prev_ctx = cur

    # rev4: delete generation
    b4 = modified_backbone_delete(base)
    c4 = [p for i, p in enumerate(base_conf) if i != 1]
    ledger.apply("ev:delete", {"edge": 1})
    cur = RevisionContext("rev4", b4, c4, "independent")
    step(cur, prev_ctx, "delete s:bob lives_in s:city"); prev_ctx = cur

    # rev5: factor update
    cur = RevisionContext("rev5", base, list(base_conf), "factor:city_hub=0.5")
    step(cur, prev_ctx, "factor city_hub 0.0->0.5"); prev_ctx = cur

    result = {
        "format": "icde-p1-update-loop-v1",
        "host_informal": "wall-clock not used; counting/identity metrics only",
        "seed": SEED,
        "n_worlds": N_WORLDS,
        "budget": BUDGET,
        "delta": DELTA,
        "stale_success_total": sum(r["stale_success"] for r in revisions),
        "n_stale_rejected": n_stale_rejected,
        "n_mismatches_vs_independent": n_mismatches,
        "dedup": {"duplicate_idempotent": dedup_replay, "conflict_rejected": conflict_replay},
        "revisions": revisions,
        "acceptance": {
            "stale_success_zero": sum(r["stale_success"] for r in revisions) == 0,
            "all_revisions_match_independent": n_mismatches == 0,
            "dedup_works": dedup_replay == "duplicate_idempotent" and conflict_replay == "conflict_rejected",
        },
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
                        encoding="utf-8", newline="\n")
    print(json.dumps({
        "stale_success": result["stale_success_total"],
        "n_stale_rejected": n_stale_rejected,
        "n_mismatches": n_mismatches,
        "dedup": result["dedup"],
        "acceptance": result["acceptance"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
