"""Write result tables directly from frozen analysis; no extra experiments."""
from pathlib import Path
import statistics
from icde_grouped_inventory_20261108 import ROOT, load, save, sha
from icde_portfolio_study_20261108 import BASE


def main():
    a,s,p=load(BASE/'analysis.json'),load(BASE/'summary.json'),load(BASE/'protocol.json')
    fair=[]
    for r,t in zip(a['curves'],a['feature_adjusted_curves']):
        assert (r['objective'],r['budget_ms'])==(t['objective'],t['budget_ms'])
        fair.append({'objective':r['objective'],'budget_ms':r['budget_ms'],
            'fixed_without_routing_capped_loss_ms':r['fixed_capped_loss_ms'],
            'oracle_with_feature_capped_loss_ms':t['oracle_capped_loss_ms'],
            'reduction_percent':100*(r['fixed_capped_loss_ms']-t['oracle_capped_loss_ms'])/r['fixed_capped_loss_ms'],
            'fixed_without_routing_successes':r['fixed_successes'],
            'oracle_with_feature_successes':t['oracle_successes']})
    save(BASE/'routing_overhead_comparison.json',{'kind':'feature_cost_added_to_oracle_only',
        'analysis_sha256':sha(BASE/'analysis.json'),'rows':fair,
        'limitation':'only measured signature/count-size extraction; excludes fitting, inference and storage for an unimplemented router'})
    lines=['# 方法选择上界：全部结构可行历史查询的验证（2026-11-08）','',
        '[说明文本已清理]','',
        '## 1. 冻结范围与输出语义','',
        '- 从576个历史准备查询中，按既有静态盘点的 `prototype_eligible` 选择全部148个，DW 85、ENFR 63；'
        '其中38个scope≥20。未按本轮结果剔除查询。其余428个未进入本实验，不能向全体推广。',
        '- 148个查询×4方法×3重复=1,776次计时运行。种子1009/1013/1019，q=.9，τ=.25，'
        '计数状态上限32768、计数划分上限127、参数划分上限31。方法次序按查询及重复轮转。',
        '- 真值由计时之外的完整计数张量与精确有理数端点轨道求值得到：101个查询存在统一严格众数，47个不存在。'
        '“不存在统一严格众数”可包含并列边界，不必然意味着众数反转。参考结果不传给任何被测策略。',
        '- 主目标：交付有效稳定证书；非稳定证明、耗尽和超时均不计作稳定批准。次目标：完成稳定或不存在统一严格众数的证明。'
        'MC无否定证明接口；次目标差距包含接口能力差异。',
        '- 四种方法均支付相同的分组及直接根界前端。完整精确法另有计数赢家常量快路径；'
        'partial_joint采用standard_mass，partial_factor采用factor_mass；不重复比较已无独立收益的目标调度。',
        '[说明文本已清理]','',
        '## 2. 计时、上界与成本口径','',
        '单次运行设100ms协作式检查点上限。原生数值运算不能被强行中断，晚到结果丢弃并记录超额时间。'
        '1/2/5/10/20/50ms曲线从实际首个最终证明的完成时间统计，不是分别执行的硬期限实验。'
        '方法内部的分组、矩阵构造和统计构造计时；数据准备、准备查询加载、真值求解、持久化与审计分开。'
        '正式计时前在已知ENFR q175对四方法各预热一次。','',
        '最佳固定方法可在每个交付门槛及目标下事后选择，但整个工作负载只用一种方法。'
        '逐查询上界则对每个查询，在同样三次重复上选成功次数最多的方法；并列时选封顶损失较低者。'
        '它对该查询的三个重复固定使用一个方法，没有逐重复挑最快者。成本上界另按三次平均封顶损失最小化。'
        '这仍使用未来结果且不支付真实选择器成本，只是这四个固定求解器间“一次选择”的经验参照；'
        '不限制共享中间工作的新混合算法，也不是未来分布上的理论上界。','',
        '封顶损失：在期限B内完成所需证明，记实测完成时间；其他情况记B。'
        '它是评价损失，并非实际CPU时间。下面另列真实总耗时、超时和原生调用超额。','',
        '## 3. 稳定证书交付（主目标）','',
        '| 门槛ms | 最佳固定方法 | 固定交付/444 | 逐查询上界/444 | 增量百分点 | 稳定查询召回：固定→上界 | 封顶损失减少 |',
        '| --- | --- | --- | --- | --- | --- | --- |']
    for r in a['curves']:
        if r['objective']=='stable_certificate':
            lines.append(f"| {r['budget_ms']:g} | {r['fixed_coverage_method']} | {r['fixed_successes']} | {r['oracle_successes']} | {r['coverage_gain_pp']:.2f} | {100*r['fixed_stable_recall']:.1f}%→{100*r['oracle_stable_recall']:.1f}% | {r['capped_loss_reduction_percent']:.1f}% |")
    lines += ['', '稳定查询召回的分母是101×3=303；总体交付率的分母是148×3=444。'
        '100ms的68.24%总体交付率已达到此工作负载的稳定查询比例，不能将其余31.76%解释为漏认证。','',
        '## 4. 完整判定（次目标）','',
        '| 门槛ms | 固定完成/444 | 逐查询上界/444 | 增量百分点 | 固定封顶损失ms | 上界封顶损失ms |',
        '| --- | --- | --- | --- | --- | --- |']
    for r in a['curves']:
        if r['objective']=='complete_classification':
            lines.append(f"| {r['budget_ms']:g} | {r['fixed_successes']} | {r['oracle_successes']} | {r['coverage_gain_pp']:.2f} | {r['fixed_capped_loss_ms']:.3f} | {r['oracle_capped_loss_ms']:.3f} |")
    lines += ['', '该目标下各门槛的最佳固定方法均为dense_exact。100ms时两者都完成444/444，'
        '事后成本上界从8.918ms降至6.437ms（27.82%）；因两者都完成全部判定，这两个数也对应所选完成路径的平均实测计算时间。'
        '上界依然不是已实现方法的平均时间。','',
        '## 5. 互补来自哪里，选择成本会不会吃掉空间','',
        '5ms新增49次稳定交付，分布在17个查询：10个由partial_factor提供（30次），7个由MC提供（19次）。'
        '其中16个查询从0/3变为3/3，只有ENFR q133由2/3变为3/3。'
        '因此主差距不只来自交付边界附近的微小计时波动；仍不能据此声称17个新独立样本。'
        '未发现非稳定查询上的完整判定覆盖增益。','',
        '5ms事后覆盖选择分布：dense_exact 89、partial_factor 35、MC 14、partial_joint 10。'
        '这些是事后所选策略数量，包含已有共同根界上的微小时间差，不能全部当作各策略独有的查询。'
        '在逐图/逐规模子组内重新选择最佳固定方法后，5ms稳定证书覆盖上界增益分别为：'
        'DW 8.24、ENFR 11.64、scope≥20 4.39、scope<20 3.03个百分点。'
        '分组先验本身可能吃掉一部分总体空间，必须用简单分组规则作强对照。','',
        f"已实测分组签名与计数状态数提取：中位{a['feature_probe_ms']['median']:.4f}ms、均值{a['feature_probe_ms']['mean']:.4f}ms、最大{a['feature_probe_ms']['maximum']:.4f}ms。"
        '只给逐查询上界增加该次特征提取时间、保持固定基线无选择开销，得到：','',
        '| 目标 | 门槛ms | 固定损失ms（无选择开销） | 上界损失ms（加特征开销） | 剩余减少 |',
        '| --- | --- | --- | --- | --- |']
    for r in fair:
        if r['budget_ms'] in (5,10,100):
            name='稳定证书' if r['objective']=='stable_certificate' else '完整判定'
            lines.append(f"| {name} | {r['budget_ms']:g} | {r['fixed_without_routing_capped_loss_ms']:.3f} | {r['oracle_with_feature_capped_loss_ms']:.3f} | {r['reduction_percent']:.2f}% |")
    lines += ['', '5/10/100ms的覆盖增量在这项特征开销敏感性计算中不变。'
        '特征提取未吃掉主要空间，但这没有计入尚未实现的模型推断、训练、索引维护或服务加载成本。'
        '`analysis.json`中的feature_adjusted_curves给两端都加特征开销；上表和图(c)改用更合适的非对称比较，'
        '完整数字另存routing_overhead_comparison.json。','',
        '## 6. 实际运行成本与超时','',
        '| 方法 | stable | nonuniform | unresolved | timeout | 实际总计算秒 | 最大超额ms |',
        '| --- | --- | --- | --- | --- | --- | --- |']
    for method,c in a['measured_costs'].items():
        o=c['outcomes']
        lines.append(f"| {method} | {o.get('stable',0)} | {o.get('nonuniform',0)} | {o.get('unresolved',0)} | {o.get('timeout',0)} | {c['actual_total_seconds']:.3f} | {c['maximum_overrun_ms']:.3f} |")
    lines += ['', '每行444次计时运行。MC最严重的原生运算超额为205.686ms，即一次调用总计约305.686ms后被丢弃。'
        '这明确排除了硬实时SLA解释。dense_exact最大完成时间80.300ms，所有444次在100ms内完成。'
        '总计算时间包含失败路径消耗，不能用表中的封顶损失替代。','',
        '## 7. 风险与审计','',
        '精确方法为确定性证明；MC保留每查询每运行0.025+0.025=0.05的统计风险合同。'
        '三次重复不合并为更高置信证书，也不声称整个工作负载错误概率≤0.05。'
        '对固定查询，只有一个MC接口；任何最终错误证书均落在这个接口的错误事件中，'
        '因此在独立评价随机性上冻结的一次选择无需为三个确定性接口额外均分风险。'
        '这不是选择器的泛化证明，当前事后选择不能替代前瞻验证。','',
        f"- 运行内通过{s['checks']:,}项检查，含精确真值、区域完整覆盖、区域赢家包络、端点反例与时钟恢复。",
        '- 独立汇总核验通过18,930项检查：冻结哈希、NPZ CRC、148×4×3完整矩阵、逐次文件一致、超时丢弃、'
        '真值一致、逐查询而非逐重复选择、封顶损失及真实耗时重算。',
        '- 该核验共享既有精确参考与数值内核，不等于第二套独立精确求值实现；'
        '当前控制也不是SPROUT/C-FOVE/credal-circuit已发表完整系统的复现。',
        '- 历史数值源文件与输入哈希前后不变。本轮输出写入新attempt1，没有更新旧主稿或旧PDF。','',
        '## 8. 研究决策','',
        '值得保留“在严格短交付期限内选择求值方法”的有限研究机会：'
        '5–10ms下稳定交付上界提高约9–11个百分点，初步结构特征开销不足以解释掉它。'
        '100ms下覆盖空间已经消失，不能继续以“解决更多稳定查询”为无限预算论点。'
        '完整判定成本仍有约27%的事后空间，但需要实际选择器及跨数据/评分器验证才构成算法结果。','',
        '下一道门槛应是简单可部署选择规则能否兑现空间：仅允许推断前可得特征，'
        '首先比较按图/计数状态的朴素阈值、简单成本模型与固定精确法；'
        '固定候选规则、预算、随机种子与数据划分后，再做不使用评价结果调参的验证。'
        '应同时报告错误路由代价和完整加载/特征/推断时间。'
        '若对朴素分组或成本模型没有独立改进，则方法选择作为系统工程组件，而不单列ICDE创新点。','',
        '本轮不自动训练选择器、不再开新确认矩阵、不声称论文已达强ICDE接收水平。'
        '原有真实准确率与事实概率校准缺口没有被本轮实验解决。','',
        '## 产物','',
        '- [四面板结果图PNG](figures_final/portfolio_headroom.png) / [PDF](figures_final/portfolio_headroom.pdf)',
        '- [冻结协议](protocol.json)、[汇总](summary.json)、[分析](analysis.json)、[独立验证](validation.json)',
        '- [单侧选择开销对照](routing_overhead_comparison.json)；cases/与references/为逐次及逐查询文件。','']
    target=BASE/'RESULTS_ZH.md'
    with target.open('x',encoding='utf-8') as f:f.write('\n'.join(lines))
    paths=[target,BASE/'protocol.json',BASE/'summary.json',BASE/'analysis.json',BASE/'validation.json',
           BASE/'routing_overhead_comparison.json',BASE/'figures_final/portfolio_headroom.png',
           BASE/'figures_final/portfolio_headroom.pdf']
    paths += [ROOT/'scripts'/name for name in ('icde_portfolio_validate_20261108.py','icde_portfolio_figures_20261108.py','icde_portfolio_writeup_20261108.py')]
    save(BASE/'artifact_manifest.json',{'kind':'post_run_reporting_provenance',
        'sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in paths}})
    print(target)


if __name__=='__main__':main()
