"""Frozen stronger population controls and a correction to proper-score reporting.

The first diagnostic sorted labels for ranking and then paired them with the
unsorted confidences for Brier/logloss. Ranking metrics were unaffected.
Old frozen sources/results remain intact; this new run supersedes those scores.
"""
import argparse
from fractions import Fraction as Q
import math
from pathlib import Path
import time
import numpy as np

import icde_prospective_20261107 as old
import icde_alignment_signal_20261108 as signal
from icde_grouped_inventory_20261108 import ROOT,load,save,sha,identities
from icde_grouped_exact_20261108 import compile_counts,solve_counts
from icde_association_study_20261108 import BASE as INITIAL
from run_vldb_interval_gate_v1 import clipped_box

BASE=INITIAL.parent/'strong_control_and_signal_correction_attempt1'
ORIGINAL_METRICS=signal.metrics


def corrected_metrics(y,confidence):
    result=ORIGINAL_METRICS(y,confidence)
    y=np.asarray(y,dtype=float);confidence=np.asarray(confidence,dtype=float)
    clipped=np.clip(confidence,1e-12,1-1e-12)
    result['brier']=float(np.mean((confidence-y)**2))
    result['logloss']=float(-np.mean(y*np.log(clipped)+(1-y)*np.log1p(-clipped)))
    return result


def population_controls(compiled,exact,k,nominal):
    weights=np.asarray(1,dtype=object);den=1
    q=Q.from_float(float(nominal));a,b=q.numerator,q.denominator
    for signature,edges,endpoint in compiled['groups']:
        n=len(edges)
        vector=np.asarray([math.comb(n,j)*a**j*(b-a)**(n-j) for j in range(n+1)],dtype=object)
        weights=np.multiply.outer(weights,vector);den*=b**n
    if sum(map(int,weights.flat))!=den:raise AssertionError('nominal distribution normalization failed')
    nominal_pi=[Q(sum(map(int,weights[compiled['winners']==c])),den) for c in range(k)]
    minimum=[Q(int(np.min(values)),exact['denominator']) for values in exact['numerators']]
    maximum=[Q(int(np.max(values)),exact['denominator']) for values in exact['numerators']]
    if any(not lo<=q<=hi for q,lo,hi in zip(nominal_pi,minimum,maximum)):
        raise AssertionError('nominal law outside exact marginal ranges')
    epsilon=max(max(abs(q-lo),abs(q-hi)) for q,lo,hi in zip(nominal_pi,minimum,maximum))
    scalar=[];separate=[]
    for w in range(k):
        scalar.append(min(nominal_pi[w]-nominal_pi[d] for d in range(k) if d!=w)-2*epsilon)
        separate.append(min(minimum[w]-maximum[d] for d in range(k) if d!=w))
        truth=min(Q(r['minimum_gap_exact']) for r in exact['pairs'] if r['candidate']==w)
        if max(scalar[w],separate[w])>truth:raise AssertionError('population sufficient bound exceeds true gap')
    safe=exact['uniform_winners']
    for gaps in (scalar,separate):
        if any(g>0 and w not in safe for w,g in enumerate(gaps)):
            raise AssertionError('invalid population certificate')
    return {'nominal_probabilities_exact':list(map(str,nominal_pi)),
            'candidate_probability_minima_exact':list(map(str,minimum)),
            'candidate_probability_maxima_exact':list(map(str,maximum)),
            'optimal_uniform_candidate_drift_exact':str(epsilon),
            'oracle_scalar_gaps_exact':list(map(str,scalar)),
            'separate_event_gaps_exact':list(map(str,separate)),
            'oracle_scalar_winners':[w for w,g in enumerate(scalar) if g>0],
            'separate_event_winners':[w for w,g in enumerate(separate) if g>0]}


def freeze(out):
    if out.exists():raise FileExistsError(out)
    parent=load(INITIAL/'protocol.json')
    code=dict(parent['code_sha256'])
    for name in ('icde_association_followup_20261108.py','test_icde_association_followup_20261108.py'):
        code['scripts/'+name]=sha(ROOT/'scripts'/name)
    inputs=dict(parent['input_sha256'])
    for name in ('protocol.json','summary.json','quantifier_census.json','alignment_signal.json','static_diagnosis.json'):
        path=INITIAL/name;inputs[path.relative_to(ROOT).as_posix()]=sha(path)
    save(out/'protocol.json',{'kind':'strong_population_comparison_and_proper_score_correction',
        'parent_protocol_sha256':sha(INITIAL/'protocol.json'),'code_sha256':code,'input_sha256':inputs,
        'cases':[r for r in parent['all_cases'] if r['prototype_eligible']],
        'nominal':.9,'tau':.25,'state_cap':32768,
        'strong_controls':['optimal global candidate-event drift in scalar 2epsilon condition',
                           'separately exact minimum winner and maximum competitor event probabilities'],
        'interpretation':'population sufficiency audit; exact oracle controls pay full reference cost and are not measured zero-cost online policies; no full credal-circuit reproduction',
        'correction':'Brier/logloss in initial signal metrics paired sorted y with unsorted confidence. Recompute using original paired observations; preserve all original inputs, folds, features, fits and outputs',
        'primary_signal_unchanged':'same source-fivefold ridge=1; 1000 identical-source-bootstrap reps; no hyperparameter changes or new queries',
        'frozen_at_unix':time.time()})
    print('Frozen stronger population controls and proper-score correction',flush=True)


def preflight(out):
    p=load(out/'protocol.json');checks=identities(p,False)
    if (out/'summary.json').exists():raise FileExistsError('completed output exists')
    save(out/'recovery.json',{'status':'PASS','checks':checks})
    print('Preflight PASS',checks,flush=True)


def run(out):
    p=load(out/'protocol.json')
    if load(out/'recovery.json')['status']!='PASS':raise AssertionError('preflight required')
    checks=identities(p,False);rows=[]
    original={(r['graph'],r['rank']):r for r in load(INITIAL/'quantifier_census.json')['rows']}
    for case in p['cases']:
        kernel,meta=old.read_query(case['graph'],case['rank'])
        low,high=clipped_box(np.full(case['scope_edges'],p['nominal']),p['tau'])
        compiled=compile_counts(kernel,low,high,p['state_cap'])
        exact=solve_counts(compiled,len(kernel.candidates))
        controls=population_controls(compiled,exact,len(kernel.candidates),p['nominal'])
        rows.append({**original[case['graph'],case['rank']],**controls})
        checks+=1
    mechanism={'queries':len(rows),'robust_queries':sum(bool(r['uniform_winners']) for r in rows),
        'pointwise_omissions':sum(r['quantifier_omission'] for r in rows),
        'oracle_scalar_certifiable':sum(bool(r['oracle_scalar_winners']) for r in rows),
        'separate_event_certifiable':sum(bool(r['separate_event_winners']) for r in rows),
        'pointwise_omissions_fixed_by_oracle_scalar':sum(r['quantifier_omission'] and bool(r['oracle_scalar_winners']) for r in rows),
        'pointwise_omissions_fixed_by_separate_events':sum(r['quantifier_omission'] and bool(r['separate_event_winners']) for r in rows),
        'robust_but_separate_events_fail':sum(bool(r['uniform_winners']) and not r['separate_event_winners'] for r in rows)}
    save(out/'strong_population_controls.json',{'summary':mechanism,'rows':rows})
    previous=load(INITIAL/'alignment_signal.json')
    signal.metrics=corrected_metrics
    corrected=signal.diagnose(previous['oof_rows'],1000)
    for oldrow,newrow in zip(previous['oof_rows'],corrected['oof_rows']):
        for key in ('fold','baseline_probability','extended_probability','prediction','correct','stable'):
            if oldrow[key]!=newrow[key]:raise AssertionError('reporting correction changed a fit or prediction')
        checks+=1
    for subgroup in previous['subgroups']:
        for model in ('baseline','baseline_plus_stability'):
            for metric in ('aurc','auroc','accuracy','risk_at_coverage'):
                if previous['subgroups'][subgroup][model][metric]!=corrected['subgroups'][subgroup][model][metric]:
                    raise AssertionError('ranking metric changed during proper-score correction')
            checks+=1
    corrected['supersedes_proper_scores_in']=str((INITIAL/'alignment_signal.json').relative_to(ROOT))
    save(out/'alignment_signal_corrected.json',corrected)
    checks+=identities(p,False)
    save(out/'summary.json',{'status':'PASS','checks':checks,'mechanism':mechanism,
         'corrected_signal_differences':corrected['differences'],
         'protocol_sha256':sha(out/'protocol.json'),
         'outputs_sha256':{name:sha(out/name) for name in ('strong_population_controls.json','alignment_signal_corrected.json')},
         'old_fits_and_ranking_metrics_unchanged':True,'historical_sources_unchanged':True})
    print({'status':'PASS','mechanism':mechanism,'signal':corrected['differences']},flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=('freeze','preflight','run'),required=True)
    parser.add_argument('--output',type=Path,default=BASE)
    args=parser.parse_args()
    {'freeze':freeze,'preflight':preflight,'run':run}[args.phase](args.output.resolve())
