"""Retrospective query oracle: choose one policy over repeats, never per repeat."""
import argparse
from collections import Counter
from pathlib import Path
import statistics

from icde_grouped_inventory_20261108 import load, save, sha
from icde_portfolio_study_20261108 import BASE, POLICIES


def requested(row, objective):
    return row['status'] == 'stable' or (objective == 'complete_classification' and row['status'] == 'nonuniform')


def evaluate(rows, references, budget, objective, add_features=False):
    methods = list(POLICIES)
    queries = [(r['graph'],r['rank']) for r in references]
    times = {(r['graph'],r['rank']):r['feature_seconds'] for r in references}
    table = {(q,m):[] for q in queries for m in methods}
    for row in rows:
        q,m = (row['graph'],row['rank']),row['policy']
        elapsed = row['compute_seconds'] + (times[q][row['repeat']] if add_features else 0.)
        delivered = requested(row,objective) and elapsed <= budget
        table[q,m].append((int(delivered), elapsed if delivered else budget))
    if any(len(values)!=3 for values in table.values()):
        raise AssertionError('need exactly three repeats per query and policy')
    # Oracle selects ONCE per query, using the aggregate of all three repeats.
    aggregate = {key:(sum(a for a,b in values),sum(b for a,b in values)) for key,values in table.items()}
    totals = {m:(sum(aggregate[q,m][0] for q in queries),sum(aggregate[q,m][1] for q in queries)) for m in methods}
    fixed = min(methods,key=lambda m:(-totals[m][0],totals[m][1],m))
    fixed_cost = min(methods,key=lambda m:(totals[m][1],-totals[m][0],m))
    chosen = {q:min(methods,key=lambda m:(-aggregate[q,m][0],aggregate[q,m][1],m)) for q in queries}
    cost_chosen = {q:min(methods,key=lambda m:(aggregate[q,m][1],-aggregate[q,m][0],m)) for q in queries}
    n = len(rows)//len(methods)
    oracle_success = sum(aggregate[q,chosen[q]][0] for q in queries)
    oracle_loss = sum(aggregate[q,cost_chosen[q]][1] for q in queries)/n
    fixed_loss = totals[fixed_cost][1]/n
    stable = sum(bool(r['uniform_winners']) for r in references)*3
    return {'budget_ms':budget*1000,'objective':objective,'feature_cost_added':add_features,
        'queries':len(queries),'query_repeats':n,'true_stable_query_repeats':stable,
        'fixed_coverage_method':fixed,'fixed_successes':totals[fixed][0],
        'oracle_successes':oracle_success,'fixed_delivery':totals[fixed][0]/n,
        'oracle_delivery':oracle_success/n,'coverage_gain_pp':100*(oracle_success-totals[fixed][0])/n,
        'fixed_stable_recall':totals[fixed][0]/stable if stable and objective=='stable_certificate' else None,
        'oracle_stable_recall':oracle_success/stable if stable and objective=='stable_certificate' else None,
        'fixed_cost_method':fixed_cost,'fixed_capped_loss_ms':fixed_loss*1000,
        'oracle_capped_loss_ms':oracle_loss*1000,
        'capped_loss_reduction_percent':100*(fixed_loss-oracle_loss)/fixed_loss if fixed_loss else 0.,
        'oracle_selection_counts':dict(Counter(chosen.values())),
        'method_successes':{m:totals[m][0] for m in methods},
        'method_capped_loss_ms':{m:totals[m][1]/n*1000 for m in methods},
        'oracle_choices':[{ 'graph':q[0],'rank':q[1],'policy':chosen[q],
            'cost_policy':cost_chosen[q],'successes':aggregate[q,chosen[q]][0],
            'fixed_successes':aggregate[q,fixed][0]} for q in queries]}


def main(out):
    p,s = load(out/'protocol.json'),load(out/'summary.json')
    rows,refs = s['rows'],s['references']
    curves = []
    for objective in p['objectives']:
        for budget in p['delivery_deadlines_ms']:
            curves.append(evaluate(rows,refs,budget/1000,objective))
    subgroups = {}
    for name,select in [('dw',lambda r:r['graph']=='dw'),('enfr',lambda r:r['graph']=='enfr'),
                        ('scope_ge20',lambda r:r['scope_edges']>=20),('scope_lt20',lambda r:r['scope_edges']<20),
                        ('stable_truth',lambda r:bool(r['uniform_winners'])),
                        ('nonuniform_truth',lambda r:not r['uniform_winners'])]:
        subset = [r for r in refs if select(r)]
        keys = {(r['graph'],r['rank']) for r in subset}
        subrows = [r for r in rows if (r['graph'],r['rank']) in keys]
        subgroups[name] = [evaluate(subrows,subset,b/1000,o) for o in p['objectives'] for b in p['delivery_deadlines_ms']]
    feature_curves = [evaluate(rows,refs,b/1000,o,True) for o in p['objectives'] for b in p['delivery_deadlines_ms']]
    feature = [t*1000 for r in refs for t in r['feature_seconds']]
    costs = {m:{'actual_total_seconds':sum(r['compute_seconds'] for r in rows if r['policy']==m),
                'outcomes':dict(Counter(r['status'] for r in rows if r['policy']==m)),
                'overrun_count':sum(r['overrun_seconds']>0 for r in rows if r['policy']==m),
                'maximum_overrun_ms':max(r['overrun_seconds'] for r in rows if r['policy']==m)*1000}
             for m in POLICIES}
    save(out/'analysis.json',{'status':'PASS','summary_sha256':sha(out/'summary.json'),
        'queries':len(refs),'true_stable_queries':sum(bool(r['uniform_winners']) for r in refs),
        'true_nonuniform_queries':sum(not r['uniform_winners'] for r in refs),
        'curves':curves,'subgroups':subgroups,'feature_adjusted_curves':feature_curves,
        'feature_probe_ms':{'median':statistics.median(feature),'maximum':max(feature),
                            'mean':statistics.mean(feature)},'measured_costs':costs})
    for r in curves:
        print(f"{r['objective']} {r['budget_ms']:g}ms: {r['fixed_coverage_method']} "
              f"{r['fixed_successes']}/{r['query_repeats']} -> oracle {r['oracle_successes']}, "
              f"gain {r['coverage_gain_pp']:.2f}pp; capped loss -{r['capped_loss_reduction_percent']:.1f}%")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=BASE)
    main(parser.parse_args().output.resolve())
