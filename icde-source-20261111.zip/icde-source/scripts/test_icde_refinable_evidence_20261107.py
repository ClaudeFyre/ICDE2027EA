"""Independent correctness checks for the new development prototype."""
from fractions import Fraction as Q
from itertools import product
import math
import unittest

import numpy as np

from icde_refinable_evidence_20261107 import DegreeRefiner, Evidence, exact_mask, members
from vldb_capture_attribute_v0 import DegreeScoreKernel
from vldb_difference_envelope_v2 import compile_difference_kernel


def random_kernel(seed):
    rng = np.random.default_rng(seed)
    heads, tails = rng.integers(0, 5, (2, 7))
    incidence = tuple(np.asarray(np.flatnonzero((heads if d == 0 else tails) == entity), dtype=np.intp)
                      for entity in range(5) for d in (0, 1))
    raw = DegreeScoreKernel(0, tuple(range(1, 5)), tuple(range(7)), incidence,
                           rng.random(4), rng.random(4), .8)
    return compile_difference_kernel(raw)


class RefinerTests(unittest.TestCase):
    def test_shared_incidence_dp_matches_all_boolean_worlds(self):
        for seed in (7, 11, 19):
            kernel = random_kernel(seed)
            refiner = DegreeRefiner(kernel)
            for code in (0, 8, 117, 842, 2186):
                digits = [(code // (3 ** e)) % 3 for e in range(7)]
                low = np.asarray([d == 1 for d in digits])
                high = np.asarray([d != 0 for d in digits])
                all_states = np.asarray(list(product((False, True), repeat=7)))
                valid = np.all(all_states >= low, axis=1) & np.all(all_states <= high, axis=1)
                scores = kernel.scores(all_states[valid])
                coarse = refiner.coarse(low, high)
                actual = set(map(int, np.argmax(scores, axis=1)))
                self.assertTrue(actual <= set(members(coarse, 4)))
                for w in range(4):
                    for d in range(4):
                        if w == d:
                            continue
                        oracle = bool(np.all((scores[:, w] > scores[:, d]) |
                                             ((scores[:, w] == scores[:, d]) & (w < d))))
                        proof, work, status = refiner.eliminate(w, d, low, high, 100000)
                        self.assertEqual(status, "complete")
                        self.assertEqual(proof, oracle)
                        self.assertGreaterEqual(work, 1)

    def test_capped_work_never_invents_a_proof(self):
        refiner = DegreeRefiner(random_kernel(7), state_cap=1)
        low, high = np.zeros(7, dtype=np.bool_), np.ones(7, dtype=np.bool_)
        for budget in (0, 1, 2, 5):
            proof, spent, status = refiner.eliminate(0, 1, low, high, budget)
            self.assertLessEqual(spent, budget)
            if status != "complete":
                self.assertFalse(proof)

    def test_historical_updates_match_explicit_polynomial(self):
        evidence = Evidence(4)
        for mask in (15, 3, 12, 15, 8):
            evidence.append(mask)
        # Choose and revisit old rows, rather than a completed prefix.
        for i, mask in ((3, 5), (0, 7), (1, 1), (3, 1), (0, 2)):
            evidence.refine(i, mask)
            a = [sum(m == 1 << w for m in evidence.masks) for w in range(4)]
            b = [sum(bool(m & (1 << d)) for m in evidence.masks) for d in range(4)]
            self.assertEqual(evidence.a, a)
            self.assertEqual(evidence.b, b)
            values = []
            for w in range(4):
                pair = []
                for d in range(4):
                    if w == d:
                        continue
                    direct = sum((Q(math.comb(a[w], i) * math.comb(b[d], j) * (-1) ** j, i+j+1)
                                  for i in range(a[w]+1) for j in range(b[d]+1)), Q(0))
                    self.assertEqual(evidence.wealth(a[w], b[d]), direct)
                    pair.append(direct)
                values.append(min(pair))
            w, _, good = evidence.best()
            self.assertEqual(values[w], max(values))
            self.assertEqual(good, max(values) >= 80)

    def test_invalid_refinement_rejected(self):
        evidence = Evidence(3)
        evidence.append(3)
        for invalid in (0, 7, 4):
            with self.assertRaises(ValueError):
                evidence.refine(0, invalid)

    def test_oracle_bit_order_is_independent_of_numpy_world_order(self):
        winners = [0, 1, 2, 0]
        self.assertEqual(exact_mask(winners, np.array([False, True]),
                                    np.array([True, True])), 5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
