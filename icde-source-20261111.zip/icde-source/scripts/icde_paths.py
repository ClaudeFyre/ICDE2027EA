"""Scripts-side entry point for the ICDE portable path resolver.

This file is NOT a second implementation. It bootstraps the canonical resolver
from ``nodes/05_icde_query_engine/experiments/_common/icde_paths.py`` (the
single source of truth) by loading it under a private module name, then
re-exports its public API. Keeping one real implementation means a fix to the
resolver automatically applies to both the experiment runners and the
scripts-side harnesses.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
_CANONICAL = (
    _REPO_ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "experiments"
    / "_common"
    / "icde_paths.py"
)

if not _CANONICAL.is_file():
    raise FileNotFoundError(
        f"Canonical ICDE resolver not found at '{_CANONICAL}'. "
        "The repo layout appears incomplete; this shim cannot bootstrap."
    )

_spec = importlib.util.spec_from_file_location("_icde_paths_canonical", _CANONICAL)
_module = importlib.util.module_from_spec(_spec)
sys.modules["_icde_paths_canonical"] = _module
assert _spec.loader is not None
_spec.loader.exec_module(_module)

# Re-export the public surface.
resolve_repo_root = _module.resolve_repo_root
resolve_input = _module.resolve_input
resolve_graph_reference = _module.resolve_graph_reference
trace_root_from_summary = _module.trace_root_from_summary
trace_dirs_from_summary = _module.trace_dirs_from_summary
content_digest = _module.content_digest
KNOWN_INPUTS = _module.KNOWN_INPUTS

__all__ = [
    "resolve_repo_root",
    "resolve_input",
    "resolve_graph_reference",
    "trace_root_from_summary",
    "trace_dirs_from_summary",
    "content_digest",
    "KNOWN_INPUTS",
]
