from fractions import Fraction as Q
from itertools import product
import unittest
import numpy as np
from icde_grouped_exact_20261108 import solve_counts
from icde_parameter_association_20261108 import pointwise_population,audit_masks


class AssociationTest(unittest.TestCase):
    def compiled(self,winners,sizes):
        a=np.asarray(winners,dtype=np.int64)
        return {'winners':a,'shape':a.shape,'count_states':a.size,
                'groups':tuple(((i,),tuple(range(n)),(.65,1.)) for i,n in enumerate(sizes))}

    def test_two_edge_exact_separation(self):
        c=self.compiled([0,1,0],[2])
        exact=solve_counts(c,2)
        result,masks=pointwise_population(c,exact,2)
        self.assertEqual(exact['uniform_winners'],[0])
        self.assertAlmostEqual(min(r['minimum_gap'] for r in exact['pairs'] if r['candidate']==0),.09)
        self.assertAlmostEqual(result['minimum_gaps'][0],-.155)
        self.assertEqual(result['pointwise_certifiable_winners'],[])
        self.assertEqual(masks.tolist(),[3,3,1])
        self.assertEqual(audit_masks(c,masks),3)

    def test_grouped_population_against_boolean_uniform_cells(self):
        c=self.compiled([[0,1],[1,0],[2,0]],[2,1])
        exact=solve_counts(c,3)
        result,masks=pointwise_population(c,exact,3)
        expected=[[Q(0) for d in range(3)] for w in range(3)]
        lo=Q.from_float(.65)
        for fixed in product((0,1),repeat=3):
            probability=lo**sum(fixed)*(1-lo)**(3-sum(fixed))
            attainable=set()
            for world in product((0,1),repeat=3):
                if all(z>=a for z,a in zip(world,fixed)):
                    attainable.add(int(c['winners'][sum(world[:2]),world[2]]))
            for w in range(3):
                for d in range(3):
                    if w!=d:
                        expected[w][d]+=probability*min(int(y==w)-int(y==d) for y in attainable)
        for r in result['pairs']:
            self.assertEqual(Q(r['gap_exact']),expected[r['candidate']][r['competitor']])
        audit_masks(c,masks)

    def test_constant_winner_and_domain_rejection(self):
        c=self.compiled([1,1,1],[2])
        result,masks=pointwise_population(c,solve_counts(c,2),2)
        self.assertEqual(result['pointwise_certifiable_winners'],[1])
        self.assertEqual(result['minimum_gaps_exact'][1],'1')
        c['groups']=(((0,),(0,1),(.65,.99)),)
        with self.assertRaises(ValueError):
            pointwise_population(c,solve_counts(c,2),2)


if __name__=='__main__':unittest.main()
