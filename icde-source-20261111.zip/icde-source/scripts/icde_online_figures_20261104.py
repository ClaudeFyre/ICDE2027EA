"""Plot completed ICDE online and frozen G1 results without research execution.

Online coverage deduplicates timing repetitions. Serving time is the mean of
three warm pilot workers at 16 queries and the single completed warm worker at
each larger completed scale. An incomplete 500-query attempt contributes only
its failure status, never an inferred coverage or runtime point. G1 curves
average three model seeds at 1024 worlds; no error bars or intervals are inferred.
Every consumed file is hashed in the manifest.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "nodes/09_vldb_query_certification/results"
METHODS = ("scope_full_risk", "difference_eager", "difference_lazy")
GRAPHS = ("D-W", "EN-FR")
METHOD_LABELS = ("Scope only", "Shared event, eager", "Shared event, lazy")
COLORS = ("#555555", "#205c8a", "#b46a22")
MARKERS = ("o", "s", "^")
G1_METHODS = ("point_margin", "mean_score_margin", "certified_modal")
G1_LABELS = ("Point margin", "Mean-score margin", "Certified modal")
G1_COLORS = ("#205c8a", "#7d7098", "#ae4747")
COVERAGES = (.1, .25, .5, .75)


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def inside(value):
    path = Path(value)
    path = (path if path.is_absolute() else ROOT / path).resolve()
    path.relative_to(ROOT)
    return path


class Sources:
    def __init__(self):
        self.records = {}

    def add(self, path, role):
        path = inside(path)
        key = path.relative_to(ROOT).as_posix()
        if key not in self.records:
            self.records[key] = {"path": key, "sha256": digest(path),
                                 "bytes": path.stat().st_size, "roles": []}
        if role not in self.records[key]["roles"]:
            self.records[key]["roles"].append(role)
        return self.records[key]

    def json(self, path, role):
        self.add(path, role)
        with inside(path).open(encoding="utf-8-sig") as handle:
            return json.load(handle)


def load_online(directory, expected_queries, expected_repeats, sources):
    directory = inside(directory)
    batch = sources.json(directory / "batch_summary.json", "completed_online_batch")
    sources.add(directory / "protocol_freeze.json", "online_protocol_and_code_identity")
    if batch["status"] != "COMPLETE":
        raise ValueError("online batch is incomplete")
    specifications = [row for row in batch["measurements"]
                      if row["mode"] == "warm" and row["method"] == "all"]
    if len(specifications) != expected_repeats:
        raise ValueError("unexpected number of warm timing workers")
    first_cases = None
    timings = {(graph, method): [] for graph in GRAPHS for method in METHODS}
    totals = {}
    selections = None
    seeds = None
    for specification in specifications:
        path = inside(specification["path"])
        record = sources.add(path, "online_warm_worker")
        if record["sha256"] != specification["output_sha256"]:
            raise ValueError("online worker hash differs from completed batch summary")
        worker = sources.json(path, "online_warm_worker")
        if worker["status"] != "COMPLETE":
            raise ValueError("online worker is incomplete")
        if int(worker["config"]["query_count"]) != expected_queries:
            raise ValueError("query scale differs from requested figure point")
        current_seeds = tuple(worker["config"]["seeds"])
        if len(current_seeds) != 3 or len(set(current_seeds)) != 3:
            raise ValueError("online figure requires the three declared MC seeds")
        current_selections = {
            item["graph"]: tuple(item["query_selection"]["query_ids"])
            for item in worker["graph_setup"]}
        if any(len(current_selections[graph]) != expected_queries for graph in GRAPHS):
            raise ValueError("distinct-query denominator is inconsistent")
        if selections is not None and (selections != current_selections or seeds != current_seeds):
            raise ValueError("warm repetitions changed the scientific input population")
        selections, seeds = current_selections, current_seeds
        cases = {}
        serving = {(graph, method): 0. for graph in GRAPHS for method in METHODS}
        current_totals = {(graph, method): {"cases": 0, "robust": 0, "nominal": 0,
                                          "nontrivial_cases": 0, "nontrivial_robust": 0}
                          for graph in GRAPHS for method in METHODS}
        for row in worker["query_policy_rows"]:
            key = (row["graph"], row["query_id"], row["seed"], row["method"])
            if key in cases:
                raise ValueError("duplicate scientific case within a warm worker")
            cases[key] = (row["stable"], row["samples_used"], row["event_samples_used"],
                          row["uniform_prefix_sha256"], row["winner_prefix_sha256"])
            pair = (row["graph"], row["method"])
            serving[pair] += float(row["seconds"]["query_serving_total"])
            group = current_totals[pair]
            group["cases"] += 1
            group["robust"] += int(row["stable"])
            group["nominal"] += int(row["nominal_certified"])
            group["nontrivial_cases"] += int(row["candidate_count"] > 1)
            group["nontrivial_robust"] += int(row["candidate_count"] > 1 and row["stable"])
        if first_cases is not None and cases != first_cases:
            raise ValueError("timing repetitions changed scientific outcomes or paired prefixes")
        first_cases, totals = cases, current_totals
        for pair in timings:
            if current_totals[pair]["cases"] != expected_queries * len(current_seeds):
                raise ValueError("incomplete method/source/seed population")
            timings[pair].append(serving[pair])
    points = []
    for graph in GRAPHS:
        for method in METHODS:
            pair = graph, method
            group = totals[pair]
            points.append({"graph": graph, "method": method,
                           "queries": expected_queries, "MC_seeds": list(seeds),
                           **group, "robust_percent": 100 * group["robust"] / group["cases"],
                           "serving_seconds": statistics.mean(timings[pair]),
                           "warm_worker_serving_seconds": timings[pair],
                           "timing_repetitions": expected_repeats})
    return points, selections, seeds


def load_utility(path, sources):
    sources.add(path, "frozen_G1_label_risk_coverage")
    with inside(path).open(encoding="utf-8-sig", newline="") as handle:
        selected = [row for row in csv.DictReader(handle)
                    if int(row["budget"]) == 1024
                    and row["method"] in G1_METHODS
                    and float(row["coverage"]) in COVERAGES]
    points = []
    for graph in ("dw", "enfr"):
        for method in G1_METHODS:
            for coverage in COVERAGES:
                rows = [row for row in selected if row["graph"] == graph
                        and row["method"] == method and float(row["coverage"]) == coverage]
                if len(rows) != 3 or {int(row["seed"]) for row in rows} != {17, 23, 31}:
                    raise ValueError("G1 figure requires all three fixed model seeds")
                if any(row["attainable"].lower() != "true" or row["risk"] == "" for row in rows):
                    raise ValueError("an unattainable G1 coverage cannot be plotted as observed risk")
                risks = [float(row["risk"]) for row in rows]
                points.append({"graph": graph, "method": method,
                               "requested_coverage": coverage, "worlds": 1024,
                               "model_seeds": [17, 23, 31],
                               "mean_risk_percent": 100 * statistics.mean(risks),
                               "seed_values": [{"seed": int(row["seed"]), "risk": float(row["risk"]),
                                                "selected": int(row["selected"]),
                                                "errors": int(row["errors"])} for row in rows]})
    return points


def incomplete_scale(directory, safe_run_path, sources):
    """Read only attempt-level failure provenance, never a pending worker."""
    directory = inside(directory)
    freeze = directory / "protocol_freeze.json"
    record = {"queries": 500, "status": "incomplete", "complete_worker_loaded": False,
              "coverage_percent": None, "serving_seconds": None,
              "attempt_directory": directory.relative_to(ROOT).as_posix(),
              "watchdog_limit_seconds": None}
    if freeze.is_file():
        sources.add(freeze, "incomplete_500_protocol_and_code_identity")
    safe_run_path = inside(safe_run_path)
    if safe_run_path.is_file():
        failure = sources.json(safe_run_path, "500_safe_run_failure_record")
        record.update({"safe_run_status": failure.get("status"),
                       "safe_run_reason": failure.get("reason"),
                       "safe_run_elapsed_seconds": failure.get("elapsed_seconds"),
                       "return_code": failure.get("return_code"),
                       "peak_job_memory_gb": failure.get("peak_job_memory_gb")})
        if failure.get("status") == "failed":
            record["status"] = "failed_no_complete_result"
        log_name = failure.get("log_path")
        if log_name and inside(log_name).is_file():
            log_path = inside(log_name)
            sources.add(log_path, "500_parent_watchdog_failure_log")
            text = log_path.read_text(encoding="utf-8-sig")
            if "bounded batch time exhausted" in text:
                record["status"] = "parent_watchdog_timeout"
                record["watchdog_limit_seconds"] = 850
    return record


def save_pair(figure, directory, stem):
    pdf, png = directory / f"{stem}.pdf", directory / f"{stem}.png"
    figure.savefig(pdf, metadata={"Title": stem, "Creator": "ICDE raw-result figure script"})
    figure.savefig(png, dpi=300)
    plt.close(figure)
    return [{"path": path.relative_to(ROOT).as_posix(), "sha256": digest(path),
             "bytes": path.stat().st_size} for path in (pdf, png)]


def online_figure(points, output, failed_stage=None):
    figure, axes = plt.subplots(2, 2, figsize=(7, 3.5), sharex="col", sharey="row")
    figure.subplots_adjust(left=.09, right=.985, bottom=.13, top=.86, hspace=.29, wspace=.14)
    handles = []
    for column, graph in enumerate(GRAPHS):
        axes[0, column].set_title(graph.replace("-", "\N{EN DASH}"), pad=4)
        for index, method in enumerate(METHODS):
            rows = sorted((row for row in points if row["graph"] == graph and row["method"] == method),
                          key=lambda row: row["queries"])
            x = [row["queries"] for row in rows]
            line, = axes[0, column].plot(x, [row["robust_percent"] for row in rows],
                                         color=COLORS[index], marker=MARKERS[index],
                                         linestyle="--" if index == 2 else "-", label=METHOD_LABELS[index])
            axes[1, column].plot(x, [row["serving_seconds"] for row in rows],
                                color=COLORS[index], marker=MARKERS[index],
                                linestyle="--" if index == 2 else "-")
            if column == 0:
                handles.append(line)
        for axis in axes[:, column]:
            axis.set_xscale("log")
            axis.set_xlim(13.5, 580)
            axis.set_xticks((16, 128, 500), ("16", "128", "500"))
            axis.xaxis.set_minor_locator(NullLocator())
            axis.grid(axis="y", color=".89", linewidth=.45)
            axis.spines[["top", "right"]].set_visible(False)
        axes[0, column].set_ylim(0, 100)
        axes[1, column].set_ylim(bottom=0)
        axes[1, column].set_xlabel("Queries per graph")
        if failed_stage is not None:
            for axis in axes[:, column]:
                axis.axvline(500, color=".7", linestyle=":", linewidth=.6)
            message = "500: no complete result"
            if failed_stage.get("watchdog_limit_seconds") is not None:
                message += "\n850 s batch limit"
            axes[0, column].text(.98, .35, message, transform=axes[0, column].transAxes,
                                 ha="right", va="center", fontsize=7.5, color=".35")
    axes[0, 0].set_ylabel("Robust certificates (%)")
    axes[1, 0].set_ylabel("Serving time (s)")
    figure.legend(handles, METHOD_LABELS, loc="upper center", ncol=3,
                  frameon=False, bbox_to_anchor=(.52, 1.0))
    return save_pair(figure, output, "online_scale")


def utility_figure(points, output):
    figure, axes = plt.subplots(1, 2, figsize=(7, 2.3), sharey=True)
    figure.subplots_adjust(left=.09, right=.985, bottom=.23, top=.76, wspace=.14)
    maximum = max(row["mean_risk_percent"] for row in points)
    upper = 5 * math.ceil((maximum + 3) / 5)
    handles = []
    for column, graph in enumerate(("dw", "enfr")):
        axis = axes[column]
        axis.set_title(GRAPHS[column].replace("-", "\N{EN DASH}"), pad=4)
        for index, method in enumerate(G1_METHODS):
            rows = sorted((row for row in points if row["graph"] == graph and row["method"] == method),
                          key=lambda row: row["requested_coverage"])
            line, = axis.plot([100 * row["requested_coverage"] for row in rows],
                              [row["mean_risk_percent"] for row in rows],
                              color=G1_COLORS[index], marker=MARKERS[index],
                              linestyle="--" if index == 2 else "-", label=G1_LABELS[index])
            if column == 0:
                handles.append(line)
        axis.set_xlim(7, 78)
        axis.set_xticks((10, 25, 50, 75))
        axis.set_ylim(0, upper)
        axis.set_xlabel("Requested automatic coverage (%)")
        axis.grid(axis="y", color=".89", linewidth=.45)
        axis.spines[["top", "right"]].set_visible(False)
    axes[0].set_ylabel("Empirical label error (%)")
    figure.legend(handles, G1_LABELS, loc="upper center", ncol=3,
                  frameon=False, bbox_to_anchor=(.52, 1.0))
    return save_pair(figure, output, "alignment_risk_coverage")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pilot-dir", default=str(RESULTS / "icde_online_pilot_20261104_attempt1"))
    parser.add_argument("--scale128-dir", default=str(RESULTS / "icde_online_scale128_20261104_attempt1"))
    parser.add_argument("--scale500-dir", default=str(RESULTS / "icde_online_scale500_20261104_attempt1"))
    parser.add_argument("--scale500-safe-run", default=".runtime/runs/icde-online-scale500-attempt1.json")
    parser.add_argument("--g1-csv", default="nodes/02_sampling_diagnosis/results/pw_value_20261028/attempt3/risk_coverage.csv")
    parser.add_argument("--output-dir", default="papers/icde/regular2027/figures/online_20261104_attempt1")
    args = parser.parse_args()
    sources, online = Sources(), []
    previous_selection = None
    previous_seeds = None
    failed_stage = None
    stage_statuses = []
    for count, repeats, directory in ((16, 3, args.pilot_dir), (128, 1, args.scale128_dir), (500, 1, args.scale500_dir)):
        if count == 500:
            summary_path = inside(directory) / "batch_summary.json"
            complete = False
            if summary_path.is_file():
                summary = sources.json(summary_path, "500_attempt_batch_status")
                complete = summary.get("status") == "COMPLETE"
            if not complete:
                failed_stage = incomplete_scale(directory, args.scale500_safe_run, sources)
                stage_statuses.append(failed_stage)
                continue
        points, selection, seeds = load_online(directory, count, repeats, sources)
        if previous_selection is not None:
            if seeds != previous_seeds or any(selection[graph][:len(previous_selection[graph])]
                                               != previous_selection[graph] for graph in GRAPHS):
                raise ValueError("online scales must retain the same seeds and nested query subsets")
        previous_selection, previous_seeds = selection, seeds
        online.extend(points)
        stage_statuses.append({"queries": count, "status": "COMPLETE",
                               "warm_timing_repetitions": repeats})
    utility = load_utility(args.g1_csv, sources)
    sources.add(Path(__file__), "plotting_code_only_no_new_research_execution")
    output = inside(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["DejaVu Serif"],
        "font.size": 8, "axes.titlesize": 8, "axes.labelsize": 8,
        "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 8,
        "axes.linewidth": .6, "lines.linewidth": 1.15, "lines.markersize": 3.8,
        "legend.handlelength": 1.8, "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    figures = online_figure(online, output, failed_stage) + utility_figure(utility, output)
    online_caption = (
        "Online robust coverage and observed serving time on completed nested query subsets. "
        "Coverage uses three paired MC seeds per source. Serving time averages three warm "
        "workers at 16 queries and uses one warm worker at each larger completed scale; "
        "static setup is reported separately.")
    if failed_stage is not None:
        if failed_stage.get("watchdog_limit_seconds") is not None:
            online_caption += (" The 500-query attempt did not complete within the 850-second "
                               "parent batch limit; no 500-query coverage or serving-time point is inferred.")
        else:
            online_caption += (" The 500-query attempt has no complete result; no 500-query "
                               "coverage or serving-time point is inferred.")
    manifest = {
        "schema_version": "icde-online-figure-provenance-20261104-v1",
        "source_files": sorted(sources.records.values(), key=lambda row: row["path"]),
        "figures": figures, "online_points": online, "label_utility_points": utility,
        "online_stage_statuses": stage_statuses,
        "aggregation": {
            "online_coverage": "robust cases / (distinct sources per graph * three MC seeds); timing repeats deduplicated",
            "online_serving_seconds": "sum over actual query-seed cases, excluding separately reported static setup; mean of three warm workers only at 16 queries",
            "scale_timing_repetitions": {"16": 3, "128": 1,
                                         "500": None if failed_stage is not None else 1},
            "incomplete_worker_files_parsed": False,
            "incomplete_scales_have_no_inferred_numeric_points": True,
            "nested_query_subsets": True, "independent_queries_not_implied_by_MC_repetition": True,
            "utility": "arithmetic mean of empirical label risk over model seeds17/23/31 at 1024 worlds",
            "uncertainty_intervals": "none; no intervals fabricated from dependent query-seed cases",
            "omitted_G1_curves": ["point_entropy", "uncertified_vote"],
        },
        "caption_drafts": {
            "online_scale": online_caption,
            "alignment_risk_coverage": "Empirical alignment-label error versus requested automatic coverage in the frozen strong-RREA G1 study at1024 worlds, averaged over three model seeds. Curves compare point margin, mean-score margin and certified modal release. Point entropy and uncertified voting are omitted for readability; no uncertainty intervals are shown.",
        },
        "new_training_sampling_or_experiments": False,
    }
    with (output / "figure_provenance.json").open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    print(json.dumps({"output_dir": output.relative_to(ROOT).as_posix(), "figures": figures}))


if __name__ == "__main__":
    main()
