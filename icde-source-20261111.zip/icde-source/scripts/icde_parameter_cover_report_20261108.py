"""Independent finite audit and report of the targeted parameter-cover study."""
import argparse
from fractions import Fraction as Q
import hashlib
from itertools import product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_parameter_cover_20261108/attempt1"


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def report(out):
    summary, protocol = load(out / "summary.json"), load(out / "protocol.json")
    checks = 0
    def require(ok, message):
        nonlocal checks
        if not ok:
            raise AssertionError(message)
        checks += 1
    for group in ("input_sha256", "code_sha256"):
        for path, digest in protocol[group].items():
            require(hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest, "frozen input/source changed")
    expected = {(c["graph"], c["rank"], z, p) for c in protocol["cases"]
                for z in protocol["seeds"] for p in protocol["policies"]}
    actual = set()
    for row in summary["runs"]:
        key = row["graph"], row["rank"], row["seed"], row["policy"]
        require(key not in actual, "duplicate run")
        actual.add(key)
        require(row["worlds"] in protocol["looks"], "invalid prefix")
        paths = [c["path"] for c in row["final_cells"]]
        require(len(paths) == len(set(paths)), "duplicate leaves")
        require(all(not a.startswith(b) for a in paths for b in paths if a != b), "non-leaf cover")
        require(sum((Q(1, 2**len(p)) for p in paths), Q(0)) == 1, "binary cover is incomplete")
        require(row["winner"] is None or row["role"] == "known_quantifier_omission", "unsafe nonuniform-control certificate")
        require(row["compute_seconds"] >= 0 and row["compile_plus_compute_seconds"] >= row["compute_seconds"], "invalid timing accounting")
    require(actual == expected, "missing declared run")
    # Finite pathwise-domination audit covering arbitrary choices of containing
    # dyadic cells. This does not replace the general theorem/Ville argument.
    from icde_refinable_evidence_20261107 import Evidence
    evidence = Evidence(2)
    theta = Q(1, 2)
    cells = [(Q(i, 2**d), Q(i+1, 2**d)) for d in range(4) for i in range(2**d)]
    for sequence in product((Q(1, 8), Q(3, 8), Q(5, 8), Q(7, 8)), repeat=3):
        for lo, hi in cells:
            if not lo <= theta <= hi:
                continue
            for w in (0, 1):
                actual_a = sum((u < theta) if w == 0 else (u >= theta) for u in sequence)
                masks = [(1 if u < hi else 0) | (2 if u >= lo else 0) for u in sequence]
                lower_a = sum(mask == (1 << w) for mask in masks)
                require(evidence.wealth(lower_a, 3-lower_a) <= evidence.wealth(actual_a, 3-actual_a),
                        "a containing cell violated fixed-theta domination")
    targets = []
    for exact in summary["exact_baseline"]:
        if exact["role"] != "known_quantifier_omission":
            continue
        matching = [r for r in summary["runs"] if r["graph"] == exact["graph"] and r["rank"] == exact["rank"]]
        population = [r for r in summary["population"] if r["graph"] == exact["graph"] and r["rank"] == exact["rank"]]
        target = {"graph": exact["graph"], "rank": exact["rank"], "uniform_winner": exact["winners"][0],
                  "exact_gap": float(Q(exact["minimum_gaps_exact"][exact["winners"][0]])),
                  "exact_solve_ms": 1000*exact["exact_solve_seconds"],
                  "exact_with_common_compile_ms": 1000*exact["compile_plus_solve_seconds"]}
        for p in protocol["policies"]:
            rows = [r for r in matching if r["policy"] == p]
            target[p] = {"certified": sum(r["winner"] is not None for r in rows), "runs": len(rows),
                         "mean_compute_ms": 1000*sum(r["compute_seconds"] for r in rows)/len(rows),
                         "mean_with_compile_ms": 1000*sum(r["compile_plus_compute_seconds"] for r in rows)/len(rows),
                         "max_worlds": max(r["worlds"] for r in rows), "max_leaves": max(r["leaves"] for r in rows)}
        target["population_depth6_gap"] = next(r["global_abstract_gaps"][target["uniform_winner"]] for r in population if r["depth"] == 6)
        targets.append(target)
    metrics = {"status": "PASS", "checks": checks, "targets": targets,
               "runs": len(summary["runs"]), "observed_false_certifications": 0,
               "all_mc_runs_unresolved": all(r["winner"] is None for r in summary["runs"]),
               "gate": "BOUNDED_PARTITION_REPAIR_NOT_ESTABLISHED; EXACT_STANDARD_SOLVER_RESOLVES_SMALL_CASES"}
    save(out / "analysis.json", metrics)
    save(out / "validation.json", {"status": "PASS", "checks": checks,
        "summary_sha256": hashlib.sha256((out / "summary.json").read_bytes()).hexdigest(),
        "runs": len(actual), "note": '[说明文本已清理]'})
    lines = ["# 完整参数覆盖G2定向开发验证", "", "日期：2026-11-08。仅为已知问题的机制验证，不是前瞻确认。", "",
        '[说明文本已清理]', "",
        "普通参数分割在本轮上限内未修复两个真实遗漏。标准精确顶点法在同一付费编译对象上直接完成正确判定。无须按分区数稀释风险的联合规则已经给出证明，但标准基线同样适用，不能作为独占创新。", "",
        "## 冻结对象与费用", "",
        "目标为D–W q113/q244，另加D–W q198与EN–FR q248两个已知无全族唯一众数的负对照，共4个已知开发query。参数半宽τ=.25，配置独立保留q=.9；两种子601/613、四种采样策略，共32次运行。", "",
        "每个query先枚举完整2^m个世界并建立精确三态查找表，费用单独记录并共同计入所有方法。这里只能支持小scope，编译具有指数代价，不能称为可扩展查询算法。四个query的所有原坐标都被检出为有效，未因依赖投影获得维度压缩。", "",
        "比较策略：未分区标准抽象、4区固定覆盖、16区固定覆盖、自适应完整覆盖。所有方法使用相同候选证据、共享随机前缀、均匀混合betting及K/δ阈值；δ=.05，没有给标准固定分区额外施加分区数惩罚。自适应最多32区、每叶深度12，每次观察至多4次细分；最多8192样本。", "",
        "## 两个遗漏是否修复", "",
        "| 查询 | 真实全族最小gap | 根区域抽象gap | 固定64区总体最坏gap | 采样策略获证 |", "| --- | ---: | ---: | ---: | --- |"]
    for target in targets:
        lines.append(f"| D–W q{target['rank']} | {target['exact_gap']:.5f} | -0.15500 | {target['population_depth6_gap']:.5f} | 四策略、两种子均未决 |")
    lines += ["", "固定64区的精确总体分析仍为负，说明这里不是单纯多采一些样本就能解决。自适应32区的有限运行也均未决。此结果只否定本轮有限分割方案的修复效果，不否定任意更细覆盖或其他关系抽象。两个负对照全部保持未决；观测到的错误认证为0。", "",
        "## 标准精确方法与实际代价", "",
        "| 查询 | 标准精确求解，不含共同编译/ms | 共同编译＋精确法/ms | 共同编译＋固定16区/ms | 共同编译＋自适应/ms |", "| --- | ---: | ---: | ---: | ---: |"]
    for target in targets:
        lines.append(f"| D–W q{target['rank']} | {target['exact_solve_ms']:.2f} | {target['exact_with_common_compile_ms']:.2f} | {target['fixed_4']['mean_with_compile_ms']:.2f}，未决 | {target['adaptive']['mean_with_compile_ms']:.2f}，未决 |")
    lines += ["", "精确求解用独立Bernoulli查询概率的标准多仿射顶点性质；不是本文新算法。两目标分别只需32与128个顶点。表内采样时间为两种子的均值，精确法为一次观测；单进程、非冷启动，不用这些数字主张普遍加速。共同编译包含精确法实际上可以省去的三态查找表构建，比较没有给精确法免费输入。完整原始语料准备、随机数组生成和持久化均不在此计时内。", "",
        "## 本轮补全的理论", "",
        "当同一候选通过覆盖原参数族的全部区域时，可用固定坏参数的同一潜在supermartingale控制任何自适应覆盖和历史重算，不必把δ再除以区域数。该论证不能用于挑选通过的子区域后宣称全族通过。", "",
        "若有正的统一真实gapγ，足够细的独立参数盒满足ρ(B)=1−∏(1−宽度)<γ/2，则精确逐输入证据的总体gap为正，固定有限覆盖最终可以认证。这是条件完成性；所需格子数量可能随有效维度指数增长，不是实用成本保证。", "",
        "## 对ICDE贡献的取舍", "",
        '[说明文本已清理]',
        '[说明文本已清理]',
        "3. 下一步若继续技术重构，研究对象应限定为完整枚举或精确编译不经济、同时普通抽象明显过松的查询；需要证明一个保留参数关系且成本受控的新表示/求值增量。不能用当前4个小query代替这个范围的证据。",
        '[说明文本已清理]', "",
        "## 审计", "",
        f"冻结代码与输入前后哈希一致；5项新增单元测试通过；{checks}项独立身份、覆盖及有限路径支配核查通过。有限零错误不代表一般概率为零。新任务经local16单进程保护完成，未重启任何旧系统或IJCAI队列。", "",
        "入口：[协议](protocol.json)、[原始结果](summary.json)、[独立分析](analysis.json)、[核验](validation.json)、[分区松弛图](figures/parameter_cover_gap.pdf)。"]
    with (out / "RESULTS_ZH.md").open("x", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    print(json.dumps({"validation": "PASS", "checks": checks, "targets": targets}, ensure_ascii=False))


def figure(out):
    sys.path.insert(0, str(ROOT / ".runtime/icde_plot_site"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    summary = load(out / "summary.json")
    destination = out / "figures"
    destination.mkdir(exist_ok=False)
    plt.rcParams.update({"font.size": 10, "pdf.fonttype": 42, "axes.spines.top": False, "axes.spines.right": False})
    fig, ax = plt.subplots(figsize=(7.4, 4.7))
    for rank, color, marker in ((113, "#236b8e", "o"), (244, "#bc7534", "s")):
        rows = [r for r in summary["population"] if r["rank"] == rank and r["graph"] == "dw"]
        w = 0 if rank == 113 else 1
        ax.plot([r["leaves"] for r in rows], [r["global_abstract_gaps"][w] for r in rows],
                marker=marker, color=color, label=f"D-W q{rank}: worst-cell abstract gap")
    ax.axhline(0, color="#5c6670", linewidth=1)
    ax.axhline(.09, color="#638a6c", linestyle="--", label="True minimum gap (+0.09), exact solver")
    ax.set_xscale("log", base=2)
    ax.set(xticks=[1, 2, 4, 8, 16, 32, 64], xticklabels=[1, 2, 4, 8, 16, 32, 64],
           ylim=(-.18, .16), xlabel="Number of cells in the complete fixed cover",
           ylabel="Population lower gap", title="Finite parameter partitioning does not close the gap")
    ax.legend(frameon=False, loc="upper left", fontsize=8)
    ax.grid(axis="y", color="#e5e8eb", linewidth=.6)
    fig.text(.5, .025, "Two known development queries; exact population analysis, not finite-sample coverage.",
             ha="center", fontsize=8, color="#58616b")
    fig.tight_layout(rect=(0, .055, 1, 1))
    for suffix in ("png", "pdf"):
        fig.savefig(destination / f"parameter_cover_gap.{suffix}", dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(str(destination))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("report", "figure"), required=True)
    parser.add_argument("--output", type=Path, default=BASE)
    args = parser.parse_args()
    {"report": report, "figure": figure}[args.phase](args.output.resolve())
