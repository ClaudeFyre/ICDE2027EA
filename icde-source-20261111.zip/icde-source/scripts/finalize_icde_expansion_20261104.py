"""Update current ICDE writing entry points after the reviewed full build."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PAPER=ROOT/'papers/icde/regular2027'

def read(path):return json.loads(path.read_text('utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    validation='papers/icde/regular2027/WRITING_VALIDATION_expanded_20261104_attempt2.json'
    plan=read(ROOT/'configs/icde_research_plan_20261104.json')
    plan['status']='active_icde_only_12_main_page_expansion_online128_complete_scale500_timeout'
    plan['content'].update(pdf='output/pdf/ICDE_ScopeRace_full_draft_20261104.pdf',pdf_build_directory='output/pdf/icde_expanded_20261104_attempt5',pdf_pages_total=13,pdf_main_pages=12,figures=6,tables=5,references=29,writing_validation=validation,expansion_report='papers/icde/regular2027/EXPANSION_REPORT_20261104.md')
    plan['established_evidence'].update(stdlib_tests_passed=104,online_unique_queries=256,online_nominal_seeds=[61,73,89],online_scope_cases='573/768',online_shared_evidence_cases='638/768',online_scope_serving_seconds=55.4143,online_eager_serving_seconds=45.1358,online_scale500='850-second batch watchdog, no completed worker output',strong_rrea='2 graphs x32 sources x64 worlds, full15000 candidates, zero certificates forced by radius>1',universal_cold_walltime_speedup=False)
    statuses={'I0':'complete_expanded_manuscript_12_main_pages','I1':'bibliography_expanded_own_ICDM_fulltext_pending','I2':'complete_pilot_and_readonly_identity_work_timing_audit','I3':'128_complete_500_timeout_neural_interface_complete_robust_bound_uninformative','I5':'complete_12_main_page_IEEE_layout_verified_author_metadata_pending'}
    for row in plan['work_packages']:
        if row['id'] in statuses:row['status']=statuses[row['id']]
    plan['execution_policy']['new_experiments_started_in_this_writing_turn']=True
    plan['execution_policy']['completed_bounded_protocols']=['configs/icde_online_pilot_20261104.json','configs/icde_online_scale128_20261104.json','nodes/09_vldb_query_certification/results/icde_rrea_applicability_20261104_attempt1/protocol_before_draws.json']
    plan['execution_policy']['failed_bounded_protocols']=['configs/icde_online_scale500_20261104.json']
    write(ROOT/'configs/icde_research_plan_20261104.json',plan)
    ledger=read(PAPER/'EVIDENCE_LEDGER_20261104.json')
    for row in ledger['sources']:
        if sha(ROOT/row['path'])!=row['sha256']:raise RuntimeError('Historical evidence changed: '+row['path'])
    new_sources=[
      'nodes/09_vldb_query_certification/results/icde_online_pilot_20261104_attempt1/batch_summary.json',
      'nodes/09_vldb_query_certification/results/icde_online_scale128_20261104_attempt1/batch_summary.json',
      'nodes/09_vldb_query_certification/results/icde_online_analysis_20261104_attempt1/validation.json',
      'nodes/09_vldb_query_certification/results/icde_online_analysis_20261104_attempt1/summary.json',
      '.runtime/runs/icde-online-scale500-attempt1.json',
      'nodes/09_vldb_query_certification/results/icde_rrea_applicability_20261104_attempt1/summary.json',
      'nodes/09_vldb_query_certification/results/icde_rrea_applicability_20261104_attempt1/protocol_before_draws.json',
      'nodes/09_vldb_query_certification/results/icde_rrea_applicability_20261104_attempt1/dw/progress.json',
      'nodes/09_vldb_query_certification/results/icde_rrea_applicability_20261104_attempt1/enfr/progress.json',
      'papers/icde/regular2027/figures/attempt5/figure_provenance.json',
      'papers/icde/regular2027/figures/online_20261104_attempt1/figure_provenance.json']
    for path in new_sources:
        if path not in {r['path'] for r in ledger['sources']}:ledger['sources'].append({'path':path,'sha256':sha(ROOT/path)})
    ledger['claims'].append({'id':'online-expansion-128','unique_sources':256,'seeds':[61,73,89],'cases_per_method':768,'scope_certificates':573,'shared_eager_certificates':638,'shared_lazy_certificates':638,'scope_serving_seconds':55.4143,'eager_serving_seconds':45.1358,'shared_setup_seconds':[26.219,17.661],'cold_process_means_scope_eager_lazy':[10.1012,10.3701,9.8111],'scale500_completed':False,'neural_full_graph_64_worlds_complete':True,'neural_certificates':0,'neural_radius':1.1694203418401818,'model_probabilities':'declared synthetic','online_tests_passed':9})
    ledger['pending_submission_evidence']=['full published ICDM predecessor comparison','direct strong mode/variance-adaptive inference controls','complete 500-source online result and larger graph sizes','useful scope-valid strong-model robust evidence','verified authors affiliations ORCIDs and actual in-review overlap']
    ledger['new_research_inference_performed_in_this_expansion']=True
    ledger['execution_metadata_notes']=['First two descriptive seed-purpose config labels differ from the fixed executed identifier icde_online_worlds_v1; per-row seed derivation independently verified.','Each warm repeat is a fresh worker with within-worker prepared-state/cache reuse, rather than one process spanning repeats.','500 attempt terminated at its batch watchdog; no inferred results.']
    write(PAPER/'EVIDENCE_LEDGER_20261104.json',ledger)
    report='[说明文本已清理]'
    (PAPER/'EXPANSION_REPORT_20261104.md').write_text(report,encoding='utf-8')
    review='[说明文本已清理]'
    (PAPER/'BUILD_REVIEW_20261104.md').write_text(review,encoding='utf-8')
    readme=(PAPER/'README.md').read_text('utf-8').replace('[七页初稿](../../../output/pdf/ICDE_ScopeRace_draft_20261104.pdf)','[12页正文完整稿](../../../output/pdf/ICDE_ScopeRace_full_draft_20261104.pdf)').replace('WRITING_VALIDATION_20261104_attempt4.json','WRITING_VALIDATION_expanded_20261104_attempt1.json')
    readme=readme.replace('[说明文本已清理]','[说明文本已清理]')
    (PAPER/'README.md').write_text(readme,encoding='utf-8')
    exp=PAPER/'EXPERIMENT_PLAN_20261104.md'
    text=exp.read_text('utf-8').replace('本文件给出协议的执行优先级，不代表新实验已经运行或门槛通过；本次仅写作，不启动训练、采样、校准或旧系统矩阵。','本文件给出执行优先级；用户进一步授权按计划扩充完整稿后，在线16/128层与强RREA适用性已执行，500层到达时限。最新状态见[扩充与实验记录](EXPANSION_REPORT_20261104.md)，以下条件仍用于后续决策。').replace('本文件本次仅写作，后续推断按独立冻结协议逐项进行。','后续推断继续按独立冻结协议逐项进行；当前完成与失败均见扩充记录。')
    exp.write_text(text,encoding='utf-8')
    status=ROOT/'nodes/09_vldb_query_certification/status.toml'
    text=status.read_text('utf-8').replace('icde_regular_research_writing_and_evidence_completion','icde_12page_online128_complete_500_timeout_strong_model_boundary').replace('tests_passed = 95','tests_passed = 104').replace('按ICDE实验安排完成前序/用途审查并冻结真正在线总成本pilot；之后按门槛补规模和strong scorer。','完成ICDM全文与直接mode对照；修复500源中断输出粒度后冻结重跑；研究有效强模型robust界。')
    status.write_text(text,encoding='utf-8')
    print(json.dumps({'pdf_main_pages':12,'pdf_total_pages':13,'figures':6,'tables':5,'references':29,'ready_for_submission':False}))

if __name__=='__main__':main()
