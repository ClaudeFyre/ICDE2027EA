"""Targeted d=16 stress rerun; v1 outputs remain preserved. --smoke uses temp only."""
from __future__ import annotations
import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path
import mpmath as mp
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
for folder in (ROOT / "scripts", ROOT / "src"):
    sys.path.insert(0, str(folder))
import www_certify_serving as srv
import www_highprecision_reference_v2 as hp
from www_reviewer_v2_common import freeze, save_once
from run_www_equal_budget import full_payload, load_full_payload
from www_budget_frontier import NUMERICAL_GUARD
from pkgea.www_fsl import gaussian_distance_matrix

OUT = ROOT / "nodes/04_www_distributional/results/reviewer_followup_v2/stress"
SOURCES = ["scripts/run_www_reviewer_stress_v2.py", "scripts/run_www_reviewer_retest.ps1", "scripts/www_highprecision_reference_v2.py",
    "scripts/www_reviewer_v2_common.py", "scripts/www_certify_serving.py",
    "scripts/www_budget_frontier.py", "scripts/run_www_equal_budget.py",
    "src/pkgea/www_fsl.py", "src/pkgea/distributional/full_covariance.py",
    "papers/www/REVIEWER_FOLLOWUP_RETEST_20261003.md"]


def cases():
    d = 16
    rng = np.random.default_rng(20261003)
    means = rng.normal(size=(4, d))
    qm = rng.normal(size=d)
    for label, diagonal in [("zero", np.zeros(d)), ("rank_deficient", np.r_[np.ones(8), np.zeros(8)]),
                            ("near_singular", np.geomspace(1e-12, 1, d)), ("well_conditioned", np.linspace(1, 2, d))]:
        covs = np.stack([np.diag(diagonal)] * 4)
        for inflated in (False, True):
            yield f"spectrum_{label}_{'inflated' if inflated else 'native'}", qm, np.diag(diagonal), means, covs, np.float32, inflated
    for scale in (1e-6, 1.0, 1e6):
        q = np.ones(d) * scale
        tm = np.stack([q * 1.2, q * 2, -q, q * 3])
        for inflated in (False, True):
            yield f"scale_{scale}_{inflated}", q, np.eye(d), tm, np.stack([np.eye(d)] * 4), np.float32, inflated
    # A compressed tie that full-FP32 means resolve. This forces mean restoration.
    tm = np.zeros((3, d)); tm[:, 0] = [1.0004, 1.0002, 3]
    yield "fp16_mean_flip", np.zeros(d), np.zeros((d,d)), tm, np.zeros((3,d,d)), np.float16, False
    tm = means.copy(); cv = np.stack([np.diag(np.linspace(.3, 1.7, d))] * 4)
    for inflated in (False, True):
        yield f"fp16_covariance_{inflated}", qm, np.eye(d), tm, cv, np.float16, inflated
    for separation in (-4e-6, 0.0, 4e-6):
        tm = np.zeros((3,d)); tm[:,0] = [1, -1, 3]
        q = np.zeros(d);q[0] = separation
        yield f"near_tie_{separation}", q, np.eye(d), tm, np.stack([np.eye(d)]*3), np.float32, False
    # Float64 source perturbation smaller than a float distance ULP: preserve mp winner.
    tm = np.zeros((3,d));tm[:,0] = [-1, 1, 3]
    q = np.zeros(d);q[0] = 2**-54
    yield "sub_ulp_real_vs_numeric", q, np.eye(d), tm, np.stack([np.eye(d)]*3), np.float32, False
    # Noncommuting positive definite covariance at d=16.
    a=rng.normal(size=(d,d));b=rng.normal(size=(d,d))
    cv=np.stack([a@a.T+np.eye(d)]*4)
    yield "noncommuting_spd", qm, b@b.T+np.eye(d), means, cv, np.float32, False


def execute_case(name, qm, qc, tm, tc, dtype, inflated, runtime):
    srv.PAYLOAD_DIR = runtime / name / "payloads"
    srv.BOUNDS_DIR = runtime / name / "bounds"
    srv.BACKING_DIR = runtime / name / "backing"
    cell="stress";method="full_fp16" if dtype==np.float16 else "full_fp32"
    full=full_payload(tm, tc, dtype=np.float32, metadata={"case":name})
    fm,fc=load_full_payload(full)
    blob=full_payload(fm,fc,dtype=dtype,metadata={"case":name})
    path=srv.payload_path(cell,method);path.parent.mkdir(parents=True);path.write_bytes(blob)
    pinned=srv.sha256_bytes(blob)
    bounds=srv.build_bounds(cell=cell,method=method,pinned_sha256=pinned,
        full_means=fm,full_covariances=fc,extra_metadata={"case":name})
    im,ic=load_full_payload(blob)
    deltas=bounds["deltas"].copy()
    if inflated:
        # Additional conservative inflation tests refinement, never a smaller bound.
        deltas=srv.outward_float32(deltas+100).astype(np.float64)
    # Round-trip the actual serving vector, including any explicit test inflation.
    np.save(runtime/name/"serving_bounds.npy",deltas.astype(np.float32))
    deltas=np.load(runtime/name/"serving_bounds.npy").astype(np.float64)
    down=np.nextafter(deltas.astype(np.float32),np.float32(-np.inf)).astype(np.float64)
    info=srv.build_backing(cell=cell,full_payload=full,targets=tuple(map(str,range(len(fm)))),extra_metadata={"case":name})
    store=srv.open_backing(cell,body_sha256=info["body_sha256"])
    est=srv.exact_distances(qm,qc,im,ic)
    ref_sq=gaussian_distance_matrix(np.concatenate((qm[None],fm)),np.concatenate((qc[None],fc)),1)[0]
    numeric_winner=int(np.argmin(ref_sq))
    res=srv.certify_or_refine_query(estimate_w2=est,deltas=deltas,store=store,query_mean=qm,query_covariance=qc)
    with mp.workdps(hp.DIGITS):
        exact,real_winner,real_gap=hp.distances_and_winner(qm,qc,fm,fc)
        compressed,_,_=hp.distances_and_winner(qm,qc,im,ic)
        radii=[hp.w2(m,c,n,k) for m,c,n,k in zip(fm,fc,im,ic)]
        runtime_error=max(abs(hp.scalar(v)-x) for v,x in zip(est,compressed))
        violations=[i for i,(bound,radius) in enumerate(zip(deltas,radii)) if hp.scalar(bound)<radius+runtime_error]
        resolved=real_gap>2*hp.scalar(NUMERICAL_GUARD)
        if res["served_answer"]!=numeric_winner or violations or runtime_error>NUMERICAL_GUARD:
            raise RuntimeError(f"STOP: {name}: wrong numeric answer or uncovered radius/runtime error")
        if resolved and res["served_answer"]!=real_winner:
            raise RuntimeError(f"STOP: {name}: disagrees with resolved high-precision winner")
        return {"case":name,"dimension":16,"dtype":np.dtype(dtype).name,
            "inputs":{"query_mean":qm.tolist(),"query_covariance":qc.tolist(),"full_means":fm.tolist(),
                      "full_covariances":fc.tolist(),"compressed_means":im.tolist(),"compressed_covariances":ic.tolist()},
            "full_payload_sha256":srv.sha256_bytes(full),"compressed_payload_sha256":pinned,
            "stored_deltas":deltas.tolist(),"downward_neighbors":down.tolist(),"bound_inflation":100 if inflated else 0,
            "serving":res,"numeric_reference_winner":numeric_winner,"high_precision_winner":real_winner,
            "high_precision_distances":[mp.nstr(x,hp.DIGITS) for x in exact],
            "high_precision_gap":mp.nstr(real_gap,hp.DIGITS),"high_precision_distortions":[mp.nstr(x,hp.DIGITS) for x in radii],
            "max_runtime_error":float(runtime_error),"resolved_hp_agreement":res["served_answer"]==real_winner if resolved else None,
            "numeric_agreement":True,"bounds_cover_distortion_plus_observed_runtime_error":not violations}


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--smoke",action="store_true");args=parser.parse_args()
    metadata={"schema_version":"www-reviewer-stress-v2", "primary_reference":"frozen numeric full-FP32",
              "dimension":16,"guard":NUMERICAL_GUARD,"scope":"empirical stress diagnostic, no universal floating-point guarantee"}
    if not args.smoke:
        frozen=freeze(SOURCES)
        metadata.update(frozen);save_once(OUT/"manifest.json",metadata)
    rows=[]
    with tempfile.TemporaryDirectory() as td:
        for case in cases():
            print("STRESS",case[0],flush=True)
            if not args.smoke:
                if freeze(SOURCES)!=frozen:
                    raise RuntimeError("STOP: source/environment changed during stress")
                name,qm,qc,tm,tc,dtype,inflated=case
                save_once(OUT/"inputs"/f"{name}.json",{"case":name,"query_mean":qm.tolist(),
                    "query_covariance":qc.tolist(),"target_means":tm.tolist(),
                    "target_covariances":tc.tolist(),"dtype":np.dtype(dtype).name,"inflated":inflated})
            try:
                row=execute_case(*case,Path(td))
            except Exception:
                if not args.smoke:
                    shutil.copytree(Path(td)/case[0],OUT/"STOP_runtime"/case[0],dirs_exist_ok=False)
                raise
            rows.append(row)
            if not args.smoke: save_once(OUT/"cases"/f"{case[0]}.json",row)
    summary={"status":"STRESS_V2_PASS","cases":len(rows),"wrong_numeric":0,
             "dimension":16,"states":{s:sum(r['serving']['state']==s for r in rows) for s in ('certified','refined','full_index_safe_path')},
             "max_runtime_error":max(r["max_runtime_error"] for r in rows),"scope":metadata["scope"]}
    if not args.smoke:save_once(OUT/"summary.json",summary)
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    try:main()
    except Exception as exc:
        if "--smoke" not in sys.argv:
            save_once(OUT/"STOP.json",{"error":str(exc)})
        raise
