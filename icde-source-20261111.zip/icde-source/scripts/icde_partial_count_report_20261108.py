"""Read-only audit and report of partial/factorized compilation experiments."""
from fractions import Fraction as Q
from collections import Counter
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_partial_count_20261108"


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path,obj):
    with path.open("x",encoding="utf-8") as handle:
        json.dump(obj,handle,ensure_ascii=False,indent=2,allow_nan=False)
        handle.write("\n")


def report(base):
    main = load(base/"attempt1/summary.json")
    factor = load(base/"factor_followup_attempt1/summary.json")
    checks = 0
    def require(condition,message):
        nonlocal checks
        if not condition:
            raise AssertionError(message)
        checks += 1
    for folder in ("attempt1","factor_followup_attempt1"):
        p = load(base/folder/"protocol.json")
        for group in ("code_sha256","input_sha256"):
            for name,digest in p[group].items():
                require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,"changed frozen source/input")
    p = load(base/"attempt1/protocol.json")
    expected = {(c["graph"],c["rank"],policy,repeat) for c in p["cases"] for policy in p["policies"] for repeat in range(p["repeats"])}
    actual = set()
    refs = {(r["graph"],r["rank"]):r["uniform_winners"] for r in main["references"]}
    for row in main["rows"]:
        key = row["graph"],row["rank"],row["policy"],row["repeat"]
        require(key not in actual,"duplicate main run")
        actual.add(key)
        require(row["splits"]<=p["max_splits"],"count budget exceeded")
        require(row["status"]!="stable" or row["winner"] in refs[row["graph"],row["rank"]],"wrong stable decision")
        require(row["status"]!="nonuniform" or not refs[row["graph"],row["rank"]],"wrong nonuniform decision")
    require(actual==expected,"missing declared main runs")
    f = load(base/"factor_followup_attempt1/protocol.json")
    expected = {(c["graph"],c["rank"],policy,repeat) for c in f["cases"] for policy in f["policies"] for repeat in range(f["repeats"])}
    actual = set()
    for row in factor["rows"]:
        key = row["graph"],row["rank"],row["policy"],row["repeat"]
        require(key not in actual,"duplicate follow-up run")
        actual.add(key)
        require(row["status"]!="stable" or row["winner"] in refs[row["graph"],row["rank"]],"unsafe stable followup")
        require(row["status"]!="nonuniform" or not refs[row["graph"],row["rank"]],"unsafe negative followup")
        if row["policy"].startswith("factor_"):
            require(row["probability_states_allocated"]==0,"factor method allocated joint probability table")
            require(row["count_splits"]<=f["max_splits"] and row["parameter_splits"]<=f["max_parameter_splits"],"two-space budget exceeded")
    require(actual==expected,"missing declared factor runs")
    aggregate = []
    for policy in p["policies"]:
        selected = [r for r in main["rows"] if r["policy"]==policy and r["repeat"]==0]
        aggregate.append({"policy":policy,"distinct_queries":len(selected),
            "statuses":dict(Counter(r["status"] for r in selected)),
            "point_score_states":sum(r["point_score_states"] for r in selected),
            "splits":sum(r["splits"] for r in selected)})
    case_rows = []
    for case in f["cases"]:
        row = {"graph":case["graph"],"rank":case["rank"],"count_states":case["count_states"]}
        for method in f["policies"]:
            a = next(r for r in factor["aggregates"] if r["graph"]==case["graph"] and r["rank"]==case["rank"] and r["policy"]==method)
            row[method] = {"milliseconds":a["median_seconds"]*1000,"status":a["status"],
                "count_splits":a["count_splits"],"parameter_splits":a["parameter_splits"],
                "point_score_states":a["point_score_states"]}
        case_rows.append(row)
    agreement_main = []
    for case in p["cases"]:
        rows = {r["policy"]:r for r in main["rows"] if r["graph"]==case["graph"] and r["rank"]==case["rank"] and r["repeat"]==0}
        agreement_main.append((rows["standard_mass"]["status"],rows["standard_mass"]["winner"]) == (rows["certificate"]["status"],rows["certificate"]["winner"]))
    factor_agreement = [r["factor_mass"]["status"]==r["factor_certificate"]["status"] for r in case_rows]
    result = {"status":"PASS","checks":checks,"main_aggregate":aggregate,"cost_rows":case_rows,
        "main_schedule_decision_agreement":sum(agreement_main),"main_distinct_queries":len(agreement_main),
        "factor_schedule_status_agreement":sum(factor_agreement),"factor_distinct_queries":len(factor_agreement),
        "total_strategy_runs":len(main["rows"])+len(factor["rows"]),
        "distinct_development_queries":len(p["cases"]),
        "gate":{"sound_implementation":"PASS_ON_AUDITED_CASES","block_compilation_feasibility":"PASS",
                "uniform_speed_advantage":"NOT_ESTABLISHED","independent_target_schedule_gain":"NOT_ESTABLISHED",
                "novelty_over_standard_inference":"NOT_ESTABLISHED","new_confirmation":"DEFER_UNTIL_TECHNICAL_INCREMENT"}}
    save(base/"analysis.json",result)
    save(base/"validation.json",{"status":"PASS","checks":checks,
        "main_sha256":hashlib.sha256((base/"attempt1/summary.json").read_bytes()).hexdigest(),
        "factor_sha256":hashlib.sha256((base/"factor_followup_attempt1/summary.json").read_bytes()).hexdigest(),
        "note":"finite accounting and reference audit, not general zero-error or novelty proof"})
    lines = ["# 部分编译与因子化强对照：已完成结果","","日期：2026-11-08。全部是已知开发查询，不是新确认。","",
        '[说明文本已清理]',"",
        '[说明文本已清理]',"",
        "## 冻结比较与规模","",
        "第一阶段使用此前28个开发query：完整精确法、标准最大质量细化、证书瓶颈细化，各3次重复，共252次运行。两种细化共用分组、带符号分数界、精确概率表、缓存、最长轴切分及推断规则；最多127次计数区域拆分。","",
        "第二阶段针对概率表开销，在同一8个较大query与2个已知遗漏query上加入因子化强对照：不构造联合参数表，使用单组矩阵和参数代表盒上的sum-product区间松弛，必要时同时细分计数与参数空间。两个因子化调度共用3:1动作规则、127次计数拆分和31次参数拆分上限。五种方法重新交错运行3次，共150次。","",
        "合计402次策略运行，但只有28个不同开发query；第二阶段10个是其子集。没有新训练、新数据来源或新前瞻确认。","",
        "## 评分状态减少不等于总时间下降","",
        "| 第一阶段方法 | 稳定query | 已证非稳定query | 单点计数状态评分总数 | 计数拆分总数 |",
        "| --- | ---: | ---: | ---: | ---: |"]
    for a in aggregate:
        lines.append(f"| {a['policy']} | {a['statuses'].get('stable',0)} | {a['statuses'].get('nonuniform',0)} | {a['point_score_states']} | {a['splits']} |")
    lines += ["","状态评分计数按每query一次确定性执行统计，不把3次计时重复累加。整块区域的界计算、概率更新与推断另有成本，不能把单点评分减少量换算为加速倍数。两种调度在28个query上的最终答案/状态全部一致。","",
        "## 同进程重测的成本与输出","",
        "下表为第二阶段3次准备对象计算的中位数，包含各方法的分组、根界、概率准备、界更新、推断和调度。未含原始语料准备、对象加载及持久化，不是冷启动服务延迟。标‘未决’的值不与完成判定直接换算加速倍数。","",
        "| 查询 | 完整精确/ms | 部分＋联合参数表/ms | 标准因子化/ms | 目标导向因子化/ms | 因子化结果 |",
        "| --- | ---: | ---: | ---: | ---: | --- |"]
    for r in case_rows:
        label = "稳定" if r["factor_certificate"]["status"]=="stable" else "未决"
        lines.append(f"| {r['graph']} q{r['rank']} | {r['dense_exact']['milliseconds']:.3f} | {r['certificate']['milliseconds']:.3f} | {r['factor_mass']['milliseconds']:.3f} | {r['factor_certificate']['milliseconds']:.3f} | {label} |")
    lines += ["","完整参数表的部分编译跳过了大多数计数点，但仍分配S大小的参数数组；多候选概率扫描和大整数更新成为瓶颈。因子化版本不分配该联合表，保留单组分布矩阵与有限区域，因此部分高置信度大query降至约1–4毫秒。其独立性与区域概率上下界均来自标准sum-product推断。","",
        "q36/q267在完整计数编译后可直接证明所有世界winner恒定，完整基线没有继续支付概率变换成本，因此约0.3毫秒优于部分法。","",
        '[说明文本已清理]',"",
        "两个已知稳定遗漏q113/q244可以被所有方法正确认证，但完整精确法约0.6毫秒，部分法与因子化法付出了更多管理成本。第二阶段两种因子化调度的10个query输出状态完全一致。","",
        "## 保证与审计","",
        "每个未决计数区域始终保留sound候选集合；计数空间保持完整无重叠覆盖。因子化版本另保持参数端点代表的完整无重叠覆盖；所有区域必须支持同一个稳定候选。非稳定输出必须对每个候选给出合法参数见证，不能把预算未决当作反例。","",
        "概率表和区域质量使用共同分母整数运算，分数界向外舍入。实验用独立完整计数结果核对全部输出、最终区域外包和参数见证，未发现错误认证/反例。5项部分编译测试及2项因子化测试通过。一般正确性依赖对应证明和模型合同，有限零错误不能外推为概率为零。","",
        "## 对贡献设计的影响","",
        "1. 按需编译在此查询类上确实可执行，表示与执行代价有明确的优劣区间。",
        '[说明文本已清理]',
        '[说明文本已清理]',
        "4. 当前得到的是更强且更完整的基线组和失败案例；强Regular所需的独立技术增量仍需针对完整查询编译/执行框架另行建立。暂不扩大新确认，不将本轮结果直接改写成已成立的新主算法。","",
        f"汇总核验{checks}项通过；原始阶段审计见各summary。冻结历史输入和数值代码哈希不变。","",
        "入口：[初始252次运行](attempt1/summary.json)、[因子化150次复核](factor_followup_attempt1/summary.json)、[分析](analysis.json)、[核验](validation.json)、[成本图](figures/partial_compilation_cost.pdf)。"]
    with (base/"RESULTS_ZH.md").open("x",encoding="utf-8") as handle:
        handle.write("\n".join(lines)+"\n")
    print(json.dumps({"validation":"PASS","checks":checks,"gate":result['gate']},ensure_ascii=False))


def figure(base):
    sys.path.insert(0,str(ROOT/".runtime/icde_plot_site"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    a = load(base/"analysis.json")
    rows = a["cost_rows"]
    destination = base/"figures"
    destination.mkdir(exist_ok=False)
    plt.rcParams.update({"font.size":9,"pdf.fonttype":42,"axes.spines.top":False,"axes.spines.right":False})
    fig,ax = plt.subplots(figsize=(10.2,5))
    x = list(range(len(rows)))
    for key,label,color,marker in (("dense_exact","Complete count exact","#366d91","o"),
            ("certificate","Partial with joint parameter table","#c78d48","s"),
            ("factor_certificate","Partial with factorized parameter bounds","#408675","^")):
        ax.plot(x,[r[key]["milliseconds"] for r in rows],marker=marker,color=color,label=label)
    for i,r in enumerate(rows):
        if r['factor_certificate']['status']=="unresolved":
            y = r['factor_certificate']['milliseconds']
            ax.scatter([i],[y],marker="x",s=90,color="#a33a3a",zorder=5)
            ax.annotate("Unresolved at refinement caps",(i,y),xytext=(5,8),textcoords="offset points",fontsize=8,color="#943232")
    ax.set_yscale("log")
    ax.set(xticks=x,xticklabels=[f"{r['graph'].upper()}-{r['rank']}" for r in rows],
        ylabel="Prepared-query compute (ms, log scale)",title="Partial compilation saves state scoring; probability representation controls cost")
    ax.tick_params(axis='x',rotation=45)
    ax.legend(frameon=False,loc="upper left",fontsize=8)
    ax.grid(axis='y',color='#e4e8ec',linewidth=.5)
    fig.text(.5,.025,"Known development subset; medians of 3 interleaved runs. An unresolved result differs from a completed decision.",
        ha='center',fontsize=8,color='#56616b')
    fig.tight_layout(rect=(0,.06,1,1))
    for suffix in ('png','pdf'):
        fig.savefig(destination/f"partial_compilation_cost.{suffix}",dpi=180,bbox_inches='tight')
    plt.close(fig)
    print(str(destination))


if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase',choices=('report','figure'),required=True)
    parser.add_argument('--output',type=Path,default=BASE)
    args = parser.parse_args()
    {'report':report,'figure':figure}[args.phase](args.output.resolve())
