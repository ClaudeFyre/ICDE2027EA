"""Cooperative deadline adapter without modifying frozen solver sources.

The adapter intercepts EXISTING perf_counter checkpoints. It cannot interrupt
a long native operation; late results are discarded and overruns are recorded.
This is not a hard real-time SLA. Real timestamps are otherwise unchanged.
"""
from __future__ import annotations

import time
from typing import Callable

REAL_COUNTER = time.perf_counter


class CooperativeBudgetExpired(BaseException):
    """Dedicated interruption, not swallowed by ordinary solver error catches."""


def budgeted_call(function: Callable, seconds: float):
    if seconds <= 0:
        raise ValueError("budget must be positive")
    previous = time.perf_counter
    started = REAL_COUNTER()
    calls = 0
    raw = None
    expired = False
    def checkpoint():
        nonlocal calls
        calls += 1
        now = REAL_COUNTER()
        if now-started >= seconds:
            raise CooperativeBudgetExpired()
        return now
    try:
        time.perf_counter = checkpoint
        raw = function()
    except CooperativeBudgetExpired:
        expired = True
    finally:
        time.perf_counter = previous
    elapsed = REAL_COUNTER()-started
    if elapsed > seconds:
        expired = True
    if expired:
        raw = None
    return {"raw":raw,"timed_out":expired,"compute_seconds":elapsed,
            "overrun_seconds":max(0.,elapsed-seconds),"clock_checkpoints":calls,
            "budget_seconds":seconds}
