"""Independent accounting and per-approved-block scalar extremum verification."""
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path
import math
import numpy as np

from icde_grouped_inventory_20261108 import ROOT,load,save,sha,identities
from icde_pair_event_tightness_20261108 import BASE as TIGHT
from icde_pruned_block_comparison_20261109 import BASE as MATCHED,prune
from icde_sparse_degree_20261108 import read_graph,read_query,restrict
from icde_grouped_exact_20261108 import compile_counts,solve_counts,direct_representative_probabilities
from run_vldb_interval_gate_v1 import clipped_box

BASE=MATCHED.parent


def main():
    checks=0
    for out in (TIGHT,BASE/'attempt1',MATCHED):
        p,s=load(out/'protocol.json'),load(out/'summary.json')
        checks+=identities(p,False)
        if s['protocol_sha256']!=sha(out/'protocol.json'):raise AssertionError('broken provenance')
    t=load(TIGHT/'summary.json');s=load(MATCHED/'summary.json');p=load(MATCHED/'protocol.json')
    for row in t['rows']:
        for pair in row['pairs']:
            a,b=Q(pair['pair_gap_exact']),Q(pair['separate_gap_exact'])
            if a-b!=Q(pair['tightness_gain_exact']) or a<b:raise AssertionError('invalid tightness difference')
            checks+=1
        chosen=[r for r in row['pairs'] if r['candidate']==row['nominal_winner']]
        difference=min(Q(r['pair_gap_exact']) for r in chosen)-min(Q(r['separate_gap_exact']) for r in chosen)
        if difference!=Q(row['bottleneck_gain_exact']):raise AssertionError('wrong bottleneck')
        if row['retained_candidates']==2 and difference!=0:raise AssertionError('binary complement identity violated')
        checks+=2
    expected={(r['graph'],r['rank'],m) for r in p['cases'] for m in p['policies']}
    actual=set()
    for row in s['rows']:
        key=row['graph'],row['rank'],row['policy']
        if key in actual:raise AssertionError('duplicate method run')
        actual.add(key)
        if row!=load(MATCHED/'cases'/f"{row['graph']}_q{row['rank']:03d}_{row['policy']}.json"):
            raise AssertionError('per-run artifact differs')
        if row['details']['status']=='stable' and (row['timed_out'] or row['compute_seconds']>.2):
            raise AssertionError('late certificate counted')
        if row['details']['lower_gap']>row['details']['upper_gap']:raise AssertionError('reversed bound')
        checks+=4
    if actual!=expected or len(actual)!=1036:raise AssertionError('incomplete all-259 matrix')
    for method,aggregate in s['aggregates'].items():
        selected=[r for r in s['rows'] if r['policy']==method]
        if dict(Counter(r['details']['status'] for r in selected))!=aggregate['statuses']:
            raise AssertionError('status totals differ')
        if not math.isclose(sum(r['compute_seconds'] for r in selected),aggregate['actual_compute_seconds'],abs_tol=1e-9):
            raise AssertionError('cost totals differ')
        checks+=2
    inventories=load(MATCHED/'anchor_pruning_inventory.json')['rows']
    inv={(r['graph'],r['rank']):r for r in inventories}
    indexes={graph:read_graph(graph) for graph in ('dw','enfr')}
    approvals={(r['graph'],r['rank']):r for r in s['rows'] if r['policy']=='block_event2' and r['details']['status']=='stable'}
    verified_blocks=scalar_probes=0
    for i,case in enumerate(p['cases']):
        key=case['graph'],case['rank']
        kernel,meta=read_query(*key,indexes[key[0]])
        focus,selected=prune(kernel)
        if focus!=inv[key]['focus_original_index'] or selected!=inv[key]['retained_original_indices']:
            raise AssertionError('common pruning metadata changed')
        checks+=2
        if key not in approvals:continue
        details=approvals[key]['details'];error_sum=Q(0);largest=Q(0)
        for block in details.get('blocks',[]):
            sub,mapping=restrict(kernel,block['candidates'])
            low,high=clipped_box(np.full(len(sub.edge_indices),.9),.25)
            compiled=compile_counts(sub,low,high,32768);exact=solve_counts(compiled,len(sub.candidates))
            den=exact['denominator'];w=mapping.index(focus)
            true_min=Q(int(np.min(exact['numerators'][w])),den)
            if str(true_min)!=block['min_anchor_probability_exact']:raise AssertionError('wrong anchor event minimum')
            if Q(block['error_upper_exact'])!=1-true_min:raise AssertionError('wrong block failure probability')
            objectives=[(w,int(np.argmin(exact['numerators'][w])))]
            for d in range(len(mapping)):
                if d==w:continue
                maximum=Q(int(np.max(exact['numerators'][d])),den)
                if str(maximum)!=block['rival_upper_exact'][str(mapping[d])]:raise AssertionError('wrong rival event maximum')
                objectives.append((d,int(np.argmax(exact['numerators'][d]))));largest=max(largest,maximum)
                checks+=1
            # Independent scalar sum-product at every claimed local extremum;
            # does not reuse the multi-axis tensor contraction to evaluate it.
            for candidate,at in objectives:
                parameter=tuple(map(int,np.unravel_index(at,compiled['shape'])))
                direct=direct_representative_probabilities(compiled,exact['matrices'],parameter,len(mapping))
                for c,value in enumerate(direct):
                    if value!=int(exact['numerators'][c][parameter]):raise AssertionError('scalar extremum verification failed')
                    checks+=1
                scalar_probes+=1
            error_sum+=1-true_min;verified_blocks+=1;checks+=2
        if details.get('blocks'):
            lower=max(Q(0),1-error_sum)-largest
            if lower<=0 or str(lower)!=details['lower_gap_exact']:
                raise AssertionError('unsafe composed block approval')
            if Q.from_float(details['lower_gap'])>lower:raise AssertionError('lower bound rounded inward')
            if any(d not in selected for block in details['blocks'] for d in block['candidates']):
                raise AssertionError('block used a removed candidate')
            checks+=3
        elif len(selected)!=1:
            # Common frontend may establish the same all-world proof on a
            # reduced complete scope, so repeat the score-separation check.
            lo,hi=kernel.score_intervals(np.zeros((1,len(kernel.edge_indices)),dtype=bool),
                                         np.ones((1,len(kernel.edge_indices)),dtype=bool))
            upper=hi[0].copy();upper[focus]=-np.inf
            if not lo[0,focus]>upper.max():raise AssertionError('unsupported empty-block approval')
            checks+=1
        if (i+1)%30==0:print(f'Validated {i+1}/259 query identities',flush=True)
    obj={'status':'PASS','checks':checks,'tightness_queries':len(t['rows']),
         'method_runs':1036,'queries':259,'verified_block_approvals':len(approvals),
         'verified_exact_blocks':verified_blocks,'independent_scalar_extremum_probes':scalar_probes,
         'summary_sha256':sha(MATCHED/'summary.json'),'pruning_inventory_sha256':sha(MATCHED/'anchor_pruning_inventory.json'),
         'validator_sha256':sha(Path(__file__)),
         'scope':'frozen hashes, per-run/matrix/cost accounting, all pruning records, all approved local block extrema by independent scalar evaluation, exact composition',
         'limitations':'unknown full truth on 240 queries; local exact tests share the proved count encoding; no claim of empirical zero error over unseen workloads'}
    save(BASE/'validation_20261109.json',obj)
    print(obj,flush=True)


if __name__=='__main__':main()
