"""Bounded exact screens of Jaccard nonmonotonicity and a clause gadget.

All data are predeclared finite toys. The clause screen checks a necessary
encoding property before addressing the target B=1 scoring restriction.
"""
import argparse
from fractions import Fraction as Q
from itertools import product
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_nonlinear_theory_20261109/attempt1"
GATE = ROOT / "papers/icde/regular2027/NONLINEAR_THEORY_GATE_AND_SCREEN_20261109.md"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    BASE.mkdir(parents=True, exist_ok=True)
    with (BASE / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def load(name):
    return json.loads((BASE / name).read_text(encoding="utf-8"))


def identities(protocol):
    for name, expected in protocol["input_sha256"].items():
        if digest(ROOT / name) != expected:
            raise AssertionError(f"Frozen identity changed: {name}")


def freeze():
    save("protocol.json", {
        "input_sha256": {path.relative_to(ROOT).as_posix(): digest(path) for path in (Path(__file__), GATE)},
        "jaccard_universe_sizes": [2, 3, 4, 5, 6],
        "jaccard_scope": "one uncertain source neighborhood; two fixed nonempty candidate neighborhoods; search first strict opposite influence on the same source edge",
        "candidate_tie_priority": "w before d; all retained witnesses require strict inequalities",
        "clause_blocks": [4, 8, 16, 32, 64],
        "clause_formula": "all eight signed three-literal clauses on three variables, hence unsatisfiable",
        "clause_threshold": "sum false-literal counts must exceed 2n+1/2 to defeat d",
        "legal_parameter_box": [0.25, 0.75], "tested_parameter": 0.5,
        "clause_score_scope": "predicate-level block gadget; adding common sum C_i makes all coefficients 0,1,2; B=1 conversion is outside this screen",
        "claim_limit": "a failed gadget rejects that construction; it does not settle the growth-axis hardness problem",
    })


def recover():
    protocol = load("protocol.json")
    identities(protocol)
    if (BASE / "screens.json").exists():
        raise FileExistsError("Results already exist")
    save("recovery.json", {"status": "PASS", "identity_checks": len(protocol["input_sha256"]),
        "protocol_sha256": digest(BASE / "protocol.json")})


def jaccard_screen(sizes):
    evaluated_pairs = 0
    for size in sizes:
        worlds = list(range(1 << size))
        neighborhoods = list(range(1, 1 << size))
        score = {a: [Q((s & a).bit_count(), (s | a).bit_count()) for s in worlds] for a in neighborhoods}
        for a, b in product(neighborhoods, repeat=2):
            if a == b:
                continue
            evaluated_pairs += 1
            for edge in range(size):
                witnesses = {}
                for s in worlds:
                    if s & (1 << edge):
                        continue
                    after = s | (1 << edge)
                    before_difference = score[a][s] - score[b][s]
                    after_difference = score[a][after] - score[b][after]
                    if before_difference == 0 or after_difference == 0:
                        continue
                    before = 1 if before_difference > 0 else -1
                    later = 1 if after_difference > 0 else -1
                    if before == later:
                        continue
                    direction = "increase" if later > before else "decrease"
                    if direction not in witnesses:
                        witnesses[direction] = {"source_before_mask": s, "source_after_mask": after,
                            "scores_before_exact": [str(score[a][s]), str(score[b][s])],
                            "scores_after_exact": [str(score[a][after]), str(score[b][after])],
                            "D_before": before, "D_after": later}
                if len(witnesses) == 2:
                    return {"found": True, "universe_size": size, "fixed_w_mask": a,
                        "fixed_d_mask": b, "edge": edge, "evaluated_candidate_pairs": evaluated_pairs,
                        **witnesses}
    return {"found": False, "evaluated_candidate_pairs": evaluated_pairs}


def clause_screen(block_sizes):
    results = []
    # Each assignment violates the clause that contains its three false literals.
    formula_unsatisfiable = all(any(all(bit != sign for bit, sign in zip(assignment, clause))
        for clause in product((0, 1), repeat=3)) for assignment in product((0, 1), repeat=3))
    if not formula_unsatisfiable:
        raise AssertionError("Frozen formula is not unsatisfiable")
    for n in block_sizes:
        masses = [math.comb(n, c) for c in range(n + 1)]
        safe_mass = 0
        for counts in product(range(n + 1), repeat=3):
            # Among all sign patterns the largest false-literal sum chooses
            # max(C_i,n-C_i) independently for each block.
            if sum(max(c, n - c) for c in counts) <= 2 * n:
                safe_mass += math.prod(masses[c] for c in counts)
        probability = Q(safe_mass, 2**(3 * n))
        results.append({"block_size": n, "independent_edges": 3 * n,
            "d_unique_win_probability_exact": str(probability),
            "d_unique_win_probability": float(probability),
            "d_pair_gap_lower_bound": float(2 * probability - 1),
            "union_hoeffding_lower_bound": 1 - 8 * math.exp(-n / 6)})
    return {"formula_unsatisfiable": formula_unsatisfiable, "parameters_all": .5,
        "parameter_witness_legal": True, "cases": results}


def run():
    protocol, recovery = load("protocol.json"), load("recovery.json")
    identities(protocol)
    if recovery["status"] != "PASS" or recovery["protocol_sha256"] != digest(BASE / "protocol.json"):
        raise AssertionError("Recovery does not match protocol")
    save("screens.json", {"protocol_sha256": digest(BASE / "protocol.json"),
        "jaccard": jaccard_screen(protocol["jaccard_universe_sizes"]),
        "clause": clause_screen(protocol["clause_blocks"])})
    print("Completed finite nonlinear and block-gadget screens", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("freeze", "recover", "run"))
    {"freeze": freeze, "recover": recover, "run": run}[parser.parse_args().mode]()
