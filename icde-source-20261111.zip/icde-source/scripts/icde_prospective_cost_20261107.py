"""Independent exact sub-study and fresh-process prepared-service timings."""
from __future__ import annotations
import argparse
from fractions import Fraction
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import icde_prospective_20261107 as study


def exact():
    from icde_gate_exact_review import full_box_reference
    from icde_gate_exact_audit_20261105 import reverse_vertex_distributions, direct_distribution
    from run_vldb_interval_gate_v1 import clipped_box
    out=study.BASE/"new_exact_reference"
    out.mkdir(parents=True,exist_ok=False)
    references,actions=[],[]
    for graph in ("dw","enfr"):
        prepared=study.load(study.BASE/"prepared"/graph/"summary.json")
        selected=[r for r in prepared["records"] if r["partition"]=="confirmation" and r["retained_candidates"]>1 and r["scope_edges"]<=8]
        for record in selected:
            kernel,metadata=study.read_query(graph,record["rank"])
            k,m=len(kernel.candidates),len(kernel.edge_indices)
            states=(np.arange(1<<m,dtype=np.uint64)[:,None] >> np.arange(m,dtype=np.uint64))&1
            before=time.perf_counter()
            winners=np.argmax(kernel.scores(states.astype(np.bool_)),axis=1).tolist()
            scoring_seconds=time.perf_counter()-before
            q=np.full(m,.9,dtype=np.float64)
            for tau in study.TAUS:
                low,high=clipped_box(q,tau)
                before=time.perf_counter()
                reference=full_box_reference(winners,k,q,low,high)
                exact_seconds=time.perf_counter()-before
                before=time.perf_counter()
                distributions=reverse_vertex_distributions(winners,k,tuple(map(Fraction.from_float,low)),tuple(map(Fraction.from_float,high)))
                for result in reference["candidate_results"]:
                    candidate=result["candidate_index"]
                    for pair in result["pair_gap_ranges"]:
                        competitor=pair["competitor_index"]
                        gaps=[distributions[candidate][v]-distributions[competitor][v] for v in range(1<<m)]
                        if min(gaps)!=Fraction(pair["minimum_gap"]) or max(gaps)!=Fraction(pair["maximum_gap"]):
                            raise AssertionError("independent full-box audit mismatch")
                direct=direct_distribution(winners,k,tuple(map(Fraction.from_float,q)))
                if direct!=list(map(Fraction,reference["nominal_probabilities_exact"])):
                    raise AssertionError("independent nominal enumeration mismatch")
                reference.update({"graph":graph,"rank":record["rank"],"query_id":metadata["query_id"],"tau":tau,
                    "candidates":list(kernel.candidates),"scoring_seconds":scoring_seconds,
                    "exact_construction_seconds":exact_seconds,"independent_audit_seconds":time.perf_counter()-before})
                path=out/f"{graph}_q{record['rank']:03d}_t{tau}.json"
                study.save(path,reference)
                references.append({"graph":graph,"rank":record["rank"],"tau":tau,"safe_modes":reference["uniform_winners"],
                    "reference_seconds":scoring_seconds+exact_seconds,"scope_edges":m,"path":path.relative_to(study.ROOT).as_posix()})
    lookup={(r["graph"],r["rank"],r["tau"]):r for r in references}
    for summary in sorted((study.BASE/"confirmation").glob("primary_*/summary.json")):
        for row in study.load(summary)["rows"]:
            key=row["graph"],row["rank"],row["tau"]
            if key not in lookup:
                continue
            raw=study.load(study.ROOT/row["case"])
            index=study.load(study.ROOT/lookup[key]["path"])["candidates"].index(raw["candidate"]) if raw["candidate"] is not None else None
            false_clear=row["delivered_within_budget"] and index not in lookup[key]["safe_modes"]
            if false_clear:
                raise AssertionError("delivered certificate fails exact full-box reference")
            actions.append({"graph":row["graph"],"rank":row["rank"],"policy":row["policy"],"seed":row["seed"],
                "delivered":row["delivered_within_budget"],"false_clear":bool(false_clear),
                "avoidable_unresolved":not row["delivered_within_budget"] and bool(lookup[key]["safe_modes"]),
                "no_uniform_unique_mode":not bool(lookup[key]["safe_modes"])})
    study.save(out/"summary.json",{"references":references,"action_audit":actions,
        "distinct_confirmation_queries":len({(r["graph"],r["rank"]) for r in references}),
        "full_box_references":len(references),"audited_primary_actions":len(actions),
        "false_clear":sum(r["false_clear"] for r in actions),
        "selection":"all confirmation queries with candidate_count>1 and complete scope<=8; not representative of all full-graph queries",
        "two_independent_fraction_calculations_agree":True,
        "reference_cost_is_not_free_serving":True})
    print(json.dumps({"reference_cases":len(references),"audited_actions":len(actions)}),flush=True)


def worker(graph,rank,policy,deadline,output):
    started=time.perf_counter()
    kernel,metadata=study.read_query(graph,rank)
    loading=time.perf_counter()-started
    row=study.execute_case(kernel,metadata,.25,211,policy,deadline)
    row["prepared_artifact_load_seconds"]=loading
    study.save(output,row)


def raw_worker(graph,rank,policy,deadline,output):
    # Fresh raw-corpus construction, not a prepared-artifact timing mislabeled
    # cold. The input-selected pilot query and full 30K corpus are unchanged.
    original_base=study.BASE
    selection=study.load(original_base/"selection_protocol.json")
    source=selection["graphs"][graph]["pilot"][rank]
    study.BASE=Path(output).parent/"raw_state"
    study.BASE.mkdir(parents=True,exist_ok=False)
    selection["graphs"][graph]["pilot"]=[source]
    selection["graphs"][graph]["confirmation"]=[]
    study.save(study.BASE/"selection_protocol.json",selection)
    started=time.perf_counter()
    study.prepare(graph)
    prepared_seconds=time.perf_counter()-started
    kernel,metadata=study.read_query(graph,0)
    row=study.execute_case(kernel,metadata,.25,211,policy,deadline)
    row.update({"full_raw_preparation_seconds":prepared_seconds,"original_pilot_rank":rank,
        "inside_compute_budget_only":row["certified"],
        "cold_contract":"parent time includes complete raw graph/corpus preparation and scoring artifacts, then online query and persistence; compute deadline applies only after preparation, not whole cold request"})
    study.save(output,row)


def cold():
    out=study.BASE/"prepared_service_cold"
    out.mkdir(parents=True,exist_ok=False)
    protocol=study.load(study.BASE/"confirmation_protocol.json")
    records=[]
    raw_records=[]
    for graph in ("dw","enfr"):
        records_in=study.load(study.BASE/"prepared"/graph/"summary.json")["records"]
        # Input-only subset for interpretable repeated timing, not all-query tail claims.
        rank=next(r["rank"] for r in records_in if r["partition"]=="pilot" and 1<r["retained_candidates"]<=32)
        deadline=protocol["budgets"][graph]["primary_deadline_seconds"]
        for repeat in range(3):
            order=list(study.POLICIES)
            shift=repeat%len(order)
            order=order[shift:]+order[:shift]
            for policy in order:
                path=out/f"{graph}_r{repeat}_{policy}.json"
                command=[sys.executable,__file__,"worker","--graph",graph,"--rank",str(rank),"--policy",policy,
                    "--deadline",str(deadline),"--output",str(path)]
                before=time.perf_counter()
                completed=subprocess.run(command,cwd=study.ROOT,capture_output=True,text=True,timeout=120)
                elapsed=time.perf_counter()-before
                if completed.returncode:
                    raise RuntimeError(completed.stderr[-2000:])
                records.append({"graph":graph,"rank":rank,"repeat":repeat,"policy":policy,
                    "parent_observed_process_to_exit_seconds":elapsed,"case_sha256":study.sha(path),
                    "certified_inside_compute_budget":study.load(path)["certified"],
                    "interpretation":"fresh process with prepared static artifacts; includes imports/load/compute/persistence/exit; raw corpus construction separately paid"})
        for policy in study.POLICIES:
            raw_dir=out/f"raw_{graph}_{policy}"
            raw_dir.mkdir()
            path=raw_dir/"result.json"
            command=[sys.executable,__file__,"raw_worker","--graph",graph,"--rank",str(rank),"--policy",policy,
                "--deadline",str(deadline),"--output",str(path)]
            before=time.perf_counter()
            completed=subprocess.run(command,cwd=study.ROOT,capture_output=True,text=True,timeout=120)
            elapsed=time.perf_counter()-before
            if completed.returncode:raise RuntimeError(completed.stderr[-2000:])
            raw_records.append({"graph":graph,"rank":rank,"policy":policy,
                "parent_observed_full_raw_cold_seconds":elapsed,"case_sha256":study.sha(path),
                "full_raw_preparation_seconds":study.load(path)["full_raw_preparation_seconds"],
                "interpretation":"single descriptive raw-input cold repetition per graph/policy; not a latency distribution or warm-budget completion claim"})
    study.save(out/"summary.json",{"records":records,"process_runs":len(records),"raw_records":raw_records,"raw_process_runs":len(raw_records),"os_cache_flushed":False,
        "tail_latency_claim":False,"selection":"one first pilot query per graph with 2..32 retained candidates, chosen by input properties only"})


def witnesses():
    """Exploratory exact point-law witnesses, not additional nominal samples."""
    out=study.BASE/"full_cube_witnesses"
    out.mkdir(parents=True,exist_ok=False)
    seeds=[101,103,107,109,113,127]
    study.save(out/"protocol_before_probes.json",{"status":"EXPLORATORY_AFTER_PRIMARY_BEFORE_PROBES",
        "probe_worlds":["all_zero","all_one"]+seeds,"selection":"all512 frozen confirmation queries",
        "proof":"For p=z in the full Bernoulli cube the law is a point mass, so its unique modal answer is Y(z); two different Y values disprove a uniform answer.",
        "limits":"Only tau=1 over all dynamic coordinates; no conclusion from a failure to find differing winners; not a new inference method or nominal samples",
        "script_sha256":study.sha(__file__)})
    found=[]
    graph_rows={}
    started=time.perf_counter()
    for graph in ("dw","enfr"):
        folder=study.DATA/graph
        entities=study.tsv(folder/"entities.tsv")
        triples=study.tsv(folder/"triples.tsv")
        ids=[r["entity_id"] for r in entities]
        positions={entity:i for i,entity in enumerate(ids)}
        h=np.asarray([positions[r["head_id"]] for r in triples],dtype=np.intp)
        t=np.asarray([positions[r["tail_id"]] for r in triples],dtype=np.intp)
        masks=np.stack([np.zeros(len(triples),dtype=np.bool_),np.ones(len(triples),dtype=np.bool_)]+
            [np.random.default_rng(seed).integers(0,2,len(triples),dtype=np.int8).astype(np.bool_) for seed in seeds])
        degrees=np.zeros((len(masks),len(ids),2),dtype=np.int64)
        for index,mask in enumerate(masks):
            np.add.at(degrees[index,:,0],h[mask],1)
            np.add.at(degrees[index,:,1],t[mask],1)
        with (out/f"{graph}_point_laws.npz").open("xb") as handle:
            np.savez_compressed(handle,binary_parameters=masks)
        rows=[]
        for rank in range(32,288):
            path=study.BASE/"prepared"/graph/f"q{rank:03d}.npz"
            metadata=study.load(path.with_suffix(".json"))
            with np.load(path,allow_pickle=False) as data:
                attribute=data["attribute"].copy()
                lexical=data["lexical"].copy()
            candidate_positions=np.asarray([positions[c] for c in metadata["candidates"]],dtype=np.intp)
            source_positions=positions[metadata["query_id"]]
            distances=np.abs(degrees[:,source_positions,None,:]-degrees[:,candidate_positions,:]).sum(axis=2).astype(np.float64)
            scores=.8*attribute[None,:]+(1.-.8)*(.6*lexical[None,:]+.4*(1./(1.+distances)))
            winners=np.argmax(scores,axis=1)
            different=next((i for i in range(1,len(masks)) if winners[i]!=winners[0]),None)
            row={"graph":graph,"rank":rank,"query_id":metadata["query_id"],"point_winners":[metadata["candidates"][i] for i in winners],
                "witness_found":different is not None,"witness_world_indices":[0,different] if different is not None else None,
                "unique_modal_probabilities_at_point_laws":["1","1"] if different is not None else None,
                "retained_candidates":len(attribute),"scope_edges":metadata["scope_edges"],"prepared_kernel_sha256":metadata["kernel_sha256"]}
            rows.append(row)
            if different is not None:found.append((graph,rank))
        graph_rows[graph]=rows
        print(f"{graph}: full-cube witnesses {sum(r['witness_found'] for r in rows)}/256",flush=True)
    found=set(found)
    contradicted=[]
    for summary in (study.BASE/"confirmation").glob("sensitivity_*/summary.json"):
        for row in study.load(summary)["rows"]:
            if row["tau"]==1 and row["delivered_within_budget"] and (row["graph"],row["rank"]) in found:
                contradicted.append(row["case"])
    if contradicted:raise AssertionError("a full-cube certificate contradicts an exact point-law witness")
    pairs={}
    for summary in (study.BASE/"confirmation").glob("primary_*/summary.json"):
        for row in study.load(summary)["rows"]:
            pairs.setdefault((row["graph"],row["rank"],row["seed"]),{})[row["policy"]]=row
    incremental={}
    for graph in ("dw","enfr"):
        incremental[graph]={}
        for policy in ("eager","lazy"):
            additions=[(key,values) for key,values in pairs.items() if key[0]==graph and values[policy]["delivered_within_budget"] and not values["direct"]["delivered_within_budget"]]
            incremental[graph][policy]={"paid_only_cases_vs_direct":len(additions),
                "paid_only_cases_with_proven_nonconstant_world_winner":sum((key[0],key[1]) in found for key,values in additions)}
    study.save(out/"summary.json",{"status":"COMPLETE_EXPLORATORY_POINT_LAW_WITNESSES","graphs":graph_rows,
        "witnesses":len(found),"distinct_queries":512,"probe_worlds_per_graph":8,
        "primary_increment_diagnostic":incremental,
        "restricted_family_interpretation":"A changing deterministic-world winner does not refute tau=.25 modal robustness; it proves those gains cannot be replaced by any all-world-invariant-winner certificate.",
        "elapsed_seconds":time.perf_counter()-started,"contradicted_delivered_certificates":contradicted,
        "no_witness_is_not_a_stability_certificate":True,"new_nominal_confidence_samples":0})


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("exact","cold","worker","raw_worker","witnesses"))
    parser.add_argument("--graph")
    parser.add_argument("--rank",type=int)
    parser.add_argument("--policy")
    parser.add_argument("--deadline",type=float)
    parser.add_argument("--output")
    args=parser.parse_args()
    if args.command=="exact":exact()
    elif args.command=="cold":cold()
    elif args.command=="witnesses":witnesses()
    elif args.command=="worker":worker(args.graph,args.rank,args.policy,args.deadline,args.output)
    else:raw_worker(args.graph,args.rank,args.policy,args.deadline,args.output)


if __name__=="__main__":main()
