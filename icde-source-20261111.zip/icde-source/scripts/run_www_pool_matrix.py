"""One-command driver for the candidate-pool scaling run.

    python scripts/run_www_pool_matrix.py --preflight-only
    python scripts/run_www_pool_matrix.py --smoke
    python scripts/run_www_pool_matrix.py

Writes only under results/pool_frontier_v1. Nothing frozen is touched.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import csv
import sys
from pathlib import Path

from run_www_workload_audit_matrix import ROOT, CELLS, checkpoint, profile, sha256

sys.path.insert(0, str(ROOT / "src"))
from pkgea.contracts import dataset_content_digest  # noqa: E402

RESULTS = ROOT / "nodes/04_www_distributional/results/pool_frontier_v1"
SPEC = "papers/www/POOL_SCALING_SPEC.md"
# 1,012 reproduces the pool every earlier run used, so the curve extends rather
# than replaces the existing evidence. The top of each cell's curve is that
# graph's whole target side, which differs per graph: D--W 4,069, EN--FR 3,885,
# EventEA 3,074. Requesting a fixed 4,000 everywhere would fail on EventEA.
LIMITS = (512, 1012, 2000, 3000)
SMOKE_CELL = ("dw", "relation", "independent")
BUDGET = 0.8
IMPLEMENTATIONS = (
    "scripts/run_www_fixed_index_audit.py",
    "scripts/www_fixed_index_audit.py",
    "scripts/www_budget_frontier.py",
    "scripts/www_pool_frontier.py",
    "scripts/summarize_www_pool_frontier.py",
    "scripts/run_www_equal_budget.py",
    "src/pkgea/www_fsl.py",
    SPEC,
)


def slug(cell):
    return "_".join(cell)


def target_pool_size(profile_path: Path) -> int:
    """How many target-side entities this probe actually has."""

    with (profile_path / "entities.tsv").open(encoding="utf-8-sig", newline="") as handle:
        return sum(1 for row in csv.DictReader(handle, delimiter="\t")
                   if row["graph_id"] == "target")


def plan(cells, limits, smoke=False):
    tasks = []
    missing = []
    for cell in cells:
        graph, family, dependence = cell
        checkpoint_path, profile_path = checkpoint(graph, family), profile(graph, dependence)
        if not checkpoint_path.is_file():
            missing.append(f"checkpoint {checkpoint_path}")
        if not profile_path.is_dir():
            missing.append(f"profile {profile_path}")
        if not checkpoint_path.is_file() or not profile_path.is_dir():
            continue
        name = slug(cell)
        pool = target_pool_size(profile_path)
        run_pool = min(pool, 1012) if smoke else pool
        cell_limits = sorted({v for v in limits if v < run_pool} | {run_pool})
        output = RESULTS / (f"smoke_{name}.json" if smoke else f"{name}.json")
        tasks.append({
            "cell": name,
            "checkpoint": str(checkpoint_path.relative_to(ROOT)).replace("\\", "/"),
            "checkpoint_sha256": sha256(checkpoint_path),
            "profile": str(profile_path.relative_to(ROOT)).replace("\\", "/"),
            "content_digest": dataset_content_digest(profile_path),
            "output": str(output.relative_to(ROOT)).replace("\\", "/"),
            "target_pool_size": pool,
            "candidate_limits": cell_limits,
            "command": [
                sys.executable, "scripts/run_www_fixed_index_audit.py",
                str(output.relative_to(ROOT)),
                "--checkpoint", str(checkpoint_path.relative_to(ROOT)),
                "--profile", str(profile_path.relative_to(ROOT)),
                "--cell", name,
                "--candidate-pool", "graph",
                "--candidate-limit", str(run_pool),
                "--candidate-limits", *[str(v) for v in cell_limits],
                "--budget-fractions", f"{BUDGET:g}",
            ],
        })
    if missing:
        raise RuntimeError("missing experiment inputs:\n  " + "\n  ".join(sorted(set(missing))))
    return tasks


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--limits", nargs="+", type=int, default=list(LIMITS))
    args = parser.parse_args()

    limits = tuple(sorted({int(v) for v in args.limits}))
    cells = [SMOKE_CELL] if args.smoke else list(CELLS)
    if args.smoke:
        limits = (512, 1012)
    RESULTS.mkdir(parents=True, exist_ok=True)

    tasks = plan(cells, limits, smoke=args.smoke)
    manifest = {
        "schema_version": "pkgea-www-pool-frontier-v1",
        "specification": SPEC,
        "budget_fraction": BUDGET,
        "candidate_limits": list(limits),
        "smoke": bool(args.smoke),
        "implementations": {path: sha256(ROOT / path) for path in IMPLEMENTATIONS},
        "tasks": tasks,
    }
    path = RESULTS / ("smoke_manifest.json" if args.smoke else "manifest.json")
    if path.exists():
        if json.loads(path.read_text(encoding="utf-8")) != manifest:
            raise RuntimeError(
                f"{path.name} differs from the frozen plan; inputs or implementation changed"
            )
    else:
        with path.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(manifest, indent=2, sort_keys=True) + "\n")

    print(f"PREFLIGHT PASS: {len(tasks)} cells, budget {BUDGET}", flush=True)
    for task in tasks:
        print(f"  {task['cell']}: pools {task['candidate_limits']}", flush=True)
    if args.preflight_only:
        return 0

    for index, task in enumerate(tasks, 1):
        print(f"\n=== [{index}/{len(tasks)}] {task['cell']} ===", flush=True)
        existing = ROOT / task["output"]
        if existing.exists():
            done = json.loads(existing.read_text(encoding="utf-8"))
            recorded = [int(v) for v in done["protocol"]["candidate_limits"]]
            if recorded == task["candidate_limits"]:
                print(f"SKIP {task['cell']}: already complete for these pools", flush=True)
                continue
            raise RuntimeError(
                f"{task['output']} holds pools {recorded}, not "
                f"{task['candidate_limits']}. "
                "Delete that one file and rerun; completed cells are skipped."
            )
        code = subprocess.call(task["command"], cwd=ROOT)
        if code:
            print(f"FAILED {task['cell']} exit={code}", flush=True)
            return code
    if args.smoke:
        code = subprocess.call([sys.executable, "scripts/summarize_www_pool_frontier.py",
                                "--smoke"], cwd=ROOT)
        if code:
            print(f"STOP: smoke validation failed (exit={code}); full run must not start",
                  flush=True)
            return code
        print("\nPOOL FRONTIER COMPLETE AND VALIDATED (smoke)", flush=True)
        return 0
    code = subprocess.call([sys.executable, "scripts/summarize_www_pool_frontier.py"],
                           cwd=ROOT)
    if code:
        print(f"STOP: pool summary validation failed (exit={code})", flush=True)
        return code
    print("\nPOOL FRONTIER COMPLETE AND VALIDATED", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except RuntimeError as error:
        print(f"\nSTOP: {error}\n\nNo experiment result was written. Report this line and the "
              f"command you ran; see {SPEC} section 5.", flush=True)
        raise SystemExit(2)
