"""Publish the prespecified terminal decision; no additional experiment."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'nodes/09_vldb_query_certification/results/icde_final_random_audit_20261109/attempt2'


def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def report():
    s=load(BASE/'summary.json');v=load(BASE/'validation.json');p=load(BASE/'protocol.json')
    assert v['status']=='PASS' and v['summary_sha256']==sha(BASE/'summary.json')
    counts=s['sample_counts'];ci=s['simultaneous95_intervals_population_counts'];rows=s['rows']
    old_frontier=load(ROOT/'nodes/09_vldb_query_certification/results/icde_pair_event_tightness_20261108/attempt1/summary.json')['rows']
    previous={(x['graph'],x['rank']) for x in old_frontier if x['role']=='frontier'}
    overlap=sum((r['graph'],r['rank']) in previous for r in rows)
    matched=load(ROOT/'nodes/09_vldb_query_certification/results/icde_block_comparison_20261109/matched_anchor_pruning_attempt1/summary.json')
    prior_validation=load(ROOT/'nodes/09_vldb_query_certification/results/icde_block_comparison_20261109/validation_20261109.json')
    assert prior_validation['status']=='PASS'
    population={(x['graph'],x['rank']) for x in p['population']}
    mc={(x['graph'],x['rank']) for x in matched['rows'] if x['policy']=='generic_eager' and x['details']['status']=='stable'}
    known_robust={(x['graph'],x['rank']) for x in matched['rows'] if x['policy']=='block_event2' and x['details']['status']=='stable'}
    known_nonrobust=set()
    for x in old_frontier:
        key=x['graph'],x['rank']
        if key not in population:continue
        (known_robust if x['uniform_winners'] else known_nonrobust).add(key)
    for x in rows:
        if x['classification']=='unknown':continue
        (known_robust if x['classification']=='robust' else known_nonrobust).add((x['graph'],x['rank']))
    assert not known_robust & known_nonrobust
    logical={'robust_R':[len(known_robust),259-len(known_nonrobust)],
             'additional_A':[len(known_robust-mc),len(population-mc-known_nonrobust)]}
    complete=[r for r in rows if r.get('reference_kind')=='full_exact_tensor']
    reliable=[r for r in rows if r['classification']!='unknown']
    cdf={str(t):sum(r.get('reference_seconds',float('inf'))<=t for r in reliable) for t in (1,5,30)}
    kinds=Counter(r.get('reference_kind','unresolved') for r in rows)
    unknown_causes=Counter()
    for r in rows:
        if r['classification']!='unknown':continue
        if r.get('reference_kind') in ('watchdog_timeout','worker_exit','missing_output'):
            reason=r['reference_kind']
        elif any(a.get('timed_out',False) for a in r.get('attempts',[])):
            reason='prespecified_time_budget'
        elif r.get('factor_evidence',{}).get('status')=='unresolved':
            reason='prespecified_refinement_limit'
        else:reason='prespecified_resource_admission'
        unknown_causes[reason]+=1
    lines=['# 最后一轮随机审计与终止决策','', '2026-11-09（北京时间）。依据抽样前冻结规则；不是新查询确认。','',
        '## 结果与执行分支','',f"最终分支：**{s['decision']} / {s['reason']}**。可靠参考为{len(reliable)}/40；协议要求至少32/40。",'',
        '| 随机样本结果 | 数量 |','|---|---:|',f"| 已证明鲁棒 | {counts['robust']} |",f"| 已证明非鲁棒 | {counts['nonrobust']} |",f"| 未知（超时、未准入或未决） | {counts['unknown']} |",f"| 完整精确概率结果（含确定性单候选） | {counts['full_exact_probabilities']} |",f"| 1秒内可靠判定 | {counts['fast_1s']} |",'',
        '## 总体空间：保留未知而非只算完成者','',
        '40个样本来自完整259总体的简单无放回抽样；固定种子2026110901，未补抽，未排除既有参考。与原19例重叠%d例。这是历史查询总体审计，不是新的未参与设计的确认集。' % overlap,'',
        '以下使用有限总体超几何尾反演，未知标签作最坏补全；三个区间合计控制95%覆盖。它们只针对冻结259总体：','',
        '| 总体指标 | 同时置信区间（查询数） | 含义 |','|---|---|---|',
        f"| 真正鲁棒R | [{ci['robust_R'][0]}, {ci['robust_R'][1]}] | 完整参数族严格众数 |",
        f"| 当前MC交付集合之外的鲁棒A | [{ci['additional_A'][0]}, {ci['additional_A'][1]}] | 对冻结200ms、39次MC交付的潜在新增空间 |",
        f"| 测试参考组合1s判定F | [{ci['tested_portfolio_fast_F'][0]}, {ci['tested_portfolio_fast_F'][1]}] | 仅本次测试求解器，不代表所有精确算法 |",'',
        '[说明文本已清理]','',
        '另作不依赖抽样外推的逻辑盘点：合并此前已验证分块批准、19例精确参考与本次决定性参考，R在[%d,%d]，A在[%d,%d]。这只是已知证明的并集；与抽样区间分开列出，不更改冻结分支。' % (*logical['robust_R'],*logical['additional_A']),'',
        '## 求解时间能说明什么','',
        '计时从共同剪枝开始，包含准入、重建和先前失败尝试；图加载、进程启动另报。张量10s、总求解30s、子进程看门狗45s。合作式期限仍可能被单次原生调用越过，晚到结果不批准。','',
        '全40样本中，在1/5/30秒内取得可靠判定分别为%d/%d/%d个；完整张量精确结果%d个。只对完成者给时间不能代表整体时间分布。对资源拒绝/超时也不能据此声称所有精确方法至少需要更长时间。' % (cdf['1'],cdf['5'],cdf['30'],len(complete)),'',
        '参考种类：'+', '.join(f'{k}={n}' for k,n in sorted(kinds.items()))+'。','',
        '未知原因：'+', '.join(f'{k}={n}' for k,n in sorted(unknown_causes.items()))+'。这些类别只记录执行结果，不推断查询是否鲁棒。','',
        '## MC漏解的两种口径','',
        '当前A针对一次200ms运行的未交付，可能包含有限样本不足、实现费用和总体充分条件损失。原148例的10/101=9.90%是精确逐世界总体条件遗漏，不能与这里直接比较。','',
        '完整精确子集上的逐世界诊断：可用%d个，其中鲁棒%d个、遗漏%d个；这个解出子集受结构选择影响，不作为259总体漏解率。' % (s['pointwise_diagnostic_subset']['available'],s['pointwise_diagnostic_subset']['robust'],s['pointwise_diagnostic_subset']['omitted']),'',
        '## 验证、失败重跑及停止含义','',
        '首次运行的第2个样本在写出巨大的整数S时触发Python十进制转换限制，留下不完整JSON；旧脚本、协议、日志和结果保留于attempt1。attempt2只修复大整数及原子写出，40个样本完全相同，科学阈值与求解预算未变。回归测试覆盖超大整数完整写出、失败不发布半条记录及不覆盖既有证据。','',
        '验证器重建全部决定性参考；完整张量重算，因子证书检查计数/参数划分完整无重叠、重新计算全部决定性概率界或反例。有限总体区间另用小总体全枚举验证覆盖率，包括依赖标签的缺失。验证仍复用已证明的评分包络，不声称独立重写了通用推断引擎。','']
    if s['decision']=='STOP':
        lines += ['按协议停止当前方法路线：不实现两项修复，不启动新查询确认，不增加参考预算或另抽容易样本，不继续以新瓶颈延长研究。','',
            '[说明文本已清理]','',
            '[说明文本已清理]']
    else:
        lines += ['[说明文本已清理]']
    lines += ['', '## 文件','', '- protocol.json：抽样、门槛、预算与来源哈希。','- summary.json：40例全部结果及尚待验证的原始汇总（现已由validation.json核验）。','- validation.json：独立核算与决定性参考重算。','- figures/random_audit.png、.pdf：结果与总体区间图。','']
    dest=BASE/'RESULTS_ZH.md'
    with dest.open('x',encoding='utf-8') as stream:stream.write('\n'.join(lines))
    extra={'reference_kind_counts':dict(kinds),'unknown_execution_causes':dict(unknown_causes),'previous_frontier_overlap':overlap,'reliable_completion_counts_by_seconds':cdf,
           'known_proof_union_logical_bounds':logical,
           'counts':counts,'intervals':ci,'decision':s['decision'],'reason':s['reason'],'protocol_sha256':sha(BASE/'protocol.json'),
           'summary_sha256':sha(BASE/'summary.json'),'validation_sha256':sha(BASE/'validation.json')}
    with (BASE/'report_metrics.json').open('x',encoding='utf-8') as stream:json.dump(extra,stream,ensure_ascii=False,indent=2)
    print(json.dumps(extra,ensure_ascii=False,indent=2))


def plot():
    sys.path.insert(0,str(ROOT/'.runtime/icde_plot_site'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    d=load(BASE/'report_metrics.json');c=d['counts'];ci=d['intervals']
    fig,axes=plt.subplots(1,2,figsize=(10.6,4.5),constrained_layout=True)
    ax=axes[0];values=[c['robust'],c['nonrobust'],c['unknown']]
    bars=ax.bar(range(3),values,color=['#28745e','#a86541','#9299a6'],width=.6)
    ax.bar_label(bars,padding=3);ax.set_xticks(range(3),['Proved\nrobust','Proved\nnonrobust','Unknown'])
    ax.set(ylabel='Queries out of the fixed SRS of 40',ylim=(0,43),title='(a) Do not discard censored references')
    ax=axes[1]
    for y,(label,key,color) in enumerate([('Robust R','robust_R','#28745e'),('Additional A','additional_A','#34659c'),('Fast reference F','tested_portfolio_fast_F','#a86541')]):
        lo,hi=ci[key];ax.plot([lo,hi],[y,y],color=color,lw=5,solid_capstyle='round');ax.scatter([lo,hi],[y,y],color=color,s=35)
        ax.text(lo,y+.13,str(lo),ha='center',fontsize=9);ax.text(hi,y+.13,str(hi),ha='center',fontsize=9)
    ax.axvline(20,color='#34659c',ls=':',lw=1);ax.axvline(130,color='#a86541',ls=':',lw=1)
    ax.set_yticks(range(3),['Robust R','Additional A','Fast reference F']);ax.invert_yaxis()
    ax.set(xlim=(-7,268),ylim=(2.55,-.6),xlabel='Population count out of 259',title='(b) Simultaneous 95% outer intervals')
    ax.text(.02,.02,'Unknown truth uses worst-case completion.\nF describes only the tested reference portfolio.',transform=ax.transAxes,fontsize=8)
    for ax in axes:
        ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.12);ax.set_axisbelow(True)
    fig.suptitle('Prespecified final audit: '+d['decision'],fontsize=13)
    folder=BASE/'figures';folder.mkdir()
    for ext in ('png','pdf'):fig.savefig(folder/f'random_audit.{ext}',dpi=180)
    plt.close(fig)
    files={p.relative_to(BASE).as_posix():sha(p) for p in BASE.rglob('*') if p.is_file() and p.name!='manifest.json'}
    with (BASE/'manifest.json').open('x',encoding='utf-8') as stream:json.dump({'files':files,'reporter_sha256':sha(Path(__file__))},stream,indent=2)
    print('PNG/PDF and immutable manifest written.')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['report','plot'],required=True)
    args=parser.parse_args();{'report':report,'plot':plot}[args.phase]()
