"""Audit all admitted local-repair runs and produce the research decision."""
from __future__ import annotations

import hashlib
import ast
import json
from pathlib import Path
import statistics

import icde_local_repair_validation_20261110 as study


ROOT, OUT = study.ROOT, study.OUT
STRATA = {"full_sequence": tuple(range(8)), "small_representation": (0, 1),
    "capacity": (2, 3, 4, 5), "large_representation": (6,), "historical_deletion": (7,)}


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def main():
    study.identities()
    protocol = load(OUT / "protocol.json")
    reuse = load(OUT / "reuse_manifest.json")["cases"]
    current_ast = ast.parse((ROOT / "scripts/icde_local_repair_validation_20261110.py").read_text(encoding="utf-8"))
    current_functions = {n.name: ast.dump(n) for n in current_ast.body if isinstance(n, ast.FunctionDef)}
    attempt_suffix = "a" + OUT.name.removeprefix("attempt")
    micro = load(ROOT / next(name for name in protocol["sha256"] if "/development/self_check_" in name))
    assert sha(OUT / "source_frozen.py") == protocol["sha256"]["scripts/icde_local_repair_validation_20261110.py"]
    assert sha(OUT / "kernel_frozen.py") == protocol["sha256"]["scripts/icde_dynamic_hungarian_20261110.py"]
    traces, missing, failures, resources, resource_files, partial = [], [], [], [], [], []
    for graph in study.prior.GRAPHS:
        reference = load(study.prior.OUT / "traces" / f"{graph}_dense_cold_r0" / "result.json")
        for method in study.METHODS:
            for repeat in range(3):
                name = f"{graph}_{method}_r{repeat}"
                folder = OUT / "traces" / name
                path = folder / "result.json"
                task_id = f"icde-localrepair-{graph}-{method}-r{repeat}-20261110-{attempt_suffix}"
                if name in reuse:
                    origin = reuse[name]
                    task_id = origin["source_task_id"]
                    source_folder = ROOT / origin["source_folder"]
                    old_ast = ast.parse((source_folder.parents[1] / "source_frozen.py").read_text(encoding="utf-8"))
                    old_functions = {n.name: ast.dump(n) for n in old_ast.body if isinstance(n, ast.FunctionDef)}
                    for function in ("dense_solution", "objective", "validate", "run_trace"):
                        assert current_functions[function] == old_functions[function]
                    if method == "dynamic_hungarian":
                        assert sha(source_folder.parents[1] / "kernel_frozen.py") == sha(ROOT / "scripts/icde_dynamic_hungarian_20261110.py")
                    for filename, expected in origin["files"].items():
                        assert sha(folder / filename) == expected
                        assert sha(ROOT / origin["source_folder"] / filename) == expected
                run_path = ROOT / ".runtime/runs" / (task_id + ".json")
                if run_path.exists():
                    execution = load(run_path)
                    resources.append(execution)
                    resource_files.extend((run_path, Path(execution["log_path"])))
                    if execution["status"] != "completed" or execution["return_code"] != 0:
                        failures.append({"case": name, "status": execution["status"],
                            "reason": execution["reason"], "return_code": execution["return_code"]})
                    else:
                        assert execution["peak_job_memory_gb"] <= 7
                        assert execution["profile"] == "local16" and execution["profile_values"]["threads"] == 1
                else:
                    missing.append(str(run_path.relative_to(ROOT)))
                if not path.exists():
                    missing.append(str(path.relative_to(ROOT)))
                    checkpoints = sorted(folder.glob("event_*.json"))
                    for step, checkpoint in enumerate(checkpoints):
                        event = load(checkpoint)
                        check = event["validation"]
                        assert event["step"] == step and event["event"] == study.prior.EVENTS[step]
                        assert event["status"] == check["status"] == "PASS"
                        assert abs(check["objective"] - reference["records"][step]["result"]["objective"]) <= 1e-6
                        assert abs(check["objective"] - check["actual_vector_objective"]) <= 1e-6
                        if method != "dense_jv":
                            assert check["max_global_violation"] <= 1e-8 and abs(check["primal_dual_gap"]) <= 1e-6
                    partial.append({"case": name, "event_checkpoints": len(checkpoints)})
                    continue
                row = load(path)
                assert row["status"] == "PASS" and len(row["records"]) == 8
                assert row["graph"] == graph and row["method"] == method and row["repeat"] == repeat
                assert abs(row["maintenance_seconds"] - sum(e["seconds"] for e in row["records"])) < 1e-8
                assert abs(row["setup_plus_8_seconds"] - row["setup_seconds"] - row["maintenance_seconds"]) < 1e-8
                for step, event in enumerate(row["records"]):
                    check = event["validation"]
                    assert event["status"] == check["status"] == "PASS"
                    assert event["step"] == step and event["event"] == study.prior.EVENTS[step]
                    assert abs(check["objective"] - reference["records"][step]["result"]["objective"]) <= 1e-6
                    assert abs(check["objective"] - check["actual_vector_objective"]) <= 1e-6
                    assert 0 <= event["matched_sources"] <= min(event["active_sources"], event["active_targets"])
                    assert 0 <= event["score_update_seconds"] <= event["seconds"]
                    assert load(folder / f"event_{step:02d}.json") == event
                    if method != "dense_jv":
                        assert check["max_global_violation"] <= 1e-8
                        assert abs(check["primal_dual_gap"]) <= 1e-6
                traces.append(row)
    groups = {}
    for graph in study.prior.GRAPHS:
        for method in study.METHODS:
            rows = [t for t in traces if t["graph"] == graph and t["method"] == method]
            if not rows:
                continue
            runs = [r for r in resources if r["task_id"].startswith(f"icde-localrepair-{graph}-{method}-r")]
            groups[graph, method] = {"graph": graph, "method": method, "runs": len(rows),
                "median_maintenance_seconds": statistics.median(r["maintenance_seconds"] for r in rows),
                "median_setup_seconds": statistics.median(r["setup_seconds"] for r in rows),
                "median_setup_plus_8_seconds": statistics.median(r["setup_plus_8_seconds"] for r in rows),
                "minimum_setup_plus_8_seconds": min(r["setup_plus_8_seconds"] for r in rows),
                "maximum_setup_plus_8_seconds": max(r["setup_plus_8_seconds"] for r in rows),
                "repeat_setup_plus_8_seconds": [r["setup_plus_8_seconds"] for r in rows],
                "maximum_event_seconds": max(e["seconds"] for r in rows for e in r["records"]),
                "median_independent_validation_seconds": statistics.median(
                    sum(e["validation"]["seconds"] for e in r["records"]) for r in rows),
                "maximum_job_commit_GiB": max((r["peak_job_memory_gb"] for r in runs), default=None),
                "maximum_observed_event_end_RSS_GiB": max(e["rss_end_bytes"] for r in rows for e in r["records"]) / 2**30,
                "median_event_seconds": [statistics.median(r["records"][s]["seconds"] for r in rows) for s in range(8)]}
    comparisons = []
    for stratum, steps in STRATA.items():
        for graph in study.prior.GRAPHS:
            for repeat in range(3):
                rows = {t["method"]: t for t in traces if t["graph"] == graph and t["repeat"] == repeat}
                if "region_lp" not in rows or len(rows) < 2:
                    continue
                costs = {method: r["setup_seconds"] + sum(r["records"][s]["seconds"] for s in steps)
                    for method, r in rows.items()}
                best = min((m for m in rows if m != "region_lp"), key=costs.get)
                all_observed = len(rows) == len(study.METHODS)
                comparisons.append({"stratum": stratum, "graph": graph, "repeat": repeat,
                    "costs_seconds": costs, "strongest_baseline": best,
                    "all_baselines_observed": all_observed,
                    "region_beats_all_baselines": costs["region_lp"] < costs[best] if all_observed else None,
                    "gate_falsified_by_observed_baseline": costs["region_lp"] >= costs[best],
                    "best_baseline_over_region": costs[best] / costs["region_lp"]})
    signals = []
    for stratum in STRATA:
        rows = [r for r in comparisons if r["stratum"] == stratum]
        if len(rows) == 6 and all(r["region_beats_all_baselines"] for r in rows):
            signals.append(stratum)
    refuted = [stratum for stratum in STRATA
        if len([r for r in comparisons if r["stratum"] == stratum]) == 6
        and all(r["gate_falsified_by_observed_baseline"] for r in comparisons if r["stratum"] == stratum)]
    complete = not missing and not failures
    if complete:
        assert len(traces) == 24 and sum(len(r["records"]) for r in traces) == 192
    decision = "INCOMPLETE_WITH_DECLARED_OUTCOMES"
    if complete:
        decision = "PERFORMANCE_SIGNAL_NOVELTY_OPEN" if signals else "STOP_REGION_LP_NO_STRONG_BASELINE_ADVANTAGE"
    elif len(refuted) == len(STRATA):
        decision = "STOP_REGION_LP_OBSERVED_BASELINE_DOMINATION_WITH_COVERAGE_GAPS"
    summary = {"status": "COMPLETE" if complete else "PARTIAL", "decision": decision,
        "trace_sequences": len(traces), "update_runs": sum(len(r["records"]) for r in traces),
        "validated_partial_update_checkpoints": sum(r["event_checkpoints"] for r in partial),
        "missing": missing, "failures": failures, "partial_cases": partial,
        "regional_performance_signals": signals,
        "regional_fallback_events": sum(e["solver"]["fallback"] for r in traces if r["method"] == "region_lp" for e in r["records"]),
        "regional_completed_events": sum(len(r["records"]) for r in traces if r["method"] == "region_lp"),
        "strata_refuted_by_observed_baselines": refuted,
        "full_pair_checks": sum(e["validation"]["full_pair_checks"] for r in traces for e in r["records"]),
        "sequence_costs": list(groups.values()), "paired_stratum_comparisons": comparisons,
        "novelty": '[说明文本已清理]',
        "software_scope": "native SciPy JV, HiGHS basis reuse, Numba compiled 2007 dynamic Hungarian reimplementation",
        "software_gaps": ["original dynamic Hungarian author software not executed", "Morita et al. original algorithm not executed",
            "original ShortCut and TODS systems not executed"],
        "superseded_attempt": {"path": "attempt1", "reason": "manual interruption to optimize repeated dummy traversal in the dynamic baseline",
            "completed_sequences": len(list((OUT.parent / "attempt1/traces").glob("*/result.json")))},
        "micro_check": micro, "reporter_sha256": sha(Path(__file__))}
    summary["reused_unchanged_baselines"] = reuse
    summary["reused_baseline_code_paths_verified"] = True
    save(OUT / "summary.json", summary)
    lines = ["# 增量匹配局部修复验证结果", "", "2026年11月10日。", "",
        f"状态为 **{summary['status']}**，决策为 **{decision}**。完成{len(traces)}条连续序列、"
        f"{summary['update_runs']}次完整序列内更新。另{len(partial)}条未完成序列，"
        f"其{summary['validated_partial_update_checkpoints']}个已有前缀检查点核验通过。"
        f"缺失记录{len(missing)}项，运行失败{len(failures)}项。", "",
        "## 同合同完整费用", "",
        '[说明文本已清理]', "",
        "| 图 | 方法 | 重复数 | 8次维护中位秒 | 初始化中位秒 | 初始化加8次中位秒 | 总秒范围 |",
        "| --- | --- | --- | --- | --- | --- | --- |"]
    for row in groups.values():
        lines.append(f"| {row['graph']} | {row['method']} | {row['runs']} | {row['median_maintenance_seconds']:.3f} | "
            f"{row['median_setup_seconds']:.3f} | {row['median_setup_plus_8_seconds']:.3f} | "
            f"[{row['minimum_setup_plus_8_seconds']:.3f}, {row['maximum_setup_plus_8_seconds']:.3f}] |")
    lines += ["", "初始化包含方法状态恢复、新增结构及动态Hungarian的JIT准备。维护包含变化分数、匹配、"
        "区域识别、边界检查、扩展和回退。共同首快照费用沿用上一轮实测D–W 46.403秒、"
        "EN–FR 43.828秒，各路径同加。编码器、变化向量生成、Python启动和研究核验另属边界。", "",
        "## 分层与重复", "",
        "分层费用为方法初始化加该层对应步骤之和。层内测量来自完整连续轨迹的相应位置，"
        "未独立运行纯容量或纯表示变化服务。三次重复是同一历史轨迹的计时重复。", "",
        "| 分层 | 图 | 全部基线齐全重复数 | 已执行基线支配区域方法重复数 | 已执行最强基线/区域费用比范围 |",
        "| --- | --- | --- | --- | --- |"]
    for stratum in STRATA:
        for graph in study.prior.GRAPHS:
            rows = [r for r in comparisons if r["stratum"] == stratum and r["graph"] == graph]
            if rows:
                ratios = [r["best_baseline_over_region"] for r in rows]
                lines.append(f"| {stratum} | {graph} | {sum(r['all_baselines_observed'] for r in rows)}/{len(rows)} | "
                    f"{sum(r['gate_falsified_by_observed_baseline'] for r in rows)}/{len(rows)} | "
                    f"[{min(ratios):.4f}, {max(ratios):.4f}] |")
    lines += ["", "费用比大于1表示区域方法更快。预声明的跨两图三重复性能信号为 "
        + ("、".join(signals) if signals else "无") + "。完整配对费用保存在summary.json。", "",
        "缺失基线不计作区域方法获胜。已经实测的基线若反复支配区域方法，足以否定"
        "要求区域方法同时优于全部基线的必要条件。两图三重复均被已执行基线支配的分层为 "
        + ("、".join(refuted) if refuted else "无") + "。未运行方法的费用保留未知。", "",
        "## 更新位置与修复范围", "",
        "| 图 | 步骤 | 更新 | HiGHS秒 | 原生JV秒 | 动态Hungarian秒 | 区域LP秒 | 区域最大源数中位 | 区域输出配对变化源数中位 | 区域回退次数 | 动态探索源数中位 |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    for graph in study.prior.GRAPHS:
        local = [r for r in traces if r["graph"] == graph and r["method"] == "region_lp"]
        dynamic = [r for r in traces if r["graph"] == graph and r["method"] == "dynamic_hungarian"]
        if not local:
            continue
        for step, event_name in enumerate(study.prior.EVENTS):
            values = [groups[graph, method]["median_event_seconds"][step] if (graph, method) in groups else None
                for method in study.METHODS]
            sizes = [max((p["sources"] for p in r["records"][step]["solver"]["region_rounds"]), default=0) for r in local]
            fallbacks = sum(r["records"][step]["solver"]["fallback"] for r in local)
            changed = statistics.median(r["records"][step]["matching_changed_sources"] for r in local)
            explored = (f"{statistics.median(r['records'][step]['solver']['distinct_explored_real_rows'] for r in dynamic):.0f}"
                if dynamic else "未完成")
            lines.append(f"| {graph} | {step} | {event_name} | "
                + " | ".join("—" if v is None else f"{v:.3f}" for v in values)
                + f" | {statistics.median(sizes):.0f} | {changed:.0f} | {fallbacks} | {explored} |")
    lines += ["", "区域最大源数包括扩大和完整回退后的规模。动态探索数是该次标准修复实际访问的真实源并集。"
        "区域缩减比例与最少必要修复范围分别解释，并列最优可能产生不同配对。逐轮区域、边界和LP费用保存在事件JSON。", "",
        f"完整区域运行的{summary['regional_completed_events']}个更新中，{summary['regional_fallback_events']}个触发全量回退。"
        "这些结果测量当前区域/对偶拼接方式的闭合能力，不把扩大后的证书区域解释为不可避免的最小影响范围。", "",
        "## 核验与资源", "",
        f"完整向量定价累计{summary['full_pair_checks']:,}对次。提供对偶的三个路径均核对全图可行性和"
        "原始—对偶gap，原生JV另与已冻结冷启动参考及实际向量配对目标核对。定价容差1e−8，目标/gap容差1e−6。", "",
        "| 图 | 方法 | 峰值作业提交GiB | 最大事件末RSS GiB | 独立核验中位秒 |",
        "| --- | --- | --- | --- | --- |"]
    for row in groups.values():
        commit = row["maximum_job_commit_GiB"]
        lines.append(f"| {row['graph']} | {row['method']} | " + ("—" if commit is None else f"{commit:.3f}")
            + f" | {row['maximum_observed_event_end_RSS_GiB']:.3f} | {row['median_independent_validation_seconds']:.3f} |")
    lines += ["", "作业提交内存与文件映射驻留内存分别解释，RSS为事件末采样的最大值。本轮允许完整分数缓存，"
        "不主张无缓存性能。三次计时重复没有增加独立图、种子或业务更新来源。", "",
        '[说明文本已清理]', "",
        "动态Hungarian参考实现依照2007年作者算法的批量行列修复，由Numba编译。它复用旧匹配、对偶和"
        "增广树所探索的局部范围。该实现属于论文算法的本项目重实现，原作者软件和Morita等的原版算法未执行。", "",
        '[说明文本已清理]', "",
        "冻结后已补读Morita等2023年预印本全文第3节。该工作同时覆盖原始与对偶更新，"
        "并在3.2节处理非平衡、允许不完全匹配的变体和虚拟点收缩。"
        "因此允许不匹配、对偶复用及虚拟点压缩都已有直接先例。当前动态基线仍是2007年规则的本项目重实现，"
        "没有将补读全文当作已执行Morita等完整算法的证据。", "",
        "[动态Hungarian作者全文](https://publications.ri.cmu.edu/storage/publications/pub_files/pub4/mills_tettey_g_ayorkor_2007_3/mills_tettey_g_ayorkor_2007_3.pdf) "
        "[局部权重原始—对偶更新](https://arxiv.org/abs/2208.11325) "
        "[TODS空间容量匹配作者全文](https://hub.hku.hk/bitstream/10722/129985/1/content.pdf)", "",
        "## 限制与结果边界", "",
        "- 两份历史图、同一种子及受控连续更新均为开发资产。真实日志、独立数据与编码器总费用仍缺。",
        "- 动态基线是编译后的算法重实现。2023年方法、ShortCut及TODS原版系统对照仍有缺口。",
        f"- 修订后微型自检通过{micro['sequential_cases']}个连续情况、{micro['assertions']}项断言，支持所测输入的实现核验。",
        "- 本轮没有20%提前停止，也没有根据结果调整区域扩展预算或选择新配置。", ""]
    lines += ["## 基线实现修订", "",
        "attempt1的D–W源退出运行中，标准动态基线逐个访问等价虚拟点，单步耗时677.606秒。"
        "目标退出步骤运行时人工中止该序列，完整日志和已经完成的两条基线保留。"
        "修订001将同松弛值虚拟列同时加入树，并省略被已有虚拟行支配的松弛扫描。"
        "区域LP随后还出现临时内存问题，内存修订后的有效矩阵位于attempt3。"
        "修订细节及原始失败资源记录随asset_manifest.json保留。", ""]
    lines += [f"attempt3复用{len(reuse)}条未经过改动分支、已完整通过的对应基线测量。"
        "每个对应情况取最新完整记录，未选择最快运行，来源及哈希保存在reuse_manifest.json。"
        "这些测量按原运行计数。区域LP在清理原生临时模型及复用完整矩阵视图后重新运行。"
        "复用前核对基线入口、目标与核验函数语法树一致，动态路径另核对编译内核源码哈希一致。"
        "匹配合同、区域选择及8轮回退预算保持原协议。", "",
        "attempt2首次区域失败的峰值提交内存约7.022GiB。一次队列重试覆盖了该次原始stderr及资源JSON，"
        "主要资源字段从已观察的控制器输出恢复，前7步检查点和重试日志保留。"
        "原始具体异常栈缺失，记录没有将其补写为已证实的某一种异常。", ""]
    lines += ['[说明文本已清理]', ""]
    if missing or failures:
        lines += ["## 未完成与失败", ""]
        lines += ["- " + name for name in missing]
        lines += ["- " + json.dumps(row, ensure_ascii=False) for row in failures]
        lines += [""]
    (OUT / "RESULTS_ZH.md").write_text("\n".join(lines), encoding="utf-8")
    extra = [ROOT / "scripts/icde_local_repair_report_20261110.py", study.RULES]
    extra.append(OUT.parent / "REVISION_001.md")
    extra.append(OUT.parent / "REVISION_002.md")
    extra.append(OUT.parent / "SCHEDULING_UPDATE_001.md")
    extra += [p for p in (ROOT / ".runtime/icde_local_repair_sources_20261110").glob("2208.11325.*") if p.is_file()]
    extra += [p for p in (OUT.parent / "attempt1").rglob("*") if p.is_file()]
    extra += [p for p in (OUT.parent / "attempt2").rglob("*") if p.is_file()]
    extra += list((OUT.parent / "development").glob("*.json"))
    historical_runs = sorted((ROOT / ".runtime/runs").glob("icde-localrepair-*-20261110-a1.json"))
    historical_runs += sorted((ROOT / ".runtime/runs").glob("icde-localrepair-*-20261110-a2.json"))
    for path in historical_runs:
        extra.extend((path, Path(load(path)["log_path"])))
    for task in ("icde-localrepair-selfcheck-dev1-20261110", "icde-localrepair-selfcheck-dev2-20261110", "icde-localrepair-selfcheck-dev3-20261110",
        "icde-localrepair-freeze-20261110-a1", f"icde-localrepair-freeze-20261110-{attempt_suffix}"):
        path = ROOT / ".runtime/runs" / (task + ".json")
        if path.exists():
            extra.extend((path, Path(load(path)["log_path"])))
    files = sorted({p for p in OUT.rglob("*") if p.is_file()} | set(resource_files) | set(extra))
    save(OUT / "asset_manifest.json", {"decision": decision,
        "files": {p.relative_to(ROOT).as_posix(): sha(p) for p in files},
        "reporter_sha256": sha(Path(__file__)), "protocol_sha256": sha(OUT / "protocol.json")})
    print(json.dumps({k: v for k, v in summary.items() if k not in ("sequence_costs", "paired_stratum_comparisons")},
        ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
