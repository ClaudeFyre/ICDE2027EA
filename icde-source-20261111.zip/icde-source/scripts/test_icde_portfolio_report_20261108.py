import unittest
from icde_portfolio_report_20261108 import evaluate, requested
from icde_portfolio_study_20261108 import POLICIES


class QueryOracleTest(unittest.TestCase):
    def test_no_per_repeat_switching(self):
        refs = [{'graph':'x','rank':1,'feature_seconds':[0]*3,'uniform_winners':[0]}]
        rows = [{'graph':'x','rank':1,'policy':m,'repeat':r,
                 'status':'stable' if i==r else 'unresolved','compute_seconds':.001}
                for i,m in enumerate(POLICIES) for r in range(3)]
        a = evaluate(rows,refs,.01,'stable_certificate')
        self.assertEqual(a['oracle_successes'],1)  # Per-realization union would be 3.
        self.assertEqual(a['oracle_selection_counts'],{'dense_exact':1})

    def test_failure_costs_budget_and_objectives_differ(self):
        refs = [{'graph':'x','rank':1,'feature_seconds':[.002]*3,'uniform_winners':[]}]
        rows = [{'graph':'x','rank':1,'policy':m,'repeat':r,
                 'status':'nonuniform' if m=='dense_exact' else 'unresolved','compute_seconds':.001}
                for m in POLICIES for r in range(3)]
        a = evaluate(rows,refs,.01,'stable_certificate')
        b = evaluate(rows,refs,.01,'complete_classification')
        c = evaluate(rows,refs,.002,'complete_classification',True)
        self.assertEqual(a['oracle_successes'],0)
        self.assertAlmostEqual(a['oracle_capped_loss_ms'],10)
        self.assertEqual(b['oracle_successes'],3)
        self.assertAlmostEqual(b['oracle_capped_loss_ms'],1)
        self.assertEqual(c['oracle_successes'],0)
        self.assertFalse(requested({'status':'timeout'},'complete_classification'))


if __name__ == '__main__':
    unittest.main()
