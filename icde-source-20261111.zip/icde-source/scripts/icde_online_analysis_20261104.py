"""Audit completed ICDE online batches and write descriptive research artifacts.

No scorer is imported or executed and no random worlds are generated. Use one
--batch argument per completed batch, and a NEW --output-dir. Audit failures
produce an explicit failed audit artifact and a nonzero exit status.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter, defaultdict
import csv
from fractions import Fraction
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import sys
import traceback


ROOT = Path(__file__).resolve().parents[1]
PURPOSE = "icde_online_worlds_v1"
CANONICAL = ("entities.tsv", "relations.tsv", "triples.tsv", "alignments.tsv",
             "attributes.tsv", "confidence_metadata.json")
METHODS = ("scope_full_risk", "difference_eager", "difference_lazy")
EMPTY_HASH = hashlib.sha256(b"").hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def write_csv(path, rows):
    if not rows:
        return
    fields = list(dict.fromkeys(field for row in rows for field in row))
    with Path(path).open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def relative(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def resolve_repo(path):
    path = Path(path)
    path = path.resolve() if path.is_absolute() else (ROOT / path).resolve()
    path.relative_to(ROOT)
    return path


def percentile(values, probability):
    values = sorted(values)
    if not values:
        return None
    position = (len(values) - 1) * probability
    left, right = math.floor(position), math.ceil(position)
    return values[left] + (values[right] - values[left]) * (position - left)


def descriptive(values):
    values = list(values)
    if not values:
        return {"n": 0, "mean": None, "median": None, "minimum": None,
                "maximum": None, "p95_linear": None, "sum": 0}
    return {"n": len(values), "mean": statistics.mean(values),
            "median": statistics.median(values), "minimum": min(values),
            "maximum": max(values), "p95_linear": percentile(values, .95),
            "sum": sum(values)}


class Audit:
    def __init__(self):
        self.check_counts = Counter()
        self.error_counts = Counter()
        self.examples = []
        self.warnings = []

    def check(self, condition, category, context):
        self.check_counts[category] += 1
        if not condition:
            self.error_counts[category] += 1
            if len(self.examples) < 100:
                self.examples.append({"category": category, "context": context})

    def close(self, left, right, category, context):
        self.check(math.isclose(left, right, rel_tol=1e-10, abs_tol=1e-7), category, context)

    def nonnegative(self, mapping, category, context):
        for key, value in mapping.items():
            self.check(isinstance(value, (int, float)) and math.isfinite(value) and value >= 0,
                       category, f"{context}:{key}={value!r}")


def scientific_identity(query):
    return {key: query[key] for key in (
        "query_id", "candidate_ids", "candidate_tie_order", "scope_edge_indices",
        "scope_edge_count", "candidate_count", "scope_certificate", "box_audit")}


def row_science(row):
    return {key: row[key] for key in (
        "stable", "status", "certified_candidate", "nominal_certified",
        "nominal_candidate_index", "nominal_certificate_samples", "samples_used",
        "winner_counts", "event_samples_used", "event_count", "event_free_rows",
        "work_used", "work_budget", "event_ambiguity_upper", "final_lower_gap")}


class Analyzer:
    def __init__(self):
        self.audit = Audit()
        self.hash_cache = {}
        self.dataset_cache = {}
        self.query_identities = {}
        self.graph_inputs = {}
        self.prefixes = {}
        self.row_repeats = {}
        self.shared_execution_contract = None
        self.compact = []
        self.processes = []
        self.setup_rows = []
        self.batch_metadata = []
        self.provenance = []
        source = (ROOT / "scripts/icde_online_execution.py").read_text("utf-8-sig")
        calls = [node for node in ast.walk(ast.parse(source)) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Name) and node.func.id == "stream_seed"
                 and len(node.args) >= 5 and isinstance(node.args[4], ast.Constant)]
        self.audit.check(any(node.args[4].value == PURPOSE for node in calls),
                         "actual_seed_purpose", "execution source must use frozen nominal purpose")
        seed_tree = ast.parse((ROOT / "scripts/vldb_capture_attribute_v0.py").read_text("utf-8-sig"))
        self.salt = next(node.value.value for node in seed_tree.body
                         if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant)
                         and any(isinstance(target, ast.Name) and target.id == "SALT"
                                 for target in node.targets))

    def sha(self, path):
        path = Path(path).resolve()
        if path not in self.hash_cache:
            digest = hashlib.sha256()
            with path.open("rb") as handle:
                for block in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(block)
            self.hash_cache[path] = digest.hexdigest()
        return self.hash_cache[path]

    def dataset(self, path):
        path = resolve_repo(path)
        if path not in self.dataset_cache:
            digest = hashlib.sha256(b"pkgea-dataset-revision-v1\0")
            hashes = {}
            for name in CANONICAL:
                item = path / name
                if item.is_file():
                    payload = item.read_bytes()
                    hashes[name] = hashlib.sha256(payload).hexdigest()
                    digest.update(name.encode("utf-8") + b"\0" + payload + b"\0")
            with (path / "alignments.tsv").open(encoding="utf-8-sig", newline="") as handle:
                pool = [row["source_entity_id"] for row in csv.DictReader(handle, delimiter="\t")
                        if row["split"] == "test"]
            self.dataset_cache[path] = (digest.hexdigest(), hashes, pool)
        return self.dataset_cache[path]

    def prefix(self, identity, n, uniform_hash, winner_hash, context):
        key = (*identity, n)
        value = (uniform_hash, winner_hash)
        self.audit.check(all(isinstance(item, str) and len(item) == 64 for item in value),
                         "prefix_hash_shape", context)
        if key in self.prefixes:
            self.audit.check(self.prefixes[key] == value, "paired_prefix_agreement", context)
        else:
            self.prefixes[key] = value

    def validate_row(self, row, query, config, context, batch_name):
        a = self.audit
        n, m, k = row["samples_used"], row["scope_edge_count"], row["candidate_count"]
        method = row["method"]
        a.check(method in METHODS and row["policy"] == method, "method_identity", context)
        a.check(m == query["scope_edge_count"] and k == query["candidate_count"], "row_query_shape", context)
        a.check(row["dataset_revision"] == query["scope_certificate"]["dataset_revision"],
                "row_revision", context)
        payload = (f"{self.salt}|{row['graph']}|{row['dataset_revision']}|{row['query_id']}|"
                   f"{row['seed']}|{PURPOSE}")
        seed = int.from_bytes(hashlib.sha256(payload.encode("utf-8")).digest()[:16], "big")
        a.check(row["rng_seed_hex"] == hex(seed), "actual_seed_derivation", context)
        a.check(row["seed"] in config["seeds"], "configured_seed", context)
        a.check(type(n) is int and 0 <= n <= config["sample_count"], "world_cap", context)
        a.check(row["worlds_generated"] == row["nominal_score_rows"] == n,
                "nominal_complete_rows", context)
        counts = row["winner_counts"]
        a.check(len(counts) == k and all(type(value) is int and value >= 0 for value in counts)
                and sum(counts) == n, "winner_counts", context)
        a.check(row["random_uniform_draws"] == n * m and row["event_extra_random_draws"] == 0,
                "random_draw_accounting", context)
        en = row["event_samples_used"]
        a.check(row["event_rows_computed"] == en and 0 <= row["event_count"] <=
                row["event_free_rows"] <= en <= n, "event_complete_prefix", context)
        a.check(en == 0 or en in config["event_checkpoints"], "protected_event_prefix", context)
        a.check(row["retained_uniform_values"] == (0 if method == METHODS[0] else n * m)
                and row["retained_score_values"] == (0 if method == METHODS[0] else n * k),
                "retained_state", context)
        a.close(row["nominal_delta"], config["delta_total"] if method == METHODS[0]
                else config["delta_nominal"], "nominal_risk", context)
        a.close(row["event_beta_total"], 0 if method == METHODS[0] else config["beta_total"],
                "event_risk", context)
        if method == METHODS[0]:
            a.check(en == row["event_calls"] == row["event_count"] == 0,
                    "scope_has_no_event_evidence", context)
        for name in ("event_ambiguity_upper", "scope_epsilon_upper"):
            a.check(math.isfinite(row[name]) and 0 <= row[name] <= 1, "probability_bounds", context)
        a.nonnegative(row["seconds"], "row_timing_nonnegative", context)
        a.check(sum(value for key, value in row["seconds"].items() if key != "query_serving_total")
                <= row["seconds"]["query_serving_total"] + 1e-6, "serving_stage_partition", context)
        model, fees = query["cost_model"], config["work_model"]
        unit = max(1, m + model["original_incidence_entries"] + fees["nominal_candidate_units"] * k)
        worst = 2 * m + 2 * model["interval_incidence_entries"] + fees["interval_candidate_units"] * k
        budget = (int(config["sample_count"] * config["budget_fraction"]) + 1) * unit
        a.close(row["nominal_unit_work"], unit, "nominal_fee", context)
        a.close(row["work_budget"], budget, "work_budget_identity", context)
        a.check(0 <= row["work_used"] <= budget and row["work_overshoot"] == 0,
                "strict_final_work_budget", context)
        expected_work = unit * (n + 1) + config["interval_work_weight"] * (
            2 * m * en + (2 * model["interval_incidence_entries"]
                         + fees["interval_candidate_units"] * k) * row["event_free_rows"])
        a.close(row["work_used"], expected_work, "recomputed_total_work", context)
        identity = (row["graph"], row["dataset_revision"], row["query_id"], row["seed"])
        previous_n = previous_event = 0
        previous_work = float(unit)
        previous_elapsed = 0.0
        event_actual_sum = 0.0
        rejected = 0
        for index, point in enumerate(row["trace"]):
            label = f"{context}:trace{index}"
            tn, te = point["nominal_samples"], point["event_samples"]
            base_work = previous_work + (tn - previous_n) * unit
            a.check(previous_n < tn <= n and previous_event <= te <= tn,
                    "monotone_complete_prefixes", label)
            a.check(previous_elapsed <= point["elapsed_seconds"] <= row["seconds"]["query_serving_total"] + 1e-7,
                    "trace_elapsed", label)
            a.check(0 <= point["work_completed"] <= budget, "strict_trace_work_budget", label)
            selected = point["event_upgrade_to"]
            admission = point["event_admission"]
            if selected is not None:
                a.check(selected in config["event_checkpoints"] and previous_event < selected <= tn,
                        "event_upgrade_identity", label)
                a.close(point["event_upper_fee"], (selected - previous_event) * worst
                        * config["interval_work_weight"], "static_admission_fee", label)
            if admission == "approved":
                a.check(selected == te and base_work + point["event_upper_fee"] <= budget + 1e-7
                        and 0 <= point["event_actual_fee"] <= point["event_upper_fee"],
                        "approved_before_paid_evidence", label)
            elif admission == "rejected_budget":
                rejected += 1
                a.check(te == previous_event and point["event_actual_fee"] == 0
                        and base_work + point["event_upper_fee"] > budget,
                        "rejected_evidence_unchanged", label)
            else:
                a.check(admission == "not_requested" and te == previous_event
                        and point["event_actual_fee"] == 0 and selected is None,
                        "unrequested_evidence_unchanged", label)
            a.close(point["work_completed"], base_work + point["event_actual_fee"],
                    "trace_work_reconstruction", label)
            self.prefix(identity, tn, point["uniform_prefix_sha256"], point["winner_prefix_sha256"], label)
            event_actual_sum += point["event_actual_fee"]
            previous_n, previous_event = tn, te
            previous_work, previous_elapsed = point["work_completed"], point["elapsed_seconds"]
        a.close(row["work_used"], unit * (n + 1) + event_actual_sum, "trace_total_work", context)
        a.check(row["event_admission_rejections"] == rejected, "rejection_count", context)
        if config["deadline_seconds"] is None:
            a.check(previous_n == n and previous_event == en, "final_trace_prefix", context)
            a.check(row["nominal_score_calls"] == len(row["trace"]), "score_call_count", context)
        self.prefix(identity, n, row["uniform_prefix_sha256"], row["winner_prefix_sha256"], context)
        if n == 0:
            a.check(row["uniform_prefix_sha256"] == row["winner_prefix_sha256"] == EMPTY_HASH,
                    "empty_prefix_hash", context)
        elif k > 1:
            top_counts = sorted(counts, reverse=True)
            delta = config["delta_total"] if method == METHODS[0] else config["delta_nominal"]
            alpha = delta / (k * (k - 1) // 2)
            rho = config["nominal"]["rho"]
            radius = math.sqrt((n + rho) * math.log((n + rho) / (rho * alpha * alpha))) / n
            expected_lower = max(-1.0, (top_counts[0] - top_counts[1]) / n - radius)
            a.close(row["final_lower_gap"], expected_lower, "final_nominal_gap_reconstruction", context)
        if row["nominal_certified"]:
            cn, ci = row["nominal_certificate_samples"], row["nominal_candidate_index"]
            a.check(cn is not None and 0 <= cn <= n and ci is not None and 0 <= ci < k,
                    "nominal_certificate_identity", context)
            if k > 1:
                witnesses = [point for point in row["trace"] if point["nominal_samples"] == cn]
                a.check(len(witnesses) == 1 and witnesses[0]["lower_gap"] > 0
                        and witnesses[0]["leader_index"] == ci, "nominal_certificate_witness", context)
            a.check(0 <= row["nominal_certificate_seconds"] <= row["seconds"]["query_serving_total"] + 1e-7,
                    "nominal_certificate_time", context)
        if row["stable"]:
            ci = row["certified_candidate_index"]
            a.check(row["nominal_certified"] and ci is not None and 0 <= ci < k
                    and row["certified_candidate"] == query["candidate_ids"][ci],
                    "robust_certificate_identity", context)
            if k > 1:
                a.check(row["final_lower_gap"] > 2 * min(row["scope_epsilon_upper"],
                                                        row["event_ambiguity_upper"]),
                        "robust_strict_gap", context)
            a.check(not any(point["certificate_discarded_after_deadline"] for point in row["trace"]),
                    "no_late_returned_certificate", context)
        science_key = (*identity, method)
        science = row_science(row)
        if science_key in self.row_repeats:
            a.check(self.row_repeats[science_key] == science, "repeat_scientific_result_agreement", context)
        else:
            self.row_repeats[science_key] = science

    def batch(self, batch_path):
        batch = resolve_repo(batch_path)
        name = batch.name
        a = self.audit
        freeze_path, summary_path = batch / "protocol_freeze.json", batch / "batch_summary.json"
        freeze, summary = read_json(freeze_path), read_json(summary_path)
        a.check(summary["status"] == "COMPLETE", "completed_batch", name)
        config = freeze["config"]
        a.check(config == summary["config"] and freeze["stage"] == summary["stage"], "batch_frozen_config", name)
        a.nonnegative({"batch_elapsed_seconds": summary["batch_elapsed_seconds"]}, "batch_timing_nonnegative", name)
        common_contract = {key: config[key] for key in ("sample_count", "tau", "delta_total", "delta_nominal",
                            "beta_total", "event_checkpoints", "nominal", "work_model", "budget_fraction",
                            "interval_work_weight", "deadline_seconds", "attribute_weight", "selection_salt", "seeds")}
        if self.shared_execution_contract is None:
            self.shared_execution_contract = common_contract
        else:
            a.check(self.shared_execution_contract == common_contract, "cross_batch_execution_contract", name)
        for item, expected in freeze["code_and_config_sha256"].items():
            path = resolve_repo(item)
            a.check(path.is_file() and self.sha(path) == expected, "frozen_code_config_hash", f"{name}:{item}")
        if config.get("seed_purpose") != PURPOSE:
            a.warnings.append({"batch": name, "kind": "config_seed_label_differs_from_execution",
                               "config_label": config.get("seed_purpose"), "actual_purpose": PURPOSE})
        self.batch_metadata.append({"batch": name, "query_count_per_graph": config["query_count"],
            "seeds": config["seeds"], "stage": summary["stage"], "config_seed_purpose": config.get("seed_purpose"),
            "actual_seed_purpose": PURPOSE, "worker_count": len(summary["measurements"]),
            "batch_elapsed_seconds": summary["batch_elapsed_seconds"]})
        self.provenance.append({"batch": relative(batch), "protocol_freeze_sha256": self.sha(freeze_path),
                                "batch_summary_sha256": self.sha(summary_path)})
        seen_measurements = set()
        for measurement in summary["measurements"]:
            worker_path = resolve_repo(measurement["path"])
            worker_path.relative_to(batch)
            a.check(self.sha(worker_path) == measurement["output_sha256"], "child_output_hash", str(worker_path))
            worker = read_json(worker_path)
            worker_id = (measurement["mode"], measurement["repeat"], measurement["method"])
            a.check(worker_id not in seen_measurements, "unique_worker_measurement", f"{name}:{worker_id}")
            seen_measurements.add(worker_id)
            context = f"{name}:{worker_path.name}"
            a.check(worker["status"] == "COMPLETE" and worker["schema_version"] == "icde-incremental-modal-execution-v1",
                    "worker_schema_status", context)
            a.check(worker["config"] == config and worker["repeat"] == measurement["repeat"]
                    and worker["mode"] == measurement["mode"], "worker_config_identity", context)
            plan = worker["risk_plan"]
            a.check(plan["event_checkpoints"] == config["event_checkpoints"]
                    and plan["protected_box_count"] == 1 and plan["complete_nominal_prefix_required"] is True
                    and plan["uncomputed_h_defaults_to_zero"] is False
                    and plan["joint_guarantee_across_competing_policies_or_queries"] is False,
                    "event_risk_plan_contract", context)
            event_spent = Fraction.from_float(plan["alpha_per_checkpoint"]) * len(config["event_checkpoints"])
            a.check(event_spent <= Fraction.from_float(config["beta_total"])
                    and event_spent + Fraction.from_float(config["delta_nominal"])
                    <= Fraction.from_float(config["delta_total"]), "exact_event_risk_allocation", context)
            a.nonnegative(worker["seconds"], "worker_timing_nonnegative", context)
            a.nonnegative({key: measurement[key] for key in ("external_process_wall_seconds", "peak_process_rss_bytes",
                                                            "worker_before_serialization_seconds")},
                          "process_measurement_nonnegative", context)
            a.close(worker["seconds"]["worker_before_serialization"],
                    measurement["worker_before_serialization_seconds"], "worker_time_record", context)
            a.check(measurement["external_process_wall_seconds"] >= worker["seconds"]["worker_before_serialization"],
                    "external_encloses_worker_time", context)
            a.check(worker["timing_contract"]["no_full_stream_precapture"] is True,
                    "incremental_execution_flag", context)
            queries = {}
            for report in worker["graph_setup"]:
                graph, revision = report["graph"], report["dataset_revision"]
                actual_revision, hashes, pool = self.dataset(report["dataset_path"])
                a.check(revision == actual_revision and report["input_sha256"] == hashes,
                        "input_hashes_and_revision", f"{context}:{graph}")
                profile = next(item for item in config["profiles"] if item["graph"] == graph)
                a.check(profile["expected_revision"] == revision, "profile_revision", f"{context}:{graph}")
                selected = sorted(pool, key=lambda source: (
                    hashlib.sha256(f"{config['selection_salt']}|{source}".encode()).digest(), source))[:config["query_count"]]
                a.check(len(pool) == len(set(pool)) == report["query_selection"]["pool_size"] == config.get("expected_query_pool", 500),
                        "frozen_source_universe", f"{context}:{graph}")
                a.check(selected == report["query_selection"]["query_ids"] and len(set(selected)) == len(selected),
                        "label_independent_selection", f"{context}:{graph}")
                a.check(len(report["query_setup"]) == config["query_count"], "prepared_query_count", context)
                graph_identity = (report["dataset_path"], revision, tuple(sorted(hashes.items())))
                if graph in self.graph_inputs:
                    a.check(self.graph_inputs[graph] == graph_identity, "cross_batch_graph_identity", context)
                else:
                    self.graph_inputs[graph] = graph_identity
                a.nonnegative(report["seconds"], "graph_setup_timing_nonnegative", context)
                for query in report["query_setup"]:
                    qid = query["query_id"]
                    queries[graph, qid] = query
                    a.check(qid in selected and query["candidate_count"] == len(query["candidate_ids"])
                            and query["scope_edge_count"] == len(query["scope_edge_indices"]),
                            "query_setup_shape", f"{context}:{qid}")
                    a.check(query["candidate_audit"]["status"] == query["coupled_audit"]["status"] == "PASS"
                            and query["scope_certificate"]["exact"] is True, "scope_candidate_diagnostics", f"{context}:{qid}")
                    a.nonnegative(query["setup_seconds"], "query_setup_timing_nonnegative", context)
                    identity = scientific_identity(query)
                    identity_key = (graph, revision, qid)
                    if identity_key in self.query_identities:
                        a.check(self.query_identities[identity_key] == identity,
                                "cross_worker_query_contract", f"{context}:{qid}")
                    else:
                        self.query_identities[identity_key] = identity
                self.setup_rows.append({"batch": name, "mode": worker["mode"], "repeat": worker["repeat"],
                    "process_method": measurement["method"], "graph": graph, "queries": len(selected),
                    "graph_total_seconds": report["seconds"]["graph_total_including_audits"],
                    "reconstruction_seconds": report["reconstruction"]["seconds"],
                    **{f"query_setup_{key}_sum": sum(query["setup_seconds"][key] for query in report["query_setup"])
                       for key in report["query_setup"][0]["setup_seconds"]}})
            a.check(worker["unique_queries"] == len(queries), "worker_unique_queries", context)
            rows = worker["query_policy_rows"]
            selected_methods = METHODS if measurement["method"] == "all" else (measurement["method"],)
            expected_keys = {(graph, qid, seed, method) for graph, qid in queries
                             for seed in config["seeds"] for method in selected_methods}
            actual_keys = {(row["graph"], row["query_id"], row["seed"], row["method"]) for row in rows}
            a.check(len(rows) == worker["query_seed_method_cases"] == len(actual_keys)
                    and actual_keys == expected_keys, "complete_worker_case_grid", context)
            for row in rows:
                query = queries[row["graph"], row["query_id"]]
                self.validate_row(row, query, config, f"{context}:{row['graph']}:{row['query_id']}:{row['seed']}:{row['method']}", name)
                compact = {"batch": name, "query_count_per_graph": config["query_count"],
                           "mode": worker["mode"], "repeat": worker["repeat"],
                           **{key: row[key] for key in ("graph", "query_id", "seed", "method", "candidate_count",
                             "scope_edge_count", "nominal_certified", "stable", "status", "samples_used",
                             "event_samples_used", "event_count", "random_uniform_draws", "work_used", "work_budget")},
                           **{f"seconds_{key}": value for key, value in row["seconds"].items()}}
                self.compact.append(compact)
            self.processes.append({"batch": name, "query_count_per_graph": config["query_count"],
                "mode": worker["mode"], "repeat": worker["repeat"], "method": measurement["method"],
                "external_wall_seconds": measurement["external_process_wall_seconds"],
                "peak_process_rss_bytes": measurement["peak_process_rss_bytes"],
                "worker_before_serialization_seconds": worker["seconds"]["worker_before_serialization"],
                "module_import_seconds": worker["seconds"]["module_import"],
                "CP_prewarm_seconds": worker["seconds"]["CP_prewarm"],
                "graph_setup_seconds": sum(report["seconds"]["graph_total_including_audits"] for report in worker["graph_setup"]),
                "query_serving_seconds": sum(row["seconds"]["query_serving_total"] for row in rows),
                "child_output_sha256": measurement["output_sha256"], "path": measurement["path"]})
            del worker, rows, queries
        expected_jobs = ({("warm", 0, "all")} if summary["stage"] == "scale" else
                         {("cold", repeat, method) for repeat in range(config["cold_repetitions"]) for method in config["methods"]}
                         | {("warm", repeat, "all") for repeat in range(config["warm_repetitions"])})
        a.check(seen_measurements == expected_jobs, "complete_batch_job_grid", name)


def aggregate_rows(rows):
    nontrivial = [row for row in rows if row["candidate_count"] > 1]
    return {
        "cases": len(rows), "distinct_sources": len({(row["graph"], row["query_id"]) for row in rows}),
        "seeds": sorted({row["seed"] for row in rows}),
        "nominal_certificates": sum(row["nominal_certified"] for row in rows),
        "robust_certificates": sum(row["stable"] for row in rows),
        "nontrivial_cases": len(nontrivial),
        "nontrivial_nominal_certificates": sum(row["nominal_certified"] for row in nontrivial),
        "nontrivial_robust_certificates": sum(row["stable"] for row in nontrivial),
        "worlds": sum(row["samples_used"] for row in rows),
        "event_rows": sum(row["event_samples_used"] for row in rows),
        "random_uniform_draws": sum(row["random_uniform_draws"] for row in rows),
        "work_used": sum(row["work_used"] for row in rows),
        "status_counts": dict(Counter(row["status"] for row in rows)),
        "serving_seconds": descriptive(row["seconds_query_serving_total"] for row in rows),
        "competitive_serving_seconds": descriptive(row["seconds_query_serving_total"] for row in nontrivial),
        "serving_stage_seconds_sum": {key.removeprefix("seconds_"): sum(row[key] for row in rows)
                                      for key in rows[0] if key.startswith("seconds_")} if rows else {}}


def make_artifacts(analyzer, output):
    scientific, serving, cold = [], [], []
    canonical = [row for row in analyzer.compact if row["mode"] == "warm" and row["repeat"] == 0]
    for metadata in analyzer.batch_metadata:
        batch = metadata["batch"]
        subset = [row for row in canonical if row["batch"] == batch]
        for graph in ("ALL", *sorted({row["graph"] for row in subset})):
            for method in METHODS:
                group = [row for row in subset if row["method"] == method and (graph == "ALL" or row["graph"] == graph)]
                if group:
                    scientific.append({"batch": batch, "graph": graph, "method": method,
                                       "query_count_per_graph": metadata["query_count_per_graph"], **aggregate_rows(group)})
        for graph, seed, method in itertools.product(sorted({row["graph"] for row in subset}), metadata["seeds"], METHODS):
            group = [row for row in subset if (row["graph"], row["seed"], row["method"]) == (graph, seed, method)]
            if group:
                scientific.append({"batch": batch, "graph": graph, "seed": seed, "method": method,
                                   "query_count_per_graph": metadata["query_count_per_graph"], **aggregate_rows(group)})
    groups = defaultdict(list)
    for row in analyzer.compact:
        groups[row["batch"], row["mode"], row["repeat"], row["graph"], row["method"]].append(row)
    for key, rows in sorted(groups.items()):
        metrics = aggregate_rows(rows)
        serving.append({**dict(zip(("batch", "mode", "repeat", "graph", "method"), key)),
                        **{name: metrics[name] for name in ("cases", "distinct_sources", "nominal_certificates", "robust_certificates",
                                                           "nontrivial_cases", "nontrivial_robust_certificates", "work_used", "worlds", "event_rows")},
                        **{f"serving_{name}": value for name, value in metrics["serving_seconds"].items()},
                        **{f"competitive_serving_{name}": value for name, value in metrics["competitive_serving_seconds"].items()},
                        **{f"stage_{name}_sum": value for name, value in metrics["serving_stage_seconds_sum"].items()}})
    process_groups = defaultdict(list)
    for process in analyzer.processes:
        if process["mode"] == "cold":
            process_groups[process["batch"], process["method"]].append(process)
    for (batch, method), processes in sorted(process_groups.items()):
        cold.append({"batch": batch, "method": method,
                     "external_wall_seconds": descriptive(item["external_wall_seconds"] for item in processes),
                     "peak_process_rss_bytes": descriptive(item["peak_process_rss_bytes"] for item in processes),
                     "individual_external_wall_seconds": [item["external_wall_seconds"] for item in processes],
                     "repeats": [item["repeat"] for item in processes]})
    audit = {"status": "PASS" if not analyzer.audit.error_counts else "FAIL",
             "check_counts": dict(analyzer.audit.check_counts), "error_counts": dict(analyzer.audit.error_counts),
             "error_examples": analyzer.audit.examples, "warnings": analyzer.audit.warnings,
             "unique_observed_prefixes": len(analyzer.prefixes),
             "raw_worlds_regenerated": False, "scope_completeness_reproved": False}
    result = {"schema": "icde-online-scientific-analysis-20261104-v1", "audit": audit,
        "provenance": {"analysis_script_sha256": analyzer.sha(Path(__file__)), "batches": analyzer.provenance,
            "actual_seed_purpose": PURPOSE, "seed_salt": analyzer.salt,
            "warm_definition": "Every repeat is a fresh worker. Static graphs and CP cache are reused within that worker, not across repeats.",
            "risk_scope": "per query, nominal run and separately evaluated policy; not workload-wide or best-policy protection",
            "scientific_counts": "canonical warm repeat0; other repeats verify deterministic scientific results and measure timing",
            "statistical_units": "distinct graph/source queries, with repeated MC seeds; nested scales and repeats are not new independent queries",
            "timing": "Serving excludes shared graph setup. Cold external process wall includes imports, setup, audits and output; OS cache not flushed.",
            "memory": "Sampled process peak RSS from batch parent; not VRAM or method-specific memory for all-method warm workers.",
            "quantiles": "linear interpolation, descriptive; no population tail-latency guarantee",
            "work": "modeled variable work excludes build, CP, policy, hashing and I/O; all appear in measured wall time"},
        "batches": analyzer.batch_metadata, "scientific_summary": scientific,
        "cold_process_summary": cold, "process_measurements": analyzer.processes,
        "serving_summary": serving, "graph_setup": analyzer.setup_rows}
    write_json(output / "summary.json", result)
    write_json(output / "validation.json", audit)
    write_csv(output / "query_rows.csv", analyzer.compact)
    write_csv(output / "serving_summary.csv", serving)
    write_csv(output / "process_measurements.csv", analyzer.processes)
    write_csv(output / "graph_setup.csv", analyzer.setup_rows)
    plot_points = [{key: value for key, value in row.items()
                    if key not in ("status_counts", "serving_seconds", "competitive_serving_seconds", "serving_stage_seconds_sum")}
                   | {"serving_sum_seconds": row["serving_seconds"]["sum"],
                      "serving_p50_seconds": row["serving_seconds"]["median"],
                      "serving_p95_seconds": row["serving_seconds"]["p95_linear"],
                      "competitive_serving_sum_seconds": row["competitive_serving_seconds"]["sum"],
                      "competitive_serving_p50_seconds": row["competitive_serving_seconds"]["median"],
                      "competitive_serving_p95_seconds": row["competitive_serving_seconds"]["p95_linear"]} for row in scientific]
    write_csv(output / "scientific_points.csv", plot_points)
    lines = ["# ICDE incremental execution: measured results", "",
             f"Audit status: **{audit['status']}**. These are descriptive measurements from the supplied completed batches.", "",
             "Scientific counts use warm repeat 0. Timing repeats do not add independent queries. The actual nominal seed purpose is `icde_online_worlds_v1`; the first two configuration labels differ from that executed purpose. Each warm repeat starts a fresh worker, with static graphs and confidence-bound caches reused within that worker.", "",
             "| Queries/graph | Graph | Method | Nominal | Robust | Competitive robust | Serving total s, all queries | All p50/p95 ms | Competitive p50/p95 ms |",
             "| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for row in scientific:
        if "seed" in row:
            continue
        timing = row["serving_seconds"]
        competitive = row["competitive_serving_seconds"]
        competitive_text = (f"{1000*competitive['median']:.4f}/{1000*competitive['p95_linear']:.4f}"
                            if competitive["n"] else "n/a")
        lines.append(f"| {row['query_count_per_graph']} | {row['graph']} | {row['method']} | {row['nominal_certificates']}/{row['cases']} | {row['robust_certificates']}/{row['cases']} | {row['nontrivial_robust_certificates']}/{row['nontrivial_cases']} | {timing['sum']:.4f} | {1000*timing['median']:.4f}/{1000*timing['p95_linear']:.4f} | {competitive_text} |")
    lines += ["", "Cold end-to-end measurements include process startup, setup, audits and output. Three repetitions support descriptive comparisons; no run is selected for being fastest.", "",
              "| Batch | Method | Repetitions | Mean s | Median s | Min–max s | Individual seconds |",
              "| --- | --- | ---: | ---: | ---: | ---: | --- |"]
    for row in cold:
        timing = row["external_wall_seconds"]
        lines.append(f"| {row['batch']} | {row['method']} | {timing['n']} | {timing['mean']:.4f} | {timing['median']:.4f} | {timing['minimum']:.4f}–{timing['maximum']:.4f} | {', '.join(f'{value:.4f}' for value in row['individual_external_wall_seconds'])} |")
    by_batch = defaultdict(dict)
    for row in cold:
        by_batch[row["batch"]][row["method"]] = row["external_wall_seconds"]
    for batch, methods in by_batch.items():
        if all(method in methods for method in METHODS[:2]):
            baseline, eager = methods[METHODS[0]], methods[METHODS[1]]
            mean_change = 100 * (baseline["mean"] - eager["mean"]) / baseline["mean"]
            median_change = 100 * (baseline["median"] - eager["median"]) / baseline["median"]
            lines += ["", f"For {batch}, eager's cold mean changes by {mean_change:+.2f}% in the direction of lower time, and its cold median changes by {median_change:+.2f}%. These are measured descriptive comparisons; the warm serving totals do not establish the same end-to-end gain."]
    lines += ["", "Scope-only allocates the full 0.05 risk to nominal inference; event methods split 0.025 nominal and 0.025 event risk. Thus whole procedures have equal total risk, while their nominal boundaries differ. These online runs protect one probability box and use three seeds; they must not be pooled with the earlier two-seed V2 pilot.", "",
              "The methods have separate per-query, per-run risk guarantees. Greater modal certification does not establish improved identity accuracy or calibrated real-world probabilities. Repeated seeds, nested query sets and timing repetitions are not independent data sources. Logical work excludes construction, confidence-bound computation, policy and I/O; serving and process measurements include their respective execution costs.", "",
              "Source and checkpoint locality claims are not added by this analysis. Input identities, common-prefix hashes, exact fee-accounting identities and recorded complete event prefixes are audited; the analyzer does not regenerate worlds or prove semantic scope completeness.", "",
              "Warm all-method RSS is a shared-worker measurement. CPU peak RSS is not VRAM. Scale runs have one observed worker unless additional repetitions appear explicitly in the supplied batch."]
    if audit["status"] != "PASS":
        lines += ["", "**Audit failed. Do not use these descriptive tables as validated publication results until the listed issues are resolved.**"]
    with (output / "RESULTS_DRAFT.md").open("x", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return not analyzer.audit.error_counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", action="append", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    output = resolve_repo(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    analyzer = None
    try:
        analyzer = Analyzer()
        for batch in args.batch:
            analyzer.batch(batch)
        success = make_artifacts(analyzer, output)
    except Exception as error:
        write_json(output / "analysis_failure.json", {"status": "ANALYSIS_FAILED", "error": str(error),
                   "traceback": traceback.format_exc(), "no_publication_validation": True})
        raise
    print(json.dumps({"output": relative(output), "audit": "PASS" if success else "FAIL",
                      "rows": len(analyzer.compact), "errors": dict(analyzer.audit.error_counts)}))
    if not success:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
