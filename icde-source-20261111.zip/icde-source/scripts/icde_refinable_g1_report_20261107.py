"""Read-only audit/report and standalone scientific figure for the G1 pilot."""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "nodes/09_vldb_query_certification/results/icde_refinable_g1_20261107/attempt1"


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, obj):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def analyze(out):
    summary, protocol = load(out / "summary.json"), load(out / "protocol.json")
    oldbase = ROOT / "nodes/09_vldb_query_certification/results/icde_prospective_20261107"
    expected = {(r["graph"], r["rank"], t, s, p) for r in protocol["cases"]
                for t in protocol["taus"] for s in protocol["seeds"] for p in protocol["policies"]}
    actual, checks = set(), 0
    def require(ok, message):
        nonlocal checks
        if not ok:
            raise AssertionError(message)
        checks += 1
    for group in ("code_sha256", "input_sha256"):
        for name, digest in protocol[group].items():
            require(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest,
                    "frozen artifact changed")
    for row in summary["cases"]:
        key = row["graph"], row["rank"], row["tau"], row["seed"], row["policy"]
        require(key not in actual, "duplicate run")
        actual.add(key)
        require(0 <= row["dp_work"] <= protocol["pair_work_budget"], "work cap violation")
        require(0 <= row["worlds"] <= protocol["max_worlds"], "sample cap violation")
        require(row["compute_seconds"] >= 0, "negative time")
        reference = load(oldbase / "new_exact_reference" / f"{row['graph']}_q{row['rank']:03d}_t{row['tau']}.json")
        require(row["winner"] is None or row["winner"] in reference["uniform_winners"], "unsafe output")
        require(row["worlds"] != 0 or row["status"].startswith("direct"), "unsupported no-sample output")
    require(actual == expected, "incomplete declared matrix")
    mechanism, pairs, failures = [], [], []
    for tau in protocol["taus"]:
        selected = [r for r in summary["mechanisms"] if r["tau"] == tau]
        mechanism.append({"tau": tau, "distinct_queries": len(selected),
            "exact_safe": sum(bool(r["exact_uniform_winners"]) for r in selected),
            "scalar_population": sum(r["scalar_population_certifiable"] for r in selected),
            "directional_population": sum(r["directional_population_certifiable"] for r in selected),
            "directional_only": sum(r["directional_population_certifiable"] and not r["scalar_population_certifiable"] for r in selected),
            "quantifier_incomplete": sum(r["quantifier_incomplete"] for r in selected)})
        lookup = {(r["graph"], r["rank"], r["seed"], r["policy"]): r
                  for r in summary["cases"] if r["tau"] == tau}
        observations = [(lookup[g, i, z, "fully_paid"], lookup[g, i, z, "adaptive"])
                        for g, i, z in {(r["graph"], r["rank"], r["seed"])
                                       for r in summary["cases"] if r["tau"] == tau}]
        full_work = sum(a["dp_work"] for a, b in observations)
        adaptive_work = sum(b["dp_work"] for a, b in observations)
        full_time = sum(a["compute_seconds"] for a, b in observations)
        adaptive_time = sum(b["compute_seconds"] for a, b in observations)
        pairs.append({"tau": tau, "paired_cases": len(observations),
            "identical_winner_or_unresolved": sum(a["winner"] == b["winner"] for a, b in observations),
            "adaptive_only": sum(a["winner"] is None and b["winner"] is not None for a, b in observations),
            "fully_paid_only": sum(b["winner"] is None and a["winner"] is not None for a, b in observations),
            "fully_paid_dp_work": full_work, "adaptive_dp_work": adaptive_work,
            "dp_work_reduction": 1 - adaptive_work / full_work,
            "adaptive_to_fully_paid_time_ratio": adaptive_time / full_time})
        for row in selected:
            gaps = list(map(Q, row["directional_population_gaps_exact"]))
            require(not any(g > 0 for g in gaps) or bool(row["exact_uniform_winners"]),
                    "positive directional gap contradicts exact reference")
            if row["quantifier_incomplete"]:
                reference = load(oldbase / "new_exact_reference" / f"{row['graph']}_q{row['rank']:03d}_t{tau}.json")
                w = reference["uniform_winners"][0]
                true_gap = min(Q(p["minimum_gap"]) for p in reference["candidate_results"][w]["pair_gap_ranges"])
                failures.append({"graph": row["graph"], "rank": row["rank"], "query_id": row["query_id"],
                    "tau": tau, "winner": w, "true_minimum_gap_exact": str(true_gap),
                    "true_minimum_gap": float(true_gap), "directional_gap_exact": str(gaps[w]),
                    "directional_gap": float(gaps[w])})
    require(len(summary["compiler_audits"]) == len(protocol["cases"]) * len(protocol["taus"]), "missing compiler audit")
    full = [r for r in summary["cases"] if r["policy"] == "fully_paid"]
    adaptive = [r for r in summary["cases"] if r["policy"] == "adaptive"]
    aggregate = {
        "same_decision_cases": sum(r["identical_winner_or_unresolved"] for r in pairs),
        "paired_cases": len(full),
        "dp_work_reduction": 1 - sum(r["dp_work"] for r in adaptive) / sum(r["dp_work"] for r in full),
        "adaptive_to_fully_paid_time_ratio": sum(r["compute_seconds"] for r in adaptive) / sum(r["compute_seconds"] for r in full)}
    metrics = {"status": "PASS", "independent_accounting_checks": checks,
        "population_mechanism": mechanism, "paired": pairs, "paired_aggregate": aggregate,
        "real_quantifier_counterexamples": failures,
        "compiler_audit_checks": sum(r["checks"] for r in summary["compiler_audits"]),
        "compiler_state_cases": sum(r["draws_plus_cube"] for r in summary["compiler_audits"]),
        "tighter_state_cases": sum(r["tighter_than_intervals"] for r in summary["compiler_audits"]),
        "not_exact_state_cases": sum(r["refined_set_not_exact"] for r in summary["compiler_audits"]),
        "gate": {"prototype_correctness": "PASS_ON_AUDITED_CASES", "directional_population_advantage": "NOT_ESTABLISHED",
                 "adaptive_end_to_end_advantage": "NOT_ESTABLISHED", "new_confirmation_expansion": "DO_NOT_EXPAND_YET"}}
    save(out / "analysis.json", metrics)
    save(out / "validation.json", {"status": "PASS", "checks": checks,
        "declared_runs": len(expected), "distinct_queries": len(protocol["cases"]),
        "result_sha256": hashlib.sha256((out / "summary.json").read_bytes()).hexdigest(),
        "note": "Finite implementation/accounting audit, not novelty or population-wide zero-error proof"})
    lines = ["# 可细化证据G1开发验证", "", "日期：2026-11-07。协议先于新推断冻结；本轮使用已研究数据，不是前瞻确认。", "",
        '[说明文本已清理]', "",
        '[说明文本已清理]', "",
        "## 输入与比较", "",
        "复用原有全部20个非单候选、完整scope≤8的精确参考查询，候选数2或3。三种宽度、两个新随机种子、四种策略，共480次运行。概率为配置的独立边保留q=.9。它们来自完整图保留候选的查询，但这个小scope子组不代表完整工作负载，也不是新的独立确认集。", "",
        "所有策略使用相同候选、随机前缀、δ=1/20、均匀混合betting、256世界上限、2048次声明DP工作预算及全局直接区间。DP工作包括状态转移和最终状态评分，不包括全部系统成本；实际计算时间另计。", "",
        "coarse只使用区间候选证据；fully_paid逐样本充分尝试成对排除；adaptive按当前最难竞争者补算历史样本；direct_pair先尝试全世界成对证明再回退fully_paid。coarse不是历史cheap传输方法。参考枚举不进入策略决策或策略计时。", "",
        "## 总体层面的证据强度", "",
        "下表用精确概率比较机制的可认证性，不是给任何策略免费提供总体概率的运行实验。scalar指已知最优统一候选漂移时的严格gap>2ε条件，而非粗糙全图TV。", "",
        "| 参数半宽τ | 真正全族稳定/20 | scalar总体条件可通过 | 精确方向性总体条件可通过 | 量词松弛遗漏 |", "| --- | ---: | ---: | ---: | ---: |"]
    for r in mechanism:
        lines.append(f"| {r['tau']:g} | {r['exact_safe']} | {r['scalar_population']} | {r['directional_population']} | {r['quantifier_incomplete']} |")
    lines += ["", "三种宽度均未发现方向性可通过而scalar不能通过的真实查询。τ=.25有2个真实查询的全族最小众数gap约+.09，但精确逐输入最坏证据gap约−.155；即使把候选集合算到精确，增加样本也不能修复其负均值。", "",
        "| 查询 | τ | 实际全族最小gap | 精确抽象gap |", "| --- | ---: | ---: | ---: |"]
    for r in failures:
        lines.append(f"| {r['graph']} rank {r['rank']} | {r['tau']:g} | {r['true_minimum_gap']:.6f} | {r['directional_gap']:.6f} |")
    lines += ["", "## 有限预算执行结果", "", "每项分母40为20个query×2个seed，不是40个独立query。", "",
        "| τ | coarse认证 | fully_paid认证 | adaptive认证 | direct_pair回退认证 | adaptive减少DP工作 | adaptive/full总计算时间比 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
    for pair in pairs:
        tau = pair["tau"]
        counts = {r["policy"]: r["certified"] for r in summary["aggregates"] if r["tau"] == tau}
        lines.append(f"| {tau:g} | {counts['coarse']}/40 | {counts['fully_paid']}/40 | {counts['adaptive']}/40 | {counts['direct_pair_then_fully_paid']}/40 | {100*pair['dp_work_reduction']:.1f}% | {pair['adaptive_to_fully_paid_time_ratio']:.3f} |")
    lines += ["", f"adaptive与fully_paid的{aggregate['paired_cases']}个配对案例全部给出相同winner或未决决定。总DP工作少{100 * aggregate['dp_work_reduction']:.1f}%，观测总计算时间比为{aggregate['adaptive_to_fully_paid_time_ratio']:.3f}[说明文本已清理]", "",
        "τ=.05时pair编译比coarse多认证5个query×seed案例，支持共享结构编译比独立区间更精确；它不证明候选方向优于scalar传输，更不证明adaptive比fully_paid增加覆盖。", "",
        "## 正确性与审计", "",
        f"- 480个输出均与独立全参数盒精确参考相容，观测错误认证0；不能外推为未枚举查询零错误。",
        f"- {metrics['compiler_state_cases']}个抽样/全立方体状态案例，{metrics['compiler_audit_checks']}项编译核对；{metrics['tighter_state_cases']}个案例比独立区间更紧，本次精化集合与精确可能赢家集合无差异。这是有限集合，不是所有输入的编译正确性证明。",
        "- 5项针对共享边、任意历史补算、预算截断、非法细化与位序的独立单元测试通过。",
        "- 预先指定的scalar分离合成例在两种子下分别用271和189样本获证；量词松弛合成例在1024样本内均保持未决。合成例展示能力边界，不是实际图收益。",
        "- 冻结历史代码、参考与准备对象前后哈希一致；新任务在local16约束下单进程完成，运行约18秒、峰值内存约0.04GiB。", "",
        "## 对贡献设计的影响与下一顺序", "",
        '[说明文本已清理]',
        "2. C2的路径下界仍可保证有效性，但真实例证明其不完备性有实际影响。不能把理论正确性写成更强的认证能力。",
        '[说明文本已清理]',
        '[说明文本已清理]',
        '[说明文本已清理]', "",
        "数据入口：[协议](protocol.json)、[原始结果](summary.json)、[独立分析](analysis.json)、[核验](validation.json)。图见[机制与执行对照](figures/g1_mechanism_execution.pdf)。"]
    with (out / "RESULTS_ZH.md").open("x", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    print(json.dumps({"validation": "PASS", "checks": checks, "gate": metrics["gate"]}, ensure_ascii=False))


def figures(out):
    sys.path.insert(0, str(ROOT / ".runtime/icde_plot_site"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    data = load(out / "analysis.json")
    destination = out / "figures"
    destination.mkdir(exist_ok=False)
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42, "savefig.dpi": 180})
    fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.4))
    x, width = [0, 1, 2], .23
    for offset, key, label, color in ((-1, "exact_safe", "Exact robust mode", "#52657d"),
                                     (0, "scalar_population", "Scalar drift condition", "#57a0b5"),
                                     (1, "directional_population", "Directional condition", "#d18a49")):
        values = [r[key] for r in data["population_mechanism"]]
        bars = axes[0].bar([i + offset * width for i in x], values, width, label=label, color=color)
        axes[0].bar_label(bars, padding=2, fontsize=8)
    axes[0].set(xticks=x, xticklabels=["0.05", "0.25", "1.0"], ylim=(0, 23),
                xlabel="Parameter half-width", ylabel="Queries (out of 20)",
                title="A. Population evidence: exact small-scope reference")
    axes[0].legend(frameon=False, loc="upper right", fontsize=8)
    pair = data["paired"]
    for offset, values, label, color in ((-.18, [1-r["dp_work_reduction"] for r in pair], "DP work", "#57a0b5"),
                                       (.18, [r["adaptive_to_fully_paid_time_ratio"] for r in pair], "Observed compute time", "#d18a49")):
        bars = axes[1].bar([i + offset for i in x], values, .34, label=label, color=color)
        axes[1].bar_label(bars, fmt="%.2f", padding=3, fontsize=8)
    axes[1].axhline(1, color="#52657d", linestyle="--", linewidth=1)
    axes[1].set(xticks=x, xticklabels=["0.05", "0.25", "1.0"], ylim=(0, 1.32),
                xlabel="Parameter half-width", ylabel="Adaptive / fully paid (lower is better)",
                title="B. Equal decisions; no observed compute-time gain")
    axes[1].legend(frameon=False, loc="lower left", fontsize=8)
    fig.text(.5, .02, "Development pilot: 20 known queries; 2 seeds; population conditions are not finite-sample serving results.",
             ha="center", fontsize=8, color="#4e5965")
    fig.tight_layout(rect=(0, .06, 1, 1), w_pad=2.1)
    for suffix in ("png", "pdf"):
        fig.savefig(destination / f"g1_mechanism_execution.{suffix}", bbox_inches="tight")
    plt.close(fig)
    print(str(destination))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("analyze", "figures"), required=True)
    parser.add_argument("--output", type=Path, default=DEFAULT)
    args = parser.parse_args()
    {"analyze": analyze, "figures": figures}[args.phase](args.output.resolve())
