"""Serial, single-query end-to-end timing using the host's existing E1/E2 artifacts.

No Monte Carlo reconstruction. All 45 fresh processes run sequentially.
Process startup/first-request measurements do not imply a cold OS file cache.
"""
from __future__ import annotations
import argparse
import gc
import json
import os
import random
import subprocess
import sys
import threading
import time
from pathlib import Path
# Set before importing NumPy so all fresh workers use the same BLAS concurrency.
for thread_key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[thread_key] = "1"
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
for folder in (ROOT/"scripts",ROOT/"src"):
    sys.path.insert(0,str(folder))
import torch
torch.set_num_threads(1)
import www_certify_serving as srv
from run_www_equal_budget import load_full_payload,load_representation_payload
from pkgea.www_fsl import gaussian_distance_matrix
from www_reviewer_v2_common import freeze,save_once,sha

V1=ROOT/"nodes/04_www_distributional/results/reviewer_followup_v1"
OUT=ROOT/"nodes/04_www_distributional/results/reviewer_followup_v2/e3"
INPUTS=ROOT/".runtime/www_reviewer_e3_inputs"
CELLS=("dw_gcn_independent","enfr_relation_structural","eventea_gcn_structural")
METHODS=("full_fp32","full_fp16","margin_f16")
TAG="margin_f16_c50"
STAGES=("authorization","final_test")
REPS=5
SOURCES=["scripts/run_www_reviewer_e3_v2.py","scripts/run_www_reviewer_retest.ps1","scripts/www_reviewer_v2_common.py",
    "scripts/www_certify_serving.py","scripts/run_www_equal_budget.py","src/pkgea/www_fsl.py",
    "src/pkgea/distributional/full_covariance.py","papers/www/REVIEWER_FOLLOWUP_RETEST_20261003.md"]


def read(path):return json.loads(path.read_text(encoding="utf-8"))


def locations(cell,method):
    if method=="margin_f16":
        return (ROOT/f".runtime/www_reviewer_e2_v1/{cell}/{TAG}.npz",
                ROOT/f".runtime/www_reviewer_e2_bounds_v1/{cell}/{TAG}.npz")
    return (srv.payload_path(cell,method),None if method=="full_fp32" else srv.bounds_path(cell,method))


def plan():
    result={**freeze(SOURCES),"schema_version":"www-reviewer-e3-v2",
        "cells":list(CELLS),"methods":list(METHODS),"reps":REPS,"e2_frontier_tag":TAG,
        "cache_scope":"OS cache uncontrolled; fresh-process load and first request only",
        "load_scope":"payload decode, bounds load, backing verification; excludes Python import/startup",
        "torch_threads":torch.get_num_threads(),
        "files":{},"inputs":{}}
    inputs=read(INPUTS/"manifest.json")
    result["files"][(INPUTS/"manifest.json").relative_to(ROOT).as_posix()]=sha(INPUTS/"manifest.json")
    for cell in CELLS:
        fixed_path=ROOT/f"nodes/04_www_distributional/results/fixed_index_v1/{cell}.json"
        fixed=read(fixed_path)
        result["files"][fixed_path.relative_to(ROOT).as_posix()]=sha(fixed_path)
        result["inputs"][cell]=fixed["inputs"]
        for method in METHODS:
            payload,bounds=locations(cell,method)
            if method!="margin_f16" and sha(payload)!=fixed["artifacts"][method]["sha256"]:
                raise RuntimeError(f"STOP: frozen payload mismatch: {cell}/{method}")
            if bounds:
                with np.load(bounds,allow_pickle=False) as data:
                    meta=json.loads(str(data["metadata_json"]))
                    if meta["payload_sha256"]!=sha(payload):raise RuntimeError("STOP: bounds payload mismatch")
                    values=np.asarray(data["deltas_f32"],dtype=np.float64)
                    if values.shape!=(1012,) or np.any(~np.isfinite(values)) or np.any(values<0):
                        raise RuntimeError("STOP: invalid stored bounds")
                if method=="margin_f16":
                    evidence=V1/f"e2/cells/{cell}_final_test.json"
                    recorded=read(evidence)["artifacts"][TAG]
                    result["files"][evidence.relative_to(ROOT).as_posix()]=sha(evidence)
                    if payload.stat().st_size+bounds.stat().st_size!=recorded["front_bytes"]:
                        raise RuntimeError("STOP: E2 front bytes mismatch")
                else:
                    evidence=V1/f"cells/{cell}_final_test.json"
                    result["files"][evidence.relative_to(ROOT).as_posix()]=sha(evidence)
                    if sha(bounds)!=read(evidence)["methods"][method]["front_bytes"]["bounds_sha256"]:
                        raise RuntimeError("STOP: E1 bound hash mismatch")
            for path in (payload,bounds):
                if path:result["files"][path.relative_to(ROOT).as_posix()]=sha(path)
        back=srv.backing_path(cell);result["files"][back.relative_to(ROOT).as_posix()]=sha(back)
        for stage in STAGES:
            for key in ("qm","qc"):
                path=INPUTS/f"{cell}_{stage}_{key}.npy"
                data=np.load(path)
                if len(data)!=100 or srv.sha256_bytes(data.tobytes())!=inputs["cells"][cell][stage][key+"_sha256"]:
                    raise RuntimeError(f"STOP: cached query moments differ: {path}")
                result["files"][path.relative_to(ROOT).as_posix()]=sha(path)
    return result


def timed_query(qm,qc,im,ic,deltas,store,reference=False):
    started=time.perf_counter();phases={}
    t=time.perf_counter();reason=srv.validate_domain(qm,qc)
    if reason=="non-finite source moments":raise RuntimeError("STOP: non-finite query")
    phases["domain_validation"]=time.perf_counter()-t
    t=time.perf_counter()
    # This is the full Gaussian comparison, including array preparation and PSD work.
    squared=gaussian_distance_matrix(np.concatenate((qm[None],im)),np.concatenate((qc[None],ic)),1)[0]
    estimate=np.sqrt(np.maximum(squared,0))
    phases["compressed_match"]=time.perf_counter()-t
    t=time.perf_counter();winner=int(np.argmin(squared));active=np.array([],dtype=int)
    if reference:
        state="full_reference";answer=winner;gap=None
    else:
        positions=np.arange(len(im));upper=estimate+deltas;lower=estimate-deltas
        gap=float(np.min(np.where(positions==winner,np.inf,lower))-upper[winner])
        if reason is not None:state="full_index_safe_path";active=positions
        elif gap>0:state="certified"
        else:state="refined";active=positions[(lower<=upper[winner])|(positions==winner)]
        answer=winner
    phases["bound_check"]=time.perf_counter()-t
    phases["backing_read"]=0.;phases["exact_active_set"]=0.
    if len(active):
        t=time.perf_counter();restored=store.read_targets(active);phases["backing_read"]=time.perf_counter()-t
        t=time.perf_counter()
        distances=srv.exact_distances(qm,qc,restored["means"],restored["covariances"])
        answer=int(active[int(np.argmin(distances))]);phases["exact_active_set"]=time.perf_counter()-t
    phases["total"]=time.perf_counter()-started
    return {"served_answer":answer,"state":state,"domain_rejection":reason,"gap":gap,
            "active_set_size":len(active),"records_read":len(active),"phases":phases}


class RssSampler:
    def __enter__(self):
        import psutil
        self.process=psutil.Process(os.getpid());self.peak=self.process.memory_info().rss
        self.stop_event=threading.Event()
        def sample():
            while not self.stop_event.wait(.002):self.peak=max(self.peak,self.process.memory_info().rss)
        self.thread=threading.Thread(target=sample,daemon=True);self.thread.start();return self
    def __exit__(self,*args):
        self.peak=max(self.peak,self.process.memory_info().rss)
        self.stop_event.set();self.thread.join()


def worker(cell,method,rep,pinned):
    if plan()!=pinned:raise RuntimeError("STOP: code/input plan changed after freeze")
    query={s:(np.load(INPUTS/f"{cell}_{s}_qm.npy"),np.load(INPUTS/f"{cell}_{s}_qc.npy")) for s in STAGES}
    # Reference work is untimed, then full reference arrays are released for RSS.
    fm,fc=load_full_payload(srv.payload_path(cell,"full_fp32").read_bytes())
    truth={s:np.argmin(gaussian_distance_matrix(np.concatenate((qm,fm)),np.concatenate((qc,fc)),100),axis=1)
           for s,(qm,qc) in query.items()}
    del fm,fc;gc.collect()
    payload,bounds=locations(cell,method)
    rows=[]
    with RssSampler() as rss:
        t=time.perf_counter();blob=payload.read_bytes()
        im,ic=(load_representation_payload(blob) if method=="margin_f16" else load_full_payload(blob))
        deltas=None
        if bounds:
            with np.load(bounds,allow_pickle=False) as data:
                deltas=np.asarray(data["deltas_f32"],dtype=np.float64)
        store=None if method=="full_fp32" else srv.open_backing(cell)
        load_seconds=time.perf_counter()-t
        resident_index_bytes=im.nbytes+ic.nbytes+(0 if deltas is None else deltas.nbytes)
        record_bytes=None if store is None else store.header["record_bytes"]
        if record_bytes not in (None,612):raise RuntimeError("STOP: unexpected backing record size")
        for stage,(qm,qc) in query.items():
            for q in range(100):
                row=timed_query(qm[q],qc[q],im,ic,deltas,store,reference=method=="full_fp32")
                row.update(stage=stage,query_index=q,reference_winner=int(truth[stage][q]))
                if row["served_answer"]!=row["reference_winner"]:
                    save_once(OUT/"STOP_case.json",{"cell":cell,"method":method,"row":row,
                        "query_mean":qm[q].tolist(),"query_covariance":qc[q].tolist()})
                    raise RuntimeError("STOP: wrong served answer")
                row["correct"]=True;rows.append(row)
    records=sum(x["records_read"] for x in rows)
    bytes_read=0 if store is None else store.bytes_read
    if bytes_read!=records*612:raise RuntimeError("STOP: record byte mismatch")
    return {"schema_version":"www-reviewer-e3-worker-v2","cell":cell,"method":method,"rep":rep,
        "freeze_commit":pinned["freeze_commit"],"process_load_seconds":load_seconds,"rows":rows,
        "peak_process_rss_bytes":rss.peak,"decoded_index_array_bytes":resident_index_bytes,
        "front_disk_bytes":payload.stat().st_size+(0 if bounds is None else bounds.stat().st_size),
        "backing_disk_bytes":0 if store is None else srv.backing_path(cell).stat().st_size,
        "startup_backing_verification_bytes":0 if store is None else srv.backing_path(cell).stat().st_size,
        "records_read":records,"logical_query_bytes_read":bytes_read,"record_bytes":record_bytes}


def aggregate():
    totals={}
    for method in METHODS:
        outputs=[read(OUT/f"raw/{c}_{method}_rep{r}.json") for c in CELLS for r in range(REPS)]
        rows=[x for out in outputs for x in out["rows"]]
        if len(rows)!=3000 or not all(x["correct"] and x["served_answer"]==x["reference_winner"] for x in rows):
            raise RuntimeError("STOP: incomplete/incorrect raw measurement")
        # Only the first request of each process is a first-process request.
        steady=[x for out in outputs for x in out["rows"][1:]]
        totals[method]={"unique_queries":600,"repeated_query_measurements":len(rows),
            "states":{s:sum(x['state']==s for x in rows) for s in ('certified','refined','full_reference','full_index_safe_path')},
            "front_disk_bytes_mean":float(np.mean([o['front_disk_bytes'] for o in outputs])),
            "backing_disk_bytes_mean":float(np.mean([o['backing_disk_bytes'] for o in outputs])),
            "decoded_index_array_bytes_mean":float(np.mean([o['decoded_index_array_bytes'] for o in outputs])),
            "peak_process_rss_bytes_mean":float(np.mean([o['peak_process_rss_bytes'] for o in outputs])),
            "records_read_total":sum(o['records_read'] for o in outputs),
            "logical_query_bytes_read_total":sum(o['logical_query_bytes_read'] for o in outputs),
            "steady_query_seconds":{str(p):float(np.percentile([x['phases']['total'] for x in steady],p)) for p in (50,95,99)},
            "first_process_query_seconds":{str(p):float(np.percentile([o['rows'][0]['phases']['total'] for o in outputs],p)) for p in (50,95,99)},
            "process_load_seconds":{str(p):float(np.percentile([o['process_load_seconds'] for o in outputs],p)) for p in (50,95,99)},
            "phase_seconds_mean":{k:float(np.mean([x['phases'][k] for x in rows])) for k in rows[0]['phases']}}
    result={"status":"E3_V2_PASS","scope":"full single-query Gaussian matching included; OS cache uncontrolled",
            "methods":totals,"wrong":0}
    save_once(OUT/"summary.json",result);print(json.dumps(result,indent=2))


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--preflight-only",action="store_true")
    parser.add_argument("--smoke",action="store_true")
    parser.add_argument("--worker",nargs=3,metavar=("CELL","METHOD","REP"));args=parser.parse_args()
    pinned=plan()
    if args.preflight_only:
        print(f"PREFLIGHT PASS: {len(pinned['files'])} host files pinned; 45 serial fresh processes; no MC rerun")
        return
    if args.smoke:
        outputs=[worker(CELLS[0],method,0,pinned) for method in METHODS]
        save_once(OUT.parent/"e3_smoke/engineering.json",{
            "status":"ENGINEERING_PASS","freeze_commit":pinned['freeze_commit'],
            "query_decisions":sum(len(x['rows']) for x in outputs),"wrong":0})
        print("ENGINEERING_PASS: all three methods, 600 query decisions; formal timings not started")
        return
    save_once(OUT/"manifest.json",pinned)
    if args.worker:
        cell,method,rep=args.worker
        if cell not in CELLS or method not in METHODS or int(rep) not in range(REPS):raise RuntimeError("bad worker")
        save_once(OUT/f"raw/{cell}_{method}_rep{rep}.json",worker(cell,method,int(rep),pinned));return
    for rep in range(REPS):
        for cell in CELLS:
            order=list(METHODS);random.Random(20261003+rep).shuffle(order)
            for method in order:
                path=OUT/f"raw/{cell}_{method}_rep{rep}.json"
                if path.exists():
                    old=read(path)
                    if old['freeze_commit']!=pinned['freeze_commit'] or len(old['rows'])!=200 or not all(x['correct'] for x in old['rows']):
                        raise RuntimeError("STOP: invalid resumed worker")
                    print("SKIP",cell,method,rep,flush=True);continue
                print("RUN",cell,method,rep,flush=True)
                subprocess.run([sys.executable,str(Path(__file__).resolve()),"--worker",cell,method,str(rep)],cwd=ROOT,check=True)
    aggregate()


if __name__=="__main__":
    try:main()
    except Exception as exc:
        save_once(OUT/"STOP.json",{"error":str(exc)})
        raise
