"""Direct categorical mode inference and protected numerical gap bounds.

Primary sources:
* Jain et al., AISTATS 2022, Sections 2 and 3.1:
  https://proceedings.mlr.press/v151/anand-jain22a/anand-jain22a.pdf
* Maurer and Pontil, 2009, Theorem 4:
  https://arxiv.org/pdf/0907.3740

Jain's published PPR-1v1 uses a uniform Beta(1,1) prior and delta/(K-1)
mode-error allocation. The default here conservatively protects every unordered
pair with delta/binom(K,2), as requested by the common all-pairs contract.
allocation='jain_mode' recovers the published allocation; prior='jeffreys' is
an explicitly named Beta(1/2,1/2) variant, not the paper's default.

PPR only certifies a zero-gap decision. It is not a numerical lower bound and
must not be substituted into a positive robustness threshold. Empirical
Bernstein below is a fixed-checkpoint bound, not a betting confidence sequence.
All guarantees concern an independent categorical stream with a fixed universe.
"""

from __future__ import annotations

from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
from functools import lru_cache
import math
from numbers import Integral


DEFAULT_CHECKPOINTS = tuple(range(32, 4097, 64)) + (4096,)
PRECISION = 80


def _fraction(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name} cannot be Boolean")
    try:
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError("nonfinite value")
            return Fraction.from_float(value)
        return Fraction(value)
    except (TypeError, ValueError, OverflowError, ZeroDivisionError) as error:
        raise ValueError(f"invalid {name}") from error


def _delta(value):
    value = _fraction(value, "delta")
    if not 0 < value < 1:
        raise ValueError("delta must lie strictly between zero and one")
    return value


def _counts(counts, n):
    if isinstance(n, bool) or not isinstance(n, Integral) or n < 0:
        raise ValueError("n must be a nonnegative integer")
    values = tuple(counts)
    if not values or any(isinstance(value, bool) or not isinstance(value, Integral)
                         or value < 0 for value in values):
        raise ValueError("counts must be nonempty nonnegative integers")
    values = tuple(int(value) for value in values)
    if sum(values) != n:
        raise ValueError("categorical counts must sum to n")
    return values, int(n)


def _top_two(values):
    leader = max(range(len(values)), key=lambda index: (values[index], -index))
    competitor = max((index for index in range(len(values)) if index != leader),
                     key=lambda index: (values[index], -index), default=None)
    return leader, competitor


@lru_cache(maxsize=32768)
def _ppr_terms(a, b, prior):
    """Exact numerator/denominator of prior/posterior density at 1/2."""
    total = a + b
    pair_binomial = math.comb(total, a)
    if prior == "uniform":
        return 1 << total, (total + 1) * pair_binomial
    if prior == "jeffreys":
        return math.comb(2 * a, a) * math.comb(2 * b, b), (1 << total) * pair_binomial
    raise ValueError("prior must be uniform or jeffreys")


def ppr_pair_ratio(a, b, *, prior="uniform") -> Fraction:
    """Return the exact PPR at pair-null p=1/2; other labels are not trials."""
    if any(isinstance(value, bool) or not isinstance(value, Integral) or value < 0
           for value in (a, b)):
        raise ValueError("pair counts must be nonnegative integers")
    numerator, denominator = _ppr_terms(int(a), int(b), prior)
    return Fraction(numerator, denominator)


def ppr_details(counts, n, delta, *, prior="uniform", allocation="all_pairs") -> dict:
    """Inspect a nominal PPR decision, preserving exact risk arithmetic.

    For each pair's conditional Bernoulli parameter, the prior/posterior ratio
    at the true parameter is a nonnegative (super)martingale. Its confidence
    sets are intervals containing the empirical pair fraction. If a>b and the
    set excludes 1/2, the entire set lies above 1/2. A union bound protects
    data-dependent leaders and arbitrary global inspection times.

    For a fixed a and b<a, E(a,b+1)/E(a,b)=2(b+nu)/(a+b+2nu)<1.
    Thus the largest competitor count is the hardest test for either symmetric
    prior, proving the top-two shortcut rather than assuming pair independence.
    """
    values, n = _counts(counts, n)
    risk = _delta(delta)
    if prior not in ("uniform", "jeffreys"):
        raise ValueError("prior must be uniform or jeffreys")
    if allocation not in ("all_pairs", "jain_mode"):
        raise ValueError("allocation must be all_pairs or jain_mode")
    k = len(values)
    leader, competitor = _top_two(values)
    divisor = max(1, k * (k - 1) // 2 if allocation == "all_pairs" else k - 1)
    alpha = risk / divisor
    a, b = values[leader], values[competitor] if competitor is not None else 0
    numerator, denominator = _ppr_terms(a, b, prior)
    separated = a > b and numerator * alpha.numerator >= denominator * alpha.denominator
    return {
        "certified": k == 1 or separated,
        "candidate_index": leader if k == 1 or separated else None,
        "empirical_leader_index": leader, "competitor_index": competitor,
        "candidate_count": k, "nominal_samples": n, "pair_samples": a + b,
        "leader_count": a, "competitor_count": b,
        "prior": prior, "allocation": allocation, "alpha_exact": str(alpha),
        "log_ppr_at_half_diagnostic": math.log(numerator) - math.log(denominator),
        "decision_arithmetic": "exact_integer_cross_multiplication",
        "numerical_positive_gap_provided": False,
        "simultaneous_all_pairs_guarantee": allocation == "all_pairs",
        "rule_name": ("jain2022_uniform_PPR_1v1" if prior == "uniform" and allocation == "jain_mode"
                      else f"PPR_1v1_{prior}_{allocation}"),
    }


def ppr_certified(counts, n, delta, *, prior="uniform", allocation="all_pairs") -> bool:
    """Nominal-only mode decision. See ppr_details for the exact contract."""
    return bool(ppr_details(counts, n, delta, prior=prior, allocation=allocation)["certified"])


def _contexts():
    return (Context(prec=PRECISION, rounding=ROUND_CEILING),
            Context(prec=PRECISION, rounding=ROUND_FLOOR))


def _decimal(value: Fraction, context):
    return context.divide(Decimal(value.numerator), Decimal(value.denominator))


def _log_up(value: Fraction, context):
    # Decimal ln/sqrt are correctly rounded. One exterior Decimal neighbour
    # additionally protects their conversion even if rounding is nearest.
    return context.next_plus(context.ln(_decimal(value, context)))


def _float_down(value: Decimal):
    if value <= -1:
        return -1.
    if value >= 1:
        return 1.
    result = float(value)
    if Fraction.from_float(result) > Fraction(value):
        result = math.nextafter(result, -math.inf)
    return result


def _rule(rule):
    specification = {"name": rule} if isinstance(rule, str) else dict(rule)
    name = specification.get("name", specification.get("rule"))
    aliases = {"normal": "normal_mixture", "eb": "empirical_bernstein",
               "empirical_bernstein_fixed_checkpoints": "empirical_bernstein"}
    name = aliases.get(name, name)
    if name not in ("normal_mixture", "empirical_bernstein"):
        raise ValueError("need a numerical-gap rule; PPR cannot supply a robustness margin")
    specification["name"] = name
    return specification


def numerical_gap_details(counts, n, delta, rule="normal_mixture") -> dict:
    """Lower bound on the empirical leader's least favorable true gap.

    EB: let C=binom(K,2), M be the number of frozen checks, a/b the largest
    two counts, mean=(a-b)/n, V=((a+b)-(a-b)^2/n)/(n-1). Apply Maurer--Pontil
    Theorem 4 to (D+1)/2 and its complement, for both directions of every pair.
    alpha=delta/(2*C*M); radius=sqrt(2*V*ln(2/alpha)/n)
    +14*ln(2/alpha)/(3*(n-1)). Only listed fixed prefixes are protected.

    At fixed a>=b, V increases with b and mean decreases with b. Therefore
    the runner-up is the least favorable gap under both implemented radii.
    No future samples, hidden categories, or fitted variance estimates enter.
    """
    values, n = _counts(counts, n)
    risk = _delta(delta)
    specification = _rule(rule)
    k = len(values)
    leader, competitor = _top_two(values)
    details = {"rule": specification["name"], "candidate_count": k,
               "nominal_samples": n, "leader_index": leader,
               "competitor_index": competitor, "delta_exact": str(risk),
               "rounding": "outward_Decimal80_and_downward_final_float"}
    if k == 1:
        return {**details, "lower_gap": 1., "structural_single_candidate": True}
    if n == 0 or (specification["name"] == "empirical_bernstein" and n < 2):
        return {**details, "lower_gap": -1., "insufficient_samples": True}
    a, b = values[leader], values[competitor]
    pair_count = k * (k - 1) // 2
    mean = Fraction(a - b, n)
    upper, lower = _contexts()
    if specification["name"] == "normal_mixture":
        rho = _fraction(specification.get("rho", 64.), "rho")
        if rho <= 0:
            raise ValueError("rho must be positive")
        alpha = risk / pair_count
        logarithm = _log_up((n + rho) / (rho * alpha * alpha), upper)
        square = upper.multiply(_decimal(n + rho, upper), logarithm)
        radius = upper.divide(upper.next_plus(upper.sqrt(square)), Decimal(n))
        details.update({"alpha_per_unordered_pair_exact": str(alpha),
                        "time_protection": "anytime_normal_mixture", "rho_exact": str(rho)})
    else:
        checkpoints = tuple(specification.get("checkpoints", DEFAULT_CHECKPOINTS))
        if (not checkpoints or any(type(value) is not int or value < 2 for value in checkpoints)
                or checkpoints != tuple(sorted(set(checkpoints)))):
            raise ValueError("checkpoints must be a fixed increasing sequence of integers >=2")
        if n not in checkpoints:
            raise ValueError("n is not a protected empirical-Bernstein checkpoint")
        alpha = risk / (2 * pair_count * len(checkpoints))
        logarithm = _log_up(2 / alpha, upper)
        variance = Fraction((a + b) * n - (a - b) ** 2, n * (n - 1))
        if variance < 0:
            raise AssertionError("negative exact sample variance")
        square = upper.divide(upper.multiply(upper.multiply(Decimal(2),
                                                              _decimal(variance, upper)), logarithm), Decimal(n))
        first = upper.next_plus(upper.sqrt(square))
        second = upper.divide(upper.multiply(Decimal(14), logarithm), Decimal(3 * (n - 1)))
        radius = upper.add(first, second)
        details.update({"alpha_per_direction_and_checkpoint_exact": str(alpha),
                        "sample_variance_exact": str(variance),
                        "protected_checkpoints": list(checkpoints),
                        "time_protection": "union_over_fixed_checkpoints_only",
                        "source": "Maurer_Pontil_2009_Theorem4_rescaled_range2"})
    gap = lower.subtract(_decimal(mean, lower), radius)
    return {**details, "lower_gap": _float_down(gap)}


def numerical_gap_bound(counts, n, delta, rule="normal_mixture") -> float:
    """Return the protected numerical lower gap; freeze EB checks in advance."""
    return numerical_gap_details(counts, n, delta, rule)["lower_gap"]
