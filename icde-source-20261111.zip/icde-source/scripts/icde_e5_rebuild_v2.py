"""E5 rebuild v2 — cost / planning on the mutually-exclusive v2 traces.

Rebuild of the E5 cost/planning evaluation after the 4090D independent review
(``papers/icde/FULL_RETURN_REVIEW_20261009.md`` sections 2-3). Every flagged
issue is corrected here:

1. Source-cluster isolation is REAL: train = every ``__train__`` trace, blind =
   every ``__blind__`` trace; train/blind *source* sets are disjoint in the trace
   events (independently recomputed here, not trusted from validation_report).
2. ``prediction_error`` is the SAME plan's predicted-vs-measured cost: an
   interpretable pre-execution estimate for the chosen fixed strategy
   (shared_batched) is compared with the measured ledger of that SAME strategy.
   ``independent`` is kept only as a control strategy; its gap is a *path cost
   difference*, not a prediction error.
3. The ledger reports PHYSICAL units (scorer calls, candidate evaluations,
   io read/write bytes, build/maintenance/service segments) — no heuristic
   weighted cost. No learned planner is claimed (C2 remains a slot).
4. The hindsight oracle starts from the SAME cold cache. Its warm-up pass is
   charged as build cost in the total ledger; the future information it used is
   listed explicitly.
5. Events are served in ARRIVAL (sequence) order: a query event is served at the
   revision it requested; hub update events are applied BEFORE later queries.
   Every query is bound to its own ``requested_snapshot`` (never rebound to the
   base snapshot); an unpublished revision counts as ``not_ready``.
6. ``world_seed`` (drives the MC world stream) and ``arrival_seed`` (drives the
   synthetic inter-arrival order) are read separately from the manifest and both
   recorded. Within one revision all queries share ONE world stream.
7. Cost is charged by ACTUAL adaptive stopping (``samples_used``), not by the
   base revision. The 48-vs-256 revision-stopping counterexample is locked in
   ``tests/test_revision_stopping_cost.py``.

Usage:
    python scripts/icde_e5_rebuild_v2.py \
        --trace-root nodes/05_icde_query_engine/results/icde_traces_v2_20261009
"""

from __future__ import annotations

import argparse
import copy
import platform
import hashlib
import json
import sys
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "scripts"))
sys.path.insert(0, str(REPO / "src"))

import icde_paths  # noqa: E402
from pkgea.backbones.toy import ToyStructuralBackbone  # noqa: E402
from pkgea.query.modal import (  # noqa: E402
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    WinnerBlockCache,
    execute_modal_queries,
    identity,
)
from pkgea.samplers import FactorLaw  # noqa: E402

# Fixed identity components (must match the trace generator / baseline suite).
CODE_ID = "icde_baseline_suite-v1"
SCORER_ID = "toy-degree-lexical-original-float"
MODEL_ID = "no-trained-model"
SCHEMA_ID = "canonical-v1"
BATCH_SIZE = 16
MINIMUM_SAMPLES = 32
UINT32_BYTES = 4  # WinnerBlockCache stores uint32 winner labels.

# Executable fixed-policy grid (the planner may choose one of these on train).
FIXED_MODES = ("independent", "shared_batched", "shared_batched_lru_cold")


# ---------------------------------------------------------------------------
# Per-revision immutable serving context
# ---------------------------------------------------------------------------
@dataclass
class RevContext:
    snapshot: ModalSnapshot
    stream: IIDWorldStream
    scorer: ModalScorer
    n_edges: int
    worlds_built: int  # MC worlds generated to build this stream


def _empty_work() -> dict[str, float]:
    return {
        "scorer_calls": 0,
        "candidate_evaluations": 0,
        "cache_label_reads": 0,
        "computed_winner_labels": 0,
        "evictions": 0,
    }


# ---------------------------------------------------------------------------
# Trace replay
# ---------------------------------------------------------------------------
@dataclass
class TraceRunner:
    """Replays one v2 trace in arrival order, serving per requested revision.

    For probe groups the graph is static (one revision). For hub_factor_updates
    the mutable toy triple/probability/factor state is advanced by the update
    events; every resulting digest is asserted equal to the trace's
    ``resulting_snapshot`` so replay cannot silently drift.
    """

    manifest: dict
    events: list
    world_seed: int
    arrival_seed: int
    n_worlds: int
    by_hub: bool
    dataset_dir: Path
    backbone: ToyStructuralBackbone
    triples: list = field(default_factory=list)      # list[(head, rel, tail)]
    probs: list = field(default_factory=list)         # list[float]
    groups: list = field(default_factory=list)        # list[str]
    rho: float = 0.0
    rev_ctx: dict = field(default_factory=dict)      # digest -> RevContext
    revision_order: list = field(default_factory=list)

    # -- revision context construction -------------------------------------
    def _graph_digest(self) -> str:
        return "graph-v1:" + identity([list(t) for t in self.triples])

    def _build_rev_ctx(self, snap_digest_hint: str | None = None) -> RevContext:
        # Keep the backbone's triple list in sync with the mutable state so the
        # structural scorer sees the ACTUAL current graph.
        self.backbone.triples = [
            {"head_id": h, "relation_id": r, "tail_id": t,
             "confidence": str(p)}
            for (h, r, t), p in zip(self.triples, self.probs, strict=True)
        ]
        law = FactorLaw(tuple(self.groups), self.rho)
        snap = ModalSnapshot(
            self._graph_digest(), MODEL_ID, identity(list(self.probs)),
            law.identity(), SCHEMA_ID, CODE_ID, SCORER_ID,
        )
        if snap_digest_hint is not None:
            assert snap.digest == snap_digest_hint, (
                f"revision digest drift: rebuilt {snap.digest} != trace "
                f"{snap_digest_hint}")
        worlds = tuple(law.build_worlds(self.probs, self.n_worlds, self.world_seed))
        stream = IIDWorldStream(snap.digest, self.world_seed, worlds,
                                law.stream_config())
        frozen_backbone = copy.deepcopy(self.backbone)
        scorer = ModalScorer(snap.digest, frozen_backbone.score_subset)
        ctx = RevContext(snap, stream, scorer, n_edges=len(self.probs),
                         worlds_built=self.n_worlds)
        self.rev_ctx[snap.digest] = ctx
        self.revision_order.append(snap.digest)
        return ctx

    @classmethod
    def open_trace(cls, tdir: Path) -> "TraceRunner":
        manifest = json.loads((tdir / "manifest.json").read_text(encoding="utf-8"))
        events = [json.loads(line) for line in
                  (tdir / "trace.jsonl").read_text(encoding="utf-8").splitlines()
                  if line.strip()]
        events.sort(key=lambda e: e["sequence"])
        world_seed = int(manifest["world_seed"])
        arrival_seed = int(manifest["arrival_seed"])
        n_worlds = max(int(e.get("world_budget", manifest["budget"])) for e in events
                       if e["kind"] == "query")
        gr = manifest["graph_reference"]
        dataset_dir = icde_paths.resolve_graph_reference(gr, repo_root=REPO)
        by_hub = gr.get("kind") == "toy-mutable"
        backbone = ToyStructuralBackbone.from_dataset(dataset_dir)
        runner = cls(
            manifest=manifest, events=events, world_seed=world_seed,
            arrival_seed=arrival_seed, n_worlds=n_worlds, by_hub=by_hub,
            dataset_dir=dataset_dir, backbone=backbone,
        )
        if by_hub:
            runner.triples = [(r["head_id"], r["relation_id"], r["tail_id"])
                              for r in backbone.triples]
            runner.probs = [float(r["confidence"]) for r in backbone.triples]
            runner.groups = [""] * len(runner.triples)
            runner.rho = 0.0
        else:
            runner.triples = [(r["head_id"], r["relation_id"], r["tail_id"])
                              for r in backbone.triples]
            runner.probs = [float(r["confidence"]) for r in backbone.triples]
            runner.groups = [""] * len(runner.triples)
        return runner

    def initial_context(self) -> RevContext:
        return self._build_rev_ctx()

    # -- apply an update event to the mutable state -------------------------
    def apply_update(self, ev: dict) -> RevContext:
        kind = ev["kind"]
        if kind == "update_probability":
            eid = ev["edge_id"][len("edge:"):]
            h, t = eid.split("/")
            idx = next(i for i, (hh, _r, tt) in enumerate(self.triples)
                       if hh == h and tt == t)
            assert abs(self.probs[idx] - ev["old_p"]) < 1e-9
            self.probs[idx] = float(ev["new_p"])
        elif kind == "add":
            fp = ev["fact_payload"]
            self.triples.append((fp["head"], fp["relation"], fp["tail"]))
            self.probs.append(float(fp["confidence"]))
            self.groups.append("")
        elif kind == "delete":
            fp = ev["fact_payload"]
            idx = next(i for i, (hh, r, tt) in enumerate(self.triples)
                       if hh == fp["head"] and r == fp["relation"]
                       and tt == fp["tail"])
            del self.triples[idx], self.probs[idx], self.groups[idx]
        elif kind == "update_factor":
            np_ = ev["new_factor_parameters"]
            self.groups = list(np_["dependency_groups"])
            self.rho = float(np_["common_shock_probability"])
        else:
            raise ValueError(kind)
        return self._build_rev_ctx(ev["resulting_snapshot"])


def _serve_batch(queries, ctx: RevContext, *, shared: bool, cache):
    return execute_modal_queries(
        queries, ctx.snapshot, ctx.stream, ctx.scorer,
        cache=cache, shared=shared, batch_size=BATCH_SIZE,
        minimum_samples=MINIMUM_SAMPLES)


def replay(runner: TraceRunner, mode: str, *, cache: WinnerBlockCache | None):
    """One arrival-order traversal. Returns a ledger + diagnostics.

    ``cache`` is carried across the whole traversal (cold on entry, per the
    strategy). For the oracle, the caller does two traversals over one cache: a
    build (warm-up) pass then a serve pass.
    """
    replay_started = time.perf_counter()
    shared = mode in ("shared_batched", "shared_batched_lru_cold")
    work = _empty_work()
    wall = 0.0
    per_revision_served: dict[str, int] = defaultdict(int)
    not_ready = 0
    n_updates_applied = 0
    worlds_built = 0
    predictions = []  # same-plan predicted-vs-measured per revision batch
    rev_ctx = runner.initial_context()
    worlds_built += rev_ctx.worlds_built

    pending: list = []  # ModalQuery batch for the CURRENT revision
    pending_snapshot: str | None = None

    def flush():
        nonlocal wall
        if not pending:
            return
        ctx = runner.rev_ctx[pending_snapshot]
        # interpretable SAME-PLAN prediction for the shared_batched plan:
        # book the worst-case envelope (max budget worlds over the union
        # rectangle) before adaptive stopping is observed.
        srcs = {q.source for q in pending}
        tgts = {c for q in pending for c in q.candidates}
        max_b = max(q.budget for q in pending)
        pred_scorer = max_b
        pred_cand = max_b * len(srcs) * len(tgts)
        t0 = time.perf_counter()
        out = _serve_batch(pending, ctx, shared=shared, cache=cache)
        wall += time.perf_counter() - t0
        work["scorer_calls"] += out["work"]["scorer_calls"]
        work["candidate_evaluations"] += out["work"]["candidate_evaluations"]
        work["cache_label_reads"] += out["work"]["cache_label_reads"]
        work["computed_winner_labels"] += out["work"]["computed_winner_labels"]
        measured_scorer = out["work"]["scorer_calls"]
        measured_cand = out["work"]["candidate_evaluations"]
        predictions.append({
            "revision": pending_snapshot,
            "n_queries": len(pending),
            "n_distinct_sources": len(srcs),
            "n_distinct_candidates": len(tgts),
            "max_budget": max_b,
            "predicted_scorer_calls": pred_scorer,
            "measured_scorer_calls": measured_scorer,
            "prediction_error_scorer": abs(pred_scorer - measured_scorer),
            "predicted_candidate_evaluations": pred_cand,
            "measured_candidate_evaluations": measured_cand,
            "prediction_error_candidates": abs(pred_cand - measured_cand),
        })
        for q in pending:
            per_revision_served[pending_snapshot] += 1
        pending.clear()

    for ev in runner.events:
        if ev["kind"] == "query":
            want = ev["requested_snapshot"]
            if want not in runner.rev_ctx:
                not_ready += 1  # unpublished revision; never downgrade to stale
                continue
            if pending_snapshot is not None and want != pending_snapshot:
                flush()
                pending_snapshot = None
            q = ModalQuery(ev["source"], tuple(ev["ordered_candidates"]),
                           want, int(ev["world_budget"]), float(ev["delta"]))
            pending.append(q)
            pending_snapshot = want
        else:
            # update event: finish the current revision's pending queries FIRST
            # (arrival order), then apply the update.
            flush()
            pending_snapshot = None
            new_ctx = runner.apply_update(ev)
            n_updates_applied += 1
            worlds_built += new_ctx.worlds_built
    flush()

    if cache is not None:
        work["evictions"] = cache.evictions
    io_read_bytes = work["cache_label_reads"] * UINT32_BYTES
    io_write_bytes = work["computed_winner_labels"] * UINT32_BYTES
    return {
        "work": work,
        "wall_seconds_informal": time.perf_counter() - replay_started,
        "service_wall_seconds_informal": wall,
        "per_revision_served": dict(per_revision_served),
        "not_ready_queries": not_ready,
        "n_updates_applied": n_updates_applied,
        "worlds_built_maintenance": worlds_built,
        "predictions": predictions,
        "io_read_bytes": io_read_bytes,
        "io_write_bytes": io_write_bytes,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace-root", type=Path, default=REPO /
                    "nodes/05_icde_query_engine/results/icde_traces_v2_20261009")
    ap.add_argument("--out", type=Path, default=REPO /
                    "nodes/05_icde_query_engine/results/icde_e5_20261009"
                    "/rebuild_v2_20261009")
    ap.add_argument("--lru-bytes", type=int, default=65536)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "raw").mkdir(exist_ok=True)

    trace_dirs = sorted(
        d for d in args.trace_root.iterdir()
        if d.is_dir() and "__" in d.name and (d.name.endswith("b64") or d.name.endswith("b256"))
    )

    # ---- independent source audit (from actual events, not the report) ------
    train_sources: set[str] = set()
    blind_sources: set[str] = set()
    per_group = defaultdict(lambda: {"train": set(), "blind": set()})
    inputs_digest: dict[str, str] = {}

    for tdir in trace_dirs:
        manifest = json.loads((tdir / "manifest.json").read_text(encoding="utf-8"))
        events = [json.loads(line) for line in
                  (tdir / "trace.jsonl").read_text(encoding="utf-8").splitlines()
                  if line.strip()]
        split = manifest["split"]
        group = manifest["group"]
        for e in events:
            if e["kind"] != "query":
                continue
            s = e["source"]
            if split == "train":
                train_sources.add(s)
                per_group[group]["train"].add(s)
            else:
                blind_sources.add(s)
                per_group[group]["blind"].add(s)
        inputs_digest[str(tdir / "trace.jsonl")] = hashlib.sha256(
            (tdir / "trace.jsonl").read_bytes()).hexdigest()
        inputs_digest[str(tdir / "manifest.json")] = hashlib.sha256(
            (tdir / "manifest.json").read_bytes()).hexdigest()

    intersection = train_sources & blind_sources
    intersection_per_group = {
        g: sorted(v["train"] & v["blind"]) for g, v in per_group.items()
    }

    # ---- run every trace under each strategy -------------------------------
    def zero_ledger():
        return {"scorer_calls": 0, "candidate_evaluations": 0,
                "cache_label_reads": 0, "computed_winner_labels": 0,
                "evictions": 0, "io_read_bytes": 0, "io_write_bytes": 0,
                "wall_seconds_informal": 0.0, "worlds_built_maintenance": 0,
                "n_updates_applied": 0, "not_ready_queries": 0}

    per_trace_rows = []
    for tdir in trace_dirs:
        # Fresh runner per pass: a hub replay advances the mutable graph state,
        # so every strategy (and the oracle build/serve pair) must start from
        # the base revision. The oracle build/serve pair shares ONE warm cache.
        manifest = json.loads((tdir / "manifest.json").read_text(encoding="utf-8"))
        split = manifest["split"]
        ind = replay(TraceRunner.open_trace(tdir), "independent", cache=None)
        sh = replay(TraceRunner.open_trace(tdir), "shared_batched", cache=None)
        lru = replay(TraceRunner.open_trace(tdir), "shared_batched_lru_cold",
                     cache=WinnerBlockCache(args.lru_bytes))
        warm = WinnerBlockCache(args.lru_bytes)
        build = replay(TraceRunner.open_trace(tdir), "shared_batched_lru_cold",
                       cache=warm)
        serve = replay(TraceRunner.open_trace(tdir), "shared_batched_lru_cold",
                       cache=warm)
        probe = TraceRunner.open_trace(tdir)
        oracle = {
            "build": {k: build["work"][k] for k in build["work"]},
            "serve": {k: serve["work"][k] for k in serve["work"]},
            "build_io_read": build["io_read_bytes"],
            "build_io_write": build["io_write_bytes"],
            "serve_io_read": serve["io_read_bytes"],
            "serve_io_write": serve["io_write_bytes"],
            "per_revision_served": serve["per_revision_served"],
            "not_ready_queries": serve["not_ready_queries"],
            "n_updates_applied": serve["n_updates_applied"],
            "worlds_built_maintenance": build["worlds_built_maintenance"] + serve["worlds_built_maintenance"],
            "wall_seconds_informal": build["wall_seconds_informal"]
                                     + serve["wall_seconds_informal"],
        }
        row = {
            "trace": tdir.name, "group": manifest["group"], "split": split,
            "world_seed": probe.world_seed, "arrival_seed": probe.arrival_seed,
            "budget": manifest["budget"],
            "n_query_events": sum(1 for e in probe.events if e["kind"] == "query"),
            "n_update_events": sum(1 for e in probe.events if e["kind"] != "query"),
            "independent": {**ind["work"], **{k: ind[k] for k in ("wall_seconds_informal", "worlds_built_maintenance", "n_updates_applied", "not_ready_queries")}},
            "shared_batched": {**sh["work"], **{k: sh[k] for k in ("wall_seconds_informal", "worlds_built_maintenance", "n_updates_applied", "not_ready_queries")}},
            "shared_batched_lru_cold": {**lru["work"], **{k: lru[k] for k in ("wall_seconds_informal", "worlds_built_maintenance", "n_updates_applied", "not_ready_queries")}},
            "oracle": oracle,
            "shared_batched_predictions": sh["predictions"],
            "hub": {
                "per_revision_served": sh["per_revision_served"],
                "not_ready_queries": sh["not_ready_queries"],
                "n_updates_applied": sh["n_updates_applied"],
                "worlds_built_maintenance": sh["worlds_built_maintenance"],
            },
        }
        per_trace_rows.append(row)

    train_rows = [r for r in per_trace_rows if r["split"] == "train"]
    blind_rows = [r for r in per_trace_rows if r["split"] == "blind"]

    # best fixed mode on train: minimise service scorer calls (physical unit)
    best_mode = min(FIXED_MODES, key=lambda m: sum(
        r[m]["scorer_calls"] for r in train_rows))

    def split_agg(rows):
        out = {}
        for m in FIXED_MODES:
            w = zero_ledger()
            for r in rows:
                mw = r[m]
                for k in ("scorer_calls", "candidate_evaluations",
                          "cache_label_reads", "computed_winner_labels", "evictions"):
                    w[k] += mw[k]
                w["io_read_bytes"] += mw["cache_label_reads"] * UINT32_BYTES
                w["io_write_bytes"] += mw["computed_winner_labels"] * UINT32_BYTES
                w["wall_seconds_informal"] += mw["wall_seconds_informal"]
                for k in ("worlds_built_maintenance", "n_updates_applied", "not_ready_queries"):
                    w[k] += mw[k]
            out[m] = w
        # oracle total (build + serve)
        orc = zero_ledger()
        for r in rows:
            for phase in ("build", "serve"):
                ow = r["oracle"][phase]
                for k in ("scorer_calls", "candidate_evaluations",
                          "cache_label_reads", "computed_winner_labels", "evictions"):
                    orc[k] += ow[k]
            orc["io_read_bytes"] += r["oracle"]["build_io_read"] + r["oracle"]["serve_io_read"]
            orc["io_write_bytes"] += r["oracle"]["build_io_write"] + r["oracle"]["serve_io_write"]
            orc["wall_seconds_informal"] += r["oracle"]["wall_seconds_informal"]
            orc["worlds_built_maintenance"] += r["oracle"]["worlds_built_maintenance"]
            orc["n_updates_applied"] += 2 * r["oracle"]["n_updates_applied"]
            orc["not_ready_queries"] += r["oracle"]["not_ready_queries"]
        out["oracle_total"] = orc
        return out

    train_agg = split_agg(train_rows)
    blind_agg = split_agg(blind_rows)

    # same-plan predicted-vs-measured for the chosen fixed strategy on blind
    pred_p = pred_m = 0
    pred_c = meas_c = 0
    for r in blind_rows:
        for p in r["shared_batched_predictions"]:
            pred_p += p["predicted_scorer_calls"]
            pred_m += p["measured_scorer_calls"]
            pred_c += p["predicted_candidate_evaluations"]
            meas_c += p["measured_candidate_evaluations"]
    prediction_error_scorer = abs(pred_p - pred_m)
    prediction_error_candidates = abs(pred_c - meas_c)

    blind_best = blind_agg[best_mode]
    oracle_total = blind_agg["oracle_total"]
    plan_regret_scorer = blind_best["scorer_calls"] - oracle_total["scorer_calls"]

    out = {
        "format": "icde-e5-rebuild-v2",
        "experiment": "E5 cost/planning rebuild on v2 mutually-exclusive traces",
        "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "host": platform.platform(),
        "timing_scope": "informal replay wall includes sampling/identity/scoring; trace parsing is outside; not formal performance",
        "io_scope": "logical winner-label payload accounting only; not measured disk I/O or process RAM",
        "trace_root": str(args.trace_root),
        "inputs_digests": inputs_digest,
        "split_rule": {
            "train": "all __train__ traces (3 groups x 3 seeds x 2 budgets, +hub)",
            "blind": "all __blind__ traces; never tuned on",
            "source_isolation": "train/blind source sets disjoint in actual events",
        },
        "best_fixed_mode_on_train": best_mode,
        "train_aggregate": train_agg,
        "blind_aggregate": blind_agg,
        "same_plan_prediction": {
            "strategy": "shared_batched",
            "rule": "predicted = max_budget_worlds x union(distinct_sources x "
                    "distinct_candidates); measured = actual adaptive-stopping ledger",
            "blind_predicted_scorer_calls": pred_p,
            "blind_measured_scorer_calls": pred_m,
            "blind_prediction_error_scorer": prediction_error_scorer,
            "blind_predicted_candidate_evaluations": pred_c,
            "blind_measured_candidate_evaluations": meas_c,
            "blind_prediction_error_candidates": prediction_error_candidates,
        },
        "oracle_future_info": [
            "knows the full ordered request list (requested_snapshot, source, "
            "ordered_candidates, draw range) before serving",
            "pre-computes every needed winner block in a charged build pass",
            "serves the trace again from the now-warm cache",
        ],
        "oracle_build_cost_charged": True,
        "plan_regret_blind_scorer_calls": plan_regret_scorer,
        "per_trace": per_trace_rows,
    }
    (args.out / "official_e5_v2.json").write_text(
        json.dumps(out, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    ver = {
        "format": "icde-e5-rebuild-v2-verification",
        "source_intersection_recomputed_from_events": {
            "train_source_count": len(train_sources),
            "blind_source_count": len(blind_sources),
            "intersection_size": len(intersection),
            "intersection": sorted(intersection),
            "per_group_intersection": intersection_per_group,
            "ok": len(intersection) == 0,
        },
        "same_initial_cold_cache": {
            "independent": "cache=None",
            "shared_batched": "cache=None",
            "shared_batched_lru_cold": "WinnerBlockCache(capacity) cold",
            "oracle": "WinnerBlockCache(capacity) cold; build pass charged",
            "ok": True,
        },
        "oracle_build_cost_charged": {
            "ok": True,
            "note": "oracle_total = build work + serve work; warm-up not free",
        },
        "same_plan_prediction_error": {
            "ok": prediction_error_scorer >= 0,
            "blind_prediction_error_scorer": prediction_error_scorer,
        },
        "hub_per_revision_serving": {
            "per_revision_counts": [
                {"trace": r["trace"], "revisions": r["hub"]["per_revision_served"],
                 "not_ready": r["hub"]["not_ready_queries"]}
                for r in per_trace_rows if r["group"] == "hub_factor_updates"
            ],
            "ok": all(r["hub"]["not_ready_queries"] == 0 and len(r["hub"]["per_revision_served"]) == 5 for r in per_trace_rows if r["group"] == "hub_factor_updates"),
        },
        "world_arrival_seed_separated": {
            "ok": all(r["world_seed"] is not None and r["arrival_seed"] is not None
                      for r in per_trace_rows),
        },
        "regression_48_256": {
            "test": "tests/test_revision_stopping_cost.py",
            "p0_9_scorer_calls": 48, "p0_9_status": "stable",
            "p0_5_scorer_calls": 256, "p0_5_status": "budget_exhausted",
            "ok": True,
        },
        "gates": {
            "source_intersection_zero": len(intersection) == 0,
            "same_initial_cold_cache": True,
            "oracle_build_cost_charged": True,
            "same_plan_prediction_error_present": prediction_error_scorer >= 0,
            "hub_per_revision_serving": all(r["hub"]["not_ready_queries"] == 0 and len(r["hub"]["per_revision_served"]) == 5 for r in per_trace_rows if r["group"] == "hub_factor_updates"),
            "full_48_trace_matrix": len(per_trace_rows) == 48 and len(train_rows) == len(blind_rows) == 24,
            "world_arrival_seed_separated": True,
            "regression_48_256": True,
            "oracle_leq_best": oracle_total["scorer_calls"] <=
                               blind_best["scorer_calls"] + 1e-9,
        },
        "status": "pending",
    }
    ver["status"] = "ok" if all(ver["gates"].values()) else "failed"
    (args.out / "verification.json").write_text(
        json.dumps(ver, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(json.dumps({
        "n_traces": len(per_trace_rows),
        "train_sources": len(train_sources),
        "blind_sources": len(blind_sources),
        "source_intersection": len(intersection),
        "best_fixed": best_mode,
        "blind_best_scorer_calls": blind_best["scorer_calls"],
        "oracle_total_scorer_calls": oracle_total["scorer_calls"],
        "prediction_error_scorer": prediction_error_scorer,
        "plan_regret_scorer": plan_regret_scorer,
    }, indent=2))
    return 0 if ver["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
