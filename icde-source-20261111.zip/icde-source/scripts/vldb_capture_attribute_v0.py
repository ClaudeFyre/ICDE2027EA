"""New float64 attribute-scorer categorical captures, without EA-label scoring.

No legacy winner stream or float32 scoring kernel is reused.  Capturing all
worlds is offline work, never a measurement of early-stopping savings.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


REPO = Path(__file__).resolve().parents[1]
if str(REPO / "src") not in sys.path:
    sys.path.insert(0, str(REPO / "src"))

from pkgea.backbones.attribute import AttributeStructuralBackbone
from pkgea.contracts import dataset_revision_digest
from pkgea.query.index import StaticCandidateIndex
from pkgea.scope import build_incident_degree_certificate


SCHEMA = "vldb-categorical-stream-v1"
SALT = "vldb-v0-20261104"
CANONICAL_FILES = (
    "entities.tsv", "relations.tsv", "triples.tsv", "alignments.tsv",
    "attributes.tsv", "confidence_metadata.json",
)
DEFAULT_PROFILES = (
    {"graph": "D-W", "dataset_path":
     "data/interim/openea-d-w-probe-q500-a512-attributes-independent-s17"},
    {"graph": "EN-FR", "dataset_path":
     "data/interim/openea-en-fr-probe-q500-a512-attributes-independent-s17"},
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _inside(root: Path, value: str | Path) -> Path:
    candidate = Path(value)
    path = (candidate if candidate.is_absolute() else root / candidate).resolve()
    path.relative_to(root)
    return path


def _read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def _write_new(path: Path, value: dict[str, Any]) -> float:
    started = time.perf_counter()
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    return time.perf_counter() - started


def _positive_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return value


def select_queries(
    sources: list[str] | tuple[str, ...], count: int, salt: str = SALT
) -> tuple[str, ...]:
    """Select without labels; source-list order cannot affect the subset."""
    _positive_int(count, "query_count")
    if len(set(sources)) != len(sources) or count > len(sources):
        raise ValueError("query pool must be unique and large enough")
    return tuple(sorted(sources, key=lambda source: (
        hashlib.sha256(f"{salt}|{source}".encode("utf-8")).digest(), source,
    ))[:count])


def stream_seed(graph: str, revision: str, source: str, base_seed: int, purpose: str) -> int:
    payload = f"{SALT}|{graph}|{revision}|{source}|{base_seed}|{purpose}"
    return int.from_bytes(hashlib.sha256(payload.encode("utf-8")).digest()[:16], "big")


@dataclass(frozen=True)
class DegreeScoreKernel:
    source: str
    candidates: tuple[str, ...]
    edge_indices: tuple[int, ...]
    incidence_positions: tuple[np.ndarray, ...]
    attribute: np.ndarray
    lexical: np.ndarray
    attribute_weight: float

    def scores(self, states: np.ndarray) -> np.ndarray:
        """Exact float64 integer degrees; operation order matches the backbone."""
        states = np.asarray(states)
        if states.dtype != np.bool_ or states.ndim != 2:
            raise ValueError("states must be a two-dimensional Boolean matrix")
        if states.shape[1] != len(self.edge_indices):
            raise ValueError("state width differs from the frozen edge order")
        degrees = np.empty((states.shape[0], len(self.incidence_positions)), dtype=np.float64)
        for column, positions in enumerate(self.incidence_positions):
            degrees[:, column] = np.sum(states[:, positions], axis=1, dtype=np.float64)
        distance = (
            np.abs(degrees[:, 0, None] - degrees[:, 2::2])
            + np.abs(degrees[:, 1, None] - degrees[:, 3::2])
        )
        structural = 1.0 / (1.0 + distance)
        structural_score = 0.6 * self.lexical[None, :] + 0.4 * structural
        result = (
            self.attribute_weight * self.attribute[None, :]
            + (1.0 - self.attribute_weight) * structural_score
        )
        if not np.isfinite(result).all():
            raise ValueError("nonfinite attribute score")
        return result


def build_degree_kernel(
    backbone: AttributeStructuralBackbone,
    source: str,
    candidates: tuple[str, ...],
    edge_indices: tuple[int, ...],
) -> DegreeScoreKernel:
    if not candidates or len(set(candidates)) != len(candidates):
        raise ValueError("candidate order must be unique and nonempty")
    if tuple(sorted(set(edge_indices))) != edge_indices:
        raise ValueError("edge indices must be unique and in original row order")
    if any(index < 0 or index >= len(backbone.triples) for index in edge_indices):
        raise ValueError("invalid edge index")
    if len(backbone.triples) >= 2 ** 52:
        raise ValueError("float64 cannot guarantee exact degree-distance integers")
    entities = (source, *candidates)
    columns: dict[str, list[int]] = {}
    positions: list[list[int]] = [[] for _ in range(2 * len(entities))]
    for index, entity in enumerate(entities):
        columns.setdefault(entity, []).append(index)
    for local_index, original_index in enumerate(edge_indices):
        triple = backbone.triples[original_index]
        for entity_column in columns.get(triple["head_id"], ()):
            positions[2 * entity_column].append(local_index)
        for entity_column in columns.get(triple["tail_id"], ()):
            positions[2 * entity_column + 1].append(local_index)
    return DegreeScoreKernel(
        source, candidates, edge_indices,
        tuple(np.asarray(indices, dtype=np.intp) for indices in positions),
        np.asarray([backbone.attribute_scores[source, target] for target in candidates],
                   dtype=np.float64),
        np.asarray([backbone.structural.lexical_scores[source, target] for target in candidates],
                   dtype=np.float64),
        float(backbone.attribute_weight),
    )


def audit_coupled_scores(
    backbone: AttributeStructuralBackbone,
    local_kernel: DegreeScoreKernel,
    full_states: np.ndarray,
) -> dict[str, Any]:
    """Zero-tolerance full/local/backbone comparison, including unpruned winner."""
    started = time.perf_counter()
    full_kernel = build_degree_kernel(
        backbone, local_kernel.source, local_kernel.candidates,
        tuple(range(len(backbone.triples))),
    )
    full_kernel_build = time.perf_counter() - started
    started = time.perf_counter()
    full_scores = full_kernel.scores(full_states)
    full_seconds = time.perf_counter() - started
    started = time.perf_counter()
    local_states = full_states[:, local_kernel.edge_indices]
    local_scores = local_kernel.scores(local_states)
    local_seconds = time.perf_counter() - started
    if not np.array_equal(full_scores, local_scores):
        maximum = float(np.max(np.abs(full_scores - local_scores)))
        raise AssertionError(f"full/local score audit failed: max_abs_error={maximum!r}")
    all_targets = tuple(sorted(backbone.target_entities, key=str))
    started = time.perf_counter()
    backbone_rows = []
    full_pool_winners = []
    for state in full_states:
        scores = backbone.score_subset(
            tuple(bool(value) for value in state), (local_kernel.source,), all_targets,
        )
        backbone_rows.append([
            scores[local_kernel.source, candidate] for candidate in local_kernel.candidates
        ])
        full_pool_winners.append(max(
            all_targets, key=lambda candidate: scores[local_kernel.source, candidate]
        ))
    backbone_seconds = time.perf_counter() - started
    reference = np.asarray(backbone_rows, dtype=np.float64)
    if not np.array_equal(reference, full_scores):
        maximum = float(np.max(np.abs(reference - full_scores)))
        raise AssertionError(f"full/backbone score audit failed: max_abs_error={maximum!r}")
    winners = np.argmax(local_scores, axis=1)
    retained_winners = [local_kernel.candidates[int(index)] for index in winners]
    if retained_winners != full_pool_winners:
        raise AssertionError("pruned/full-pool lexical-tie winner audit failed")
    return {
        "status": "PASS", "worlds": len(full_states), "absolute_tolerance": 0.0,
        "relative_tolerance": 0.0, "maximum_absolute_score_error": 0.0,
        "full_local_score_equal": True, "full_backbone_score_equal": True,
        "full_pool_winner_equal": True,
        "coupled_full_state_sha256": hashlib.sha256(full_states.tobytes(order="C")).hexdigest(),
        "winner_indices": [int(index) for index in winners],
        "cost": {
            "full_kernel_build_seconds": full_kernel_build,
            "coupled_full_kernel_seconds": full_seconds,
            "coupled_local_extraction_and_kernel_seconds": local_seconds,
            "full_graph_backbone_all_target_scoring_seconds": backbone_seconds,
            "interpretation": "eight_coupled_world_diagnostic_not_paper_speedup",
        },
    }


def generate_winner_indices(
    kernel: DegreeScoreKernel,
    probabilities: np.ndarray,
    sample_count: int,
    seed: int,
    chunk_size: int,
) -> tuple[list[int], dict[str, Any]]:
    _positive_int(sample_count, "sample_count")
    _positive_int(chunk_size, "chunk_size")
    probabilities = np.asarray(probabilities, dtype=np.float64)
    if probabilities.shape != (len(kernel.edge_indices),):
        raise ValueError("local probability order differs from kernel")
    if not np.isfinite(probabilities).all() or np.any((probabilities < 0) | (probabilities > 1)):
        raise ValueError("invalid declared Bernoulli probabilities")
    rng = np.random.default_rng(seed)
    winners: list[int] = []
    sampling_seconds = scoring_seconds = 0.0
    for start in range(0, sample_count, chunk_size):
        count = min(chunk_size, sample_count - start)
        before = time.perf_counter()
        states = rng.random((count, len(probabilities)), dtype=np.float64) < probabilities
        sampling_seconds += time.perf_counter() - before
        before = time.perf_counter()
        winners.extend(int(index) for index in np.argmax(kernel.scores(states), axis=1))
        scoring_seconds += time.perf_counter() - before
    return winners, {
        "sampling_seconds": sampling_seconds, "float64_degree_scoring_seconds": scoring_seconds,
        "sampled_edge_variables": sample_count * len(probabilities),
        "candidate_score_evaluations": sample_count * len(kernel.candidates),
        "degree_incidence_reads": sample_count * sum(map(len, kernel.incidence_positions)),
        "all_worlds_generated_offline": True, "early_stopping_speedup_claim": False,
    }


def capture_attribute(config: dict, root: Path, output_dir: Path) -> dict[str, Any]:
    """Write fresh graph/seed manifests and return paths, digests and total cost."""
    started = time.perf_counter()
    root = Path(root).resolve()
    settings = config.get("capture_attribute", config)
    output_dir = _inside(root, output_dir)
    count = _positive_int(settings.get("query_count", 16), "query_count")
    expected_pool = _positive_int(settings.get("expected_query_pool", 500), "expected_query_pool")
    sample_count = _positive_int(settings.get("sample_count", 4096), "sample_count")
    chunk_size = _positive_int(settings.get("chunk_size", 256), "chunk_size")
    audit_worlds = _positive_int(settings.get("audit_worlds", 8), "audit_worlds")
    seeds = tuple(settings.get("seeds", [11, 17]))
    if not seeds or len(set(seeds)) != len(seeds) or any(
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 0 for seed in seeds
    ):
        raise ValueError("stream seeds must be unique nonnegative integers")
    required_hash_seed = settings.get("required_pythonhashseed", "0")
    if (required_hash_seed is not None
            and os.environ.get("PYTHONHASHSEED") != str(required_hash_seed)):
        raise ValueError("set PYTHONHASHSEED before launching the capture process")
    profiles = settings.get("profiles", DEFAULT_PROFILES)
    if not profiles:
        raise ValueError("at least one frozen profile is required")
    profile_specs = []
    for profile in profiles:
        graph = str(profile["graph"])
        slug = re.sub(r"[^a-z0-9]+", "_", graph.casefold()).strip("_")
        if not slug:
            raise ValueError("empty graph filename identity")
        dataset = _inside(root, profile["dataset_path"])
        profile_specs.append((profile, graph, slug, dataset))
    if len({spec[2] for spec in profile_specs}) != len(profile_specs):
        raise ValueError("graph output identities must be unique")
    targets = [output_dir / f"attribute_{slug}_s{seed}.json"
               for _, _, slug, _ in profile_specs for seed in seeds]
    if any(path.exists() for path in targets) or (output_dir / "capture_failure.json").exists():
        raise FileExistsError("capture output is already present; use a fresh output directory")
    output_dir.mkdir(parents=True, exist_ok=True)
    implementation_hashes = {
        name: file_sha256(REPO / name)
        for name in (
            "scripts/vldb_capture_attribute_v0.py", "src/pkgea/backbones/attribute.py",
            "src/pkgea/backbones/toy.py", "src/pkgea/query/index.py", "src/pkgea/scope.py",
        )
    }
    result: dict[str, Any] = {
        "status": "RUNNING", "schema_version": "vldb-attribute-capture-report-v0",
        "manifest_paths": [], "manifests_sha256": {}, "graphs": [],
        "training_executed": False, "ea_accuracy_evaluated": False,
        "legacy_winner_stream_reused": False, "early_stopping_speedup_claim": False,
    }
    current = {"stage": "input"}
    try:
        for profile, graph, slug, dataset in profile_specs:
            graph_started = time.perf_counter()
            current = {"graph": graph, "stage": "input_identity"}
            before = time.perf_counter()
            hashes = {name: file_sha256(dataset / name) for name in CANONICAL_FILES
                      if (dataset / name).is_file()}
            revision = dataset_revision_digest(dataset)
            if profile.get("expected_revision", revision) != revision:
                raise ValueError(f"input revision differs for {graph}")
            metadata = json.loads((dataset / "confidence_metadata.json").read_text("utf-8-sig"))
            if metadata.get("edge_dependence", {}).get("assumption") != "independent":
                raise ValueError("this capture supports declared independent profiles only")
            triples = _read_tsv(dataset / "triples.tsv")
            if any(row.get("dependency_group", "") for row in triples):
                raise ValueError("nonempty dependency group in declared independent profile")
            probabilities = np.asarray(
                [float(row["confidence"]) for row in triples], dtype=np.float64
            )
            if not len(triples) or not np.isfinite(probabilities).all() or np.any(
                (probabilities < 0) | (probabilities > 1)
            ):
                raise ValueError("invalid declared edge probabilities")
            query_pool = [row["source_entity_id"] for row in _read_tsv(dataset / "alignments.tsv")
                          if row["split"] == "test"]
            if len(query_pool) != expected_pool or len(set(query_pool)) != len(query_pool):
                raise ValueError("held-out source query pool differs from frozen count")
            selected_queries = select_queries(
                query_pool, count, settings.get("query_selection_salt", SALT)
            )
            input_seconds = time.perf_counter() - before
            current["stage"] = "static_backbone"
            before = time.perf_counter()
            backbone = AttributeStructuralBackbone.from_dataset(dataset)
            backbone_seconds = time.perf_counter() - before
            before = time.perf_counter()
            candidate_index = StaticCandidateIndex.from_attribute_backbone(backbone)
            index_seconds = time.perf_counter() - before
            records = []
            kernels = {}
            for source in selected_queries:
                current = {"graph": graph, "query_id": source, "stage": "scope_and_audit"}
                before = time.perf_counter()
                selection = candidate_index.select(source, 1)
                candidates = tuple(sorted(map(str, selection.candidates)))
                certificate, scoped = build_incident_degree_certificate(
                    triples, dataset_revision=revision, query_id=source, candidates=candidates,
                    scorer_id="pkgea/attribute-structural", scorer_version="1.0",
                )
                edge_indices = tuple(sorted(scoped))
                kernel = build_degree_kernel(backbone, source, candidates, edge_indices)
                kernels[source] = kernel
                scope_seconds = time.perf_counter() - before
                audit_seed = stream_seed(graph, revision, source, 0, "full_local_audit")
                before = time.perf_counter()
                full_states = np.random.default_rng(audit_seed).random(
                    (audit_worlds, len(triples)), dtype=np.float64
                ) < probabilities
                audit_sampling_seconds = time.perf_counter() - before
                audit = audit_coupled_scores(backbone, kernel, full_states)
                audit["rng_seed_hex"] = hex(audit_seed)
                audit["cost"]["coupled_full_world_sampling_seconds"] = audit_sampling_seconds
                audit["cost"]["full_world_bernoulli_draws"] = audit_worlds * len(triples)
                records.append({
                    "query_id": source, "candidate_ids": list(candidates),
                    "candidate_tie_order": "lexicographic_unicode_first",
                    "candidate_count_before_pruning": len(backbone.target_entities),
                    "candidate_pruned_count": selection.pruned,
                    "candidate_bound_kth_lower": selection.kth_lower_bound,
                    "candidate_preservation": "inherited_world_uniform_static_range_bound",
                    "scope_edge_count": len(edge_indices),
                    "scope_edge_indices": list(edge_indices),
                    "scope_certificate": certificate.as_dict(),
                    "coupled_audit": audit,
                    "scope_and_local_kernel_build_seconds": scope_seconds,
                })
            shared_build = {
                "input_identity_loading_and_selection_seconds": input_seconds,
                "static_attribute_backbone_seconds": backbone_seconds,
                "static_candidate_index_seconds": index_seconds,
                "scope_kernel_and_coupled_audit_seconds":
                    time.perf_counter() - graph_started - input_seconds
                    - backbone_seconds - index_seconds,
                "charged_once_per_graph": True,
                "static_tfidf_corpus": "all_legacy_backbone_source_and_target_entities",
                "gold_targets_used_for_accuracy": False,
            }
            graph_result = {"graph": graph, "dataset_revision": revision,
                            "shared_build_cost": shared_build, "stream_costs": []}
            for base_seed in seeds:
                query_rows = []
                stream_started = time.perf_counter()
                for record in records:
                    source = record["query_id"]
                    current = {"graph": graph, "query_id": source,
                               "seed": base_seed, "stage": "stream_capture"}
                    kernel = kernels[source]
                    seed = stream_seed(graph, revision, source, base_seed, "winner_stream")
                    winners, cost = generate_winner_indices(
                        kernel, probabilities[list(kernel.edge_indices)],
                        sample_count, seed, chunk_size,
                    )
                    query_rows.append({
                        **record, "winner_indices": winners, "stream_seed": base_seed,
                        "rng_seed_hex": hex(seed), "capture_cost": cost,
                    })
                stream_seconds = time.perf_counter() - stream_started
                verify_started = time.perf_counter()
                if dataset_revision_digest(dataset) != revision or any(
                    file_sha256(dataset / name) != expected for name, expected in hashes.items()
                ):
                    raise ValueError("input changed during capture")
                input_reverification_seconds = time.perf_counter() - verify_started
                manifest = {
                    "schema_version": SCHEMA, "graph": graph,
                    "dataset_path": dataset.relative_to(root).as_posix(),
                    "dataset_revision": revision, "input_sha256": hashes,
                    "implementation_sha256": implementation_hashes,
                    "scorer": {"id": "pkgea/attribute-structural", "version": "1.0",
                               "checkpoint_sha256": None, "attribute_weight": 0.8},
                    "world_law": {
                        "id": "independent-Bernoulli-from-exposed-confidence-vldb-v0",
                        "semantics": "declared", "dependence": "independent",
                        "probability_column": "triples.tsv:confidence",
                        "probabilities_fitted": False, "real_probability_calibration_claim": False,
                        "legacy_confidence_type_is_not_a_new_calibration_claim": True,
                        "latent_truth_file_consumed": False,
                    },
                    "full_edge_count": len(triples), "stream_seed": base_seed,
                    "sample_count_per_query": sample_count, "chunk_size": chunk_size,
                    "query_selection": {
                        "pool": "legacy_test_source_ids_only", "pool_size": expected_pool,
                        "count": count, "salt": settings.get("query_selection_salt", SALT),
                        "algorithm": "sha256(utf8(salt+'|'+source)); ascending digest,source",
                        "labels_used_for_selection": False,
                    },
                    "numeric_contract": {
                        "degree_dtype": "float64", "score_dtype": "float64",
                        "degree_kernel": "Boolean_incident_sum_to_exact_float64_integer",
                        "score_formula": "a*attribute+(1-a)*(0.6*lexical+0.4/(1+L1_degree))",
                        "legacy_float32_kernel_reused": False,
                        "numpy": np.__version__, "python": platform.python_version(),
                        "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
                        "rng": "numpy.default_rng.PCG64_derived_SHA256_128bit_seed",
                    },
                    "shared_build_cost": shared_build,
                    "stream_capture_before_serialization_seconds": stream_seconds,
                    "offline_generation_cost_is_early_stopping_latency": False,
                    "ea_accuracy_evaluated": False, "queries": query_rows,
                }
                path = output_dir / f"attribute_{slug}_s{base_seed}.json"
                serialization_seconds = _write_new(path, manifest)
                relative = path.relative_to(root).as_posix()
                result["manifest_paths"].append(relative)
                digest_started = time.perf_counter()
                result["manifests_sha256"][relative] = file_sha256(path)
                manifest_hash_seconds = time.perf_counter() - digest_started
                graph_result["stream_costs"].append({
                    "seed": base_seed, "capture_seconds": stream_seconds,
                    "serialization_seconds": serialization_seconds,
                    "input_reverification_seconds": input_reverification_seconds,
                    "manifest_hash_seconds": manifest_hash_seconds,
                    "sampled_edge_variables": sum(
                        row["capture_cost"]["sampled_edge_variables"] for row in query_rows
                    ),
                })
            graph_result["total_graph_seconds"] = time.perf_counter() - graph_started
            result["graphs"].append(graph_result)
            del backbone, candidate_index, kernels, records
        result["status"] = "ATTRIBUTE_CAPTURE_COMPLETE"
        result["total_wall_seconds"] = time.perf_counter() - started
        result["cost_summary"] = {
            "total_wall_seconds": result["total_wall_seconds"],
            "graph_costs_include_shared_build_once": True,
            "sampled_edge_variables": sum(
                stream["sampled_edge_variables"]
                for graph in result["graphs"] for stream in graph["stream_costs"]
            ),
            "capture_generated_every_world": True,
            "not_an_early_stopping_speedup_measurement": True,
        }
        return result
    except Exception as error:
        failure = {
            "status": "ATTRIBUTE_CAPTURE_STOP", "location": current,
            "exception_type": type(error).__name__, "message": str(error),
            "partial_manifest_paths": result["manifest_paths"],
            "elapsed_seconds": time.perf_counter() - started,
        }
        path = output_dir / "capture_failure.json"
        if not path.exists():
            _write_new(path, failure)
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--root", type=Path, default=REPO)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8-sig"))
    report = capture_attribute(config, args.root, args.output_dir)
    print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
