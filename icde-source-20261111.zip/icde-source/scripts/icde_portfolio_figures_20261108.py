"""Scientific figures for frozen historical solver-choice headroom."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'.runtime/icde_plot_site'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'nodes/09_vldb_query_certification/results/icde_portfolio_headroom_20261108/attempt1'


def main():
    a=json.loads((BASE/'analysis.json').read_text(encoding='utf-8'))
    out=BASE/'figures_final'
    out.mkdir(exist_ok=False)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'pdf.fonttype':42,'savefig.dpi':180})
    fig,axes=plt.subplots(2,2,figsize=(12.4,8.5))
    labels={'dense_exact':'Dense exact','partial_joint':'Partial joint',
            'partial_factor':'Partial factor','mc_eager':'MC eager'}
    colors=['#2563A6','#4C9C6C','#BD7B27','#9A659D']
    for ax,obj,title in zip(axes[0],['stable_certificate','complete_classification'],
                            ['(a) Stable-certificate delivery','(b) Complete stable / nonuniform classification']):
        rows=[r for r in a['curves'] if r['objective']==obj]
        x=[r['budget_ms'] for r in rows]
        for color,(method,label) in zip(colors,labels.items()):
            ax.plot(x,[100*r['method_successes'][method]/444 for r in rows],
                    '-o',lw=1.3,ms=3,color=color,label=label)
        ax.plot(x,[100*r['fixed_delivery'] for r in rows],'--',lw=2,color='#344054',label='Best fixed (hindsight)')
        ax.plot(x,[100*r['oracle_delivery'] for r in rows],'-D',lw=2,ms=4,color='#BD3F37',label='Query oracle (hindsight)')
        ax.set_xscale('log');ax.set_xticks(x,labels=[str(int(v)) for v in x])
        ax.set_ylim(0,104);ax.set_title(title,loc='left',fontsize=11)
        ax.set_xlabel('Delivery deadline (ms)');ax.set_ylabel('Delivered / all query-repeats (%)')
        ax.grid(alpha=.18)
        if obj=='stable_certificate':
            ax.axhline(101/148*100,color='#888888',ls=':',lw=1)
            ax.text(1.08,70.2,'Stable fraction: 101 / 148',fontsize=9,color='#666666')
            ax.legend(fontsize=8,loc='lower right',ncol=2)
    ax=axes[1,0]
    for obj,label,color in [('stable_certificate','Stable certificate','#2563A6'),
                            ('complete_classification','Complete classification','#BD3F37')]:
        base=[r for r in a['curves'] if r['objective']==obj]
        adjusted=[r for r in a['feature_adjusted_curves'] if r['objective']==obj]
        x=[r['budget_ms'] for r in base]
        gain=[100*(r['fixed_capped_loss_ms']-t['oracle_capped_loss_ms'])/r['fixed_capped_loss_ms']
              for r,t in zip(base,adjusted)]
        ax.plot(x,gain,'-o',color=color,label=label)
    ax.set_xscale('log');ax.set_xticks(x,labels=[str(int(v)) for v in x]);ax.set_ylim(0,34)
    ax.set_title('(c) Remaining capped-loss headroom after feature cost',loc='left',fontsize=11)
    ax.set_xlabel('Delivery deadline (ms)');ax.set_ylabel('Capped-loss reduction vs best fixed (%)')
    ax.grid(alpha=.18);ax.legend(fontsize=9,loc='upper left')
    ax=axes[1,1]
    methods=list(labels)
    statuses=['stable','nonuniform','unresolved','timeout']
    sc=['#4C9C6C','#2563A6','#D8AE59','#B66B69']
    left=np.zeros(4)
    for status,color in zip(statuses,sc):
        values=np.asarray([a['measured_costs'][m]['outcomes'].get(status,0) for m in methods])
        ax.barh(range(4),values,left=left,label=status.capitalize(),color=color,height=.6)
        for i,(v,l) in enumerate(zip(values,left)):
            if v>=20:ax.text(l+v/2,i,str(v),va='center',ha='center',fontsize=9,color='white')
        left+=values
    ax.set_yticks(range(4),labels=[labels[m] for m in methods]);ax.set_ylim(4,-.7)
    ax.set_xlim(0,444);ax.set_xlabel('Query-repeats (148 queries x 3 repeats)')
    ax.set_title('(d) Outcomes under 100 ms cooperative execution cap',loc='left',fontsize=11)
    ax.legend(fontsize=8,ncol=2,loc='lower right')
    fig.suptitle('Historical workload solver-choice headroom: 148 eligible queries, 1,776 runs',fontsize=14,y=.99)
    fig.text(.5,.016,'Prepared compute only. Smaller deadlines are delivery analysis, not hard-SLA executions.\n'
             'Query oracle chooses one solver per query over three repeats; no deployable routing policy is evaluated.',
             ha='center',fontsize=9,color='#444444')
    fig.tight_layout(rect=(0,.075,1,.96),h_pad=2.5,w_pad=2.2)
    for suffix in ('png','pdf'):
        fig.savefig(out/f'portfolio_headroom.{suffix}')
    plt.close(fig)
    print(out/'portfolio_headroom.png')


if __name__=='__main__':main()
