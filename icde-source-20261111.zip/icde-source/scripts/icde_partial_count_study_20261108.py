"""Frozen finite comparison of partial compilation and shared-bound controls."""
import argparse
import json
from fractions import Fraction as Q
from pathlib import Path
import time
import zipfile

import numpy as np

import icde_prospective_20261107 as old
from icde_grouped_exact_20261108 import compile_counts,solve_counts
from icde_grouped_inventory_20261108 import ROOT,load,save,sha
from icde_partial_count_20261108 import execute
from run_vldb_interval_gate_v1 import clipped_box

PARENT = ROOT / "nodes/09_vldb_query_certification/results/icde_grouped_query_20261108/prototype_attempt1"
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_partial_count_20261108/attempt1"
POLICIES = ("dense_exact","standard_mass","certificate")


def freeze(out):
    if out.exists():
        raise FileExistsError(out)
    parent = load(PARENT/"protocol.json")
    code = dict(parent["code_sha256"])
    for name in ("icde_partial_count_20261108.py","icde_partial_count_study_20261108.py","test_icde_partial_count_20261108.py"):
        code[f"scripts/{name}"] = sha(ROOT/"scripts"/name)
    inputs = dict(parent["input_sha256"])
    inputs[(PARENT/"summary.json").relative_to(ROOT).as_posix()] = sha(PARENT/"summary.json")
    save(out/"protocol.json",{
        "kind":"known_query_partial_compilation_development_gate",
        "cases":parent["cases"],"tau":.25,"nominal":.9,"state_cap":32768,"max_splits":127,
        "repeats":3,"policies":list(POLICIES),"method_order":"rotate by query index and repetition",
        "baseline":"same grouping, signed score bounds, exact probability tables, interval inference and caches; standard max-mass versus target bottleneck region selection",
        "dense_control":"same root bound, plus global count-constant proof before any probability transform",
        "joint_parameters":"maintain probability bounds for every endpoint orbit; never pick a different parameter per sample or count region",
        "timing":"prepared-query compute including grouping, root, probability matrices, bounds, inference and scheduling; scorer loading/persistence separate",
        "audit":"independent complete count oracle outside timings; not supplied to a partial solver",
        "limits":"retains complete parameter representative arrays of size S; does not remove that exponential dependence",
        "code_sha256":code,"input_sha256":inputs,"frozen_at_unix":time.time()})
    print(f"Frozen {len(parent['cases'])} queries, {len(parent['cases'])*9} runs",flush=True)


def identities(p,crc=False):
    count = 0
    for group in ("code_sha256","input_sha256"):
        for name,digest in p[group].items():
            path = ROOT/name
            if sha(path)!=digest:
                raise AssertionError(f"changed frozen identity: {name}")
            count += 1
            if crc and name.endswith(".npz"):
                with zipfile.ZipFile(path) as archive:
                    if archive.testzip() is not None:
                        raise AssertionError("prepared artifact CRC failure")
                count += 1
    return count


def preflight(out):
    p = load(out/"protocol.json")
    checks = identities(p,True)
    if (out/"summary.json").exists() or list(out.glob("*.pending")):
        raise ValueError("a new attempt is needed for existing expected outputs")
    save(out/"recovery.json",{"status":"PASS","checks":checks,
        "scope":"all consumed source/input identities and NPZ CRCs, not a whole-workspace scan"})
    print(f"Recovery PASS {checks}",flush=True)


def audit(result,compiled,exact,k):
    checks = 0
    safe = exact["uniform_winners"]
    if result["status"]=="stable" and result["winner"] not in safe:
        raise AssertionError("incorrect robust certificate")
    if result["status"]=="nonuniform" and safe:
        raise AssertionError("incorrect nonuniform proof")
    checks += 2
    if result["kind"]=="partial_count_regions":
        coverage = np.zeros(compiled["shape"],dtype=np.int16)
        for leaf in result["leaf_records"]:
            ranges = tuple(slice(a,b+1) for a,b in zip(leaf["low"],leaf["high"]))
            coverage[ranges] += 1
            for winner in compiled["winners"][ranges].flat:
                if not leaf["mask"] & (1 << int(winner)):
                    raise AssertionError("region bound eliminated an attainable winner")
                checks += 1
        if not np.all(coverage==1):
            raise AssertionError("count regions overlap or fail to cover the whole count space")
        checks += 1
        if result["status"]=="nonuniform" and set(w["candidate"] for w in result["witnesses"])!=set(range(k)):
            raise AssertionError("nonuniform proof lacks a witness for every candidate")
        den = int(result["denominator_exact"])
        if den!=exact["denominator"]:
            raise AssertionError("parameter denominator differs from exact reference")
        for proof in result["witnesses"]:
            t = tuple(proof["high_endpoint_counts"])
            true = int(exact["numerators"][proof["candidate"]][t])-int(exact["numerators"][proof["competitor"]][t])
            upper = int(proof["upper_gap_numerator"])
            if not true <= upper <= 0:
                raise AssertionError("a claimed parameter witness is invalid")
            checks += 1
    return checks


def run(out):
    p = load(out/"protocol.json")
    if load(out/"recovery.json")["status"]!="PASS":
        raise AssertionError("recovery audit required")
    checked = identities(p)
    reference_rows,rows = [],[]
    started = time.perf_counter()
    for index,case in enumerate(p["cases"]):
        before = time.perf_counter()
        kernel,meta = old.read_query(case["graph"],case["rank"])
        loading = time.perf_counter()-before
        m,k = case["scope_edges"],case["candidates"]
        low,high = clipped_box(np.full(m,p["nominal"]),p["tau"])
        before = time.perf_counter()
        compiled = compile_counts(kernel,low,high,p["state_cap"])
        exact = solve_counts(compiled,k)
        reference_rows.append({**case,"uniform_winners":exact["uniform_winners"],
                               "outside_timing_reference_seconds":time.perf_counter()-before})
        decisions = {}
        for repeat in range(p["repeats"]):
            offset = (index+repeat)%len(POLICIES)
            for policy in POLICIES[offset:]+POLICIES[:offset]:
                result = execute(kernel,low,high,policy,p)
                if result["splits"]>p["max_splits"]:
                    raise AssertionError("node budget exceeded")
                checked += audit(result,compiled,exact,k)
                decision = result["status"],result["winner"],result["splits"],result["point_score_states"]
                if policy in decisions and decisions[policy]!=decision:
                    raise AssertionError("deterministic policy changed across timing repeats")
                decisions[policy] = decision
                row = {**case,"policy":policy,"repeat":repeat,
                       "prepared_query_load_seconds":loading,**result}
                filename = out/"cases"/f"{case['graph']}_q{case['rank']:03d}_{policy}_r{repeat}.json"
                save(filename,row)
                rows.append({k:v for k,v in row.items() if k not in ("trace","leaf_records","witnesses")})
        print(f"completed {index+1}/{len(p['cases'])} {case['graph']} q{case['rank']:03d}: {decisions}",flush=True)
    checked += identities(p)
    save(out/"summary.json",{"status":"PASS","checks":checked,"rows":rows,"references":reference_rows,
        "protocol_sha256":sha(out/"protocol.json"),"elapsed_seconds":time.perf_counter()-started,
        "historical_inputs_unchanged":True,
        "limitations":["known development queries only","same degree scorer and independent equal-endpoint retention",
            "complete parameter arrays remain allocated","no full reproduction of SPROUT or credal-circuit systems",
            "standard best-first scheduling is not claimed as novel","warm prepared compute, no raw-data cold service claim"]})
    print(json.dumps({"status":"PASS","runs":len(rows),"checks":checked},ensure_ascii=False),flush=True)


if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase",choices=("freeze","preflight","run"),required=True)
    parser.add_argument("--output",type=Path,default=BASE)
    args = parser.parse_args()
    {"freeze":freeze,"preflight":preflight,"run":run}[args.phase](args.output.resolve())
