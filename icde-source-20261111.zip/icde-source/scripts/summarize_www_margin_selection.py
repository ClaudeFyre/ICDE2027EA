"""Validate and summarize preregistered WWW margin-aware experiment stages."""

from __future__ import annotations

import argparse
import json
import math
import tempfile
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "nodes/04_www_distributional/results/margin_selection"
CELLS = (
    ("dw", "relation", "independent"),
    ("enfr", "relation", "structural"),
    ("dw", "gcn", "structural"),
    ("enfr", "gcn", "independent"),
    ("enfr", "relation", "independent"),
    ("dw", "gcn", "independent"),
    ("enfr", "gcn", "structural"),
    ("dw", "relation", "structural"),
)
SEEDS = {"a": (59, 71), "b": (83, 97, 103)}


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temporary, path)
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def wilson(successes: int, total: int, z: float = 1.959963984540054) -> list[float]:
    if not 0 <= successes <= total or total <= 0:
        raise ValueError("invalid binomial count")
    p = successes / total
    denominator = 1.0 + z * z / total
    center = (p + z * z / (2.0 * total)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / total + z * z / (4.0 * total**2)) / denominator
    return [max(0.0, center - half), min(1.0, center + half)]


def path_for(stage: str, cell: tuple[str, str, str]) -> Path:
    return RESULTS / f"stage_{stage}" / f"www_margin_{'_'.join(cell)}_v1.json"


def slack_relation(current: dict, margin: dict) -> str:
    current_slack = current["slack_diagnostics"]
    margin_slack = margin["slack_diagnostics"]
    current_flips = int(current_slack["authoritative_flipped_source_count"])
    margin_flips = int(margin_slack["authoritative_flipped_source_count"])
    if margin_flips != current_flips:
        return "improved" if margin_flips < current_flips else "worsened"
    tolerance = max(
        float(current_slack["tau_slack"]), float(margin_slack["tau_slack"])
    )
    difference = (
        float(margin_slack["minimum_slack_summary"]["min"])
        - float(current_slack["minimum_slack_summary"]["min"])
    )
    if difference > tolerance:
        return "improved"
    if difference < -tolerance:
        return "worsened"
    return "unchanged"


def robustness_label(margin_authorized: int, total: int = 40) -> str:
    """Apply the frozen Stage-B wording threshold from the specification."""

    if total != 40 or not 0 <= margin_authorized <= total:
        raise ValueError("Stage-B robustness contract requires 40 units")
    if margin_authorized == 40:
        return "robust_all_tested_units"
    if margin_authorized >= 38:
        return "mostly_robust_name_failed_units"
    return "stage_a_16of16_contains_seed_luck"


def combined_summary() -> dict[str, object]:
    """Combine the preregistered two- and three-seed stages.

    Forty units for the frozen eight cells; the counts follow the active cell
    set so an added graph is summarized by this same code rather than a fork.
    """

    stage_values = {}
    for stage in ("a", "b"):
        count = len(CELLS) * len(SEEDS[stage])
        path = RESULTS / f"stage_{stage}" / "summary_v1.json"
        if not path.is_file():
            raise FileNotFoundError(path)
        value = json.loads(path.read_text(encoding="utf-8"))
        assert value["schema_version"] == "pkgea-www-margin-summary-v1"
        assert value["stage"] == stage
        assert value["cell_seed_count"] == count
        stage_values[stage] = value
    rows = [*stage_values["a"]["rows"], *stage_values["b"]["rows"]]
    total = len(CELLS) * (len(SEEDS["a"]) + len(SEEDS["b"]))
    assert len(rows) == total
    assert len({(tuple(row["cell"]), row["seed"]) for row in rows}) == total
    assert {row["seed"] for row in rows} == {59, 71, 83, 97, 103}

    lambda_checks = []
    for cell in CELLS:
        cell_rows = [row for row in rows if tuple(row["cell"]) == cell]
        assert len(cell_rows) == len(SEEDS["a"]) + len(SEEDS["b"])
        stage_a_lambda = {row["lambda"] for row in cell_rows if row["seed"] in SEEDS["a"]}
        stage_b_lambda = {row["lambda"] for row in cell_rows if row["seed"] in SEEDS["b"]}
        assert len(stage_a_lambda) == len(stage_b_lambda) == 1
        old = float(next(iter(stage_a_lambda)))
        new = float(next(iter(stage_b_lambda)))
        change = abs(new - old) / max(abs(old), 1e-15)
        family = cell[1]
        expected_side = old < 0.25 if family == "gcn" else old >= 0.25
        observed_side = new < 0.25 if family == "gcn" else new >= 0.25
        lambda_checks.append(
            {
                "cell": list(cell),
                "encoder_family": family,
                "stage_a_lambda": old,
                "stage_b_lambda": new,
                "relative_change": change,
                "within_one_percent": change <= 0.01,
                "family_separation_preserved": expected_side and observed_side,
            }
        )

    margin_authorized = sum(row["margin_passes"] for row in rows)
    seeds_per_cell = len(SEEDS["a"]) + len(SEEDS["b"])
    by_cell = []
    for cell in CELLS:
        cell_rows = [row for row in rows if tuple(row["cell"]) == cell]
        current = sum(row["current_passes"] for row in cell_rows)
        margin = sum(row["margin_passes"] for row in cell_rows)
        diagonal = sum(row["diagonal_passes"] for row in cell_rows)
        by_cell.append(
            {
                "cell": list(cell),
                "seed_count": seeds_per_cell,
                "current_authorized": current,
                "margin_authorized": margin,
                "diagonal_authorized": diagonal,
                "current_wilson_95": wilson(current, seeds_per_cell),
                "margin_wilson_95": wilson(margin, seeds_per_cell),
            }
        )
    failures = [
        {"cell": row["cell"], "seed": row["seed"]}
        for row in rows
        if not row["margin_passes"]
    ]
    return {
        "schema_version": "pkgea-www-margin-combined-summary-v1",
        "stages": ["a", "b"],
        "authorization_seeds": [59, 71, 83, 97, 103],
        "cell_seed_count": total,
        "robustness_label": robustness_label(margin_authorized),
        "permitted_paper_wording": (
            "authorized on all tested units"
            if margin_authorized == 40
            else "report the observed proportion and name every failed unit"
            if margin_authorized >= 38
            else "Stage A 16/16 was an n=2 observation with seed luck"
        ),
        "current_authorized": sum(row["current_passes"] for row in rows),
        "margin_authorized": margin_authorized,
        "diagonal_authorized": sum(row["diagonal_passes"] for row in rows),
        "margin_failed_units": failures,
        "storage_neutrality_all_pass": all(
            row["storage_neutrality_passes"] for row in rows
        ),
        "maximum_storage_relative_deviation": max(
            row["storage_relative_deviation"] for row in rows
        ),
        "lambda_maximum_relative_change": max(
            row["relative_change"] for row in lambda_checks
        ),
        "lambda_all_within_one_percent": all(
            row["within_one_percent"] for row in lambda_checks
        ),
        "lambda_family_separation_preserved": all(
            row["family_separation_preserved"] for row in lambda_checks
        ),
        "lambda_checks": lambda_checks,
        "by_cell": by_cell,
        "rows": rows,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("a", "b", "combined"), required=True)
    parser.add_argument(
        "--results-root",
        type=Path,
        help="results directory holding stage_a/stage_b (default: the frozen matrix)",
    )
    parser.add_argument(
        "--cells",
        nargs="+",
        metavar="GRAPH/FAMILY/DEPENDENCE",
        help="cell set to summarize (default: the frozen eight cells, in order)",
    )
    args = parser.parse_args()
    if args.results_root is not None:
        globals()["RESULTS"] = (
            args.results_root
            if args.results_root.is_absolute()
            else ROOT / args.results_root
        )
    if args.cells is not None:
        globals()["CELLS"] = tuple(tuple(cell.split("/")) for cell in args.cells)
    if args.stage == "combined":
        summary = combined_summary()
        output = RESULTS / "combined_summary_v1.json"
        atomic_json(output, summary)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0
    expected_seeds = SEEDS[args.stage]
    rows = []
    for cell in CELLS:
        path = path_for(args.stage, cell)
        if not path.is_file():
            raise FileNotFoundError(path)
        value = json.loads(path.read_text(encoding="utf-8"))
        protocol = value["protocol"]
        assert protocol["margin_aware_experiment"] is True
        assert protocol["selection_seed"] == 17
        assert tuple(protocol["test_seeds"]) == expected_seeds
        assert protocol["reference_seed"] == 1017
        assert protocol["gate_budget"] == 2048
        assert protocol["reference_samples"] == 4096
        gates = value["validation"]["held_out_gate_checks"]
        assert len(gates) == len(expected_seeds)
        selection = value["profiles"][0]["rank_gate"]["margin_aware_selection"]
        assert selection["selection_data_contract"] == (
            "selection_seed_only_no_test_stream_input"
        )
        for gate in gates:
            current = gate["entity_adaptive_rank_gate"]
            margin = gate["margin_aware_rank_gate"]
            diagonal = gate["diagonal_only_gate"]
            rows.append(
                {
                    "cell": list(cell),
                    "seed": int(gate["seed"]),
                    "current_passes": bool(current["passes"]),
                    "margin_passes": bool(margin["passes"]),
                    "diagonal_passes": bool(diagonal["passes"]),
                    "current_winner_agreement": current.get("winner_agreement"),
                    "margin_winner_agreement": margin.get("winner_agreement"),
                    "diagonal_winner_agreement": diagonal["winner_agreement"],
                    "current_distance_error": current.get(
                        "mean_relative_distance_error"
                    ),
                    "margin_distance_error": margin.get(
                        "mean_relative_distance_error"
                    ),
                    "diagonal_distance_error": diagonal[
                        "mean_relative_distance_error"
                    ],
                    "storage_neutrality_passes": bool(
                        margin["storage_neutrality_passes"]
                    ),
                    "storage_relative_deviation": float(
                        margin["storage_relative_deviation"]
                    ),
                    "lambda": float(selection["lambda"]),
                    "strict_quarter_certificate": bool(
                        selection[
                            "strict_quarter_certificate_on_selection_stream"
                        ]
                    ),
                    "slack_relation_when_current_fails": (
                        slack_relation(current, margin)
                        if not current["passes"] and not margin["selection_paused"]
                        else None
                    ),
                }
            )
    expected_count = len(CELLS) * len(expected_seeds)
    assert len(rows) == expected_count
    neutrality = all(row["storage_neutrality_passes"] for row in rows)
    conversions = [
        row for row in rows
        if not row["current_passes"] and row["margin_passes"]
    ]
    failed_relations = [
        row["slack_relation_when_current_fails"]
        for row in rows
        if row["slack_relation_when_current_fails"] is not None
    ]
    if not neutrality:
        branch = 3
        branch_label = "storage_neutrality_failure_invalidates_conversion"
    elif conversions:
        branch = 1
        branch_label = "equal_storage_converts_at_least_one_failure"
    elif "improved" in failed_relations and "worsened" not in failed_relations:
        branch = 2
        branch_label = "zero_conversion_but_failure_slack_improves"
    else:
        branch = 3
        branch_label = "zero_conversion_without_unambiguous_slack_improvement"
    run_stage_b = bool(neutrality and branch in (1, 2))
    by_cell = []
    for cell in CELLS:
        cell_rows = [row for row in rows if tuple(row["cell"]) == cell]
        by_cell.append(
            {
                "cell": list(cell),
                "current_authorized": sum(row["current_passes"] for row in cell_rows),
                "margin_authorized": sum(row["margin_passes"] for row in cell_rows),
                "diagonal_authorized": sum(row["diagonal_passes"] for row in cell_rows),
                "seed_count": len(cell_rows),
                "current_wilson_95": wilson(
                    sum(row["current_passes"] for row in cell_rows), len(cell_rows)
                ),
                "margin_wilson_95": wilson(
                    sum(row["margin_passes"] for row in cell_rows), len(cell_rows)
                ),
            }
        )
    summary = {
        "schema_version": "pkgea-www-margin-summary-v1",
        "stage": args.stage,
        "predeclared_branch": branch,
        "branch_label": branch_label,
        "stage_b_authorized_by_predeclared_rule": run_stage_b,
        "cell_seed_count": expected_count,
        "storage_neutrality_all_pass": neutrality,
        "maximum_storage_relative_deviation": max(
            row["storage_relative_deviation"] for row in rows
        ),
        "current_authorized": sum(row["current_passes"] for row in rows),
        "margin_authorized": sum(row["margin_passes"] for row in rows),
        "diagonal_authorized": sum(row["diagonal_passes"] for row in rows),
        "converted_failures": len(conversions),
        "strict_quarter_certificate_cell_seeds": sum(
            row["strict_quarter_certificate"] for row in rows
        ),
        "failed_slack_relations": {
            label: failed_relations.count(label)
            for label in ("improved", "unchanged", "worsened")
        },
        "by_cell": by_cell,
        "rows": rows,
    }
    output = RESULTS / f"stage_{args.stage}" / "summary_v1.json"
    atomic_json(output, summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
