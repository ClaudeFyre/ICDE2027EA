"""Read-only adapters for the archived ICDE categorical streams.

No scorer, RNG, inference routine, or numerical package is imported.  The
adapters expose observed winner prefixes, not new or completed experiments.
Event bounds remain attached to the original paid policy, family and risk
allocation; they are never merged into an uncharged best-envelope oracle.

Public interfaces:
    iter_control_groups(root=ROOT, controls_dir=None, hybrid_dir=None)
    iter_exact_groups(root=ROOT, exact_dir=None)
    build_replay_manifest(groups, root=ROOT, verify_sources=True)

Each yielded dictionary contains ``winner_indices`` (the longest compatible
saved prefix), ``available_checks`` (planned looks supported by that prefix),
``policies`` (original decisions, traces and charges), and
``protected_event_by_n`` (policy_id -> n_h -> paid evidence).  A bound's
``available_at_nominal_n`` must have been reached and its cumulative event fee
must be charged by a replay before that bound is used.  Missing event counts
are None: the archives only retain a cumulative count at the final event
prefix, although intermediate protected upper bounds are saved.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import struct


ROOT = Path(__file__).resolve().parents[1]
RESULTS = Path("nodes/09_vldb_query_certification/results")
CONTROLS = RESULTS / "icde_gate_controls_20261105_attempt1"
HYBRID = RESULTS / "icde_gate_hybrid_20261105_attempt1"
EXACT = RESULTS / "icde_exact_review_20261105_attempt1"
SCHEMA = "icde-strong-replay-observed-assets-v1"


def canonical_sha256(value):
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
                     allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _integer(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"invalid {name}: {value!r}")
    return value


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"invalid finite {name}: {value!r}")
    return float(value)


class _Reader:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.artifacts = {}

    def path(self, path):
        path = Path(path)
        resolved = path.resolve() if path.is_absolute() else (self.root / path).resolve()
        resolved.relative_to(self.root)
        return resolved

    def read(self, path):
        path = self.path(path)
        raw = path.read_bytes()
        record = {"path": path.relative_to(self.root).as_posix(),
                  "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
        previous = self.artifacts.setdefault(record["path"], record)
        if previous != record:
            raise ValueError(f"source changed during read: {path}")
        return json.loads(raw.decode("utf-8-sig")), record


def _setup_contexts(reader, directory):
    contexts = {}
    for path in sorted(directory.glob("setup_*.json")):
        report, artifact = reader.read(path)
        for query in report.get("query_setup", []):
            identity = {
                "graph": report["graph"], "query_id": query["query_id"],
                "dataset_revision": report["dataset_revision"],
                "input_sha256": report["input_sha256"],
                "candidate_ids": query["candidate_ids"],
                "candidate_tie_order": query["candidate_tie_order"],
                "scope_edge_indices": query["scope_edge_indices"],
                "scope_certificate": query["scope_certificate"],
                "cost_model": query["cost_model"],
                "nominal_q_sha256": query["box_audit"]["q_sha256"],
            }
            key = report["graph"], query["query_id"]
            if key in contexts and contexts[key]["identity"] != identity:
                raise ValueError(f"conflicting setup identity: {key}")
            contexts[key] = {"identity": identity, "query": query, "artifact": artifact}
    if not contexts:
        raise ValueError(f"no query setup reports in {directory}")
    return contexts


def _risk_plan(protocol):
    config = protocol["config"]
    plan = protocol.get("risk_plan", {})
    protected = tuple(plan.get("event_checkpoints", config["event_checkpoints"]))
    if not protected or len(set(protected)) != len(protected):
        raise ValueError("event checkpoints must be distinct")
    if any(_integer(n, "event checkpoint", 1) != n for n in protected):
        raise ValueError("invalid event checkpoints")
    beta = _finite(config["beta_total"], "beta_total")
    alpha = _finite(plan.get("alpha_per_checkpoint", beta / len(protected)), "event alpha")
    return {"event_checkpoints": list(protected), "beta_total": beta,
            "alpha_per_checkpoint": alpha,
            "source_risk_scope": protocol.get("risk", plan.get("risk_scope")),
            "joint_best_policy_guarantee": False}


def _trace_evidence(row, plan, policy_id):
    """Retain only actually paid complete event prefixes, with original fees."""
    n_final = row["samples_used"]
    final_h = _integer(row.get("event_samples_used", 0), "event_samples_used")
    final_count = _integer(row.get("event_count", 0), "event_count")
    if final_count > final_h:
        raise ValueError("event count exceeds its complete prefix")
    if final_h and row.get("event_beta_total") != plan["beta_total"]:
        raise ValueError("saved event bound uses a different risk allocation")
    evidence, traces = {}, []
    previous_n = previous_h = 0
    actual_total = 0.0
    static_total = 0.0
    for original in row["trace"]:
        point = dict(original)
        n = _integer(point["nominal_samples"], "trace nominal_samples", 1)
        h = _integer(point["event_samples"], "trace event_samples")
        if not previous_n < n <= n_final or not previous_h <= h <= n:
            raise ValueError("trace prefix order is invalid")
        actual = _finite(point.get("actual_event_fee", point.get("event_actual_fee", 0.)),
                         "actual_event_fee")
        static = _finite(point.get("static_event_fee", point.get("event_upper_fee", 0.)),
                         "static_event_fee")
        if actual < 0 or static < 0 or actual > static:
            raise ValueError("invalid event admission charges")
        actual_total += actual
        static_total += static if point.get("event_admission") == "approved" else 0.
        point["normalized_actual_event_fee"] = actual
        point["normalized_static_event_fee"] = static
        point["cumulative_actual_event_fee"] = actual_total
        point["normalized_work_used"] = _finite(
            point.get("work_used", point.get("work_completed")), "trace work")
        if h > previous_h:
            if h not in plan["event_checkpoints"] or point.get("event_admission") != "approved":
                raise ValueError("unprotected or unpaid event-prefix growth")
            upper = _finite(point["event_upper"], "event upper")
            if not 0 <= upper <= 1:
                raise ValueError("event upper is outside [0,1]")
            evidence[h] = {
                "policy_id": policy_id, "original_policy": row["policy"],
                "event_samples": h, "event_upper": upper,
                "event_count": final_count if h == final_h else None,
                "event_count_provenance": "saved_final_cumulative_count" if h == final_h
                                          else "not_saved_at_intermediate_prefix",
                "available_at_nominal_n": n,
                "static_upgrade_fee": static, "actual_upgrade_fee": actual,
                "cumulative_actual_event_fee": actual_total,
                "cumulative_admitted_static_event_fee": static_total,
                "original_work_used_at_evaluation": point["normalized_work_used"],
                "alpha_per_checkpoint": plan["alpha_per_checkpoint"],
                "original_nominal_delta": row["nominal_delta"],
                "original_event_beta_total": row.get("event_beta_total", 0.),
                "envelope": row.get("envelope", "generic_full_scope_event"),
                "epsilon_source_upper": point.get("epsilon_source_upper"),
                "effective_epsilon_upper": point.get("effective_epsilon_upper"),
                "uniform_prefix_sha256": point.get("uniform_prefix_sha256"),
                "winner_prefix_sha256": point.get("winner_prefix_sha256"),
                "requires_charging_original_event_work": True,
                "valid_at_original_event_alpha_only": True,
                "cross_policy_minimum_protected": False,
            }
        elif actual != 0:
            raise ValueError("positive event charge without prefix growth")
        previous_n, previous_h = n, h
        traces.append(point)
    if previous_h != final_h or (n_final and previous_n != n_final):
        raise ValueError("trace does not reach the saved final prefixes")
    return traces, evidence, actual_total


def _normalize_case(reader, path, payload, row, context, protocol, protocol_artifact,
                    label, family_identity, reference=None, extra_artifacts=()):
    identity = context["identity"]
    for key in ("graph", "query_id", "dataset_revision"):
        if row[key] != identity[key]:
            raise ValueError(f"row/setup {key} mismatch in {path}")
    k = len(identity["candidate_ids"])
    if row["candidate_count"] != k or row["scope_edge_count"] != len(identity["scope_edge_indices"]):
        raise ValueError("row/setup candidate or scope count mismatch")
    for key in ("graph", "query_id", "tau", "policy"):
        if key in payload and payload[key] != row[key]:
            raise ValueError(f"wrapper/row {key} mismatch")
    winners = list(row["winner_indices"])
    n = _integer(row["samples_used"], "samples_used")
    if len(winners) != n or any(_integer(w, "winner index") >= k for w in winners):
        raise ValueError("winner prefix has the wrong length or candidate index")
    counts = [0] * k
    for winner in winners:
        counts[winner] += 1
    if counts != row["winner_counts"]:
        raise ValueError("saved winner counts disagree with ordered winners")
    digest = hashlib.sha256()
    check_hashes = {0: digest.hexdigest()}
    for index, winner in enumerate(winners, 1):
        digest.update(struct.pack("<q", winner))
        check_hashes[index] = digest.hexdigest()
    if row.get("winner_prefix_sha256") != digest.hexdigest():
        raise ValueError("saved winner-prefix hash disagrees with ordered winners")
    for point in row["trace"]:
        if point.get("winner_prefix_sha256") != check_hashes.get(point["nominal_samples"]):
            raise ValueError("trace winner-prefix hash disagrees with ordered winners")
    plan = _risk_plan(protocol)
    case_data, artifact = reader.read(path)
    if case_data != payload:
        raise ValueError("case changed between discovery and normalization")
    policy_id = f"{label}:{row['policy']}"
    traces, event, actual_event = _trace_evidence(row, plan, policy_id)
    planned = [_integer(value, "nominal checkpoint", 1) for value in row["actual_nominal_checkpoints"]]
    cap = _integer(protocol.get("sample_cap", protocol["config"]["sample_count"]), "sample cap", 1)
    artifacts = [protocol_artifact, context["artifact"], artifact, *extra_artifacts]
    result = {
        "policy_id": policy_id, "original_policy": row["policy"], "source_label": label,
        "source_path": artifact["path"], "source_sha256": artifact["sha256"],
        "query_identity": identity, "query_identity_sha256": canonical_sha256(identity),
        "family_identity": family_identity, "family_identity_sha256": canonical_sha256(family_identity),
        "graph": row["graph"], "query_id": row["query_id"], "seed": row["seed"],
        "seed_purpose": row["seed_purpose"], "rng_seed_hex": row["rng_seed_hex"],
        "tau": row["tau"], "candidate_count": k, "scope_edge_count": row["scope_edge_count"],
        "winner_indices": winners, "winner_counts": counts,
        "observed_prefix_length": n, "planned_nominal_checks": planned,
        "available_checks": sorted(value for value in planned if value <= n),
        "observed_trace_checks": [point["nominal_samples"] for point in traces],
        "capture_cap": cap, "censored": n < cap,
        "censoring_semantics": "saved original-policy stopping prefix; missing later worlds are unknown",
        "original_objective": row["objective"], "inference_rule": row["inference_rule"],
        "original_policy_cert": bool(row["certified"]),
        "original_policy_robust": bool(row.get("robust_certified", False)),
        "original_nominal_cert": bool(row["nominal_certified"]),
        "original_returned_candidate_index": row["certified_candidate_index"],
        "original_status": row["status"], "nominal_delta": row["nominal_delta"],
        "event_beta_total": row.get("event_beta_total", 0.), "risk_plan": plan,
        "scope_epsilon_upper": row["scope_epsilon_upper"],
        "epsilon_source_upper": row.get("epsilon_source_upper"),
        "effective_epsilon_upper": row.get("effective_epsilon_upper"),
        "envelope": row.get("envelope", "generic_full_scope_event"),
        "cost_model": identity["cost_model"],
        "costs": {"original_work_used": row["work_used"], "original_work_budget": row["work_budget"],
                  "original_actual_event_work": actual_event, "original_seconds": row["seconds"],
                  "semantics": row["work_semantics"]},
        "trace": traces, "protected_event_by_n": event,
        "exact_reference": reference,
        "original_review_labels": {key: payload[key] for key in (
            "approved", "uniform_safe", "false_clear", "reviewed", "avoidable_review",
            "exists_uniform_winner", "exact_ambiguous") if key in payload},
        "source_artifacts": artifacts,
    }
    return result


def _merge_group(cases, kind, auxiliary=()):
    if not cases:
        raise ValueError("cannot merge an empty group")
    first = cases[0]
    identity_keys = ("query_identity_sha256", "family_identity_sha256", "seed", "seed_purpose",
                     "rng_seed_hex", "capture_cap", "scope_epsilon_upper")
    # Deliberately compare every pair, not just equal-length final hashes.
    for index, left in enumerate(cases):
        for right in cases[index + 1:]:
            if any(left[key] != right[key] for key in identity_keys):
                raise ValueError("incompatible query, family, stream or cap identities")
            common = min(left["observed_prefix_length"], right["observed_prefix_length"])
            if left["winner_indices"][:common] != right["winner_indices"][:common]:
                raise ValueError("policy winner streams disagree on their common prefix")
            left_uniform = {p["nominal_samples"]: p.get("uniform_prefix_sha256") for p in left["trace"]}
            right_uniform = {p["nominal_samples"]: p.get("uniform_prefix_sha256") for p in right["trace"]}
            for n in left_uniform.keys() & right_uniform.keys():
                if left_uniform[n] != right_uniform[n]:
                    raise ValueError("policy uniform hashes disagree on a shared checkpoint")
    longest = max(cases, key=lambda value: (value["observed_prefix_length"], value["policy_id"]))
    n = longest["observed_prefix_length"]
    policies = {}
    for case in cases:
        if case["policy_id"] in policies:
            raise ValueError("duplicate policy label within one stream/family group")
        policies[case["policy_id"]] = case
    planned = sorted({check for case in cases for check in case["planned_nominal_checks"]})
    artifacts = {item["path"]: item for case in cases for item in case["source_artifacts"]}
    for item in auxiliary:
        artifacts[item["source_artifact"]["path"]] = item["source_artifact"]
    identity = first["query_identity"]
    return {
        "schema": SCHEMA, "kind": kind, "graph": first["graph"], "query_id": first["query_id"],
        "seed": first["seed"], "seed_purpose": first["seed_purpose"],
        "rng_seed_hex": first["rng_seed_hex"], "tau": first["tau"],
        "query_identity": identity, "query_identity_sha256": first["query_identity_sha256"],
        "family_identity": first["family_identity"],
        "family_identity_sha256": first["family_identity_sha256"],
        "candidate_ids": identity["candidate_ids"], "scope_edge_indices": identity["scope_edge_indices"],
        "candidate_count": first["candidate_count"], "scope_edge_count": first["scope_edge_count"],
        "scope_epsilon_upper": first["scope_epsilon_upper"], "cost_model": first["cost_model"],
        "winner_indices": longest["winner_indices"], "winner_counts": longest["winner_counts"],
        "observed_prefix_length": n, "longest_prefix_source_policy": longest["policy_id"],
        "capture_cap": first["capture_cap"], "censored": n < first["capture_cap"],
        "planned_nominal_checks": planned, "available_checks": [value for value in planned if value <= n],
        "observed_trace_checks": sorted({value for case in cases for value in case["observed_trace_checks"]}),
        "policies": policies,
        "protected_event_by_n": {key: value["protected_event_by_n"] for key, value in policies.items()},
        "deterministic_controls": list(auxiliary), "exact_reference": first["exact_reference"],
        "source_artifacts": sorted(artifacts.values(), key=lambda item: item["path"]),
        "replay_only": True, "new_model_calls": 0, "new_random_draws": 0,
        "new_source_replication": False,
        "replay_limitations": [
            "longest saved prefix is retrospective and may be adaptively truncated",
            "a new rule not stopping within the available prefix is censored, not a budget failure",
            "event evidence remains policy-specific and must be charged before use",
            "new risk allocations do not automatically protect archived event upper bounds",
            "replay timing is not original scorer or encoder end-to-end serving time",
        ],
    }


def iter_control_groups(root=ROOT, controls_dir=None, hybrid_dir=None):
    """Yield controls/hybrid groups, verifying candidate, scope and stream identity."""
    reader = _Reader(root)
    grouped = defaultdict(list)
    directories = (("controls", CONTROLS if controls_dir is None else controls_dir),
                   ("hybrid", HYBRID if hybrid_dir is None else hybrid_dir))
    found = False
    for label, raw_directory in directories:
        directory = reader.path(raw_directory)
        if not directory.is_dir():
            continue
        found = True
        protocol, protocol_artifact = reader.read(directory / "protocol_freeze.json")
        contexts = _setup_contexts(reader, directory)
        for path in sorted((directory / "cases").glob("*.json")):
            row, _ = reader.read(path)
            context = contexts[row["graph"], row["query_id"]]
            query = context["query"]
            box = query["box_audit"]
            family = {"kind": "independent_clipped_box", "tau": row["tau"],
                      "q_sha256": box["q_sha256"], "low_sha256": box["low_sha256"],
                      "high_sha256": box["high_sha256"],
                      "query_identity_sha256": canonical_sha256(context["identity"])}
            case = _normalize_case(reader, path, row, row, context, protocol,
                                   protocol_artifact, label, family)
            grouped[row["graph"], row["query_id"], row["seed"], row["tau"]].append(case)
    if not found:
        raise FileNotFoundError("no controls/hybrid archive directories")
    for key in sorted(grouped):
        yield _merge_group(grouped[key], "controls_hybrid")


def iter_exact_groups(root=ROOT, exact_dir=None):
    """Yield one exact-review group per source/seed/width; never merge widths."""
    reader = _Reader(root)
    directory = reader.path(EXACT if exact_dir is None else exact_dir)
    protocol, protocol_artifact = reader.read(directory / "protocol_freeze.json")
    contexts = _setup_contexts(reader, directory)
    maps = {}
    for path in sorted((directory / "winner_maps").glob("*.json")):
        value, artifact = reader.read(path)
        key = value["graph"], value["query_id"]
        if key in maps:
            raise ValueError("duplicate exact winner map")
        context = contexts[key]
        identity = context["identity"]
        m = len(identity["scope_edge_indices"])
        if (value["candidate_ids"] != identity["candidate_ids"]
                or value["scope_edge_indices"] != identity["scope_edge_indices"]
                or value["m"] != m or value["all_worlds"] != 1 << m):
            raise ValueError("winner-map/setup identity mismatch")
        if len(value["world_index_to_winner"]) != value["all_worlds"]:
            raise ValueError("incomplete enumerated winner map")
        if any(_integer(winner, "enumerated winner") >= len(identity["candidate_ids"])
               for winner in value["world_index_to_winner"]):
            raise ValueError("enumerated winner index is outside candidate order")
        q = [Fraction(value) for value in value["q_exact"]]
        if len(q) != m or any(not 0 <= value <= 1 for value in q):
            raise ValueError("invalid exact-map nominal law")
        q_hash = hashlib.sha256(b"".join(struct.pack("<d", float(value)) for value in q)).hexdigest()
        if q_hash != identity["nominal_q_sha256"]:
            raise ValueError("winner-map/setup nominal law mismatch")
        maps[key] = value, artifact
    grouped, auxiliary = defaultdict(list), defaultdict(list)
    for path in sorted((directory / "cases").glob("*.json")):
        payload, case_artifact = reader.read(path)
        key = payload["graph"], payload["query_id"]
        reference_path = (directory / payload["exact_reference_path"]).resolve()
        reference, reference_artifact = reader.read(reference_path)
        if reference_artifact["sha256"] != payload["exact_reference_sha256"]:
            raise ValueError("exact reference hash mismatch")
        for name in ("graph", "query_id", "tau"):
            if reference[name] != payload[name]:
                raise ValueError("case/reference family mismatch")
        if reference["candidate_ids"] != contexts[key]["identity"]["candidate_ids"]:
            raise ValueError("reference/setup candidate-order mismatch")
        exact_vectors = [[Fraction(value) for value in reference[name]]
                         for name in ("q_exact", "low_exact", "high_exact")]
        if (any(len(vector) != len(contexts[key]["identity"]["scope_edge_indices"])
                for vector in exact_vectors)
                or any(not 0 <= low <= q <= high <= 1 for q, low, high in zip(*exact_vectors))):
            raise ValueError("invalid exact-reference family box")
        seed = payload.get("row", {}).get("seed", protocol["seed"])
        group_key = key + (seed, payload["tau"])
        if "row" not in payload:
            auxiliary[group_key].append({"original_policy": payload["policy"],
                "original_case": payload, "source_artifact": case_artifact})
            continue
        row = payload["row"]
        winner_map, map_artifact = maps[key]
        if reference["q_exact"] != winner_map["q_exact"]:
            raise ValueError("reference/winner-map nominal law mismatch")
        family = {"kind": "independent_exact_product_box", "tau": row["tau"],
                  "q_exact": reference["q_exact"], "low_exact": reference["low_exact"],
                  "high_exact": reference["high_exact"],
                  "query_identity_sha256": canonical_sha256(contexts[key]["identity"])}
        case = _normalize_case(reader, path, payload, row, contexts[key], protocol,
            protocol_artifact, "exact", family, reference,
            (reference_artifact, map_artifact))
        case["winner_map"] = winner_map
        grouped[group_key].append(case)
    if auxiliary.keys() - grouped.keys():
        raise ValueError("deterministic exact cases lack corresponding MC stream groups")
    for key in sorted(grouped):
        result = _merge_group(grouped[key], "exact_review", auxiliary.get(key, ()))
        result["winner_map"] = grouped[key][0]["winner_map"]
        result["oracle_lookup_note"] = (
            "Complete winner map can support a separate table-oracle experiment; "
            "new RNG draws would not be archived-prefix replay or original scorer timing.")
        yield result


def build_replay_manifest(groups, root=ROOT, verify_sources=True):
    """Bind the supplied normalized groups to immutable original artifact hashes."""
    root = Path(root).resolve()
    artifacts, identities, counts = {}, [], Counter()
    for group in groups:
        if group.get("schema") != SCHEMA:
            raise ValueError("unexpected normalized replay schema")
        counts[group["kind"]] += 1
        identities.append({key: group[key] for key in (
            "kind", "graph", "query_id", "seed", "seed_purpose", "tau",
            "query_identity_sha256", "family_identity_sha256", "observed_prefix_length")})
        for artifact in group["source_artifacts"]:
            previous = artifacts.setdefault(artifact["path"], artifact)
            if previous != artifact:
                raise ValueError("artifact identity differs between replay groups")
    if verify_sources:
        for artifact in artifacts.values():
            path = (root / artifact["path"]).resolve()
            path.relative_to(root)
            raw = path.read_bytes()
            if len(raw) != artifact["bytes"] or hashlib.sha256(raw).hexdigest() != artifact["sha256"]:
                raise ValueError(f"source changed after normalization: {path}")
    return {"schema": SCHEMA, "group_counts": dict(counts), "group_identities": identities,
            "source_artifacts": sorted(artifacts.values(), key=lambda value: value["path"]),
            "source_artifacts_verified": bool(verify_sources), "replay_only": True,
            "new_model_calls": 0, "new_random_draws": 0,
            "adapter_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "group_identities_sha256": canonical_sha256(identities)}
