"""Frozen, bounded strong-control reanalysis of archived full-family RREA streams."""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import time
import zipfile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def load_inputs(config):
    base = ROOT / config["rrea_source"]
    original = read(base / "protocol_before_draws.json")
    files = [base / "protocol_before_draws.json", base / "summary.json"]
    graphs = {}
    for graph in config["graphs"]:
        folder = base / graph
        progress_path = folder / "progress.json"
        progress = read(progress_path)
        prefix_path = folder / "prefixes/prefix_0512.npz"
        law_path = folder / "law_masks_before_draws.npz"
        for path in (prefix_path, law_path):
            with zipfile.ZipFile(path) as archive:
                if archive.testzip() is not None:
                    raise ValueError(f"NPZ CRC failed: {path}")
        with np.load(prefix_path, allow_pickle=False) as archive:
            winners = archive["winners"].copy()
            full_counts = archive["counts"].copy()
            sources = archive["source_indices"].copy()
            targets = archive["target_order"].copy()
        with np.load(law_path, allow_pickle=False) as archive:
            law = {key: archive[key].copy() for key in (
                "nominal_optional", "full_box_low_optional", "full_box_high_optional",
                "optional_original_indices", "pinned")}
        identity = original["graphs"][graph]
        if progress["status"] != "COMPLETE" or progress["completed_worlds"] != 512:
            raise ValueError("incomplete source capture")
        if winners.shape != (512, 32) or full_counts.shape != (32, 15000):
            raise ValueError("the original full-candidate source shape changed")
        if not np.array_equal(sources, identity["query_source_indices"]):
            raise ValueError("source selection changed")
        if hashlib.sha256(targets.tobytes()).hexdigest() != identity["target_order_sha256"]:
            raise ValueError("target ordering changed")
        if sha(law_path) != identity["law_masks_sha256"]:
            raise ValueError("law archive identity changed")
        if sha(prefix_path) != progress["latest_prefix_sha256"]:
            raise ValueError("winner archive identity changed")
        if np.any(winners < 0) or np.any(winners >= 15000):
            raise ValueError("winner outside full candidate pool")
        for query in range(32):
            if not np.array_equal(np.bincount(winners[:, query], minlength=15000), full_counts[query]):
                raise ValueError("saved counts disagree with full ordered winner trace")
        for n in config["looks"]:
            digest = hashlib.sha256(np.asarray(winners[:n], dtype=np.int32).tobytes()).hexdigest()
            if digest != progress["snapshots"][str(n)]["winner_prefix_sha256"]:
                raise ValueError("a checkpoint prefix does not match the archived stream")
        if len(law["nominal_optional"]) != identity["families"][config["family"]]["varied_coordinates"]:
            raise ValueError("wide family coordinate count changed")
        files += [prefix_path, law_path, progress_path]
        graphs[graph] = {"winners": winners, "law": law, "progress": progress,
                         "identity": identity, "source_indices": sources, "targets": targets}
    return graphs, files


def compact_evidence(evidence, counts):
    lower, upper = evidence["lower"], evidence["upper"]
    unique = {}
    for index, count in enumerate(counts):
        if int(count) not in unique:
            unique[int(count)] = [float(lower[index]), float(upper[index])]
    leader = evidence["leader_index"]
    worst = evidence["worst_upper_competitor_index"]
    return {"method": evidence["method"], "alpha_exact": evidence["alpha_exact"],
            "delta_exact": evidence["delta_exact"], "risk_scope": evidence["risk_scope"],
            "leader_index": leader, "worst_upper_competitor_index": worst,
            "leader_probability_interval": [float(lower[leader]), float(upper[leader])],
            "competitor_probability_interval": [float(lower[worst]), float(upper[worst])] if worst is not None else None,
            "nominal_lower_gap": evidence["lower_gap"],
            "intervals_by_count": {str(key): value for key, value in sorted(unique.items())}}


def run(config_path, output, seconds):
    import icde_strong_bounds_20261106 as strong

    started = time.perf_counter()
    config = read(config_path)
    if config["family"] != "A_full_edge_box" or config["looks"] != [32, 64, 128, 256, 512]:
        raise ValueError("original wide family and budget schedule must remain fixed")
    output.relative_to(ROOT)
    output.mkdir(parents=True, exist_ok=False)
    graphs, input_files = load_inputs(config)
    code_files = [Path(__file__), ROOT / "scripts/icde_strong_bounds_20261106.py"]
    frozen = {"schema": "strong-bound-reanalysis-input-freeze-v1",
              "status": "FROZEN_BEFORE_NEW_RULE_EVALUATION_AFTER_HISTORICAL_OUTCOMES_SEEN",
              "config": config, "config_sha256": sha(config_path),
              "source_and_input_sha256": {str(path.relative_to(ROOT)): sha(path) for path in input_files + code_files},
              "input_validation": {"all_selected_npz_crc_valid": True,
                  "all_512_ordered_winners_recounted": True, "all_five_prefix_digests_match": True,
                  "same_source_target_law_and_full_family": True},
              "historical_global_recovery": {
                  "path": "nodes/00_audit/results/icde_strong_bounds_recovery_20261106_attempt1.json",
                  "status": "FAIL_OUTSIDE_SELECTED_INPUTS",
                  "known_issues": "one historical UTF8-BOM JSON and 476 empty historical logs/placeholders (.log/.txt/.touch/.diff); no NPZ/digest failure; preserved"},
              "training_calls": 0, "encoder_calls": 0, "new_world_draws": 0}
    write_new(output / "protocol_before_evaluation.json", frozen)
    rows = []
    first = {}
    numeric_seconds = defaultdict(float)
    divergence = {}
    delta = Fraction(config["delta_per_query_per_separately_evaluated_probability_method"])
    try:
        with (output / "cases.jsonl").open("x", encoding="utf-8") as cases:
            for graph, data in graphs.items():
                t = time.perf_counter()
                law = data["law"]
                bounds = strong.product_divergence_bounds(law["nominal_optional"],
                    law["full_box_low_optional"], law["full_box_high_optional"])
                if any(isinstance(value, float) and not np.isfinite(value) for value in bounds.values()):
                    raise ValueError("unexpected nonfinite full-family bound")
                divergence[graph] = bounds
                numeric_seconds["divergence_construction"] += time.perf_counter() - t
                for n in config["looks"]:
                    for query in range(32):
                        if time.perf_counter() - started >= seconds:
                            raise TimeoutError("bounded reanalysis deadline reached")
                        counts = np.bincount(data["winners"][:n, query], minlength=15000)
                        leader = int(np.argmax(counts))
                        common = {"graph": graph, "query_position": query,
                                  "source_index": int(data["source_indices"][query]),
                                  "source_id": data["identity"]["query_source_ids"][query],
                                  "family": config["family"], "n": n,
                                  "candidate_count": 15000, "delta": str(delta),
                                  "world_role": "primary" if n == 256 else "diagnostic" if n == 512 else "earlier_fixed_look",
                                  "count_sha256_int64": hashlib.sha256(counts.astype(np.int64).tobytes()).hexdigest(),
                                  "nonzero_counts": [[int(i), int(counts[i])] for i in np.flatnonzero(counts)],
                                  "empirical_leader": leader}
                        for legacy in ("normal", "empirical_bernstein"):
                            gap = data["progress"]["snapshots"][str(n)]["numerical_lower_gaps"][legacy][query]
                            # Fraction comparison preserves the strict positive-gap decision.
                            for kind, epsilon in (("coupling_tv", 1.), ("hellinger_tv", bounds["tv_hellinger_upper"])):
                                protected_gap = Fraction.from_float(float(gap)) - 2 * Fraction.from_float(float(epsilon))
                                rows.append({**common, "inference": "legacy_" + legacy,
                                    "transport": kind, "lower_gap": float(protected_gap),
                                    "certified": protected_gap > 0, "nominal_certified": gap > 0,
                                    "evidence": "archived protected numerical gap"})
                        for method in config["probability_methods"]:
                            t = time.perf_counter()
                            evidence = strong.categorical_probability_bounds(counts, n, delta,
                                method=method, looks=tuple(config["looks"]))
                            numeric_seconds["probability_" + method] += time.perf_counter() - t
                            evidence_record = compact_evidence(evidence, counts)
                            gap_rows = []
                            for transport in config["deterministic_transports"]:
                                t = time.perf_counter()
                                decision = strong.transport_mode_intervals(evidence["lower"], evidence["upper"],
                                    evidence["leader_index"], bounds, method=transport)
                                numeric_seconds["transport_" + transport] += time.perf_counter() - t
                                row = {**common, "inference": method, "transport": transport,
                                       "lower_gap": decision["lower_gap"], "certified": decision["certified"],
                                       "nominal_certified": evidence["nominal_certified"],
                                       "evidence": evidence_record,
                                       "worst_competitor_index": decision["worst_competitor_index"]}
                                gap_rows.append(row)
                                rows.append(row)
                            best = max(gap_rows, key=lambda row: row["lower_gap"])
                            rows.append({**best, "transport": "best_deterministic",
                                         "selected_deterministic_transport": best["transport"],
                                         "selection_protected_by_same_probability_event": True})
                        # Persist a complete query checkpoint before any subsequent work.
                        block = [row for row in rows if row["graph"] == graph and row["n"] == n and row["query_position"] == query]
                        for row in block:
                            key = graph, query, row["inference"], row["transport"]
                            if row["certified"] and key not in first:
                                first[key] = {"n": n, "winner": row["empirical_leader"]}
                            row["first_certificate_worlds"] = first.get(key, {}).get("n")
                            cases.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                        cases.flush()
                    print(json.dumps({"graph": graph, "look": n,
                        "seconds": time.perf_counter()-started,
                        "certified_at_look": {method: sum(1 for row in rows if row["graph"] == graph and row["n"] == n and row["inference"] == method and row["transport"] == "best_deterministic" and row["certified"]) for method in config["probability_methods"]}}), flush=True)
        summaries = []
        grouped = defaultdict(list)
        for row in rows:
            grouped[(row["n"], row["inference"], row["transport"])].append(row)
        for (n, inference, transport), values in sorted(grouped.items()):
            summaries.append({"n": n, "inference": inference, "transport": transport,
                "queries": len(values), "instantaneous_certificates": sum(row["certified"] for row in values),
                "cumulative_certificates": sum(row["first_certificate_worlds"] is not None for row in values),
                "nominal_certificates_at_look": sum(row["nominal_certified"] for row in values),
                "graphs": {graph: {"queries": sum(row["graph"]==graph for row in values),
                    "cumulative_certificates": sum(row["graph"]==graph and row["first_certificate_worlds"] is not None for row in values)} for graph in config["graphs"]}})
        changed = [path for path, digest in frozen["source_and_input_sha256"].items() if sha(ROOT/path)!=digest]
        if changed:
            raise ValueError(f"inputs/source changed during reanalysis: {changed}")
        result = {"status": "COMPLETE_EXPLORATORY_ARCHIVED_STREAM_REANALYSIS",
                  "family": config["family"], "distinct_queries": 64,
                  "primary_worlds": 256, "diagnostic_worlds": 512,
                  "training_calls": 0, "encoder_calls": 0, "new_world_draws": 0,
                  "divergence_bounds": divergence, "results": summaries,
                  "statistical_and_transport_seconds_in_this_replay": dict(numeric_seconds),
                  "elapsed_reanalysis_seconds": time.perf_counter()-started,
                  "cases_sha256": sha(output/"cases.jsonl"),
                  "risk_scope": config["mixture_risk"] + "; methods separately evaluated; not workload or best-inference guarantee",
                  "timing_scope": config["runtime_scope"],
                  "validation": {"input_and_source_identities_unchanged": True,
                      "no_family_or_candidate_reduction": True, "protected_full_candidate_count": 15000,
                      "no_new_truth_accuracy_claim": True}}
        write_new(output / "summary.json", result)
        print(json.dumps({"status": result["status"], "elapsed_seconds":result["elapsed_reanalysis_seconds"],
                          "main": [item for item in summaries if item["n"] in (256,512) and item["transport"] in ("coupling_tv","best_deterministic")]}, ensure_ascii=False),flush=True)
    except BaseException as error:
        write_new(output / "failure.json", {"status":"FAILED_PRESERVED", "error":str(error),
                                            "rows_completed":len(rows), "elapsed_seconds":time.perf_counter()-started})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=600.)
    args = parser.parse_args()
    if not 0 < args.seconds <= 600:
        parser.error("seconds must be in (0,600]")
    run(args.config.resolve(), args.output.resolve(), args.seconds)


if __name__ == "__main__":
    main()
