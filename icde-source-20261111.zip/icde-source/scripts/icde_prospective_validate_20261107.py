"""Check the complete frozen experiment matrix and certificate accounting."""
from fractions import Fraction
import math
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from icde_prospective_20261107 import BASE,DATA,ROOT,LOOKS,POLICIES,load,save,sha


def main():
    protocol=load(BASE/"confirmation_protocol.json")
    selection=load(BASE/"selection_protocol.json")
    checked=0
    def require(condition,message):
        nonlocal checked
        checked+=1
        if not condition:raise AssertionError(message)
    for path,digest in protocol["code_sha256"].items():
        require(sha(ROOT/path)==digest,"frozen numerical source changed")
    expected={(graph,rank,seed,policy) for graph in ("dw","enfr") for rank in range(32,288) for seed in (211,223,227) for policy in POLICIES}
    actual=set()
    total_cases=0
    common_prefixes={}
    for path in sorted((BASE/"confirmation").glob("*/summary.json")):
        summary=load(path)
        frozen_run=load(path.parent/"protocol_before_runs.json")
        require(frozen_run["script_sha256"]==protocol["code_sha256"]["scripts/icde_prospective_20261107.py"],"run used different executor")
        for row in summary["rows"]:
            total_cases+=1
            raw_path=ROOT/row["case"]
            require(sha(raw_path)==row["case_sha256"],"case bytes changed")
            raw=load(raw_path)
            require(raw["full_candidates"]==15000,"full candidate pool changed")
            require(sum(raw["winner_counts"])==raw["worlds"],"winner counts do not sum to actual worlds")
            require(raw["worlds"] in (0,*LOOKS),"unprotected nominal prefix")
            require(raw["event_worlds"] in (0,*LOOKS) and raw["event_worlds"]<=raw["worlds"],"unprotected event prefix")
            require(0<=raw["event_count"]<=raw["event_worlds"],"event count outside prefix")
            require(Fraction(raw["nominal_delta_exact"])+Fraction(raw["event_beta_exact"])<=Fraction(1,20),"risk exceeds total")
            require(row["response_seconds_including_persistence"]>=raw["compute_seconds"],"response omits compute")
            require(row["delivered_within_budget"]==(raw["certified"] and row["response_seconds_including_persistence"]<=summary["deadline_seconds"]),"late result counted within deadline")
            if raw["certified"] and raw["worlds"]==0:
                require(raw["retained_candidates"]==1 or raw["status"]=="direct_global_interval_certificate","unsupported zero-sample certificate")
            if raw["certified"] and raw["worlds"]>0:
                final=raw["trace"][-1]
                require(max(final["deterministic_gap"],final["paid_gap"])>0 and not final["late_discard"],"certificate lacks positive protected gap")
            if path.parent.name.startswith("primary_"):
                key=(row["graph"],row["rank"],row["seed"],row["policy"])
                require(key not in actual,"duplicate primary case")
                actual.add(key)
                require(abs(summary["deadline_seconds"]-protocol["budgets"][row["graph"]]["primary_deadline_seconds"])<1e-12,"primary budget changed")
                for point in raw["trace"]:
                    prefix_key=(row["graph"],row["rank"],row["seed"],point["n"])
                    prior=common_prefixes.setdefault(prefix_key,point["winner_prefix_sha256"])
                    require(prior==point["winner_prefix_sha256"],"paired winner prefix differs")
    require(actual==expected,"primary confirmation matrix incomplete or contains substituted cases")
    for graph in ("dw","enfr"):
        record=selection["graphs"][graph]
        require(not set(record["pilot"])&set(record["confirmation"]),"pilot overlaps confirmation")
        require(len(set(record["confirmation"]))==256,"confirmation IDs changed")
        for name,digest in record["input_sha256"].items():
            require(sha(DATA/graph/name)==digest,"source data changed")
        for rank in range(288):
            path=BASE/"prepared"/graph/f"q{rank:03d}.json"
            prepared=load(path)
            intended=record["pilot"][rank] if rank<32 else record["confirmation"][rank-32]
            require(prepared["query_id"]==intended,"prepared ID changed")
            require(prepared["candidate_preservation"]["status"]=="PASS","invalid candidate removal")
            require(prepared["full_local_audit"]=="PASS_ONE_COUPLED_WORLD","full/local audit missing")
            require(sha(path.with_suffix(".npz"))==prepared["kernel_sha256"],"prepared kernel changed")
    reference=load(BASE/"new_exact_reference/summary.json")
    require(reference["two_independent_fraction_calculations_agree"],"exact reference not independently checked")
    require(reference["false_clear"]==0,"exact reference detects unsafe certificate")
    require(load(BASE/"prepared_service_cold/summary.json")["process_runs"]==24,"fresh process repetitions incomplete")
    require(load(BASE/"prepared_service_cold/summary.json")["raw_process_runs"]==8,"full raw-input cold observations incomplete")
    witnesses=load(BASE/"full_cube_witnesses/summary.json")
    require(witnesses["distinct_queries"]==512,"full-cube probe diagnostic incomplete")
    require(not witnesses["contradicted_delivered_certificates"],"full-cube witness contradicts a delivered certificate")
    maintenance=load(BASE/"maintenance_actions.json")
    require(maintenance["outside_family_reuses"]==0,"maintenance consumer reused outside the approved family")
    require(maintenance["request_count"]==6144*3,"maintenance request cases incomplete")
    final=load(BASE/"final_summary.json")
    require(len(final["curves"])==2*4*4,"budget sensitivity incomplete")
    require(all(r["cases"]==64 for r in final["curves"]),"budget curve has missing query")
    require(len(final["sensitivity"])==2*6*4,"width sensitivity incomplete")
    require(all(r["cases"]==64 for r in final["sensitivity"]),"width sensitivity has missing query")
    save(BASE/"validation.json",{"status":"PASS","checks":checked,"primary_cases":len(actual),"all_confirmation_cases":total_cases,
        "distinct_confirmation_queries":512,"paired_prefix_checks":len(common_prefixes),"full_candidate_count":15000,
        "exact_reference_queries":reference["distinct_confirmation_queries"],"exact_audited_primary_actions":reference["audited_primary_actions"],
        "warning":"implementation/accounting validation; does not prove novelty, fact calibration, independent industrial demand or zero error on unenumerated queries"})
    print(f"PASS {checked} checks; {len(actual)} primary and {total_cases} total confirmation cases",flush=True)


if __name__=="__main__":main()
