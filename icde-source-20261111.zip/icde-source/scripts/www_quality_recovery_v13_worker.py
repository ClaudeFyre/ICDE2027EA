"""Source-backed RREA worker; raw author files remain intact in vendor/CIKM."""
from www_quality_recovery_v13_common import *
import argparse, platform, importlib

def runtime(seed,qa=False):
    import numpy as np, random
    threads=os.cpu_count() or 1
    try:
        import psutil
        threads=psutil.cpu_count(logical=False) or threads
    except ImportError:pass
    os.environ['OMP_NUM_THREADS']=str(threads);os.environ['TF_CPP_MIN_LOG_LEVEL']='1'
    import tensorflow as tensorflow, keras
    if keras.__version__!='2.10.0' or (tensorflow.__version__!='2.10.1' and not (qa and platform.system()=='Darwin' and tensorflow.__version__=='2.10.0')):
        raise RuntimeError('frozen TensorFlow/Keras environment differs')
    from importlib.metadata import version
    from keras.optimizers.optimizer_v1 import RMSprop
    import inspect
    if sha(inspect.getsourcefile(RMSprop))!=sha(VENDOR/'keras210_optimizer_v1_original.py'):raise ValueError('optimizer implementation differs from frozen Keras2.10 source')
    expected=load(CONFIG)['environment']
    for package in ['keras','numpy','scipy','psutil','h5py','protobuf','tqdm']:
        if version(package)!=expected[package]:raise ValueError('frozen dependency differs '+package)
    if sys.version_info[:3]!=(3,10,16):raise ValueError('requires independent Python3.10.16')
    tf=tensorflow.compat.v1;tf.disable_v2_behavior();tf.reset_default_graph()
    random.seed(seed);np.random.seed(seed);tf.set_random_seed(seed)
    gpu=tensorflow.config.list_physical_devices('GPU')
    config=tf.ConfigProto(intra_op_parallelism_threads=threads,inter_op_parallelism_threads=min(4,threads))
    config.gpu_options.allow_growth=True
    session=tf.Session(config=config);tf.keras.backend.set_session(session)
    sys.path.insert(0,str(VENDOR))
    module=importlib.import_module('official_model_extracted');utils=importlib.import_module('utils')
    identity={'python':sys.version,'platform':platform.platform(),'tensorflow':tensorflow.__version__,'keras':keras.__version__,'device':'gpu' if gpu else 'cpu','gpu_devices':[str(d) for d in gpu],'cpu_fallback_reason':None if gpu else 'GPU unavailable in this frozen TensorFlow environment','threads':threads,'cuda_build':tensorflow.sysconfig.get_build_info(),'source_commit':load(CONFIG)['model']['commit'],'official_reproduction_verified':False,'implementation':'author source extracted, declared compat.v1/legacy optimizer patch','mac_qa':qa,'dependency_versions':{p:version(p) for p in ['keras','numpy','scipy','psutil','h5py','protobuf','tqdm']}}
    return tf,keras,module,utils,session,identity

def matrices(g,utils,mask=None):
    import numpy as np
    tr=g['triples'] if mask is None else g['triples'][mask]
    # Fixed full entity/relation vocabulary; only active triples change.
    a,ri,rv,ef,rf=utils.get_matrix(tr.tolist(),set(range(len(g['entity_ids']))),set(range(len(g['relations'])+1)))
    adj=np.stack(a.nonzero(),axis=1).astype(np.int64)
    ri=np.asarray(ri,dtype=np.int64);rv=np.asarray(rv,dtype=np.float32)
    ra=np.stack(rf.nonzero(),axis=1).astype(np.int64);ea=np.stack(ef.nonzero(),axis=1).astype(np.int64)
    if len(adj)==0 or set(adj[:,0])!=set(range(len(g['entity_ids']))):raise ValueError('isolated node unsupported by official segment_sum path')
    if (ri[:,0].max()+1)!=len(adj):raise ValueError('relation row/adjacency mismatch')
    return [adj,ri,rv,ra,ea],rf.shape[1]

def build(g,m,mod,rel_size):
    import numpy as np
    c=load(CONFIG)['model'];mod.batch_size=len(g['entity_ids'])
    train,feature=mod.get_trgat(node_size=len(g['entity_ids']),rel_size=rel_size,node_hidden=c['node_hidden'],rel_hidden=c['rel_hidden'],triple_size=len(m[0]),n_attn_heads=c['attention_heads'],dropout_rate=c['dropout'],gamma=c['margin'],lr=c['learning_rate'],depth=c['depth'])
    return train,feature

def feed(m):
    import numpy as np
    return [np.expand_dims(v,0) for v in m]

def embed(feature,m):
    import numpy as np
    v=np.asarray(feature.predict_on_batch(feed(m)))
    if v.ndim!=2 or v.shape[1]!=600 or not np.isfinite(v).all():raise ValueError('nonfinite/dimension-mismatched RREA output')
    return v

def placement_trace(tf,keras,sess,feature,m,out):
    meta=tf.RunMetadata();options=tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
    fd=dict(zip(feature.inputs,feed(m)));phase=keras.backend.learning_phase()
    if not isinstance(phase,int):fd[phase]=0
    sess.run(feature.outputs,feed_dict=fd,options=options,run_metadata=meta)
    devices=[{'device':d.device,'executed_nodes':len(d.node_stats),'node_names':[n.node_name for n in d.node_stats]} for d in meta.step_stats.dev_stats]
    save(out/'execution_placement.json',{'devices':devices,'gpu_ops_executed':any('GPU' in d['device'].upper() and d['executed_nodes']>0 for d in devices),'scope':'actual feature inference after initialized weights; sparse/dense may occupy different devices'})

def masks(g):
    import numpy as np
    tr=g['triples'];deg=np.bincount(np.concatenate([tr[:,0],tr[:,2]]),minlength=len(g['entity_ids']))
    mask=np.ones(len(tr),dtype=bool);removed=[]
    for i,(h,r,t) in enumerate(tr):
        if h!=t and deg[h]>1 and deg[t]>1:
            mask[i]=False;deg[h]-=1;deg[t]-=1;removed.append(i)
            if len(removed)==64:break
    if not removed:raise ValueError('no eligible edge perturbation')
    return mask,removed

def mask_restore(g,m,rs,mod,utils,feature,out):
    import numpy as np
    started=time.monotonic();weights=feature.get_weights();before=embed(feature,m)
    mask,removed=masks(g);changed,rs2=matrices(g,utils,mask)
    if rs2!=rs:raise ValueError('world changed fixed relation vocabulary')
    _,f2=build(g,changed,mod,rs);f2.set_weights(weights);perturbed=embed(f2,changed)
    restored,rs3=matrices(g,utils,np.ones(len(g['triples']),dtype=bool));_,f3=build(g,restored,mod,rs3);f3.set_weights(weights);after=embed(f3,restored)
    if any(not np.array_equal(a,b) for a,b in zip(m,restored)):raise ValueError('restored graph inputs differ')
    weight_changed=any(not np.array_equal(a,b) for a,b in zip(weights,feature.get_weights())) or any(not np.array_equal(a,b) for a,b in zip(weights,f2.get_weights())) or any(not np.array_equal(a,b) for a,b in zip(weights,f3.get_weights()))
    diff=float(np.max(np.abs(after-before)));change=float(np.max(np.abs(perturbed-before)))
    if weight_changed or diff>float(load(CONFIG)['graph_policy']['restore_max_abs_error']) or change==0:raise ValueError('mask/restore identity or response gate failed')
    with (out/'mask_restore.npz').open('xb') as f:np.savez_compressed(f,active_edge_mask=mask,removed_rows=np.array(removed),original=before,perturbed=perturbed,restored=after,entity_ids=np.array(g['entity_ids']))
    projection_evidence=None
    if (out/'inputs.npz').exists():
        capture=np.load(out/'inputs.npz',allow_pickle=False);basis=capture['basis'];worlds=np.stack([normalized(v) for v in [before,perturbed,after]])
        projected={str(d):worlds@basis[:,:d] for d in (16,32)}
        with (out/'world_projection_engineering.npz').open('xb') as f:np.savez_compressed(f,normalized_worlds=worlds,projected_d16=projected['16'],projected_d32=projected['32'],sample_mean_d32=projected['32'].mean(0),basis=basis)
        if not np.isfinite(projected['32']).all():raise ValueError('invalid frozen world projection')
        projection_evidence={'same_frozen_basis':True,'worlds':3,'source_capture_sha256':sha(out/'inputs.npz'),'engineering_only':True}
    record={'status':'RREA_MASK_RESTORE_PASS','frozen_world_projection':projection_evidence,'removed_rows':removed,'parameters_changed':weight_changed,'restore_max_abs_error':diff,'perturbation_max_abs_error':change,'input_matrices_rebuilt':True,'fixed_relation_vocabulary':True,'wall_seconds':time.monotonic()-started,'original_input_hashes':[hashlib.sha256(v.tobytes()).hexdigest() for v in m],'perturbed_input_hashes':[hashlib.sha256(v.tobytes()).hexdigest() for v in changed],'restored_input_hashes':[hashlib.sha256(v.tobytes()).hexdigest() for v in restored]}
    save(out/'mask_restore.json',record);return record

def oracle(feature,m,keras):
    import numpy as np
    emb=sorted([l for l in feature.layers if isinstance(l,keras.layers.Embedding)],key=lambda l:int(l.name.rsplit('_',1)[1]) if l.name.rsplit('_',1)[1].isdigit() else -1)
    ent=emb[0].get_weights()[0].astype(np.float64);rel=emb[1].get_weights()[0].astype(np.float64)
    encoder=next(l for l in feature.layers if l.__class__.__name__=='NR_GraphAttention')
    kernels=keras.backend.batch_get_value([v[0] for v in encoder.attn_kernels]);adj,ri,rv,ra,ea=m;n=len(ent)
    def avg(indices,values):
        result=np.zeros((n,values.shape[1]));counts=np.bincount(indices[:,0],minlength=n)
        np.add.at(result,indices[:,0],values[indices[:,1]])
        return result/counts[:,None]
    relation_mix=np.zeros((len(adj),rel.shape[1]));np.add.at(relation_mix,ri[:,0],rv[:,None]*rel[ri[:,1]])
    norm=np.linalg.norm(relation_mix,axis=1);relation_mix/=np.maximum(norm[:,None],np.sqrt(1e-12))
    def stack(value):
        value=np.maximum(value,0);outs=[value]
        for w in kernels:
            neigh=value[adj[:,1]];selfs=value[adj[:,0]]
            neigh=neigh-2*np.sum(neigh*relation_mix,axis=1)[:,None]*relation_mix
            logits=(np.concatenate([selfs,neigh,relation_mix],axis=1)@w).ravel()
            maximum=np.full(n,-np.inf);np.maximum.at(maximum,adj[:,0],logits)
            att=np.exp(logits-maximum[adj[:,0]]);sums=np.zeros(n);np.add.at(sums,adj[:,0],att);att/=sums[adj[:,0]]
            value=np.zeros_like(value);np.add.at(value,adj[:,0],neigh*att[:,None]);value=np.maximum(value,0);outs.append(value)
        return np.concatenate(outs,axis=1)
    return np.concatenate([stack(avg(ea,ent)),stack(avg(ra,rel))],axis=1)

def optimizer_regression(tf,keras):
    import numpy as np,inspect
    from keras.optimizers.optimizer_v1 import RMSprop
    p=keras.backend.variable(np.array([1.,-2.,.25],dtype=np.float32))
    grad=np.array([1e-8,.2,-.01],dtype=np.float32)
    loss=tf.reduce_sum(p*tf.constant(grad));opt=RMSprop(lr=.005)
    update=keras.backend.function([],[loss],updates=opt.get_updates(loss,[p]))
    expected=np.array([1.,-2.,.25],dtype=np.float32);acc=np.zeros(3,dtype=np.float32);errors=[]
    rho=np.float32(.9);rate=np.float32(.005);eps=np.float32(keras.backend.epsilon())
    for _ in range(3):
        acc=rho*acc+(np.float32(1)-rho)*grad*grad
        expected=expected-rate*grad/(np.sqrt(acc)+eps)
        update([]);actual=keras.backend.get_value(p)
        errors.append(float(np.max(np.abs(actual-expected))))
    if max(errors)>1e-6:raise ValueError('Keras2.2.4 RMSprop formula regression failed')
    return {'status':'RREA_RMSPROP224_EQUATION_PASS','steps':3,'max_errors':errors,'epsilon_location':'outside sqrt(new accumulator)','installed_optimizer_source_sha256':sha(inspect.getsourcefile(RMSprop))}

def engineering(out,seed,qa):
    import numpy as np
    tf,keras,mod,utils,sess,identity=runtime(seed,qa);save(out/'environment.json',identity)
    optimizer_check=optimizer_regression(tf,keras);save(out/'optimizer_checks.json',optimizer_check)
    g={'entity_ids':['small_'+str(i) for i in range(8)],'relations':[('small','r'+str(i)) for i in range(3)],'triples':np.array([(0,1,1),(1,2,2),(2,3,3),(3,1,0),(4,1,5),(5,2,6),(6,3,7),(7,1,4),(0,2,2),(4,2,6)],dtype=np.int64)}
    m,rs=matrices(g,utils);train,feature=build(g,m,mod,rs);actual=embed(feature,m);placement_trace(tf,keras,sess,feature,m,out);expected=oracle(feature,m,keras)
    if not np.allclose(actual,expected,rtol=1e-4,atol=1e-5):raise ValueError('independent fixed-weight NumPy forward failed')
    encoder=next(l for l in feature.layers if l.__class__.__name__=='NR_GraphAttention');w=encoder.attn_kernels[0][0]
    rng=np.random.RandomState(1917);coeff=rng.normal(size=actual.shape).astype(np.float32)
    objective=tf.reduce_sum(feature.output*tf.constant(coeff));gradient=tf.gradients(objective,w)[0]
    fdict=dict(zip(feature.inputs,feed(m)));phase=keras.backend.learning_phase()
    if not isinstance(phase,int):fdict[phase]=0
    grad=sess.run(gradient,feed_dict=fdict);index=np.unravel_index(int(np.argmax(np.abs(grad))),grad.shape)
    original=keras.backend.get_value(w);estimates=[]
    for delta in [-.001,.001]:
        v=original.copy();v[index]+=delta;keras.backend.set_value(w,v)
        estimates.append(float(np.sum(oracle(feature,m,keras)*coeff)))
    keras.backend.set_value(w,original);fd=(estimates[1]-estimates[0])/.002;auto=float(grad[index])
    if not np.isfinite(grad).all() or not np.isclose(fd,auto,rtol=.03,atol=.03):raise ValueError('independent finite-difference gradient failed')
    # Exercise the actual compiled author loss/optimizer as well.
    batch=np.array([[0,4,1,5],[1,5,2,6],[2,6,3,7],[3,7,0,4]],dtype=np.int64)
    loss=float(np.asarray(train.train_on_batch(feed(m)+[batch[None]],np.zeros((1,1)))).ravel()[0])
    if not np.isfinite(loss):raise ValueError('nonfinite training loss')
    mask_restore(g,m,rs,mod,utils,feature,out)
    checks=[(377,{'16':224,'32':347},1500,32),(399,{'16':258,'32':369},1500,32),(447,{'16':352,'32':416},1500,None),(424,{'16':312,'32':397},1500,32)]
    for h,p,n,want in checks:
        if choose_dimension(h,p,n)!=want:raise ValueError('integer projection regression')
    save(out/'engineering.json',{'status':'QUALITY_V13_SOURCE_ENGINEERING_PASS','forward_max_abs_error':float(np.max(np.abs(actual-expected))),'gradient_index':list(map(int,index)),'autodiff_gradient':auto,'numpy_finite_difference':fd,'compiled_loss':loss,'integer_regressions':4,'official_reproduction_verified':False,'test_evaluations_completed':0})
    print('QUALITY_V13_SOURCE_ENGINEERING_PASS',flush=True)

def pilot(out,key,seed,qa):
    import numpy as np
    tf,keras,mod,utils,sess,identity=runtime(seed,qa);save(out/'environment.json',identity)
    g=graph(key);m,rs=matrices(g,utils);train,feature=build(g,m,mod,rs)
    started=time.monotonic();losses=[];tp=g['pairs']['train'];size=len(g['entity_ids'])
    for step in range(3):
        batch=np.tile(tp,(size//len(tp)+1,1));np.random.shuffle(batch);batch=batch[:size]
        batch=np.concatenate([batch,np.random.randint(0,size,batch.shape)],axis=1)
        loss=float(np.asarray(train.train_on_batch(feed(m)+[batch[None]],np.zeros((1,1)))).ravel()[0])
        if not np.isfinite(loss):raise ValueError('full graph pilot loss invalid')
        losses.append(loss)
    raw=embed(feature,m);normalized(raw);placement_trace(tf,keras,sess,feature,m,out)
    mask_restore(g,m,rs,mod,utils,feature,out)
    save(out/'pilot_complete.json',{'status':'QUALITY_V13_FULL_GRAPH_PILOT_PASS','graph':key,'updates':3,'losses':losses,'wall_seconds':time.monotonic()-started,'statistics':g['statistics'],'test_evaluations_completed':0,'quality_evaluations_completed':0,'weights_reused_for_training':False})
    print('QUALITY_V13_FULL_GRAPH_PILOT_PASS',flush=True)

def training(out,key,seed,qa):
    import numpy as np
    tf,keras,mod,utils,sess,identity=runtime(seed,qa);save(out/'environment.json',identity)
    g=graph(key);m,rs=matrices(g,utils);train,feature=build(g,m,mod,rs)
    save(out/'input_identity.json',{'entity_ids':g['entity_ids'],'role_specific_relation_ids':g['relations'],'statistics':g['statistics'],'source_commit':load(CONFIG)['model']['commit']})
    c=load(CONFIG)['model'];best=None;history=[];started=time.monotonic()
    train_pairs=g['pairs']['train'];batch_size=len(g['entity_ids'])
    for step in range(1,c['updates']+1):
        ratio=batch_size//len(train_pairs)+1
        batch=np.reshape(np.repeat(train_pairs[None],ratio,axis=0),(-1,2));np.random.shuffle(batch);batch=batch[:batch_size]
        batch=np.concatenate([batch,np.random.randint(0,batch_size,batch.shape)],axis=-1)
        loss=float(np.asarray(train.train_on_batch(feed(m)+[batch[None]],np.zeros((1,1)))).ravel()[0])
        if not np.isfinite(loss):raise ValueError('training loss invalid')
        if step%100==0:
            save(out/('progress_update_'+str(step)+'.json'),{'update':step,'loss':loss,'elapsed_seconds':time.monotonic()-started,'test':'DEFERRED'})
            print(key,seed,'update',step,'loss',loss,flush=True)
        if step%c['validation_every']==0:
            raw=embed(feature,m);val=point_ranks(normalized(raw),g['pairs']['validation'],g['targets'])
            score=(val['hits'],val['mrr'],-step)
            r={'update':step,'loss':loss,'validation_hits':val['hits'],'validation_mrr':val['mrr'],'elapsed_seconds':time.monotonic()-started,'test':'DEFERRED'};history.append(r);save(out/('validation_update_'+str(step)+'.json'),r)
            if best is None or score>best[0]:
                best=(score,step,[v.copy() for v in feature.get_weights()],raw.copy())
                with (out/('checkpoint_update_'+str(step)+'.npz')).open('xb') as f:np.savez_compressed(f,**{'w'+str(i):v for i,v in enumerate(best[2])})
            print(key,seed,r,flush=True)
    feature.set_weights(best[2]);raw=embed(feature,m);placement_trace(tf,keras,sess,feature,m,out)
    with (out/'checkpoint.weights.npz').open('xb') as f:np.savez_compressed(f,**{'w'+str(i):v for i,v in enumerate(best[2])})
    if not np.allclose(raw,best[3],atol=1e-6,rtol=0):raise ValueError('best checkpoint recomputation differs')
    selection=capture_projection(raw,g,out/'inputs.npz');save(out/'validation_selection.json',selection)
    # Native CSLS validation is diagnostic only, never checkpoint/projection selection.
    save(out/'native_validation_csls.json',csls_ranks(raw,g['pairs']['validation'],g['targets'],g['sources']))
    mask_restore(g,m,rs,mod,utils,feature,out)
    save(out/'training_complete.json',{'status':'QUALITY_V13_RREA_TRAINING_COMPLETE','graph':key,'seed':seed,'updates':c['updates'],'best_update':best[1],'history':history,'checkpoint_sha256':sha(out/'checkpoint.weights.npz'),'inputs_sha256':sha(out/'inputs.npz'),'validation_selection_sha256':sha(out/'validation_selection.json'),'training_variant':c['variant'],'test_evaluations_completed':0,'official_reproduction_verified':False,'wall_seconds':time.monotonic()-started})
    print('QUALITY_V13_RREA_TRAINING_COMPLETE',flush=True)

def evaluate(out,key,cell,seal_path):
    import numpy as np
    seal=load(seal_path)
    if seal.get('status')!='QUALITY_V13_ALL_REQUIRED_VALIDATION_CHOICES_SEALED' or seal.get('test_evaluations_completed')!=0:raise ValueError('invalid global validation seal')
    record=seal['cells'][cell.name]
    for n,h in record.items():
        if sha(cell/n)!=h:raise ValueError('sealed artifact changed '+n)
    g=graph(key);capture=np.load(cell/'inputs.npz',allow_pickle=False)
    if capture['entity_ids'].tolist()!=g['entity_ids']:raise ValueError('entity identity mismatch')
    hidden=capture['hidden'];basis=capture['basis'];values={'raw':capture['raw'],'hidden':hidden,'16':hidden@basis[:,:16],'32':hidden@basis[:,:32]}
    results={k:point_ranks(v,g['pairs']['test'],g['targets']) for k,v in values.items()}
    results['native_csls']=csls_ranks(capture['raw'],g['pairs']['test'],g['targets'],g['sources'])
    save(out/'test_quality.json',{'status':'QUALITY_V13_SEALED_TEST_COMPLETE','cell':cell.name,'validation_seal_sha256':sha(seal_path),'candidate_scope':'all 15000 targets','evaluation':results,'test_used_for_selection':False,'scores':load(CONFIG)['retrieval']})
    print('QUALITY_V13_SEALED_TEST_COMPLETE',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--job',choices=['engineering','pilot','train','evaluate'],required=True);p.add_argument('--out',required=True);p.add_argument('--graph',choices=['dw','enfr']);p.add_argument('--seed',type=int,default=17);p.add_argument('--cell');p.add_argument('--seal');p.add_argument('--mac-qa',action='store_true');a=p.parse_args()
    verify_bundle();out=contained(a.out);out.mkdir(parents=True,exist_ok=False)
    try:
        if a.job=='engineering':engineering(out,a.seed,a.mac_qa)
        elif a.job=='pilot':pilot(out,a.graph,a.seed,a.mac_qa)
        elif a.job=='train':training(out,a.graph,a.seed,a.mac_qa)
        else:evaluate(out,a.graph,contained(a.cell),contained(a.seal))
    except Exception as e:
        save(out/'STOP.json',{'exception':type(e).__name__,'reason':str(e),'job':a.job});raise
