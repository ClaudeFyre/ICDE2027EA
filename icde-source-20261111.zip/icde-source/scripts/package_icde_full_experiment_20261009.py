"""Build/verify the 2026-10-09 full-experiment handoff bundle.

Whitelist-only: include the本轮 docs, modal module, ICDE scripts, new tests,
toy data, the whole experiments/ tree, and the enumerated results trees.
Exclude OAEI raw dumps, checkpoints, SQLite/WAL, WWW/WSDM result dumps, venv/.runtime.
Modeled on scripts/package_icde_local_pilot.py.
"""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# papers/icde: all本轮 + existing root markdown (small, handoff-readable).
PAPERS_GLOB = "*.md"

SCRIPTS = [
    "run_icde_local_pilot.py",
    "verify_icde_local_replay.py",
    "icde_host_preflight.py",
    "audit_icde_oaei_intake.py",
    "audit_icde_gcn_winners.py",
    "package_icde_local_pilot.py",
    "icde_baseline_suite.py",
    "icde_exp_common.py",
    "icde_e5_planner_harness.py",
    "icde_e5_official_eval.py",
    "build_icde_p1_traces.py",
    "validate_icde_p1_traces.py",
    "run_icde_p1_update_loop.py",
    "run_icde_p1_baseline_compare.py",
    "audit_icde_oaei_v2_intake.py",
    "stream_worker_crash_audit.py",
    "backbones/torch_gcn_align.py",
    "backbones/torch_gcn_local_recompute.py",
]

NEW_TESTS = [
    "test_modal_query.py",
    "test_icde_oaei_intake.py",
]

QUERY_SRC = [
    "src/pkgea/query/modal.py",
    "src/pkgea/query/__init__.py",
]

N05 = Path("nodes/05_icde_query_engine")

# results subtrees to include wholesale (relative to nodes/05_icde_query_engine/results)
RESULTS_WHOLE = [
    "icde_e0_20261009",
    "icde_e1_20261009",
    "icde_e2_20261009",
    "icde_e3_20261009",
    "icde_e4_20261009",
    "icde_e5_20261009",
    "icde_e6_20261009",
    "icde_oaei_v2_20261009",
    "icde_p1_20261009",
    "local_pilot_20261009/merge_verify_20261009",
]

# traces tree: include but exclude the local-only E5 verification trace.
TRACES_DIR = "icde_traces_20261009"
TRACES_EXCLUDE_DIRPARTS = {"controlled_synthetic__seed17__b64"}


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def collect_files():
    files = set()

    # papers/icde root markdown
    papers_dir = ROOT / "papers/icde"
    for p in sorted(papers_dir.glob(PAPERS_GLOB)):
        files.add(p)

    # query module
    for rel in QUERY_SRC:
        files.add(ROOT / rel)

    # scripts
    for rel in SCRIPTS:
        files.add(ROOT / "scripts" / rel)

    # new tests
    for rel in NEW_TESTS:
        files.add(ROOT / "tests" / rel)

    # toy data
    toy = ROOT / "data/toy/exact_world_minimal"
    for p in sorted(toy.iterdir()):
        if p.is_file():
            files.add(p)

    # experiments whole tree (incl _common)
    exp = ROOT / N05 / "experiments"
    for p in sorted(exp.rglob("*")):
        if p.is_file():
            files.add(p)

    # results whole subtrees
    results = ROOT / N05 / "results"
    for sub in RESULTS_WHOLE:
        d = results / sub
        for p in sorted(d.rglob("*")):
            if p.is_file():
                files.add(p)

    # traces: include, but drop the local-only E5 verification trace dir
    traces = results / TRACES_DIR
    for p in sorted(traces.rglob("*")):
        if not p.is_file():
            continue
        rel_parts = p.relative_to(traces).parts
        if rel_parts and rel_parts[0] in TRACES_EXCLUDE_DIRPARTS:
            continue
        files.add(p)

    # node-level handoff files
    files.add(ROOT / N05 / "status.toml")
    files.add(ROOT / N05 / "README.md")
    files.add(results / "icde_full_acceptance_20261009.json")

    # drop nonexistent (safety), sort
    existing = sorted(p for p in files if p.is_file())
    return existing


def verify(path):
    with zipfile.ZipFile(path) as bundle:
        manifest = json.loads(bundle.read("BUNDLE_MANIFEST.json"))
        on_disk = set(bundle.namelist())
        declared = set(manifest["files"]) | {"BUNDLE_MANIFEST.json"}
        if on_disk != declared:
            raise ValueError(
                f"bundle inventory mismatch: only-in-zip={on_disk - declared} only-in-manifest={declared - on_disk}"
            )
        for name, checksum in manifest["files"].items():
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError(f"unsafe bundle path: {name}")
            if hashlib.sha256(bundle.read(name)).hexdigest() != checksum:
                raise ValueError(f"checksum mismatch: {name}")
        # guard: no raw OAEI dump / checkpoint / sqlite slipped in
        for name in bundle.namelist():
            low = name.lower()
            if ("oaei_kg_v2" in low and name.endswith((".rdf.xml", ".xml")) and "/reference/" not in low):
                raise ValueError(f"raw OAEI dump leaked into bundle: {name}")
            if low.endswith((".sqlite", ".db", ".wal", ".ckpt", ".pt", ".pth")):
                raise ValueError(f"excluded artifact leaked: {name}")
    return {
        "verified": True,
        "files": len(manifest["files"]),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--verify", type=Path)
    args = parser.parse_args()
    if args.verify:
        print(json.dumps(verify(args.verify), indent=2))
        return
    if args.output is None or args.output.exists():
        raise ValueError("choose a fresh bundle output")
    files = collect_files()
    manifest = {
        "format": "icde-full-experiment-bundle-v1",
        "created": "2026-10-09",
        "files": {
            p.relative_to(ROOT).as_posix(): _sha(p) for p in files
        },
        "traces_note": "official traces = 4 groups x seeds {17,23,31} x budgets {64,256} = 24; controlled_synthetic__seed17__b64 (E5 local-only) excluded.",
        "excluded": [
            "OAEI raw KG dumps (data/raw/oaei_kg_v2_20261009; license unconfirmed)",
            "all checkpoints / model weights (.ckpt/.pt/.pth)",
            "SQLite / WAL (.sqlite/.db/.wal)",
            "WWW/WSDM result dumps",
            "venv / .runtime local Python environments",
        ],
        "boundary": "本机正确性 + intake 冻结已闭合；价值信号关卡与 C1/C2/C3 研究验收未闭合。计数类指标为硬证据，墙钟 informal。",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED) as bundle:
        for path in files:
            bundle.write(path, path.relative_to(ROOT).as_posix())
        bundle.writestr("BUNDLE_MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
    result = verify(args.output)
    args.output.with_suffix(".manifest.json").write_text(
        json.dumps({**manifest, "verification": result}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
