"""Finite incremental fixtures for the inference-control runner."""

import json
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from icde_gate_comparison_runner import (
    POLICIES, ROOT, actual_checkpoints, prepare_settings, run_case, write_json,
)
from icde_online_execution import PreparedQuery


class Clock:
    def __init__(self):
        self.value = 0.

    def __call__(self):
        return self.value


class Kernel:
    candidates = ("a", "b")
    edge_indices = (0,)

    def __init__(self, *, clock=None, score_delay=0.):
        self.score_rows = []
        self.event_rows = []
        self.clock, self.score_delay = clock, score_delay

    def scores(self, states):
        self.score_rows.append(len(states))
        if self.clock:
            self.clock.value += self.score_delay
        result = np.zeros((len(states), 2), dtype=np.float64)
        result[:, 0] = 1.
        return result

    def ambiguity_indicators(self, q, low, high, uniforms, nominal_scores=None):
        if nominal_scores is None or len(nominal_scores) != len(uniforms):
            raise AssertionError("event call did not reuse original nominal scores")
        self.event_rows.append(len(uniforms))
        return np.zeros(len(uniforms), dtype=np.bool_)


class ComparisonRunnerTests(unittest.TestCase):
    def settings(self, **extra):
        return prepare_settings({"sample_count": 256,
                                 "work_model": {"nominal_candidate_units": 16,
                                                "interval_candidate_units": 1}, **extra})

    def query(self, kernel=None, scope=1.):
        return PreparedQuery("toy", "q", "revision", kernel or Kernel(),
                             np.array([.5]), np.array([0.]), np.array([1.]), scope,
                             {"cost_model": {"original_incidence_entries": 0,
                                             "interval_incidence_entries": 0}})

    def test_nominal_policies_stop_early_without_event_or_unused_scoring(self):
        for policy in ("normal_nominal", "ppr_nominal", "eb_nominal"):
            query = self.query()
            row = run_case(query, self.settings(), policy, 97)
            self.assertTrue(row["certified"])
            self.assertEqual(row["objective"], "nominal")
            self.assertFalse(row["robust_certified"])
            self.assertEqual(query.kernel.event_rows, [])
            self.assertEqual(sum(query.kernel.score_rows), row["worlds_generated"])
            self.assertLess(row["worlds_generated"], 256)
            self.assertEqual(row["nominal_delta"], .05)

    def test_original_ppr_allocation_is_used_and_not_repurposed_as_a_gap(self):
        row = run_case(self.query(), self.settings(), "ppr_nominal", 97)
        self.assertEqual(row["ppr_final_test"]["prior"], "uniform")
        self.assertEqual(row["ppr_final_test"]["allocation"], "jain_mode")
        self.assertIsNone(row["final_lower_gap"])
        self.assertEqual(row["event_beta_total"], 0.)

    def test_robust_scope_and_event_policies_keep_different_evidence_contracts(self):
        for prefix in ("normal", "eb"):
            scope = run_case(self.query(), self.settings(), prefix + "_scope", 109)
            query = self.query()
            event = run_case(query, self.settings(), prefix + "_event", 109)
            self.assertFalse(scope["certified"])
            self.assertEqual(scope["nominal_delta"], .05)
            self.assertTrue(event["robust_certified"])
            self.assertEqual(event["nominal_delta"], .025)
            self.assertEqual(event["event_beta_total"], .025)
            self.assertEqual(sum(query.kernel.event_rows), event["event_samples_used"])
            self.assertLessEqual(event["event_samples_used"], event["samples_used"])
            self.assertLessEqual(event["work_used"], event["work_budget"])

    def test_static_rejection_computes_no_hidden_event_rows(self):
        for policy in ("normal_event", "eb_event"):
            query = self.query()
            row = run_case(query, self.settings(interval_work_weight=100000.), policy, 109)
            self.assertFalse(row["certified"])
            self.assertEqual(query.kernel.event_rows, [])
            self.assertEqual(row["samples_used"], 256)
            self.assertGreater(row["event_admission_rejections"], 0)

    def test_extra_budget_checkpoint_is_included_in_the_eb_union(self):
        settings = self.settings(sample_count=4096, budget_fraction=.25)
        self.assertIn(1024, actual_checkpoints(settings))
        row = run_case(self.query(), self.settings(budget_fraction=.5), "eb_scope", 127)
        self.assertIn(128, row["inference_rule"]["checkpoints"])
        self.assertIn(128, row["actual_nominal_checkpoints"])

    def test_policies_have_identical_paired_prefixes_even_when_stops_differ(self):
        rows = [run_case(self.query(), self.settings(), policy, 127) for policy in POLICIES]
        prefixes = [next(step for step in row["trace"] if step["nominal_samples"] == 32)
                    for row in rows]
        self.assertEqual(len({row["rng_seed_hex"] for row in rows}), 1)
        self.assertEqual(len({step["uniform_prefix_sha256"] for step in prefixes}), 1)
        self.assertEqual(len({step["winner_prefix_sha256"] for step in prefixes}), 1)

    def test_late_blocks_do_not_publish_success(self):
        clock = Clock()
        query = self.query(Kernel(clock=clock, score_delay=2.), scope=0.)
        row = run_case(query, self.settings(deadline_seconds=1.), "normal_scope", 97, clock=clock)
        self.assertFalse(row["certified"])
        self.assertEqual(row["status"], "deadline_postblock")
        self.assertEqual(row["worlds_generated"], 32)
        self.assertEqual(len(row["winner_indices"]), 32)

    def test_atomic_case_output_is_new_and_independently_readable(self):
        temporary_root = ROOT / "tmp"
        temporary_root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="icde_comparison_test_", dir=temporary_root) as name:
            path = Path(name) / "case.json"
            write_json(path, {"completed": True, "winner_counts": [32, 0]})
            self.assertTrue(json.loads(path.read_text("utf-8"))["completed"])
            self.assertFalse(path.with_name("case.json.pending").exists())
            with self.assertRaises(FileExistsError):
                write_json(path, {"completed": False})


if __name__ == "__main__":
    unittest.main()
