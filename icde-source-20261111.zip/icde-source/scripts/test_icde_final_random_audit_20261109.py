"""Check finite-population coverage, including outcome-dependent censoring."""
from itertools import combinations
import unittest
from icde_final_random_audit_20261109 import finite_interval


class FiniteCoverage(unittest.TestCase):
    def test_exhaustive_srs_coverage(self):
        N,n,alpha=9,4,.1
        for true_total in range(N+1):
            covered=outer_covered=0;total=0
            for sample in combinations(range(N),n):
                positives=[i for i in sample if i<true_total]
                x=len(positives);lo,hi=finite_interval(N,n,x,x,alpha)
                # Hide all positive labels on odd-numbered IDs. Censoring may
                # depend arbitrarily on label/structure; it is not MAR.
                hidden=sum(i%2 for i in positives)
                a,b=finite_interval(N,n,x-hidden,x,alpha)
                covered+=lo<=true_total<=hi;outer_covered+=a<=true_total<=b;total+=1
                self.assertLessEqual(a,lo);self.assertGreaterEqual(b,hi)
            self.assertGreaterEqual(covered/total,1-alpha)
            self.assertGreaterEqual(outer_covered/total,1-alpha)

    def test_all_unknown_remains_uninformative(self):
        self.assertEqual(finite_interval(259,40,0,40),[0,259])
        with self.assertRaises(ValueError):finite_interval(259,40,5,4)


if __name__=='__main__':unittest.main()
