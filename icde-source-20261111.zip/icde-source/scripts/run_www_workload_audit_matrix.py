"""Run the twelve-cell WWW workload-transfer and storage audit."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "nodes/04_www_distributional/results/workload_generalization"
PYTHON = Path(r"D:\miniconda\envs\baokai\python.exe")
CELLS = tuple(
    (graph, family, dependence)
    for graph in ("dw", "enfr", "eventea")
    for family in ("gcn", "relation")
    for dependence in ("independent", "structural")
)


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def checkpoint(graph: str, family: str) -> Path:
    stem = "gcn_align" if family == "gcn" else "relation_align"
    root = "nodes/04_www_distributional/checkpoints/scale500"
    if family == "relation" and graph != "eventea":
        root = "nodes/03_wsdm/checkpoints/scale500"
    return ROOT / root / f"{stem}_{graph}_scale500_s17.pt"


def profile(graph: str, dependence: str) -> Path:
    graph_name = {"dw": "openea-d-w", "enfr": "openea-en-fr", "eventea": "eventea-en-fr"}[graph]
    suffix = "independent-s17" if dependence == "independent" else "structural-c55-s17"
    return ROOT / "data/interim" / f"{graph_name}-probe-q500-a512-attributes-{suffix}"


def task(cell: tuple[str, str, str], worlds: int) -> dict[str, object]:
    graph, family, dependence = cell
    slug = "_".join(cell)
    output = RESULTS / f"www_workload_audit_{slug}_v2.json"
    command = [
        str(PYTHON), "scripts/run_www_workload_audit.py",
        str(output.relative_to(ROOT)),
        "--checkpoint", str(checkpoint(graph, family).relative_to(ROOT)),
        "--profile", str(profile(graph, dependence).relative_to(ROOT)),
        "--cell", slug,
        "--worlds", str(worlds),
    ]
    return {
        "cell": list(cell),
        "checkpoint": str(checkpoint(graph, family)),
        "checkpoint_sha256": sha256(checkpoint(graph, family)) if checkpoint(graph, family).is_file() else None,
        "profile": str(profile(graph, dependence)),
        "output": str(output),
        "command": command,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--worlds", type=int, default=2048)
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--cell", action="append", help="optional slug filter")
    args = parser.parse_args()
    selected = [cell for cell in CELLS if not args.cell or "_".join(cell) in args.cell]
    tasks = [task(cell, args.worlds) for cell in selected]
    missing = [item["checkpoint"] for item in tasks if not Path(item["checkpoint"]).is_file()]
    missing += [item["profile"] for item in tasks if not Path(item["profile"]).is_dir()]
    if not PYTHON.is_file():
        missing.append(str(PYTHON))
    if missing:
        raise FileNotFoundError("missing audit inputs: " + ", ".join(missing))
    implementation = ROOT / "scripts/run_www_workload_audit.py"
    manifest = {
        "schema_version": "pkgea-www-workload-transfer-matrix-v2",
        "implementation_sha256": sha256(implementation),
        "worlds": args.worlds,
        "tasks": tasks,
        "preflight": {"status": "pass", "task_count": len(tasks)},
    }
    RESULTS.mkdir(parents=True, exist_ok=True)
    manifest_path = RESULTS / "task_manifest_v2.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps(manifest["preflight"], indent=2), flush=True)
    if args.preflight_only:
        return 0
    for item in tasks:
        output = Path(item["output"])
        if output.is_file():
            payload = json.loads(output.read_text(encoding="utf-8"))
            if all(payload.get("validation", {}).values()):
                print(f"[workload-matrix] skip validated {item['cell']}", flush=True)
                continue
            raise RuntimeError(f"existing audit output failed validation: {output}")
        print(f"[workload-matrix] start {item['cell']}", flush=True)
        process = subprocess.run(item["command"], cwd=ROOT)
        if process.returncode:
            return int(process.returncode)
    print("WWW WORKLOAD AUDIT MATRIX COMPLETE", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
