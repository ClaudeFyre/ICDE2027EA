"""Validate manifests and compare deterministic evidence across host reruns."""

import argparse
import hashlib
import json
from pathlib import Path


def validate(root):
    manifest = json.loads((root / "manifest.json").read_text())
    for name, expected in manifest.items():
        path = root / name
        if path.parent != root or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"invalid manifest entry: {name}")
    return json.loads((root / "summary.json").read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("reference", type=Path)
    parser.add_argument("rerun", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("use a fresh output")
    reference, rerun = validate(args.reference), validate(args.rerun)
    fields = (
        "config",
        "snapshot",
        "source_hashes",
        "oracle",
        "counterexamples",
        "precision_counterexample",
        "controlled_update_trace",
        "toy_world_sensitivity",
        "acceptance",
    )
    checks = {key: reference[key] == rerun[key] for key in fields}
    checks["raw_worlds"] = (args.reference / "worlds.jsonl").read_bytes() == (
        args.rerun / "worlds.jsonl"
    ).read_bytes()
    checks["same_run_names"] = reference["runs"].keys() == rerun["runs"].keys()
    for name in reference["runs"]:
        checks[name] = all(
            reference["runs"][name][key] == rerun["runs"].get(name, {}).get(key)
            for key in ("results", "work", "cache")
        )
    result = {
        "passed": all(checks.values()),
        "checks": checks,
        "boundary": "Wall-clock and host metadata intentionally differ; evidence and physical work must agree.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
