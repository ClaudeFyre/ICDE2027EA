"""Does certified coverage survive a realistic candidate pool?

Coverage is the paper's efficiency headline and candidate-pool size controls it
directly: more candidates means more near-ties, and a near-tie is exactly what
the certificate cannot separate.  The reported 92.5% comes from a 1,012-target
pool built from aligned pairs, so the obvious question is what happens at
realistic pool sizes.

Pools are nested by construction, so one set of moments computed at the full
pool serves every smaller pool.  That is what makes this sweep cost about as
much as a single run rather than one run per pool size.

Full FP16 is certified alongside the allocation rules.  The certificate does not
care how the index was compressed --- it only needs a per-target distortion
bound --- so including it tests whether certification is a correctness layer
over interchangeable compression schemes rather than a feature of one allocator.
"""

from __future__ import annotations

import time

import numpy as np

from pkgea.www_fsl import gaussian_distance_matrix, margin_criticalities
from run_www_equal_budget import (
    atomic_write_json, full_payload, load_full_payload, load_representation_payload,
    representation_payload,
)
from run_www_workload_audit import split_metrics
from www_budget_frontier import (
    RULES, certificate_report, summarize_slack, decision_slack, target_distortions,
)
from www_fixed_index_audit import allocation_scores, digest, match_bytes, passes


def truth_positions_for(targets, sources, truth):
    index = {target: position for position, target in enumerate(targets)}
    return np.asarray([index[truth[source]] for source in sources], dtype=np.int64)


def run_pool_frontier(*, output, cell, means, covariances, selection_timing, moments,
                      splits, sources, full_targets, truth, metadata, max_error,
                      budget_fraction, candidate_limits):
    """``means``/``covariances`` must cover sources followed by the FULL pool."""

    started = time.perf_counter()
    source_count = len(sources)
    limits = sorted({int(v) for v in candidate_limits})
    if max(limits) > len(full_targets):
        raise RuntimeError(
            f"limit {max(limits)} exceeds the {len(full_targets)}-entity target pool"
        )
    required = {truth[source] for source in sources}
    if min(limits) < len(required):
        raise RuntimeError("smallest pool cannot hold every test truth")

    pools = {}
    for limit in limits:
        kept = set(required)
        for target in full_targets:
            if len(kept) == limit:
                break
            kept.add(target)
        ordered = tuple(t for t in full_targets if t in kept)
        if len(ordered) != limit or not required.issubset(ordered):
            raise RuntimeError(f"truth-preserving construction failed at {limit}")
        pools[limit] = ordered

    position = {target: i for i, target in enumerate(full_targets)}
    results = {}
    for limit in limits:
        targets = pools[limit]
        rows = np.asarray([source_count + position[t] for t in targets])
        tm_full, tc_full = means[rows], covariances[rows]
        cell_metadata = {**metadata, "candidate_count": limit}
        full = full_payload(tm_full, tc_full, dtype=np.dtype("float32"),
                            metadata=cell_metadata)
        tm, tc = load_full_payload(full)

        selection = splits["selection"]
        reference_selection = gaussian_distance_matrix(
            np.concatenate((means[selection], tm)),
            np.concatenate((covariances[selection], tc)),
            len(means[selection]),
        )
        criticalities = np.asarray(
            margin_criticalities(reference_selection)["entity_criticalities"]
        )[len(means[selection]):]
        scores = dict(zip(RULES, allocation_scores(tc, criticalities)))

        payloads, selection_maps = {}, {}
        budget = int(budget_fraction * len(full))
        for rule in RULES:
            try:
                payload, mapping, row = match_bytes(tm, tc, scores[rule],
                                                    cell_metadata, budget)
            except RuntimeError as error:
                selection_maps[rule] = {"infeasible": str(error)}
                continue
            payloads[rule] = payload
            selection_maps[rule] = row
            if rule == "margin_w2":
                payloads["margin_fp16"], _ = representation_payload(
                    tm, tc, mapping, cell_metadata, dtype=np.dtype("float16")
                )
        # Not byte-matched: full FP16 is whatever it is, and is certified anyway.
        payloads["full_fp16"] = full_payload(tm, tc, dtype=np.dtype("float16"),
                                             metadata=cell_metadata)
        hashes = {name: digest(p) for name, p in payloads.items()}

        truths = truth_positions_for(targets, sources, truth)
        stages = {}
        for label, seed in (("authorization", 59), ("final_test", 71)):
            query_means, query_covariances, timing = moments(seed, label)
            section = splits[label]
            qm, qc = query_means[section], query_covariances[section]
            reference = gaussian_distance_matrix(
                np.concatenate((qm, tm)), np.concatenate((qc, tc)), len(qm)
            )
            stage_rows = {}
            for name, payload in payloads.items():
                if digest(payload) != hashes[name]:
                    raise RuntimeError("frozen artifact digest mismatch")
                loader = (load_full_payload if name.startswith("full_")
                          else load_representation_payload)
                index_means, index_covariances = loader(payload)
                estimate = gaussian_distance_matrix(
                    np.concatenate((qm, index_means)),
                    np.concatenate((qc, index_covariances)), len(qm),
                )
                row = split_metrics(reference, estimate, truths[section], sources[section])
                row["passes"] = passes(row, max_error)
                row["artifact_bytes"] = len(payload)
                row["artifact_sha256"] = hashes[name]
                row["slack"] = summarize_slack(decision_slack(reference, estimate))
                deltas = target_distortions(tm, tc, index_means, index_covariances)
                report = certificate_report(reference, estimate, deltas)
                if report["certified_disagreeing_with_full_index"]:
                    raise RuntimeError(
                        f"certificate unsound in {cell} {label} pool={limit} {name}"
                    )
                row["certificate"] = report
                stage_rows[name] = row
            stages[label] = {"methods": stage_rows, "moment_timing": timing}
            flips = {n: r["certificate"]["coverage"] for n, r in stage_rows.items()}
            print(f"[pool] {cell} pool={limit} {label} coverage: "
                  + str({k: round(v, 3) for k, v in flips.items()}), flush=True)

        results[str(limit)] = {
            "candidate_count": limit,
            "full_fp32_bytes": len(full),
            "selection": selection_maps,
            "stages": stages,
        }

    atomic_write_json(output, {
        "schema_version": "www-pool-frontier-v1",
        "cell": cell,
        "inputs": metadata,
        "protocol": {
            "budget_fraction": budget_fraction,
            "candidate_limits": limits,
            "full_pool_size": len(full_targets),
            "rules": [*RULES, "margin_fp16", "full_fp16"],
            "pools_are_nested": True,
            "moments_computed_once_at_full_pool": True,
            "per_query_certificate": True,
        },
        "pools": results,
        "timing": {
            "selection_moments": selection_timing,
            "total_seconds": time.perf_counter() - started + selection_timing["total_seconds"],
        },
    })
