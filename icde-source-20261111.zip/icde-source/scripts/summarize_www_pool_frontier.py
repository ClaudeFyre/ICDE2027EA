"""Validate and summarize the twelve-cell WWW candidate-pool sweep."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from run_www_pool_matrix import RESULTS
from run_www_workload_audit_matrix import ROOT


BASELINE = ROOT / "nodes/04_www_distributional/results/certificate_v1"
METHODS = ("frob", "uniform_w2", "margin_w2", "margin_fp16", "full_fp16")
STAGES = ("authorization", "final_test")
SHARED_LIMITS = (512, 1012, 2000, 3000)
RECOVERY_CELLS = (
    "eventea_gcn_independent", "eventea_gcn_structural",
    "eventea_relation_independent", "eventea_relation_structural",
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def check_baseline(cell: str, stage: str, method: str,
                   observed: dict, frozen: dict) -> None:
    """The 1,012-target point must exactly replay the earlier certificate run."""
    for field in ("queries", "certified", "certified_disagreeing_with_full_index"):
        require(observed["certificate"][field] == frozen["certificate"][field],
                f"1,012 baseline mismatch: {cell} {stage} {method} {field}")
    for field in ("flipped_query_count", "artifact_bytes", "artifact_sha256"):
        require(observed[field] == frozen[field],
                f"1,012 baseline mismatch: {cell} {stage} {method} {field}")


def check_baseline_selection(cell: str, observed: dict, frozen: dict) -> None:
    """The allocation is part of replay, even when ranking metrics agree."""
    for method in ("frob", "uniform_w2", "margin_w2"):
        old = frozen["selection"][f"0.8:{method}"]
        new = observed["selection"][method]
        require(new["representations"] == old["representations"],
                f"1,012 baseline mismatch: {cell} {method} representation map")


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def recovery_paths(results: Path) -> dict[str, Path]:
    """Verify the stopped run is intact before using separately rerun cells."""
    recovery = results / "recovery_v1"
    manifest_path = recovery / "manifest.json"
    require(manifest_path.is_file(), f"missing recovery manifest {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    require(manifest["schema_version"] == "www-pool-recovery-v1",
            "wrong recovery manifest schema")
    require(manifest["original_manifest_sha256"] == file_sha256(results / "manifest.json"),
            "original pool manifest changed after STOP")
    require(set(manifest["original_cells"]) == set(RECOVERY_CELLS),
            "recovery must name exactly the four EventEA cells")
    for name, expected in manifest["implementations"].items():
        require(file_sha256(ROOT / name) == expected,
                f"recovery implementation changed: {name}")
    for cell in RECOVERY_CELLS:
        require(manifest["original_cells"][cell] == file_sha256(results / f"{cell}.json"),
                f"stopped result changed after recovery began: {cell}")
    return {cell: recovery / f"{cell}.json" for cell in RECOVERY_CELLS}


def validate_smoke(results: Path = RESULTS, baseline: Path = BASELINE) -> None:
    manifest_path = results / "smoke_manifest.json"
    require(manifest_path.is_file(), f"missing smoke manifest {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    require(manifest["smoke"] and len(manifest["tasks"]) == 1,
            "smoke manifest must name one cell")
    task = manifest["tasks"][0]
    require(task["candidate_limits"] == [512, 1012],
            "smoke must use only the 512 and 1,012 pools")
    path = ROOT / task["output"]
    require(path.is_file(), f"missing smoke result {path}")
    cell = json.loads(path.read_text(encoding="utf-8"))
    require(cell["schema_version"] == "www-pool-frontier-v1", "wrong smoke schema")
    require(cell["cell"] == task["cell"] and cell["protocol"]["candidate_limits"] == [512, 1012],
            "smoke result does not match its frozen manifest")
    require(cell["inputs"]["checkpoint_sha256"] == task["checkpoint_sha256"],
            "smoke checkpoint differs from the manifest")
    require(cell["inputs"]["dataset_content_digest"] == task["content_digest"],
            "smoke dataset differs from the manifest")
    frozen_path = baseline / f"{task['cell']}.json"
    require(frozen_path.is_file(), f"missing frozen baseline {frozen_path}")
    frozen = json.loads(frozen_path.read_text(encoding="utf-8"))
    for limit in (512, 1012):
        pool = cell["pools"][str(limit)]
        for stage in STAGES:
            require(set(pool["stages"][stage]["methods"]) == set(METHODS),
                    f"smoke methods incomplete at pool={limit} {stage}")
            for method, row in pool["stages"][stage]["methods"].items():
                require(row["certificate"]["certified_disagreeing_with_full_index"] == 0,
                        f"CERTIFICATE UNSOUND: smoke pool={limit} {stage} {method}")
                if limit == 1012 and method != "full_fp16":
                    old = frozen["stages"][stage]["methods"][f"0.8:{method}"]
                    check_baseline(task["cell"], stage, method, row, old)


def summarize(results: Path = RESULTS, baseline: Path = BASELINE,
              *, use_recovery: bool = False) -> dict:
    manifest_path = results / "manifest.json"
    require(manifest_path.is_file(), f"missing {manifest_path}; run preflight first")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    tasks = manifest["tasks"]
    require(len(tasks) == 12, f"expected 12 cells, found {len(tasks)}")
    overrides = recovery_paths(results) if use_recovery else {}
    totals = {label: {method: {"certified": 0, "queries": 0, "cells": 0,
                              "byte_ratios": []} for method in METHODS}
              for label in (*map(str, SHARED_LIMITS), "full")}
    full_pool_by_cell = {}

    for task in tasks:
        cell_name = task["cell"]
        path = overrides.get(cell_name, ROOT / task["output"])
        require(path.is_file(), f"missing completed cell {path}")
        cell = json.loads(path.read_text(encoding="utf-8"))
        require(cell["schema_version"] == "www-pool-frontier-v1",
                f"wrong result schema in {cell_name}")
        require(cell["cell"] == cell_name, f"cell label mismatch in {path}")
        require(cell["inputs"]["checkpoint_sha256"] == task["checkpoint_sha256"],
                f"checkpoint changed in {cell_name}")
        require(cell["inputs"]["dataset_content_digest"] == task["content_digest"],
                f"dataset changed in {cell_name}")
        limits = task["candidate_limits"]
        require(cell["protocol"]["candidate_limits"] == limits,
                f"pool plan changed in {cell_name}")
        require(sorted(map(int, cell["pools"])) == limits,
                f"pool outputs incomplete in {cell_name}")
        require(1012 in limits, f"missing 1,012 baseline in {cell_name}")
        full_pool_by_cell[cell_name] = max(limits)
        frozen_path = baseline / f"{cell_name}.json"
        require(frozen_path.is_file(), f"missing frozen baseline {frozen_path}")
        frozen = json.loads(frozen_path.read_text(encoding="utf-8"))
        check_baseline_selection(cell_name, cell["pools"]["1012"], frozen)

        for limit in limits:
            pool = cell["pools"][str(limit)]
            require(pool["candidate_count"] == limit,
                    f"candidate count mismatch in {cell_name} pool={limit}")
            label = "full" if limit == max(limits) else str(limit)
            require(label in totals, f"unexpected pool {limit} in {cell_name}")
            stage_rows = [pool["stages"][stage]["methods"] for stage in STAGES]
            require(set(stage_rows[0]) == set(stage_rows[1]),
                    f"method set changed between stages in {cell_name} pool={limit}")

            for method in METHODS:
                if method not in stage_rows[0]:
                    require(method in ("frob", "uniform_w2", "margin_w2", "margin_fp16"),
                            f"full FP16 missing in {cell_name} pool={limit}")
                    continue  # An allocation may be infeasible at a byte budget.
                rows = [stage_rows[index][method] for index in range(2)]
                require(rows[0]["artifact_sha256"] == rows[1]["artifact_sha256"],
                        f"index not frozen in {cell_name} pool={limit} {method}")
                group = totals[label][method]
                group["cells"] += 1
                group["byte_ratios"].append(
                    rows[0]["artifact_bytes"] / pool["full_fp32_bytes"]
                )
                for stage, row in zip(STAGES, rows, strict=True):
                    certificate = row["certificate"]
                    require(certificate["certified_disagreeing_with_full_index"] == 0,
                            f"CERTIFICATE UNSOUND: {cell_name} pool={limit} {stage} {method}")
                    require(certificate["queries"] == 100,
                            f"query split changed in {cell_name} pool={limit} {stage}")
                    group["certified"] += certificate["certified"]
                    group["queries"] += certificate["queries"]
                    if limit == 1012 and method != "full_fp16":
                        old = frozen["stages"][stage]["methods"][f"0.8:{method}"]
                        check_baseline(cell_name, stage, method, row, old)

    by_pool = {}
    for label, methods in totals.items():
        by_pool[label] = {}
        for method, row in methods.items():
            by_pool[label][method] = {
                "cells": row["cells"],
                "queries": row["queries"],
                "certified": row["certified"],
                "coverage": row["certified"] / row["queries"] if row["queries"] else None,
                "mean_byte_ratio_vs_full_fp32": (
                    sum(row["byte_ratios"]) / len(row["byte_ratios"])
                    if row["byte_ratios"] else None
                ),
            }

    return {
        "status": ("PASS_WWW_POOL_FRONTIER_RECOVERY" if use_recovery
                   else "PASS_WWW_POOL_FRONTIER"),
        "cells": len(tasks),
        "baseline_1012_reproduction": "PASS",
        "provenance": ({"original_cells": 8, "recovered_eventea_cells": 4,
                        "recovery_manifest": "recovery_v1/manifest.json"}
                       if use_recovery else {"original_cells": 12}),
        "full_pool_by_cell": full_pool_by_cell,
        "by_pool": by_pool,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--recovery", action="store_true",
                        help="validate eight original cells plus four corrected EventEA reruns")
    args = parser.parse_args()
    try:
        if args.smoke:
            validate_smoke()
            print("PASS: smoke certificate sound; 1,012 baseline reproduced")
            return 0
        summary = summarize(use_recovery=args.recovery)
    except RuntimeError as error:
        print(f"STOP: {error}")
        return 2
    destination = RESULTS / "recovery_v1" if args.recovery else RESULTS
    destination.joinpath("summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8",
        newline="\n",
    )
    lines = ["# WWW candidate-pool scaling", "",
             "All 12 cells passed; the 1,012-target baseline reproduces the frozen certificate run.",
             "No certified answer disagreed with the full index.", "",
             "| Pool | Method | Cells | Certified / queries | Coverage | Mean bytes / full FP32 |",
             "| --- | --- | ---: | ---: | ---: | ---: |"]
    if args.recovery:
        lines[4:4] = [
            "Four EventEA cells were rerun with the frozen 1,012-target moment "
            "reduction isolated from added distractors. The original stopped "
            "results remain intact; see recovery_v1/manifest.json.", "",
        ]
    for label, methods in summary["by_pool"].items():
        for method, row in methods.items():
            coverage = f"{row['coverage']:.1%}" if row["coverage"] is not None else "infeasible"
            ratio = (f"{row['mean_byte_ratio_vs_full_fp32']:.3f}"
                     if row["mean_byte_ratio_vs_full_fp32"] is not None else "—")
            lines.append(f"| {label} | {method} | {row['cells']} | "
                         f"{row['certified']} / {row['queries']} | {coverage} | {ratio} |")
    destination.joinpath("summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8",
                                             newline="\n")
    print("PASS: 12 cells, frozen 1,012 baseline, zero certificate violations")
    print(f"Summary: {destination / 'summary.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
