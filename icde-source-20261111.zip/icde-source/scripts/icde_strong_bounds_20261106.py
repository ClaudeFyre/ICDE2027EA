"""Independent standard probability bounds and product-law transports.

This module does not modify or import the frozen ScopeRace inference modules.
It implements standard beta-binomial mixture confidence sequences, protected
fixed-look Clopper--Pearson intervals, and standard divergence inequalities.
It is NOT an implementation of all procedures in Voracek (NeurIPS 2024).

Risk contract: with K fixed categories, a mixture interval receives delta/K;
its single two-sided Ville event protects both endpoints at every time.  A
fixed-look CP endpoint receives delta/(2*K*number_of_predeclared_looks).
Candidates not yet observed remain in K.  All transport choices below reuse
the SAME simultaneous probability-interval event and deterministic model box.
No calibration, factual correctness, or empirical optimality is inferred.

Uniform and Jeffreys beta-binomial marginal likelihoods are exact rationals.
Bisection compares exact integer powers and returns outward endpoints.  SciPy
is used only to initialize CP inversion: an exact binomial-tail check validates
every returned endpoint, with exact bisection as a fallback.  Product bounds
use directed Decimal arithmetic.  No experiment or file-writing entrypoint is
provided.

References: Jain et al., AISTATS 2022 (PPR/mixture confidence sequences);
Clopper and Pearson, 1934 (fixed-look binomial inversion);
Dvijotham et al., ICLR 2020 (divergence-based smoothed-model certification).
"""

from __future__ import annotations

from collections import Counter
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction
from functools import lru_cache
import math
from numbers import Integral

import numpy as np


PRECISION = 110
DEFAULT_BISECTION_STEPS = 60


def _risk(value, *, tail=False):
    if isinstance(value, bool):
        raise ValueError("risk cannot be Boolean")
    # A decimal spelling such as 0.05 denotes that declared risk, not its
    # slightly larger binary64 representation. Fractions remain exact.
    try:
        result = Fraction(str(value)) if isinstance(value, (float, np.floating)) else Fraction(value)
    except (ValueError, TypeError, ZeroDivisionError, OverflowError) as error:
        raise ValueError("invalid risk") from error
    if not 0 < result < (Fraction(1, 2) if tail else 1):
        raise ValueError("risk must lie in (0, 1/2)" if tail else "risk must lie in (0, 1)")
    return result


def _integer(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return int(value)


def _bernoulli_counts(successes, n):
    n = _integer(n, "n")
    successes = _integer(successes, "successes")
    if successes > n:
        raise ValueError("successes cannot exceed n")
    return successes, n


def _fraction_float(value, upward):
    result = float(value)
    represented = Fraction.from_float(result)
    if (upward and represented < value) or (not upward and represented > value):
        result = math.nextafter(result, math.inf if upward else -math.inf)
    return result


def _decimal_float(value, upward):
    if value.is_infinite():
        return math.inf if value > 0 else -math.inf
    result = float(value)
    if math.isinf(result):
        return result
    represented = Decimal.from_float(result)
    if (upward and represented < value) or (not upward and represented > value):
        result = math.nextafter(result, math.inf if upward else -math.inf)
    return result


def _decimal(value):
    return Decimal.from_float(float(value))


def _sqrt_lower(value):
    return Decimal(0) if value == 0 else max(Decimal(0), value.sqrt().next_minus())


def _sqrt_upper(value):
    return Decimal(0) if value == 0 else value.sqrt().next_plus()


def _positive_integer_power(value, exponent):
    """Directed products under the caller's rounding context."""
    result = Decimal(1)
    while exponent:
        if exponent & 1:
            result *= value
        exponent >>= 1
        if exponent:
            value *= value
    return result


@lru_cache(maxsize=65536)
def mixture_marginal(successes, n, prior="uniform"):
    """Exact integral of p**s * (1-p)**(n-s) against the named Beta prior."""
    successes, n = _bernoulli_counts(successes, n)
    failures = n - successes
    if prior == "uniform":
        return Fraction(1, (n + 1) * math.comb(n, successes))
    if prior == "jeffreys":
        return Fraction(math.comb(2 * successes, successes) * math.comb(2 * failures, failures),
                        (1 << (2 * n)) * math.comb(n, successes))
    raise ValueError("prior must be uniform or jeffreys")


def _mixture_inside(successes, n, alpha, prior, p):
    target = alpha * mixture_marginal(successes, n, prior)
    a, b = p.numerator, p.denominator
    likelihood_numerator = pow(a, successes) * pow(b - a, n - successes)
    return likelihood_numerator * target.denominator >= target.numerator * pow(b, n)


@lru_cache(maxsize=65536)
def _mixture_interval_cached(successes, n, alpha, prior, steps):
    if n == 0:
        return 0., 1.
    centre = Fraction(successes, n)
    if successes == 0:
        lower = Fraction(0)
    else:
        outside, inside = Fraction(0), centre
        for _ in range(steps):
            midpoint = (outside + inside) / 2
            if _mixture_inside(successes, n, alpha, prior, midpoint):
                inside = midpoint
            else:
                outside = midpoint
        lower = outside
    if successes == n:
        upper = Fraction(1)
    else:
        inside, outside = centre, Fraction(1)
        for _ in range(steps):
            midpoint = (inside + outside) / 2
            if _mixture_inside(successes, n, alpha, prior, midpoint):
                inside = midpoint
            else:
                outside = midpoint
        upper = outside
    return _fraction_float(lower, False), _fraction_float(upper, True)


def bernoulli_mixture_interval(successes, n, alpha, *, prior="uniform", steps=DEFAULT_BISECTION_STEPS):
    """Anytime-valid Beta-mixture Bernoulli CS, exact-rational inversion.

    M_n(p) = marginal_likelihood / (p**s * (1-p)**(n-s)).  The returned
    interval contains {p: M_n(p) <= 1/alpha}; including equality is conservative.
    This is a probability interval, not the original zero-gap PPR-1v1 rule.
    """
    successes, n = _bernoulli_counts(successes, n)
    alpha = _risk(alpha)
    steps = _integer(steps, "steps", 8)
    if steps > 256:
        raise ValueError("steps cannot exceed 256")
    mixture_marginal(successes, n, prior)  # Validate named prior, including n=0.
    return _mixture_interval_cached(successes, n, alpha, prior, steps)


def _binomial_range_numerator(n, a, b, first, last):
    if first > last:
        return 0
    remainder = b - a
    term = math.comb(n, first) * pow(a, first) * pow(remainder, n - first)
    result = term
    for k in range(first, last):
        term = term * a * (n - k) // (remainder * (k + 1))
        result += term
    return result


def _binomial_cdf_numerator(n, cutoff, p):
    """Return integer numerator/denominator of P_p[Bin(n,p) <= cutoff]."""
    a, b = p.numerator, p.denominator
    denominator = pow(b, n)
    if cutoff < 0:
        return 0, denominator
    if cutoff >= n:
        return denominator, denominator
    if a == 0:
        return denominator, denominator
    if a == b:
        return 0, denominator
    if cutoff + 1 <= n - cutoff:
        numerator = _binomial_range_numerator(n, a, b, 0, cutoff)
    else:
        numerator = denominator - _binomial_range_numerator(n, a, b, cutoff + 1, n)
    return numerator, denominator


def _cp_endpoint_safe(successes, n, alpha, point, lower):
    if lower:
        cdf, denominator = _binomial_cdf_numerator(n, successes - 1, point)
        numerator = denominator - cdf
    else:
        numerator, denominator = _binomial_cdf_numerator(n, successes, point)
    return numerator * alpha.denominator <= alpha.numerator * denominator


def _cp_root(successes, n, alpha, lower):
    from scipy.special import betaincinv

    if lower:
        approximate = float(betaincinv(successes, n - successes + 1, float(alpha)))
    else:
        approximate = 1. - float(betaincinv(n - successes, successes + 1, float(alpha)))
    if math.isfinite(approximate):
        point = min(1., max(0., approximate))
        for _ in range(64):
            if _cp_endpoint_safe(successes, n, alpha, Fraction.from_float(point), lower):
                return point
            point = math.nextafter(point, -math.inf if lower else math.inf)
            point = min(1., max(0., point))
    # Exact safe/unsafe bisection is independent of SciPy's numerical root.
    left, right = Fraction(0), Fraction(1)
    for _ in range(DEFAULT_BISECTION_STEPS):
        middle = (left + right) / 2
        safe = _cp_endpoint_safe(successes, n, alpha, middle, lower)
        if (lower and safe) or (not lower and not safe):
            left = middle
        else:
            right = middle
    return _fraction_float(left if lower else right, not lower)


@lru_cache(maxsize=65536)
def _fixed_cp_cached(successes, n, alpha):
    if n == 0:
        return 0., 1.
    lower = 0. if successes == 0 else _cp_root(successes, n, alpha, True)
    upper = 1. if successes == n else _cp_root(successes, n, alpha, False)
    return lower, upper


def fixed_look_cp_interval(successes, n, alpha_tail):
    """Fixed-look CP; alpha_tail is a separate risk for EACH endpoint."""
    successes, n = _bernoulli_counts(successes, n)
    return _fixed_cp_cached(successes, n, _risk(alpha_tail, tail=True))


def categorical_probability_bounds(counts, n, delta, *, method="mixture_uniform", looks=None):
    """Simultaneously protect a fixed full categorical universe.

    Only distinct integer counts are inverted. All K candidate intervals are
    nevertheless protected, including zero-count candidates. This avoids any
    unproved shortcut concerning the worst competitor after transport.
    """
    n = _integer(n, "n")
    values = tuple(counts)
    if not values or any(isinstance(x, bool) or not isinstance(x, Integral) or x < 0 for x in values):
        raise ValueError("counts must be nonempty nonnegative integers")
    values = tuple(map(int, values))
    if sum(values) != n:
        raise ValueError("categorical counts must sum to n")
    risk, k = _risk(delta), len(values)
    if method not in ("mixture_uniform", "mixture_jeffreys", "cp_fixed"):
        raise ValueError("unknown probability method")
    if method == "cp_fixed":
        if looks is None:
            raise ValueError("fixed-look CP requires a predeclared look schedule")
        schedule = tuple(_integer(x, "look", 1) for x in looks)
        if not schedule or len(set(schedule)) != len(schedule) or tuple(sorted(schedule)) != schedule:
            raise ValueError("looks must be strictly increasing positive integers")
        if n and n not in schedule:
            raise ValueError("current n is outside the predeclared look schedule")
        alpha = risk / (2 * k * len(schedule))
        interval = lambda count: fixed_look_cp_interval(count, n, alpha)
        risk_scope = "all K candidates, two tails, and all predeclared looks"
    else:
        schedule = None
        alpha = risk / k
        prior = method.removeprefix("mixture_")
        interval = lambda count: bernoulli_mixture_interval(count, n, alpha, prior=prior)
        risk_scope = "all K candidates, both endpoints, and all times (Ville)"
    leader = max(range(k), key=lambda i: (values[i], -i))
    empirical_runner = max((i for i in range(k) if i != leader),
                          key=lambda i: (values[i], -i), default=None)
    if k == 1:
        lower = upper = np.ones(1, dtype=np.float64)
        worst, gap = None, 1.
    else:
        intervals = {count: interval(count) for count in set(values)}
        lower = np.asarray([intervals[count][0] for count in values], dtype=np.float64)
        upper = np.asarray([intervals[count][1] for count in values], dtype=np.float64)
        worst = max((i for i in range(k) if i != leader), key=lambda i: (upper[i], -i))
        with localcontext() as ctx:
            ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
            gap = _decimal_float(_decimal(lower[leader]) - _decimal(upper[worst]), False)
    return {"method": method, "n": n, "candidate_count": k, "delta_exact": str(risk),
            "alpha_exact": str(alpha), "risk_scope": risk_scope, "looks": schedule,
            "leader_index": leader, "empirical_runner_index": empirical_runner,
            "worst_upper_competitor_index": worst, "lower": lower, "upper": upper,
            "lower_gap": gap, "nominal_certified": gap > 0,
            "exact_rational_endpoint_protection": True}


def _coordinate_affinity_lower(q, p):
    if q == p:
        return Decimal(1)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        return _sqrt_lower(q * p) + _sqrt_lower((1 - q) * (1 - p))


def _coordinate_chi2_factor_upper(q, p, reverse):
    base = p if reverse else q
    if base in (0, 1):
        return Decimal(1) if p == q else Decimal("Infinity")
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        denominator_lower = base * (1 - base)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
        distance_upper = (p - q) if p >= q else (q - p)
        return 1 + distance_upper * distance_upper / denominator_lower


def product_divergence_bounds(q, low, high):
    """Uniform bounds over an independent Bernoulli parameter box.

    Affinity endpoints minimize a concave coordinate function. Both chi-square
    coordinate objectives are convex in the varied probability, so endpoints
    suffice. Forward chi2 means chi2(P || Q), the direction used for transport
    from expectations/variances under nominal Q. Zero nominal support is
    handled explicitly. Pinned coordinates are left unchanged.
    """
    q, low, high = [np.asarray(x, dtype=np.float64) for x in np.broadcast_arrays(q, low, high)]
    if any(np.any(~np.isfinite(x)) or np.any((x < 0) | (x > 1)) for x in (q, low, high)):
        raise ValueError("probabilities must be finite and in [0,1]")
    if np.any(low > high):
        raise ValueError("box low exceeds high")
    groups = Counter(zip(q.ravel().tolist(), low.ravel().tolist(), high.ravel().tolist()))
    affinity, forward, reverse = Decimal(1), Decimal(1), Decimal(1)
    for (qf, lf, hf), count in groups.items():
        qd, ld, hd = map(_decimal, (qf, lf, hf))
        coordinate_affinity = min(_coordinate_affinity_lower(qd, p) for p in (ld, hd))
        coordinate_forward = max(_coordinate_chi2_factor_upper(qd, p, False) for p in (ld, hd))
        coordinate_reverse = max(_coordinate_chi2_factor_upper(qd, p, True) for p in (ld, hd))
        with localcontext() as ctx:
            ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
            affinity *= _positive_integer_power(coordinate_affinity, count)
        with localcontext() as ctx:
            ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
            forward *= _positive_integer_power(coordinate_forward, count)
            reverse *= _positive_integer_power(coordinate_reverse, count)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        affinity_squared_lower = affinity * affinity
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
        tv = _sqrt_upper(max(Decimal(0), 1 - affinity_squared_lower))
        chi2 = max(Decimal(0), forward - 1)
        chi2_reverse = max(Decimal(0), reverse - 1)
    return {"affinity_lower": max(0., _decimal_float(affinity, False)),
            "tv_hellinger_upper": min(1., _decimal_float(tv, True)),
            "chi2_upper": _decimal_float(chi2, True),
            "chi2_reverse_upper": _decimal_float(chi2_reverse, True),
            "actual_coordinates": int(q.size), "varied_coordinates": int(np.sum(low != high)),
            "unique_coordinate_triplets": len(groups), "independent_product_required": True,
            "all_box_contains_nominal": bool(np.all((low <= q) & (q <= high))),
            "numerical_protection": f"directed Decimal{PRECISION} and outward binary64 conversion"}


def _validate_interval(lower, upper):
    lower, upper = float(lower), float(upper)
    if not (math.isfinite(lower) and math.isfinite(upper) and 0 <= lower <= upper <= 1):
        raise ValueError("invalid probability interval")
    return lower, upper


def _hellinger_lower_decimal(q, affinity):
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        affinity_square_lower = affinity * affinity
        first_lower = affinity * _sqrt_lower(q)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
        epsilon_upper = _sqrt_upper(1 - affinity_square_lower)
        second_upper = epsilon_upper * _sqrt_upper(1 - q)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        difference = max(Decimal(0), first_lower - second_upper)
        return min(Decimal(1), difference * difference)


def hellinger_event_interval(lower, upper, affinity_lower):
    """Binary-event affinity transport, stronger than uniform TV in general."""
    lower, upper = _validate_interval(lower, upper)
    affinity_lower = float(affinity_lower)
    if not math.isfinite(affinity_lower) or not 0 <= affinity_lower <= 1:
        raise ValueError("affinity lower bound must be in [0,1]")
    if affinity_lower == 1:
        return lower, upper
    a = _decimal(affinity_lower)
    bound_lower = _hellinger_lower_decimal(_decimal(lower), a)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        complement_lower = 1 - _decimal(upper)
    complement = _hellinger_lower_decimal(complement_lower, a)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
        bound_upper = 1 - complement
    return max(0., _decimal_float(bound_lower, False)), min(1., _decimal_float(bound_upper, True))


def _chi2_lower_decimal(q, divergence):
    if divergence == 0 or q in (0, 1):
        return q
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
        penalty_upper = _sqrt_upper(divergence * q * (1 - q))
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        return max(Decimal(0), q - penalty_upper)


def chi2_event_interval(lower, upper, chi2_upper):
    """Cauchy--Schwarz event transport for chi2(P || Q).

    The clipped lower function max(0,q-sqrt(H*q*(1-q))) is nondecreasing:
    before becoming positive it is zero; where positive its derivative is
    positive (for q>=1/2 immediately, otherwise use H<q/(1-q)). Thus interval
    endpoint substitution is valid despite the *unclipped* function not being
    globally monotone. The upper bound follows by the complementary event.
    """
    lower, upper = _validate_interval(lower, upper)
    h = float(chi2_upper)
    if math.isnan(h) or h < 0:
        raise ValueError("chi-square upper bound must be nonnegative")
    if math.isinf(h):
        return 0., 1.
    hd = _decimal(h)
    low = _chi2_lower_decimal(_decimal(lower), hd)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        complement_lower = 1 - _decimal(upper)
    complement = _chi2_lower_decimal(complement_lower, hd)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
        high = 1 - complement
    return max(0., _decimal_float(low, False)), min(1., _decimal_float(high, True))


def chi2_pair_gap_lower(winner_lower, winner_upper, competitor_lower, competitor_upper, chi2_upper):
    """Transport D=1{winner}-1{competitor}, using Var_Q(D).

    Rectangle bounds give mass<=min(1,U_w+U_c) and
    |mean|>=max(0,L_w-U_c,L_c-U_w). These need not attain their extrema
    together, so this is a conservative variance upper bound. Each competitor
    must be checked; count ordering is not assumed after this refinement.
    """
    wl, wu = _validate_interval(winner_lower, winner_upper)
    cl, cu = _validate_interval(competitor_lower, competitor_upper)
    h = float(chi2_upper)
    if math.isnan(h) or h < 0:
        raise ValueError("chi-square upper bound must be nonnegative")
    if math.isinf(h):
        return -1.
    wl, wu, cl, cu, hd = map(_decimal, (wl, wu, cl, cu, h))
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        gap_lower = wl - cu
        absolute_mean_lower = max(Decimal(0), wl - cu, cl - wu)
        mean_square_lower = absolute_mean_lower * absolute_mean_lower
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
        mass_upper = min(Decimal(1), wu + cu)
        variance_upper = min(Decimal(1), max(Decimal(0), mass_upper - mean_square_lower))
        penalty_upper = _sqrt_upper(hd * variance_upper)
    with localcontext() as ctx:
        ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
        result = max(Decimal(-1), gap_lower - penalty_upper)
    return _decimal_float(result, False)


def transport_mode_intervals(lower, upper, leader, bounds, *, method="hellinger_event"):
    """Return a lower bound on every transported winner-minus-competitor gap."""
    lower, upper = np.asarray(lower, dtype=np.float64), np.asarray(upper, dtype=np.float64)
    if lower.ndim != 1 or upper.shape != lower.shape or not lower.size:
        raise ValueError("probability arrays must be nonempty equal-length vectors")
    if np.any(~np.isfinite(lower)) or np.any(~np.isfinite(upper)) or np.any(lower < 0) or np.any(upper > 1) or np.any(lower > upper):
        raise ValueError("invalid probability arrays")
    leader = _integer(leader, "leader")
    if leader >= len(lower):
        raise ValueError("leader is outside candidate universe")
    if method not in ("tv", "hellinger_event", "chi2_event", "chi2_pair"):
        raise ValueError("unknown transport method")
    if len(lower) == 1:
        return {"method": method, "lower_gap": 1., "certified": True,
                "worst_competitor_index": None, "same_probability_event": True}
    competitors = [i for i in range(len(lower)) if i != leader]
    cache, gaps = {}, []
    if method == "tv":
        epsilon = float(bounds["tv_hellinger_upper"])
        if not math.isfinite(epsilon) or not 0 <= epsilon <= 1:
            raise ValueError("invalid TV upper bound")
        with localcontext() as ctx:
            ctx.prec, ctx.rounding = PRECISION, ROUND_CEILING
            penalty_upper = 2 * _decimal(epsilon)
        winner_lower_decimal = _decimal(lower[leader])
        for i in competitors:
            key = float(upper[i])
            if key not in cache:
                with localcontext() as ctx:
                    ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
                    value = winner_lower_decimal - _decimal(key) - penalty_upper
                    cache[key] = max(-1., _decimal_float(value, False))
            gaps.append(cache[key])
    elif method == "chi2_pair":
        for i in competitors:
            key = float(lower[i]), float(upper[i])
            if key not in cache:
                cache[key] = chi2_pair_gap_lower(lower[leader], upper[leader], *key, bounds["chi2_upper"])
            gaps.append(cache[key])
    else:
        if method == "hellinger_event":
            transform = lambda lo, hi: hellinger_event_interval(lo, hi, bounds["affinity_lower"])
        else:
            transform = lambda lo, hi: chi2_event_interval(lo, hi, bounds["chi2_upper"])
        winner_lower = transform(lower[leader], upper[leader])[0]
        for i in competitors:
            key = float(lower[i]), float(upper[i])
            if key not in cache:
                cache[key] = transform(*key)[1]
            with localcontext() as ctx:
                ctx.prec, ctx.rounding = PRECISION, ROUND_FLOOR
                gaps.append(_decimal_float(_decimal(winner_lower) - _decimal(cache[key]), False))
    position = min(range(len(gaps)), key=lambda j: (gaps[j], competitors[j]))
    gap = gaps[position]
    return {"method": method, "lower_gap": gap, "certified": gap > 0,
            "worst_competitor_index": competitors[position],
            "same_probability_event": True, "all_competitors_checked": True,
            "deterministic_box_transport": True}
