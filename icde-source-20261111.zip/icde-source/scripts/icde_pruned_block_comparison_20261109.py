"""Matched universal anchor pruning for every method in the all-259 comparison.

The initial block prototype already pruned rivals whose global upper score
cannot reach the anchor lower score. This rerun exposes the SAME pruning to
every control before any sampling/inference, charging its construction cost.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import time
import numpy as np

import icde_block_comparison_20261109 as common
from icde_sparse_degree_20261108 import restrict
from icde_grouped_exact_20261108 import groups_for_box
from icde_grouped_inventory_20261108 import ROOT,load,save,sha,identities
from run_vldb_interval_gate_v1 import clipped_box

BASE=common.BASE.parent/'matched_anchor_pruning_attempt1'
ORIGINAL_EXECUTE=common.execute
FRONT_RECORDS={}


def prune(kernel):
    m=len(kernel.edge_indices)
    focus=int(np.argmax(kernel.scores(np.ones((1,m),dtype=np.bool_))[0]))
    lo,hi=kernel.score_intervals(np.zeros((1,m),dtype=np.bool_),np.ones((1,m),dtype=np.bool_))
    selected=[c for c in range(len(kernel.candidates)) if c==focus or hi[0,c]>=lo[0,focus]]
    kept=set(selected)
    for c in range(len(kernel.candidates)):
        if c not in kept and not hi[0,c]<lo[0,focus]:raise AssertionError('invalid universal rival pruning')
    return focus,selected


def execute(kernel,meta,case,policy,p):
    focus,selected=prune(kernel)
    key=case['graph'],case['rank']
    digest=hashlib.sha256(json.dumps(selected,separators=(',',':')).encode()).hexdigest()
    basic={'graph':key[0],'rank':key[1],'original_K':len(kernel.candidates),
           'active_K':len(selected),'original_scope_edges':len(kernel.edge_indices),
           'focus_original_index':focus,'retained_original_indices':selected,'selected_sha256':digest}
    existing=FRONT_RECORDS.get(key,{})
    if existing and existing['selected_sha256']!=digest:raise AssertionError('pruning changed between methods')
    FRONT_RECORDS[key]={**existing,**basic}
    if len(selected)==1:
        FRONT_RECORDS[key].update({'active_scope_edges':0,'active_G':0,'active_log2_S':0.,'trivial_after_pruning':True})
        return {'status':'stable','winner':focus,'focus':focus,'kind':'common_anchor_pruning_singleton',
                'lower_gap':1.,'upper_gap':1.,'active_K':1,'selected_sha256':digest,
                'endpoint_cache_entries':0,'endpoint_matrix_calls':0}
    reduced,mapping=restrict(kernel,selected)
    updated={**meta,'candidates':list(reduced.candidates),'retained_candidates':len(selected),
             'scope_edges':len(reduced.edge_indices)}
    FRONT_RECORDS[key].update({'active_scope_edges':len(reduced.edge_indices),'trivial_after_pruning':False})
    actual_case=case
    if policy=='factor_event':
        low,high=clipped_box(np.full(len(reduced.edge_indices),p['nominal']),p['tau'])
        groups=groups_for_box(reduced,low,high)
        sizes=[len(edges) for signature,edges,endpoint in groups]
        log_s=sum(math.log2(n+1) for n in sizes)
        s=math.prod(n+1 for n in sizes) if log_s<13000 else None
        actual_case={**case,'retained_candidates':len(selected),'scope_edges':len(reduced.edge_indices),
            'reconstructed_group_count':len(groups),'group_size_histogram':dict(Counter(sizes)),
            'count_states_exact':s}
        original_cap=(len(selected)<=8 and len(reduced.edge_indices)<=96 and s is not None
                      and s<=32768 and len(selected)*s*sum(n+1 for n in sizes)<=2000000)
        FRONT_RECORDS[key].update({'active_G':len(groups),'active_log2_S':log_s,
                                  'satisfies_original_prototype_limits_after_pruning':original_cap})
    raw=ORIGINAL_EXECUTE(reduced,updated,actual_case,policy,p)
    if raw.get('winner') is not None:raw['winner']=mapping[raw['winner']]
    raw['focus']=mapping[raw['focus']]
    for block in raw.get('blocks',[]):
        block['candidates']=[mapping[c] for c in block['candidates']]
        block['rival_upper_exact']={str(mapping[int(c)]):v for c,v in block['rival_upper_exact'].items()}
    raw.update({'active_K':len(selected),'active_scope_edges':len(reduced.edge_indices),
                'selected_sha256':digest,'common_anchor_pruning':True})
    return raw


def freeze(out):
    if out.exists():raise FileExistsError(out)
    parent=load(common.BASE/'protocol.json')
    p={**parent,'kind':'historical_four_controls_with_matched_universal_anchor_pruning',
       'common_anchor_pruning':'winner of all-present world anchors strict global upper<lower elimination; identical deterministic preprocessing paid by every method; all-259 denominator retained',
       'development_context':'initial block-positive result prompted matching this preprocessing; not new blind confirmation',
       'frozen_at_unix':time.time()}
    p['code_sha256']=dict(parent['code_sha256'])
    for name in ('icde_pruned_block_comparison_20261109.py','test_icde_anchor_pruning_20261109.py'):
        p['code_sha256']['scripts/'+name]=sha(ROOT/'scripts'/name)
    p['input_sha256']=dict(parent['input_sha256'])
    for name in ('protocol.json','summary.json'):
        path=common.BASE/name;p['input_sha256'][path.relative_to(ROOT).as_posix()]=sha(path)
    save(out/'protocol.json',p)
    print('Frozen matched pruning: same all-259 queries, four methods, 200ms',flush=True)


def preflight(out):
    p=load(out/'protocol.json');checks=identities(p,False)
    if (out/'summary.json').exists() or (out/'cases').exists():raise FileExistsError('new attempt required')
    save(out/'recovery.json',{'status':'PASS','checks':checks})
    print('Preflight PASS',checks,flush=True)


def run(out):
    previous=common.execute
    try:
        common.execute=execute
        common.run(out)
    finally:common.execute=previous
    # Reports only: no solver reads these records as a free preprocessing cache.
    actual=[r for key,r in FRONT_RECORDS.items() if key in {(c['graph'],c['rank']) for c in load(out/'protocol.json')['cases']}]
    if len(actual)!=259:raise AssertionError('missing common-front-end accounting')
    save(out/'anchor_pruning_inventory.json',{'queries':259,'rows':actual,
         'singletons_after_pruning':sum(r['trivial_after_pruning'] for r in actual),
         'competitive_now_within_original_limits':sum(r.get('satisfies_original_prototype_limits_after_pruning',False) for r in actual),
         'median_active_K':float(np.median([r['active_K'] for r in actual])),
         'scope':'runtime front-end metadata, never provided to policies as cached preprocessing'})
    print('Matched pruning inventory saved',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=('freeze','preflight','run'),required=True)
    parser.add_argument('--output',type=Path,default=BASE);args=parser.parse_args()
    {'freeze':freeze,'preflight':preflight,'run':run}[args.phase](args.output.resolve())
