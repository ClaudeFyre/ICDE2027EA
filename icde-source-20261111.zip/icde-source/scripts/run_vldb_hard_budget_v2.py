"""Freeze/replay conservative admission over existing V2 evidence only."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]
FILES = ("scripts/run_vldb_hard_budget_v2.py", "scripts/vldb_budget_policy_v2_hard.py",
         "tests/test_vldb_budget_policy_v2_hard.py",
         "papers/vldb/HARD_BUDGET_ADDENDUM_V2_20261104.md")


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def read(path):
    return json.loads(path.read_text("utf-8-sig"))


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def verify(config, protocol, output, create):
    parent_frozen = read(ROOT / config["parent_freeze"])
    for name, expected in parent_frozen["code_sha256"].items():
        if digest(ROOT / name) != expected:
            raise ValueError(f"changed parent frozen source: {name}")
    if digest(ROOT / config["parent_protocol"]) != parent_frozen["protocol_sha256"]:
        raise ValueError("changed parent protocol")
    parent = read(ROOT / config["parent_results"])
    if parent["status"] != "V2_EXECUTION_COMPLETE":
        raise ValueError("parent stage incomplete")
    for specification in parent["raw_paired_stream_files"]:
        path = (ROOT / specification["path"]).resolve()
        path.relative_to(ROOT)
        if digest(path) != specification["sha256"]:
            raise ValueError("changed saved V2 stream")
    identity = {"protocol_sha256": digest(protocol),
                "parent_results_sha256": digest(ROOT / config["parent_results"]),
                "parent_freeze_sha256": digest(ROOT / config["parent_freeze"]),
                "raw_streams": parent["raw_paired_stream_files"],
                "code_sha256": {name: digest(ROOT / name) for name in FILES}}
    if create:
        write_new(output / "protocol_snapshot.json", config)
        write_new(output / "protocol_freeze.json", identity)
    else:
        if read(output / "protocol_freeze.json") != identity:
            raise ValueError("changed hard-admission identity")
    return parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", default="configs/vldb_hard_budget_v2_20261104.json")
    parser.add_argument("--stage", required=True, choices=("freeze", "replay"))
    args = parser.parse_args()
    protocol = ROOT / args.protocol
    config = read(protocol)
    if os.environ.get("PYTHONHASHSEED") != config["required_pythonhashseed"]:
        raise ValueError("launch with frozen hash seed")
    output = (ROOT / config["result_root"]).resolve()
    output.relative_to(ROOT)
    parent = verify(config, protocol, output, args.stage == "freeze")
    if args.stage == "replay":
        from run_vldb_budget_gate_v2 import aggregate_policy_rows
        from vldb_budget_policy_v2_hard import run_hard_budget_policy

        settings = read(ROOT / config["parent_protocol"])
        started = time.perf_counter()
        rows = []
        for specification in parent["raw_paired_stream_files"]:
            rows.extend(run_hard_budget_policy(read(ROOT / specification["path"]), settings))
        violations = sum(row["work_used"] > row["work_budget"] for row in rows)
        result = {"status": "PASS" if not violations else "FAIL",
                  "policy_rows": rows, "aggregate": aggregate_policy_rows(rows),
                  "logical_work_budget_violations": violations,
                  "new_worlds_generated": 0, "same_walltime_advantage_claim": False,
                  "replay_seconds": time.perf_counter() - started,
                  "reuse_is_independent_replication": False}
        verify(config, protocol, output, False)
        write_new(output / "hard_budget_gate.json", result)
        if violations:
            raise ValueError("hard admission exceeded its declared budget")
    print(json.dumps({"stage": args.stage, "result_root": str(output)}))


if __name__ == "__main__":
    main()
