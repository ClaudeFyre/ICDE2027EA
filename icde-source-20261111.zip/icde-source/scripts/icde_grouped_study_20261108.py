"""Bounded correctness/cost prototype after a frozen static feasibility census.

The solver is a strong standard counting/tensor baseline, NOT asserted to be
a new general inference algorithm. All decisions are development evidence.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path
import statistics
import time
import zipfile

import numpy as np

import icde_prospective_20261107 as old
from icde_gate_exact_review import full_box_reference
from icde_grouped_exact_20261108 import compile_counts, solve_counts, direct_representative_probabilities
from icde_grouped_inventory_20261108 import load, save, sha, OLD, ROOT
from run_vldb_interval_gate_v1 import clipped_box

INVENTORY = ROOT / "nodes/09_vldb_query_certification/results/icde_grouped_query_20261108/inventory_attempt1"
BASE = INVENTORY.parent / "prototype_attempt1"


def freeze(out):
    if out.exists():
        raise FileExistsError(out)
    inventory = load(INVENTORY / "inventory.json")
    parent = load(INVENTORY / "protocol.json")
    code = dict(parent["code_sha256"])
    for name in ("icde_grouped_exact_20261108.py", "icde_grouped_study_20261108.py",
                 "test_icde_grouped_exact_20261108.py", "icde_gate_exact_review.py"):
        code[f"scripts/{name}"] = sha(ROOT / "scripts" / name)
    files = [INVENTORY / "inventory.json", INVENTORY / "protocol.json"]
    cases = []
    for selected in inventory["selected_for_prototype"]:
        row = next(r for r in inventory["rows"] if r["graph"] == selected["graph"] and r["rank"] == selected["rank"])
        if not row["prototype_eligible"]:
            raise AssertionError("selected query violates the frozen structural limits")
        cases.append({**selected, "scope_edges": row["scope_edges"], "candidates": row["retained_candidates"],
                      "count_states": row["count_states"], "group_sizes": row["group_sizes"]})
        meta = OLD / "prepared" / row["graph"] / f"q{row['rank']:03d}.json"
        files.extend((meta, meta.with_suffix(".npz")))
        if selected["role"] == "exact_small_scope_audit":
            files.append(OLD / "new_exact_reference" / f"{row['graph']}_q{row['rank']:03d}_t0.25.json")
    save(out / "protocol.json", {"kind": "known_input_standard_counting_baseline_feasibility",
        "cases": cases, "tau": .25, "nominal": .9, "limits": parent["prototype_limits"],
        "exact_repeats": 3, "mc_seeds": [709, 719], "mc_world_cap": 1024,
        "large_score_probe_seed": 823, "large_score_probes": 128,
        "mc_baseline": "unchanged optimized generic eager from prospective study, with common direct-global-interval front end; per-query risk .05",
        "same_group_baseline": "scalar sum-product on every compact parameter representative for all tiny cases; same groups and exact matrices, all preparation charged",
        "large_validation": "no complete Boolean enumeration; deterministic/random coupled score probes plus independent scalar evaluations at tensor extrema",
        "selection": "frozen structural census: largest feasible scopes plus all 20 prior tiny exact queries; no new independent confirmation",
        "cost": "each exact repeat includes count compilation, matrix construction, exact contraction and gap extraction; prepared query loading and direct front end recorded separately; raw corpus construction/persistence excluded",
        "novelty": "standard ingredients instantiated as a strong baseline; practical gain is not automatically a novel contribution",
        "code_sha256": code, "input_sha256": {p.relative_to(ROOT).as_posix(): sha(p) for p in files},
        "frozen_at_unix": time.time()})
    print(json.dumps({"frozen_queries": len(cases), "large": sum(c["role"] == "static_large_scope" for c in cases)}, ensure_ascii=False), flush=True)


def identities(protocol, crc=False):
    checks = 0
    for group in ("code_sha256", "input_sha256"):
        for name, digest in protocol[group].items():
            path = ROOT / name
            if sha(path) != digest:
                raise AssertionError(f"frozen identity changed: {name}")
            checks += 1
            if crc and name.endswith(".npz"):
                with zipfile.ZipFile(path) as archive:
                    if archive.testzip() is not None:
                        raise AssertionError("prepared CRC failure")
                checks += 1
    return checks


def preflight(out):
    p = load(out / "protocol.json")
    count = identities(p, crc=True)
    if (out / "summary.json").exists() or list(out.glob("*.pending")):
        raise ValueError("expected outputs already present")
    save(out / "recovery.json", {"status": "PASS", "checks": count,
        "scope": "all consumed inputs, code and NPZ CRCs; no whole-workspace scan"})
    print(f"Recovery PASS: {count}", flush=True)


def run(out):
    p = load(out / "protocol.json")
    if load(out / "recovery.json")["status"] != "PASS":
        raise AssertionError("recovery required")
    checks = identities(p)
    cases, mcs, references = [], [], []
    for index, case in enumerate(p["cases"]):
        before = time.perf_counter()
        kernel, meta = old.read_query(case["graph"], case["rank"])
        query_load = time.perf_counter() - before
        m, k = case["scope_edges"], case["candidates"]
        q = np.full(m, p["nominal"])
        low, high = clipped_box(q, p["tau"])
        before = time.perf_counter()
        lower, upper = kernel.score_intervals(np.zeros((1, m), dtype=np.bool_), np.ones((1, m), dtype=np.bool_))
        direct_candidate = int(np.argmax(lower[0]))
        others = upper[0].copy()
        others[direct_candidate] = -np.inf
        direct_safe = bool(lower[0, direct_candidate] > max(others))
        direct_seconds = time.perf_counter() - before
        timings, last = [], None
        for repeat in range(p["exact_repeats"]):
            before = time.perf_counter()
            compiled = compile_counts(kernel, low, high, p["limits"]["count_states"])
            result = solve_counts(compiled, k)
            elapsed = time.perf_counter() - before
            if compiled["count_states"] != case["count_states"]:
                raise AssertionError("actual representation differs from frozen census")
            if last is not None and (result["pairs"] != last["pairs"] or result["uniform_winners"] != last["uniform_winners"]):
                raise AssertionError("exact repeat changed result")
            timings.append({"repeat": repeat, "total_seconds": elapsed, "compile_seconds": compiled["compilation_seconds"],
                            "matrix_seconds": result["matrix_seconds"], "solve_seconds": result["solve_seconds"]})
            last = result
        if direct_safe and result["uniform_winners"] != [direct_candidate]:
            raise AssertionError("global direct proof conflicts with exact counting")
        checks += 1
        scalar_started = time.perf_counter()
        points = set(tuple(pair["minimizing_high_endpoint_counts"]) for pair in result["pairs"])
        if case["role"] == "exact_small_scope_audit":
            points = set(product(*(range(n) for n in compiled["shape"])))
        for point in sorted(points):
            scalar = direct_representative_probabilities(compiled, result["matrices"], point, k)
            if scalar != [int(v[point]) for v in result["numerators"]]:
                raise AssertionError("tensor transform differs from scalar sum-product at a parameter representative")
            checks += 1
        scalar_seconds = time.perf_counter() - scalar_started
        # Probe the compact score mapping without enumerating the full Boolean
        # space for large cases. Every small Boolean state is checked instead.
        if case["role"] == "exact_small_scope_audit":
            states = ((np.arange(1 << m)[:, None] >> np.arange(m)) & 1).astype(np.bool_)
        else:
            random = np.random.default_rng(p["large_score_probe_seed"] + index).random((p["large_score_probes"], m)) < .5
            states = np.concatenate((np.zeros((1, m), dtype=np.bool_), np.ones((1, m), dtype=np.bool_), random))
        original = np.argmax(kernel.scores(states), axis=1)
        grouped_counts = [np.sum(states[:, list(edges)], axis=1, dtype=np.int64) for sig, edges, endpoint in compiled["groups"]]
        compact = compiled["winners"][tuple(grouped_counts)]
        if not np.array_equal(original, compact):
            raise AssertionError("count-compiled winners differ from frozen numerical scorer")
        checks += len(states)
        if case["role"] == "exact_small_scope_audit":
            before = time.perf_counter()
            brute = full_box_reference(original.tolist(), k, q, low, high)
            brute_seconds = time.perf_counter() - before
            frozen = load(OLD / "new_exact_reference" / f"{case['graph']}_q{case['rank']:03d}_t0.25.json")
            for pair in result["pairs"]:
                w, d = pair["candidate"], pair["competitor"]
                expected = next(x for x in brute["candidate_results"][w]["pair_gap_ranges"] if x["competitor_index"] == d)
                oldpair = next(x for x in frozen["candidate_results"][w]["pair_gap_ranges"] if x["competitor_index"] == d)
                if Q(pair["minimum_gap_exact"]) != Q(expected["minimum_gap"]) or expected["minimum_gap"] != oldpair["minimum_gap"]:
                    raise AssertionError("exact grouped gap differs from full independent/frozen reference")
                checks += 1
            references.append({**case, "parameter_vertex_count": 1 << m, "reference_solve_seconds": brute_seconds,
                               "scalar_all_representatives_seconds": scalar_seconds,
                               "same_group_scalar_total_seconds": scalar_seconds + timings[-1]["compile_seconds"] + timings[-1]["matrix_seconds"]})
        row = {**case, "uniform_winners": result["uniform_winners"], "pairs": result["pairs"],
               "timings": timings, "median_exact_compute_seconds": statistics.median(t["total_seconds"] for t in timings),
               "shared_prepared_query_load_seconds": query_load, "direct_safe": direct_safe,
               "direct_candidate": direct_candidate if direct_safe else None, "direct_seconds": direct_seconds,
               "score_probes": len(states), "scalar_audited_representatives": len(points),
               "no_complete_boolean_map_for_large": case["role"] == "static_large_scope"}
        cases.append(row)
        for seed in p["mc_seeds"]:
            if direct_safe:
                mc = {"certified": True, "candidate": kernel.candidates[direct_candidate], "worlds": 0,
                      "compute_seconds": 0., "status": "common_direct_front_end", "nominal_delta_exact": "0", "event_beta_exact": "0"}
            else:
                mc = old.execute_case(kernel, meta, p["tau"], seed, "eager")
            candidate = kernel.candidates.index(mc["candidate"]) if mc["candidate"] is not None else None
            if candidate is not None and candidate not in result["uniform_winners"]:
                raise AssertionError("generic MC certificate disagrees with exact full-box reference")
            mcs.append({**case, "seed": seed, "candidate": candidate, "certified": mc["certified"],
                        "worlds": mc["worlds"], "compute_seconds": mc["compute_seconds"],
                        "direct_plus_compute_seconds": direct_seconds + mc["compute_seconds"],
                        "status": mc["status"], "nominal_delta_exact": mc["nominal_delta_exact"],
                        "event_beta_exact": mc["event_beta_exact"]})
            checks += 1
        print(f"completed {index+1}/{len(p['cases'])}: {case['graph']} q{case['rank']:03d}, m={m}, S={compiled['count_states']}, exact={result['uniform_winners']}, direct={direct_safe}", flush=True)
    checks += identities(p)
    save(out / "summary.json", {"status": "PASS", "checks": checks, "cases": cases,
        "generic_mc": mcs, "small_references": references, "protocol_sha256": sha(out / "protocol.json"),
        "historical_inputs_unchanged": True,
        "limitations": ["known structurally selected development subset, not prospective confirmation",
            "degree-incidence scorer and configured independent retention only",
            "standard counting and tensor elimination are not claimed as novel",
            "no complete implementation of C-FOVE, credal-circuit or parameter-synthesis competitors",
            "prepared-object exploratory timings, not raw-data cold service latency",
            "uniform symmetry may disappear for heterogeneous endpoints or neural features"]})
    print(json.dumps({"status": "PASS", "queries": len(cases), "mc_runs": len(mcs), "checks": checks}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("freeze", "preflight", "run"), required=True)
    parser.add_argument("--output", type=Path, default=BASE)
    args = parser.parse_args()
    {"freeze": freeze, "preflight": preflight, "run": run}[args.phase](args.output.resolve())
