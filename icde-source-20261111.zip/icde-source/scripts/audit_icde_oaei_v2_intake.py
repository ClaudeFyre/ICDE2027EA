"""OAEI 2025 KG Track v2 intake audit.

Reproducible audit for two domains (Star Wars-SWTOR, MCU-Marvel).
Streams RDF/XML graph dumps with iterparse; never loads whole file into memory.
Only Python stdlib + numpy required.

Usage:
    python scripts/audit_icde_oaei_v2_intake.py \
        --raw E:\\pkgea\\data\\raw\\oaei_kg_v2_20261009 \
        --out  nodes/05_icde_query_engine/results/icde_oaei_v2_20261009

Outputs:
    oaei_v2_intake.json        aggregate audit
    manifest_<side>.json        per-file frozen digest manifest
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

RDF_NS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
ALIGNMENT_NS_OK = {
    "http://knowledgeweb.semanticweb.org/heterogeneity/alignment",
    "http://knowledgeweb.semanticweb.org/heterogeneity/alignment#",
}

# Domain -> (source_wiki_host, target_wiki_host, expected_instance_counts)
DOMAINS = {
    "starwars-swtor": {
        "source_dir": "starwars_swg_source",
        "target_dir": "starwars_swtor_target",
        "source_wiki": "dbkwik.webdatacommons.org/starwars.wikia.com",
        "target_wiki": "dbkwik.webdatacommons.org/swtor.wikia.com",
        "official_instances": {"source": 145033, "target": 4180},
        "reference_file": "starwars-swtor.reference.xml",
        "frozen": {
            "bytes": 486151,
            "sha256": "b67c2c0209023e5b6aa8d11dfd045515444d3a5a8400d44d0ffdaedd9faa1e33",
        },
    },
    "marvelcinematicuniverse-marvel": {
        "source_dir": "marvel_source",
        "target_dir": "marvel_target",
        "source_wiki": "dbkwik.webdatacommons.org/marvelcinematicuniverse.wikia.com",
        "target_wiki": "dbkwik.webdatacommons.org/marvel.wikia.com",
        "official_instances": {"source": 17187, "target": 210996},
        "reference_file": "marvelcinematicuniverse-marvel.reference.xml",
        "frozen": {
            "bytes": 604605,
            "sha256": "a7bbcf3e8239171382ff54e86d677d7a0baefd0af8ba5a26d6397e96f20ea6af",
        },
    },
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def expand_tag(tag: str) -> tuple[str, str]:
    """Return (namespace, localname) from Clark-notation tag."""
    if tag.startswith("{"):
        ns, local = tag[1:].split("}", 1)
        return ns, local
    return "", tag


def predicate_ns(pred_uri: str) -> str:
    """Group predicate by its namespace base (everything up to last / or #).
    Accepts Clark-notation '{ns}local' or plain URI."""
    if pred_uri.startswith("{"):
        pred_uri = pred_uri[1:].split("}", 1)[0]
    m = re.match(r"^(https?://[^/]+/[^?#]*)[/#][^/#?]*$", pred_uri)
    if m:
        return m.group(1)
    return pred_uri


def parse_reference(raw: bytes) -> dict:
    tree = ET.fromstring(raw)
    namespaces = {e.tag.rsplit("}", 1)[0][1:] for e in tree.iter() if e.tag.endswith("}Cell")}
    if len(namespaces) != 1 or not namespaces <= ALIGNMENT_NS_OK:
        raise ValueError(f"unsupported alignment namespace: {namespaces}")
    ns_uri = namespaces.pop()
    ns = {"a": ns_uri}
    resource_attr = f"{{{RDF_NS}}}resource"
    cells = tree.findall(".//a:Cell", ns)
    if not cells:
        raise ValueError("no cells found")
    pairs = []
    for c in cells:
        e1 = c.find("a:entity1", ns)
        e2 = c.find("a:entity2", ns)
        rel = c.findtext("a:relation", namespaces=ns)
        if e1 is None or e2 is None or not rel:
            raise ValueError("empty cell or missing relation")
        s = e1.get(resource_attr)
        t = e2.get(resource_attr)
        if not s or not t:
            raise ValueError("empty entity resource")
        pairs.append((s, t))
    schema = [p for p in pairs if ("/class/" in p[0] or "/property/" in p[0]
                                    or "/class/" in p[1] or "/property/" in p[1])]
    instance = [p for p in pairs if p not in schema]
    return {
        "alignment_namespace": ns_uri,
        "cells": len(cells),
        "unique_pairs": len(set(pairs)),
        "schema_cells": len(schema),
        "instance_cells": len(instance),
        "relations": sorted({c.findtext("a:relation", namespaces=ns) for c in cells}),
        "source_entities": sorted({p[0] for p in pairs}),
        "target_entities": sorted({p[1] for p in pairs}),
        "_pairs": pairs,
    }


def audit_graph(path: Path, side: str, own_wiki: str, other_wiki: str,
                gold_source_set: set, gold_target_set: set) -> dict:
    """Stream-parse one RDF/XML graph dump.

    own_wiki: e.g. "dbkwik.webdatacommons.org/starwars.wikia.com"
    other_wiki: e.g. "dbkwik.webdatacommons.org/swtor.wikia.com"
    gold_source_set / gold_target_set: set of gold URIs on this side / other side.
    """
    stats = {
        "side": side,
        "subjects_total": set(),
        "instance_subjects": set(),       # /resource/ URIs on own wiki
        "class_subjects": set(),          # /class/ URIs
        "property_subjects": set(),      # /property/ URIs
        "predicate_ns_counter": Counter(),
        "predicate_counter": Counter(),
        "object_uri_count": 0,
        "object_literal_count": 0,
        "self_link_objects": 0,          # rdf:resource on own dbkwik wiki
        "cross_wiki_objects": 0,         # rdf:resource on other dbkwik wiki
        "external_wiki_objects": 0,       # rdf:resource on wikia.com (non-dbkwik)
        "other_uri_objects": 0,
        "label_subjects": set(),          # subjects with rdfs:label / skos:prefLabel
        # leakage: gold pairs explicitly realized as triples in this dump
        "gold_pairs_realized_in_source": 0,  # only meaningful on source side
        "gold_source_hit_subjects": set(),   # gold source URIs actually present as subjects
        "gold_target_hit_objects": set(),    # gold target URIs actually present as objects
    }
    resource_attr = f"{{{RDF_NS}}}resource"  # child URI objects
    about_attr = f"{{{RDF_NS}}}about"         # rdf:Description subject
    langstring = "{http://www.w3.org/2001/XMLSchema#}langString"

    # We process at rdf:Description granularity.
    context = ET.iterparse(str(path), events=("end",))
    for event, elem in context:
        ns, local = expand_tag(elem.tag)
        if local != "Description" or ns != RDF_NS:
            continue
        subj = elem.get(about_attr) or elem.get(resource_attr)
        if subj is None:
            elem.clear()
            continue
        stats["subjects_total"].add(subj)
        # classify subject
        if f"{own_wiki}/resource/" in subj:
            stats["instance_subjects"].add(subj)
        elif "/class/" in subj:
            stats["class_subjects"].add(subj)
        elif "/property/" in subj:
            stats["property_subjects"].add(subj)

        for child in elem:
            p_ns, p_local = expand_tag(child.tag)
            pred = child.tag  # full URI
            stats["predicate_ns_counter"][predicate_ns(pred)] += 1
            stats["predicate_counter"][pred] += 1

            obj_uri = child.get(resource_attr)
            if obj_uri is not None:
                stats["object_uri_count"] += 1
                if own_wiki in obj_uri:
                    stats["self_link_objects"] += 1
                elif other_wiki in obj_uri:
                    stats["cross_wiki_objects"] += 1
                    # leakage: is this gold source->target?
                    if subj in gold_source_set and obj_uri in gold_target_set:
                        stats["gold_pairs_realized_in_source"] += 1
                    stats["gold_target_hit_objects"].add(obj_uri)
                elif "wikia.com" in obj_uri or "wikia.com" in obj_uri:
                    stats["external_wiki_objects"] += 1
                else:
                    stats["other_uri_objects"] += 1
            else:
                text = child.text
                if text is not None and text.strip():
                    stats["object_literal_count"] += 1
                if p_local in ("label", "prefLabel", "altLabel", "name"):
                    stats["label_subjects"].add(subj)
                if subj in gold_source_set:
                    pass
            if subj in gold_source_set:
                stats["gold_source_hit_subjects"].add(subj)
        elem.clear()

    out = {
        "side": side,
        "subjects_total": len(stats["subjects_total"]),
        "instance_subjects": len(stats["instance_subjects"]),
        "class_subjects": len(stats["class_subjects"]),
        "property_subjects": len(stats["property_subjects"]),
        "predicate_namespace_top20": stats["predicate_ns_counter"].most_common(20),
        "predicate_top20": stats["predicate_counter"].most_common(20),
        "object_uri_count": stats["object_uri_count"],
        "object_literal_count": stats["object_literal_count"],
        "self_link_objects": stats["self_link_objects"],
        "cross_wiki_objects": stats["cross_wiki_objects"],
        "external_wiki_objects": stats["external_wiki_objects"],
        "other_uri_objects": stats["other_uri_objects"],
        "label_subjects": len(stats["label_subjects"]),
        "gold_source_hit_subjects": len(stats["gold_source_hit_subjects"]),
        "gold_target_hit_objects_in_this_dump": len(stats["gold_target_hit_objects"]),
        "gold_pairs_realized_explicitly_in_dump": stats["gold_pairs_realized_in_source"],
    }
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    report = {"domains": {}, "raw_dir": str(args.raw)}

    for domain, cfg in DOMAINS.items():
        d = {"config": {k: v for k, v in cfg.items() if k != "frozen"}}
        # --- reference ---
        ref_path = args.raw / "reference" / cfg["reference_file"]
        raw = ref_path.read_bytes()
        ref_sha = hashlib.sha256(raw).hexdigest()
        ref_bytes = len(raw)
        ref = parse_reference(raw)
        pairs = ref.pop("_pairs")
        gold_source_set = {s for s, _ in pairs}
        gold_target_set = {t for _, t in pairs}

        d["reference"] = {
            "file": str(ref_path),
            "bytes": ref_bytes,
            "sha256": ref_sha,
            "frozen_bytes": cfg["frozen"]["bytes"],
            "frozen_sha256": cfg["frozen"]["sha256"],
            "matches_frozen": (ref_bytes == cfg["frozen"]["bytes"]
                               and ref_sha == cfg["frozen"]["sha256"]),
            **{k: v for k, v in ref.items()},
        }
        d["reference"]["source_entities"] = len(d["reference"]["source_entities"])
        d["reference"]["target_entities"] = len(d["reference"]["target_entities"])

        # --- source graph ---
        src_path = args.raw / cfg["source_dir"] / "source.rdf.xml"
        src_bytes = src_path.stat().st_size
        src_sha = sha256_file(src_path)
        src_audit = audit_graph(
            src_path, "source",
            own_wiki=cfg["source_wiki"], other_wiki=cfg["target_wiki"],
            gold_source_set=gold_source_set, gold_target_set=gold_target_set,
        )
        d["source_graph"] = {
            "file": str(src_path),
            "bytes": src_bytes,
            "sha256": src_sha,
            "format": "RDF/XML (text/xml, single dump)",
            **src_audit,
            "official_instance_count": cfg["official_instances"]["source"],
        }

        # --- target graph ---
        tgt_path = args.raw / cfg["target_dir"] / "target.rdf.xml"
        tgt_bytes = tgt_path.stat().st_size
        tgt_sha = sha256_file(tgt_path)
        # On target side, gold_source/target sets are reversed for cross-wiki counting
        tgt_audit = audit_graph(
            tgt_path, "target",
            own_wiki=cfg["target_wiki"], other_wiki=cfg["source_wiki"],
            gold_source_set=gold_target_set, gold_target_set=gold_source_set,
        )
        d["target_graph"] = {
            "file": str(tgt_path),
            "bytes": tgt_bytes,
            "sha256": tgt_sha,
            "format": "RDF/XML (text/xml, single dump)",
            **tgt_audit,
            "official_instance_count": cfg["official_instances"]["target"],
        }

        # --- leakage summary ---
        total_gold = len(pairs)
        realized_src = d["source_graph"]["gold_pairs_realized_explicitly_in_dump"]
        realized_tgt = d["target_graph"]["gold_pairs_realized_explicitly_in_dump"]
        d["leakage"] = {
            "gold_pairs_total": total_gold,
            "gold_pairs_realized_in_source_dump": realized_src,
            "gold_pairs_realized_in_target_dump": realized_tgt,
            "gold_pairs_realized_in_either": realized_src + realized_tgt,  # upper bound
            "ratio_of_gold_explicitly_linked": (realized_src + realized_tgt) / total_gold,
            "note": "If >0, these explicit cross-wiki links must be removed from model input "
                    "before training/eval; they are the construction source of gold.",
        }
        report["domains"][domain] = d

    out_json = args.out / "oaei_v2_intake.json"
    out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=list),
                       encoding="utf-8")
    print(f"Wrote {out_json}")


if __name__ == "__main__":
    main()
