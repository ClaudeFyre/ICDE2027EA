"""Explicit encoder adapters for the WWW distributional benchmark.

Checkpoint execution is registered by the checkpoint's on-disk ``format``.
Descriptor adapter ids are metadata and are deliberately not used to guess an
execution implementation.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol, runtime_checkable

import torch

from torch_gcn_align import GCNAlign, normalized_adjacency
from torch_relation_align import RelationAwareAlign


@runtime_checkable
class DistributionalEncoderAdapter(Protocol):
    format_id: str
    descriptor_adapter_id: str
    message_passing_steps: int
    normalization_family: str

    def load(self, checkpoint: dict[str, object]) -> None: ...

    def entity_ids(self) -> list[str]: ...

    def edge_endpoints(self) -> tuple[list[int], list[int]]: ...

    def encode(self, active_edge_mask: torch.Tensor) -> torch.Tensor: ...


class _CheckpointAdapter:
    message_passing_steps = 2

    def __init__(self) -> None:
        self.checkpoint: dict[str, object] | None = None

    def load(self, checkpoint: dict[str, object]) -> None:
        if checkpoint.get("format") != self.format_id:
            raise ValueError(
                f"adapter {self.format_id!r} cannot load checkpoint format "
                f"{checkpoint.get('format')!r}"
            )
        self.checkpoint = checkpoint

    def _loaded(self) -> dict[str, object]:
        if self.checkpoint is None:
            raise RuntimeError("adapter has not loaded a checkpoint")
        return self.checkpoint

    def entity_ids(self) -> list[str]:
        return list(self._loaded()["entity_ids"])

    def edge_endpoints(self) -> tuple[list[int], list[int]]:
        checkpoint = self._loaded()
        return list(checkpoint["heads"]), list(checkpoint["tails"])


class GCNDistributionalEncoderAdapter(_CheckpointAdapter):
    format_id = "pkgea-torch-gcn-align-v1"
    descriptor_adapter_id = "pkgea/torch-gcn-align-v1"
    normalization_family = "symmetric_degree"

    def load(self, checkpoint: dict[str, object]) -> None:
        super().load(checkpoint)
        self.model = GCNAlign(
            int(checkpoint["feature_dimension"]), int(checkpoint["dimension"])
        )
        self.model.load_state_dict(checkpoint["model_state"])
        self.model.eval()
        self.features = checkpoint["features"].detach().cpu()
        self.heads = torch.tensor(checkpoint["heads"], dtype=torch.long)
        self.tails = torch.tensor(checkpoint["tails"], dtype=torch.long)

    def encode(self, active_edge_mask: torch.Tensor) -> torch.Tensor:
        weights = active_edge_mask.to(dtype=torch.float32, device="cpu")
        adjacency = normalized_adjacency(
            len(self.entity_ids()), self.heads, self.tails, weights, torch.device("cpu")
        )
        return self.model(adjacency, self.features)


class RelationDistributionalEncoderAdapter(_CheckpointAdapter):
    format_id = "pkgea-torch-relation-contrastive-v1"
    descriptor_adapter_id = "pkgea/torch-relation-contrastive-v1"
    normalization_family = "active_edge_weighted_node_mean_plus_row_l2"

    def load(self, checkpoint: dict[str, object]) -> None:
        super().load(checkpoint)
        self.model = RelationAwareAlign(
            int(checkpoint["feature_dimension"]),
            int(checkpoint["dimension"]),
            int(checkpoint["relation_count"]),
        )
        self.model.load_state_dict(checkpoint["model_state"])
        self.model.eval()
        self.features = checkpoint["features"].detach().cpu()
        self.heads = torch.tensor(checkpoint["heads"], dtype=torch.long)
        self.tails = torch.tensor(checkpoint["tails"], dtype=torch.long)
        self.relations = torch.tensor(
            checkpoint["relation_indices"], dtype=torch.long
        )

    def encode(self, active_edge_mask: torch.Tensor) -> torch.Tensor:
        weights = active_edge_mask.to(dtype=torch.float32, device="cpu")
        return self.model(
            self.features, self.heads, self.tails, self.relations, weights
        )


_REGISTRY: dict[str, Callable[[], DistributionalEncoderAdapter]] = {
    GCNDistributionalEncoderAdapter.format_id: GCNDistributionalEncoderAdapter,
    RelationDistributionalEncoderAdapter.format_id: RelationDistributionalEncoderAdapter,
}


def registered_checkpoint_formats() -> tuple[str, ...]:
    return tuple(sorted(_REGISTRY))


def load_distributional_encoder(
    checkpoint: dict[str, object],
) -> DistributionalEncoderAdapter:
    format_id = checkpoint.get("format")
    factory = _REGISTRY.get(str(format_id))
    if factory is None:
        expected = ", ".join(registered_checkpoint_formats())
        raise ValueError(
            f"unregistered WWW checkpoint format {format_id!r}; expected one of: "
            f"{expected}"
        )
    adapter = factory()
    adapter.load(checkpoint)
    return adapter
