"""Integrate independently audited ICDE gate evidence into the research draft."""
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
PAPER=ROOT/'papers/icde/regular2027'

def replace_paragraph(text,prefix,replacement):
    pattern=r'(?m)^'+re.escape(prefix)+r'[^\n]*'
    matches=list(re.finditer(pattern,text))
    if len(matches)!=1:raise ValueError((prefix,len(matches)))
    return text[:matches[0].start()]+replacement+text[matches[0].end():]

def main():
    text=(PAPER/'history/pre_gate_20261104/main.tex').read_text('utf-8-sig')
    text=text.replace('% Content source: manuscript.md; historical evidence retains its original identity.',
                      '% Canonical paper source; manuscript.md is regenerated from this source.')
    text=text.replace('Sequential execution uses one numerical thread and a seven-GiB job memory limit.',
                      'Degree jobs use one thread and a seven-GiB limit; neural jobs use a separate GPU profile.')
    text=replace_paragraph(text,'Graph-based data integration often',r'''Graph-based integration can attach uncertainty to facts. A fixed scorer ranks candidates for one graph realization, but its winner can vary across possible worlds. Approximating the resulting answer distribution therefore requires precise semantics.''')
    abstract=r'''Probabilistic graph queries can return different winners in different possible worlds. Evaluating the expected graph does not generally identify the candidate that wins most often. ScopeRace certifies this modal answer under a declared variable-work cap. A query contract binds the scorer, candidates, numerical semantics and joint world law. Simultaneous inference protects adaptive stopping; dependency-complete scopes preserve world-wise evaluation. Paid event evidence converts nominal gaps into certificates over a declared model family, sharing existing random inputs without treating uncomputed evidence as free. On two graph profiles, shared event execution certifies 2396 versus 2180 of 3000 query--seed cases. Direct mode-estimation controls reveal a stronger nominal baseline, while full-graph neural experiments produce nonvacuous certificates for restricted parameter maintenance. An independently checked exact study separates safe approvals, unsafe nominal shortcuts and avoidable reviews over continuous model families. The results support a query-processing contribution in evidence-preserving execution and controlled review, with construction, inference and persistence costs exposed. Conditional model stability remains distinct from alignment-label correctness, and broad model families can still yield no certificate.'''
    text=re.sub(r'(?s)\\begin\{abstract\}.*?\\end\{abstract\}',lambda m:'\\begin{abstract}\n'+abstract+'\n\\end{abstract}',text,count=1)
    text=replace_paragraph(text,'A motivating workflow is',r'''Our operational example reviews a change to a stochastic graph-scoring service. Retention probabilities are configured randomization settings: the maintainer changes an approved parameter batch while keeping the scorer fixed, and asks whether its cached modal answers can be retained throughout that family. Unresolved answers receive further review. This gives the probability law an executable meaning without interpreting it as calibrated fact truth. The certificate protects the stated model-behavior decision; external identity accuracy remains a separate empirical question.''')
    text=replace_paragraph(text,'The paper specifies nominal',r'''The contribution is an evidence-preserving physical execution framework for fixed-scorer modal queries: complete candidate and dependency contracts, local or full-graph execution, shared paid evidence prefixes, and preexecution work admission. We prove its validity conditions and assess its cost against direct inference controls. Completed query-load, neural and exact decision studies establish where these execution choices matter, with negative refinements and label-utility results retained.''')
    text=replace_paragraph(text,'The caller freezes a matching',r'''The caller freezes a scorer revision and its configured world generator. For a proposed retention-policy update, an approval means that one answer remains the unique mode across the approved family. It does not assert that every individual sampled prediction is invariant. A review record binds the answer, family, evidence prefix, risk and cost. Our prototype evaluates this decision with both full-graph neural workloads and independently solved structured queries.''')
    insertion=r'''
\subsection{Direct Mode and Variance-Adaptive Controls}

For the closest nominal comparison, we implement the original uniform-prior PPR-1v1 rule~\cite{jain2022pacmode}. If the empirical leader and runner-up have counts $a>b$, its conditional-pair evidence at equality is
\begin{equation}
E_{ab}=\frac{2^{a+b}}{(a+b+1)\binom{a+b}{a}}.
\label{eq:ppr}
\end{equation}
The published mode allocation stops when $E_{ab}\ge(K-1)/\delta$. The prior/posterior confidence-set argument protects the relevant comparisons to a fixed true mode; a separate all-pairs variant is available. At fixed leader count, increasing the competing count decreases this evidence until equality, justifying the runner-up shortcut. Integer cross-multiplication avoids quantile or log-rounding errors. This is an attributed inference control rather than a new statistical primitive.

For a numerical positive gap, we also use a fixed-checkpoint empirical Bernstein bound~\cite{maurer2009empirical}. With $C=\binom K2$, $M$ predefined looks and $v=((a+b)-(a-b)^2/n)/(n-1)$,
\begin{equation}
L^{\rm EB}=\frac{a-b}{n}
-\sqrt{\frac{2v\log(4CM/\delta)}{n}}
-\frac{14\log(4CM/\delta)}{3(n-1)}.
\label{eq:eb}
\end{equation}
The range-two rescaling and union over both directions, all pairs and all looks protect adaptive leader selection at those looks. Computation rounds outward. Every actual inspection time, including cap and budget endpoints, is frozen in $M$. Our PPR stopping implementation returns a nominal decision; it is not inserted as a numerical marginal-gap lower bound in the robustness condition.
'''
    anchor='\\subsection{Dependency-Complete Local Execution}'
    text=text.replace(anchor,insertion+'\n'+anchor,1)
    hybrid=r'''
\subsection{A Fixed-Partition Execution Alternative}

For independent coordinates, a fixed source-incident partition $S_0$ and its complement $T$ allow a compositional alternative. Insert the intermediate law $Q_{S_0}\times P_T$ and apply the triangle inequality to each winner event. If $h_T$ is the generic event envelope with the source coordinates fixed at their nominal realization for each shared uniform draw, then
\begin{equation}
\sup_{P\in\mathcal U}\max_c |\pi_c(P)-q_c|
\le\varepsilon_{S_0}+\mathbb E h_T.
\label{eq:hybrid}
\end{equation}
Here $\varepsilon_{S_0}$ is the deterministic product-coupling bound for that partition. The nominal world and scores remain unchanged. A separately protected upper bound $b_T$ gives drift $\min(\varepsilon_{\rm scope},\varepsilon_{S_0}+b_T,1)$, with upward addition. Each hybrid policy pays its own complete-prefix evidence and retains the full-width static admission fee. Selecting the smaller of two estimated envelopes would require protecting both. This standard compositional argument is an execution alternative with mixed empirical value, not a new general coupling theorem.
'''
    text=text.replace('\\subsection{Dependence Boundaries}',hybrid+'\n\\subsection{Dependence Boundaries}',1)
    text=replace_paragraph(text,'We distinguish nominal scheduling,',r'''We separate nominal scheduling, robust query-load execution, direct inference controls, full-graph neural applicability and controlled decision value. The degree workloads use two OpenEA-derived profiles~\cite{sun2020openea} with 500 test sources and 1012 exposed targets each. Their exposed synthetic probabilities define the supplied world law. The neural maintenance setting instead uses explicitly configured Bernoulli retention. None of these laws establishes calibrated real-fact probabilities.''')
    text=replace_paragraph(text,'The robust pilot has 32 unique',r'''The completed robust workload contains 1000 distinct queries, each repeated under seeds 61, 73 and 89. Direct controls use the original 16 sources per graph and fresh streams 97, 109 and 127. Exact review selects another bounded property-defined subset for exhaustive reference. These sources have been examined before; new streams, nested query sets and timing repetitions are not independent graph-source replications. Candidate removals have universal outward range checks, and input, scorer, scope and numerical identities are frozen.''')
    text=replace_paragraph(text,'The strict budget-admission replay was designed',r'''Earlier replay exposed and repaired event-block overshoot before the incremental protocols. Their strict invariant concerns declared variable work. The new complete workloads preserve that rule and record construction, inference, serialization and memory separately. Targeted arithmetic, prefix and execution tests supplement the proofs; independent audits rederive fees, categorical decisions, paired-prefix identities and exact reference classifications.''')
    text=text.replace('Original pilot sources & 16 & 16 \\\\','Completed sources & 500 & 500 \\\\')
    text=text.replace('Pilot mean scoped edges & 599.69 & 111.94 \\\\','Mean scoped edges & 1022.58 & 526.54 \\\\')
    text=text.replace('Pilot singleton queries & 2 & 9 \\\\','Singleton queries & 120 & 202 \\\\')
    marker=text.index('figures/attempt5/scope_candidates.pdf')
    figure_start=text.rfind('\\begin{figure*}',0,marker)
    figure_end=text.index('\\end{figure*}',marker)+len('\\end{figure*}')
    text=text[:figure_start]+text[figure_end:]
    start=text.index('\\subsection{Exact Transport and Dependence Checks}')
    end=text.index('\\subsection{Robust Certification Under Strict Work Budgets}',start)
    text=text[:start]+r'''\subsection{Exact Transport and Dependence Checks}

Earlier rational-arithmetic checks cover 240 transfer decisions over six fixed winner maps, with no invalid decision, plus 36 common-shock law pairs and 72 mass/marginal checks. The endpoint-path comparison protects a weaker object than a continuous box and is not pooled with whole-family certification. The new exact review below independently solves full parameter boxes for actual structured queries. These exponential references test correctness and decisions; their cost is recorded separately from algorithm execution.

'''+text[end:]
    start=text.index('\\subsection{Robust Certification Under Strict Work Budgets}')
    end=text.index('\\section{Related Work}',start)
    insert=(PAPER/'GATE_RESULTS_INSERT_20261106.tex').read_text('utf-8').replace('gates_20261106_attempt1','gates_20261106_attempt2')
    insert=insert.replace('Eight durable shards preserve',r'The primary independent parameter box has half-width $.001$, with a 4096-world-equivalent variable-work cap. Scope-only uses nominal risk $.05$; event methods use $.025$ nominal and $.025$ over six event prefixes. Eight durable shards preserve')
    insert=insert.replace('A paired control uses 32 distinct queries, three seeds and seven policies.',r'A paired control uses 32 distinct queries, fresh seeds 97, 109 and 127, and seven policies. The Bernstein rule is Eq.~\ref{eq:eb}; the hybrid uses Eq.~\ref{eq:hybrid}.')
    insert=insert.replace('Its criterion supplies no numerical positive-gap bound for direct substitution into our robust threshold.','Its implemented zero-gap stopping criterion is not a numerical marginal-gap bound for the robust threshold.')
    insert=insert.replace('At the diagnostic 512-world budget, these counts become 61, 64 and 58.',r'At the diagnostic 512-world budget, these counts become 61, 64 and 58. The configured law pins one lowest-index incident triple per entity and retains each optional triple with probability $.9$.')
    insert=insert.replace('Retrieval uses frozen reference target-density correction.',r'Scores are $2\cos(i,c)-r_c$, where target $k$10 density $r_c$ is frozen on unperturbed full source/target pools. This differs from per-world recomputed CSLS. The graphs have 30000 entities each and 81011/88198 triples.')
    insert=insert.replace('Its bound is $.120203$.','Its conservative drift bound is approximately $.120203$.')
    insert=insert.replace('It establishes neither adaptive encoder savings nor factual probability calibration.',r'The complete 512-world capture takes 365.52 seconds and peaks at 7.41 GiB job memory. It does not measure adaptive encoder savings.')
    insert=insert.replace('evaluating exact rational multi-affine gap extrema at parameter-box vertices determines whole-box stability.',r'evaluating exact rational multi-affine gap extrema at parameter-box vertices determines whole-box stability: each gap is affine in each Bernoulli parameter separately, so repeated endpoint minimization reaches a vertex. A separate audit recomputes these extrema in reverse coordinate order and cross-checks them with direct product-mass sums.')
    insert=insert.replace('Six fixed half-widths and nine policies produce 1728 controlled cases; these repeat 32 queries.',r'Six fixed half-widths and nine policies produce 1728 controlled cases; these repeat 32 queries under source-specific fresh streams based on seed 151. Exact reference cost is excluded from method cost.')
    insert=insert.replace('The earlier source-conditioned abstraction',r'An earlier three-process cold comparison gives mean totals 10.10, 10.37 and 9.81 seconds for scope, eager and lazy; eager initialization reverses its mean comparison. The eight completed shards take about 2698 seconds including preparation and research persistence. Serving differences are therefore not universal pipeline speedups. The earlier source-conditioned abstraction')
    utility=r'''
\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{figures/online_20261104_attempt1/alignment_risk_coverage.pdf}
\caption{Retained external-label risk--coverage results from the frozen RREA study, averaged over three paired model/world seeds on 256 sources per graph. Valid model-query certificates can select less accurate entity links.}
\label{fig:utility}
\end{figure*}

'''
    text=text[:start]+insert+'\n'+utility+text[end:]
    text=replace_paragraph(text,'Our ICDM 2024 work studies',r'''Our ICDM work studies probabilistic graph alignment~\cite{li2024probabilisticea}. Its public thesis treatment develops Gaussian PGNN representations, likelihood learning and Markov-chain exploration of alignment-label posteriors, including confidence intervals and Brier evaluation~\cite{li2025thesis}. ScopeRace instead fixes a scoring mapping and samples independent graph worlds for protected modal-query execution. The thesis and conference publication remain distinct sources. We claim neither a new PGNN/MCMC model nor the first uncertainty-aware alignment output.''')
    text=replace_paragraph(text,'The robust degree experiments use',r'''Completed 500-query workloads establish the stated query-load behavior, while direct PPR controls sharpen the nominal baseline. Full-graph RREA supports nonempty robustness for a restricted maintenance request; the wider full-edge box remains vacuous. Exact references verify safe approvals, unsafe family-wide use of nominal shortcuts and avoidable reviews under controlled laws. These results do not establish industrial demand, factual calibration or a graph-size scaling law. Adding unsupported edges or imposing global one-to-one assignment changes the contract.''')
    text=replace_paragraph(text,'The demonstrated value is',r'''ScopeRace contributes conditional modal-query processing through evidence-preserving physical execution. Its statistical and coupling tools are attributed; broader deployment workloads remain open, and label-utility failures limit automatic matching claims.''')
    text=replace_paragraph(text,'OpenAI Codex assisted manuscript',r'''OpenAI Codex assisted drafting the abstract and Sections I--IX, literature lookup, protocol and code preparation, figure generation, and artifact inspection. The authors are responsible for checking correctness, originality, attribution and the submitted results.''')
    (PAPER/'main.tex').write_text(text,encoding='utf-8')
    bib=(PAPER/'history/pre_gate_20261104/references.bib').read_text('utf-8-sig')
    bib+='\n'+(PAPER/'references_gate_extra.bib').read_text('utf-8')
    bib+=r'''
@inproceedings{maurer2009empirical,
  author = {Andreas Maurer and Massimiliano Pontil},
  title = {Empirical Bernstein Bounds and Sample Variance Penalization},
  booktitle = {Proceedings of the Conference on Learning Theory},
  year = {2009},
  url = {https://arxiv.org/abs/0907.3740}
}
'''
    (PAPER/'references.bib').write_text(bib,encoding='utf-8')
    print({'word_tokens':len(text.split()),'figures':text.count('\\begin{figure*}'),'tables':text.count('\\begin{table')})

if __name__=='__main__':main()
