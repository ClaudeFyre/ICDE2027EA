"""Report the frozen matched experiment; no query execution or policy tuning."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'nodes/09_vldb_query_certification/results/icde_block_comparison_20261109'
MATCH = BASE / 'matched_anchor_pruning_attempt1'
TIGHT = ROOT / 'nodes/09_vldb_query_certification/results/icde_pair_event_tightness_20261108/attempt1'
OUT = BASE / 'report_attempt1'
METHODS = ['direct_transport', 'generic_eager', 'factor_event', 'block_event2']
LABELS = ['Scalar transport', 'Abstract MC', 'Factor event', 'Block event (2)']


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def analyze():
    import numpy as np
    if OUT.exists():
        raise FileExistsError('Use a new report attempt rather than overwriting.')
    OUT.mkdir()
    summary = load(MATCH / 'summary.json')
    inventory = load(MATCH / 'anchor_pruning_inventory.json')['rows']
    tight = load(TIGHT / 'summary.json')
    validation = load(BASE / 'validation_20261109.json')
    assert validation['status'] == 'PASS'
    keys = [(r['graph'], r['rank']) for r in inventory]
    inv = {(r['graph'], r['rank']): r for r in inventory}
    runs = {(r['graph'], r['rank'], r['policy']): r for r in summary['rows']}
    easy = {k for k in keys if inv[k]['trivial_after_pruning'] or inv[k].get('satisfies_original_prototype_limits_after_pruning', False)}
    hard = set(keys) - easy
    assert len(keys) == 259 and len(easy) == 30 and len(hard) == 229
    def stable(k, m):
        r = runs[(*k, m)]
        return r['details']['status'] == 'stable' and not r['timed_out'] and r['compute_seconds'] <= .2
    counts = {name: {m: sum(stable(k, m) for k in subset) for m in METHODS}
              for name, subset in [('all259', keys), ('simplified30', easy), ('remaining229', hard)]}
    costs = {}
    for m in METHODS:
        # This penalty treats every failure as using the full delivery allowance.
        # It is NOT measured runtime, or a completed-query-only speed comparison.
        costs[m] = float(np.mean([runs[(*k, m)]['compute_seconds'] if stable(k, m) else .2 for k in keys]))
    delta = np.array([int(stable(k, 'block_event2')) - int(stable(k, 'generic_eager')) for k in keys])
    rng = np.random.default_rng(20261109)
    bs = np.zeros(10000)
    for graph in sorted({k[0] for k in keys}):
        d = delta[np.array([k[0] == graph for k in keys])]
        bs += d[rng.integers(0, len(d), size=(10000, len(d)))].sum(axis=1)
    bs *= 100 / len(keys)
    plus, minus = int(sum(delta == 1)), int(sum(delta == -1))
    n = plus + minus
    paired_p = min(1., 2 * sum(math.comb(n, x) for x in range(min(plus, minus) + 1)) / 2**n)
    stats = {'difference_pp': float(100 * delta.mean()), 'block_only': plus, 'eager_only': minus,
             'common': sum(stable(k, 'block_event2') and stable(k, 'generic_eager') for k in keys),
             'bootstrap_percentile95_pp': np.quantile(bs, [.025, .975]).tolist(),
             'bootstrap_repetitions': 10000, 'seed': 20261109, 'stratification': 'graph; paired query resampling',
             'discordance_exact_two_sided_p': paired_p,
             'interpretation': 'Descriptive historical-development workload uncertainty; one timing run per method, not independent confirmation.'}
    frontier = [r for r in tight['references'] if r['role'] == 'frontier']
    data = {'date': '2026-11-09', 'counts': counts, 'stratum_sizes': {'all259': 259, 'simplified30': 30, 'remaining229': 229},
            'aggregates': summary['aggregates'], 'paired_block_minus_eager': stats,
            'mean_capped_stable_delivery_penalty_seconds': costs,
            'penalty_definition': 'actual compute time if stable within 0.2s; 0.2 otherwise; not measured runtime',
            'active_G_median': float(np.median([r['active_G'] for r in inventory])),
            'active_log2_S_median': float(np.median([r['active_log2_S'] for r in inventory])),
            'frontier_exact_seconds': {'sum': sum(r['compute_seconds'] for r in frontier),
                'median': float(np.median([r['compute_seconds'] for r in frontier])),
                'maximum': max(r['compute_seconds'] for r in frontier)},
            'source_sha256': {str(p.relative_to(ROOT)).replace('\\', '/'): digest(p) for p in
                [MATCH/'summary.json', MATCH/'anchor_pruning_inventory.json', TIGHT/'summary.json', BASE/'validation_20261109.json', Path(__file__)]},
            'decision': 'large-scale clear-advantage gate NOT passed; maintain ICDE target, no submission-readiness claim'}
    save(OUT / 'analysis.json', data)
    lines = ['# 大规模可靠界验证：最终匹配对照', '', '2026-11-09。主比较为 matched_anchor_pruning_attempt1；其余尝试仅作开发记录。', '',
        '[说明文本已清理]', '',
        '[说明文本已清理]', '',
        '## 2. 成对与分别事件界', '',
        '对名义赢家w，计算 Δ=min_d inf_p(π_w−π_d)−[inf_p π_w−max_d sup_p π_d]，保留精确分数。', '',
        '- 原148查询：27个精确Δ>0，其中25个>10⁻¹²；中位数及75%分位均为0，均值0.006786，最大0.147875。',
        '- G分组均值：3–4组为0.000091，5–6组为0.006572，7–8组为0.022874。整体Spearman为0.419，但仅K≥3时降为0.271；二候选61例因互补恒等式全部为0。',
        '- 原101个鲁棒查询中，仅11个有>10⁻¹²的瓶颈增益；成对与分别事件仍均认证101个。',
        '- 从259中仅按静态S≤65536选出全部19个边界查询，全部取得精确参考，7鲁棒、12非统一。这7个的瓶颈增益全为0；19个整体G–Δ相关为−0.117。',
        '- 原集合G=3–8，边界集合G=6–10；不能外推为G≈26的实证趋势。当前优先事件级实现，成对界保留为对照。', '',
        '19个参考的已准备内核计算合计%.6fs，中位%.6fs，最慢%.6fs，不含加载。它们是原型门槛外而仍可精确求解的查询，不能把259例统称为精确不可解。' % (data['frontier_exact_seconds']['sum'], data['frontier_exact_seconds']['median'], data['frontier_exact_seconds']['maximum']), '',
        '## 3. 全259查询：同内核、同剪枝、同预算', '',
        '每方法每查询一次、200ms协作式计算预算。使用相同稀疏内核、全局分数安全剪枝、局部scope更新与计费缓存；计时包含方法内部剪枝和重建，不含另报的图加载。晚到证书不计入交付，协作计时仍可能超时，不能称硬延迟保证。', '',
        '| 方法 | 全259稳定 | 简化30稳定 | 剩余229稳定 | 超时 | 未准入 | 未决 | 非统一反例 | 平均gap区间宽度 |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for m, label in zip(METHODS, LABELS):
        a = summary['aggregates'][m]; st = a['statuses']
        lines.append('| %s | %d | %d | %d | %d | %d | %d | %d | %.4f |' % (label, counts['all259'][m], counts['simplified30'][m], counts['remaining229'][m], st.get('timeout', 0), st.get('resource_not_admitted', 0), st.get('unresolved', 0), st.get('nonuniform', 0), a['mean_gap_interval_width']))
    lines += ['', '“简化30”包含剪枝后4个单候选及26个重新满足原精确原型门槛的竞争查询；其余229个仍不满足门槛。总体+6的来源是较容易简化的部分（21对13），核心难例上分块24对MC26。原竞争查询分母为407，原型可行为148/407=36.36%；576总量中的169个单候选不进入竞争可行率。', '',
        '分块与MC：共同成功%d个、分块独有%d个、MC独有%d个。配对差值%.3f个百分点；按图分层、查询配对自助法的描述性95%%区间为[%.3f, %.3f]个百分点，跨0；不一致对的精确双侧检验p=%.3f。本工作负载为历史开发集，且只计时一次，不能替代新查询及多次计时确认。' % (stats['common'], plus, minus, stats['difference_pp'], *stats['bootstrap_percentile95_pp'], paired_p), '',
        '[说明文本已清理]', '',
        '## 4. 成本口径与验证', '',
        '分块实际总计算时间更低，但包含大量快速未准入与未决，不能写成相对MC的速度提升。将所有未稳定交付计作完整0.2s惩罚后，各方法均值如下（这是交付惩罚，不是实测运行时）：', '']
    lines += ['- %s：%.6fs。' % (label, costs[m]) for m, label in zip(METHODS, LABELS)]
    lines += ['', '独立验证PASS：17,146项检查、1,036次方法运行、167个精确参考；全部45个分块批准重算，包含157个局部精确块、446个极值点的独立标量求值。它核对实现与合同，不把240个未知全局真值视为已验证。', '',
        '## 5. 方法实质与适用边界', '',
        '原型将竞争者两两分块，在保留原分数及tie顺序的限制候选集内精确求事件界，再用union bound组合。共享输入依赖没有被假设独立；不过跨块失败可能重复计费，各块最坏参数也可能不同，因此方法仍保守。负下界只表示未决。', '',
        '标准分组计数、多线性端点、事件限制及union bound均有先行基础。factor_event是标准因子化事件松弛对照，不是已发表Credal Circuits完整软件；共享事件与多输出也非本文独占。当前degree评分器满足候选限制不改变分数，不能直接覆盖全局归一化或集体匹配模型。', '',
        '## 6. 后续决策', '',
        '[说明文本已清理]', '',
        '新方法若在仍困难的竞争查询上、相同构造和计算费用下有稳定交付优势，再扩大盲测、重复计时与完整credal/部分编译系统对照；否则保留为系统性实验分析资产。实验分析类路线仅为备选，未自动切回PVLDB。', '',
        '配置维护有公开需求证据但缺乏与独立保留参数完全匹配的真实配置日志；OpenRefine阈值/权重调整与Wikidated数据变更不可冒充当前保留参数日志。当前无实测免重算收益；不得恢复“事实概率已校准”或“对齐准确率有增量改善”的主张。', '',
        '来源：相邻matched_anchor_pruning_attempt1/{protocol,summary,anchor_pruning_inventory}.json、../validation_20261109.json；精确界源位于icde_pair_event_tightness_20261108/attempt1。文件SHA-256和描述性统计保存于analysis.json。']
    (OUT / 'RESULTS_ZH.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'counts': counts, 'paired': stats, 'penalty': costs}, indent=2))


def plot():
    sys.path.insert(0, str(ROOT / '.runtime/icde_plot_site'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    d = load(OUT / 'analysis.json'); t = load(TIGHT / 'summary.json')
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.8), constrained_layout=True)
    colors = ['#939aab', '#34659c', '#b48a42', '#20775e']
    ax = axes[0, 0]
    for role, color, marker in [('known', '#34659c', 'o'), ('frontier', '#be6638', '^')]:
        rows = [r for r in t['rows'] if r['role'] == role]
        for i, r in enumerate(rows):
            jitter = ((i * 37) % 19 - 9) / 65
            ax.scatter(r['group_count'] + jitter, r['bottleneck_gain'], color=color, marker=marker, s=20, alpha=.65, label=(f'{role} (n={len(rows)})' if i == 0 else None))
    ax.set(xlabel='Count groups G (jittered)', ylabel='Exact pair minus separate gap', title='(a) Tightness gain: limited to G = 3–10')
    ax.legend(frameon=False, fontsize=8); ax.set_ylim(-.006, .16)
    for ax, key, title in [(axes[0, 1], 'all259', '(b) All 259 originally excluded queries'), (axes[1, 0], 'remaining229', '(c) 229 still outside limits after pruning')]:
        vals = [d['counts'][key][m] for m in METHODS]
        bars = ax.bar(range(4), vals, color=colors, width=.65)
        ax.bar_label(bars, padding=3)
        ax.set_xticks(range(4), ['Scalar\ntransport', 'Abstract\nMC', 'Factor\nevent', 'Block\nevent (2)'])
        ax.set(ylabel='Stable answers within 200 ms', title=title, ylim=(0, 54))
    ax = axes[1, 1]
    widths = [d['aggregates'][m]['mean_gap_interval_width'] for m in METHODS]
    bars = ax.bar(range(4), widths, color=colors, width=.65)
    ax.bar_label(bars, fmt='%.3f', padding=3)
    ax.set_xticks(range(4), ['Scalar\ntransport', 'Abstract\nMC', 'Factor\nevent', 'Block\nevent (2)'])
    ax.set(ylabel='Mean reported gap interval width', title='(d) Delivered bounds, including unresolved', ylim=(0, 2.22))
    ax.text(.03, .08, 'Missing or late evidence uses [−1, 1].\nLower width alone does not establish superiority.', transform=ax.transAxes, fontsize=8)
    for ax in axes.flat:
        ax.spines[['top', 'right']].set_visible(False)
        ax.grid(axis='y', alpha=.15); ax.set_axisbelow(True)
        ax.title.set_fontsize(10)
    fig.suptitle('Scalability screen: the hard-query advantage gate is not passed', fontsize=13)
    folder = OUT / 'figures'; folder.mkdir()
    for ext in ['png', 'pdf']:
        fig.savefig(folder / f'scalability_gate.{ext}', dpi=180)
    plt.close(fig)
    save(OUT / 'manifest.json', {'files': {p.relative_to(OUT).as_posix(): digest(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name != 'manifest.json'}, 'sources': d['source_sha256']})
    print('Scientific PNG/PDF and manifest saved.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--phase', choices=['analyze', 'plot'], required=True)
    args = parser.parse_args()
    {'analyze': analyze, 'plot': plot}[args.phase]()
