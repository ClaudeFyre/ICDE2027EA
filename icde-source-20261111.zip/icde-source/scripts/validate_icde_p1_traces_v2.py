"""Validate the P1 *v2* traces: schema v1 compliance PLUS the review fixes.

Extra assertions over ``validate_icde_p1_traces.py``:
  * the global train/blind source partition is disjoint: train ∩ blind = ∅;
  * every query source inside a trace belongs to that trace's declared split
    source set, and the other split's sources never appear;
  * the hub_factor_updates update chain is replayed from its events and each
    ``resulting_snapshot`` digest is re-derived from the ACTUAL mutated graph /
    probability vector / factor law -- add/delete bind the modified graph's
    digest, update_probability rebinds the probability digest, update_factor
    rebinds the factor digest.

Writes ``validation_report.json`` in the output root; exits non-zero on failure.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC = REPO_ROOT / "src"
SCRIPTS = REPO_ROOT / "scripts"
for p in (SRC, SCRIPTS):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from build_icde_p1_traces_v2 import TOY_DIR, ToyGraphState  # noqa: E402
from pkgea.backbones.toy import ToyStructuralBackbone  # noqa: E402

ALLOWED_KINDS = {"query", "update_probability", "add", "delete", "update_factor",
                 "update_attribute", "model", "pool", "schema", "rollback", "fault"}
REQUIRED_EVENT = {"trace_id", "event_id", "sequence", "kind", "arrival_ns"}
QUERY_PAYLOAD = {"request_id", "source", "ordered_candidates", "requested_snapshot",
                 "delta", "world_budget"}


def parse_iso(value):
    return datetime.fromisoformat(value)


def check_trace_schema(tdir: Path, errors: list[str], kinds: dict) -> list[dict]:
    trace_path = tdir / "trace.jsonl"
    events = [json.loads(l) for l in trace_path.open(encoding="utf-8") if l.strip()]
    seen = set()
    expected_seq = 0
    prev_arr = -1
    for ev in events:
        missing = REQUIRED_EVENT - set(ev)
        if missing:
            errors.append(f"{tdir.name}: missing {sorted(missing)}")
        eid = ev.get("event_id")
        if eid in seen:
            errors.append(f"{tdir.name}: duplicate event_id {eid}")
        seen.add(eid)
        expected_seq += 1
        if ev.get("sequence") != expected_seq:
            errors.append(f"{tdir.name}: sequence mismatch at {eid}")
        kind = ev.get("kind")
        kinds[kind] = kinds.get(kind, 0) + 1
        if kind not in ALLOWED_KINDS:
            errors.append(f"{tdir.name}: bad kind {kind}")
        arr = ev.get("arrival_ns", -1)
        if arr < prev_arr:
            errors.append(f"{tdir.name}: arrival_ns not monotone at {eid}")
        prev_arr = arr
        for f in ("event_time", "observation_time"):
            if f not in ev:
                errors.append(f"{eid}: missing {f}")
            else:
                try:
                    parse_iso(ev[f])
                except Exception:
                    errors.append(f"{eid}: bad {f}")
        if kind == "query":
            miss = QUERY_PAYLOAD - set(ev)
            if miss:
                errors.append(f"{eid}: query missing {sorted(miss)}")
            if "request_id" not in ev:
                errors.append(f"{eid}: missing request_id")
    return events


def replay_hub_chain(events, errors, tdir_name):
    """Re-derive each resulting_snapshot from the real mutated graph."""
    backbone = ToyStructuralBackbone.from_dataset(TOY_DIR)
    state = ToyGraphState(backbone)
    expected_base = state.snapshot().digest
    n_updates = 0
    for ev in events:
        kind = ev["kind"]
        if kind not in ("update_probability", "add", "delete", "update_factor"):
            continue
        if ev.get("base_snapshot") != expected_base:
            errors.append(f"{tdir_name}: update {ev['event_id']} base_snapshot != "
                          f"re-derived {ev['base_snapshot'][:10]} vs {expected_base[:10]}")
        if kind == "update_probability":
            edge_id = ev["edge_id"]
            head, tail = edge_id.split("edge:", 1)[1].split("/", 1)
            idx = next((i for i, (h, _r, t) in enumerate(state.triples)
                        if h == head and t == tail), None)
            if idx is None:
                errors.append(f"{tdir_name}: update_probability edge {edge_id} not found")
                continue
            state.probs[idx] = float(ev["new_p"])
        elif kind == "add":
            fp = ev["fact_payload"]
            state.triples.append((fp["head"], fp["relation"], fp["tail"]))
            state.probs.append(float(fp["confidence"]))
            state.groups.append("")
        elif kind == "delete":
            fp = ev["fact_payload"]
            idx = next((i for i, (h, _r, t) in enumerate(state.triples)
                        if h == fp["head"] and t == fp["tail"]), None)
            if idx is None:
                errors.append(f"{tdir_name}: delete edge not found")
                continue
            del state.triples[idx]
            del state.probs[idx]
            del state.groups[idx]
        elif kind == "update_factor":
            np_ = ev["new_factor_parameters"]
            state.groups = list(np_["dependency_groups"])
            state.rho = float(np_["common_shock_probability"])
        expected_base = state.snapshot().digest
        if ev.get("resulting_snapshot") != expected_base:
            errors.append(f"{tdir_name}: {kind} {ev['event_id']} resulting_snapshot != "
                          f"re-derived graph digest")
        n_updates += 1
    return n_updates


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path,
                    default=REPO_ROOT / "nodes" / "05_icde_query_engine" / "results" / "icde_traces_v2_20261009")
    args = ap.parse_args(argv)
    root = args.root

    summary = json.loads((root / "build_summary.json").read_text(encoding="utf-8"))
    train = set(summary["split_rule"]["train_sources"])
    blind = set(summary["split_rule"]["blind_sources"])
    global_errors: list[str] = []
    overlap = train & blind
    if overlap:
        global_errors.append(f"train∩blind non-empty: {len(overlap)} sources overlap")

    reports = []
    for t in summary["traces"]:
        # Resolve the per-trace dir against the summary's own directory (portable
        # form). ``t["dir"]`` is the repo-relative basename; the legacy absolute
        # windows_origin_dir is provenance-only and never trusted on a fresh host.
        tdir = root / t["dir"]
        errors: list[str] = []
        kinds: dict = {}
        events = check_trace_schema(tdir, errors, kinds)
        manifest = json.loads((tdir / "manifest.json").read_text(encoding="utf-8"))

        # source-isolation: query sources must belong to this trace's split.
        split = t["split"]
        allowed = set(manifest["split_source_cluster"]["this_split_sources"])
        other = blind if split == "train" else train
        for ev in events:
            if ev["kind"] != "query":
                continue
            src = ev["source"]
            if src not in allowed:
                errors.append(f"{tdir.name}: query source {src} not in {split} split set")
            if src in other:
                errors.append(f"{tdir.name}: query source {src} leaked into {split} from other split")

        n_updates = 0
        if t["group"] == "hub_factor_updates":
            n_updates = replay_hub_chain(events, errors, tdir.name)

        # manifest n_events consistency
        if manifest["trace_partition"]["n_events"] != len(events):
            errors.append(f"{tdir.name}: manifest n_events mismatch")
        reports.append({"trace_id": t["trace_id"], "dir": str(tdir), "ok": not errors,
                        "errors": errors, "kinds": kinds, "n_updates_replayed": n_updates})

    n_ok = sum(1 for r in reports if r["ok"] and not global_errors)
    out = {
        "format": "icde-p1-trace-validation-v2",
        "root": str(root),
        "train_source_count": len(train),
        "blind_source_count": len(blind),
        "train_blind_intersection": len(overlap),
        "intersection_empty": not overlap,
        "global_errors": global_errors,
        "n_traces": len(reports),
        "n_ok": n_ok,
        "n_failed": len(reports) - n_ok + (1 if global_errors else 0),
        "reports": reports,
    }
    (root / "validation_report.json").write_text(
        json.dumps(out, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"n_traces": len(reports), "n_ok": n_ok,
                      "intersection_empty": not overlap,
                      "global_errors": global_errors}))
    return 0 if n_ok == len(reports) and not global_errors else 1


if __name__ == "__main__":
    sys.exit(main())
