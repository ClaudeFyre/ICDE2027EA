"""Controlled degree-query maintenance review with an exact full-box reference.

No claim of a new exact algorithm, calibrated fact probabilities, deployment
demand or measured human savings is made. Multi-affine extrema on independent
Bernoulli boxes are attained at parameter vertices. Fractions encode the exact
binary floating-point inputs; the winner map is the frozen float64 scorer.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from dataclasses import replace
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import threading
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
TAUS = (.001, .01, .05, .1, .25, 1.)
THRESHOLDS = (.01, .05, .1, .2)
PURPOSE = "icde-exact-review-20261105"
SALT = "vldb-v0-20261104"
DEFAULT_PREFIX = ROOT / "nodes/09_vldb_query_certification/results/icde_gate_scale500_20261104_s"


def fraction(value):
    return Fraction.from_float(value) if isinstance(value, float) else Fraction(value)


def tensor_vertex_transform(values, low, high):
    """Bit e denotes world-coordinate e, and then low/high parameter choice e."""
    low, high = tuple(map(fraction, low)), tuple(map(fraction, high))
    m = len(low)
    if len(high) != m or len(values) != 1 << m:
        raise ValueError("need 2^m values and matching endpoint vectors")
    if any(not 0 <= left <= right <= 1 for left, right in zip(low, high)):
        raise ValueError("invalid independent probability box")
    result = list(map(fraction, values))
    for edge, (left, right) in enumerate(zip(low, high)):
        bit = 1 << edge
        for zero in range(len(result)):
            if zero & bit:
                continue
            one = zero | bit
            a, b = result[zero], result[one]
            result[zero] = (1 - left) * a + left * b
            result[one] = (1 - right) * a + right * b
    return tuple(result)


def exact_expectation(values, parameters):
    parameters = tuple(map(fraction, parameters))
    if len(values) != 1 << len(parameters):
        raise ValueError("world vector has wrong length")
    result = Fraction(0)
    for world, value in enumerate(values):
        mass = Fraction(1)
        for edge, probability in enumerate(parameters):
            mass *= probability if world & (1 << edge) else 1 - probability
        result += fraction(value) * mass
    return result


def lex_vertices(m):
    return sorted(range(1 << m), key=lambda index: tuple((index >> edge) & 1 for edge in range(m)))


def full_box_reference(winners, candidate_count, q, low, high):
    q, low, high = tuple(map(fraction, q)), tuple(map(fraction, low)), tuple(map(fraction, high))
    m = len(q)
    if len(winners) != 1 << m or candidate_count < 1 or any(not 0 <= w < candidate_count for w in winners):
        raise ValueError("invalid complete winner map")
    if len(low) != m or len(high) != m or any(not left <= p <= right for p, left, right in zip(q, low, high)):
        raise ValueError("nominal law must lie in the declared box")
    indicators = [tuple(int(winner == candidate) for winner in winners) for candidate in range(candidate_count)]
    nominal = [exact_expectation(indicator, q) for indicator in indicators]
    vertex_probabilities = [tensor_vertex_transform(indicator, low, high) for indicator in indicators]
    vertices = lex_vertices(m)
    results = []
    for candidate in range(candidate_count):
        pairs = []
        for competitor in range(candidate_count):
            if competitor == candidate:
                continue
            gaps = [vertex_probabilities[candidate][index] - vertex_probabilities[competitor][index]
                    for index in range(1 << m)]
            minimum, maximum = min(gaps), max(gaps)
            minimum_vertex = next(index for index in vertices if gaps[index] == minimum)
            pairs.append({"competitor_index": competitor, "minimum_gap": str(minimum),
                          "maximum_gap": str(maximum),
                          "minimum_vertex_bits": [(minimum_vertex >> edge) & 1 for edge in range(m)]})
        safe = all(Fraction(pair["minimum_gap"]) > 0 for pair in pairs)
        witness = None
        if not safe:
            for index in vertices:
                for competitor in range(candidate_count):
                    if competitor == candidate:
                        continue
                    gap = vertex_probabilities[candidate][index] - vertex_probabilities[competitor][index]
                    if gap <= 0:
                        witness = {"competitor_index": competitor,
                            "vertex_bits": [(index >> edge) & 1 for edge in range(m)],
                            "parameter_values_exact": [str(high[edge] if index & (1 << edge) else low[edge]) for edge in range(m)],
                            "candidate_probability_exact": str(vertex_probabilities[candidate][index]),
                            "competitor_probability_exact": str(vertex_probabilities[competitor][index]),
                            "gap_exact": str(gap)}
                        break
                if witness is not None:
                    break
        results.append({"candidate_index": candidate, "uniformly_unique_mode": safe,
                        "pair_gap_ranges": pairs, "unsafe_witness": witness})
    uniform = [result["candidate_index"] for result in results if result["uniformly_unique_mode"]]
    maximum = max(nominal)
    return {"world_count": 1 << m, "parameter_vertex_count": 1 << m,
        "world_bits": "coordinate0 is least significant; vertex witnesses use coordinate-order lexicographic ties",
        "q_exact": list(map(str, q)), "low_exact": list(map(str, low)), "high_exact": list(map(str, high)),
        "nominal_probabilities_exact": list(map(str, nominal)),
        "nominal_modes": [index for index, probability in enumerate(nominal) if probability == maximum],
        "uniform_winners": uniform, "exact_ambiguous": not uniform,
        "ambiguity_meaning": "no single candidate is the unique mode throughout this box; includes a possible boundary tie",
        "candidate_results": results,
        "reference_semantics": "classical exact independent-product calculation for the fixed float64 winner map; not a finite parameter grid"}


def classify_review(candidate, reference):
    approved = candidate is not None
    exists = bool(reference["uniform_winners"])
    safe = approved and candidate in reference["uniform_winners"]
    return {"approved": approved, "uniform_safe": safe,
            "false_clear": approved and not safe, "reviewed": not approved,
            "avoidable_review": not approved and exists, "exists_uniform_winner": exists,
            "exact_ambiguous": not exists}


def family_settings(engine, base, tau):
    """Preserve one-box risk allocation at the closed full-cube endpoint.

    The frozen risk-plan constructor rejects the label tau=1 although the
    scorer/envelope accepts [0,1]. Its allocation depends only on one box and
    the fixed prefix list. Reuse that identical allocation, then bind actual
    tau=1 and actual low/high arrays to run_case; no endpoint is substituted.
    """
    if tau not in TAUS:
        raise ValueError("family width was not frozen in the protocol")
    settings = engine.settings_from_config({**base, "tau": tau if tau < 1 else TAUS[0]})
    if tau == 1:
        settings = {**settings, "tau": 1.,
                    "full_cube_risk_label_adapter": "same one-box/fixed-look risk allocation; actual endpoint arrays are [0,1]"}
    return settings


def load(path):
    return json.loads(Path(path).read_text("utf-8-sig"))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + ".pending")
    with pending.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(pending, path)


def choose_inputs(prefix, requested, max_scope):
    properties, orders, records, profiles = {}, {}, [], {}
    for shard in range(8):
        folders = sorted(path for path in prefix.parent.glob(prefix.name + f"{shard:02d}_attempt*") if path.is_dir())
        if len(folders) != 1:
            raise ValueError("each frozen500 shard must have one explicit attempt")
        folder = folders[0]
        manifest = load(folder / "protocol_freeze.json")
        checkpoint = load(folder / "checkpoint.json")
        if checkpoint["status"] != "COMPLETE":
            raise ValueError("500 source-property inventory is incomplete")
        for profile in manifest["profiles"]:
            graph = profile["graph"]
            if graph in orders and orders[graph] != profile["full500_source_order"]:
                raise ValueError("source ordering changed between shards")
            orders[graph], profiles[graph] = profile["full500_source_order"], profile
        for attempt in checkpoint["attempts"]:
            for path in sorted((folder / "attempts" / attempt).glob("setup_*.json")):
                report = load(path)
                records.append({"path": str(path.relative_to(ROOT)), "sha256": sha(path)})
                for query in report["query_setup"]:
                    key = report["graph"], query["query_id"]
                    value = {"candidate_count": query["candidate_count"], "scope_edge_count": query["scope_edge_count"],
                             "candidate_ids": query["candidate_ids"], "scope_edge_indices": query["scope_edge_indices"]}
                    if key in properties and properties[key] != value:
                        raise ValueError("input/scorer properties differ across attempts")
                    properties[key] = value
    selection = {}
    for graph, order in orders.items():
        if not len(order) == len(set(order)) == 500:
            raise ValueError("invalid original500 source inventory")
        if order != sorted(order, key=lambda source: (hashlib.sha256(f"{SALT}|{source}".encode()).digest(), source)):
            raise ValueError("source inventory is not in the originalV0 hash order")
        if any((graph, source) not in properties for source in order):
            raise ValueError("missing source-property metadata")
        eligible = [source for source in order if properties[graph, source]["candidate_count"] > 1
                    and properties[graph, source]["scope_edge_count"] <= max_scope]
        selected = eligible[:requested]
        selection[graph] = {"full500_source_order": order, "eligible_count": len(eligible),
            "requested_count": requested, "actual_count": len(selected), "selected_query_ids": selected,
            "selected_properties": {source: properties[graph, source] for source in selected},
            "input_profile": profiles[graph]}
    return selection, records


def watchdog(output, finished, started, seconds):
    if not finished.wait(max(0., seconds - (time.monotonic() - started))):
        try:
            atomic_json(output / "deadline.json", {"status": "JOB_DEADLINE", "limit_seconds": seconds,
                "elapsed_seconds": time.monotonic() - started, "completed_case_files_preserved": True})
        finally:
            os._exit(124)


def execute(args, output, started):
    config_path = args.config.resolve()
    config = load(config_path)
    prefix = args.scale_root_prefix.resolve()
    selection, inventories = choose_inputs(prefix, args.queries_per_graph, args.max_scope)
    dependencies = {Path(__file__).resolve(), ROOT / "scripts/test_icde_gate_exact_review.py", config_path,
        ROOT / "scripts/icde_gate_scale_runner.py", ROOT / "scripts/icde_gate_comparison_runner.py",
        ROOT / "scripts/icde_gate_inference.py", ROOT / "scripts/icde_online_execution.py"}
    dependencies.update((ROOT / "scripts").glob("*vldb*.py"))
    dependencies.update((ROOT / "src/pkgea").rglob("*.py"))
    for chosen in selection.values():
        frozen = chosen["input_profile"]
        dataset_path = ROOT / frozen["dataset_path"]
        for filename, expected in frozen["input_sha256"].items():
            path = dataset_path / filename
            if sha(path) != expected:
                raise ValueError("current input differs from the frozen500 source-property inventory")
            dependencies.add(path)
    if args.include_hybrid:
        dependencies.update((ROOT / "scripts/icde_gate_hybrid_runner.py", ROOT / "scripts/icde_gate_hybrid_envelope.py"))
    source_hashes = {str(path.relative_to(ROOT)): sha(path) for path in sorted(dependencies)}
    protocol = {"schema": "icde-exact-maintenance-review-v1", "config": config,
        "selection": selection, "inventory_files": inventories, "source_sha256": source_hashes,
        "selection_rule": "first eligible sources in originalV0 hash order; K>1 and complete_scope<=max_scope; only saved input/scorer properties inspected",
        "MC_outcomes_used_for_selection": False, "max_scope": args.max_scope,
        "tau_grid": list(TAUS), "seed": 151, "seed_purpose": PURPOSE,
        "policies": ["ppr_nominal", "normal_scope", "normal_event"] + (["normal_hybrid"] if args.include_hybrid else []),
        "point_baselines": {"all_present": True, "strict_margin_thresholds": list(THRESHOLDS)},
        "sample_cap": 4096, "risk": "per policy/query/family nominal stream total0.05; no aggregate or best-policy guarantee",
        "world_law": "Independent Bernoulli coordinates with nominal q from frozen exposed confidence values; each family uses outward clipped(q-tau,q+tau) on the complete scope. These are controlled model/retention parameters, not calibrated fact probabilities.",
        "exact_reference": "all2^m float64 scorer winners, exact Fraction product laws and all parameter vertices; strict pair gaps",
        "time_accounting": "setup and exact reference separated from method serving; reference work not credited to algorithms",
        "shortcut_contract": "PPR is a valid nominal-mode baseline, not a robust procedure; treating it as update clearance is an explicitly unchecked shortcut control, not a claim PPR violates its nominal guarantee.",
        "tau1_compatibility": "The old risk-plan constructor disallows the label1; its width-independent one-box allocation is retained by the new explicit adapter, while actual tau1 and actual [0,1] endpoints are used for scoring/events/reference.",
        "usecase": "controlled retention-parameter maintenance review; no real deployment, human-saving or fact-calibration claim"}
    atomic_json(output / "protocol_freeze.json", protocol)
    # All input/scorer-property selection is frozen before these imports/setup audits.
    import numpy as np
    import icde_online_execution as engine
    import icde_gate_comparison_runner as comparison
    from icde_gate_scale_runner import selected_query_setup
    from run_vldb_interval_gate_v1 import clipped_box, conservative_scope_tv
    hybrid = None
    if args.include_hybrid:
        import icde_gate_hybrid_runner as hybrid
    if os.environ.get("PYTHONHASHSEED") != "0":
        raise ValueError("launch with frozen PYTHONHASHSEED=0")
    cases, graph_timings = [], []
    for graph_index, profile in enumerate(config["profiles"]):
        graph = profile["graph"]
        chosen = selection[graph]
        ids = chosen["selected_query_ids"]
        if not ids:
            graph_timings.append({"graph": graph, "selected": 0, "status": "NO_ELIGIBLE_INPUTS"})
            continue
        base = {**config, "query_count": len(ids), "expected_query_pool": 500,
            "selection_salt": SALT, "seeds": [151], "seed_purpose": PURPOSE,
            "sample_count": 4096, "delta_total": .05, "delta_nominal": .025, "beta_total": .025}
        settings = engine.settings_from_config(base)
        t = time.perf_counter()
        with selected_query_setup(engine, chosen["full500_source_order"], ids):
            prepared, report = engine.setup_graph({**profile, "expected_query_ids": ids}, settings)
        setup_seconds = time.perf_counter() - t
        if (report["dataset_revision"] != chosen["input_profile"]["dataset_revision"]
                or report["input_sha256"] != chosen["input_profile"]["input_sha256"]):
            raise ValueError("rebuilt query uses a different input revision")
        graph_slug = hashlib.sha256(graph.encode()).hexdigest()[:12]
        atomic_json(output / f"setup_{graph_slug}.json", report)
        exact_seconds = method_seconds = 0.
        for query_index, query in enumerate(prepared):
            properties = chosen["selected_properties"][query.query_id]
            if (query.metadata["candidate_count"] != properties["candidate_count"]
                    or query.metadata["scope_edge_count"] != properties["scope_edge_count"]
                    or query.metadata["candidate_ids"] != properties["candidate_ids"]
                    or query.metadata["scope_edge_indices"] != properties["scope_edge_indices"]):
                raise ValueError("rebuilt scorer properties differ from the frozen selection")
            m, k = len(query.q), len(query.kernel.candidates)
            t = time.perf_counter()
            worlds = ((np.arange(1 << m, dtype=np.uint32)[:, None]
                       >> np.arange(m, dtype=np.uint32)[None, :]) & 1).astype(bool)
            scores = query.kernel.scores(worlds)
            if scores.shape != (1 << m, k) or not np.isfinite(scores).all():
                raise ValueError("exact enumeration produced invalid frozen-scorer output")
            winners = np.argmax(scores, axis=1).astype(np.int64)
            enumeration_seconds = time.perf_counter() - t
            exact_seconds += enumeration_seconds
            query_token = hashlib.sha256(query.query_id.encode()).hexdigest()[:16]
            atomic_json(output / "winner_maps" / f"{graph_slug}_{query_token}.json", {
                "graph": graph, "query_id": query.query_id, "candidate_ids": list(query.kernel.candidates),
                "scope_edge_indices": list(query.kernel.edge_indices), "m": m,
                "world_index_to_winner": winners.tolist(), "all_worlds": 1 << m,
                "enumerated_score_sha256": hashlib.sha256(scores.tobytes(order="C")).hexdigest(),
                "distinct_world_winner_categories": len(set(winners.tolist())),
                "q_exact": [str(Fraction.from_float(float(value))) for value in query.q],
                "scorer_seconds": enumeration_seconds, "used_for_method_selection": False})
            for tau_index, tau in enumerate(TAUS):
                low, high = clipped_box(query.q, tau)
                low.setflags(write=False)
                high.setflags(write=False)
                epsilon, box_audit = conservative_scope_tv(query.q, low, high)
                metadata = {**query.metadata, "scope_epsilon_upper": epsilon, "box_audit": box_audit}
                current = replace(query, low=low, high=high, scope_epsilon=epsilon, metadata=metadata)
                settings = family_settings(engine, base, tau)
                t = time.perf_counter()
                reference = full_box_reference(winners.tolist(), k, query.q.tolist(), low.tolist(), high.tolist())
                reference_seconds = time.perf_counter() - t
                exact_seconds += reference_seconds
                reference_path = output / "exact" / f"{graph_slug}_{query_token}_t{tau_index}.json"
                atomic_json(reference_path, {"graph": graph, "query_id": query.query_id, "tau": tau,
                    "candidate_ids": list(query.kernel.candidates), "seconds": reference_seconds, **reference})
                reference_sha = sha(reference_path)
                policies = tuple(protocol["policies"])
                rotation = (graph_index + query_index + tau_index) % len(policies)
                for policy in policies[rotation:] + policies[:rotation]:
                    if time.monotonic() - started >= args.seconds:
                        raise TimeoutError("deadline before method case")
                    row = (hybrid.run_hybrid_case(current, settings, policy, 151)
                           if policy == "normal_hybrid" else comparison.run_case(current, settings, policy, 151))
                    if time.monotonic() - started >= args.seconds:
                        raise TimeoutError("method result finished after the job deadline and is not recorded")
                    candidate = row["certified_candidate_index"] if row["certified"] else None
                    serving = row["seconds"]["query_serving_total"]
                    method_seconds += serving
                    case = {"graph": graph, "query_id": query.query_id, "tau": tau, "policy": policy,
                        "returned_candidate_index": candidate, "method_serving_seconds": serving,
                        "samples_used": row["samples_used"], "work_used": row["work_used"],
                        "event_samples_used": row["event_samples_used"],
                        "exact_reference_path": str(reference_path.relative_to(output)), "exact_reference_sha256": reference_sha,
                        **classify_review(candidate, reference), "row": row}
                    destination = output / "cases" / f"{graph_slug}_{query_token}_t{tau_index}_{policy}.json"
                    atomic_json(destination, case)
                    cases.append({key: value for key, value in case.items() if key != "row"})
                    atomic_json(output / "progress.json", {"status": "RUNNING", "completed_cases": len(cases),
                        "elapsed_seconds": time.monotonic() - started, "last_case": str(destination.relative_to(output))})
                for threshold in (None, *THRESHOLDS):
                    t = time.perf_counter()
                    point_scores = query.kernel.scores(np.ones((1, m), dtype=bool))[0]
                    candidate = int(np.argmax(point_scores))
                    top = np.partition(point_scores, -2)[-2:]
                    margin = float(top.max() - top.min())
                    approved = threshold is None or margin > threshold
                    serving = time.perf_counter() - t
                    policy = "point_all_present" if threshold is None else f"point_margin_gt_{threshold:g}"
                    case = {"graph": graph, "query_id": query.query_id, "tau": tau, "policy": policy,
                        "returned_candidate_index": candidate if approved else None,
                        "method_serving_seconds": serving, "point_score_margin": margin,
                        "samples_used": 0, "deterministic_scorer_rows": 1,
                        "threshold": threshold, "exact_reference_path": str(reference_path.relative_to(output)),
                        "exact_reference_sha256": reference_sha, **classify_review(candidate if approved else None, reference)}
                    destination = output / "cases" / f"{graph_slug}_{query_token}_t{tau_index}_{policy}.json"
                    atomic_json(destination, case)
                    cases.append(case)
                    method_seconds += serving
                    atomic_json(output / "progress.json", {"status": "RUNNING", "completed_cases": len(cases),
                        "elapsed_seconds": time.monotonic() - started, "last_case": str(destination.relative_to(output))})
        graph_timings.append({"graph": graph, "selected": len(ids), "setup_seconds": setup_seconds,
            "exact_reference_seconds": exact_seconds, "method_serving_seconds": method_seconds})
    for path, expected in source_hashes.items():
        if sha(ROOT / path) != expected:
            raise ValueError("frozen runtime source/config changed")
    for item in inventories:
        if sha(ROOT / item["path"]) != item["sha256"]:
            raise ValueError("selection source-property inventory changed")
    groups = defaultdict(list)
    for case in cases:
        groups[case["graph"], case["tau"], case["policy"]].append(case)
    table = []
    for (graph, tau, policy), group in sorted(groups.items()):
        table.append({"graph": graph, "tau": tau, "policy": policy, "cases": len(group),
            **{name: sum(case[name] for case in group) for name in (
                "approved", "uniform_safe", "false_clear", "reviewed", "avoidable_review", "exact_ambiguous")},
            "method_serving_seconds": sum(case["method_serving_seconds"] for case in group)})
        table[-1]["random_worlds_generated"] = sum(case["samples_used"] for case in group)
    atomic_json(output / "summary.json", {"status": "COMPLETE", "selection": selection,
        "cases": len(cases), "review_table": table, "graph_timings": graph_timings,
        "elapsed_seconds": time.monotonic() - started,
        "interpretation": "controlled exact decision-value reference; no real human-review savings or probability calibration claim",
        "risk_scope": protocol["risk"], "exact_reference_cost_is_not_algorithm_cost": True})
    atomic_json(output / "progress.json", {"status": "COMPLETE", "completed_cases": len(cases)})


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/icde_online_scale500_20261104.json")
    parser.add_argument("--scale-root-prefix", type=Path, default=DEFAULT_PREFIX)
    parser.add_argument("--queries-per-graph", type=int, default=16)
    parser.add_argument("--max-scope", type=int, default=8)
    parser.add_argument("--include-hybrid", action="store_true")
    parser.add_argument("--seconds", type=float, default=840.)
    args = parser.parse_args()
    if not 1 <= args.queries_per_graph <= 16 or not 0 <= args.max_scope <= 8:
        parser.error("bounded gate requires at most16 queries/graph and max_scope<=8")
    if not math.isfinite(args.seconds) or not 0 < args.seconds <= 840:
        parser.error("seconds must be positive and <=840")
    output = args.output_dir.resolve()
    output.relative_to(ROOT)
    output.mkdir(parents=True, exist_ok=False)
    finished = threading.Event()
    threading.Thread(target=watchdog, args=(output, finished, started, args.seconds), daemon=True).start()
    try:
        execute(args, output, started)
    except BaseException as error:
        atomic_json(output / "failure.json", {"status": "PARTIAL_OR_FAILED", "error": str(error),
            "traceback": traceback.format_exc(), "completed_case_files_preserved": True})
        raise
    finally:
        finished.set()


if __name__ == "__main__":
    main()
