"""Package all artifacts generated in this round (corrected full-manifest
recomputation after independent review) into a single zip with SHA256
manifest, per user preference: one file for all generated materials."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

REPO = Path(r"E:\pkgea")
OUT_ZIP = REPO / "icde_sync_review_processed_20261011.zip"

ENTRIES: list[tuple[Path, str]] = []


def add(p: Path, arc: str | None = None) -> None:
    if not p.exists():
        raise FileNotFoundError(p)
    ENTRIES.append((p, arc or p.relative_to(REPO).as_posix()))


def add_dir(d: Path, arc_prefix: str) -> None:
    if not d.is_dir():
        raise FileNotFoundError(d)
    for p in sorted(d.rglob("*")):
        if p.is_file():
            ENTRIES.append((p, arc_prefix + "/" + p.relative_to(d).as_posix()))


# 1) corrected record + status
add(REPO / "papers/icde/CONSOLIDATED_SYNC_20261009.md")
add(REPO / "nodes/05_icde_query_engine/status.toml")

# 2) corrected tool + regression test (archived this round)
add(REPO / "scripts/check_icde_handoff_vs_repo.py")
add(REPO / "tests/test_icde_handoff_comparison.py")

# 3) corrected recomputation outputs (Windows host)
add(REPO / "output/full_bundle_vs_repo_corrected.json")
add(REPO / "output/python_vs_repo_corrected.json")

# 4) archived independent review evidence
add_dir(
    REPO / "nodes/05_icde_query_engine/results/sync_return_audit_20261010",
    "nodes/05_icde_query_engine/results/sync_return_audit_20261010",
)


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


manifest: dict[str, str] = {}
if OUT_ZIP.exists():
    OUT_ZIP.unlink()
with zipfile.ZipFile(OUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zf:
    for p, arc in ENTRIES:
        zf.write(p, arc)
        manifest[arc] = sha256(p)
    zf.writestr("BUILT_MANIFEST.json", json.dumps({
        "format": "icde-sync-review-processed-v1",
        "date": "2026-10-11",
        "host": "Windows 11 / Python 3.14.5 / numpy (no torch)",
        "reviewed_package": "icde_sync_review_20261010.zip (independent review of icde_consolidated_sync_20261009.zip)",
        "key_facts": {
            "python_123_scope_corrected": "byte_equal 123 / newline_only 0 / content_different 0 / missing 0",
            "full_manifest_596_corrected": "byte_equal 559 / newline_only 0 / content_different 5 (4 E6 outputs kept + status.toml evolved) / missing 32 (bundle-specific metadata)",
            "original_547": "invalid; original script compared str hash to dict manifest entry and misclassified identical files as newline-only",
            "research_acceptance": "false",
        },
        "files": manifest,
    }, ensure_ascii=False, indent=2))

with zipfile.ZipFile(OUT_ZIP) as zf:
    total = sum(1 for n in zf.namelist() if not n.endswith("/"))
    crc = zf.testzip()
zip_sha = sha256(OUT_ZIP)
print(f"wrote {OUT_ZIP}")
print(f"entries: {total} (crc errors: {crc})")
print(f"zip sha256: {zip_sha}")
