"""Candidate-block exact events + standard union bounds, an evaluated prototype.

E_B = a rival in block B beats anchor w under the fixed tie rule.
pi_w >= 1-sum_B sup_p P(E_B); pi_d <= sup_p P(Y_{B+w}=d).
All optimizations use the whole declared local parameter box, not per-U minima.
No new general union-bound or credal-inference theory is claimed.
"""
from fractions import Fraction as Q
import time
import numpy as np
from icde_sparse_degree_20261108 import restrict
from icde_grouped_exact_20261108 import groups_for_box,compile_counts,solve_counts
from icde_large_event_screen_20261108 import down,up
from run_vldb_interval_gate_v1 import clipped_box


def execute(kernel,settings):
    time.perf_counter()
    m=len(kernel.edge_indices)
    focus=int(np.argmax(kernel.scores(np.ones((1,m),dtype=np.bool_))[0]))
    lower,upper=kernel.score_intervals(np.zeros((1,m),dtype=np.bool_),np.ones((1,m),dtype=np.bool_))
    rival=[d for d in range(len(kernel.candidates)) if d!=focus and upper[0,d]>=lower[0,focus]]
    if not rival:
        return {'status':'stable','winner':focus,'focus':focus,'kind':'common_all_world_interval',
                'lower_gap':1.,'upper_gap':1.,'blocks':[]}
    error_sum=Q(0);rival_upper=Q(0);blocks=[]
    for start in range(0,len(rival),settings['block_size']):
        time.perf_counter()
        opponents=rival[start:start+settings['block_size']]
        sub,selected=restrict(kernel,[focus]+opponents)
        low,high=clipped_box(np.full(len(sub.edge_indices),settings['nominal']),settings['tau'])
        groups=groups_for_box(sub,low,high)
        shape=tuple(len(edges)+1 for signature,edges,endpoint in groups)
        size=1
        for n in shape:size*=n
        estimated=len(sub.candidates)*size*sum(shape)
        if size>settings['block_state_cap'] or max(shape,default=1)>65 or estimated>settings['block_work_cap']:
            return {'status':'resource_not_admitted','winner':None,'focus':focus,'kind':'block_resource_limit',
                    'lower_gap':-1.,'upper_gap':1.,'blocks':blocks,'failed_block_states':size,
                    'failed_block_estimated_work':estimated}
        compiled=compile_counts(sub,low,high,settings['block_state_cap'])
        exact=solve_counts(compiled,len(sub.candidates))
        w=selected.index(focus);den=exact['denominator']
        min_w=Q(int(np.min(exact['numerators'][w])),den)
        u_rivals={selected[c]:Q(int(np.max(exact['numerators'][c])),den)
                  for c in range(len(selected)) if c!=w}
        error=1-min_w
        error_sum+=error;rival_upper=max([rival_upper]+list(u_rivals.values()))
        blocks.append({'candidates':list(selected),'scope_edges':len(sub.edge_indices),
                       'count_states':size,'min_anchor_probability_exact':str(min_w),
                       'error_upper_exact':str(error),
                       'rival_upper_exact':{str(c):str(v) for c,v in u_rivals.items()}})
    lo=max(Q(0),1-error_sum)-rival_upper
    result={'status':'stable' if lo>0 else 'unresolved','winner':focus if lo>0 else None,
            'focus':focus,'kind':'restricted_candidate_block_events','lower_gap':down(lo),'upper_gap':1.,
            'lower_gap_exact':str(lo),'blocks':blocks,'remaining_rivals':len(rival),
            'sum_block_error_upper_exact':str(error_sum),'largest_rival_upper_exact':str(rival_upper)}
    time.perf_counter()
    return result
