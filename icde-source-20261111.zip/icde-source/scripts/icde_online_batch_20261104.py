"""Bounded sequential subprocess measurements for the ICDE online protocol."""
from __future__ import annotations
import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p,value):
    with p.open('x',encoding='utf-8') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n')

class PMC(ctypes.Structure):
    _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(n,ctypes.c_size_t) for n in ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]

def peak_rss(process):
    info=PMC();info.cb=ctypes.sizeof(info)
    ok=ctypes.windll.psapi.GetProcessMemoryInfo(wintypes.HANDLE(process._handle),ctypes.byref(info),info.cb)
    return int(info.PeakWorkingSetSize) if ok else 0

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--config',required=True,type=Path)
    p.add_argument('--output-dir',required=True,type=Path)
    p.add_argument('--stage',choices=['pilot','scale'],required=True)
    args=p.parse_args()
    config=json.loads(args.config.read_text('utf-8-sig'))
    out=args.output_dir.resolve();out.relative_to(ROOT)
    out.mkdir(parents=True,exist_ok=False)
    source_paths=[args.config,Path(__file__)]+list((ROOT/'scripts').glob('*vldb*.py'))+[ROOT/'scripts/icde_online_execution.py',ROOT/'scripts/test_icde_online_execution.py']+list((ROOT/'src/pkgea').rglob('*.py'))
    frozen={str(x.resolve().relative_to(ROOT)).replace('\\','/'):sha(x) for x in source_paths}
    write(out/'protocol_freeze.json',{'config':config,'code_and_config_sha256':frozen,'stage':args.stage,'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'python':sys.version,'platform':platform.platform(),'processor':platform.processor(),'logical_cpus':os.cpu_count(),'no_training':True})
    jobs=[]
    if args.stage=='pilot':
        methods=config['methods']
        for repeat in range(config['cold_repetitions']):
            ordered=methods[repeat%len(methods):]+methods[:repeat%len(methods)]
            jobs.extend(('cold',repeat,method) for method in ordered)
        jobs.extend(('warm',repeat,'all') for repeat in range(config['warm_repetitions']))
    else:
        jobs=[('warm',0,'all')]
    measurements=[];start=time.perf_counter()
    for mode,repeat,method in jobs:
        stem=f'{mode}_r{repeat}_{method}'
        dest=out/(stem+'.json');log=out/(stem+'.log')
        cmd=[sys.executable,str(ROOT/'scripts/icde_online_execution.py'),'--config',str(args.config.resolve()),'--output',str(dest),'--mode',mode,'--repeat',str(repeat),'--method',method]
        begin=time.perf_counter();peak=0
        with log.open('x',encoding='utf-8') as handle:
            proc=subprocess.Popen(cmd,cwd=ROOT,stdout=handle,stderr=subprocess.STDOUT,env=os.environ.copy())
            while proc.poll() is None:
                peak=max(peak,peak_rss(proc));time.sleep(.02)
                if time.perf_counter()-start>850:
                    proc.kill();proc.wait();raise RuntimeError('bounded batch time exhausted')
        elapsed=time.perf_counter()-begin
        if proc.returncode or not dest.exists():
            raise RuntimeError(f'worker failed: {stem}; inspect {log}')
        value=json.loads(dest.read_text('utf-8'))
        measurements.append({'mode':mode,'repeat':repeat,'method':method,'path':str(dest.relative_to(ROOT)).replace('\\','/'),'external_process_wall_seconds':elapsed,'peak_process_rss_bytes':peak,'output_sha256':sha(dest),'worker_before_serialization_seconds':value['seconds']['worker_before_serialization']})
        print(json.dumps(measurements[-1]),flush=True)
    changed=[k for k,v in frozen.items() if sha(ROOT/k)!=v]
    if changed:raise RuntimeError('frozen execution sources changed: '+str(changed))
    write(out/'batch_summary.json',{'status':'COMPLETE','stage':args.stage,'config':config,'measurements':measurements,'batch_elapsed_seconds':time.perf_counter()-start,'peak_rss_is_sampled_process_peak_not_VRAM':True,'overhead_includes_python_start_import_static_setup_audits_output':True,'os_disk_cache_flushed':False,'full_stream_precapture':False})

if __name__=='__main__':main()
