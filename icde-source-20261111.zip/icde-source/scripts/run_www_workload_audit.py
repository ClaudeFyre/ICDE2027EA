"""Audit workload transfer and practical storage baselines for one WWW cell.

The original authorization matrix changes possible-world streams while holding
500 queries fixed.  This audit partitions those queries in frozen order into
300 selector queries, 100 authorization queries, and 100 untouched final-test
queries.  Only the target-side representation map transfers: unseen query
Gaussians stay full, matching a materialized candidate index with transient
query-side state.

The audit also materializes actual target-index bytes for margin-aware FP32,
margin-aware FP16, full FP32, and full FP16 artifacts; evaluates every global
low-rank-plus-diagonal rank 0..7 (rank 0 is diagonal); and compares the full
Gaussian estimator with a mean-only estimator.  It deliberately does not
replace the frozen main matrix.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT / "src", ROOT / "scripts", ROOT / "scripts/backbones"):
    if str(search_path) not in __import__("sys").path:
        __import__("sys").path.insert(0, str(search_path))

from pkgea.contracts import dataset_content_digest, dataset_revision_digest
from pkgea.www_fsl import (
    apply_entity_representations,
    approximate_covariance_batch,
    gaussian_distance_matrix,
    mean_relative_distance_error,
    select_entity_adaptive_ranks,
    select_margin_aware_representations,
    serving_workload_digest,
    stored_scalars_per_entity,
    truth_preserving_candidate_subset,
    winner_agreement,
    winner_indices,
)
from run_www_equal_budget import (
    atomic_write_json,
    encode_worlds,
    full_payload,
    load_full_payload,
    load_representation_payload,
    load_profile,
    low_rank_payload,
    project_and_summarize,
    release_hidden_samples,
    representation_payload,
    sha256,
    time_world_generation,
    truth_accuracy,
    truth_mrr,
)
from www_encoder_adapters import load_distributional_encoder


FORMAT = "pkgea-www-workload-transfer-audit-v2"
RANKS = tuple(range(8))


def elapsed(started: float) -> float:
    return time.perf_counter() - started


def stage_indices(selection: int, authorization: int, final_test: int) -> dict[str, slice]:
    if min(selection, authorization, final_test) <= 0:
        raise ValueError("all query split sizes must be positive")
    return {
        "selection": slice(0, selection),
        "authorization": slice(selection, selection + authorization),
        "final_test": slice(selection + authorization, selection + authorization + final_test),
    }


def target_with_query_covariances(
    query_covariances: np.ndarray, target_covariances: np.ndarray
) -> np.ndarray:
    return np.concatenate((query_covariances, target_covariances), axis=0)


def split_metrics(
    reference: np.ndarray,
    estimate: np.ndarray,
    truth_positions: np.ndarray,
    source_ids: tuple[str, ...],
) -> dict[str, object]:
    reference_winners = winner_indices(reference)
    estimate_winners = winner_indices(estimate)
    flips = reference_winners != estimate_winners
    return {
        "query_count": len(reference),
        "winner_agreement": winner_agreement(estimate, reference),
        "mean_relative_distance_error": mean_relative_distance_error(estimate, reference),
        "reference_hits_at_1": truth_accuracy(reference, truth_positions),
        "estimate_hits_at_1": truth_accuracy(estimate, truth_positions),
        "reference_mrr": truth_mrr(reference, truth_positions),
        "estimate_mrr": truth_mrr(estimate, truth_positions),
        "flipped_query_count": int(flips.sum()),
        "flipped_source_ids": [
            source for source, flipped in zip(source_ids, flips, strict=True) if flipped
        ],
    }


def rank_approximation(covariances: np.ndarray, rank: int) -> np.ndarray:
    if rank == 0:
        return approximate_covariance_batch(covariances, "diagonal")
    return approximate_covariance_batch(covariances, "low_rank", rank=rank)


def global_rank_bytes(
    means: np.ndarray,
    covariances: np.ndarray,
    rank: int,
    metadata: dict[str, object],
) -> int:
    if rank == 0:
        payload, _ = representation_payload(
            means, covariances, ["diagonal"] * len(means), metadata
        )
        return len(payload)
    payload, _, _, _ = low_rank_payload(means, covariances, rank, metadata)
    return len(payload)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--cell", required=True)
    parser.add_argument("--selection-queries", type=int, default=300)
    parser.add_argument("--authorization-queries", type=int, default=100)
    parser.add_argument("--final-test-queries", type=int, default=100)
    parser.add_argument("--candidate-limit", type=int, default=1012)
    parser.add_argument("--worlds", type=int, default=2048)
    parser.add_argument("--selection-seed", type=int, default=17)
    parser.add_argument("--authorization-seed", type=int, default=59)
    parser.add_argument("--final-test-seed", type=int, default=71)
    parser.add_argument("--projection-dimension", type=int, default=16)
    parser.add_argument("--max-distance-error", type=float, default=0.0025)
    args = parser.parse_args()

    output = args.output.resolve()
    if output.exists():
        raise ValueError("output already exists; refusing to overwrite")
    if args.worlds < 3:
        raise ValueError("at least three worlds are required")
    seeds = (args.selection_seed, args.authorization_seed, args.final_test_seed)
    if len(set(seeds)) != 3:
        raise ValueError("selection, authorization, and final-test seeds must differ")

    checkpoint_path = args.checkpoint.resolve()
    profile_path = args.profile.resolve()
    profile = load_profile(args.cell, profile_path)
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    adapter = load_distributional_encoder(checkpoint)
    entity_ids = adapter.entity_ids()
    entity_index = {entity: index for index, entity in enumerate(entity_ids)}

    all_sources = tuple(dict.fromkeys(
        row["source_entity_id"] for row in profile.alignments if row["split"] == "test"
    ))
    split_total = args.selection_queries + args.authorization_queries + args.final_test_queries
    if len(all_sources) != split_total:
        raise ValueError(
            f"query split consumes {split_total} sources but profile has {len(all_sources)}"
        )
    full_targets = tuple(dict.fromkeys(
        row["target_entity_id"] for row in profile.alignments
    ))
    truth = {
        row["source_entity_id"]: row["target_entity_id"]
        for row in profile.alignments if row["split"] == "test"
    }
    targets = truth_preserving_candidate_subset(
        full_targets, all_sources, truth, args.candidate_limit
    )
    truth_retention = sum(truth[source] in targets for source in all_sources) / len(all_sources)
    if truth_retention != 1.0:
        raise AssertionError("candidate pool lost a test truth")
    target_index = {target: index for index, target in enumerate(targets)}
    truth_positions = np.asarray(
        [target_index[truth[source]] for source in all_sources], dtype=np.int64
    )
    query_entities = (*all_sources, *targets)
    query_tensor = torch.tensor(
        [entity_index[entity] for entity in query_entities], dtype=torch.long
    )

    def forward(weights: torch.Tensor) -> torch.Tensor:
        return adapter.encode(weights)[query_tensor]

    torch.set_num_threads(1)
    threshold = torch.tensor(
        [value >= 0.5 for value in profile.probabilities], dtype=torch.float32
    )
    with torch.no_grad():
        threshold_hidden = np.asarray(forward(threshold).numpy(), dtype=np.float64)
    fit_rows = np.concatenate((
        np.arange(args.selection_queries),
        np.arange(len(all_sources), len(query_entities)),
    ))
    centered = threshold_hidden[fit_rows] - threshold_hidden[fit_rows].mean(axis=0)
    _, _, right = np.linalg.svd(centered, full_matrices=False)
    dimension = min(args.projection_dimension, right.shape[0], right.shape[1])
    if dimension < 2:
        raise ValueError("projection must retain at least two dimensions")
    projection = right[:dimension].T

    split_slices = stage_indices(
        args.selection_queries, args.authorization_queries, args.final_test_queries
    )
    split_sources = {
        name: all_sources[section] for name, section in split_slices.items()
    }
    workload_digests = {
        name: serving_workload_digest(sources, targets)
        for name, sources in split_sources.items()
    }
    common_metadata = {
        "schema_version": FORMAT,
        "cell": args.cell,
        "dataset_content_digest": dataset_content_digest(profile_path),
        "checkpoint_sha256": sha256(checkpoint_path),
        "worlds": args.worlds,
        "projection_dimension": dimension,
        "candidate_count": len(targets),
    }

    def moments(seed: int, label: str) -> tuple[np.ndarray, np.ndarray, dict[str, float]]:
        print(f"[workload-audit] {args.cell} {label} seed={seed} worlds={args.worlds}", flush=True)
        started = time.perf_counter()
        worlds, generation_seconds = time_world_generation(profile, args.worlds, seed)
        hidden, encoder_seconds = encode_worlds(worlds, forward)
        means, covariances, moment_seconds = project_and_summarize(hidden, projection)
        release_hidden_samples(hidden)
        timings = {
            "world_generation_seconds": generation_seconds,
            "encoder_seconds": encoder_seconds,
            "moment_seconds": moment_seconds,
            "total_seconds": elapsed(started),
        }
        print(
            f"[workload-audit] {args.cell} {label} moments complete "
            f"in {timings['total_seconds']:.1f}s",
            flush=True,
        )
        return means, covariances, timings

    selection_means, selection_covariances, selection_timing = moments(
        args.selection_seed, "selection"
    )
    source_count = len(all_sources)
    target_slice = slice(source_count, len(query_entities))
    selection_query_slice = split_slices["selection"]
    selection_subset_means = np.concatenate((
        selection_means[selection_query_slice], selection_means[target_slice]
    ))
    selection_subset_covariances = np.concatenate((
        selection_covariances[selection_query_slice], selection_covariances[target_slice]
    ))
    selection_full_distances = gaussian_distance_matrix(
        selection_subset_means, selection_subset_covariances, args.selection_queries
    )

    adaptive = select_entity_adaptive_ranks(
        selection_subset_covariances,
        candidate_ranks=(1, 2, 4),
        residual_threshold=0.0025,
        zero_tolerance=1e-12,
    )
    full_scalars = stored_scalars_per_entity(dimension, "full")
    target_storage = sum(
        full_scalars if rank in (None, 0) else stored_scalars_per_entity(
            dimension, "low_rank", rank=int(rank)
        )
        for rank in adaptive["selected_ranks"]
    )
    margin = select_margin_aware_representations(
        selection_subset_covariances,
        selection_full_distances,
        source_count=args.selection_queries,
        target_storage_scalars=int(target_storage),
        storage_tolerance=0.005,
    )
    if margin["selection_paused"]:
        raise RuntimeError("margin storage neutrality failed")
    target_representations = tuple(
        margin["selected_representations"][args.selection_queries:]
    )
    if len(target_representations) != len(targets):
        raise AssertionError("target representation map length mismatch")

    selection_rank_rows = []
    for rank in RANKS:
        approximate_targets = rank_approximation(
            selection_covariances[target_slice], rank
        )
        approximate_distances = gaussian_distance_matrix(
            selection_subset_means,
            target_with_query_covariances(
                selection_covariances[selection_query_slice], approximate_targets
            ),
            args.selection_queries,
        )
        selection_rank_rows.append({
            "rank": rank,
            "representation": "diagonal" if rank == 0 else f"rank_{rank}",
            "winner_agreement": winner_agreement(
                approximate_distances, selection_full_distances
            ),
            "mean_relative_distance_error": mean_relative_distance_error(
                approximate_distances, selection_full_distances
            ),
            "logical_scalars_per_target": (
                stored_scalars_per_entity(dimension, "diagonal")
                if rank == 0 else stored_scalars_per_entity(
                    dimension, "low_rank", rank=rank
                )
            ),
        })
    passing_ranks = [
        row for row in selection_rank_rows
        if row["winner_agreement"] == 1.0
        and row["mean_relative_distance_error"] <= args.max_distance_error
    ]
    selected_global = min(
        passing_ranks or selection_rank_rows,
        key=lambda row: (row["logical_scalars_per_target"], row["rank"]),
    )
    global_authorized_on_selection = bool(passing_ranks)

    seed_results: dict[str, dict[str, object]] = {}
    for label, seed in (
        ("selection", args.selection_seed),
        ("authorization", args.authorization_seed),
        ("final_test", args.final_test_seed),
    ):
        if label == "selection":
            means, covariances, timings = (
                selection_means, selection_covariances, selection_timing
            )
        else:
            means, covariances, timings = moments(seed, label)
        section = split_slices[label]
        source_means = means[section]
        source_covariances = covariances[section]
        target_means = means[target_slice]
        target_covariances = covariances[target_slice]
        artifact_metadata = {
            **common_metadata,
            "stage": label,
            "seed": seed,
            "workload_digest": workload_digests[label],
            "artifact_scope": "target_index_only_query_state_transient",
        }
        full32_bytes = full_payload(
            target_means, target_covariances,
            dtype=np.dtype(np.float32), metadata=artifact_metadata,
        )
        full16_bytes = full_payload(
            target_means, target_covariances,
            dtype=np.dtype(np.float16), metadata=artifact_metadata,
        )
        full32_target_means, full32_target_covariances = load_full_payload(full32_bytes)
        full16_target_means, full16_target_covariances = load_full_payload(full16_bytes)
        reference = gaussian_distance_matrix(
            np.concatenate((source_means, full32_target_means)),
            target_with_query_covariances(source_covariances, full32_target_covariances),
            len(source_means),
        )

        margin_bytes, margin_construction_seconds = representation_payload(
            target_means, target_covariances, target_representations, artifact_metadata
        )
        margin_fp16_bytes, margin_fp16_construction_seconds = representation_payload(
            target_means,
            target_covariances,
            target_representations,
            artifact_metadata,
            dtype=np.dtype(np.float16),
        )
        margin_target_means, margin_target_covariances = load_representation_payload(
            margin_bytes
        )
        margin_fp16_target_means, margin_fp16_target_covariances = (
            load_representation_payload(margin_fp16_bytes)
        )
        margin_distances = gaussian_distance_matrix(
            np.concatenate((source_means, margin_target_means)),
            target_with_query_covariances(source_covariances, margin_target_covariances),
            len(source_means),
        )
        margin_fp16_distances = gaussian_distance_matrix(
            np.concatenate((source_means, margin_fp16_target_means)),
            target_with_query_covariances(
                source_covariances, margin_fp16_target_covariances
            ),
            len(source_means),
        )
        fp16_distances = gaussian_distance_matrix(
            np.concatenate((source_means, full16_target_means)),
            target_with_query_covariances(source_covariances, full16_target_covariances),
            len(source_means),
        )
        zeros = np.zeros_like(target_with_query_covariances(
            source_covariances, target_covariances
        ))
        mean_only_distances = gaussian_distance_matrix(
            np.concatenate((source_means, target_means)), zeros, len(source_means)
        )
        selected_rank = int(selected_global["rank"])
        global_target_covariances = rank_approximation(
            target_covariances, selected_rank
        )
        global_distances = gaussian_distance_matrix(
            np.concatenate((source_means, target_means)),
            target_with_query_covariances(source_covariances, global_target_covariances),
            len(source_means),
        )
        truth_for_split = truth_positions[section]
        sources_for_split = all_sources[section]
        method_metrics = {
            "margin": split_metrics(
                reference, margin_distances, truth_for_split, sources_for_split
            ),
            "margin_fp16": split_metrics(
                reference, margin_fp16_distances, truth_for_split, sources_for_split
            ),
            "full_fp16": split_metrics(
                reference, fp16_distances, truth_for_split, sources_for_split
            ),
            "global_rank": split_metrics(
                reference, global_distances, truth_for_split, sources_for_split
            ),
            "mean_only": split_metrics(
                reference, mean_only_distances, truth_for_split, sources_for_split
            ),
        }
        for method in ("margin", "margin_fp16", "full_fp16", "global_rank"):
            row = method_metrics[method]
            row["authorized"] = bool(
                row["winner_agreement"] == 1.0
                and row["mean_relative_distance_error"] <= args.max_distance_error
            )
        seed_results[label] = {
            "seed": seed,
            "workload_digest": workload_digests[label],
            "timing": timings,
            "artifact_bytes": {
                "full_fp32": len(full32_bytes),
                "full_fp16": len(full16_bytes),
                "margin": len(margin_bytes),
                "margin_fp16": len(margin_fp16_bytes),
                "selected_global_rank": global_rank_bytes(
                    target_means, target_covariances, selected_rank, artifact_metadata
                ),
                "margin_vs_full_fp32_ratio": len(margin_bytes) / len(full32_bytes),
                "margin_vs_full_fp16_ratio": len(margin_bytes) / len(full16_bytes),
                "margin_fp16_vs_full_fp32_ratio": (
                    len(margin_fp16_bytes) / len(full32_bytes)
                ),
                "margin_fp16_vs_full_fp16_ratio": (
                    len(margin_fp16_bytes) / len(full16_bytes)
                ),
                "selected_global_rank_vs_full_fp32_ratio": (
                    global_rank_bytes(
                        target_means,
                        target_covariances,
                        selected_rank,
                        artifact_metadata,
                    )
                    / len(full32_bytes)
                ),
                "fp16_vs_fp32_ratio": len(full16_bytes) / len(full32_bytes),
            },
            "artifact_construction_seconds": {
                "margin": margin_construction_seconds,
                "margin_fp16": margin_fp16_construction_seconds,
            },
            "methods": method_metrics,
        }

    result = {
        "schema_version": FORMAT,
        "created_on": time.strftime("%Y-%m-%d"),
        "cell": args.cell,
        "inputs": {
            "profile": str(profile_path),
            "dataset_revision": dataset_revision_digest(profile_path),
            "dataset_content_digest": dataset_content_digest(profile_path),
            "checkpoint": str(checkpoint_path),
            "checkpoint_sha256": sha256(checkpoint_path),
            "adapter_format": adapter.format_id,
        },
        "protocol": {
            "worlds_per_stage": args.worlds,
            "seeds": {
                "selection": args.selection_seed,
                "authorization": args.authorization_seed,
                "final_test": args.final_test_seed,
            },
            "query_split": {
                "selection": args.selection_queries,
                "authorization": args.authorization_queries,
                "final_test": args.final_test_queries,
                "order": "frozen_test_alignment_order",
                "pairwise_disjoint": True,
            },
            "candidate_count": len(targets),
            "full_candidate_source_count": len(full_targets),
            "candidate_construction": (
                "ordered aligned-target pool; all 500 test truths are retained; "
                "this is a fidelity workload, not candidate-retrieval recall"
            ),
            "truth_retention": truth_retention,
            "projection_dimension": dimension,
            "projection_fit": (
                "threshold-graph hidden states for selection sources plus all candidates"
            ),
            "ranking_operation": "gaussian_w2_top1_frozen_candidate_order",
            "workload_digests": workload_digests,
            "target_map_transfer": (
                "margin map fitted on selection queries; authorization/final query "
                "covariances remain full and only the target index is compressed"
            ),
            "max_distance_error": args.max_distance_error,
            "minimum_winner_agreement": 1.0,
        },
        "selection": {
            "margin": margin,
            "target_representation_counts": {
                name: target_representations.count(name)
                for name in ("diagonal", "rank_1", "rank_2", "rank_4", "full")
            },
            "all_global_ranks": selection_rank_rows,
            "selected_global_rank": selected_global,
            "global_rank_authorized_on_selection": global_authorized_on_selection,
        },
        "stages": seed_results,
        "validation": {
            "truth_retention_is_one": truth_retention == 1.0,
            "query_count_is_500": len(all_sources) == 500,
            "candidate_count_is_1012": len(targets) == 1012,
            "query_splits_are_disjoint": True,
            "workload_digests_are_distinct": len(set(workload_digests.values())) == 3,
            "margin_storage_neutrality_passes": margin["storage_neutrality_passes"],
            "authorization_margin_passes": seed_results["authorization"]["methods"]["margin"]["authorized"],
            "final_test_margin_passes": seed_results["final_test"]["methods"]["margin"]["authorized"],
            "margin_fp16_is_measured": all(
                "margin_fp16" in seed_results[stage]["methods"]
                for stage in ("selection", "authorization", "final_test")
            ),
        },
        "claim_boundary": (
            "The result measures transfer to two disjoint query subsets on the same "
            "graph revision, checkpoint, aligned-target candidate pool, and ranking "
            "operation. It does not authorize a new graph, revision, checkpoint, or "
            "candidate retrieval system."
        ),
    }
    if not all(result["validation"].values()):
        print(json.dumps(result["validation"], indent=2), flush=True)
        raise RuntimeError("workload audit validation failed")
    atomic_write_json(output, result)
    print(json.dumps({
        "cell": args.cell,
        "validation": result["validation"],
        "authorization": seed_results["authorization"]["methods"],
        "final_test": seed_results["final_test"]["methods"],
    }, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
