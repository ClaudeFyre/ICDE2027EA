"""Standard counting-symmetry exact baseline for a frozen degree query.

No complete Boolean winner table is built. Group counts define the winner
tensor directly; ordinary separable tensor contractions evaluate every
endpoint-orbit representative with exact integer arithmetic. Counting symmetry,
multiaffine endpoint extrema and variable elimination are existing techniques.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction as Q
from itertools import product
import math
import time

import numpy as np

from icde_grouped_inventory_20261108 import incidence_groups


def groups_for_box(kernel, low, high):
    m = len(kernel.edge_indices)
    if len(low) != m or len(high) != m or any(not 0 <= l <= h <= 1 for l, h in zip(low, high)):
        raise ValueError("invalid independent probability box")
    raw = incidence_groups(kernel.incidence_positions, m)
    result = []
    for signature, edges in raw:
        by_endpoint = defaultdict(list)
        for e in edges:
            by_endpoint[float(low[e]), float(high[e])].append(e)
        for endpoint, subset in sorted(by_endpoint.items()):
            result.append((signature, tuple(subset), endpoint))
    return tuple(result)


def compile_counts(kernel, low, high, state_cap=32768):
    started = time.perf_counter()
    groups = groups_for_box(kernel, low, high)
    shape = tuple(len(edges) + 1 for signature, edges, endpoint in groups)
    size = math.prod(shape)
    if size > state_cap:
        raise ValueError("count state cap exceeded")
    if len(kernel.edge_indices) >= 2**52:
        raise ValueError("degree arithmetic exceeds exact float64 integer contract")
    counts = np.indices(shape, dtype=np.int64).reshape(len(groups), size).T if groups else np.zeros((1, 0), dtype=np.int64)
    incidence = np.zeros((len(groups), len(kernel.incidence_positions)), dtype=np.int64)
    for g, (signature, edges, endpoint) in enumerate(groups):
        incidence[g, list(signature)] = 1
    degrees = (counts @ incidence).astype(np.float64)
    distance = np.abs(degrees[:, 0, None] - degrees[:, 2::2]) + np.abs(degrees[:, 1, None] - degrees[:, 3::2])
    dynamic = 1.0 / (1.0 + distance)
    structural = .6 * kernel.lexical[None, :] + .4 * dynamic
    weight = kernel.attribute_weight
    scores = weight * kernel.attribute[None, :] + (1.0 - weight) * structural
    if not np.isfinite(scores).all():
        raise ValueError("nonfinite score")
    winners = np.argmax(scores, axis=1).reshape(shape)
    return {"groups": groups, "shape": shape, "winners": winners, "count_states": size,
            "compilation_seconds": time.perf_counter() - started}


def endpoint_matrix(n, low, high):
    low, high = Q.from_float(float(low)), Q.from_float(float(high))
    denominator = math.lcm(low.denominator, high.denominator)
    l, h = int(low * denominator), int(high * denominator)
    def binomial(r, p):
        return [math.comb(r, s) * p**s * (denominator-p)**(r-s) for s in range(r+1)]
    matrix = []
    for t in range(n+1):
        a, b = binomial(t, h), binomial(n-t, l)
        row = [0] * (n+1)
        for i, ai in enumerate(a):
            if ai:
                for j, bj in enumerate(b):
                    row[i+j] += ai * bj
        if sum(row) != denominator**n:
            raise AssertionError("count-distribution weights fail normalization")
        matrix.append(row)
    return np.asarray(matrix, dtype=object), denominator**n


def solve_counts(compiled, k):
    started = time.perf_counter()
    matrices, denominator = [], 1
    for signature, edges, endpoint in compiled["groups"]:
        matrix, scale = endpoint_matrix(len(edges), *endpoint)
        matrices.append(matrix)
        denominator *= scale
    build_seconds = time.perf_counter() - started
    numerators = []
    transform_started = time.perf_counter()
    for candidate in range(k):
        values = (compiled["winners"] == candidate).astype(object)
        for axis, matrix in enumerate(matrices):
            values = np.moveaxis(np.tensordot(matrix, values, axes=(1, axis)), 0, axis)
        numerators.append(values)
    if any(int(value) != denominator for value in sum(numerators).flat):
        raise AssertionError("candidate probabilities do not sum to one")
    pairs, uniform = [], []
    for w in range(k):
        safe = True
        for d in range(k):
            if w == d:
                continue
            gaps = numerators[w] - numerators[d]
            at = int(np.argmin(gaps))
            minimum = int(gaps.flat[at])
            safe &= minimum > 0
            pairs.append({"candidate": w, "competitor": d, "minimum_gap_exact": str(Q(minimum, denominator)),
                          "minimum_gap": float(Q(minimum, denominator)),
                          "minimizing_high_endpoint_counts": list(map(int, np.unravel_index(at, gaps.shape)))})
        if safe:
            uniform.append(w)
    return {"uniform_winners": uniform, "pairs": pairs, "numerators": numerators,
            "denominator": denominator, "matrices": matrices,
            "matrix_seconds": build_seconds, "transform_and_gap_seconds": time.perf_counter() - transform_started,
            "solve_seconds": time.perf_counter() - started}


def direct_representative_probabilities(compiled, matrices, parameter_counts, k):
    """Independent scalar sum-product evaluator for one parameter representative.

    Same exact group distributions, but no multi-axis tensor transform. Used
    for small full representative tables and large extremum witnesses.
    """
    result = [0] * k
    for state in product(*(range(n) for n in compiled["shape"])):
        mass = math.prod(int(matrices[g][parameter_counts[g], state[g]]) for g in range(len(state)))
        result[int(compiled["winners"][state])] += mass
    return result
