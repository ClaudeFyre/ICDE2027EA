"""Exact arithmetic/reference tests; no scorer or experiment execution."""
from fractions import Fraction as F
import unittest
from types import SimpleNamespace

import icde_gate_exact_review as exact


class TensorReferenceTests(unittest.TestCase):
    def test_vertex_transform_matches_direct_exact_expectations(self):
        values = [-1, 0, 2, 1, -2, 3, 0, 4]
        low, high = [F(1, 5), F(1, 4), F(1, 3)], [F(3, 5), F(3, 4), F(2, 3)]
        transformed = exact.tensor_vertex_transform(values, low, high)
        for index, value in enumerate(transformed):
            parameters = [high[e] if index & (1 << e) else low[e] for e in range(3)]
            self.assertEqual(value, exact.exact_expectation(values, parameters))

    def test_multi_affine_vertex_bounds_include_interior(self):
        values = [-1, 2, 3, -4]
        low, high = [F(1, 10), F(1, 5)], [F(4, 5), F(9, 10)]
        vertices = exact.tensor_vertex_transform(values, low, high)
        for a, b in ((F(1, 3), F(1, 2)), (F(2, 3), F(3, 5))):
            value = exact.exact_expectation(values, (a, b))
            self.assertLessEqual(min(vertices), value)
            self.assertLessEqual(value, max(vertices))

    def test_finite_grid_is_not_a_whole_family_certificate(self):
        winners = [0, 0, 0, 1]  # candidate1 iff both edges active
        for probability in (F(1, 10), F(2, 5), F(3, 5)):
            self.assertLess(exact.exact_expectation([0, 0, 0, 1], [probability] * 2), F(1, 2))
        reference = exact.full_box_reference(winners, 2, [F(1, 10)] * 2, [0, 0], [1, 1])
        self.assertEqual(reference["uniform_winners"], [])
        self.assertEqual(reference["candidate_results"][0]["pair_gap_ranges"][0]["minimum_gap"], "-1")

    def test_strict_unique_mode_rejects_boundary_tie(self):
        reference = exact.full_box_reference([0, 1], 2, [F(1, 4)], [0], [F(1, 2)])
        self.assertEqual(reference["nominal_modes"], [0])
        self.assertEqual(reference["uniform_winners"], [])
        self.assertEqual(reference["candidate_results"][0]["unsafe_witness"]["gap_exact"], "0")

    def test_counterexample_uses_coordinate_lexicographic_vertex(self):
        reference = exact.full_box_reference([0, 1, 1, 1], 2, [F(1, 10)] * 2, [0, 0], [1, 1])
        witness = reference["candidate_results"][0]["unsafe_witness"]
        self.assertEqual(witness["vertex_bits"], [0, 1])
        self.assertLessEqual(F(witness["gap_exact"]), 0)

    def test_constant_map_remains_safe_over_full_box(self):
        reference = exact.full_box_reference([1, 1, 1, 1], 3, [F(1, 2)] * 2, [0, 0], [1, 1])
        self.assertEqual(reference["uniform_winners"], [1])
        self.assertTrue(reference["candidate_results"][1]["uniformly_unique_mode"])

    def test_zero_scope_and_exact_float_input_semantics(self):
        self.assertEqual(exact.tensor_vertex_transform([F(2, 3)], [], []), (F(2, 3),))
        reference = exact.full_box_reference([0], 2, [], [], [])
        self.assertEqual(reference["uniform_winners"], [0])
        self.assertEqual(exact.fraction(.1), F.from_float(.1))
        self.assertNotEqual(exact.fraction(.1), F(1, 10))

    def test_review_classification_does_not_confuse_nominal_with_uniform(self):
        ambiguous = {"uniform_winners": []}
        self.assertTrue(exact.classify_review(0, ambiguous)["false_clear"])
        self.assertFalse(exact.classify_review(None, ambiguous)["avoidable_review"])
        safe = {"uniform_winners": [1]}
        self.assertTrue(exact.classify_review(None, safe)["avoidable_review"])
        self.assertTrue(exact.classify_review(1, safe)["uniform_safe"])
        self.assertFalse(exact.classify_review(0, safe)["uniform_safe"])

    def test_invalid_box_and_world_size_fail_closed(self):
        for values, low, high in (([0, 1, 2], [0], [1]), ([0, 1], [F(3, 4)], [F(1, 4)])):
            with self.assertRaises(ValueError):
                exact.tensor_vertex_transform(values, low, high)

    def test_full_cube_adapter_preserves_one_box_risk_binds_actual_tau(self):
        def construct(config):
            self.assertLess(config["tau"], 1)
            return {**config, "risk_plan": {"protected_box_count": 1, "alpha_per_checkpoint": F(1, 240)}}
        settings = exact.family_settings(SimpleNamespace(settings_from_config=construct), {"delta_total": .05}, 1.)
        self.assertEqual(settings["tau"], 1.)
        self.assertEqual(settings["risk_plan"]["protected_box_count"], 1)
        self.assertEqual(settings["risk_plan"]["alpha_per_checkpoint"], F(1, 240))


if __name__ == "__main__":
    unittest.main()
