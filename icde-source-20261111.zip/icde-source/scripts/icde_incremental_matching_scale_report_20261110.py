"""Audit and summarize the complete scale extension without changing outputs."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "nodes/10_icde_incremental_matching/results/scale_20261110/attempt1"
GRAPHS = ("dw", "enfr")
SIZES = (1024, 4096, 8192, 15000)
METHODS = ("dense_cold", "cache_warm", "stream_warm", "block_warm")
REPEATS = {"dense_cold": 1, "cache_warm": 3, "stream_warm": 3, "block_warm": 3}


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def main():
    protocol = load(BASE / "protocol.json")
    checks = 0
    for category in ("input_sha256", "code_sha256", "dependency_sha256"):
        for name, expected in protocol[category].items():
            assert sha(ROOT / name) == expected, name
            checks += 1
    assert load(BASE / "recovery.json")["status"] == "PASS"
    assert load(BASE / "self_check.json")["status"] == "PASS"
    assert sha(BASE / "source_frozen.py") == protocol["code_sha256"][
        "scripts/icde_incremental_matching_scale_20261110.py"]
    checks += 3
    scales, traces, pot, missing = [], [], [], []
    for graph in GRAPHS:
        for n in SIZES:
            path = BASE / "scale" / f"{graph}_{n}" / "result.json"
            if not path.exists():
                missing.append(str(path.relative_to(ROOT)))
                continue
            row = load(path)
            assert row["status"] == row["validation"]["status"] == "PASS"
            assert row["sources"] == n and row["targets"] == 15000
            assert row["score_cache_bytes"] == n * 15000 * 8
            assert row["validation"]["max_global_violation"] <= 1e-8
            assert abs(row["result"]["objective"] - row["validation"]["independent_sparse_JV_objective"]) <= 1e-6
            assert sha(path.parent / "scores.npy") == row["score_sha256"]
            losses = [row["topk"][str(k)]["loss"] for k in (1, 4, 16, 64)]
            assert all(losses[i] + 1e-6 >= losses[i + 1] for i in range(3))
            assert min(losses) >= -1e-6
            scales.append(row)
            checks += 8
        cold_path = BASE / "traces" / f"{graph}_dense_cold_r0" / "result.json"
        cold = load(cold_path) if cold_path.exists() else None
        for method in METHODS:
            for repeat in range(REPEATS[method]):
                path = BASE / "traces" / f"{graph}_{method}_r{repeat}" / "result.json"
                if not path.exists():
                    missing.append(str(path.relative_to(ROOT)))
                    continue
                row = load(path)
                assert row["status"] == "PASS" and len(row["records"]) == 8
                assert row["basis_retained_across_events"] == (method != "dense_cold")
                assert abs(row["maintenance_seconds"] - sum(r["seconds"] for r in row["records"])) < 1e-8
                assert abs(row["setup_plus_8_requests_seconds"] - row["maintenance_seconds"] - row["setup_seconds"]) < 1e-8
                for step, event in enumerate(row["records"]):
                    assert event["status"] == event["validation"]["status"] == "PASS"
                    assert event["step"] == step
                    assert event["event"] == protocol["events"][step]
                    assert event["validation"]["max_global_violation"] <= 1e-8
                    assert abs(event["result"]["objective"] - event["validation"]["independent_sparse_JV_objective"]) <= 1e-6
                    assert 0 <= event["matched_sources"] <= min(event["active_sources"], event["active_targets"])
                    assert 0 <= event["changed_outside_direct_sources"] <= event["matching_changed_sources"]
                    assert load(path.parent / f"event_{step:02d}.json") == event
                    if cold is not None:
                        assert abs(event["result"]["objective"] - cold["records"][step]["result"]["objective"]) <= 1e-6
                    checks += 8 + int(cold is not None)
                traces.append(row)
                checks += 4
        for n in SIZES:
            if n not in (1024, 4096, 8192, 15000):
                continue
            path = BASE / "pot" / f"{graph}_{n}" / "result.json"
            if not path.exists():
                missing.append(str(path.relative_to(ROOT)))
                continue
            row = load(path)
            if row["status"] == "PASS":
                assert abs(row["objective"] - row["independent_dense_JV_objective"]) <= 1e-6
                assert row["global_dual_violation"] <= 1e-8
                checks += 2
            else:
                assert row["status"] == "NOT_ADMITTED"
                checks += 1
            pot.append(row)
    run_ids = [f"icde-incscale-{phase}-20261110-a1" for phase in ("freeze", "recovery", "selfcheck")]
    run_ids += [f"icde-incscale-{graph}-{n}-20261110-a1" for graph in GRAPHS for n in SIZES]
    run_ids += [f"icde-inctrace-{graph}-{method}-r{repeat}-20261110-a1"
        for graph in GRAPHS for method in METHODS for repeat in range(REPEATS[method])]
    run_ids += [f"icde-incpot-{graph}-{n}-20261110-a1" for graph in GRAPHS for n in SIZES]
    resource_runs, resource_files = {}, []
    for task_id in run_ids:
        path = ROOT / ".runtime/runs" / (task_id + ".json")
        if not path.exists():
            missing.append(str(path.relative_to(ROOT)))
            continue
        record = load(path)
        assert record["status"] == "completed" and record["return_code"] == 0, task_id
        assert record["profile"] == "local16" and record["profile_values"]["threads"] == 1
        assert record["peak_job_memory_gb"] <= 7
        assert record["missing_outputs"] == []
        checks += 4
        resource_runs[task_id] = record
        resource_files.extend((path, Path(record["log_path"])))
    grouped = {}
    for graph in GRAPHS:
        for method in METHODS:
            values = [t for t in traces if t["graph"] == graph and t["method"] == method]
            if not values:
                continue
            totals = [t["maintenance_seconds"] for t in values]
            setups = [t["setup_seconds"] for t in values]
            run_paths = [ROOT / ".runtime/runs" / f"icde-inctrace-{graph}-{method}-r{t['repeat']}-20261110-a1.json" for t in values]
            execution = [load(p) for p in run_paths if p.exists()]
            assert len(execution) == len(values), run_paths
            assert all(r["status"] == "completed" and r["return_code"] == 0 for r in execution)
            checks += 2
            grouped[graph, method] = {"graph": graph, "method": method, "runs": len(values),
                "median_maintenance_seconds": statistics.median(totals),
                "minimum_maintenance_seconds": min(totals), "maximum_maintenance_seconds": max(totals),
                "median_setup_seconds": statistics.median(setups),
                "median_setup_plus_8_seconds": statistics.median(t["setup_plus_8_requests_seconds"] for t in values),
                "maximum_observed_rss_end_bytes": max(e["rss_end_bytes"] for t in values for e in t["records"]),
                "maximum_peak_job_commit_GiB": max((r["peak_job_memory_gb"] for r in execution), default=None),
                "median_independent_validation_seconds": statistics.median(
                    sum(e["validation"]["seconds"] for e in t["records"]) for t in values),
                "maximum_observed_event_seconds": max(e["seconds"] for t in values for e in t["records"]),
                "repeat_setup_plus_8_seconds": [t["setup_plus_8_requests_seconds"] for t in values],
                "median_lp_seconds": statistics.median(
                    sum(e["result"]["lp_seconds"] for e in t["records"]) for t in values),
                "median_pricing_seconds": statistics.median(
                    sum(e["result"]["pricing_seconds"] for e in t["records"]) for t in values),
                "median_score_or_index_update_seconds": statistics.median(
                    sum(e["score_or_index_update_seconds"] for e in t["records"]) for t in values),
                "median_event_seconds": [statistics.median(t["records"][s]["seconds"] for t in values) for s in range(8)]}
    signals = []
    for graph in GRAPHS:
        if all((graph, method) in grouped for method in METHODS):
            block = grouped[graph, "block_warm"]
            cache = grouped[graph, "cache_warm"]
            stream = grouped[graph, "stream_warm"]
            cold = grouped[graph, "dense_cold"]
            if block["median_setup_plus_8_seconds"] < min(
                cache["median_setup_plus_8_seconds"], stream["median_setup_plus_8_seconds"],
                cold["median_setup_plus_8_seconds"]):
                signals.append({"graph": graph, "regime": "all_cache_admitted", "scope": "descriptive sequence median"})
            if block["median_setup_plus_8_seconds"] < stream["median_setup_plus_8_seconds"]:
                signals.append({"graph": graph, "regime": "1GiB_score_cache_budget", "scope": "descriptive sequence median"})
    cost_models = []
    for graph in GRAPHS:
        initial = next((r for r in scales if r["graph"] == graph and r["sources"] == 15000), None)
        if initial is None:
            continue
        common_initial = initial["score_matrix_seconds"] + initial["matching_seconds"]
        for method in METHODS:
            row = grouped.get((graph, method))
            if row is None:
                continue
            cost_models.append({"graph": graph, "method": method,
                "common_first_snapshot_seconds": common_initial,
                "method_setup_median_seconds": row["median_setup_seconds"],
                "mean_per_request_from_8_event_median_seconds": row["median_maintenance_seconds"] / 8,
                "model_total_seconds_by_R": {str(r): common_initial + row["median_setup_seconds"]
                    + r * row["median_maintenance_seconds"] / 8 for r in (1, 8, 32, 128)},
                "scope": "fixed observed event-mixture cost model, not measured R-event traces"})
    full_checks = sum(r["validation"]["full_pair_checks"] for r in scales) + sum(
        e["validation"]["full_pair_checks"] for t in traces for e in t["records"])
    if not missing:
        assert len(scales) == 8 and len(traces) == 20 and len(pot) == 8
        assert sum(len(t["records"]) for t in traces) == 160
        checks += 2
    summary = {"status": "COMPLETE_WITH_DECLARED_SOFTWARE_GAPS" if not missing else "PARTIAL_WITH_MISSING_CASES",
        "scale_cases": len(scales), "trace_sequences": len(traces),
        "trace_update_runs": sum(len(t["records"]) for t in traces),
        "POT_pass_cases": sum(r["status"] == "PASS" for r in pot),
        "POT_not_admitted": sum(r["status"] == "NOT_ADMITTED" for r in pot),
        "missing": missing, "audit_checks": checks, "full_active_pair_checks": full_checks,
        "block_positive_median_signals": signals,
        "direction_decision": "INCOMPLETE" if missing else (
            "DESCRIPTIVE_SIGNAL_REQUIRES_NOVELTY_REVIEW" if signals else "STOP_CAP256_AS_PAPER_CORE"),
        "paper_readiness": '[说明文本已清理]',
        "software_gaps": ["original ShortCut author software not executed", "original TODS spatial matching implementation not executed"],
        "sequence_costs": list(grouped.values()), "amortized_cost_models": cost_models,
        "resource_runs": [{"task_id": task_id, "elapsed_seconds": r["elapsed_seconds"],
            "peak_job_commit_GiB": r["peak_job_memory_gb"], "status": r["status"]}
            for task_id, r in resource_runs.items()],
        "cache_admission": [{"sources": r["sources"], "targets": r["targets"],
            "score_cache_bytes": r["score_cache_bytes"], "admission_MiB": r["cache_admission_MiB"]}
            for r in scales if r["graph"] == GRAPHS[0]],
        "reporter_sha256": sha(Path(__file__))}
    save(BASE / "summary.json", summary)

    text = ["# 完整竞争与连续更新补测结果", "", "2026年11月10日，北京时间。", "",
        "## 完成状态", "",
        f"状态为 **{summary['status']}**。完成{len(scales)}个规模情况、{len(traces)}条连续更新序列、"
        f"{summary['trace_update_runs']}次完整匹配维护运行。POT原生软件执行{summary['POT_pass_cases']}例，"
        f"另{summary['POT_not_admitted']}例按冻结内存估计未准入。", "",
        "每条更新序列在完整15000源、15000目标上依次执行8个更新，状态连续保留。"
        "冷启动每图1条序列，三个热路径每图各3条。所有完整匹配输出均核对活动容量、"
        "全候选对偶可行性和独立原生稀疏JV目标。", "",
        f"独立账单、结构与交叉目标审查{checks:,}项通过，完整活动候选对核验累计{full_checks:,}对次。"
        "重复方法和计时不增加独立数据来源数。", "",
        "## 规模改变了什么", "",
        "| 图 | 源×目标 | top1冲突余量 | 完整最优净收益 | top4损失 | top16损失 | top64损失 |",
        "| --- | --- | --- | --- | --- | --- | --- |"]
    for row in scales:
        losses = [max(0., row["topk"][str(k)]["loss"]) for k in (4, 16, 64)]
        text.append(f"| {row['graph']} | {row['sources']}×15000 | {row['top1_duplicate_excess']} | "
            f"{row['result']['objective']:.6f} | " + " | ".join(f"{v:.6f}" for v in losses) + " |")
    text += ["", "损失按给定相似度与0.4阈值的最大权部分匹配目标计算。小于1e−6的差异按核验容差解释。"
        "这些结果说明候选截断可能损失匹配目标，实体标签准确率仍需另行评价。", "",
        "| 图 | 源数 | 分数构造秒 | 匹配秒 | 其中LP秒 | 其中定价秒 | 轮数 | 含核验/诊断阶段总秒 |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for row in scales:
        text.append(f"| {row['graph']} | {row['sources']} | {row['score_matrix_seconds']:.3f} | "
            f"{row['matching_seconds']:.3f} | {row['result']['lp_seconds']:.3f} | "
            f"{row['result']['pricing_seconds']:.3f} | {row['result']['rounds']} | {row['total_seconds']:.3f} |")
    text += ["", "阶段总费用还包含输入读取、独立核验、top-k诊断与状态写出，"
        "不与单纯匹配费用混合。进程树资源监控记录与日志纳入asset_manifest.json，"
        "summary.json逐运行保留实际峰值作业提交内存。", "",
        "## 完整维护费用", "",
        "| 图 | 路径 | 序列次数 | 8次维护中位秒 | 总秒范围 | 初始恢复/新增构造中位秒 | 构造加8次维护中位秒 |",
        "| --- | --- | --- | --- | --- | --- | --- |"]
    for graph in GRAPHS:
        for method in METHODS:
            row = grouped.get((graph, method))
            if row:
                text.append(f"| {graph} | {method} | {row['runs']} | {row['median_maintenance_seconds']:.3f} | "
                    f"[{row['minimum_maintenance_seconds']:.3f}, {row['maximum_maintenance_seconds']:.3f}] | "
                    f"{row['median_setup_seconds']:.3f} | {row['median_setup_plus_8_seconds']:.3f} |")
    text += ["", "dense_cold每次重新生成全分数和候选并求解；cache_warm复用分数、候选和实际basis；"
        "stream_warm保留候选与basis，分块计算完整定价；block_warm另维护固定cap_256块界。"
        "计时从已提供的变化向量开始，覆盖完整匹配维护，编码器推理与独立核验费用单列。", "",
        "各路径从相同已物化历史状态开始。表中初始费用为恢复状态与新增结构。"
        "若计入共同首快照构造，须在各方法费用上同加规模表中的score_matrix_seconds和matching_seconds。", "",
        "| 图 | 路径 | LP中位秒 | 定价中位秒 | 分数/索引维护中位秒 | 最慢实测单次秒 | 独立核验中位秒 |",
        "| --- | --- | --- | --- | --- | --- | --- |"]
    for row in grouped.values():
        text.append(f"| {row['graph']} | {row['method']} | {row['median_lp_seconds']:.3f} | "
            f"{row['median_pricing_seconds']:.3f} | {row['median_score_or_index_update_seconds']:.3f} | "
            f"{row['maximum_observed_event_seconds']:.3f} | {row['median_independent_validation_seconds']:.3f} |")
    text += ["", "各分项分别取序列中位数，分项之和可能与总费用中位数略有差别。"
        "总费用还包含候选费用/容量修改、补边及相关管理。核验费用在算法计时之外单列，"
        "没有发生被隐去的超时回退。三个重复是同一受控序列的计时重复，尚不能估计真实负载的尾延迟。", "",
        "## 连续更新分层", "",
        "| 图 | 步骤 | 更新 | cache_warm中位秒 | stream_warm中位秒 | block_warm中位秒 | 冷启动目标 |",
        "| --- | --- | --- | --- | --- | --- | --- |"]
    for graph in GRAPHS:
        cold = next((t for t in traces if t["graph"] == graph and t["method"] == "dense_cold"), None)
        if cold is None:
            continue
        for step, event in enumerate(cold["records"]):
            costs = [grouped[graph, method]["median_event_seconds"][step]
                     if (graph, method) in grouped else float("nan")
                     for method in ("cache_warm", "stream_warm", "block_warm")]
            text.append(f"| {graph} | {step} | {event['event']} | " + " | ".join(f"{c:.3f}" for c in costs)
                        + f" | {event['result']['objective']:.6f} |")
    text += ["", "退出和再加入发生于固定实体宇宙。配对变化数及传播到未直接编辑源的情况保存在逐事件JSON。"
        "最优解可能并列，观察到的配对变化依赖求解器选择，不能直接解释为所有变化都不可避免。", "",
        "| 图 | 更新 | 冷路径配对变化源数 | 其中直接影响集外源数 |",
        "| --- | --- | --- | --- |"]
    for row in traces:
        if row["method"] == "dense_cold":
            for event in row["records"]:
                text.append(f"| {row['graph']} | {event['event']} | {event['matching_changed_sources']} | "
                    f"{event['changed_outside_direct_sources']} |")
    text += ["", "直接影响集包含向量变化源、退出/重入源，以及上一步匹配到变化或退出/重入目标的源。"
        "其余变化源反映这次求解输出的传播范围。", "",
        "## 内存边界", "",
        "完整binary64分数缓存分别为117.19、468.75、937.50、1716.61MiB。"
        "15K×15K的1,800,000,000字节矩阵在1GiB应用分数缓存额度下不准入，2GiB额度下可准入。"
        "本轮实际执行无稠密分数缓存的stream_warm与block_warm，不能只与被拒绝的dense缓存比较。", "",
        "| 源数 | 完整缓存MiB | 64MiB | 128MiB | 256MiB | 512MiB | 1024MiB | 2048MiB |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for row in summary["cache_admission"]:
        admissions = ["准入" if row["admission_MiB"][str(b)] else "未准入"
            for b in (64, 128, 256, 512, 1024, 2048)]
        text.append(f"| {row['sources']} | {row['score_cache_bytes']/2**20:.2f} | "
            + " | ".join(admissions) + " |")
    text += ["", "两图矩阵形状相同，这张表共用同一准确缓存字节数。", "",
        "| 图 | 路径 | 峰值作业提交内存GiB | 最大事件末RSS GiB |",
        "| --- | --- | --- | --- |"]
    for graph in GRAPHS:
        for method in METHODS:
            row = grouped.get((graph, method))
            if row:
                commit = row["maximum_peak_job_commit_GiB"]
                text.append(f"| {graph} | {method} | {commit:.3f} | {row['maximum_observed_rss_end_bytes']/2**30:.3f} |")
    text += ["", "Windows作业峰值为提交内存，文件映射驻留页不与其等同。RSS是事件末采样的最大值，"
        "不冒充连续采样的峰值RSS。1GiB额度限制的是应用分数缓存，整个进程仍受7GiB作业内存限制。", "",
        "## 原生POT软件补充对照", "",
        "| 图 | 两侧实体数 | 状态 | 分数构造秒 | POT求解秒 | 含核验总秒 | 目标 |",
        "| --- | --- | --- | --- | --- | --- | --- |"]
    for row in pot:
        text.append(f"| {row['graph']} | {row['n']} | {row['status']} | "
                    + (f"{row['score_seconds']:.3f} | {row['POT_seconds']:.3f} | {row['total_seconds']:.3f} | "
                       f"{row['objective']:.6f} |" if row["status"] == "PASS" else "— | — | — | — |"))
    text += ["", "该对照采用平衡完全匹配、单位质量和1−cosine成本，原生network-simplex结果与密集JV核对。"
        "主实验允许不匹配，两类性能结果分别解释。15K POT未准入来自冻结保守估计，未执行不构成实测内存下界。", "",
        "## 构造摊销", "",
        "summary.json保留实际8次请求费用。对R=1/8/32/128，可按"
        "共同首快照费用+新增构造+R×实测8次维护平均费用计算同一混合负载的费用模型。"
        "这是静态费用外推，不能当作已执行32或128次连续请求。共同费用覆盖完整分数构造和初始匹配，"
        "输入读取、编码器、研究用哈希/核验和状态落盘未计入这张运行费用模型。", "",
        "| 图 | 路径 | R=1模型秒 | R=8模型秒 | R=32模型秒 | R=128模型秒 |",
        "| --- | --- | --- | --- | --- | --- |"]
    for row in cost_models:
        text.append(f"| {row['graph']} | {row['method']} | "
            + " | ".join(f"{row['model_total_seconds_by_R'][str(r)]:.3f}" for r in (1, 8, 32, 128)) + " |")
    text += ["",
        '[说明文本已清理]', "",
        '[说明文本已清理]', ""]
    if signals:
        text += ['[说明文本已清理]']
    else:
        text += ['[说明文本已清理]']
    text += ["", '[说明文本已清理]', "",
        '[说明文本已清理]']
    text += ["", "原版ShortCut以及TODS空间匹配系统仍未完成同合同运行，软件与安装条件见"
        "papers/icde/INCREMENTAL_MATCHING_SOFTWARE_REVIEW_20261110.md。HiGHS与POT的实际执行不能替代这两项完整系统比较。", "",
        "## 保留的限制", "",
        "- 两图均为历史来源、同一RREA种子和固定600维表示，更新为受控构造及历史删边，真实业务日志仍缺失。",
        "- 本轮使用全部15000源，包含原先保留的源池，后续方法独立确认需要新的输入与协议。",
        "- 完整费用从变化向量开始，GNN重算、原始图版本处理和真实服务部署尚未纳入。",
        '[说明文本已清理]',
        "- 15K以上的真实图未执行。缓存额度准入、实际RSS与作业提交内存各自报告。", ""]
    if missing:
        text += ["## 尚缺运行", ""] + ["- " + name for name in missing] + [""]
    (BASE / "RESULTS_ZH.md").write_text("\n".join(text), encoding="utf-8")
    files = sorted({p for p in BASE.rglob("*") if p.is_file()} | set(resource_files) | {Path(__file__)})
    save(BASE / "asset_manifest.json", {"status": summary["status"],
        "files": {str(p.relative_to(ROOT)).replace("\\", "/"): sha(p) for p in files},
        "reporter_sha256": sha(Path(__file__)), "protocol_sha256": sha(BASE / "protocol.json")})
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
