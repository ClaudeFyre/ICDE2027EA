"""Finite tests of hybrid epsilon composition and unchanged paired scoring."""

from pathlib import Path
from types import SimpleNamespace
import sys
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from icde_gate_hybrid_runner import HYBRID_POLICIES, prepare_settings, run_hybrid_case
from icde_gate_hybrid_envelope import HybridEnvelope, compile_hybrid
from icde_gate_comparison_runner import run_case
from icde_online_execution import PreparedQuery
from vldb_difference_envelope_v2 import compile_difference_kernel


def fixed_winner_query():
    original = SimpleNamespace(
        source="s", candidates=("a", "b"), edge_indices=tuple(range(5)),
        incidence_positions=tuple(np.asarray(value, dtype=np.intp)
                                  for value in ((0,), (), (1,), (), (2, 3, 4), ())),
        attribute=np.zeros(2, dtype=np.float64), lexical=np.zeros(2, dtype=np.float64),
        attribute_weight=0.,
    )
    kernel = compile_difference_kernel(original)
    q = np.array([.5, 1., 1., 1., 1.], dtype=np.float64)
    low, high = q.copy(), q.copy()
    low[0], high[0] = .125, .875
    envelope = compile_hybrid(kernel, q, low, high)
    query = PreparedQuery("toy", "q", "revision", kernel, q, low, high, envelope.epsilon_scope,
                          {"cost_model": kernel.compilation_summary})
    return query, envelope


class Clock:
    def __init__(self):
        self.value = 0.

    def __call__(self):
        return self.value


class HybridRunnerTests(unittest.TestCase):
    def settings(self, **extra):
        return prepare_settings({"sample_count": 256,
                                 "work_model": {"nominal_candidate_units": 16,
                                                "interval_candidate_units": 1}, **extra})

    def test_source_drift_is_added_instead_of_silently_reusing_generic_cp(self):
        query, envelope = fixed_winner_query()
        settings = self.settings()
        generic = run_case(query, settings, "normal_event", 97)
        hybrid = run_hybrid_case(query, settings, "normal_hybrid", 97, envelope=envelope)
        self.assertTrue(generic["certified"])
        self.assertTrue(hybrid["certified"])
        self.assertGreater(hybrid["samples_used"], generic["samples_used"])
        self.assertGreaterEqual(hybrid["effective_epsilon_upper"], envelope.epsilon_source)
        self.assertGreater(hybrid["final_lower_gap"], 2 * hybrid["effective_epsilon_upper"])
        self.assertEqual(hybrid["nominal_delta"], .025)
        self.assertEqual(hybrid["event_beta_total"], .025)

    def test_normal_and_eb_hybrid_keep_fixed_bound_contract(self):
        for policy in HYBRID_POLICIES:
            query, envelope = fixed_winner_query()
            row = run_hybrid_case(query, self.settings(), policy, 109, envelope=envelope)
            self.assertTrue(row["robust_certified"])
            self.assertEqual(row["event_extra_random_draws"], 0)
            self.assertLessEqual(row["work_used"], row["work_budget"])
            self.assertEqual(row["event_rows_computed"], row["event_samples_used"])
            self.assertEqual(sum(row["winner_counts"]), row["samples_used"])
            self.assertEqual(row["effective_epsilon_upper"], envelope.combine_upper(row["event_upper"]))

    def test_paired_nominal_prefixes_match_existing_generic_policies(self):
        query, envelope = fixed_winner_query()
        settings = self.settings()
        for prefix in ("normal", "eb"):
            generic = run_case(query, settings, prefix + "_event", 127)
            hybrid = run_hybrid_case(query, settings, prefix + "_hybrid", 127, envelope=envelope)
            self.assertEqual(generic["rng_seed_hex"], hybrid["rng_seed_hex"])
            first = generic["trace"][0]
            second = hybrid["trace"][0]
            self.assertEqual(first["uniform_prefix_sha256"], second["uniform_prefix_sha256"])
            self.assertEqual(first["winner_prefix_sha256"], second["winner_prefix_sha256"])
            self.assertEqual(generic["winner_indices"][:32], hybrid["winner_indices"][:32])

    def test_unaffordable_upgrade_never_inspects_hybrid_indicators(self):
        query, envelope = fixed_winner_query()
        with patch.object(HybridEnvelope, "indicators", side_effect=AssertionError("unpaid indicator")):
            row = run_hybrid_case(query, self.settings(interval_work_weight=100000.),
                                  "normal_hybrid", 97, envelope=envelope)
        self.assertEqual(row["event_rows_computed"], 0)
        self.assertGreater(row["event_admission_rejections"], 0)
        self.assertLessEqual(row["work_used"], row["work_budget"])

    def test_actual_eb_checks_include_budget_inserted_prefix(self):
        query, envelope = fixed_winner_query()
        row = run_hybrid_case(query, self.settings(budget_fraction=.5),
                              "eb_hybrid", 97, envelope=envelope)
        self.assertIn(128, row["actual_nominal_checkpoints"])
        self.assertIn(128, row["inference_rule"]["checkpoints"])

    def test_late_nominal_block_cannot_publish_a_certificate(self):
        query, envelope = fixed_winner_query()
        clock = Clock()

        def factory(seed):
            generator = np.random.default_rng(seed)

            class Delayed:
                def random(self, *args, **kwargs):
                    clock.value += 2.
                    return generator.random(*args, **kwargs)
            return Delayed()

        row = run_hybrid_case(query, self.settings(deadline_seconds=1.), "normal_hybrid", 97,
                              envelope=envelope, clock=clock, rng_factory=factory)
        self.assertFalse(row["certified"])
        self.assertEqual(row["status"], "deadline_postblock")
        self.assertEqual(row["samples_used"], 32)

    def test_misbound_envelope_is_rejected_and_preparation_is_disclosed(self):
        query, envelope = fixed_winner_query()
        other, _ = fixed_winner_query()
        with self.assertRaisesRegex(ValueError, "not bound"):
            run_hybrid_case(other, self.settings(), "normal_hybrid", 97, envelope=envelope)
        row = run_hybrid_case(query, self.settings(), "normal_hybrid", 97)
        self.assertTrue(row["hybrid_setup_included_in_case_serving"])
        self.assertIn("setup_seconds", row["hybrid_metadata"])


if __name__ == "__main__":
    unittest.main()
