"""Development prototype: sound categorical evidence and historical refinement.

Standard betting ingredients are attributed in the accompanying theory note.
No label-accuracy, calibration, optimality or novelty assertion is made here.
Frozen degree scoring modules are imported read-only by the runner.
"""
from __future__ import annotations

from collections import Counter
from fractions import Fraction
import math
import numpy as np


def members(mask, k):
    return [j for j in range(k) if mask & (1 << j)]


class Evidence:
    def __init__(self, k, delta=Fraction(1, 20)):
        if k < 2 or not 0 < delta < 1:
            raise ValueError("need at least two fixed candidates and a valid risk")
        self.k, self.delta = k, Fraction(delta)
        self.a, self.b, self.masks = [0] * k, [0] * k, []
        self.cache = {}
        self.checks = self.scalar_evaluations = 0

    def append(self, mask):
        if not isinstance(mask, int) or not 0 < mask < (1 << self.k):
            raise ValueError("invalid nonempty candidate set")
        self.masks.append(mask)
        for d in members(mask, self.k):
            self.b[d] += 1
        if mask & (mask - 1) == 0:
            self.a[mask.bit_length() - 1] += 1

    def refine(self, i, mask):
        old = self.masks[i]
        if not isinstance(mask, int) or not mask or mask & old != mask:
            raise ValueError("refinement must be a nonempty subset")
        if old == mask:
            return
        for d in members(old ^ mask, self.k):
            self.b[d] -= 1
        if mask & (mask - 1) == 0 and old & (old - 1):
            self.a[mask.bit_length() - 1] += 1
        self.masks[i] = mask

    def wealth(self, a, b):
        key = a, b
        if key not in self.cache:
            n, term, numerator = a + b, 1, 1
            for j in range(a):
                term = term * (n + 1 - j) // (j + 1)
                numerator += term
            self.cache[key] = Fraction(numerator, (n + 1) * math.comb(n, a))
            self.scalar_evaluations += 1
        return self.cache[key]

    def best(self):
        self.checks += 1
        d0 = max(range(self.k), key=lambda d: (self.b[d], -d))
        other = max((w for w in range(self.k) if w != d0),
                    key=lambda w: (self.a[w], -w))
        candidates = []
        for w in (d0, other):
            d = max((d for d in range(self.k) if d != w),
                    key=lambda d: (self.b[d], -d))
            candidates.append((self.wealth(self.a[w], self.b[d]), -w, d))
        value, negw, d = max(candidates)
        w = -negw
        return w, d, value >= Fraction(self.k, 1) / self.delta


class DegreeRefiner:
    """Pairwise reachable degree states, preserving original score operations."""
    def __init__(self, kernel, state_cap=2048):
        self.kernel = kernel
        self.k, self.m = len(kernel.candidates), len(kernel.edge_indices)
        self.state_cap = state_cap
        self.coefficients = np.zeros((self.k, 2, self.m), dtype=np.int64)
        for direction in range(2):
            for c in range(self.k):
                column = direction * self.k + c
                self.coefficients[c, direction, kernel.positive_positions[column]] = 1
                self.coefficients[c, direction, kernel.negative_positions[column]] = -1

    def coarse(self, low, high):
        if np.array_equal(low, high):
            return 1 << int(np.argmax(self.kernel.scores(low[None, :])[0]))
        lower, upper = self.kernel.score_intervals(low[None, :], high[None, :])
        threshold = float(np.max(lower[0]))
        mask = sum(1 << c for c in range(self.k) if upper[0, c] >= threshold)
        if not mask:
            raise AssertionError("sound score intervals cannot eliminate all candidates")
        return mask

    def eliminate(self, w, d, low, high, budget):
        """Return (proof, charged operations, status); capped work stays unknown.

        One charged operation is a DP transition or a final reachable-state
        score evaluation. This is a declared work measure, not a time bound.
        """
        if w == d or budget < 1:
            return False, 0, "no_budget"
        coeff = np.concatenate((self.coefficients[w], self.coefficients[d]), axis=0)
        base = tuple(map(int, coeff @ low.astype(np.int64)))
        groups = Counter(tuple(map(int, coeff[:, e]))
                         for e in np.flatnonzero(high & ~low))
        groups.pop((0, 0, 0, 0), None)
        reachable, work = {base}, 0
        for vector, count in sorted(groups.items()):
            updated = set()
            for state in sorted(reachable):
                for amount in range(count + 1):
                    if work >= budget:
                        return False, work, "work_cap"
                    updated.add(tuple(state[j] + amount * vector[j] for j in range(4)))
                    work += 1
                    if len(updated) > self.state_cap:
                        return False, work, "state_cap"
            reachable = updated
        if work + len(reachable) > budget:
            return False, work, "work_cap"
        states = np.asarray(sorted(reachable), dtype=np.int64)
        distance = np.stack((np.abs(states[:, 0]) + np.abs(states[:, 1]),
                             np.abs(states[:, 2]) + np.abs(states[:, 3])), axis=1)
        # Same individual NumPy operations and order as frozen kernel.scores.
        dynamic = 1.0 / (1.0 + distance.astype(np.float64))
        structural = .6 * self.kernel.lexical[[w, d]][None, :] + .4 * dynamic
        weight = self.kernel.attribute_weight
        scores = weight * self.kernel.attribute[[w, d]][None, :] + (1.0 - weight) * structural
        work += len(reachable)
        dominates = scores[:, 0] > scores[:, 1]
        if w < d:
            dominates |= scores[:, 0] == scores[:, 1]
        return bool(np.all(dominates)), work, "complete"


def exact_mask(winners, low, high):
    """Independent exhaustive oracle for small Boolean scopes; never scheduled."""
    m = len(low)
    fixed = sum(int(low[e]) << e for e in range(m))
    free = [e for e in range(m) if high[e] and not low[e]]
    result = 0
    for bits in range(1 << len(free)):
        world = fixed
        for j, e in enumerate(free):
            world |= ((bits >> j) & 1) << e
        result |= 1 << int(winners[world])
    return result
