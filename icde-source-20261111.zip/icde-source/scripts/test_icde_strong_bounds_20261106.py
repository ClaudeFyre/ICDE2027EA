"""Small exact and enumerated fixtures for the new standard-bound module.

No sampling or model inference is needed. These tests are authored separately
from frozen experiment modules; running them is the coordinating agent's job.
"""

from fractions import Fraction
from itertools import product
import math
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from icde_strong_bounds_20261106 import (
    bernoulli_mixture_interval, categorical_probability_bounds,
    chi2_event_interval, chi2_pair_gap_lower, fixed_look_cp_interval,
    hellinger_event_interval, mixture_marginal, product_divergence_bounds,
    transport_mode_intervals,
)


class StrongBoundTests(unittest.TestCase):
    def test_exact_beta_marginals_include_jeffreys_boundary_cases(self):
        self.assertEqual(mixture_marginal(0, 0), 1)
        self.assertEqual(mixture_marginal(0, 1), Fraction(1, 2))
        self.assertEqual(mixture_marginal(1, 2), Fraction(1, 6))
        self.assertEqual(mixture_marginal(1, 2, "jeffreys"), Fraction(1, 8))
        self.assertEqual(mixture_marginal(0, 2, "jeffreys"), Fraction(3, 8))
        self.assertEqual(mixture_marginal(2, 2, "jeffreys"), Fraction(3, 8))

    def test_mixture_intervals_outward_at_known_single_observation_roots(self):
        for prior in ("uniform", "jeffreys"):
            lo, hi = bernoulli_mixture_interval(1, 1, Fraction(1, 20), prior=prior)
            self.assertLessEqual(Fraction.from_float(lo), Fraction(1, 40))
            self.assertGreater(lo, .024999999999)
            self.assertEqual(hi, 1.)
            lo, hi = bernoulli_mixture_interval(0, 1, Fraction(1, 20), prior=prior)
            self.assertEqual(lo, 0.)
            self.assertGreaterEqual(Fraction.from_float(hi), Fraction(39, 40))
            self.assertLess(hi, .975000000001)
            self.assertEqual(bernoulli_mixture_interval(0, 0, .05, prior=prior), (0., 1.))

    def test_exact_mixture_confidence_set_is_inside_returned_interval(self):
        for prior in ("uniform", "jeffreys"):
            for n in (1, 3, 7):
                for successes in range(n + 1):
                    lo, hi = bernoulli_mixture_interval(successes, n, Fraction(1, 10), prior=prior)
                    marginal = mixture_marginal(successes, n, prior)
                    for j in range(33):
                        p = Fraction(j, 32)
                        likelihood = p ** successes * (1 - p) ** (n - successes)
                        if likelihood >= marginal / 10:
                            self.assertLessEqual(Fraction.from_float(lo), p)
                            self.assertGreaterEqual(Fraction.from_float(hi), p)

    def test_cp_known_roots_are_protected_not_unchecked_scipy_values(self):
        lo, hi = fixed_look_cp_interval(1, 1, Fraction(1, 20))
        self.assertLessEqual(Fraction.from_float(lo), Fraction(1, 20))
        self.assertGreater(lo, .049999999999)
        self.assertEqual(hi, 1.)
        lo, hi = fixed_look_cp_interval(0, 1, Fraction(1, 20))
        self.assertEqual(lo, 0.)
        self.assertGreaterEqual(Fraction.from_float(hi), Fraction(19, 20))
        self.assertLess(hi, .950000000001)

    def test_cp_exact_small_binomial_tails_at_returned_endpoints(self):
        alpha = Fraction(1, 25)
        for n in (2, 5, 9):
            for successes in range(n + 1):
                lo, hi = fixed_look_cp_interval(successes, n, alpha)
                lp, up = Fraction.from_float(lo), Fraction.from_float(hi)
                if successes:
                    tail = sum(Fraction(math.comb(n, j)) * lp ** j * (1-lp) ** (n-j)
                               for j in range(successes, n+1))
                    self.assertLessEqual(tail, alpha)
                if successes < n:
                    cdf = sum(Fraction(math.comb(n, j)) * up ** j * (1-up) ** (n-j)
                              for j in range(successes+1))
                    self.assertLessEqual(cdf, alpha)

    def test_categorical_risk_allocation_keeps_all_zero_count_candidates(self):
        counts = [48, 2] + [0] * 98
        result = categorical_probability_bounds(counts, 50, Fraction(1, 20))
        self.assertEqual(Fraction(result["alpha_exact"]), Fraction(1, 2000))
        self.assertEqual(len(result["lower"]), 100)
        self.assertEqual(result["leader_index"], 0)
        self.assertEqual(result["empirical_runner_index"], 1)
        self.assertGreater(result["upper"][99], 0.)
        cp = categorical_probability_bounds(counts, 50, Fraction(1, 20), method="cp_fixed", looks=(10, 50))
        self.assertEqual(Fraction(cp["alpha_exact"]), Fraction(1, 8000))
        with self.assertRaises(ValueError):
            categorical_probability_bounds(counts, 50, .05, method="cp_fixed", looks=(10, 40))

    def test_single_category_is_structural_with_no_worlds(self):
        for method in ("mixture_uniform", "mixture_jeffreys", "cp_fixed"):
            evidence = categorical_probability_bounds([0], 0, .05, method=method, looks=(32, 64))
            self.assertEqual(evidence["lower_gap"], 1.)
            self.assertTrue(evidence["nominal_certified"])

    def test_product_bounds_cover_single_edge_exact_divergences(self):
        result = product_divergence_bounds([.5], [.4], [.6])
        self.assertGreaterEqual(result["tv_hellinger_upper"], .1 - 1e-15)
        self.assertLess(result["tv_hellinger_upper"], .102)
        self.assertGreaterEqual(result["chi2_upper"], .04 - 1e-15)
        self.assertLess(result["chi2_upper"], .040000000001)
        identity = product_divergence_bounds([0., .9, 1.], [0., .9, 1.], [0., .9, 1.])
        self.assertEqual(identity["affinity_lower"], 1.)
        self.assertEqual(identity["tv_hellinger_upper"], 0.)
        self.assertEqual(identity["chi2_upper"], 0.)

    def test_product_bounds_handle_support_failure_and_empty_scope(self):
        result = product_divergence_bounds([0.], [0.], [.1])
        self.assertTrue(math.isinf(result["chi2_upper"]))
        self.assertEqual(chi2_event_interval(1., 1., math.inf), (0., 1.))
        empty = product_divergence_bounds([], [], [])
        self.assertEqual(empty["actual_coordinates"], 0)
        self.assertEqual(empty["affinity_lower"], 1.)
        self.assertEqual(empty["chi2_upper"], 0.)

    def test_event_transports_cover_every_event_on_two_bernoulli_coordinates(self):
        nominal = (.3, .7)
        lows, highs = (.25, .65), (.35, .75)
        bounds = product_divergence_bounds(nominal, lows, highs)
        worlds = list(product((0, 1), repeat=2))
        def masses(parameters):
            return [math.prod(p if bit else 1-p for p, bit in zip(parameters, world)) for world in worlds]
        qmass = masses(nominal)
        for event_mask in range(16):
            event = [j for j in range(4) if event_mask & (1 << j)]
            qevent = sum(qmass[j] for j in event)
            hl, hu = hellinger_event_interval(qevent, qevent, bounds["affinity_lower"])
            cl, cu = chi2_event_interval(qevent, qevent, bounds["chi2_upper"])
            for parameters in product(*zip(lows, highs)):
                pmass = masses(parameters)
                actual = sum(pmass[j] for j in event)
                self.assertLessEqual(hl, actual + 1e-14)
                self.assertGreaterEqual(hu, actual - 1e-14)
                self.assertLessEqual(cl, actual + 1e-14)
                self.assertGreaterEqual(cu, actual - 1e-14)

    def test_dyadic_event_enumeration_has_exact_zero_tolerance_protection(self):
        nominal = (Fraction(1, 4), Fraction(3, 4))
        lows = (Fraction(1, 8), Fraction(5, 8))
        highs = (Fraction(3, 8), Fraction(7, 8))
        bounds = product_divergence_bounds(
            list(map(float, nominal)), list(map(float, lows)), list(map(float, highs)))
        worlds = list(product((0, 1), repeat=2))
        def exact_masses(parameters):
            return [math.prod(p if bit else 1-p for p, bit in zip(parameters, world))
                    for world in worlds]
        qmass = exact_masses(nominal)
        for event_mask in range(16):
            event = [j for j in range(4) if event_mask & (1 << j)]
            qevent = sum((qmass[j] for j in event), Fraction(0))
            # Every nominal event probability here is exactly binary64.
            self.assertEqual(Fraction.from_float(float(qevent)), qevent)
            hl, hu = hellinger_event_interval(float(qevent), float(qevent), bounds["affinity_lower"])
            cl, cu = chi2_event_interval(float(qevent), float(qevent), bounds["chi2_upper"])
            for parameters in product(*zip(lows, highs)):
                pmass = exact_masses(parameters)
                actual = sum((pmass[j] for j in event), Fraction(0))
                self.assertLessEqual(Fraction.from_float(hl), actual)
                self.assertGreaterEqual(Fraction.from_float(hu), actual)
                self.assertLessEqual(Fraction.from_float(cl), actual)
                self.assertGreaterEqual(Fraction.from_float(cu), actual)

    def test_empirical_tie_does_not_create_nominal_or_identity_transport_certificate(self):
        identity = {"affinity_lower": 1., "tv_hellinger_upper": 0., "chi2_upper": 0.}
        for method in ("mixture_uniform", "mixture_jeffreys", "cp_fixed"):
            evidence = categorical_probability_bounds([4, 4, 0], 8, .05,
                                                       method=method, looks=(8, 16))
            self.assertEqual(evidence["leader_index"], 0)
            self.assertEqual(evidence["empirical_runner_index"], 1)
            self.assertLessEqual(evidence["lower_gap"], 0.)
            self.assertFalse(evidence["nominal_certified"])
            for transport in ("tv", "hellinger_event", "chi2_event", "chi2_pair"):
                result = transport_mode_intervals(evidence["lower"], evidence["upper"],
                                                  0, identity, method=transport)
                self.assertLessEqual(result["lower_gap"], 0.)
                self.assertFalse(result["certified"])

    def test_chi_square_clipped_event_bounds_use_valid_interval_extrema(self):
        for h in (.01, .3, 2., 100.):
            previous = -1.
            for q in np.linspace(0., 1., 41):
                lower, upper = chi2_event_interval(q, q, h)
                self.assertGreaterEqual(lower + 1e-15, previous)
                self.assertLessEqual(lower, q + 1e-15)
                self.assertGreaterEqual(upper, q - 1e-15)
                previous = lower
            lo, hi = chi2_event_interval(.05, .9, h)
            for q in (.05, .2, .5, .9):
                qlo, qhi = chi2_event_interval(q, q, h)
                self.assertLessEqual(lo, qlo + 1e-15)
                self.assertGreaterEqual(hi, qhi - 1e-15)

    def test_pair_variance_transport_covers_enumerated_changed_laws(self):
        bounds = product_divergence_bounds([.3, .7], [.25, .65], [.35, .75])
        # D=1 on 01, -1 on 10, and zero on the remaining worlds.
        qw, qc = .7*.7, .3*.3
        lower = chi2_pair_gap_lower(qw, qw, qc, qc, bounds["chi2_upper"])
        for p0, p1 in product((.25, .35), (.65, .75)):
            actual_gap = (1-p0)*p1 - p0*(1-p1)
            self.assertLessEqual(lower, actual_gap + 1e-14)

    def test_transport_checks_all_competitors_and_identity_has_nominal_gap(self):
        lower, upper = [.8, .05, .01], [.9, .15, .05]
        identity = {"affinity_lower": 1., "tv_hellinger_upper": 0., "chi2_upper": 0.}
        for method in ("tv", "hellinger_event", "chi2_event", "chi2_pair"):
            result = transport_mode_intervals(lower, upper, 0, identity, method=method)
            self.assertTrue(result["certified"])
            self.assertEqual(result["worst_competitor_index"], 1)
            self.assertAlmostEqual(result["lower_gap"], .65, places=14)
            self.assertTrue(result["all_competitors_checked"])

    def test_validation_rejects_invalid_risks_counts_and_probability_boxes(self):
        for args in ((-1, 3, .05), (4, 3, .05), (1, 3, 0), (1, 3, 1)):
            with self.assertRaises(ValueError):
                bernoulli_mixture_interval(*args)
        with self.assertRaises(ValueError):
            categorical_probability_bounds([2, 1], 4, .05)
        with self.assertRaises(ValueError):
            product_divergence_bounds([.5], [.7], [.4])
        with self.assertRaises(ValueError):
            product_divergence_bounds([math.nan], [.4], [.6])
        with self.assertRaises(ValueError):
            hellinger_event_interval(.7, .4, .9)


if __name__ == "__main__":
    unittest.main()
