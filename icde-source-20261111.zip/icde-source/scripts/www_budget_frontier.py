"""Budget frontier: do the three allocation rules separate under tighter budgets?

The frozen 0.8-budget audit found no difference between relative Frobenius,
uniform W2 and margin-normalized W2: all three reach 10/12 final-test cells.
That tie is decided by three flipped queries in 3,600 decisions, so at 0.8 the
experiment sits in a regime where decisions are almost all preserved and no
allocation rule can show an advantage.

This sweeps the serialized-byte budget down until decisions actually break, and
reports continuous outcomes -- pooled per-query flip rate and the distribution
of decision slack -- rather than a 12-cell pass count, which has almost no power
at these effect sizes.

Physics is shared with the frozen audit: the same payload serializers, the same
``allocation_scores``, the same byte matcher and the same gate. Only the
orchestration is new, and it writes to its own results namespace, so nothing
under ``results/fixed_index_v1`` is read for writing or re-summarized.
"""

from __future__ import annotations

import time
from pathlib import Path

import numpy as np

from pkgea.distributional import gaussian_wasserstein_squared
from pkgea.www_fsl import gaussian_distance_matrix, margin_criticalities
from run_www_equal_budget import (
    atomic_write_json, full_payload, load_full_payload, load_representation_payload,
    representation_payload,
)
from run_www_workload_audit import split_metrics
from www_fixed_index_audit import allocation_scores, digest, match_bytes, passes

RULES = ("frob", "uniform_w2", "margin_w2")
NUMERICAL_GUARD = 1e-6


def decision_slack(reference, estimate):
    """Per-query margin between the estimated winner and its best rival.

    Negative slack means the estimate would elect a different candidate.  This
    is continuous where the gate is binary, so it still separates rules in the
    regime where almost nothing flips.
    """

    slack = []
    for row_reference, row_estimate in zip(reference, estimate):
        winner = int(np.argmin(row_reference))
        rival = np.argsort(row_estimate)
        best = int(rival[0])
        runner = int(rival[1]) if len(rival) > 1 else best
        other = runner if best == winner else best
        slack.append(float(row_estimate[other] - row_estimate[winner]))
    return np.asarray(slack, dtype=float)


def summarize_slack(values):
    if not len(values):
        return {}
    return {
        "min": float(np.min(values)),
        "p05": float(np.percentile(values, 5)),
        "median": float(np.median(values)),
        "mean": float(np.mean(values)),
        "negative_count": int(np.sum(values < 0)),
    }


def target_distortions(full_means, full_covariances, index_means, index_covariances):
    """Exact per-target W2 distortion, measured against the reloaded artifact.

    Taking this from the artifact rather than from the selection score table is
    what keeps the certificate sound for the quantized variants: FP16 perturbs
    the means and the stored covariance beyond the format choice that the score
    table describes, and an understated delta would make the bound unsafe.
    """

    raw = np.array([
        np.sqrt(max(0.0, gaussian_wasserstein_squared(fm, fc, im, ic)))
        for fm, fc, im, ic in zip(full_means, full_covariances,
                                  index_means, index_covariances)
    ])
    # The batched eigensolver leaves distortion of order 1e-7 even for an
    # identical artifact.  delta carries a soundness bound, so absorb that
    # noise upward: overstating it costs coverage, understating it costs
    # correctness.
    return raw + NUMERICAL_GUARD


def certify(estimate_w2, deltas):
    """Per-query soundness certificate for a compressed target index.

    The source Gaussian is supplied exactly with the request, so only targets
    carry distortion and abs(D~(q,c) - D(q,c)) <= delta_c.  Writing w for the
    compressed argmin, the true winner must also be w whenever

        min_{c != w} [ D~(q,c) - delta_c ]  >  D~(q,w) + delta_w

    because the left side lower-bounds every rival's true distance and the right
    side upper-bounds the elected candidate's.  The test needs no reference, so
    it is computable at serving time; queries that fail it fall back for that
    query alone rather than condemning the whole artifact.

    ``estimate_w2`` must be W2, not W2 squared.  The bound is the triangle
    inequality, which holds for the metric and not for its square; the project's
    distance matrices are squared, so callers must convert.
    """

    queries = np.arange(estimate_w2.shape[0])
    winner = np.argmin(estimate_w2, axis=1)
    elected_upper = estimate_w2[queries, winner] + deltas[winner]
    rival_lower = estimate_w2 - deltas[None, :]
    rival_lower[queries, winner] = np.inf
    return rival_lower.min(axis=1) > elected_upper, winner


def certificate_report(reference_squared, estimate_squared, deltas):
    """``gaussian_distance_matrix`` returns squared W2; convert before bounding.

    argmin is unchanged by the square root, so winners are unaffected, but the
    triangle inequality only holds in the metric itself.
    """

    estimate_w2 = np.sqrt(np.maximum(estimate_squared, 0.0))
    certified, winner = certify(estimate_w2, deltas)
    truth = np.argmin(reference_squared, axis=1)
    agrees = winner == truth
    # Soundness is a theorem, so a violation means an implementation fault.
    violations = int(np.sum(certified & ~agrees))
    uncertified = ~certified
    return {
        "queries": int(len(winner)),
        "certified": int(certified.sum()),
        "coverage": float(certified.mean()),
        "certified_disagreeing_with_full_index": violations,
        "uncertified_that_were_correct_anyway": int(np.sum(uncertified & agrees)),
        "uncertified_that_would_have_been_wrong": int(np.sum(uncertified & ~agrees)),
        "distinct_targets_needed_for_fallback": int(
            len(np.unique(winner[uncertified])) if uncertified.any() else 0
        ),
    }


def run_frontier(*, output, cell, means, covariances, selection_timing, moments,
                 splits, sources, targets, truth_positions, metadata, max_error,
                 budget_fractions, certify_queries=False):
    started = time.perf_counter()
    source_count = len(sources)
    target_means, target_covariances = means[source_count:], covariances[source_count:]
    full = full_payload(target_means, target_covariances,
                        dtype=np.dtype("float32"), metadata=metadata)
    tm, tc = load_full_payload(full)

    reference_selection = gaussian_distance_matrix(
        np.concatenate((means[splits["selection"]], tm)),
        np.concatenate((covariances[splits["selection"]], tc)),
        len(means[splits["selection"]]),
    )
    criticalities = np.asarray(
        margin_criticalities(reference_selection)["entity_criticalities"]
    )[len(means[splits["selection"]]):]
    scores = dict(zip(RULES, allocation_scores(tc, criticalities)))

    # Build every budget's payloads once; the moments and reference matrices
    # below are budget-independent, which is what makes the sweep affordable.
    # The all-diagonal map is the smallest representable index, so any budget
    # below it is unreachable by construction.  Record that and carry on: an
    # unattended sweep must not die hours in because one end of the range is
    # below the floor.
    floor_payload, _ = representation_payload(
        tm, tc, ["diagonal"] * len(tc), metadata, dtype=np.dtype("float32")
    )
    floor_fraction = len(floor_payload) / len(full)

    payloads: dict[tuple[float, str], bytes] = {}
    selection_maps: dict[str, dict] = {}
    infeasible: list[dict] = []
    for fraction in budget_fractions:
        budget = int(fraction * len(full))
        for rule in RULES:
            try:
                payload, mapping, row = match_bytes(tm, tc, scores[rule], metadata, budget)
            except RuntimeError as error:
                infeasible.append({
                    "budget_fraction": fraction, "rule": rule,
                    "reason": str(error), "diagonal_floor_fraction": floor_fraction,
                })
                print(f"[frontier] {cell} budget={fraction:g} {rule}: infeasible "
                      f"(diagonal floor {floor_fraction:.4f})", flush=True)
                continue
            payloads[(fraction, rule)] = payload
            row["budget_fraction"] = fraction
            selection_maps[f"{fraction:g}:{rule}"] = row
            if rule == "margin_w2":
                fp16, _ = representation_payload(
                    tm, tc, mapping, metadata, dtype=np.dtype("float16")
                )
                payloads[(fraction, "margin_fp16")] = fp16
        print(f"[frontier] {cell} budget={fraction:g} payloads built", flush=True)
    if not payloads:
        raise RuntimeError(
            f"every requested budget is below the diagonal floor {floor_fraction:.4f}"
        )

    hashes = {key: digest(value) for key, value in payloads.items()}
    build_seconds = time.perf_counter() - started

    stages: dict[str, dict] = {}
    for label, seed in (("authorization", 59), ("final_test", 71)):
        stage_started = time.perf_counter()
        query_means, query_covariances, timing = moments(seed, label)
        section = splits[label]
        query_means = query_means[section]
        query_covariances = query_covariances[section]
        reference = gaussian_distance_matrix(
            np.concatenate((query_means, tm)),
            np.concatenate((query_covariances, tc)),
            len(query_means),
        )
        rows: dict[str, dict] = {}
        for (fraction, rule), payload in payloads.items():
            if digest(payload) != hashes[(fraction, rule)]:
                raise RuntimeError("frozen artifact digest mismatch")
            index_means, index_covariances = load_representation_payload(payload)
            estimate = gaussian_distance_matrix(
                np.concatenate((query_means, index_means)),
                np.concatenate((query_covariances, index_covariances)),
                len(query_means),
            )
            row = split_metrics(reference, estimate, truth_positions[section], sources[section])
            row["passes"] = passes(row, max_error)
            row["budget_fraction"] = fraction
            row["rule"] = rule
            row["artifact_bytes"] = len(payload)
            row["artifact_sha256"] = hashes[(fraction, rule)]
            row["slack"] = summarize_slack(decision_slack(reference, estimate))
            if certify_queries:
                deltas = target_distortions(tm, tc, index_means, index_covariances)
                report = certificate_report(reference, estimate, deltas)
                if report["certified_disagreeing_with_full_index"]:
                    raise RuntimeError(
                        f"certificate unsound in {cell} {label} {fraction:g}:{rule}: "
                        f"{report['certified_disagreeing_with_full_index']} certified "
                        "queries disagree with the full index"
                    )
                row["certificate"] = report
            rows[f"{fraction:g}:{rule}"] = row
        stages[label] = {
            "methods": rows,
            "moment_timing": timing,
            "total_seconds": time.perf_counter() - stage_started,
        }
        flips = {k: v["flipped_query_count"] for k, v in rows.items()}
        print(f"[frontier] {cell} {label} flips: {flips}", flush=True)

    atomic_write_json(output, {
        "schema_version": "www-budget-frontier-v2" if certify_queries
                          else "www-budget-frontier-v1",
        "cell": cell,
        "inputs": metadata,
        "protocol": {
            "budget_fractions": list(budget_fractions),
            "rules": list(RULES),
            "query_split": {
                name: int(section.stop - section.start)
                for name, section in splits.items()
            },
            "candidate_count": len(targets),
            "diagonal_floor_fraction": floor_fraction,
            "infeasible_budgets": infeasible,
            "fixed_numeric_index": True,
            "max_relative_squared_w2_error": max_error,
            "per_query_certificate": bool(certify_queries),
            "outcome_note": (
                "Pass counts have little power here; pooled flip rate and slack "
                "distribution are the reported outcomes."
            ),
        },
        "selection": selection_maps,
        "stages": stages,
        "timing": {
            "selection_moments": selection_timing,
            "index_build_seconds": build_seconds,
            "total_seconds": time.perf_counter() - started + selection_timing["total_seconds"],
        },
    })
