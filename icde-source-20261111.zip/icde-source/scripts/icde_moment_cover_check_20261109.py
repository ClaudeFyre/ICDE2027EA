"""Bounded arithmetic checks for the moment-cover proof, without query data.

Small tests force the moment-label branch to verify feasibility and rounding.
They do not simulate the full algorithm's asymptotic large-group cutoff.
"""
from fractions import Fraction as Q
import argparse
import hashlib
from itertools import product
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_additive_theory_20261109/moment_check_attempt1"


def save(name, value):
    BASE.mkdir(parents=True, exist_ok=True)
    with (BASE / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def source_digest():
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def label(probabilities, denominator):
    n = len(probabilities)
    return (sum(n * p // denominator for p in probabilities),
            sum(n * p * (denominator - p) // denominator**2 for p in probabilities))


def representatives(options, denominator):
    n = len(options)
    states = {(0, 0): ()}
    for choices in options:
        updated = {}
        for (first, second), witness in states.items():
            for p in choices:
                key = (first + n * p // denominator,
                       second + n * p * (denominator - p) // denominator**2)
                if key not in updated:
                    updated[key] = witness + (p,)
        states = updated
    return states


def weights(probabilities, denominator):
    result = [1]
    for p in probabilities:
        updated = [0] * (len(result) + 1)
        for count, mass in enumerate(result):
            updated[count] += (denominator - p) * mass
            updated[count + 1] += p * mass
        result = updated
    if sum(result) != denominator**len(probabilities):
        raise AssertionError("Probability weights do not normalize")
    return result


def moments(probabilities, denominator):
    return Q(sum(probabilities), denominator), Q(sum(p * (denominator - p) for p in probabilities), denominator**2)


def freeze():
    save("protocol.json", {"source_sha256": source_digest(),
        "small_n": [4, 6, 8, 10], "small_denominator": 10,
        "options": "l_i=(2+i%3)/10, u_i=(6+i%4)/10",
        "large_n": [200, 400], "large_denominator": 1000,
        "large_vectors": "half 250/1000 and half 750/1000 versus half 251/1000 and half 749/1000",
        "checks": "all small endpoints reachable; retained vectors feasible; moment differences below one; exact TV and payoff error; nontrivial large-variance comparison",
        "scope": "finite arithmetic sanity checks, not a complete implementation or an independent proof"})


def run():
    protocol = json.loads((BASE / "protocol.json").read_text(encoding="utf-8"))
    if protocol["source_sha256"] != source_digest():
        raise AssertionError("Frozen checker changed")
    small = []
    for n in protocol["small_n"]:
        denominator = protocol["small_denominator"]
        options = [(2 + i % 3, 6 + i % 4) for i in range(n)]
        retained = representatives(options, denominator)
        for key, witness in retained.items():
            if key != label(witness, denominator) or any(p not in choices for p, choices in zip(witness, options)):
                raise AssertionError("Retained representative is infeasible")
        retained_weights = {key: weights(vector, denominator) for key, vector in retained.items()}
        scale = denominator**n
        maximum_tv = Q(0)
        all_minimum = Q(1)
        retained_minimum = min(Q(2 * mass[n // 2], scale) - 1 for mass in retained_weights.values())
        for vector in product(*options):
            key = label(vector, denominator)
            witness = retained[key]
            mu, variance = moments(vector, denominator)
            other_mu, other_variance = moments(witness, denominator)
            if abs(mu - other_mu) >= 1 or abs(variance - other_variance) >= 1:
                raise AssertionError("Moment-label error exceeds the proof bound")
            mass = weights(vector, denominator)
            tv = Q(sum(abs(a - b) for a, b in zip(mass, retained_weights[key])), 2 * scale)
            maximum_tv = max(maximum_tv, tv)
            all_minimum = min(all_minimum, Q(2 * mass[n // 2], scale) - 1)
        bias = retained_minimum - all_minimum
        if not 0 <= bias <= 2 * maximum_tv:
            raise AssertionError("Representative minimum violates the TV payoff bound")
        small.append({"n": n, "endpoint_vectors": 2**n, "representatives": len(retained),
            "maximum_tv_exact": str(maximum_tv), "maximum_tv": float(maximum_tv),
            "pair_gap_bias_exact": str(bias)})
    large = []
    for n in protocol["large_n"]:
        denominator = protocol["large_denominator"]
        first = (250,) * (n // 2) + (750,) * (n // 2)
        second = (251,) * (n // 2) + (749,) * (n // 2)
        mu, variance = moments(first, denominator)
        other_mu, other_variance = moments(second, denominator)
        if abs(mu - other_mu) >= 1 or abs(variance - other_variance) >= 1:
            raise AssertionError("Large comparison does not meet the moment premise")
        first_weights, second_weights = weights(first, denominator), weights(second, denominator)
        tv = Q(sum(abs(a - b) for a, b in zip(first_weights, second_weights)), 2 * denominator**n)
        minimum_variance = min(variance, other_variance)
        lower_sigma = math.isqrt(minimum_variance.numerator // minimum_variance.denominator)
        conservative_bound = Q(3, lower_sigma) + 6 / minimum_variance
        if not tv <= conservative_bound < 1:
            raise AssertionError("Nontrivial translated-Poisson comparison failed")
        large.append({"n": n, "minimum_variance_exact": str(minimum_variance),
            "tv": float(tv), "conservative_tv_bound": float(conservative_bound)})
    save("checks.json", {"status": "PASS", "protocol_sha256": hashlib.sha256((BASE / "protocol.json").read_bytes()).hexdigest(),
        "small": small, "large": large, "complete_endpoint_vectors_checked": sum(row["endpoint_vectors"] for row in small)})
    print("PASS moment-label feasibility and exact arithmetic checks", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("freeze", "run"))
    {"freeze": freeze, "run": run}[parser.parse_args().mode]()
