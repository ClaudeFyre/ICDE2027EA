"""Static scientific diagnostics; all values read from completed frozen outputs."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.runtime/icde_plot_site'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

BASE=ROOT/'nodes/09_vldb_query_certification/results/icde_parameter_association_20261108'


def main():
    q=json.loads((BASE/'attempt1/quantifier_census.json').read_text())
    c=json.loads((BASE/'strong_control_and_signal_correction_attempt1/strong_population_controls.json').read_text())
    a=json.loads((BASE/'strong_control_and_signal_correction_attempt1/alignment_signal_corrected.json').read_text())
    d=json.loads((BASE/'attempt1/static_diagnosis.json').read_text())
    out=BASE/'figures_publication';out.mkdir(exist_ok=False)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'pdf.fonttype':42,'savefig.dpi':180})
    fig,axes=plt.subplots(2,2,figsize=(12,8.3))
    ax=axes[0,0]
    values=[sum(bool(r['pointwise_certifiable_winners']) for r in q['rows']),
            c['summary']['oracle_scalar_certifiable'],c['summary']['separate_event_certifiable'],
            c['summary']['robust_queries']]
    labels=['Exact pointwise\ncondition','Optimal scalar\ndrift condition','Exact separate\nevent bounds','Exact pair\ngap reference']
    bars=ax.bar(range(4),values,color=['#BD7B27','#6792B5','#4C9C6C','#344054'],width=.65)
    ax.bar_label(bars,padding=3);ax.set_ylim(0,115)
    ax.set_xticks(range(4),labels);ax.set_ylabel('Population-certifiable queries')
    ax.set_title('(a) Strong exact controls also recover all omissions',loc='left',fontsize=11)
    ax=axes[0,1]
    robust=[r for r in q['rows'] if r['uniform_winners']]
    for flag,color,label in [(False,'#6792B5','Pointwise condition positive'),(True,'#BD3F37','Quantifier omission')]:
        rows=[r for r in robust if r['quantifier_omission']==flag]
        ax.scatter([r['true_minimum_gaps'][r['uniform_winners'][0]] for r in rows],
                   [r['minimum_gaps'][r['uniform_winners'][0]] for r in rows],
                   s=35,alpha=.65,color=color,label=f'{label} ({len(rows)})')
    ax.axhline(0,color='#555555',ls='--',lw=1)
    ax.plot([0,1],[0,1],':',color='#aaaaaa',lw=1)
    ax.set_xlim(-.02,1.04);ax.set_ylim(-.55,1.05)
    ax.set_xlabel('Exact worst-case pair gap');ax.set_ylabel('Exact pointwise population gap')
    ax.set_title('(b) Real sign separation under the fixed coupling',loc='left',fontsize=11)
    ax.legend(fontsize=8,loc='lower right');ax.grid(alpha=.15)
    ax=axes[1,0]
    categories=['Trivial\nsingle-candidate','Eligible\ncompetitive','Outside prototype\nresource limits']
    counts=d['categories']
    bars=ax.bar(range(3),[counts['trivial_single_candidate'],counts['eligible_competitive'],
                         counts['outside_prototype_resource_limits']],
                color=['#9AA4B2','#4C9C6C','#BD7B27'],width=.6)
    ax.bar_label(bars,padding=3);ax.set_xticks(range(3),categories);ax.set_ylim(0,315)
    ax.set_ylabel('Historical queries (total 576)')
    ax.set_title('(c) Non-admission is not a hardness result',loc='left',fontsize=11)
    ax.text(.02,.93,'Excluded median groups: 26; eligible median: 5',transform=ax.transAxes,
            fontsize=9,color='#555555')
    ax=axes[1,1]
    for i,key in enumerate(['aurc','brier','logloss']):
        value=a['differences'][key];delta=value['difference']*1000
        lo,hi=np.asarray(value['descriptive_source_bootstrap_95pct'])*1000
        ax.errorbar(delta,i,xerr=np.asarray([[delta-lo],[hi-delta]]),fmt='o',
                    capsize=4,color='#2563A6',ms=6)
    ax.axvline(0,color='#555555',ls='--',lw=1)
    ax.set_yticks(range(3),['AURC','Brier','Log-loss']);ax.set_ylim(2.7,-.6)
    ax.set_xlabel('Added-stability change (x 0.001; lower is better)')
    ax.set_title('(d) No reliable incremental label-risk improvement',loc='left',fontsize=11)
    ax.grid(axis='x',alpha=.15)
    ax.text(.02,.03,'512 historical sources; seeds grouped in folds.\n95% descriptive source bootstrap; fixed OOF fits.',
            transform=ax.transAxes,fontsize=9,color='#555555')
    fig.suptitle('Parameter association, structural limits, and label-risk diagnostics',fontsize=14,y=.99)
    fig.text(.5,.018,'148 eligible queries, 101 truly robust. Panel (a) uses exact oracle conditions, not zero-cost online methods.\n'
             'Configured independent retention q=0.9, tau=0.25; fixed degree scorer.\n'
             'Pointwise failure does not imply failure of all abstract-Monte-Carlo or credal-circuit algorithms.',
             ha='center',fontsize=9,color='#555555')
    fig.tight_layout(rect=(0,.09,1,.96),h_pad=2.5,w_pad=2.2)
    for suffix in ('png','pdf'):fig.savefig(out/f'association_diagnostics.{suffix}')
    plt.close(fig)
    print(out/'association_diagnostics.png')


if __name__=='__main__':main()
