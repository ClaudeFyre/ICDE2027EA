"""Finite follow-up isolating the cost of full joint parameter tables."""
import argparse
from pathlib import Path
import statistics
import time
import numpy as np

import icde_prospective_20261107 as old
from icde_grouped_inventory_20261108 import ROOT,load,save,sha
from icde_grouped_exact_20261108 import compile_counts,solve_counts
from icde_partial_count_20261108 import execute as dense_or_partial
from icde_factor_partial_20261108 import execute as factor_partial
from icde_partial_count_study_20261108 import audit
from run_vldb_interval_gate_v1 import clipped_box

PARENT = ROOT / "nodes/09_vldb_query_certification/results/icde_partial_count_20261108/attempt1"
BASE = PARENT.parent / "factor_followup_attempt1"
POLICIES = ("dense_exact","standard_mass","certificate","factor_mass","factor_certificate")


def main(out):
    if out.exists():
        raise FileExistsError(out)
    parent,summary = load(PARENT/"protocol.json"),load(PARENT/"summary.json")
    cases = [r for r in parent["cases"] if r["role"]=="static_large_scope" or (r["graph"]=="dw" and r["rank"] in (113,244))]
    code = dict(parent["code_sha256"])
    for name in ("icde_factor_partial_20261108.py","test_icde_factor_partial_20261108.py","icde_factor_partial_study_20261108.py"):
        code[f"scripts/{name}"] = sha(ROOT/"scripts"/name)
    p = {"kind":"known_query_factorized_bound_followup_after_joint_table_cost_diagnosis",
        "cases":cases,"policies":list(POLICIES),"repeats":3,"state_cap":32768,"max_splits":127,
        "max_parameter_splits":31,"tau":.25,"nominal":.9,
        "selection":"all 8 previous large prototypes plus the same 2 known omission queries; development only",
        "factor_baseline":"standard sum-product min/max relaxation, count-space and endpoint-orbit box refinement; no joint parameter table",
        "shared_rules":"same exact group distributions, outward score bounds, longest-axis splits, and 3-count-to-1-parameter action schedule; only count-region priority differs between factor controls",
        "comparison":"all 5 methods interleaved in this process; complete exact control includes direct-constant fast path",
        "code_sha256":code,"input_sha256":dict(parent["input_sha256"]),
        "parent_summary_sha256":sha(PARENT/"summary.json"),"frozen_at_unix":time.time()}
    save(out/"protocol.json",p)
    checks = 0
    def identity():
        nonlocal checks
        for group in ("code_sha256","input_sha256"):
            for name,digest in p[group].items():
                if sha(ROOT/name)!=digest:
                    raise AssertionError("frozen source/input identity changed")
                checks += 1
    identity()
    save(out/"recovery.json",{"status":"PASS","checks":checks,"scope":"inherited identities; parent NPZ CRC audit already passed"})
    rows = []
    for index,case in enumerate(cases):
        kernel,meta = old.read_query(case["graph"],case["rank"])
        low,high = clipped_box(np.full(case["scope_edges"],.9),.25)
        compiled = compile_counts(kernel,low,high)
        reference = solve_counts(compiled,case["candidates"])
        decisions = {}
        for repeat in range(p["repeats"]):
            offset = (index+repeat)%len(POLICIES)
            for policy in POLICIES[offset:]+POLICIES[:offset]:
                function = factor_partial if policy.startswith("factor_") else dense_or_partial
                result = function(kernel,low,high,policy,p)
                if result["kind"]=="factorized_partial_regions":
                    checks += audit({**result,"kind":"partial_count_regions"},compiled,reference,case["candidates"])
                    coverage = np.zeros(compiled["shape"],dtype=np.int16)
                    for cell in result["parameter_cells"]:
                        coverage[tuple(slice(a,b+1) for a,b in zip(cell["low"],cell["high"]))] += 1
                    if not np.all(coverage==1):
                        raise AssertionError("parameter orbit boxes do not form a full disjoint cover")
                    if result["count_splits"]>p["max_splits"] or result["parameter_splits"]>p["max_parameter_splits"]:
                        raise AssertionError("refinement work cap violated")
                    if result["probability_states_allocated"]!=0:
                        raise AssertionError("factorized baseline unexpectedly allocated a joint probability table")
                    checks += 3
                else:
                    checks += audit(result,compiled,reference,case["candidates"])
                decision = result["status"],result["winner"],result.get("count_splits",result.get("splits")),result.get("parameter_splits",0)
                if policy in decisions and decisions[policy]!=decision:
                    raise AssertionError("deterministic repeated result changed")
                decisions[policy] = decision
                row = {**case,"policy":policy,"repeat":repeat,**result}
                save(out/"cases"/f"{case['graph']}_q{case['rank']:03d}_{policy}_r{repeat}.json",row)
                rows.append({k:v for k,v in row.items() if k not in ("trace","leaf_records","parameter_cells","witnesses")})
        print(f"completed {case['graph']} q{case['rank']:03d}: {decisions}",flush=True)
    identity()
    aggregates = []
    for case in cases:
        for policy in POLICIES:
            selected = [r for r in rows if r['graph']==case['graph'] and r['rank']==case['rank'] and r['policy']==policy]
            first = selected[0]
            aggregates.append({**case,"policy":policy,"status":first['status'],"winner":first['winner'],
                "median_seconds":statistics.median(r['compute_seconds'] for r in selected),
                "minimum_seconds":min(r['compute_seconds'] for r in selected),
                "maximum_seconds":max(r['compute_seconds'] for r in selected),
                "point_score_states":first['point_score_states'],
                "count_splits":first.get('count_splits',first.get('splits',0)),
                "parameter_splits":first.get('parameter_splits',0),
                "probability_states_allocated":first['probability_states_allocated']})
    save(out/"summary.json",{"status":"PASS","checks":checks,"rows":rows,"aggregates":aggregates,
        "protocol_sha256":sha(out/"protocol.json"),"historical_inputs_unchanged":True,
        "limitations":["known development queries only","same degree model and homogeneous independent endpoints",
            "standard interval sum-product and branch-and-bound are not independently novel",
            "bounded refinement may remain unresolved","no full reproduction of published SPROUT or credal-circuit code",
            "prepared compute timings only; no new prospective or cross-model validation"]})
    print(f"PASS {len(rows)} runs, {checks} checks",flush=True)


if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,default=BASE)
    args = parser.parse_args()
    main(args.output.resolve())
