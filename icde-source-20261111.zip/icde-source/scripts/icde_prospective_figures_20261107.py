"""Standalone scientific figures from completed prospective artifacts only."""
from collections import defaultdict
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/".runtime/icde_plot_site"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BASE=ROOT/"nodes/09_vldb_query_certification/results/icde_prospective_20261107"
OUT=BASE/"figures"
OUT.mkdir(parents=True,exist_ok=False)
data=json.loads((BASE/"final_summary.json").read_text(encoding="utf-8"))
colors={"cheap":"#737373","direct":"#2d8a67","eager":"#2766aa","lazy":"#d47d26"}
labels={"cheap":"Mixture + transport","direct":"Global interval + cheap","eager":"Generic event, eager","lazy":"Generic event, gated"}
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42})

def finish(fig,name):
    fig.savefig(OUT/f"{name}.png",dpi=220,bbox_inches="tight")
    fig.savefig(OUT/f"{name}.pdf",bbox_inches="tight")
    plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(8,3.1),layout="constrained",sharey=True)
for ax,g in zip(axes,("dw","enfr")):
    for policy in colors:
        rows=sorted([r for r in data["curves"] if r["graph"]==g and r["policy"]==policy],key=lambda r:r["budget_seconds"])
        if rows:
            ax.plot([r["budget_seconds"] for r in rows],[r["delivered"]/r["cases"] for r in rows],"o-",label=labels[policy],color=colors[policy],markersize=4)
    ax.set_title(g.upper())
    ax.set_xlabel("Warm response budget (s)")
    ax.set_ylim(0,1.02)
axes[0].set_ylabel("Delivered robust certificate fraction")
axes[-1].legend(fontsize=7,loc="best")
finish(fig,"prospective_budget_coverage")

fig,axes=plt.subplots(1,2,figsize=(8,3.1),layout="constrained",sharey=True)
for ax,g in zip(axes,("dw","enfr")):
    for policy in colors:
        rows=sorted([r for r in data["sensitivity"] if r["graph"]==g and r["policy"]==policy],key=lambda r:r["tau"])
        if rows:
            ax.plot([r["tau"] for r in rows],[r["delivered"]/r["cases"] for r in rows],"o-",label=labels[policy],color=colors[policy],markersize=4)
    ax.set_title(g.upper());ax.set_xscale("log");ax.set_xlabel("Configured parameter half-width")
    ax.set_ylim(0,1.02)
axes[0].set_ylabel("Delivered robust certificate fraction")
axes[-1].legend(fontsize=7)
finish(fig,"prospective_width_sensitivity")

fig,axes=plt.subplots(1,2,figsize=(8,3.1),layout="constrained")
components=[("divergence","Model bound"),("direct_global_interval","Global interval"),("rng","World draws"),("scoring_hashing","Scoring / hash"),("probability_transport","Mixture / transport"),("event","Structure event"),("event_inference","Event probability"),("other","Policy / other / persistence")]
for ax,g in zip(axes,("dw","enfr")):
    groups=defaultdict(list)
    for entry in data["consumed"]:
        if "/primary_" not in entry["path"]:continue
        summary=json.loads((ROOT/entry["path"]).read_text(encoding="utf-8"))
        if summary["graph"]!=g:continue
        for row in summary["rows"]:
            raw=json.loads((ROOT/row["case"]).read_text(encoding="utf-8"))
            groups[row["policy"]].append((raw,row["response_seconds_including_persistence"]))
    bottom=np.zeros(len(colors))
    for component,label in components:
        values=[]
        for policy in colors:
            items=groups[policy]
            if component=="other":
                values.append(np.mean([max(0.,total-sum(raw["seconds"].get(k,0.) for k,_ in components if k!="other")) for raw,total in items]))
            else:values.append(np.mean([raw["seconds"].get(component,0.) for raw,total in items]))
        ax.bar(range(len(colors)),values,bottom=bottom,label=label)
        bottom+=values
    ax.set_xticks(range(len(colors)),list(colors),rotation=15)
    ax.set_title(g.upper());ax.set_ylabel("Mean response time (s)")
handles,legend_labels=axes[-1].get_legend_handles_labels()
fig.legend(handles,legend_labels,fontsize=7,ncol=4,loc="lower center",bbox_to_anchor=(.5,-.15),frameon=False)
finish(fig,"prospective_cost_breakdown")

fig,axes=plt.subplots(1,2,figsize=(8,3.1),layout="constrained")
reuse=np.asarray([1,3,10,30,100,300,1000])
for ax,g in zip(axes,("dw","enfr")):
    for policy in colors:
        row=next(r for r in data["primary"] if r["graph"]==g and r["policy"]==policy)
        serve=row["total_response_seconds"]/row["query_seed_cases"]
        # Descriptive allocation of the actually measured 288-query build,
        # not a measured independently reconstructed cold serving latency.
        allocation=data["construction_seconds"][g]/288+data["prepared_load_seconds_once_per_query"][g]/256
        amortized=allocation/reuse+serve
        ax.plot(reuse,amortized,"o-",label=labels[policy],color=colors[policy],markersize=3)
    ax.set_xscale("log");ax.set_yscale("log");ax.set_xlabel("Uses per prepared query");ax.set_title(g.upper())
axes[0].set_ylabel("Build/load allocation + mean response (s)")
axes[-1].legend(fontsize=7)
finish(fig,"prospective_construction_amortization")

reference=json.loads((BASE/"new_exact_reference/summary.json").read_text(encoding="utf-8"))
fig,axes=plt.subplots(1,2,figsize=(8,3.1),layout="constrained",sharey=True)
for ax,g in zip(axes,("dw","enfr")):
    selected=[r for r in reference["action_audit"] if r["graph"]==g]
    arrays=[]
    for policy in colors:
        rows=[r for r in selected if r["policy"]==policy]
        arrays.append([sum(r["delivered"] for r in rows),sum(r["avoidable_unresolved"] for r in rows),
            sum(not r["delivered"] and r["no_uniform_unique_mode"] for r in rows)])
    arrays=np.asarray(arrays)
    bottom=np.zeros(len(colors))
    for j,(label,color) in enumerate(zip(("Certified safe","Unresolved, uniform mode exists","No uniform unique mode"),("#2d8a67","#d8ab48","#8f8f8f"))):
        ax.bar(range(len(colors)),arrays[:,j],bottom=bottom,label=label,color=color)
        bottom+=arrays[:,j]
    ax.set_xticks(range(len(colors)),list(colors),rotation=15)
    ax.set_title(f"{g.upper()}: exact scope <= 8")
axes[0].set_ylabel("Query-seed cases (exact subgroup only)")
handles,legend_labels=axes[-1].get_legend_handles_labels()
fig.legend(handles,legend_labels,fontsize=7,ncol=3,loc="lower center",bbox_to_anchor=(.5,-.12),frameon=False)
finish(fig,"prospective_exact_unresolved")

archived=ROOT/"nodes/09_vldb_query_certification/results"
strong=json.loads((archived/"icde_strong_bounds_rrea_20261106_attempt1/summary.json").read_text(encoding="utf-8"))
fig,ax=plt.subplots(figsize=(5.5,3.1),layout="constrained")
for method,label,color in (("mixture_jeffreys","Jeffreys mixture","#2766aa"),("mixture_uniform","Uniform mixture","#d47d26"),("cp_fixed","Protected fixed-look CP","#2d8a67")):
    rows=[r for r in strong["results"] if r["inference"]==method and r["transport"]=="best_deterministic"]
    rows=sorted(rows,key=lambda r:r["n"])
    ax.plot([r["n"] for r in rows],[r["cumulative_certificates"] for r in rows],"o-",label=label,color=color,markersize=4)
ax.axvline(256,color="#888888",linestyle="--",linewidth=1)
ax.set_xscale("log",base=2);ax.set_xticks([32,64,128,256,512],[32,64,128,256,512])
ax.set_xlabel("Archived world prefix (256 primary; 512 diagnostic)")
ax.set_ylabel("Full-edge robust certificates / 64")
ax.set_ylim(0,64);ax.legend(fontsize=7);ax.set_title("Exploratory archived RREA reanalysis")
finish(fig,"archived_strong_probability_bounds")

paid=json.loads((archived/"icde_strong_paid_replay_20261106_attempt1/summary.json").read_text(encoding="utf-8"))
fig,ax=plt.subplots(figsize=(5.5,3.1),layout="constrained")
for key,label,color in (("cheap_full_risk","Strong cheap bounds","#737373"),("paid_combination","Charged generic event evidence","#2766aa")):
    ax.plot([r["tau"] for r in paid["results"]],[r[key]["certificates"] for r in paid["results"]],"o-",label=label,color=color,markersize=4)
ax.set_xscale("log");ax.set_ylim(0,33)
ax.set_xlabel("Original parameter half-width")
ax.set_ylabel("Clearances at recorded endpoint / 32")
ax.set_title("Exploratory paid-state reclassification")
ax.legend(fontsize=7)
finish(fig,"archived_paid_endpoint_reclassification")
print(json.dumps({"figures":7,"new_confirmation_figures":5,"archived_reanalysis_figures":2,"formats":["png","pdf"],"input":str(BASE/"final_summary.json")}))
