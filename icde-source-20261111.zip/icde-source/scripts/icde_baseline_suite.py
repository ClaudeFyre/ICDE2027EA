"""ICDE strong-baseline suite for ModalTop1 (P1-reusable).

This module is the *fixed engineering reference* shared by the E2/E3/E4/E5
experiments and by downstream P1 work. It implements the four strong baselines
mandated by ``papers/icde/query_contract_v1.md`` and ``RESEARCH_PLAN_20261009.md``:

==========================  =================================================
name                        physical path
==========================  =================================================
``independent``             one query at a time, no sharing, no cache
``shared_batched``           shared batched scorer; per checkpoint only the
                             missing source/candidate rectangle is scored;
                             uint32 winner-label blocks, no dense
                             world x source x candidate tensor
``winner_lru``              winner-label-block LRU (label **payload bytes**
                             budget); no cross-query rectangle sharing
``shared_batched_lru``      shared batched scorer + winner-label LRU
==========================  =================================================

All four paths run on the *identical* checkpoint grid (batch=16, minimum=32),
the *identical* tie rule (original-precision argmax, lexical candidate-ID tie),
and the *identical* world stream. Per the contract this is strong-baseline
engineering, **not** a new algorithm: ordinary batching and ordinary LRU are
baselines and their work reduction must not be claimed as algorithmic gain.

Correctness contract
--------------------
On the same trace the four baselines must produce item-for-item identical
``winner``, ``status``, ``certified_winner``, ``samples``, ``counts`` and
``evidence_digest``. Any mismatch is a bug; ``run_all_baselines`` asserts it.

Work ledger
-----------
Each run returns a ledger with, per the contract:
``scorer_calls``, ``candidate_evaluations``, ``new_winner_labels``,
``cache_label_reads``, ``cache_label_writes``, ``evictions``,
``ahead_worlds``, ``query_world_observations``, ``peak_payload_bytes``,
``wall_seconds_informal``. Wall time here is *informal* (host may carry
parallel load); only counting/identity metrics are treated as evidence.

Importing this module
---------------------
P1 and other runners do ``import icde_baseline_suite`` with ``scripts/`` on
``sys.path`` (or ``python -m`` from the repo root after adding ``scripts``).
The module also adds the repo ``src/`` to ``sys.path`` on import so
``pkgea.*`` resolves without an editable install.
"""

from __future__ import annotations

import argparse
import json
import platform
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC = REPO_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones.toy import ToyStructuralBackbone  # noqa: E402
from pkgea.contracts import dataset_content_digest  # noqa: E402
from pkgea.query.modal import (  # noqa: E402
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    WinnerBlockCache,
    execute_modal_queries,
    identity,
)
from pkgea.samplers import FactorLaw, monte_carlo_worlds  # noqa: E402

# Fixed checkpoint grid shared by every baseline (contract v1).
DEFAULT_BATCH_SIZE = 16
DEFAULT_MINIMUM_SAMPLES = 32
DEFAULT_DELTA = 0.05

BASELINES: tuple[str, ...] = (
    "independent",
    "shared_batched",
    "winner_lru",
    "shared_batched_lru",
)

# How each name maps onto the two physical switches in execute_modal_queries.
_BASELINE_SWITCH: dict[str, tuple[bool, bool]] = {
    "independent": (False, False),   # shared=False, use_cache=False
    "shared_batched": (True, False),
    "winner_lru": (False, True),
    "shared_batched_lru": (True, True),
}

SCORER_ID = "toy-degree-lexical-original-float"
CODE_ID = "icde_baseline_suite-v1"


# ---------------------------------------------------------------------------
# Context construction
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class BaselineContext:
    """Everything a baseline run needs: snapshot, stream, scorer, probabilities."""

    dataset_dir: str
    snapshot: ModalSnapshot
    stream: IIDWorldStream
    scorer: ModalScorer
    backbone: ToyStructuralBackbone
    probabilities: tuple[float, ...]
    n_worlds: int
    seed: int
    scorer_id: str


def build_context(
    dataset_dir: str | Path,
    *,
    seed: int,
    n_worlds: int,
    model_id: str = "no-trained-model",
    probability_id: str | None = None,
    factors_id: str = "independent",
    schema_id: str = "canonical-v1",
    factor_law: FactorLaw | None = None,
) -> BaselineContext:
    """Load a dataset, build the snapshot identity and a fresh iid stream.

    The scorer is the interpretable structural backbone
    (``ToyStructuralBackbone``): lexical label similarity blended with a
    world-sensitive in/out-degree structural term. It is exact/float, not a
    learned GCN, so it is the local oracle-capable scorer. The learned GCN
    scorer is *not* available locally (no torch/GPU) and is left pending.

    When ``factor_law`` is ``None`` (default) the v1 independent product law is
    used and every identity/digest is byte-identical to the frozen traces. When
    a :class:`FactorLaw` is supplied the worlds are actually sampled under the
    shared-factor (common-shock) law, the ``factors`` snapshot field is set to
    the law's canonical identity, and the stream digest binds the law.
    """

    dataset = Path(dataset_dir).resolve()
    backbone = ToyStructuralBackbone.from_dataset(dataset)
    probabilities = tuple(float(row["confidence"]) for row in backbone.triples)
    prob_digest = identity(list(probabilities)) if probability_id is None else probability_id
    graph_digest = dataset_content_digest(dataset)
    if factor_law is None:
        # v1 path: independent product law, byte-identical identities/digests.
        snapshot = ModalSnapshot(
            graph_digest, model_id, prob_digest, factors_id, schema_id, CODE_ID, SCORER_ID,
        )
        worlds = tuple(monte_carlo_worlds(probabilities, n_worlds, seed))
        stream = IIDWorldStream(snapshot.digest, seed, worlds)
    else:
        if factor_law.n_edges != len(probabilities):
            raise ValueError("factor_law edge count must match the graph triple count")
        worlds = tuple(factor_law.build_worlds(probabilities, n_worlds, seed))
        snapshot = ModalSnapshot(
            graph_digest, model_id, prob_digest, factor_law.identity(),
            schema_id, CODE_ID, SCORER_ID,
        )
        stream = IIDWorldStream(snapshot.digest, seed, worlds, factor_law.stream_config())
    scorer = ModalScorer(snapshot.digest, backbone.score_subset)
    return BaselineContext(
        dataset_dir=str(dataset),
        snapshot=snapshot,
        stream=stream,
        scorer=scorer,
        backbone=backbone,
        probabilities=probabilities,
        n_worlds=n_worlds,
        seed=seed,
        scorer_id=SCORER_ID,
    )


def make_queries(
    context: BaselineContext,
    sources: Sequence[str],
    candidates: Sequence[tuple[str, ...]],
    *,
    budget: int,
    delta: float = DEFAULT_DELTA,
) -> list[ModalQuery]:
    """Build ModalQuery objects bound to the context snapshot."""

    if len(sources) != len(candidates):
        raise ValueError("sources and candidates must align")
    return [
        ModalQuery(s, tuple(c), context.snapshot.digest, budget, delta)
        for s, c in zip(sources, candidates, strict=True)
    ]


# ---------------------------------------------------------------------------
# Per-query result extraction + work ledger
# ---------------------------------------------------------------------------
def query_fingerprint(result: dict[str, Any]) -> dict[str, Any]:
    """The item-for-item comparable view of one query result.

    Only exact identity/count fields: winner, status, certified winner, samples,
    counts and evidence digest. Bounds are included for audit but the
    cross-baseline equality check keys on the identity fields.
    """

    return {
        "query_id": result.get("query_id"),
        "status": result.get("status"),
        "estimated_winner": result.get("estimated_winner"),
        "certified_winner": result.get("certified_winner"),
        "samples_used": result.get("samples_used"),
        "counts": result.get("counts"),
        "evidence_digest": result.get("evidence_digest"),
    }


@dataclass
class BaselineRun:
    name: str
    shared: bool
    used_cache: bool
    capacity_bytes: int
    results: list[dict[str, Any]]
    work: dict[str, Any]
    wall_seconds_informal: float = 0.0
    notes: list[str] = field(default_factory=list)

    def fingerprints(self) -> list[dict[str, Any]]:
        return [query_fingerprint(r) for r in self.results]


def _ledger_from_work(
    work: dict[str, Any],
    cache: WinnerBlockCache | None,
    wall: float,
) -> dict[str, Any]:
    return {
        "scorer_calls": work["scorer_calls"],
        "candidate_evaluations": work["candidate_evaluations"],
        "new_winner_labels": work["computed_winner_labels"],
        "cache_label_reads": work["cache_label_reads"],
        # cache_label_writes: labels actually admitted into the cache. When no
        # cache is configured every block is transient, so this is 0.
        "cache_label_writes": work["computed_winner_labels"] if cache is not None else 0,
        "evictions": cache.evictions if cache is not None else 0,
        "peak_payload_bytes": cache.peak_payload_bytes if cache is not None else 0,
        "ahead_worlds": work["ahead_worlds"],
        "query_world_observations": work["query_world_observations"],
        "wall_seconds_informal": wall,
    }


def run_baseline(
    name: str,
    queries: Sequence[ModalQuery],
    context: BaselineContext,
    *,
    lru_capacity_bytes: int = 0,
    batch_size: int = DEFAULT_BATCH_SIZE,
    minimum_samples: int = DEFAULT_MINIMUM_SAMPLES,
    wall_clock: bool = True,
) -> BaselineRun:
    """Run one named baseline over ``queries`` against ``context``.

    ``lru_capacity_bytes`` is label payload bytes only. A 0 capacity means no
    LRU. A baseline whose ``used_cache`` flag is false ignores the cache.
    """

    if name not in _BASELINE_SWITCH:
        raise ValueError(f"unknown baseline {name!r}; choose from {BASELINES}")
    shared, uses_cache = _BASELINE_SWITCH[name]
    cache = WinnerBlockCache(lru_capacity_bytes) if uses_cache else None

    start = time.perf_counter() if wall_clock else None
    out = execute_modal_queries(
        list(queries),
        context.snapshot,
        context.stream,
        context.scorer,
        cache=cache,
        shared=shared,
        batch_size=batch_size,
        minimum_samples=minimum_samples,
    )
    wall = (time.perf_counter() - start) if start is not None else 0.0

    run = BaselineRun(
        name=name,
        shared=shared,
        used_cache=uses_cache,
        capacity_bytes=lru_capacity_bytes if uses_cache else 0,
        results=list(out["results"]),
        work=_ledger_from_work(out["work"], cache, wall),
    )
    return run


def run_all_baselines(
    queries: Sequence[ModalQuery],
    context: BaselineContext,
    *,
    lru_capacity_bytes: int = 4096,
    batch_size: int = DEFAULT_BATCH_SIZE,
    minimum_samples: int = DEFAULT_MINIMUM_SAMPLES,
) -> dict[str, BaselineRun]:
    """Run every baseline and assert exact winner/status equality across them.

    Raises AssertionError if the four paths disagree on any query. Returns a
    dict name -> BaselineRun.
    """

    runs = {
        name: run_baseline(
            name,
            queries,
            context,
            lru_capacity_bytes=lru_capacity_bytes,
            batch_size=batch_size,
            minimum_samples=minimum_samples,
        )
        for name in BASELINES
    }
    reference = runs["independent"].fingerprints()
    for name, run in runs.items():
        fps = run.fingerprints()
        if fps != reference:
            raise AssertionError(
                f"baseline {name!r} disagrees with 'independent' on item-for-item "
                f"winner/status/count/evidence equality; this is a bug."
            )
    return runs


# ---------------------------------------------------------------------------
# Trace reading (icde_traces_20261009 layout, for E3/E5/P1 consumption)
# ---------------------------------------------------------------------------
def iter_trace_events(trace_path: str | Path) -> list[dict[str, Any]]:
    """Read a ``trace.jsonl`` file (trace_schema_v1 event records)."""

    path = Path(trace_path)
    events: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                events.append(json.loads(line))
    return events


def validate_trace_events(events: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Enforce the trace_schema_v1 mandatory fields + event_id dedup."""

    required = {"trace_id", "event_id", "sequence", "kind", "arrival_ns"}
    seen: set[Any] = set()
    out: list[dict[str, Any]] = []
    for ev in events:
        missing = required - set(ev)
        if missing:
            raise ValueError(f"event missing mandatory fields {missing}: {ev}")
        if ev["event_id"] in seen:
            raise ValueError(f"duplicate event_id {ev['event_id']!r}")
        seen.add(ev["event_id"])
        out.append(ev)
    return out


def context_to_json(context: BaselineContext) -> dict[str, Any]:
    return {
        "dataset_dir": context.dataset_dir,
        "snapshot": asdict(context.snapshot),
        "snapshot_digest": context.snapshot.digest,
        "stream_digest": context.stream.digest,
        "n_worlds": context.n_worlds,
        "seed": context.seed,
        "probabilities": list(context.probabilities),
        "scorer_id": context.scorer_id,
        "source_entities": list(context.backbone.source_entities),
        "target_entities": list(context.backbone.target_entities),
    }


def host_info() -> dict[str, Any]:
    return {
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "informal_note": "wall-clock on this host is informal; parallel load possible",
    }


# ---------------------------------------------------------------------------
# CLI smoke: run all four baselines on the toy dataset
# ---------------------------------------------------------------------------
def _self_test() -> dict[str, Any]:
    dataset = REPO_ROOT / "data" / "toy" / "exact_world_minimal"
    context = build_context(dataset, seed=17, n_worlds=128)
    queries = make_queries(
        context,
        context.backbone.source_entities,
        [context.backbone.target_entities] * len(context.backbone.source_entities),
        budget=128,
    )
    runs = run_all_baselines(queries, context, lru_capacity_bytes=4096)
    return {
        "context": context_to_json(context),
        "baselines": {
            name: {
                "work": run.work,
                "n_queries": len(run.results),
                "all_stable": all(r["stable"] for r in run.results),
            }
            for name, run in runs.items()
        },
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ICDE strong-baseline suite")
    parser.add_argument("--dataset", type=Path, default=None,
                        help="dataset dir (default: toy exact_world_minimal)")
    parser.add_argument("--seed", type=int, default=17)
    parser.add_argument("--n-worlds", type=int, default=128)
    parser.add_argument("--budget", type=int, default=128)
    parser.add_argument("--lru-bytes", type=int, default=4096)
    parser.add_argument("--out", type=Path, default=None,
                        help="write a JSON self-test summary here")
    args = parser.parse_args(argv)

    dataset = args.dataset or (REPO_ROOT / "data" / "toy" / "exact_world_minimal")
    context = build_context(dataset, seed=args.seed, n_worlds=args.n_worlds)
    queries = make_queries(
        context,
        context.backbone.source_entities,
        [context.backbone.target_entities] * len(context.backbone.source_entities),
        budget=min(args.budget, args.n_worlds),
    )
    runs = run_all_baselines(queries, context, lru_capacity_bytes=args.lru_bytes)
    summary = {
        "format": "icde-baseline-suite-selftest-v1",
        "host": host_info(),
        "context": context_to_json(context),
        "checkpoint": {"batch_size": DEFAULT_BATCH_SIZE,
                       "minimum_samples": DEFAULT_MINIMUM_SAMPLES,
                       "tie": "original-precision-lexical-tie-v1"},
        "baselines": {
            name: {"work": run.work,
                   "results_equal_to_independent": True}
            for name, run in runs.items()
        },
    }
    text = json.dumps(summary, indent=2, ensure_ascii=False)
    if args.out:
        args.out.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
