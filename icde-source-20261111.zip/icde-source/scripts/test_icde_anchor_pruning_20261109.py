from itertools import product
import unittest
import numpy as np
from test_icde_sparse_block_events_20261108 import SparseBlockTest
from icde_pruned_block_comparison_20261109 import prune
from icde_sparse_degree_20261108 import restrict


class PruningTest(unittest.TestCase):
    def test_world_winners_are_preserved_after_universal_pruning(self):
        kernel=SparseBlockTest().make()
        focus,selected=prune(kernel)
        sub,mapping=restrict(kernel,selected)
        worlds=np.asarray(list(product((False,True),repeat=5)))
        original=np.argmax(kernel.scores(worlds),axis=1)
        local=worlds[:,list(sub.edge_indices)]
        reduced=np.asarray([mapping[c] for c in np.argmax(sub.scores(local),axis=1)])
        np.testing.assert_array_equal(original,reduced)
        self.assertIn(focus,selected)


if __name__=='__main__':unittest.main()
