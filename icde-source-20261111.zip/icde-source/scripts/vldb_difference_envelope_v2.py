"""Precompiled signed-incidence interval baseline for the fixed degree scorer.

Source/candidate incidence shared by a directed degree difference cancels
exactly before interval evaluation.  This is a standard dependency-preserving
interval baseline, not a claim of a new algorithm.  With disjoint source and
target edge supports its interval precision equals V1; compiling once only
removes repeated structural validation from the execution path.

V0/V1 are imported read-only.  The original float64 score operation order,
candidate order and first-column tie mapping are retained.  All h indicators
and fixed-N statistical contracts have the same meaning as V1.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

import vldb_interval_envelope_v1 as v1


SCHEMA = "vldb-precompiled-signed-incidence-envelope-v2"


def _readonly(array: np.ndarray, dtype=None) -> np.ndarray:
    snapshot = np.array(array, dtype=dtype, copy=True)
    snapshot.setflags(write=False)
    return snapshot


@dataclass(frozen=True)
class CompiledDifferenceKernel:
    """Validated immutable snapshots; no np.unique occurs in chunk methods."""

    source: Any
    candidates: tuple
    edge_indices: tuple
    incidence_positions: tuple[np.ndarray, ...]
    attribute: np.ndarray
    lexical: np.ndarray
    attribute_weight: float
    positive_positions: tuple[np.ndarray, ...]
    negative_positions: tuple[np.ndarray, ...]
    shared_coordinate_cancellations: int

    @property
    def compilation_summary(self) -> dict:
        original_entries = sum(len(p) for p in self.incidence_positions)
        signed_entries = sum(len(p) for p in self.positive_positions + self.negative_positions)
        return {
            "schema": SCHEMA,
            "scope_edges": len(self.edge_indices),
            "candidate_count": len(self.candidates),
            "original_incidence_entries": original_entries,
            "signed_difference_entries": signed_entries,
            "interval_incidence_entries": original_entries if self.shared_coordinate_cancellations == 0 else signed_entries,
            "interval_evaluation": "shared_source_degree_fastpath" if self.shared_coordinate_cancellations == 0 else "signed_difference_with_exact_cancellation",
            "shared_coordinate_cancellations": self.shared_coordinate_cancellations,
            "structural_validation": "performed_once_before_readonly_snapshot",
            "precision_boundary": "equals V1 for disjoint source/candidate directed supports",
            "algorithm_role": "standard_strong_interval_baseline_not_new_algorithm",
        }

    def _state_bounds(self, low_states, high_states):
        low_states = v1._states(low_states, "low_states", len(self.edge_indices))
        high_states = v1._states(high_states, "high_states", len(self.edge_indices))
        if low_states.shape != high_states.shape or np.any(low_states & ~high_states):
            raise ValueError("state intervals must have equal shapes and low<=high")
        return low_states, high_states

    def scores(self, states: np.ndarray) -> np.ndarray:
        """The frozen original nominal mapping, including exact degree sums."""
        states = v1._states(states, "states", len(self.edge_indices))
        degrees = np.empty((len(states), len(self.incidence_positions)), dtype=np.float64)
        for column, positions in enumerate(self.incidence_positions):
            degrees[:, column] = np.sum(states[:, positions], axis=1, dtype=np.float64)
        distance = (np.abs(degrees[:, 0, None] - degrees[:, 2::2])
                    + np.abs(degrees[:, 1, None] - degrees[:, 3::2]))
        dynamic = 1.0 / (1.0 + distance)
        structural = 0.6 * self.lexical[None, :] + 0.4 * dynamic
        result = self.attribute_weight * self.attribute[None, :] + (1.0 - self.attribute_weight) * structural
        if not np.isfinite(result).all():
            raise ValueError("nonfinite original nominal score")
        return result

    def degree_intervals(self, low_states: np.ndarray, high_states: np.ndarray):
        """Reusable exact integer source/target degree boxes; no conditioning.

        Columns are source out/in, then each candidate out/in.  This API alone
        does not implement a shared-source-conditioned comparison algorithm.
        """
        low_states, high_states = self._state_bounds(low_states, high_states)
        lower = np.empty((len(low_states), len(self.incidence_positions)), dtype=np.int64)
        upper = np.empty_like(lower)
        for column, positions in enumerate(self.incidence_positions):
            lower[:, column] = np.sum(low_states[:, positions], axis=1, dtype=np.int64)
            upper[:, column] = np.sum(high_states[:, positions], axis=1, dtype=np.int64)
        return lower, upper

    def difference_intervals(self, low_states: np.ndarray, high_states: np.ndarray):
        """Exact integer ranges of each signed linear degree difference.

        Output axes: (world row, out/in direction, candidate).  Each coordinate
        range is exact on the partial Boolean cube.  Different ranges may be
        mutually dependent, so their later L1 combination is an enclosure.
        """
        low_states, high_states = self._state_bounds(low_states, high_states)
        k = len(self.candidates)
        lower = np.empty((len(low_states), 2, k), dtype=np.int64)
        upper = np.empty_like(lower)
        for column, (positive, negative) in enumerate(zip(self.positive_positions, self.negative_positions)):
            direction, candidate = divmod(column, k)
            lower[:, direction, candidate] = (
                np.sum(low_states[:, positive], axis=1, dtype=np.int64)
                - np.sum(high_states[:, negative], axis=1, dtype=np.int64)
            )
            upper[:, direction, candidate] = (
                np.sum(high_states[:, positive], axis=1, dtype=np.int64)
                - np.sum(low_states[:, negative], axis=1, dtype=np.int64)
            )
        return lower, upper

    def score_bounds_from_distances(self, minimum: np.ndarray, maximum: np.ndarray):
        """V1-identical outward score operations for integer L1 enclosures."""
        if (not isinstance(minimum, np.ndarray) or not isinstance(maximum, np.ndarray)
                or minimum.ndim != 2 or minimum.shape != maximum.shape
                or minimum.shape[1] != len(self.candidates)
                or minimum.dtype.kind not in "iu" or maximum.dtype.kind not in "iu"):
            raise ValueError("distance bounds must be equal-shaped integer (n,k) arrays")
        if np.any(minimum < 0) or np.any(minimum > maximum) or np.any(maximum >= 2 ** 52):
            raise ValueError("invalid integer distance range")
        denominator = v1._add((np.float64(1), np.float64(1)),
                              (minimum.astype(np.float64), maximum.astype(np.float64)))
        if np.any(denominator[0] <= 0):
            raise AssertionError("positive structural denominator contract failed")
        dynamic = (v1._down(np.divide(np.float64(1), denominator[1])),
                   v1._up(np.divide(np.float64(1), denominator[0])))
        lexical_term = v1._multiply_nonnegative((np.float64(.6), np.float64(.6)),
                                               (self.lexical[None, :], self.lexical[None, :]))
        dynamic_term = v1._multiply_nonnegative((np.float64(.4), np.float64(.4)), dynamic)
        structural = v1._add(lexical_term, dynamic_term)
        weight = np.float64(self.attribute_weight)
        complement = (v1._down(np.subtract(np.float64(1), weight)),
                      v1._up(np.subtract(np.float64(1), weight)))
        attribute_term = v1._multiply_nonnegative((weight, weight),
                                                 (self.attribute[None, :], self.attribute[None, :]))
        lower, upper = v1._add(attribute_term, v1._multiply_nonnegative(complement, structural))
        lower, upper = np.broadcast_arrays(lower, upper)
        if not np.isfinite(lower).all() or not np.isfinite(upper).all():
            raise ValueError("nonfinite outward score interval")
        return lower.copy(), upper.copy()

    def score_intervals(self, low_states: np.ndarray, high_states: np.ndarray):
        if self.shared_coordinate_cancellations == 0:
            # Repeating source incidence once per candidate adds no precision
            # with disjoint supports.  Read each degree once, exactly as V1.
            low_degrees, high_degrees = self.degree_intervals(low_states, high_states)
            distance_min, distance_max = v1._l1_degree_intervals(low_degrees, high_degrees)
            return self.score_bounds_from_distances(distance_min, distance_max)
        lower, upper = self.difference_intervals(low_states, high_states)
        abs_min = np.where((lower <= 0) & (upper >= 0), 0, np.minimum(np.abs(lower), np.abs(upper)))
        abs_max = np.maximum(np.abs(lower), np.abs(upper))
        distance_min = np.sum(abs_min, axis=1, dtype=np.int64)
        distance_max = np.sum(abs_max, axis=1, dtype=np.int64)
        return self.score_bounds_from_distances(distance_min, distance_max)

    # Preserve the spelling proposed in the task as well as the V1 spelling.
    scores_intervals = score_intervals

    def ambiguity_indicators(self, q: np.ndarray, low: np.ndarray, high: np.ndarray,
                             uniforms: np.ndarray, nominal_scores: np.ndarray | None = None):
        q, low, high = (v1._float64_array(value, name, 1)
                        for value, name in ((q, "q"), (low, "low"), (high, "high")))
        uniforms = v1._float64_array(uniforms, "uniforms", 2)
        m, k, n = len(self.edge_indices), len(self.candidates), len(uniforms)
        if q.shape != (m,) or low.shape != q.shape or high.shape != q.shape or uniforms.shape[1] != m:
            raise ValueError("probability/uniform shapes differ from the frozen edge order")
        if np.any(low < 0) or np.any(high > 1) or np.any(low > q) or np.any(q > high):
            raise ValueError("declared box must lie in [0,1] and contain q")
        if np.any(uniforms < 0) or np.any(uniforms >= 1):
            raise ValueError("uniform draws must lie in [0,1)")
        if nominal_scores is not None:
            nominal_scores = v1._float64_array(nominal_scores, "nominal_scores", 2)
            if nominal_scores.shape != (n, k):
                raise ValueError("optional nominal_scores must have full (n,k) shape")
        result = np.zeros(n, dtype=np.bool_)
        if k == 1:
            return result
        low_states, high_states = uniforms < low[None, :], uniforms < high[None, :]
        free = np.any(low_states != high_states, axis=1)
        if not np.any(free):
            return result
        scores = (self.scores(uniforms[free] < q[None, :])
                  if nominal_scores is None else nominal_scores[free])
        winners = np.argmax(scores, axis=1)
        lower_scores, upper_scores = self.score_intervals(low_states[free], high_states[free])
        rows = np.arange(len(winners))
        winner_lower = lower_scores[rows, winners]
        competitor_upper = upper_scores.copy()
        competitor_upper[rows, winners] = -np.inf
        result[free] = ~(winner_lower > np.max(competitor_upper, axis=1))
        return result


def compile_difference_kernel(kernel) -> CompiledDifferenceKernel:
    """Validate once, cancel signed incidents, and copy immutable snapshots."""
    attribute, lexical, weight, incidence, _, k = v1._kernel_inputs(kernel)
    incidence = tuple(_readonly(array, np.intp) for array in incidence)
    positive, negative = [], []
    cancelled = 0
    # Flatten differences in (out candidates..., in candidates...) order.
    for direction in range(2):
        source = incidence[direction]
        for candidate in range(k):
            target = incidence[2 + 2 * candidate + direction]
            shared = np.intersect1d(source, target, assume_unique=True)
            cancelled += len(shared)
            positive.append(_readonly(np.setdiff1d(source, target, assume_unique=True), np.intp))
            negative.append(_readonly(np.setdiff1d(target, source, assume_unique=True), np.intp))
    return CompiledDifferenceKernel(
        getattr(kernel, "source", None), tuple(kernel.candidates), tuple(kernel.edge_indices),
        incidence, _readonly(attribute, np.float64), _readonly(lexical, np.float64), float(weight),
        tuple(positive), tuple(negative), cancelled,
    )


# Reuse the already tested fixed-N statistical baseline, not a new theorem.
confidence_upper = v1.confidence_upper
