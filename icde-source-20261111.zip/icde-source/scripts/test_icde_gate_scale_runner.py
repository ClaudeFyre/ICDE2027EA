"""Contract tests only: no scorer imports, training or world generation."""
from contextlib import contextmanager
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import icde_gate_scale_runner as runner


class ShardContractTests(unittest.TestCase):
    def test_eight_shards_cover_original_order_without_overlap(self):
        pool = [f"source-{index}" for index in range(500)]
        ordered, _ = runner.select_shard(pool, 0, 64)
        pieces = [runner.select_shard(list(reversed(pool)), shard, 64)[1] for shard in range(8)]
        self.assertEqual(tuple(item for piece in pieces for item in piece), ordered)
        self.assertEqual([len(piece) for piece in pieces], [64] * 7 + [52])
        self.assertEqual(len(set(item for piece in pieces for item in piece)), 500)

    def test_changed_universe_salt_and_out_of_range_shard_rejected(self):
        pool = [str(index) for index in range(500)]
        for values, shard, size, salt in ((pool[:-1], 0, 64, runner.SALT),
                (pool[:-1] + [pool[0]], 0, 64, runner.SALT), (pool, 8, 64, runner.SALT),
                (pool, 0, 0, runner.SALT), (pool, 0, 64, "different")):
            with self.assertRaises(ValueError):
                runner.select_shard(values, shard, size, salt)

    def test_selection_binding_restored_even_after_setup_failure(self):
        pool = [str(index) for index in range(500)]
        ordered, selected = runner.select_shard(pool, 2, 64)
        def original(values, count, salt):
            return runner.select_shard(values, 0, 500, salt)[0][:count]
        engine = SimpleNamespace(select_queries=original)
        with self.assertRaises(RuntimeError):
            with runner.selected_query_setup(engine, ordered, selected):
                self.assertEqual(engine.select_queries(pool, 64, runner.SALT), selected)
                raise RuntimeError("simulated setup interruption")
        self.assertIs(engine.select_queries, original)

    def test_source_slice_adapter_rejects_new_pool(self):
        pool = [str(index) for index in range(500)]
        ordered, selected = runner.select_shard(pool, 0, 64)
        engine = SimpleNamespace(select_queries=lambda values, count, salt:
            runner.select_shard(values, 0, 500, salt)[0][:count])
        with runner.selected_query_setup(engine, ordered, selected):
            with self.assertRaises(ValueError):
                engine.select_queries(pool[:-1] + ["new-source"], 64, runner.SALT)


class DurableCaseTests(unittest.TestCase):
    def make_row(self):
        return {"graph": "D-W", "query_id": "source", "dataset_revision": "revision",
                "seed": 61, "method": "scope_full_risk", "candidate_count": 2,
                "scope_edge_count": 3, "samples_used": 32, "winner_counts": [30, 2],
                "worlds_generated": 32, "nominal_score_rows": 32,
                "random_uniform_draws": 96, "event_extra_random_draws": 0,
                "event_rows_computed": 0, "event_samples_used": 0,
                "event_count": 0, "event_free_rows": 0,
                "work_used": 100., "work_budget": 100., "work_overshoot": 0.,
                "seconds": {"query_serving_total": .1}}

    def expected(self, row):
        return {key: row[key] for key in ("graph", "query_id", "dataset_revision", "seed",
                                         "method", "candidate_count", "scope_edge_count")}

    def test_complete_atomic_case_survives_missing_checkpoint_and_is_adoptable(self):
        row = self.make_row()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "case.json"
            runner.atomic_json(path, {"status": "COMPLETE", "manifest_sha256": "manifest",
                "query_identity_sha256": "identity", "row": row}, new_only=True)
            loaded = runner.load_verified_case(path, "manifest", "identity", self.expected(row))
            self.assertEqual(loaded["row"], row)
            with self.assertRaises(FileExistsError):
                runner.atomic_json(path, {}, new_only=True)

    def test_resume_rejects_changed_bytes_or_contract(self):
        row = self.make_row()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "case.json"
            runner.atomic_json(path, {"status": "COMPLETE", "manifest_sha256": "manifest",
                "query_identity_sha256": "identity", "row": row})
            digest = runner.file_sha(path)
            with self.assertRaises(ValueError):
                runner.load_verified_case(path, "new-manifest", "identity", self.expected(row), digest)
            with self.assertRaises(ValueError):
                runner.load_verified_case(path, "manifest", "new-query", self.expected(row), digest)
            path.write_text(path.read_text("utf-8") + " ", encoding="utf-8")
            with self.assertRaises(ValueError):
                runner.load_verified_case(path, "manifest", "identity", self.expected(row), digest)

    def test_incomplete_evidence_or_budget_overshoot_is_not_completed_case(self):
        for changed in ({"winner_counts": [29, 2]}, {"random_uniform_draws": 95},
                        {"event_rows_computed": 1}, {"work_used": 101.},
                        {"seconds": {"query_serving_total": -1.}}):
            row = self.make_row()
            row.update(changed)
            with self.assertRaises(ValueError):
                runner.validate_result(row, self.expected(row))

    def test_case_identity_does_not_depend_on_dict_order(self):
        self.assertEqual(runner.canonical_digest({"a": 1, "b": [2, 3]}),
                         runner.canonical_digest({"b": [2, 3], "a": 1}))
        self.assertNotEqual(runner.case_key("D-W", 64, 61, "scope_full_risk"),
                            runner.case_key("EN-FR", 64, 61, "scope_full_risk"))

    def test_rebuilt_query_contract_ignores_timing_but_not_candidates(self):
        metadata = {"candidate_ids": ["a", "b"], "candidate_tie_order": "fixed",
            "candidate_audit": {"status": "PASS", "seconds": .1},
            "scope_certificate": {"dataset_revision": "revision", "exact": True},
            "scope_edge_indices": [1, 2, 3], "scope_edge_count": 3, "candidate_count": 2,
            "cost_model": {"scope_edges": 3}, "box_audit": {"q_sha256": "q"},
            "setup_seconds": {"total": .2}}
        query = SimpleNamespace(graph="D-W", query_id="source", dataset_revision="revision",
                                scope_epsilon=.001, metadata=metadata)
        before = runner.canonical_digest(runner.query_identity(query))
        metadata["candidate_audit"]["seconds"] = 9.
        metadata["setup_seconds"]["total"] = 10.
        self.assertEqual(runner.canonical_digest(runner.query_identity(query)), before)
        metadata["candidate_ids"] = ["a", "new-candidate"]
        self.assertNotEqual(runner.canonical_digest(runner.query_identity(query)), before)


if __name__ == "__main__":
    unittest.main()
