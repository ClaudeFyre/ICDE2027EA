"""Durable online comparisons of nominal and robust categorical inference.

Each policy generates its own paired prefix online and stops at its requested
objective. No inference function is monkey-patched. Complete-prefix event
evidence is purchased before computation. Completed case JSONs are atomically
published independently of the final summary, so interruption preserves cases.
"""

from __future__ import annotations

import time
MODULE_STARTED = time.perf_counter()
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys

import numpy as np

from icde_online_execution import (
    ROOT, PreparedQuery, _segments, settings_from_config, setup_graph,
)
import icde_gate_inference as inference
import vldb_event_bound_v2 as event_bounds
from vldb_capture_attribute_v0 import CANONICAL_FILES, file_sha256, stream_seed
from run_vldb_interval_gate_v1 import _inside
from pkgea.contracts import dataset_revision_digest


POLICIES = ("normal_nominal", "ppr_nominal", "eb_nominal", "normal_scope",
            "normal_event", "eb_scope", "eb_event")
SCHEMA = "icde-online-inference-controls-v1"
PURPOSE = "icde-gate-controls-v1"


def prepare_settings(config, query_count=None):
    resolved = {"query_count": 16, "seeds": [97, 109, 127],
                "seed_purpose": PURPOSE, "policies": list(POLICIES), **config}
    if query_count is not None:
        resolved["query_count"] = query_count
    settings = settings_from_config(resolved)
    if settings["query_count"] not in (16, 32):
        raise ValueError("the bounded control protocol supports 16 or 32 sources per graph")
    if (not settings["policies"] or len(set(settings["policies"])) != len(settings["policies"])
            or any(policy not in POLICIES for policy in settings["policies"])):
        raise ValueError("invalid comparison policies")
    if not isinstance(settings["seed_purpose"], str) or not settings["seed_purpose"]:
        raise ValueError("seed_purpose must be an explicit nonempty string")
    return settings


def actual_checkpoints(settings):
    """The EB union protects every time the online loop can inspect a gap."""
    cap = settings["sample_count"]
    nominal = settings["nominal"]
    checks = set(range(nominal["minimum_samples"], cap + 1, nominal["check_every"]))
    checks.update((cap, int(cap * settings["budget_fraction"])))
    checks.update(value for value in settings["risk_plan"]["event_checkpoints"] if value <= cap)
    return tuple(sorted(value for value in checks if 0 < value <= cap))


def write_json(path, value, *, replace=False):
    """Flush and atomically publish one file inside a fresh attempt directory."""
    path = Path(path)
    if path.exists() and not replace:
        raise FileExistsError("refusing to replace an existing result")
    pending = path.with_name(path.name + ".pending")
    started = time.perf_counter()
    with pending.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(pending, path)
    return time.perf_counter() - started


def run_case(query: PreparedQuery, settings, policy, base_seed,
             *, clock=time.perf_counter, rng_factory=np.random.default_rng):
    """Evaluate exactly one declared objective from a fresh paired stream."""
    if policy not in POLICIES:
        raise ValueError("unknown inference-control policy")
    started = clock()
    times = {name: 0. for name in ("rng", "scoring", "event", "inference", "policy", "hashing")}
    nominal_objective = policy.endswith("_nominal")
    event_policy = policy.endswith("_event")
    ppr = policy == "ppr_nominal"
    eb = policy.startswith("eb_")
    objective = "nominal" if nominal_objective else "robust"
    delta = settings["delta_nominal"] if event_policy else settings["delta_total"]
    checks = actual_checkpoints(settings)
    eb_checks = tuple(value for value in checks if value >= 2)
    rule = ({"name": "empirical_bernstein", "checkpoints": eb_checks}
            if eb else {"name": "normal_mixture", "rho": settings["nominal"]["rho"]})
    protected = settings["risk_plan"]["event_checkpoints"]
    event_alpha = settings["risk_plan"]["alpha_per_checkpoint"]
    kernel, q = query.kernel, query.q
    k, m = len(kernel.candidates), len(q)
    if k < 1 or m != len(kernel.edge_indices):
        raise ValueError("invalid prepared query")
    model = query.metadata["cost_model"]
    incidence = model["original_incidence_entries"]
    interval_incidence = model["interval_incidence_entries"]
    units = settings["work_model"]
    nominal_unit = max(1, m + incidence + units["nominal_candidate_units"] * k)
    equivalent = int(settings["sample_count"] * settings["budget_fraction"])
    budget = (equivalent + 1) * nominal_unit
    work = float(nominal_unit)
    event_unit_upper = 2 * m + 2 * interval_incidence + units["interval_candidate_units"] * k
    weight = settings["interval_work_weight"]
    seed = stream_seed(query.graph, query.dataset_revision, query.query_id,
                       base_seed, settings["seed_purpose"])
    before = clock()
    rng = rng_factory(seed)
    times["rng"] += clock() - before
    counts = np.zeros(k, dtype=np.int64)
    n = event_n = event_count = event_free_rows = score_calls = event_calls = rejected = 0
    observed_winners, blocks, trace = [], [], []
    uniforms_hash, winners_hash = hashlib.sha256(), hashlib.sha256()
    event_upper = 1.
    gap = None
    ppr_test = None
    leader = 0
    certified = False
    nominal_candidate = None
    nominal_n = None
    nominal_seconds = None
    status = "world_cap"
    deadline = settings["deadline_seconds"]

    def elapsed():
        return clock() - started

    def expired():
        return deadline is not None and elapsed() > deadline

    if k == 1:
        certified = not expired()
        nominal_candidate, nominal_n = (0, 0) if certified else (None, None)
        nominal_seconds = elapsed() if certified else None
        status = "structurally_single_candidate" if certified else "deadline_postblock"
    else:
        for next_n in checks:
            if expired():
                status = "deadline_before_block"
                break
            charge = (next_n - n) * nominal_unit
            if work + charge > budget:
                status = "nominal_work_budget"
                break
            before = clock()
            uniforms = rng.random((next_n - n, m), dtype=np.float64)
            states = uniforms < q[None, :]
            times["rng"] += clock() - before
            before = clock()
            scores = kernel.scores(states)
            if scores.shape != (len(uniforms), k) or not np.isfinite(scores).all():
                raise ValueError("invalid nominal score mapping")
            winners = np.argmax(scores, axis=1)
            counts += np.bincount(winners, minlength=k)
            observed_winners.extend(int(value) for value in winners)
            score_calls += 1
            times["scoring"] += clock() - before
            if event_policy:
                blocks.append((n, uniforms, scores))
            n, work = next_n, work + charge
            before = clock()
            uniforms_hash.update(uniforms.tobytes(order="C"))
            winners_hash.update(winners.astype(np.int64, copy=False).tobytes(order="C"))
            times["hashing"] += clock() - before
            if expired():
                status = "deadline_postblock"
                trace.append({"nominal_samples": n, "event_samples": event_n,
                              "elapsed_seconds": elapsed(), "work_used": work, "status": status,
                              "uniform_prefix_sha256": uniforms_hash.hexdigest(),
                              "winner_prefix_sha256": winners_hash.hexdigest()})
                break
            before = clock()
            leader = int(np.argmax(counts))
            if ppr:
                ppr_test = inference.ppr_details(counts, n, delta, prior="uniform", allocation="jain_mode")
                nominal_now = ppr_test["certified"]
            else:
                gap = inference.numerical_gap_bound(counts, n, delta, rule)
                nominal_now = gap > 0
            times["inference"] += clock() - before
            if nominal_now and nominal_candidate is None and not expired():
                nominal_candidate, nominal_n, nominal_seconds = leader, n, elapsed()
            could_certify = nominal_now if nominal_objective else gap > 2 * min(query.scope_epsilon, event_upper)
            selected = None
            admission = "not_requested"
            static_fee = actual_fee = 0.
            if not could_certify and event_policy and not expired():
                before = clock()
                eligible = [value for value in protected if event_n < value <= n]
                if eligible:
                    selected = eligible[0]
                    static_fee = (selected - event_n) * event_unit_upper * weight
                    if work + static_fee > budget:
                        admission = "rejected_budget"
                        rejected += 1
                    else:
                        admission = "approved"
                times["policy"] += clock() - before
                if admission == "approved":
                    before = clock()
                    additions = free_rows = 0
                    for past_uniforms, past_scores in _segments(blocks, event_n, selected):
                        flags = kernel.ambiguity_indicators(
                            q, query.low, query.high, past_uniforms, nominal_scores=past_scores)
                        if flags.dtype != np.bool_ or flags.shape != (len(past_uniforms),):
                            raise ValueError("invalid event indicator")
                        free = np.any((past_uniforms < query.low[None, :])
                                      != (past_uniforms < query.high[None, :]), axis=1)
                        additions += int(np.count_nonzero(flags))
                        free_rows += int(np.count_nonzero(free))
                        event_calls += 1
                    variable_units = (2 * m * (selected - event_n)
                                      + (2 * interval_incidence + units["interval_candidate_units"] * k) * free_rows)
                    actual_fee = variable_units * weight
                    if actual_fee > static_fee or work + actual_fee > budget:
                        raise AssertionError("static event admission failed")
                    work += actual_fee
                    event_count += additions
                    event_free_rows += free_rows
                    event_n = selected
                    times["event"] += clock() - before
                    before = clock()
                    event_upper = event_bounds.fixed_n_binomial_upper(event_count, event_n, event_alpha)
                    times["inference"] += clock() - before
                    could_certify = gap > 2 * min(query.scope_epsilon, event_upper)
            late = expired()
            if late:
                status = "deadline_postblock"
            elif could_certify:
                certified, status = True, "certified"
            trace.append({
                "nominal_samples": n, "event_samples": event_n, "elapsed_seconds": elapsed(),
                "work_used": work, "lower_gap": gap, "event_upper": event_upper,
                "leader_index": leader, "nominal_certified_now": bool(nominal_now),
                "event_upgrade_to": selected, "event_admission": admission,
                "static_event_fee": static_fee, "actual_event_fee": actual_fee,
                "status": status, "late_certificate_discarded": bool(late and could_certify),
                "uniform_prefix_sha256": uniforms_hash.hexdigest(),
                "winner_prefix_sha256": winners_hash.hexdigest(),
            })
            if certified or late:
                break
    seconds = elapsed()
    if certified and deadline is not None and seconds > deadline:
        certified, status = False, "deadline_postblock"
        if trace:
            trace[-1].update({"status": status, "late_certificate_discarded": True})
    if work > budget or len(observed_winners) != n or int(counts.sum()) != n:
        raise AssertionError("online world/count/work invariant failed")
    return {
        "schema_version": SCHEMA, "graph": query.graph, "query_id": query.query_id,
        "dataset_revision": query.dataset_revision, "policy": policy, "method": policy, "objective": objective,
        "inference_rule": "jain2022_uniform_PPR_1v1" if ppr else rule,
        "seed": base_seed, "seed_purpose": settings["seed_purpose"], "rng_seed_hex": hex(seed),
        "candidate_count": k, "scope_edge_count": m, "tau": settings["tau"],
        "certified": certified, "stable": certified, "status": status,
        "robust_certified": certified and not nominal_objective,
        "certified_candidate_index": leader if certified else None,
        "certified_candidate": str(kernel.candidates[leader]) if certified else None,
        "nominal_certified": nominal_candidate is not None, "nominal_candidate_index": nominal_candidate,
        "nominal_certificate_samples": nominal_n, "nominal_certificate_seconds": nominal_seconds,
        "nominal_delta": delta, "event_beta_total": settings["beta_total"] if event_policy else 0.,
        "actual_nominal_checkpoints": list(checks), "samples_used": n, "worlds_generated": n,
        "nominal_score_rows": n, "nominal_score_calls": score_calls,
        "random_uniform_draws": n * m, "event_extra_random_draws": 0,
        "event_samples_used": event_n, "event_rows_computed": event_n, "event_count": event_count,
        "event_free_rows": event_free_rows, "event_calls": event_calls,
        "event_admission_rejections": rejected, "final_lower_gap": gap,
        "scope_epsilon_upper": query.scope_epsilon, "event_upper": event_upper,
        "work_used": work, "work_budget": budget, "work_overshoot": 0.,
        "work_semantics": "modeled_variable_work_excludes_build_inference_policy_hashing_and_IO",
        "seconds": {**times, "serving_total": seconds, "query_serving_total": seconds,
                    "other_overhead": max(0., seconds - sum(times.values()))},
        "deadline_seconds": deadline,
        "deadline_overrun_seconds": max(0., seconds - deadline) if deadline is not None else 0.,
        "retained_uniform_values": sum(block[1].size for block in blocks),
        "retained_score_values": sum(block[2].size for block in blocks),
        "uniform_prefix_sha256": uniforms_hash.hexdigest(),
        "winner_prefix_sha256": winners_hash.hexdigest(),
        "winner_counts": counts.tolist(), "winner_indices": observed_winners,
        "ppr_final_test": ppr_test, "trace": trace,
    }


def run_comparison(config, output, *, query_count=None, root=ROOT):
    started = time.perf_counter()
    settings = prepare_settings(config, query_count)
    if (settings["required_pythonhashseed"] is not None
            and os.environ.get("PYTHONHASHSEED") != str(settings["required_pythonhashseed"])):
        raise ValueError("launch with the frozen Python hash seed")
    output = _inside(root, output)
    output.mkdir(parents=True, exist_ok=False)
    (output / "cases").mkdir()
    source_paths = [Path(__file__).resolve(), ROOT / "scripts/test_icde_gate_comparison_runner.py",
                    ROOT / "scripts/icde_gate_inference.py", ROOT / "scripts/test_icde_gate_inference.py",
                    ROOT / "scripts/icde_online_execution.py", ROOT / "scripts/test_icde_online_execution.py"]
    source_paths += list((ROOT / "scripts").glob("*vldb*.py"))
    source_paths += list((ROOT / "src/pkgea").rglob("*.py"))
    identities = {path.relative_to(root).as_posix(): file_sha256(path) for path in source_paths}
    inputs = []
    for profile in settings["profiles"]:
        dataset = _inside(root, profile["dataset_path"])
        revision = dataset_revision_digest(dataset)
        if profile.get("expected_revision", revision) != revision:
            raise ValueError("input revision differs before protocol freeze")
        inputs.append({"graph": profile["graph"], "dataset_revision": revision,
                       "input_sha256": {name: file_sha256(dataset / name) for name in CANONICAL_FILES
                                        if (dataset / name).is_file()}})
    write_json(output / "protocol_freeze.json", {
        "schema_version": SCHEMA, "config": config,
        "resolved_query_count": settings["query_count"], "resolved_seeds": settings["seeds"],
        "actual_seed_purpose": settings["seed_purpose"], "policies": settings["policies"],
        "actual_nominal_checkpoints": list(actual_checkpoints(settings)),
        "risk_plan": settings["risk_plan"], "code_sha256": identities, "inputs": inputs,
        "before_setup_audit_and_inference_draws": True,
        "python": sys.version, "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    })
    event_bounds._bound_details.cache_clear()
    inference._ppr_terms.cache_clear()
    setups, cases = [], []
    serialization = 0.
    for graph_index, profile in enumerate(settings["profiles"]):
        prepared, report = setup_graph(profile, settings, root)
        slug = re.sub(r"[^a-z0-9]+", "_", profile["graph"].lower()).strip("_")
        setup_path = output / f"setup_{slug}.json"
        serialization += write_json(setup_path, report)
        setups.append({"graph": profile["graph"], "path": setup_path.relative_to(root).as_posix(),
                       "sha256": file_sha256(setup_path)})
        for seed_index, seed in enumerate(settings["seeds"]):
            for query_index, query in enumerate(prepared):
                policies = tuple(settings["policies"])
                offset = (graph_index + seed_index + query_index) % len(policies)
                ordered = policies[offset:] + policies[:offset]
                for position, policy in enumerate(ordered):
                    result = run_case(query, settings, policy, seed)
                    result["execution_position"] = position
                    query_hash = hashlib.sha256(query.query_id.encode("utf-8")).hexdigest()[:16]
                    path = output / "cases" / f"{slug}_{query_hash}_s{seed}_{policy}.json"
                    serialization += write_json(path, result)
                    cases.append({"graph": query.graph, "query_id": query.query_id, "seed": seed,
                                  "policy": policy, "objective": result["objective"],
                                  "certified": result["certified"],
                                  "path": path.relative_to(root).as_posix(), "sha256": file_sha256(path)})
                    serialization += write_json(output / "progress.json", {
                        "status": "RUNNING", "completed_cases": len(cases), "last_case": cases[-1],
                        "elapsed_seconds": time.perf_counter() - started,
                        "cases_directory_contains_only_atomically_published_complete_case_JSONs": True,
                    }, replace=True)
                    print(json.dumps({"completed_cases": len(cases), "graph": query.graph,
                                      "seed": seed, "policy": policy, "certified": result["certified"]}), flush=True)
    changed = [name for name, expected in identities.items() if file_sha256(root / name) != expected]
    if changed:
        raise ValueError("frozen code changed: " + ", ".join(changed))
    summary = {
        "schema_version": SCHEMA, "status": "COMPLETE", "setup_files": setups,
        "case_files": cases, "completed_cases": len(cases),
        "unique_queries": settings["query_count"] * len(settings["profiles"]),
        "seeds": settings["seeds"], "policies": settings["policies"],
        "seconds_before_summary": time.perf_counter() - started,
        "case_and_progress_serialization_seconds": serialization,
        "timing_contract": {
            "cold_comparison_claim": False, "graph_setup_reported_separately": True,
            "policy_order": "rotation_by_graph_seed_query_index",
            "CI_and_CP_time_is_in_serving_total": True,
            "PPR_inspection": "published_uniform_Jain_rule_at_declared_batch_checkpoints_not_every_draw",
            "CP_and_PPR_cache": "empty_at_worker_start_retained_across_cases",
            "paired_streams": "same graph_revision_source_seed_purpose_across_policies",
            "durability": "per_case_file_flush_fsync_atomic_publish; no storage_power_loss_claim",
        },
        "cache_info": {"CP": event_bounds._bound_details.cache_info()._asdict(),
                       "PPR": inference._ppr_terms.cache_info()._asdict()},
    }
    write_json(output / "summary.json", summary)
    write_json(output / "progress.json", {"status": "COMPLETE", "completed_cases": len(cases),
                                           "summary": "summary.json"}, replace=True)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--query-count", type=int, choices=(16, 32))
    args = parser.parse_args()
    config_path = _inside(ROOT, args.config)
    config = json.loads(config_path.read_text("utf-8-sig"))
    summary = run_comparison(config, args.output_dir, query_count=args.query_count)
    print(json.dumps({"status": summary["status"], "completed_cases": summary["completed_cases"],
                      "module_to_output_seconds": time.perf_counter() - MODULE_STARTED}))


if __name__ == "__main__":
    main()
