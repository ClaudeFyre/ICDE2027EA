"""Guarded fixed-N binomial upper bounds and predeclared-look accounting.

SciPy supplies a Clopper--Pearson quantile proposal, not a numerical proof.
An accepted proposal has an outward Decimal binomial-CDF upper bound <=alpha.
If that cannot be verified, an outward Hoeffding bound is returned instead.
Neither procedure permits arbitrary optional stopping without the union plan.
This module performs no sampling, model evaluation, file I/O or fitting.
"""

from __future__ import annotations

from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
from functools import lru_cache
import math
from typing import Any


PRECISION = 100
MAX_QUANTILE_CORRECTIONS = 32
DEFAULT_CHECKPOINTS = (96, 224, 480, 992, 2016, 4096)


def _fraction(value: Any, name: str) -> Fraction:
    """Floats mean their exact binary values; strings may specify decimals."""
    if isinstance(value, bool):
        raise ValueError(f"{name} cannot be Boolean")
    try:
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError(f"{name} must be finite")
            return Fraction.from_float(value)
        return Fraction(value)
    except (ValueError, TypeError, ZeroDivisionError, OverflowError) as error:
        raise ValueError(f"invalid {name}") from error


def _probability(value: Any, name: str) -> Fraction:
    result = _fraction(value, name)
    if not 0 < result < 1:
        raise ValueError(f"{name} must be strictly between zero and one")
    return result


def _counts(count: int, n: int) -> None:
    if type(count) is not int or type(n) is not int or n < 1 or not 0 <= count <= n:
        raise ValueError("need integer 0<=count<=n with n positive")


def _float_down(value: Fraction) -> float:
    result = float(value)
    if Fraction.from_float(result) > value:
        result = math.nextafter(result, -math.inf)
    return result


def _float_up(value: Decimal) -> float:
    if value >= 1:
        return 1.0
    result = float(value)
    # Always take the exterior neighbour; no libm/quantile ULP accuracy is
    # assumed by the final acceptance criterion.
    return min(1.0, math.nextafter(result, math.inf))


def _decimal_lower(value: Fraction, context: Context) -> Decimal:
    return context.divide(Decimal(value.numerator), Decimal(value.denominator))


def _power_upper(base: Decimal, exponent: int, context: Context) -> Decimal:
    """Positive integer power by outward multiplications, without exp/log."""
    result = Decimal(1)
    factor = base
    while exponent:
        if exponent & 1:
            result = context.multiply(result, factor)
        exponent >>= 1
        if exponent:
            factor = context.multiply(factor, factor)
    return result


def binomial_cdf_upper(count: int, n: int, probability: float) -> Decimal:
    """Outward upper bound on Pr[Bin(n,p)<=count] at this exact float p.

    Positive term recurrence avoids cancellation in the lower binomial tail.
    Each term starts from an upper (1-p)^n; recurrence divides by a lower
    bound on 1-p.  All subsequent operations round toward +infinity.
    """
    _counts(count, n)
    if isinstance(probability, bool) or not isinstance(probability, float):
        raise ValueError("probability must be a finite Python float")
    if not math.isfinite(probability) or not 0 <= probability <= 1:
        raise ValueError("probability must lie in [0,1]")
    if count == n or probability == 0.0:
        return Decimal(1)
    if probability == 1.0:
        return Decimal(0)
    upper = Context(prec=PRECISION, rounding=ROUND_CEILING)
    lower = Context(prec=PRECISION, rounding=ROUND_FLOOR)
    p = Decimal.from_float(probability)
    q_low = lower.subtract(Decimal(1), p)
    q_high = upper.subtract(Decimal(1), p)
    if q_low <= 0:
        raise ArithmeticError("cannot verify a positive complement at selected precision")
    term = _power_upper(q_high, n, upper)
    total = term
    for j in range(1, count + 1):
        term = upper.multiply(term, Decimal(n - j + 1))
        term = upper.divide(term, Decimal(j))
        term = upper.multiply(term, p)
        term = upper.divide(term, q_low)
        total = upper.add(total, term)
        if total >= 1:
            return Decimal(1)
    return min(Decimal(1), total)


def _zero_error_proposal(n: int, alpha: Fraction) -> float:
    """Outward 1-alpha**(1/n), using correctly rounded Decimal ln/exp."""
    lower = Context(prec=PRECISION, rounding=ROUND_FLOOR)
    upper = Context(prec=PRECISION, rounding=ROUND_CEILING)
    alpha_low = _decimal_lower(alpha, lower)
    if alpha_low <= 0:
        return 1.0
    logarithm_low = lower.next_minus(lower.ln(alpha_low))
    exponent_low = lower.divide(logarithm_low, Decimal(n))
    root_low = lower.next_minus(lower.exp(exponent_low))
    return _float_up(upper.subtract(Decimal(1), root_low))


def _hoeffding_upper(count: int, n: int, alpha: Fraction) -> float:
    lower = Context(prec=PRECISION, rounding=ROUND_FLOOR)
    upper = Context(prec=PRECISION, rounding=ROUND_CEILING)
    alpha_low = _decimal_lower(alpha, lower)
    if alpha_low <= 0:
        return 1.0
    logarithm_low = lower.next_minus(lower.ln(alpha_low))
    log_inverse_upper = upper.minus(logarithm_low)
    variance_upper = upper.divide(log_inverse_upper, Decimal(2 * n))
    radius_upper = upper.next_plus(upper.sqrt(variance_upper))
    mean_upper = upper.divide(Decimal(count), Decimal(n))
    return _float_up(upper.add(mean_upper, radius_upper))


def _scipy_proposal(count: int, n: int, alpha: Fraction) -> float:
    from scipy.special import betaincinv

    return float(betaincinv(count + 1, n - count, 1.0 - _float_down(alpha)))


@lru_cache(maxsize=8192)
def _bound_details(count: int, n: int, alpha: Fraction) -> dict[str, Any]:
    common = {
        "count": count, "n": n, "alpha_exact": str(alpha),
        "fixed_n_only": True, "optional_stopping_protected_without_union": False,
        "numerical_precision_decimal_digits": PRECISION,
    }
    if count == n:
        return {**common, "upper": 1.0, "method": "all_successes_one",
                "tail_verified": False, "fallback": False,
                "reason": "one_is_a_trivial_upper_bound"}
    proposal = None
    reason = "quantile_not_verified_after_upward_corrections"
    try:
        proposal = (_zero_error_proposal(n, alpha) if count == 0
                    else _scipy_proposal(count, n, alpha))
        if not math.isfinite(proposal) or not 0 <= proposal <= 1:
            reason = "nonfinite_or_out_of_range_quantile"
        else:
            alpha_low = _decimal_lower(
                alpha, Context(prec=PRECISION, rounding=ROUND_FLOOR)
            )
            candidate = proposal
            for correction in range(1, MAX_QUANTILE_CORRECTIONS + 1):
                candidate = min(1.0, math.nextafter(candidate, math.inf))
                tail = binomial_cdf_upper(count, n, candidate)
                if tail <= alpha_low:
                    return {
                        **common, "upper": candidate,
                        "method": ("clopper_pearson_zero_error_tail_verified" if count == 0
                                   else "clopper_pearson_scipy_tail_verified"),
                        "proposal": proposal, "upward_corrections": correction,
                        "binomial_cdf_upper": str(tail), "tail_verified": True,
                        "fallback": False,
                        "reason": "outward_tail_upper_le_alpha_not_a_quantile_accuracy_assumption",
                    }
    except (ImportError, ArithmeticError, ValueError, OverflowError) as error:
        reason = f"numerical_proposal_or_tail_unavailable:{type(error).__name__}"
    return {
        **common, "upper": _hoeffding_upper(count, n, alpha),
        "method": "hoeffding_fallback_outward", "proposal": proposal,
        "tail_verified": False, "fallback": True, "reason": reason,
        "fallback_guarantee": "fixed_n_one_sided_Hoeffding_with_outward_ln_sqrt",
    }


def fixed_n_binomial_details(count: int, n: int, alpha: Any) -> dict[str, Any]:
    _counts(count, n)
    probability = _probability(alpha, "alpha")
    return dict(_bound_details(count, n, probability))


def fixed_n_binomial_upper(count: int, n: int, alpha: Any) -> float:
    """Return a conservative one-sided fixed-N upper probability bound.

    The mathematical CP root solves F_{n,u}(count)=alpha.  A proposed u is
    accepted only after an outward CDF bound proves F_{n,u}(count)<=alpha;
    by tail monotonicity this u is at least the CP root.  Failed verification
    falls back to Hoeffding.  The analytic Hoeffding upper also has binomial
    lower tail <=alpha, so both branches lie above the same CP root; choosing
    the branch by the observed count does not add a second risk budget.
    A fixed ULP margin alone is never the proof.
    """
    return float(fixed_n_binomial_details(count, n, alpha)["upper"])


def validate_risk_plan(config: dict[str, Any]) -> dict[str, Any]:
    """Exact union accounting for complete-prefix, predeclared-N event looks."""
    nominal = _probability(config["delta_nominal"], "delta_nominal")
    event = _probability(config["beta_total"], "beta_total")
    total = _probability(config["delta_total"], "delta_total")
    if nominal + event > total:
        raise ValueError("nominal plus event risk exceeds delta_total")
    taus = config["tau_grid"]
    if not isinstance(taus, (tuple, list)) or not taus:
        raise ValueError("tau_grid must be a fixed nonempty sequence")
    tau_values = tuple(_fraction(tau, "tau") for tau in taus)
    if len(set(tau_values)) != len(tau_values) or any(not 0 <= tau < 1 for tau in tau_values):
        raise ValueError("tau boxes must be distinct and in [0,1)")
    checkpoints = config.get("event_checkpoints", config.get("checkpoints", DEFAULT_CHECKPOINTS))
    if not isinstance(checkpoints, (tuple, list)) or not checkpoints:
        raise ValueError("event_checkpoints must be a fixed nonempty sequence")
    if any(type(n) is not int or n <= 0 for n in checkpoints):
        raise ValueError("event checkpoints must be positive integers")
    checkpoints = tuple(checkpoints)
    if checkpoints != tuple(sorted(set(checkpoints))):
        raise ValueError("event checkpoints must be strictly increasing and unique")
    maximum = config.get("max_samples_per_query", config.get("sample_count", checkpoints[-1]))
    if type(maximum) is not int or maximum < checkpoints[-1]:
        raise ValueError("event checkpoint exceeds the fixed sample cap")
    looks = len(checkpoints)
    boxes = len(taus)
    alpha_exact = event / (looks * boxes)
    alpha_float = _float_down(alpha_exact)
    if not 0 < alpha_float < 1:
        raise ValueError("allocated event alpha is not representable as a positive float")
    spent_event = Fraction.from_float(alpha_float) * looks * boxes
    if spent_event > event:
        raise AssertionError("downward risk allocation failed")
    return {
        "schema_version": "vldb-fixed-prefix-event-risk-plan-v2",
        "event_checkpoints": checkpoints, "protected_box_count": boxes,
        "protected_checkpoint_count": looks,
        "alpha_per_checkpoint": alpha_float,
        "alpha_per_checkpoint_exact": str(alpha_exact),
        "alpha_per_checkpoint_float_exact": str(Fraction.from_float(alpha_float)),
        "delta_nominal_exact": str(nominal), "beta_total_exact": str(event),
        "delta_total_exact": str(total), "allocated_event_risk_exact": str(spent_event),
        "allocated_total_risk_exact": str(nominal + spent_event),
        "risk_scope": "per_query_per_nominal_run_simultaneous_over_boxes_and_fixed_prefixes",
        "complete_nominal_prefix_required": True,
        "uncomputed_h_defaults_to_zero": False,
        "arbitrary_random_event_sample_counts_protected": False,
        "independence_between_nominal_and_event_statistics_required": False,
        "joint_guarantee_across_competing_policies_or_queries": False,
        "budget_number_semantics": (
            "floats_are_their_exact_binary_values_strings_are_exact_decimals"
        ),
    }


def require_checkpoint(
    n: int, plan: dict[str, Any], *, computed_prefix_length: int | None = None
) -> float:
    """Refuse unprotected looks and known incomplete lazy-filled prefixes."""
    if type(n) is not int or n not in plan["event_checkpoints"]:
        raise ValueError("n is not a predeclared protected event checkpoint")
    if computed_prefix_length is not None and computed_prefix_length != n:
        raise ValueError("event evidence does not cover the complete nominal prefix")
    return float(plan["alpha_per_checkpoint"])
