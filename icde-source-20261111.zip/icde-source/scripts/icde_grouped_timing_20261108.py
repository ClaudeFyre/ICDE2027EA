"""Bounded warm timing follow-up for a first-call outlier; known queries only.

Freezes protocol and audits identities BEFORE warmup or timed evaluations.
Records warmup cost; no raw-data cold service or novelty claim.
"""
import argparse
import statistics
import time
from pathlib import Path
import numpy as np

import icde_prospective_20261107 as old
from icde_grouped_exact_20261108 import compile_counts, solve_counts
from icde_grouped_inventory_20261108 import load, save, sha, ROOT
from run_vldb_interval_gate_v1 import clipped_box

PARENT = ROOT / "nodes/09_vldb_query_certification/results/icde_grouped_query_20261108/prototype_attempt1"
BASE = PARENT.parent / "timing_attempt1"


def measure(kernel, meta, method, seed):
    started = time.perf_counter()
    m = len(kernel.edge_indices)
    lower, upper = kernel.score_intervals(np.zeros((1, m), dtype=np.bool_), np.ones((1, m), dtype=np.bool_))
    w = int(np.argmax(lower[0]))
    other = upper[0].copy()
    other[w] = -np.inf
    direct = bool(lower[0, w] > max(other))
    if direct:
        winner, worlds = w, 0
    elif method == "count_exact":
        low, high = clipped_box(np.full(m, .9), .25)
        compiled = compile_counts(kernel, low, high)
        result = solve_counts(compiled, len(kernel.candidates))
        winner = result["uniform_winners"][0] if result["uniform_winners"] else None
        worlds = 0
    else:
        result = old.execute_case(kernel, meta, .25, seed, "eager")
        winner = kernel.candidates.index(result["candidate"]) if result["candidate"] is not None else None
        worlds = result["worlds"]
    return {"method": method, "candidate": winner, "compute_seconds": time.perf_counter()-started,
            "worlds": worlds, "direct": direct}


def main(out):
    if out.exists():
        raise FileExistsError(out)
    summary, parent = load(PARENT / "summary.json"), load(PARENT / "protocol.json")
    selected = [r for r in summary["cases"] if r["role"] == "static_large_scope" or
                (r["graph"] == "dw" and r["rank"] in (113, 244))]
    code = dict(parent["code_sha256"])
    code["scripts/icde_grouped_timing_20261108.py"] = sha(Path(__file__))
    protocol = {"kind": "adaptive_development_timing_followup_for_first_call_outlier",
        "cases": [{k:r[k] for k in ("graph", "rank", "role", "scope_edges", "candidates", "count_states", "uniform_winners")} for r in selected],
        "repeats": 3, "seeds_by_repeat": [709, 719, 709], "methods": ["count_exact", "generic_eager"],
        "warmup": "both methods on EN-FR q175, seed709, to traverse the previously observed first-use path; full warmup cost recorded separately",
        "method_order": "alternate by query and repeat; each method uses the same direct interval front end",
        "cost": "prepared-query warm compute only; scorer loading separate; no raw-input cold startup or persistence",
        "code_sha256": code, "input_sha256": dict(parent["input_sha256"]),
        "parent_summary_sha256": sha(PARENT / "summary.json"), "frozen_at_unix": time.time()}
    save(out / "protocol.json", protocol)
    checks = 0
    for group in ("code_sha256", "input_sha256"):
        for name, digest in protocol[group].items():
            if sha(ROOT / name) != digest:
                raise AssertionError("frozen numerical source/input changed")
            checks += 1
    save(out / "recovery.json", {"status": "PASS", "checks": checks, "scope": "all inherited identities; parent CRC audit already passed"})
    wk, wm = old.read_query("enfr", 175)
    warm = [measure(wk, wm, method, 709) for method in protocol["methods"]]
    rows = []
    for i, case in enumerate(protocol["cases"]):
        before = time.perf_counter()
        kernel, meta = old.read_query(case["graph"], case["rank"])
        loading = time.perf_counter()-before
        for repeat, seed in enumerate(protocol["seeds_by_repeat"]):
            order = protocol["methods"] if (i+repeat)%2 == 0 else protocol["methods"][::-1]
            for method in order:
                result = measure(kernel, meta, method, seed)
                if result["candidate"] is not None and result["candidate"] not in case["uniform_winners"]:
                    raise AssertionError("timing repetition returned unsafe output")
                if method == "count_exact" and (result["candidate"] is not None) != bool(case["uniform_winners"]):
                    raise AssertionError("exact repetition changed decision")
                rows.append({**case, "repeat": repeat, "seed": seed,
                             "prepared_query_load_seconds": loading, **result})
                checks += 1
    aggregates = []
    for case in protocol["cases"]:
        for method in protocol["methods"]:
            subset = [r for r in rows if r["graph"] == case["graph"] and r["rank"] == case["rank"] and r["method"] == method]
            aggregates.append({**case, "method": method, "repeats": len(subset),
                "certified_runs": sum(r["candidate"] is not None for r in subset),
                "median_seconds": statistics.median(r["compute_seconds"] for r in subset),
                "minimum_seconds": min(r["compute_seconds"] for r in subset),
                "maximum_seconds": max(r["compute_seconds"] for r in subset)})
    for group in ("code_sha256", "input_sha256"):
        for name, digest in protocol[group].items():
            if sha(ROOT / name) != digest:
                raise AssertionError("identity changed during timing")
            checks += 1
    save(out / "summary.json", {"status": "PASS", "checks": checks, "rows": rows,
        "warmup": warm, "aggregates": aggregates, "protocol_sha256": sha(out / "protocol.json"),
        "limitations": ["same known development subset, not new confirmation", "three warm observations, no population speed significance",
            "fixed standard count compiler, not a novelty comparison against optimized lifted or credal systems"]})
    print(f"PASS {len(rows)} warm timed runs, {checks} identity/output checks", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=BASE)
    args = parser.parse_args()
    main(args.output.resolve())
