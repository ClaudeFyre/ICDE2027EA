"""WWW E1 serving contract: serialized bounds, record backing store, certify-or-refine.

This module implements the frozen protocol in
``nodes/04_www_distributional/results/reviewer_followup_v1/protocol.md``.
It is the *serving* path, not the offline ``certificate_report``: every
number a decision uses is read back from disk, bounds are float32 rounded
outward, refinement restores the full mean and covariance of exactly the
mathematically admissible active set from a record-oriented backing store,
and the tie rule is the earliest position in the frozen candidate order.

Reuse is deliberate: distortion bounds come from
``www_budget_frontier.target_distortions`` (same exact W2 plus the frozen
``NUMERICAL_GUARD``), and exact distances come through
``pkgea.www_fsl.gaussian_distance_matrix`` (same PSD policy as the frozen
audit).  Nothing here re-derives the mathematics; it only wraps it in the
read-back, outward-rounding, per-record-fetch contract reviewers asked for.
"""

from __future__ import annotations

import hashlib
import io
import json
import struct
import sys
import time
import zlib
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT / "src", ROOT / "scripts", ROOT / "scripts/backbones"):
    if str(search_path) not in sys.path:
        sys.path.insert(0, str(search_path))

BOUNDS_DIR = ROOT / ".runtime/www_reviewer_bounds_v1"
BACKING_DIR = ROOT / ".runtime/www_reviewer_backing_v1"
PAYLOAD_DIR = ROOT / ".runtime/www_fixed_index_v1"

MAGIC_BOUNDS = "pkgea-www-reviewer-bounds-v1"
MAGIC_BACKING = b"pkgea-www-backing-v1"
BACKING_HEADER = 96
BACKING_FORMAT = "<24s5I32s20s"
FRONT_METHODS = ("full_fp16", "margin_w2", "margin_fp16")

DOMAIN_MEAN_MIN = 1e-6
DOMAIN_MEAN_MAX = 1e6
DOMAIN_PSD_TOL = 1e-9


class ServingStop(RuntimeError):
    """Hard contract failure: preserve the case, never retry past it."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def payload_path(cell: str, method: str) -> Path:
    return PAYLOAD_DIR / cell / f"{method}.npz"


def bounds_path(cell: str, method: str) -> Path:
    return BOUNDS_DIR / cell / f"{method}.npz"


def backing_path(cell: str) -> Path:
    return BACKING_DIR / cell / "backing.bin"


def verify_payload_on_disk(cell: str, method: str, pinned_sha256: str) -> bytes:
    """Protocol section 1: reuse frozen payloads only after an exact hash match."""

    path = payload_path(cell, method)
    if not path.is_file():
        raise ServingStop(f"missing frozen payload {path}")
    data = path.read_bytes()
    actual = sha256_bytes(data)
    if actual != pinned_sha256:
        raise ServingStop(
            f"payload hash mismatch for {cell}/{method}: disk {actual} "
            f"pinned {pinned_sha256}")
    return data


def load_target_moments(payload: bytes, method: str) -> tuple[np.ndarray, np.ndarray]:
    """Reload a target index exactly like the frozen audit's stage loop."""

    from run_www_equal_budget import load_full_payload, load_representation_payload
    if method.startswith("full_"):
        return load_full_payload(payload)
    return load_representation_payload(payload)


def outward_float32(exact: np.ndarray) -> np.ndarray:
    """float32 rounded strictly outward (up), per target.

    Round-to-nearest can land on either side of the exact bound, so one
    ``nextafter`` step up guarantees float64(stored) >= exact for every
    input.  A non-finite or negative input is a discarded/truncated bound:
    STOP.
    """

    exact64 = np.asarray(exact, dtype=np.float64)
    if not np.all(np.isfinite(exact64)) or np.any(exact64 < 0.0):
        raise ServingStop("distortion bound is non-finite or negative")
    stored = np.nextafter(exact64.astype(np.float32), np.float32(np.inf))
    if np.any(stored.astype(np.float64) < exact64):
        raise ServingStop("outward rounding failed to dominate the exact bound")
    return stored


def representation_codes(payload: bytes, method: str, count: int) -> np.ndarray:
    """Per-target format tag; full_* artifacts are uniformly 'full' (code 8)."""

    if method.startswith("full_"):
        return np.full(count, 8, dtype=np.uint8)
    with np.load(io.BytesIO(payload), allow_pickle=False) as data:
        codes = np.asarray(data["representation_codes"], dtype=np.uint8)
    if len(codes) != count:
        raise ServingStop(f"format tags cover {len(codes)} targets, expected {count}")
    return codes


def read_bounds(cell: str, method: str, pinned_sha256: str) -> dict:
    """Protocol 2.2: read the bound vector from disk and verify it before use."""

    path = bounds_path(cell, method)
    if not path.is_file():
        raise ServingStop(f"missing bounds file {path}")
    raw = path.read_bytes()
    with np.load(io.BytesIO(raw), allow_pickle=False) as data:
        deltas = np.asarray(data["deltas_f32"], dtype=np.float32).astype(np.float64)
        codes = np.asarray(data["format_codes_u8"], dtype=np.uint8)
        metadata = json.loads(str(data["metadata_json"]))
    if metadata.get("payload_sha256") != pinned_sha256:
        raise ServingStop(f"bounds metadata names a different payload: {cell}/{method}")
    if not np.all(np.isfinite(deltas)) or np.any(deltas < 0.0):
        raise ServingStop(f"bounds contain non-finite or negative values: {cell}/{method}")
    return {
        "deltas": deltas,
        "codes": codes,
        "metadata": metadata,
        "bounds_bytes": len(raw),
        "bounds_sha256": sha256_bytes(raw),
        "disk_path": path,
    }


def relative_to_root(path: Path) -> str:
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path.resolve())


def build_bounds(*, cell: str, method: str, pinned_sha256: str,
                 full_means: np.ndarray, full_covariances: np.ndarray,
                 extra_metadata: dict) -> dict:
    """Serialize the per-target bound vector for one serving artifact.

    Bounds are measured against the reloaded artifact (protocol 2.1), stored
    as outward-rounded float32, written atomically, then read back and
    verified before the result is returned.
    """

    from www_budget_frontier import NUMERICAL_GUARD, target_distortions

    payload = verify_payload_on_disk(cell, method, pinned_sha256)
    index_means, index_covariances = load_target_moments(payload, method)
    if len(index_means) != len(full_means):
        raise ServingStop(f"{cell}/{method}: index holds {len(index_means)} targets, "
                          f"full reference holds {len(full_means)}")
    exact = target_distortions(full_means, full_covariances,
                               index_means, index_covariances)
    stored = outward_float32(exact)
    codes = representation_codes(payload, method, len(full_means))
    metadata = {
        "schema_version": MAGIC_BOUNDS,
        "cell": cell,
        "method": method,
        "payload_sha256": pinned_sha256,
        "payload_bytes": len(payload),
        "payload_disk_path": relative_to_root(payload_path(cell, method)),
        "numerical_guard": NUMERICAL_GUARD,
        "exact_delta_min": float(np.min(exact)),
        "exact_delta_max": float(np.max(exact)),
        **extra_metadata,
    }
    buffer = io.BytesIO()
    np.savez_compressed(
        buffer,
        deltas_f32=stored,
        format_codes_u8=codes,
        scalar_dtype=np.asarray("float32"),
        metadata_json=np.asarray(json.dumps(metadata, sort_keys=True)),
    )
    blob = buffer.getvalue()
    path = bounds_path(cell, method)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        # np.savez_compressed embeds zip timestamps, so idempotence is defined
        # on decoded content (deltas, codes, metadata), never on raw bytes.
        existing = read_bounds(cell, method, pinned_sha256)
        same = (np.array_equal(existing["deltas"], stored.astype(np.float64))
                and np.array_equal(existing["codes"], codes)
                and existing["metadata"] == metadata)
        if not same:
            raise ServingStop(f"existing bounds file differs; preserving it: {path}")
    else:
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(blob)
        tmp.replace(path)
    read_back = read_bounds(cell, method, pinned_sha256)
    if not np.array_equal(read_back["deltas"], stored.astype(np.float64)):
        raise ServingStop(f"bounds read-back mismatch for {cell}/{method}")
    return read_back


def front_bytes(cell: str, method: str, pinned_sha256: str) -> dict:
    """Protocol 2.1: measured resident bytes are the actual on-disk sizes."""

    payload = verify_payload_on_disk(cell, method, pinned_sha256)
    read_back = read_bounds(cell, method, pinned_sha256)
    disk_total = payload_path(cell, method).stat().st_size + \
        bounds_path(cell, method).stat().st_size
    reported = len(payload) + read_back["bounds_bytes"]
    if reported != disk_total:
        raise ServingStop(f"byte reconciliation failed for {cell}/{method}: "
                          f"reported {reported}, disk {disk_total}")
    return {
        "payload_bytes": payload_path(cell, method).stat().st_size,
        "bounds_bytes": read_back["bounds_bytes"],
        "front_bytes_total": disk_total,
        "bounds_sha256": read_back["bounds_sha256"],
    }


def build_backing(*, cell: str, full_payload: bytes, targets: tuple[str, ...],
                  extra_metadata: dict) -> dict:
    """Record-oriented full-FP32 store: one fixed record per target.

    Each record is mean + covariance upper triangle + CRC32, positioned by
    candidate index, so refinement seeks only the active set.  The body
    carries a SHA-256.  Reconstruction is idempotent: an existing store that
    differs is a STOP, never an overwrite.
    """

    from run_www_equal_budget import load_full_payload
    means, covariances = load_full_payload(full_payload)
    dimension = int(means.shape[1])
    upper = np.triu_indices(dimension)
    upper_count = int(len(upper[0]))
    count = int(len(means))
    if count != len(targets):
        raise ServingStop(f"{cell}: backing holds {count} targets, expected {len(targets)}")
    record_bytes = (dimension + upper_count) * 4 + 4
    body = bytearray()
    for index in range(count):
        record = struct.pack(
            f"<{dimension + upper_count}f",
            *np.asarray(means[index], dtype=np.float32),
            *np.asarray(covariances[index][upper], dtype=np.float32))
        crc = struct.pack("<I", zlib.crc32(record) & 0xFFFFFFFF)
        body += record + crc
    assert len(body) == count * record_bytes
    digest = hashlib.sha256(bytes(body)).hexdigest()
    header = struct.pack(BACKING_FORMAT, MAGIC_BACKING, 1, count, record_bytes,
                         dimension, upper_count, bytes.fromhex(digest), b"")
    assert len(header) == BACKING_HEADER
    blob = header + bytes(body)
    path = backing_path(cell)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file() and path.read_bytes() != blob:
        raise ServingStop(f"existing backing store differs; preserving it: {path}")
    if not path.is_file():
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(blob)
        tmp.replace(path)
    store = open_backing(cell, body_sha256=digest)
    probe = store.read_targets(np.arange(count))
    stored_means = np.asarray(np.asarray(means, dtype=np.float32), dtype=np.float64)
    stored_covs = np.asarray(np.asarray(covariances, dtype=np.float32), dtype=np.float64)
    off = np.triu_indices(dimension)
    expanded = np.zeros_like(stored_covs)
    expanded[:, off[0], off[1]] = stored_covs[:, off[0], off[1]]
    expanded[:, off[1], off[0]] = stored_covs[:, off[0], off[1]]
    if not np.array_equal(probe["means"], stored_means):
        raise ServingStop(f"backing round-trip lost record fidelity: {cell}")
    if not np.array_equal(probe["covariances"], expanded):
        raise ServingStop(f"backing round-trip changed covariances: {cell}")
    return {
        "cell": cell,
        "path": path,
        "bytes": len(blob),
        "record_bytes": record_bytes,
        "targets": count,
        "dimension": dimension,
        "body_sha256": digest,
        "metadata": {**extra_metadata, "schema_version": MAGIC_BACKING.decode(),
                     "dimension": dimension},
    }


class BackingStore:
    """Positioned per-record reader with honest byte accounting."""

    def __init__(self, path: Path, header: dict):
        self.path = path
        self.header = header
        self.bytes_read = 0
        self.records_read = 0
        self.reads = 0

    def reset_counters(self) -> None:
        self.bytes_read = 0
        self.records_read = 0
        self.reads = 0

    def read_targets(self, indices: np.ndarray) -> dict:
        header = self.header
        dimension = header["dimension"]
        upper_count = header["upper_count"]
        record_bytes = header["record_bytes"]
        count = header["count"]
        indices = np.unique(np.asarray(indices, dtype=np.int64))
        if indices.size and (indices.min() < 0 or indices.max() >= count):
            raise ServingStop(f"{self.path}: target index outside the candidate order")
        means = np.zeros((len(indices), dimension), dtype=np.float64)
        covariances = np.zeros((len(indices), dimension, dimension), dtype=np.float64)
        upper = np.triu_indices(dimension)
        with self.path.open("rb") as handle:
            for row, index in enumerate(indices):
                handle.seek(BACKING_HEADER + int(index) * record_bytes)
                raw = handle.read(record_bytes)
                self.reads += 1
                self.records_read += 1
                self.bytes_read += len(raw)
                if len(raw) != record_bytes:
                    raise ServingStop(f"{self.path}: short read at target {index}")
                payload, crc = raw[:-4], struct.unpack("<I", raw[-4:])[0]
                if zlib.crc32(payload) & 0xFFFFFFFF != crc:
                    raise ServingStop(f"{self.path}: CRC failure at target {index}")
                values = struct.unpack(f"<{dimension + upper_count}f", payload)
                means[row] = values[:dimension]
                covariances[row][upper] = values[dimension:]
                covariances[row][(upper[1], upper[0])] = values[dimension:]
        return {"indices": indices, "means": means, "covariances": covariances}


def open_backing(cell: str, *, body_sha256: str | None = None) -> BackingStore:
    path = backing_path(cell)
    if not path.is_file():
        raise ServingStop(f"missing backing store {path}")
    with path.open("rb") as handle:
        header_raw = handle.read(BACKING_HEADER)
        if len(header_raw) != BACKING_HEADER:
            raise ServingStop(f"{path}: truncated header")
        magic, version, count, record_bytes, dimension, upper_count, digest, _res = \
            struct.unpack(BACKING_FORMAT, header_raw)
        if magic.rstrip(b"\x00") != MAGIC_BACKING or version != 1:
            raise ServingStop(f"{path}: wrong backing format")
        body = handle.read()
    actual = hashlib.sha256(body).hexdigest()
    if actual != digest.hex():
        raise ServingStop(f"{path}: body digest mismatch")
    if body_sha256 is not None and actual != body_sha256:
        raise ServingStop(f"{path}: body differs from the pinned digest")
    if len(body) != count * record_bytes:
        raise ServingStop(f"{path}: body length is not a whole number of records")
    return BackingStore(path, {
        "count": count, "record_bytes": record_bytes,
        "dimension": dimension, "upper_count": upper_count,
        "body_sha256": actual})


def validate_domain(query_mean: np.ndarray, query_covariance: np.ndarray) -> str | None:
    """Protocol 2.5: None when in domain, otherwise the rejection reason."""

    if not (np.all(np.isfinite(query_mean)) and np.all(np.isfinite(query_covariance))):
        return "non-finite source moments"
    scale = float(np.max(np.abs(query_mean)))
    if scale > DOMAIN_MEAN_MAX:
        return f"source mean scale {scale:.3e} above the accepted domain"
    if 0.0 < scale < DOMAIN_MEAN_MIN:
        return f"source mean scale {scale:.3e} below the accepted domain"
    symmetric = 0.5 * (query_covariance + query_covariance.T)
    eigenvalues = np.linalg.eigvalsh(symmetric)
    magnitude = max(1.0, float(np.max(np.abs(eigenvalues))))
    if -float(np.min(eigenvalues)) > DOMAIN_PSD_TOL * magnitude:
        return "source covariance violates the PSD policy beyond tolerance"
    return None


def exact_distances(query_mean: np.ndarray, query_covariance: np.ndarray,
                    target_means: np.ndarray, target_covariances: np.ndarray) -> np.ndarray:
    """W2 (the metric, not squared) against restored records, same PSD path."""

    from pkgea.www_fsl import gaussian_distance_matrix
    squared = gaussian_distance_matrix(
        np.concatenate((query_mean[None, :], target_means), axis=0),
        np.concatenate((query_covariance[None], target_covariances), axis=0),
        1)[0]
    return np.sqrt(np.maximum(squared, 0.0))


def certify_or_refine_query(*, estimate_w2: np.ndarray, deltas: np.ndarray,
                            store: BackingStore, query_mean: np.ndarray,
                            query_covariance: np.ndarray,
                            tie_policy: str = "first_frozen_position") -> dict:
    """One query through the serving contract.

    ``estimate_w2`` and ``deltas`` are float64 rows over the frozen candidate
    order (W2, not squared).  Certified iff min lower over rivals strictly
    exceeds the winner upper; otherwise the mathematically admissible active
    set (lower <= winner upper, ties included, plus the winner) is restored
    from the backing store and scored exactly.  Out-of-domain queries take the
    safe full-index path over all records.
    """

    if tie_policy != "first_frozen_position":
        raise ServingStop(f"unknown tie policy {tie_policy}")
    estimate_w2 = np.asarray(estimate_w2, dtype=np.float64)
    deltas = np.asarray(deltas, dtype=np.float64)
    if estimate_w2.shape != deltas.shape or estimate_w2.ndim != 1:
        raise ServingStop("estimate and delta rows must share the frozen order")
    started = time.perf_counter()
    count = len(estimate_w2)
    positions = np.arange(count)
    upper = estimate_w2 + deltas
    lower = estimate_w2 - deltas
    winner = int(np.argmin(estimate_w2))
    gap = float(np.min(np.where(positions == winner, np.inf, lower)) - upper[winner])
    reason = validate_domain(query_mean, query_covariance)
    if reason == "non-finite source moments":
        # The request itself cannot be scored; refusing is the only sound
        # answer.  Preserve the case upstream instead of serving a guess.
        raise ServingStop(f"non-finite query moments cannot be served: {reason}")
    if reason is not None:
        state = "full_index_safe_path"
        active = positions
    elif gap > 0.0:
        state = "certified"
        active = positions[:0]
    else:
        state = "refined"
        active = positions[(lower <= upper[winner]) | (positions == winner)]
    if state == "certified":
        answer = winner
    else:
        restored = store.read_targets(active)
        distances = exact_distances(query_mean, query_covariance,
                                    restored["means"], restored["covariances"])
        # distances are rows of the (sorted, unique) active set; map the
        # minimizing row back to its candidate position in the frozen order.
        answer = int(active[int(np.argmin(distances))])
    return {
        "state": state,
        "domain_rejection": reason,
        "compressed_winner": winner,
        "served_answer": answer,
        "gap": gap,
        "active_set_size": int(len(active)),
        "records_read": int(len(active)),
        "seconds": time.perf_counter() - started,
    }
