import tempfile
from pathlib import Path
import unittest
import numpy as np
from icde_final_random_audit_20261109_v2 import save,load,ROOT


class EvidenceSerialization(unittest.TestCase):
    def test_resource_exclusion_big_integer_roundtrip(self):
        folder=Path(tempfile.mkdtemp(prefix='audit_evidence_test_',dir=ROOT/'.runtime'))
        path=folder/'case.json';large=3**15000
        save(path,{'S':large,'status':'unknown','rank':np.int64(16)})
        self.assertEqual(load(path),{'S':large,'status':'unknown','rank':16})
        self.assertFalse(path.with_suffix('.json.pending').exists())
        with self.assertRaises(FileExistsError):save(path,{'replacement':True})

    def test_bad_payload_does_not_publish_partial_record(self):
        folder=Path(tempfile.mkdtemp(prefix='audit_evidence_test_',dir=ROOT/'.runtime'))
        path=folder/'case.json'
        with self.assertRaises(TypeError):save(path,{'invalid':object()})
        self.assertFalse(path.exists())


if __name__=='__main__':unittest.main()
