"""Exact finite-world tests of the fixed source-partition hybrid contract."""

from fractions import Fraction
from itertools import product
from pathlib import Path
from types import SimpleNamespace
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from icde_gate_hybrid_envelope import compile_hybrid
from vldb_difference_envelope_v2 import compile_difference_kernel


def kernel_fixture(incidence, m, lexical=(0., 0.)):
    original = SimpleNamespace(
        source="s", candidates=("a", "b"), edge_indices=tuple(range(m)),
        incidence_positions=tuple(np.asarray(values, dtype=np.intp) for values in incidence),
        attribute=np.zeros(2, dtype=np.float64), lexical=np.asarray(lexical, dtype=np.float64),
        attribute_weight=0.,
    )
    return compile_difference_kernel(original)


def improving_fixture():
    # e0 is source-out; e1 is a pinned b-out edge; e2 is b->a, affecting
    # b-out and a-in together. Both candidates survive universal static ranges.
    kernel = kernel_fixture(((0,), (), (), (2,), (1, 2), ()), 3, lexical=(0., .05))
    q = np.array([.75, 1., .5], dtype=np.float64)
    low = np.array([.625, 1., .375], dtype=np.float64)
    high = np.array([.875, 1., .625], dtype=np.float64)
    return kernel, q, low, high


def negative_fixture():
    # Source variation cannot change a's win: a has fixed out-degree1 and b
    # has fixed out-degree3. Generic intervals already prove this, so charging
    # positive source TV makes the hybrid bound strictly worse.
    kernel = kernel_fixture(((0,), (), (1,), (), (2, 3, 4), ()), 5)
    q = np.array([.5, 1., 1., 1., 1.], dtype=np.float64)
    low = np.array([.125, 1., 1., 1., 1.], dtype=np.float64)
    high = np.array([.875, 1., 1., 1., 1.], dtype=np.float64)
    return kernel, q, low, high


def winner_probabilities(kernel, parameters):
    """Exact independent product mass; scorer and tie mapping remain float64."""
    states = list(product((False, True), repeat=len(parameters)))
    winners = np.argmax(kernel.scores(np.asarray(states, dtype=np.bool_)), axis=1)
    probabilities = [Fraction(0) for _ in kernel.candidates]
    for state, winner in zip(states, winners):
        mass = Fraction(1)
        for active, probability in zip(state, parameters):
            mass *= probability if active else 1 - probability
        probabilities[int(winner)] += mass
    return probabilities


def expected_flags(kernel, q, low, high, hybrid=None):
    """Integrate U exactly over its finite threshold-cell partition."""
    intervals = []
    for coordinate in range(len(q)):
        boundaries = sorted({Fraction(0), Fraction(1),
                             Fraction.from_float(float(q[coordinate])),
                             Fraction.from_float(float(low[coordinate])),
                             Fraction.from_float(float(high[coordinate]))})
        intervals.append(list(zip(boundaries[:-1], boundaries[1:])))
    expectation = Fraction(0)
    for cell in product(*intervals):
        uniforms = np.array([[float((left + right) / 2) for left, right in cell]], dtype=np.float64)
        scores = kernel.scores(uniforms < q[None, :])
        flags = (kernel.ambiguity_indicators(q, low, high, uniforms, nominal_scores=scores)
                 if hybrid is None else hybrid.indicators(uniforms, nominal_scores=scores))
        mass = Fraction(1)
        for left, right in cell:
            mass *= right - left
        if flags[0]:
            expectation += mass
    return expectation


class HybridEnvelopeTests(unittest.TestCase):
    def test_strict_gain_over_both_full_event_and_scope_bounds(self):
        kernel, q, low, high = improving_fixture()
        hybrid = compile_hybrid(kernel, q, low, high)
        full_mean = expected_flags(kernel, q, low, high)
        hybrid_mean = expected_flags(kernel, q, low, high, hybrid)
        self.assertEqual(full_mean, Fraction(9, 32))
        self.assertEqual(hybrid_mean, Fraction(1, 16))
        hybrid_bound = Fraction.from_float(hybrid.epsilon_source) + hybrid_mean
        self.assertLess(hybrid_bound, full_mean)
        self.assertLess(hybrid_bound, Fraction.from_float(hybrid.epsilon_scope))
        self.assertEqual(hybrid.source_positions, (0,))

    def test_every_corner_and_interior_grid_obeys_uniform_candidate_event_bound(self):
        for fixture in (improving_fixture, negative_fixture):
            kernel, q, low, high = fixture()
            hybrid = compile_hybrid(kernel, q, low, high)
            event_mean = expected_flags(kernel, q, low, high, hybrid)
            bound = Fraction.from_float(hybrid.epsilon_source) + event_mean
            nominal = winner_probabilities(kernel, tuple(Fraction.from_float(float(value)) for value in q))
            grid = []
            for lo, mid, hi in zip(low, q, high):
                left, center, right = map(lambda value: Fraction.from_float(float(value)), (lo, mid, hi))
                grid.append(sorted({left, (left + center) / 2, center, (center + right) / 2, right}))
            for parameters in product(*grid):
                alternative = winner_probabilities(kernel, parameters)
                for actual, reference in zip(alternative, nominal):
                    self.assertLessEqual(abs(actual - reference), bound)

    def test_retain_negative_precision_case(self):
        kernel, q, low, high = negative_fixture()
        hybrid = compile_hybrid(kernel, q, low, high)
        self.assertEqual(expected_flags(kernel, q, low, high), 0)
        self.assertEqual(expected_flags(kernel, q, low, high, hybrid), 0)
        self.assertGreater(hybrid.epsilon_source, 0)
        self.assertGreater(hybrid.combine_upper(0), 0)

    def test_nominal_q_and_scores_are_not_frozen_to_one_source_state(self):
        kernel, q, low, high = improving_fixture()
        original_q = q.copy()
        hybrid = compile_hybrid(kernel, q, low, high)
        uniforms = np.array([[.1, .5, .9], [.9, .5, .9]], dtype=np.float64)
        scores = kernel.scores(uniforms < q[None, :])
        winners = np.argmax(scores, axis=1)
        self.assertEqual(winners.tolist(), [1, 0])
        self.assertTrue(np.array_equal(q, original_q))
        self.assertTrue(np.array_equal(kernel.scores(uniforms < hybrid.q[None, :]), scores))
        cached = scores.copy()
        hybrid.indicators(uniforms, nominal_scores=cached)
        self.assertTrue(np.array_equal(cached, scores))
        self.assertFalse(hybrid.q.flags.writeable)
        self.assertFalse(hybrid.low_T.flags.writeable)

    def test_shared_source_target_edges_are_included_in_source_partition(self):
        kernel = kernel_fixture(((0,), (1,), (1,), (0,), (), ()), 2)
        q = np.array([.5, .5], dtype=np.float64)
        low, high = np.array([.25, .25]), np.array([.75, .75])
        hybrid = compile_hybrid(kernel, q, low, high)
        self.assertEqual(hybrid.source_positions, (0, 1))
        self.assertTrue(np.array_equal(hybrid.low_T, q))
        self.assertTrue(np.array_equal(hybrid.high_T, q))
        uniforms = np.array([[.1, .9], [.6, .3]], dtype=np.float64)
        self.assertFalse(np.any(hybrid.indicators(uniforms)))
        self.assertFalse(np.any(hybrid.free_flags(uniforms)))

    def test_empty_source_partition_recovers_the_generic_envelope(self):
        kernel = kernel_fixture(((), (), (0,), (), (1,), ()), 2)
        q = np.array([.5, .5], dtype=np.float64)
        low, high = np.array([.25, .25]), np.array([.75, .75])
        hybrid = compile_hybrid(kernel, q, low, high)
        self.assertEqual(hybrid.source_positions, ())
        self.assertEqual(hybrid.epsilon_source, 0.)
        self.assertEqual(expected_flags(kernel, q, low, high, hybrid),
                         expected_flags(kernel, q, low, high))
        self.assertEqual(hybrid.combine_upper(.125), min(hybrid.epsilon_scope, .125))

    def test_unchanged_static_fee_and_outward_composition(self):
        kernel, q, low, high = improving_fixture()
        hybrid = compile_hybrid(kernel, q, low, high)
        cost = kernel.compilation_summary
        expected = 96 * (2 * len(q) + 2 * cost["interval_incidence_entries"] + 64 * 2)
        self.assertEqual(hybrid.event_work_upper(96), expected)
        upper = .1
        combined = hybrid.combine_upper(upper)
        exact_sum = Fraction.from_float(hybrid.epsilon_source) + Fraction.from_float(upper)
        self.assertGreaterEqual(Fraction.from_float(combined), exact_sum)
        self.assertLessEqual(combined, hybrid.epsilon_scope)
        self.assertTrue(hybrid.metadata["additional_preparation_must_be_charged_in_wall_time"])

    def test_prepared_overload_and_invalid_assumptions_fail_closed(self):
        kernel, q, low, high = improving_fixture()
        prepared = SimpleNamespace(kernel=kernel, q=q, low=low, high=high)
        self.assertEqual(compile_hybrid(prepared).source_positions, (0,))
        with self.assertRaisesRegex(ValueError, "independent"):
            compile_hybrid(kernel, q, low, high, dependence="shared_factor")
        with self.assertRaises(ValueError):
            compile_hybrid(kernel, q.astype(np.float32), low, high)
        with self.assertRaises(ValueError):
            compile_hybrid(kernel, q, high, low)
        hybrid = compile_hybrid(prepared)
        with self.assertRaises(ValueError):
            hybrid.combine_upper(float("nan"))


if __name__ == "__main__":
    unittest.main()
