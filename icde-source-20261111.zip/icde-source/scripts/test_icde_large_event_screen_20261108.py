from fractions import Fraction as Q
import unittest
from icde_large_event_screen_20261108 import event_gap_interval,admission


class EventScreenTest(unittest.TestCase):
    def test_cell_cover_robust_gap_is_minimum_across_cells(self):
        # Exact probabilities at two parameter representatives.
        cells=[([6,3,1],[6,3,1]),([5,4,1],[5,4,1])]
        result=event_gap_interval(cells,0,10)
        self.assertEqual(Q(result['lower_gap_exact']),Q(1,10))
        self.assertEqual(result['lower_gap_exact'],result['upper_gap_exact'])
        self.assertLessEqual(Q.from_float(result['lower_gap']),Q(1,10))
        self.assertGreaterEqual(Q.from_float(result['upper_gap']),Q(1,10))

    def test_large_joint_state_count_does_not_force_factor_rejection(self):
        base={'retained_candidates':20,'reconstructed_group_count':30,'group_size_histogram':{'1':30}}
        self.assertTrue(admission(base)['admitted'])
        base['retained_candidates']=15000
        self.assertFalse(admission(base)['admitted'])


if __name__=='__main__':unittest.main()
