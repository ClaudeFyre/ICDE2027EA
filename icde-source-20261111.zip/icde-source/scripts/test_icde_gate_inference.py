"""Exact finite fixtures for direct mode tests and positive-gap inference."""

from fractions import Fraction
from itertools import product
import math
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from icde_gate_inference import (
    DEFAULT_CHECKPOINTS, numerical_gap_bound, numerical_gap_details,
    ppr_certified, ppr_details, ppr_pair_ratio,
)


class GateInferenceTests(unittest.TestCase):
    def test_exact_uniform_and_jeffreys_ratios_at_known_counts(self):
        self.assertEqual(ppr_pair_ratio(0, 0), 1)
        self.assertEqual(ppr_pair_ratio(3, 0), 2)
        self.assertEqual(ppr_pair_ratio(2, 1), Fraction(2, 3))
        self.assertEqual(ppr_pair_ratio(2, 0, prior="jeffreys"), Fraction(3, 2))
        self.assertEqual(ppr_pair_ratio(1, 1, prior="jeffreys"), Fraction(1, 2))
        self.assertTrue(ppr_certified([3, 0], 3, Fraction(1, 2)))
        self.assertFalse(ppr_certified([3, 0], 3, Fraction(1, 2) - Fraction(1, 1000)))

    def test_no_observation_single_observation_and_ties_do_not_certify(self):
        for counts in ([0, 0, 0], [1, 0, 0], [10, 10, 0]):
            self.assertFalse(ppr_certified(counts, sum(counts), .05))
        self.assertEqual(numerical_gap_bound([0, 0], 0, .05), -1.)
        self.assertEqual(numerical_gap_bound([1, 0], 1, .05, "empirical_bernstein"), -1.)

    def test_structural_single_category_requires_no_sampling(self):
        self.assertTrue(ppr_certified([0], 0, .05))
        self.assertEqual(numerical_gap_bound([0], 0, .05, "empirical_bernstein"), 1.)

    def test_all_pair_and_published_jain_allocations_are_explicit(self):
        all_pairs = ppr_details([30, 4, 2, 1], 37, Fraction(1, 20))
        original = ppr_details([30, 4, 2, 1], 37, Fraction(1, 20), allocation="jain_mode")
        self.assertEqual(Fraction(all_pairs["alpha_exact"]), Fraction(1, 120))
        self.assertEqual(Fraction(original["alpha_exact"]), Fraction(1, 60))
        self.assertTrue(all_pairs["simultaneous_all_pairs_guarantee"])
        self.assertFalse(original["simultaneous_all_pairs_guarantee"])
        self.assertEqual(original["rule_name"], "jain2022_uniform_PPR_1v1")

    def test_top_two_test_matches_every_competitor_with_rare_and_zero_counts(self):
        for prior in ("uniform", "jeffreys"):
            for counts in ([20, 3, 0, 1], [5, 4, 0, 0], [100, 1, 1, 0], [0, 0, 12, 2]):
                winner = max(range(len(counts)), key=lambda i: (counts[i], -i))
                alpha = Fraction(1, 20) / math.comb(len(counts), 2)
                expected = all(counts[winner] > count and
                               ppr_pair_ratio(counts[winner], count, prior=prior) >= 1 / alpha
                               for index, count in enumerate(counts) if index != winner)
                self.assertEqual(ppr_certified(counts, sum(counts), Fraction(1, 20), prior=prior), expected)

    def test_pair_evidence_does_not_use_unrelated_categorical_observations(self):
        # Keep K fixed and the same leader/runner-up while adding other labels.
        sparse = [20, 5] + [0] * 75
        other_observations = [20, 5] + [1] * 75
        first = ppr_details(sparse, sum(sparse), .05)
        second = ppr_details(other_observations, sum(other_observations), .05)
        self.assertEqual(first["pair_samples"], 25)
        self.assertEqual(first["log_ppr_at_half_diagnostic"], second["log_ppr_at_half_diagnostic"])
        self.assertEqual(first["certified"], second["certified"])

    def test_large_support_has_a_nonvacuous_mode_test_without_float_overflow(self):
        counts = [64] + [0] * 14999
        self.assertTrue(ppr_certified(counts, 64, .05, allocation="jain_mode"))
        self.assertLess(numerical_gap_bound(counts, 64, .05), 0)
        self.assertTrue(ppr_certified([4096, 0, 0], 4096, .05, prior="jeffreys"))

    def test_normal_mixture_agrees_with_the_declared_reference(self):
        counts = [600, 300, 100]
        n, delta, rho = 1000, .05, 64.
        alpha = delta / 3
        reference = .3 - math.sqrt((n + rho) * math.log((n + rho) / (rho * alpha * alpha))) / n
        actual = numerical_gap_bound(counts, n, delta, {"name": "normal_mixture", "rho": rho})
        self.assertAlmostEqual(actual, reference, places=14)

    def test_empirical_bernstein_range_two_constant_and_exact_variance(self):
        counts, n = [180, 50, 26], 256
        delta = Fraction(1, 20)
        rule = {"name": "empirical_bernstein", "checkpoints": [32, 96, 256]}
        details = numerical_gap_details(counts, n, delta, rule)
        variance = Fraction((180 + 50) * n - 130 ** 2, n * (n - 1))
        self.assertEqual(Fraction(details["sample_variance_exact"]), variance)
        alpha = delta / (2 * 3 * 3)
        self.assertEqual(Fraction(details["alpha_per_direction_and_checkpoint_exact"]), alpha)
        log_term = math.log(float(2 / alpha))
        reference = 130 / n - math.sqrt(2 * float(variance) * log_term / n) - 14 * log_term / (3 * (n - 1))
        self.assertAlmostEqual(details["lower_gap"], reference, places=14)

    def test_positive_gap_is_numerical_and_unprotected_checks_fail_closed(self):
        rule = {"name": "empirical_bernstein", "checkpoints": [32, 96, 992]}
        gap = numerical_gap_bound([992, 0], 992, .05, rule)
        self.assertGreater(gap, .5)
        with self.assertRaisesRegex(ValueError, "not a protected"):
            numerical_gap_bound([993, 0], 993, .05, rule)
        with self.assertRaisesRegex(ValueError, "PPR"):
            numerical_gap_bound([100, 0], 100, .05, "ppr")
        self.assertEqual(len(DEFAULT_CHECKPOINTS), 65)

    def test_exact_finite_horizon_optional_stopping_under_a_tied_bernoulli(self):
        # Any declared unique mode is wrong under p=1/2. Enumerate all paths,
        # rather than treating the last prefix alone as the stopping event.
        horizon, wrong = 12, 0
        for sequence in product((0, 1), repeat=horizon):
            counts = [0, 0]
            for n, label in enumerate(sequence, 1):
                counts[label] += 1
                if ppr_certified(counts, n, Fraction(1, 20)):
                    wrong += 1
                    break
        self.assertGreater(wrong, 0)
        self.assertLessEqual(Fraction(wrong, 2 ** horizon), Fraction(1, 20))

    def test_exact_binomial_false_certificate_mass_for_fixed_checkpoint_bound(self):
        n, wrong_mass = 64, 0
        rule = {"name": "empirical_bernstein", "checkpoints": [n]}
        for a in range(n + 1):
            if numerical_gap_bound([a, n - a], n, Fraction(1, 20), rule) > 0:
                wrong_mass += math.comb(n, a)
        self.assertGreater(wrong_mass, 0)
        self.assertLessEqual(Fraction(wrong_mass, 2 ** n), Fraction(1, 20))

    def test_invalid_count_risk_and_checkpoint_inputs_are_rejected(self):
        for counts, n in (([1, 2], 4), ([-1, 2], 1), ([True, 0], 1), ([], 0)):
            with self.assertRaises(ValueError):
                ppr_certified(counts, n, .05)
        with self.assertRaises(ValueError):
            numerical_gap_bound([100, 0], 100, 0.)
        with self.assertRaises(ValueError):
            numerical_gap_bound([100, 0], 100, .05,
                                {"name": "empirical_bernstein", "checkpoints": [100, 100]})


if __name__ == "__main__":
    unittest.main()
