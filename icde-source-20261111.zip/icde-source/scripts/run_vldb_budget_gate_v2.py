"""Fresh paired nominal/event captures for the frozen V2 logical-work gate.

All methods consume the same per-run U prefix.  Every prefix event observation
is paid for in that run.  Full-cap capture timings are offline measurements;
policy replay uses an explicit logical work model, not online wall-clock time.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import time
from collections import defaultdict
from pathlib import Path

import numpy as np

from run_vldb_interval_gate_v1 import (
    _array_hash, _inside, _write_new, audit_candidate_preservation,
    build_selected_backbone, clipped_box, conservative_scope_tv,
)
from vldb_capture_attribute_v0 import build_degree_kernel, stream_seed
from vldb_stream_frontier_v0 import _verify_scope, file_sha256
from pkgea.contracts import dataset_revision_digest
from pkgea.scope import build_incident_degree_certificate


SCHEMA = "vldb-paired-budget-gate-v2"


def source_candidate_overlap(kernel) -> dict:
    source_out, source_in = map(set, kernel.incidence_positions[:2])
    pair_count = len(kernel.candidates)
    shared_pairs = maximum = out_out = in_in = out_in = in_out = 0
    for column in range(pair_count):
        target_out = set(kernel.incidence_positions[2 + 2 * column])
        target_in = set(kernel.incidence_positions[3 + 2 * column])
        oo, ii = source_out & target_out, source_in & target_in
        oi, io = source_out & target_in, source_in & target_out
        shared = oo | ii | oi | io
        shared_pairs += bool(shared)
        maximum = max(maximum, len(shared))
        out_out += len(oo)
        in_in += len(ii)
        out_in += len(oi)
        in_out += len(io)
    return {
        "source_candidate_pairs": pair_count, "pairs_with_shared_incident_edge": shared_pairs,
        "maximum_pair_shared_incident_edges": maximum,
        "source_out_target_out": out_out, "source_in_target_in": in_in,
        "source_out_target_in": out_in, "source_in_target_out": in_out,
        "precision_implication": "No source-target edge-coefficient cancellation when all intersections are zero.",
    }


def _check_flags(value: np.ndarray, n: int, name: str) -> np.ndarray:
    if not isinstance(value, np.ndarray) or value.dtype != np.bool_ or value.shape != (n,):
        raise ValueError(f"{name} must be a Boolean array with one entry per U row")
    return value


def _check_counts(value: np.ndarray, n: int, name: str) -> np.ndarray:
    if not isinstance(value, np.ndarray) or value.dtype.kind not in "iu" or value.shape != (n,) or np.any(value < 0):
        raise ValueError(f"{name} must be nonnegative integer work counts per U row")
    return value.astype(np.int64, copy=False)


def capture_paired_stream(compiled, q: np.ndarray, boxes: list[dict], *, seed: int,
                          sample_count: int, chunk_size: int, source_indicator,
                          max_source_assignments: int = 4) -> dict:
    """Generate U once and share cached nominal scores with both event cores."""
    if q.dtype != np.float64 or q.shape != (len(compiled.edge_indices),) or not np.isfinite(q).all() or np.any((q < 0) | (q > 1)):
        raise ValueError("q must match the frozen float64 scope order")
    if sample_count <= 0 or chunk_size <= 0:
        raise ValueError("sample and chunk counts must be positive")
    if not boxes or len({box["tau"] for box in boxes}) != len(boxes):
        raise ValueError("need distinct frozen tau boxes")
    rng = np.random.default_rng(seed)
    uniforms_hash = hashlib.sha256()
    winners = []
    records = [{
        "tau": box["tau"], "epsilon_scope_upper": box["epsilon_scope_upper"],
        "epsilon_full_graph_upper": box["epsilon_full_graph_upper"],
        "endpoint_audit": box["endpoint_audit"], "h_difference": [],
        "h_source_conditioned": [], "free_flags": [],
        "conditioning_assignment_counts": [], "conditioning_degree_rows": [],
        "difference_fullcap_seconds": 0.0, "source_conditioned_fullcap_seconds": 0.0,
    } for box in boxes]
    sampling_seconds = nominal_seconds = 0.0
    started = time.perf_counter()
    for begin in range(0, sample_count, chunk_size):
        count = min(chunk_size, sample_count - begin)
        before = time.perf_counter()
        uniforms = rng.random((count, len(q)), dtype=np.float64)
        uniforms_hash.update(uniforms.tobytes(order="C"))
        sampling_seconds += time.perf_counter() - before
        before = time.perf_counter()
        scores = compiled.scores(uniforms < q[None, :])
        if scores.dtype != np.float64 or scores.shape != (count, len(compiled.candidates)) or not np.isfinite(scores).all():
            raise ValueError("compiled nominal scorer returned an invalid matrix")
        winners.extend(int(value) for value in np.argmax(scores, axis=1))
        nominal_seconds += time.perf_counter() - before
        for box, record in zip(boxes, records):
            before = time.perf_counter()
            difference = _check_flags(compiled.ambiguity_indicators(q, box["low"], box["high"], uniforms, nominal_scores=scores), count, "difference flags")
            record["difference_fullcap_seconds"] += time.perf_counter() - before
            before = time.perf_counter()
            conditioned, metadata = source_indicator(
                compiled, q, box["low"], box["high"], uniforms,
                nominal_scores=scores, difference_flags=difference,
                max_source_assignments=max_source_assignments,
            )
            conditioned = _check_flags(conditioned, count, "source-conditioned flags")
            free = _check_flags(metadata["free_flags"], count, "free flags")
            assignments = _check_counts(metadata["conditioning_assignment_counts"], count, "conditioning assignment counts")
            degree_rows = _check_counts(metadata["conditioning_degree_rows"], count, "conditioning degree rows")
            if np.any(conditioned & ~difference):
                raise ValueError("source-conditioned refinement contradicts a certified difference row")
            record["source_conditioned_fullcap_seconds"] += time.perf_counter() - before
            record["h_difference"].extend(bool(value) for value in difference)
            record["h_source_conditioned"].extend(bool(value) for value in conditioned)
            record["free_flags"].extend(bool(value) for value in free)
            record["conditioning_assignment_counts"].extend(int(value) for value in assignments)
            record["conditioning_degree_rows"].extend(int(value) for value in degree_rows)
    for record in records:
        record["difference_event_count"] = sum(record["h_difference"])
        record["source_conditioned_event_count"] = sum(record["h_source_conditioned"])
        record["h_difference_sha256"] = _array_hash(np.asarray(record["h_difference"], dtype=np.bool_))
        record["h_source_conditioned_sha256"] = _array_hash(np.asarray(record["h_source_conditioned"], dtype=np.bool_))
    return {
        "winner_indices": winners, "winner_indices_sha256": _array_hash(np.asarray(winners, dtype=np.int64)),
        "tau_records": records, "uniform_sha256": uniforms_hash.hexdigest(),
        "uniform_shape": [sample_count, len(q)],
        "random_uniform_draws": sample_count * len(q), "additional_event_random_draws": 0,
        "nominal_score_rows_evaluated": sample_count,
        "nominal_scores_shared_with_all_event_cores": True,
        "fullcap_offline_timing": {
            "uniform_generation_and_hash_seconds": sampling_seconds,
            "nominal_score_and_argmax_seconds": nominal_seconds,
            "capture_total_seconds": time.perf_counter() - started,
            "is_online_stopped_policy_latency": False,
        },
    }


def _settings(config: dict) -> dict:
    seeds = tuple(config.get("fresh_nominal_seeds", config.get("seeds", (41, 53))))
    if not seeds or len(set(seeds)) != len(seeds) or any(isinstance(seed, bool) or not isinstance(seed, int) or seed < 0 for seed in seeds):
        raise ValueError("fresh nominal seeds must be distinct nonnegative integers")
    sample_count = config.get("sample_count", 4096)
    chunk_size = config.get("chunk_size", 256)
    if isinstance(sample_count, bool) or not isinstance(sample_count, int) or sample_count <= 0 or isinstance(chunk_size, bool) or not isinstance(chunk_size, int) or chunk_size <= 0:
        raise ValueError("sample and chunk counts must be positive integers")
    taus = tuple(float(value) for value in config["tau_grid"])
    if not taus or len(set(taus)) != len(taus) or any(not math.isfinite(value) or not 0 < value < 1 for value in taus):
        raise ValueError("frozen tau boxes must be distinct and in (0,1)")
    return {**config, "fresh_nominal_seeds": seeds, "sample_count": sample_count,
            "chunk_size": chunk_size, "tau_grid": taus,
            "seed_purpose": config.get("seed_purpose", "v2_budget_worlds"),
            "max_source_assignments": config.get("max_source_assignments", 4)}


def aggregate_policy_rows(rows: list[dict]) -> list[dict]:
    if not rows:
        return []
    keys = sorted({(row["graph"], row["tau"], row["budget_fraction"], row["interval_work_weight"], row["policy"]) for row in rows})
    result = []
    for graph, tau, budget, weight, policy in keys:
        selected = [row for row in rows if (row["graph"], row["tau"], row["budget_fraction"], row["interval_work_weight"], row["policy"]) == (graph, tau, budget, weight, policy)]
        result.append({
            "graph": graph, "tau": tau, "budget_fraction": budget,
            "interval_work_weight": weight, "policy": policy,
            "query_seed_cases": len(selected),
            "unique_queries": len({row["query_id"] for row in selected}),
            "stable_count": sum(bool(row["stable"]) for row in selected),
            "coverage": sum(bool(row["stable"]) for row in selected) / len(selected),
            "nontrivial_stable_count": sum(bool(row["stable"]) and row["candidate_count"] > 1 for row in selected),
            "samples_used": sum(row["samples_used"] for row in selected),
            "event_samples_used": sum(row["event_samples_used"] for row in selected),
            "work_used": sum(row["work_used"] for row in selected),
            "work_budget": sum(row["work_budget"] for row in selected),
            "work_budget_overshoot_cases": sum(row["work_used"] > row["work_budget"] + 1e-9 for row in selected),
            "certified_past_budget_cases": sum(bool(row["stable"]) and row["work_used"] > row["work_budget"] + 1e-9 for row in selected),
            "status_counts": {status: sum(row["status"] == status for row in selected) for status in sorted({row["status"] for row in selected})},
            "interpretation": "Descriptive query-seed cases; no wall-clock equal-budget conclusion.",
        })
    return result


def run_budget_gate(config: dict, root: str | Path, output_dir: str | Path) -> dict:
    from vldb_difference_envelope_v2 import compile_difference_kernel
    from vldb_source_conditioned_v2 import source_conditioned_indicators
    from vldb_budget_policy_v2 import run_budget_policy

    root = Path(root).resolve()
    output = _inside(root, output_dir)
    settings = _settings(config)
    if os.environ.get("PYTHONHASHSEED") != str(config.get("required_pythonhashseed", "0")):
        raise ValueError("use the frozen Python hash seed for original TF-IDF arithmetic")
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("use a fresh V2 artifact directory")
    output.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    groups = defaultdict(list)
    for specification in config["stream_manifests"]:
        path = _inside(root, specification["path"])
        if file_sha256(path) != specification["sha256"]:
            raise ValueError("frozen V0 manifest changed")
        manifest = json.loads(path.read_text(encoding="utf-8"))
        dataset = _inside(root, manifest["dataset_path"])
        if manifest["schema_version"] != "vldb-categorical-stream-v1" or dataset_revision_digest(dataset) != manifest["dataset_revision"]:
            raise ValueError("V0 schema or actual input revision differs")
        if manifest["world_law"].get("dependence") != "independent" or manifest["world_law"].get("semantics") != "declared":
            raise ValueError("V2 only supports the frozen declared independent law")
        for name, expected in manifest["implementation_sha256"].items():
            if file_sha256(_inside(root, name)) != expected:
                raise ValueError("inherited V0 implementation identity changed")
        for name, expected in manifest["input_sha256"].items():
            if file_sha256(dataset / name) != expected:
                raise ValueError("inherited dataset file changed")
        groups[(manifest["graph"], manifest["dataset_path"], manifest["dataset_revision"])].append(manifest)
    if not groups:
        raise ValueError("explicit V0 manifests are required")
    identity_seconds = time.perf_counter() - started
    builds, query_audits, raw_files, policy_rows, captures = [], [], [], [], []
    io_seconds = policy_seconds = 0.0
    for (graph, dataset_path, revision), manifests in groups.items():
        first = manifests[0]
        ids = tuple(row["query_id"] for row in first["queries"])
        if not ids or len(set(ids)) != len(ids):
            raise ValueError("V0 query identities must be unique")
        for manifest in manifests:
            if tuple(row["query_id"] for row in manifest["queries"]) != ids or manifest["scorer"] != first["scorer"]:
                raise ValueError("V0 manifests do not share the fixed query/scorer identities")
            for left, right in zip(first["queries"], manifest["queries"]):
                _verify_scope(right, manifest)
                if left["candidate_ids"] != right["candidate_ids"] or left["scope_edge_indices"] != right["scope_edge_indices"]:
                    raise ValueError("V0 nominal seeds changed candidates or scope")
        dataset = _inside(root, dataset_path)
        backbone, reconstruction = build_selected_backbone(dataset, ids, attribute_weight=float(first["scorer"]["attribute_weight"]))
        probabilities = np.asarray([float(row["confidence"]) for row in backbone.triples], dtype=np.float64)
        full_edges = len(backbone.triples)
        if full_edges != first["full_edge_count"]:
            raise ValueError("full edge count differs from V0")
        full_bounds = {}
        before = time.perf_counter()
        for tau in settings["tau_grid"]:
            lo, hi = clipped_box(probabilities, tau)
            full_bounds[tau] = conservative_scope_tv(probabilities, lo, hi)[0]
        reconstruction["full_graph_box_bound_seconds"] = time.perf_counter() - before
        builds.append({"graph": graph, "dataset_revision": revision, **reconstruction})
        for row in first["queries"]:
            source = row["query_id"]
            candidates = tuple(row["candidate_ids"])
            indices = tuple(row["scope_edge_indices"])
            certificate, selected = build_incident_degree_certificate(
                backbone.triples, dataset_revision=revision, query_id=source,
                candidates=candidates, scorer_id=first["scorer"]["id"], scorer_version=first["scorer"]["version"],
            )
            if tuple(sorted(selected)) != indices or certificate.certificate_sha256 != row["scope_certificate"]["certificate_sha256"]:
                raise ValueError("reconstructed complete scope differs from V0")
            pruning = audit_candidate_preservation(backbone, source, candidates)
            if pruning["status"] != "PASS":
                return {"schema_version": SCHEMA, "status": "V2_FAIL_CANDIDATE_PRUNING", "graph": graph, "query_id": source, "candidate_audit": pruning, "policy_results_interpreted": False}
            before = time.perf_counter()
            kernel = build_degree_kernel(backbone, source, candidates, indices)
            compiled = compile_difference_kernel(kernel)
            compilation_seconds = time.perf_counter() - before
            q = probabilities[list(indices)]
            overlap = source_candidate_overlap(kernel)
            boxes = []
            for tau in settings["tau_grid"]:
                lo, hi = clipped_box(q, tau)
                epsilon, audit = conservative_scope_tv(q, lo, hi)
                boxes.append({"tau": tau, "low": lo, "high": hi, "epsilon_scope_upper": epsilon,
                              "epsilon_full_graph_upper": full_bounds[tau], "endpoint_audit": audit})
            summary = compiled.compilation_summary
            cost_model = {
                "original_incidence_entries": summary["original_incidence_entries"],
                "interval_incidence_entries": summary["interval_incidence_entries"],
                "source_incidence_entries": sum(len(value) for value in kernel.incidence_positions[:2]),
                "candidate_count": len(candidates), "scope_edge_count": len(indices),
            }
            query_audits.append({"graph": graph, "query_id": source, "candidate_pruning_audit": pruning,
                                 "source_candidate_incident_overlap": overlap, "compilation": summary,
                                 "measured_one_compilation_seconds": compilation_seconds,
                                 "policy_declares_a_common_plan_initialization_charge_per_run": True,
                                 "measured_compilation_is_not_an_online_amortization_claim": True})
            for nominal_seed in settings["fresh_nominal_seeds"]:
                derived = stream_seed(graph, revision, source, nominal_seed, settings["seed_purpose"])
                captured = capture_paired_stream(
                    compiled, q, boxes, seed=derived, sample_count=settings["sample_count"],
                    chunk_size=settings["chunk_size"], source_indicator=source_conditioned_indicators,
                    max_source_assignments=settings["max_source_assignments"],
                )
                record = {
                    "schema_version": "vldb-paired-query-stream-v2", "graph": graph,
                    "dataset_revision": revision, "query_id": source, "nominal_seed": nominal_seed,
                    "candidate_ids": list(candidates), "candidate_count": len(candidates),
                    "scope_edge_count": len(indices), "full_edge_count": full_edges,
                    "scope_edge_indices": list(indices), "scope_certificate": certificate.as_dict(),
                    "rng_seed_hex": hex(derived), "seed_purpose": settings["seed_purpose"],
                    "world_law": first["world_law"], "cost_model": cost_model,
                    "same_U_for_nominal_and_events": True, "event_samples_shared_across_seeds": False,
                    **captured,
                }
                slug = re.sub(r"[^a-z0-9]+", "_", graph.casefold()).strip("_")
                name = f"paired_{slug}_{hashlib.sha256(source.encode()).hexdigest()[:16]}_s{nominal_seed}.json"
                path = output / name
                io_seconds += _write_new(path, record)
                raw_files.append({"path": path.relative_to(root).as_posix(), "sha256": file_sha256(path)})
                before = time.perf_counter()
                rows = run_budget_policy(record, settings)
                policy_seconds += time.perf_counter() - before
                for policy in rows:
                    policy_rows.append({"graph": graph, "query_id": source, "nominal_seed": nominal_seed,
                                        "candidate_count": len(candidates), **policy})
                captures.append({
                    "graph": graph, "query_id": source, "nominal_seed": nominal_seed,
                    "uniform_sha256": captured["uniform_sha256"], "random_uniform_draws": captured["random_uniform_draws"],
                    "additional_event_random_draws": 0, "fullcap_offline_timing": captured["fullcap_offline_timing"],
                    "tau_event_counts": [{"tau": item["tau"], "difference": item["difference_event_count"],
                                          "source_conditioned": item["source_conditioned_event_count"],
                                          "difference_seconds": item["difference_fullcap_seconds"],
                                          "source_conditioned_additional_seconds": item["source_conditioned_fullcap_seconds"]}
                                         for item in captured["tau_records"]],
                })
    aggregate = aggregate_policy_rows(policy_rows)
    return {
        "schema_version": SCHEMA, "status": "V2_EXECUTION_COMPLETE",
        "unique_queries": len(query_audits), "fresh_query_seed_runs": len(captures),
        "fresh_nominal_seeds": list(settings["fresh_nominal_seeds"]), "world_cap": settings["sample_count"],
        "dataset_reconstruction_costs": builds, "query_audits": query_audits,
        "raw_paired_stream_files": raw_files, "captures": captures, "policy_rows": policy_rows,
        "aggregate": aggregate,
        "additional_event_random_draws": 0,
        "total_random_uniform_draws": sum(row["random_uniform_draws"] for row in captures),
        "source_candidate_overlap": {
            "retained_pairs": sum(row["source_candidate_incident_overlap"]["source_candidate_pairs"] for row in query_audits),
            "pairs_with_shared_incident_edge": sum(row["source_candidate_incident_overlap"]["pairs_with_shared_incident_edge"] for row in query_audits),
            "directed_coordinate_cancellations": sum(row["compilation"]["shared_coordinate_cancellations"] for row in query_audits),
        },
        "cost": {"input_identity_seconds": identity_seconds, "paired_capture_io_seconds": io_seconds,
                 "logical_policy_replay_seconds": policy_seconds, "total_offline_wall_seconds": time.perf_counter() - started,
                 "policy_budget_unit": "explicit_logical_work", "same_walltime_advantage_claim": False,
                 "event_cost_amortized_across_seeds": False,
                 "full_cap_generation_is_online_stopping_measurement": False},
        "all_candidate_outward_pruning_pass": True, "new_training": False,
        "real_probability_calibration_claim": False, "IJCAI_research_resumed": False,
    }
