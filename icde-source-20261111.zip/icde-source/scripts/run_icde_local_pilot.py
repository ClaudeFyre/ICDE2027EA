"""Small, portable E0/E1 correctness pilot. No formal timing claims."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from pkgea.backbones.toy import ToyStructuralBackbone
from pkgea.contracts import dataset_content_digest
from pkgea.evaluation.objectives import estimate_objectives
from pkgea.query.modal import (
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    WinnerBlockCache,
    execute_modal_queries,
    identity,
    world_winner,
)
from pkgea.samplers import exact_worlds, monte_carlo_worlds

ROOT = Path(__file__).resolve().parents[1]


def run(output: Path, budget: int, seed: int) -> None:
    if output.exists():
        raise ValueError("output already exists; use a fresh attempt directory")
    output.mkdir(parents=True)
    dataset = ROOT / "data/toy/exact_world_minimal"
    backbone = ToyStructuralBackbone.from_dataset(dataset)
    probabilities = tuple(float(row["confidence"]) for row in backbone.triples)
    source_files = [
        "src/pkgea/query/modal.py",
        "src/pkgea/certified.py",
        "src/pkgea/samplers/core.py",
        "src/pkgea/backbones/toy.py",
        "scripts/run_icde_local_pilot.py",
    ]
    hashes = {f: hashlib.sha256((ROOT / f).read_bytes()).hexdigest() for f in source_files}
    snapshot = ModalSnapshot(
        dataset_content_digest(dataset),
        "no-trained-model",
        identity(probabilities),
        "independent",
        "canonical-v1",
        identity(hashes),
        "toy-degree-lexical-original-float",
    )
    start = time.perf_counter()
    worlds = tuple(monte_carlo_worlds(probabilities, budget, seed))
    sample_time = time.perf_counter() - start
    stream = IIDWorldStream(snapshot.digest, seed, worlds)
    queries = [
        ModalQuery(source, backbone.target_entities, snapshot.digest, budget)
        for source in backbone.source_entities
    ]
    # Exact enumeration is a weighted target oracle, never CS observations.
    exact = exact_worlds(probabilities)
    objectives = estimate_objectives(exact, backbone.score)
    oracle = {
        s: {
            "probabilities": {
                c: objectives.winner_probability.get((s, c), 0.0) for c in backbone.target_entities
            },
            "expected_scores": {
                c: objectives.expected_score[(s, c)] for c in backbone.target_entities
            },
        }
        for s in backbone.source_entities
    }
    raw = []
    for index, world in enumerate(worlds):
        scores = backbone.score(world.state)
        raw.append(
            {
                "draw": index,
                "state": world.state,
                "winners": {
                    s: world_winner(
                        {c: scores[(s, c)] for c in backbone.target_entities},
                        backbone.target_entities,
                    )
                    for s in backbone.source_entities
                },
            }
        )
    runs = {}
    for name, shared, capacity in [
        ("independent", False, 0),
        ("batched", True, 0),
        ("winner_lru", False, budget * 8),
        ("shared_winner_lru", True, budget * 8),
        ("tiny_lru", True, 64),
    ]:
        cache = WinnerBlockCache(capacity)
        for phase in ("cold_application", "repeat_application"):
            start = time.perf_counter()
            result = execute_modal_queries(
                queries,
                snapshot,
                stream,
                ModalScorer(snapshot.digest, backbone.score_subset),
                shared=shared,
                cache=cache,
            )
            result["engineering_seconds"] = time.perf_counter() - start
            result["cache"] = {
                "capacity_payload_bytes": capacity,
                "peak_payload_bytes": cache.peak_payload_bytes,
                "evictions_cumulative": cache.evictions,
            }
            runs[name + "/" + phase] = result
    reference = runs["independent/cold_application"]["results"]
    equivalent = all(result["results"] == reference for result in runs.values())
    stable_correct = all(
        not r["stable"]
        or r["certified_winner"]
        == max(
            oracle[r["query_id"]]["probabilities"], key=oracle[r["query_id"]]["probabilities"].get
        )
        for r in reference
    )
    # Three distinct answer objects, on an explicit one-dimensional embedding task.
    # Source 0; a=0 on 60% of worlds and a=10 otherwise; b=3 always.
    # Score=1/(1+distance): modal=a and mean-score=a; Gaussian W2 selects b.
    counterexample = {
        "law": {
            "a_embedding_0": 0.6,
            "a_embedding_10": 0.4,
            "source_embedding": 0.0,
            "b_embedding": 3.0,
        },
        "modal": "a",
        "modal_probabilities": {"a": 0.6, "b": 0.4},
        "mean_score": {"a": 0.6 + 0.4 / 11, "b": 0.25},
        "gaussian_squared_w2": {"a": 40.0, "b": 9.0},
    }
    # A second law separates mean score from modal: a wins narrowly most worlds.
    counterexample["mean_modal_separation"] = {
        "world_probabilities": [0.6, 0.4],
        "scores": [[0.51, 0.50], [0.0, 1.0]],
        "modal": "a",
        "mean": "b",
        "expected_scores": [0.306, 0.7],
    }
    # Controlled update -> fresh iid stream -> refreshed query, whole-revision invalidation.
    update_cache = WinnerBlockCache(budget * 8)
    update_trace = []
    old_stream, old_query = None, None
    for revision, p in enumerate((0.9, 0.1, 0.9)):
        current = ModalSnapshot(
            "controlled-edge-v1",
            "no-trained-model",
            identity([p]),
            "independent",
            "canonical-v1",
            identity(hashes),
            "bernoulli-score",
        )
        current_stream = IIDWorldStream(
            current.digest, seed + revision, tuple(monte_carlo_worlds([p], budget, seed + revision))
        )
        current_query = ModalQuery("controlled-source", ("a", "b"), current.digest, budget)

        def controlled_score(state, sources, targets):
            return {(s, t): float(state[0] == (t == "a")) for s in sources for t in targets}

        controlled_scorer = ModalScorer(current.digest, controlled_score)
        rejected = None
        if old_stream is not None:
            try:
                execute_modal_queries([old_query], current, old_stream, controlled_scorer)
            except ValueError:
                rejected = True
            else:
                rejected = False
        fresh = execute_modal_queries(
            [current_query], current, current_stream, controlled_scorer, cache=update_cache
        )
        independent = execute_modal_queries(
            [current_query], current, current_stream, controlled_scorer, shared=False
        )
        update_trace.append(
            {
                "event_id": f"probability-{revision}",
                "revision": revision,
                "probability": p,
                "stale_rejected": rejected,
                "matches_fresh_reference": fresh["results"] == independent["results"],
                "work": fresh["work"],
                "result": fresh["results"][0],
            }
        )
        old_stream, old_query = current_stream, current_query
    near = {"a": 1.0, "b": 1.0 + 1e-8}
    precision = {
        "float64_winner": world_winner(near, ("a", "b")),
        "float32_winner": world_winner(
            {c: float(np.float32(v)) for c, v in near.items()}, ("a", "b")
        ),
    }
    acceptance = {
        "same_stream_all_paths_exact": equivalent,
        "stable_results_match_exhaustive_target": stable_correct,
        "bounded_cache_payload": all(
            r["cache"]["peak_payload_bytes"] <= r["cache"]["capacity_payload_bytes"]
            for r in runs.values()
        ),
        "float_conversion_can_change_winner": precision["float64_winner"]
        != precision["float32_winner"],
    }
    acceptance["update_refresh_query_consistent"] = all(
        row["matches_fresh_reference"]
        and row["stale_rejected"] is not False
        and row["work"]["cache_label_reads"] == 0
        and row["result"]["certified_winner"] == ("a" if row["probability"] > 0.5 else "b")
        for row in update_trace
    )
    sensitivity = {
        s: {
            "positive_mass_winner_count": sum(v > 0 for v in values["probabilities"].values()),
            "winner_world_sensitive": sum(v > 0 for v in values["probabilities"].values()) > 1,
        }
        for s, values in oracle.items()
    }
    payload = {
        "format": "icde-local-correctness-pilot-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "host": {"platform": platform.platform(), "python": sys.version, "numpy": np.__version__},
        "config": {
            "budget": budget,
            "seed": seed,
            "batch_size": 16,
            "minimum_samples": 32,
            "delta": 0.05,
            "dataset": "data/toy/exact_world_minimal",
        },
        "snapshot": asdict(snapshot),
        "source_hashes": hashes,
        "sampling_engineering_seconds": sample_time,
        "oracle_worlds": len(exact),
        "oracle": oracle,
        "counterexamples": counterexample,
        "precision_counterexample": precision,
        "controlled_update_trace": update_trace,
        "toy_world_sensitivity": sensitivity,
        "runs": runs,
        "acceptance": acceptance,
        "claim_boundary": "Toy E0/E1 only. LRU and batching are baselines, not new algorithms; no scale, quality, local-update or durable-query guarantee.",
    }
    (output / "worlds.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in raw))
    (output / "summary.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    manifest = {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir() if p.is_file()
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"acceptance": acceptance, "output": str(output)}, indent=2))
    if not all(acceptance.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--budget", type=int, default=256)
    parser.add_argument("--seed", type=int, default=17)
    args = parser.parse_args()
    run(args.output, args.budget, args.seed)
