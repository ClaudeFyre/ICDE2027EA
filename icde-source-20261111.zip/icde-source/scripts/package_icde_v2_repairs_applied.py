"""Package all artifacts generated in this round (v2 local repairs application)
into a single zip with a SHA256 manifest, per user preference: package all
generated materials into ONE file.
"""
from __future__ import annotations

import hashlib
import io
import json
import zipfile
from pathlib import Path

REPO = Path(r"E:\pkgea")
OUT_ZIP = REPO / "icde_v2_local_repairs_applied_20261009.zip"

# (repo-relative source, archive path)
ENTRIES: list[tuple[Path, str]] = []


def add(src: str, arc: str | None = None) -> None:
    p = REPO / src
    if not p.exists():
        raise FileNotFoundError(src)
    ENTRIES.append((p, arc or src))


# 1) fix record + new guide
add("papers/icde/LOCAL_REPAIR_APPLIED_20261009.md")
add("papers/icde/FRESH_HOST_FINAL_V2_LOCAL_20261009.md")

# 2) repaired source files (applied overlay)
add("src/pkgea/samplers/factor_law.py")
add("scripts/icde_e5_rebuild_v2.py")
add("nodes/05_icde_query_engine/experiments/E3_update_query_mix/runner_revision_v2.py")
add("nodes/05_icde_query_engine/experiments/E6_recovery/run_e6_subprocess_faults.py")
add("tests/test_return_v2_service_semantics.py")

# 3) backups of the pre-repair originals (from staging)
for f in [
    "src/pkgea/samplers/factor_law.py",
    "scripts/icde_e5_rebuild_v2.py",
    "nodes/05_icde_query_engine/experiments/E3_update_query_mix/runner_revision_v2.py",
    "nodes/05_icde_query_engine/experiments/E6_recovery/run_e6_subprocess_faults.py",
]:
    bk = Path(r"E:\pkgea\tmp\icde_v2_repairs_backup_20261009") / f
    if not bk.exists():
        raise FileNotFoundError(bk)
    ENTRIES.append((bk, "backup_pre_repair/" + f))

# 4) E6 Windows-branch verification outputs (freshly run this round)
add("nodes/05_icde_query_engine/results/icde_e6_20261009/subprocess_faults_20261009/analysis.md")
add("nodes/05_icde_query_engine/results/icde_e6_20261009/subprocess_faults_20261009/verification.json")
add("nodes/05_icde_query_engine/results/icde_e6_20261009/subprocess_faults_20261009/output.json")

# 5) test log
add("output/icde_102_tests_20261009.log")

# 6) updated status.toml
add("nodes/05_icde_query_engine/status.toml")

# 7) source patch kit
add("tmp/icde_v2_repairs_20261009/REVIEW.md", "repair_kit/REVIEW.md")
add("tmp/icde_v2_repairs_20261009/REPAIR_MANIFEST.json", "repair_kit/REPAIR_MANIFEST.json")
add("tmp/icde_v2_repairs_20261009/KIT_MANIFEST.json", "repair_kit/KIT_MANIFEST.json")
add("tmp/icde_v2_repairs_20261009/repairs.patch", "repair_kit/repairs.patch")
add("tmp/icde_v2_repairs_20261009/apply_repairs.py", "repair_kit/apply_repairs.py")
add("tmp/icde_v2_repairs_20261009/verify_bundle.py", "repair_kit/verify_bundle.py")
add("tmp/icde_v2_repairs_20261009/FRESH_HOST_GUIDE.md", "repair_kit/FRESH_HOST_GUIDE.md")
add("tmp/icde_v2_repairs_20261009/audit_icde_v2_semantics.py", "repair_kit/audit_icde_v2_semantics.py")


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


manifest: dict[str, str] = {}
if OUT_ZIP.exists():
    OUT_ZIP.unlink()
with zipfile.ZipFile(OUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zf:
    for p, arc in ENTRIES:
        zf.write(p, arc)
        manifest[arc] = sha256(p)
    zf.writestr("BUILT_MANIFEST.json", json.dumps({
        "format": "icde-v2-local-repairs-applied-bundle-v1",
        "date": "2026-10-09",
        "host": "Windows 11 / Python 3.14.5 / numpy (no torch)",
        "base_package": "icde_full_experiment_v2_20261009.zip (sha256 71a2ef9de63a83354432d9d8b46bd1e225010f957905a310c1ed81aa3ca034fb, unmodified)",
        "repair_kit": "icde_v2_local_repairs_20261009.zip",
        "files": manifest,
        "verification": {
            "tests": "102 passed (99 + 3 new regression test_return_v2_service_semantics.py)",
            "e6_windows_branch": "10/10 subprocess fault injections passed (os._exit=91, taskkill=1); no torn reads; verification.json gates all true",
            "status_toml_frozen": "publication_mode=frozen_until_www_operator_refresh unchanged; [icde_v2_local_repairs_20261009] appended",
        },
    }, ensure_ascii=False, indent=2))

with zipfile.ZipFile(OUT_ZIP) as zf:
    total = sum(1 for n in zf.namelist() if not n.endswith("/"))
    crc = zf.testzip()
with open(OUT_ZIP, "rb") as fh:
    zip_sha = sha256(OUT_ZIP)
print(f"wrote {OUT_ZIP}")
print(f"entries: {total} (crc errors: {crc})")
print(f"zip sha256: {zip_sha}")
