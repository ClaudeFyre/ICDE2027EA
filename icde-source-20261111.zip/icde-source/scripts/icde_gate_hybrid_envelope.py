"""Fixed source-partition hybrid drift evidence for the degree scorer.

This is a scorer-specific execution policy built from standard compositional
coupling/TV tools, not a new general abstraction theorem. It assumes independent
Bernoulli coordinates on the unchanged complete scope and a fixed parameter box.
No sampling, fitting, confidence computation or policy selection occurs here.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import hashlib
import math
import time

import numpy as np

from run_vldb_interval_gate_v1 import conservative_scope_tv
from vldb_difference_envelope_v2 import CompiledDifferenceKernel


SCHEMA = "icde-fixed-source-partition-hybrid-envelope-v1"


def _array_hash(array):
    return hashlib.sha256(array.tobytes(order="C")).hexdigest()


def _probability_vector(value, name, m):
    if (not isinstance(value, np.ndarray) or value.dtype != np.float64
            or value.shape != (m,) or not np.isfinite(value).all()):
        raise ValueError(f"{name} must be a finite float64 vector in the complete edge order")
    result = value.copy()
    result.setflags(write=False)
    return result


def _sum_upper(left, right):
    exact = Fraction.from_float(left) + Fraction.from_float(right)
    if exact >= 1:
        return 1.
    result = float(exact)
    if Fraction.from_float(result) < exact:
        result = math.nextafter(result, math.inf)
    return result


@dataclass(frozen=True)
class HybridEnvelope:
    kernel: CompiledDifferenceKernel
    q: np.ndarray
    low_T: np.ndarray
    high_T: np.ndarray
    source_positions: tuple[int, ...]
    epsilon_source: float
    epsilon_scope: float
    metadata: dict

    def indicators(self, uniforms, nominal_scores=None):
        """Evaluate paid h_T, keeping original full-q nominal scores intact."""
        return self.kernel.ambiguity_indicators(
            self.q, self.low_T, self.high_T, uniforms, nominal_scores=nominal_scores)

    def free_flags(self, uniforms):
        """Actual hybrid free rows for the unchanged fee formula, after admission."""
        if (not isinstance(uniforms, np.ndarray) or uniforms.dtype != np.float64
                or uniforms.ndim != 2 or uniforms.shape[1] != len(self.q)
                or not np.isfinite(uniforms).all()
                or np.any((uniforms < 0) | (uniforms >= 1))):
            raise ValueError("uniforms must be a valid float64 complete-scope block")
        return np.any((uniforms < self.low_T[None, :])
                      != (uniforms < self.high_T[None, :]), axis=1)

    def effective_epsilon(self, event_upper):
        """Combine one protected upper bound on E[h_T] with deterministic TV."""
        if isinstance(event_upper, (bool, np.bool_)):
            raise ValueError("event upper bound cannot be Boolean")
        bound = float(event_upper)
        if not math.isfinite(bound) or not 0 <= bound <= 1:
            raise ValueError("event upper bound must lie in [0,1]")
        return min(self.epsilon_scope, _sum_upper(self.epsilon_source, bound), 1.)

    combine_upper = effective_epsilon

    def event_work_upper(self, rows, *, interval_candidate_units=64, weight=1.):
        """The same worst-case event fee as the full generic implementation.

        In particular m is the original complete-scope width, not |T|. Hybrid
        preparation must additionally be timed; this function supplies no fee
        discount for deterministic source handling or reused confidence work.
        """
        if type(rows) is not int or rows < 0:
            raise ValueError("rows must be a nonnegative integer")
        if type(interval_candidate_units) is not int or interval_candidate_units < 0:
            raise ValueError("candidate work units must be nonnegative integers")
        if isinstance(weight, bool) or not math.isfinite(weight) or weight <= 0:
            raise ValueError("weight must be positive and finite")
        cost = self.kernel.compilation_summary
        m, k = len(self.q), len(self.kernel.candidates)
        return rows * (2 * m + 2 * cost["interval_incidence_entries"]
                       + interval_candidate_units * k) * weight


def compile_hybrid(kernel, q=None, low=None, high=None, *, dependence="independent"):
    """Prepare h_T with source incident coordinates frozen at q in its box.

    Call either compile_hybrid(compiled_kernel, q, low, high) or
    compile_hybrid(prepared_query). The original q remains unchanged: setting
    box endpoints to q does not fix source realizations across nominal worlds.
    They are still X_S(q,U_S), shared across all candidate comparisons.
    """
    started = time.perf_counter()
    if q is None and low is None and high is None:
        prepared = kernel
        if not all(hasattr(prepared, name) for name in ("kernel", "q", "low", "high")):
            raise ValueError("provide a prepared query or the kernel and all three parameter vectors")
        kernel, q, low, high = prepared.kernel, prepared.q, prepared.low, prepared.high
    if dependence != "independent":
        raise ValueError("this hybrid contract requires independent Bernoulli coordinates")
    if not isinstance(kernel, CompiledDifferenceKernel):
        raise ValueError("hybrid currently supports the frozen compiled degree scorer only")
    m = len(kernel.edge_indices)
    q = _probability_vector(q, "q", m)
    low = _probability_vector(low, "low", m)
    high = _probability_vector(high, "high", m)
    if np.any((low < 0) | (low > q) | (q > high) | (high > 1)):
        raise ValueError("box must lie in [0,1] and contain q")
    source = tuple(sorted(set(map(int, kernel.incidence_positions[0]))
                          | set(map(int, kernel.incidence_positions[1]))))
    if any(index < 0 or index >= m for index in source):
        raise ValueError("source incidence lies outside the complete scope")
    positions = np.asarray(source, dtype=np.intp)
    low_T, high_T = low.copy(), high.copy()
    low_T[positions], high_T[positions] = q[positions], q[positions]
    source_epsilon, source_audit = conservative_scope_tv(q[positions], low[positions], high[positions])
    scope_epsilon, scope_audit = conservative_scope_tv(q, low, high)
    low_T.setflags(write=False)
    high_T.setflags(write=False)
    metadata = {
        "schema_version": SCHEMA,
        "partition": "fixed_union_of_source_in_and_out_incidence_positions",
        "partition_chosen_from_observed_worlds": False,
        "source_positions": list(source), "source_coordinate_count": len(source),
        "remaining_coordinate_count": m - len(source), "complete_scope_width": m,
        "candidate_count": len(kernel.candidates),
        "source_target_shared_edges": "included_in_source_partition_and_frozen_in_h_T_box",
        "world_law_requirement": "independent_Bernoulli_coordinates_product_parameter_box",
        "nominal_probability_sha256": _array_hash(q),
        "original_low_sha256": _array_hash(low), "original_high_sha256": _array_hash(high),
        "hybrid_low_sha256": _array_hash(low_T), "hybrid_high_sha256": _array_hash(high_T),
        "epsilon_source_upper": source_epsilon, "epsilon_scope_upper": scope_epsilon,
        "source_TV_audit": source_audit, "scope_TV_audit": scope_audit,
        "event_mean_target": "E_U[h_T(U)]_with_nominal_source_realizations_X_S(q,U_S)",
        "combined_bound": "min(epsilon_scope,epsilon_source+protected_upper_E_h_T,1)",
        "event_risk": "one_fixed_hybrid_policy_own_beta_over_protected_complete_prefixes",
        "generic_and_hybrid_observed_minimum_without_extra_risk_allocation": False,
        "original_nominal_scorer_and_winner_distribution_changed": False,
        "event_fee": "same_full_m_incidence_candidate_formula_as_generic; actual_hybrid_free_rows",
        "additional_preparation_must_be_charged_in_wall_time": True,
        "cost_model": kernel.compilation_summary,
        "setup_seconds": time.perf_counter() - started,
        "generic_theorem_novelty_claim": False,
    }
    return HybridEnvelope(kernel, q, low_T, high_T, source, source_epsilon,
                          scope_epsilon, metadata)
