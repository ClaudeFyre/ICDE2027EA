"""Paired online generic/hybrid event policies with independently valid risks.

The generic controls call the frozen comparison core unchanged. The hybrid
core below explicitly adds deterministic source TV to its own protected h_T
upper bound. It does not proxy an event function while omitting source drift.
"""

from __future__ import annotations

import time
MODULE_STARTED = time.perf_counter()
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys

import numpy as np

from icde_online_execution import ROOT, _segments, settings_from_config, setup_graph
from icde_gate_comparison_runner import actual_checkpoints, run_case, write_json
from icde_gate_hybrid_envelope import HybridEnvelope, compile_hybrid
import icde_gate_inference as inference
import vldb_event_bound_v2 as event_bounds
from vldb_capture_attribute_v0 import CANONICAL_FILES, file_sha256, stream_seed
from run_vldb_interval_gate_v1 import _inside
from pkgea.contracts import dataset_revision_digest


POLICIES = ("normal_event", "normal_hybrid", "eb_event", "eb_hybrid")
HYBRID_POLICIES = ("normal_hybrid", "eb_hybrid")
SCHEMA = "icde-fixed-partition-hybrid-online-gate-v1"
PURPOSE = "icde-gate-controls-v1"


def prepare_settings(config, query_count=None):
    raw = {"query_count": 16, "seeds": [97, 109, 127], "seed_purpose": PURPOSE,
           "policies": list(POLICIES), **config}
    if query_count is not None:
        raw["query_count"] = query_count
    settings = settings_from_config(raw)
    if settings["query_count"] not in (16, 32):
        raise ValueError("the hybrid gate supports 16 or 32 sources per graph")
    policies = settings["policies"]
    if not policies or len(set(policies)) != len(policies) or any(value not in POLICIES for value in policies):
        raise ValueError("invalid hybrid/control policies")
    if not isinstance(settings["seed_purpose"], str) or not settings["seed_purpose"]:
        raise ValueError("an explicit stream purpose is required")
    return settings


def run_hybrid_case(query, settings, policy, base_seed, *, envelope=None,
                    clock=time.perf_counter, rng_factory=np.random.default_rng):
    """Run one fixed hybrid policy; never choose generic/hybrid by observed h."""
    if policy not in HYBRID_POLICIES:
        raise ValueError("run_hybrid_case requires normal_hybrid or eb_hybrid")
    started = clock()
    created_here = envelope is None
    before = clock()
    if envelope is None:
        envelope = compile_hybrid(query)
    if not isinstance(envelope, HybridEnvelope) or envelope.kernel is not query.kernel:
        raise ValueError("hybrid envelope is not bound to this compiled query")
    if not np.array_equal(envelope.q, query.q):
        raise ValueError("hybrid preparation changed nominal probabilities")
    if (envelope.metadata["original_low_sha256"] != hashlib.sha256(query.low.tobytes(order="C")).hexdigest()
            or envelope.metadata["original_high_sha256"] != hashlib.sha256(query.high.tobytes(order="C")).hexdigest()):
        raise ValueError("hybrid envelope belongs to a different declared parameter box")
    times = {name: 0. for name in ("rng", "scoring", "event", "inference", "policy", "hashing")}
    times["hybrid_preparation_in_case"] = clock() - before
    kernel, q = query.kernel, query.q
    k, m = len(kernel.candidates), len(q)
    checks = actual_checkpoints(settings)
    rule = ({"name": "empirical_bernstein", "checkpoints": tuple(value for value in checks if value >= 2)}
            if policy == "eb_hybrid" else {"name": "normal_mixture", "rho": settings["nominal"]["rho"]})
    plan = settings["risk_plan"]
    protected, alpha = plan["event_checkpoints"], plan["alpha_per_checkpoint"]
    nominal_delta = settings["delta_nominal"]
    cost = query.metadata["cost_model"]
    model = settings["work_model"]
    nominal_unit = max(1, m + cost["original_incidence_entries"] + model["nominal_candidate_units"] * k)
    equivalent = int(settings["sample_count"] * settings["budget_fraction"])
    budget, work = (equivalent + 1) * nominal_unit, float(nominal_unit)
    weight = settings["interval_work_weight"]
    seed = stream_seed(query.graph, query.dataset_revision, query.query_id,
                       base_seed, settings["seed_purpose"])
    before = clock()
    rng = rng_factory(seed)
    times["rng"] += clock() - before
    counts = np.zeros(k, dtype=np.int64)
    blocks, trace, winners_observed = [], [], []
    uniforms_hash, winner_hash = hashlib.sha256(), hashlib.sha256()
    n = event_n = event_count = event_free = score_calls = event_calls = rejected = 0
    event_upper = 1.
    effective = envelope.combine_upper(event_upper)
    lower = None
    leader = 0
    certified = False
    nominal_candidate = nominal_n = nominal_time = None
    status = "world_cap"
    deadline = settings["deadline_seconds"]

    def elapsed():
        return clock() - started

    def expired():
        return deadline is not None and elapsed() > deadline

    if k == 1:
        certified = not expired()
        if certified:
            nominal_candidate, nominal_n, nominal_time = 0, 0, elapsed()
        status = "structurally_single_candidate" if certified else "deadline_postblock"
    else:
        for next_n in checks:
            if expired():
                status = "deadline_before_block"
                break
            nominal_fee = (next_n - n) * nominal_unit
            if work + nominal_fee > budget:
                status = "nominal_work_budget"
                break
            before = clock()
            uniforms = rng.random((next_n - n, m), dtype=np.float64)
            states = uniforms < q[None, :]
            times["rng"] += clock() - before
            before = clock()
            scores = kernel.scores(states)
            if scores.shape != (len(uniforms), k) or not np.isfinite(scores).all():
                raise ValueError("invalid original nominal scores")
            winners = np.argmax(scores, axis=1)
            counts += np.bincount(winners, minlength=k)
            winners_observed.extend(int(value) for value in winners)
            score_calls += 1
            times["scoring"] += clock() - before
            blocks.append((n, uniforms, scores))
            n, work = next_n, work + nominal_fee
            before = clock()
            uniforms_hash.update(uniforms.tobytes(order="C"))
            winner_hash.update(winners.astype(np.int64, copy=False).tobytes(order="C"))
            times["hashing"] += clock() - before
            if expired():
                status = "deadline_postblock"
                trace.append({"nominal_samples": n, "event_samples": event_n,
                              "elapsed_seconds": elapsed(), "work_used": work, "status": status,
                              "uniform_prefix_sha256": uniforms_hash.hexdigest(),
                              "winner_prefix_sha256": winner_hash.hexdigest()})
                break
            before = clock()
            leader = int(np.argmax(counts))
            lower = inference.numerical_gap_bound(counts, n, nominal_delta, rule)
            times["inference"] += clock() - before
            if lower > 0 and nominal_candidate is None and not expired():
                nominal_candidate, nominal_n, nominal_time = leader, n, elapsed()
            before = clock()
            effective = envelope.combine_upper(event_upper)
            could_certify = lower > 2 * effective
            admission, selected = "not_requested", None
            upper_fee = actual_fee = 0.
            if not could_certify and not expired():
                eligible = [value for value in protected if event_n < value <= n]
                if eligible:
                    selected = eligible[0]
                    upper_fee = envelope.event_work_upper(
                        selected - event_n, interval_candidate_units=model["interval_candidate_units"], weight=weight)
                    if work + upper_fee > budget:
                        admission, rejected = "rejected_budget", rejected + 1
                    else:
                        admission = "approved"
            times["policy"] += clock() - before
            if admission == "approved":
                before = clock()
                added = free = 0
                for old_u, old_scores in _segments(blocks, event_n, selected):
                    flags = envelope.indicators(old_u, nominal_scores=old_scores)
                    free_flags = envelope.free_flags(old_u)
                    if flags.dtype != np.bool_ or flags.shape != (len(old_u),):
                        raise ValueError("invalid hybrid indicator")
                    added += int(np.count_nonzero(flags))
                    free += int(np.count_nonzero(free_flags))
                    event_calls += 1
                actual_units = (2 * m * (selected - event_n)
                                + (2 * cost["interval_incidence_entries"] + model["interval_candidate_units"] * k) * free)
                actual_fee = actual_units * weight
                if actual_fee > upper_fee or work + actual_fee > budget:
                    raise AssertionError("hybrid static admission failed")
                work += actual_fee
                event_count, event_free = event_count + added, event_free + free
                event_n = selected
                times["event"] += clock() - before
                before = clock()
                event_upper = event_bounds.fixed_n_binomial_upper(event_count, event_n, alpha)
                times["inference"] += clock() - before
                before = clock()
                effective = envelope.combine_upper(event_upper)
                could_certify = lower > 2 * effective
                times["policy"] += clock() - before
            late = expired()
            if late:
                status = "deadline_postblock"
            elif could_certify:
                certified, status = True, "certified"
            trace.append({
                "nominal_samples": n, "event_samples": event_n, "elapsed_seconds": elapsed(),
                "work_used": work, "lower_gap": lower, "event_upper": event_upper,
                "epsilon_source_upper": envelope.epsilon_source, "effective_epsilon_upper": effective,
                "leader_index": leader, "event_upgrade_to": selected, "event_admission": admission,
                "static_event_fee": upper_fee, "actual_event_fee": actual_fee,
                "status": status, "late_certificate_discarded": bool(late and could_certify),
                "uniform_prefix_sha256": uniforms_hash.hexdigest(),
                "winner_prefix_sha256": winner_hash.hexdigest(),
            })
            if certified or late:
                break
    seconds = elapsed()
    if certified and deadline is not None and seconds > deadline:
        certified, status = False, "deadline_postblock"
        if trace:
            trace[-1].update({"status": status, "late_certificate_discarded": True})
    if work > budget or len(winners_observed) != n or int(counts.sum()) != n:
        raise AssertionError("hybrid count/world/work invariant failed")
    return {
        "schema_version": SCHEMA, "graph": query.graph, "query_id": query.query_id,
        "dataset_revision": query.dataset_revision, "policy": policy, "method": policy,
        "objective": "robust", "inference_rule": rule, "envelope": "fixed_source_partition_hybrid",
        "seed": base_seed, "seed_purpose": settings["seed_purpose"], "rng_seed_hex": hex(seed),
        "candidate_count": k, "scope_edge_count": m, "tau": settings["tau"],
        "certified": certified, "stable": certified, "robust_certified": certified, "status": status,
        "certified_candidate_index": leader if certified else None,
        "certified_candidate": str(kernel.candidates[leader]) if certified else None,
        "nominal_certified": nominal_candidate is not None, "nominal_candidate_index": nominal_candidate,
        "nominal_certificate_samples": nominal_n, "nominal_certificate_seconds": nominal_time,
        "nominal_delta": nominal_delta, "event_beta_total": settings["beta_total"],
        "actual_nominal_checkpoints": list(checks), "samples_used": n, "worlds_generated": n,
        "nominal_score_rows": n, "nominal_score_calls": score_calls,
        "random_uniform_draws": n * m, "event_extra_random_draws": 0,
        "event_samples_used": event_n, "event_rows_computed": event_n,
        "event_count": event_count, "event_free_rows": event_free, "event_calls": event_calls,
        "event_admission_rejections": rejected, "final_lower_gap": lower,
        "scope_epsilon_upper": envelope.epsilon_scope, "epsilon_source_upper": envelope.epsilon_source,
        "event_upper": event_upper, "effective_epsilon_upper": effective,
        "work_used": work, "work_budget": budget, "work_overshoot": 0.,
        "work_semantics": "same_generic_modeled_variable_work; extra_hybrid_setup_and_CI_timed_separately",
        "seconds": {**times, "serving_total": seconds, "query_serving_total": seconds,
                    "other_overhead": max(0., seconds - sum(times.values()))},
        "hybrid_setup_included_in_case_serving": created_here,
        "hybrid_metadata": envelope.metadata,
        "deadline_seconds": deadline,
        "deadline_overrun_seconds": max(0., seconds - deadline) if deadline is not None else 0.,
        "uniform_prefix_sha256": uniforms_hash.hexdigest(), "winner_prefix_sha256": winner_hash.hexdigest(),
        "winner_counts": counts.tolist(), "winner_indices": winners_observed,
        "retained_uniform_values": sum(value[1].size for value in blocks), "trace": trace,
    }


def run_gate(config, output, *, query_count=None, root=ROOT):
    started = time.perf_counter()
    settings = prepare_settings(config, query_count)
    if (settings["required_pythonhashseed"] is not None
            and os.environ.get("PYTHONHASHSEED") != str(settings["required_pythonhashseed"])):
        raise ValueError("launch with the frozen Python hash seed")
    output = _inside(root, output)
    output.mkdir(parents=True, exist_ok=False)
    (output / "cases").mkdir()
    source_paths = [Path(__file__).resolve(), ROOT / "scripts/test_icde_gate_hybrid_runner.py",
                    ROOT / "scripts/icde_gate_hybrid_envelope.py", ROOT / "scripts/test_icde_gate_hybrid_envelope.py",
                    ROOT / "scripts/icde_gate_inference.py", ROOT / "scripts/icde_gate_comparison_runner.py",
                    ROOT / "scripts/icde_online_execution.py"]
    source_paths += list((ROOT / "scripts").glob("*vldb*.py"))
    source_paths += list((ROOT / "src/pkgea").rglob("*.py"))
    identities = {path.relative_to(root).as_posix(): file_sha256(path) for path in source_paths}
    input_ids = []
    for profile in settings["profiles"]:
        dataset = _inside(root, profile["dataset_path"])
        revision = dataset_revision_digest(dataset)
        if profile.get("expected_revision", revision) != revision:
            raise ValueError("input revision differs before freeze")
        input_ids.append({"graph": profile["graph"], "dataset_revision": revision,
                          "input_sha256": {name: file_sha256(dataset / name) for name in CANONICAL_FILES
                                           if (dataset / name).is_file()}})
    write_json(output / "protocol_freeze.json", {
        "schema_version": SCHEMA, "config": config, "resolved_policies": settings["policies"],
        "resolved_query_count": settings["query_count"], "seeds": settings["seeds"],
        "actual_seed_purpose": settings["seed_purpose"], "risk_plan": settings["risk_plan"],
        "actual_nominal_checkpoints": list(actual_checkpoints(settings)),
        "code_sha256": identities, "inputs": input_ids, "before_any_setup_or_inference_draws": True,
        "observed_generic_hybrid_minimum_used": False,
    })
    event_bounds._bound_details.cache_clear()
    setups, cases = [], []
    serialization = 0.
    for graph_index, profile in enumerate(settings["profiles"]):
        prepared, report = setup_graph(profile, settings, root)
        before = time.perf_counter()
        envelopes = {query.query_id: compile_hybrid(query) for query in prepared}
        hybrid_setup_seconds = time.perf_counter() - before
        report["hybrid_preparation_seconds"] = hybrid_setup_seconds
        report["hybrid_preparation"] = {key: value.metadata for key, value in envelopes.items()}
        slug = re.sub(r"[^a-z0-9]+", "_", profile["graph"].lower()).strip("_")
        setup_path = output / f"setup_{slug}.json"
        serialization += write_json(setup_path, report)
        setups.append({"graph": profile["graph"], "path": setup_path.relative_to(root).as_posix(),
                       "sha256": file_sha256(setup_path), "hybrid_preparation_seconds": hybrid_setup_seconds})
        for seed_index, seed in enumerate(settings["seeds"]):
            for query_index, query in enumerate(prepared):
                policies = tuple(settings["policies"])
                offset = (graph_index + seed_index + query_index) % len(policies)
                for position, policy in enumerate(policies[offset:] + policies[:offset]):
                    result = (run_hybrid_case(query, settings, policy, seed,
                                               envelope=envelopes[query.query_id])
                              if policy in HYBRID_POLICIES else run_case(query, settings, policy, seed))
                    result["execution_position"] = position
                    query_hash = hashlib.sha256(query.query_id.encode("utf-8")).hexdigest()[:16]
                    path = output / "cases" / f"{slug}_{query_hash}_s{seed}_{policy}.json"
                    serialization += write_json(path, result)
                    cases.append({"graph": query.graph, "query_id": query.query_id, "seed": seed,
                                  "policy": policy, "certified": result["certified"],
                                  "path": path.relative_to(root).as_posix(), "sha256": file_sha256(path)})
                    serialization += write_json(output / "progress.json", {
                        "status": "RUNNING", "completed_cases": len(cases), "last_case": cases[-1],
                        "elapsed_seconds": time.perf_counter() - started}, replace=True)
                    print(json.dumps({"completed_cases": len(cases), "policy": policy,
                                      "graph": query.graph, "seed": seed, "certified": result["certified"]}), flush=True)
    changed = [name for name, expected in identities.items() if file_sha256(root / name) != expected]
    if changed:
        raise ValueError("frozen code changed: " + ", ".join(changed))
    summary = {"schema_version": SCHEMA, "status": "COMPLETE", "case_files": cases,
               "setup_files": setups, "completed_cases": len(cases),
               "unique_queries": settings["query_count"] * len(settings["profiles"]),
               "seeds": settings["seeds"], "policies": settings["policies"],
               "seconds_before_summary": time.perf_counter() - started,
               "serialization_seconds": serialization,
               "timing_contract": {"cold_claim": False, "shared_graph_and_hybrid_setup_reported_separately": True,
                                   "hybrid_setup_required_for_hybrid_policies": True,
                                   "CP_cache": "empty_at_start_retained_across_cases_rotating_policy_order",
                                   "no_observed_envelope_selection": True}}
    write_json(output / "summary.json", summary)
    write_json(output / "progress.json", {"status": "COMPLETE", "completed_cases": len(cases),
                                           "summary": "summary.json"}, replace=True)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--query-count", type=int, choices=(16, 32))
    args = parser.parse_args()
    config = json.loads(_inside(ROOT, args.config).read_text("utf-8-sig"))
    summary = run_gate(config, args.output_dir, query_count=args.query_count)
    print(json.dumps({"status": summary["status"], "completed_cases": summary["completed_cases"],
                      "module_to_output_seconds": time.perf_counter() - MODULE_STARTED}))


if __name__ == "__main__":
    main()
