"""Frozen numeric index reuse and byte-matched selector ablations."""
from __future__ import annotations

import hashlib
import time
from pathlib import Path

import numpy as np

from pkgea.www_fsl import (
    apply_entity_representations, gaussian_distance_matrix, margin_criticalities,
)
from pkgea.distributional import gaussian_wasserstein_squared, low_rank_plus_diagonal
from run_www_equal_budget import (
    atomic_write_json, full_payload, load_full_payload,
    representation_payload, load_representation_payload,
)
from run_www_workload_audit import split_metrics

NAMES = ("diagonal", "rank_1", "rank_2", "rank_4", "full")


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def threshold_map(scores, threshold):
    eligible = scores <= threshold
    indices = np.where(eligible.any(axis=1), eligible.argmax(axis=1), 4)
    return [NAMES[int(index)] for index in indices]


def match_bytes(means, covariances, scores, metadata, budget):
    """Search empirical thresholds without looking at held-out winners."""
    points = np.unique(np.r_[0.0, scores[np.isfinite(scores)]])
    cache = {}

    def evaluate(index):
        index = max(0, min(len(points)-1, index))
        if index not in cache:
            names = threshold_map(scores, points[index])
            payload, _ = representation_payload(means, covariances, names, metadata)
            cache[index] = (len(payload), names, payload)
        return index, cache[index]

    lo, hi = 0, len(points)-1
    while lo <= hi:
        middle = (lo+hi)//2
        _, row = evaluate(middle)
        if row[0] <= budget:
            hi = middle-1
        else:
            lo = middle+1
    for index in range(lo-12, lo+13):
        evaluate(index)
    feasible = [(index, row) for index, row in cache.items() if row[0] <= budget]
    if not feasible:
        raise RuntimeError("no threshold meets byte budget")
    index, (size, names, payload) = max(feasible, key=lambda row: (row[1][0], -row[0]))
    deviation = (budget-size)/budget
    if deviation > 0.005:
        raise RuntimeError(f"byte matching failed: {deviation:.6f}")
    return payload, names, {
        "threshold": float(points[index]), "budget_bytes": budget,
        "actual_bytes": size, "relative_budget_shortfall": deviation,
        "evaluated_thresholds": len(cache), "counts": {n: names.count(n) for n in NAMES},
        "representations": names,
    }


def allocation_scores(target_covariances, criticalities):
    """Per-target distortion under each representation, for the three rules.

    A: relative Frobenius.  B: uniform W2.  C: W2 normalized by the selection
    criticality.  Shared by the frozen 0.8-budget audit and the budget sweep so
    the two cannot diverge in how distortion is measured.
    """

    tc = target_covariances
    zero = np.zeros(tc.shape[1])
    frob, w2 = [], []
    for name in NAMES[:-1]:
        approx = apply_entity_representations(tc, [name]*len(tc))
        frob.append(np.linalg.norm(tc-approx, axis=(1,2))/np.maximum(np.linalg.norm(tc, axis=(1,2)), 1e-12))
        w2.append(np.array([np.sqrt(gaussian_wasserstein_squared(zero,c,zero,a)) for c,a in zip(tc,approx)]))
    frob, w2 = np.stack(frob,axis=1), np.stack(w2,axis=1)
    margin = np.divide(w2, criticalities[:,None], out=np.full_like(w2,np.inf), where=criticalities[:,None]>0)
    margin[w2<=1e-15] = 0
    return frob, w2, margin


def passes(row, max_error):
    return bool(row["flipped_query_count"] == 0 and row["mean_relative_distance_error"] <= max_error)


def run_audit(*, output, cell, means, covariances, selection_timing, moments,
              splits, sources, targets, truth_positions, metadata, max_error):
    started = time.perf_counter()
    source_count = len(sources)
    if source_count != 500 or len(targets) != 1012:
        raise RuntimeError("frozen query/candidate count mismatch")
    target_means, target_covariances = means[source_count:], covariances[source_count:]
    # Metadata does not depend on method/stage, so matching measures representation.
    full = full_payload(target_means, target_covariances, dtype=np.dtype('float32'), metadata=metadata)
    tm, tc = load_full_payload(full)
    reference = gaussian_distance_matrix(
        np.concatenate((means[splits['selection']], tm)),
        np.concatenate((covariances[splits['selection']], tc)), 300,
    )
    criticalities = np.asarray(margin_criticalities(reference)['entity_criticalities'])[300:]
    frob, w2, margin = allocation_scores(tc, criticalities)
    budget = int(0.8*len(full))
    payloads = {'full_fp32': full}
    maps = {}
    for name, scores in [('frob',frob),('uniform_w2',w2),('margin_w2',margin)]:
        payload, mapping, row = match_bytes(tm,tc,scores,metadata,budget)
        payloads[name] = payload
        maps[name] = row
        if name == 'margin_w2':
            payloads['margin_fp16'], _ = representation_payload(tm,tc,mapping,metadata,dtype=np.dtype('float16'))
    payloads['full_fp16'] = full_payload(tm,tc,dtype=np.dtype('float16'),metadata=metadata)

    # Global ranks use the same serializer fields, extended to ranks 0..7.
    # Store covariance factors through a standalone NPZ format shared by both precisions.
    import io

    def global_payload(rank,dtype):
        factors, diagonals = zip(*(low_rank_plus_diagonal(c,rank=rank) for c in tc)) if rank else (np.zeros((len(tc),tc.shape[1],0)),np.diagonal(tc,axis1=1,axis2=2))
        stream=io.BytesIO()
        np.savez_compressed(stream,means=np.asarray(tm,dtype=dtype),factors=np.asarray(factors,dtype=dtype),diagonals=np.asarray(diagonals,dtype=dtype))
        return stream.getvalue()

    def load_global(payload):
        with np.load(io.BytesIO(payload),allow_pickle=False) as data:
            m=np.asarray(data['means'],dtype=float)
            f=np.asarray(data['factors'],dtype=float)
            c=f@np.swapaxes(f,1,2)
            ix=np.arange(c.shape[1]); c[:,ix,ix]+=data['diagonals']
        return m,c

    rank_rows=[]; global_options={}
    for rank in range(8):
        payload=global_payload(rank,np.float32); global_options[rank]=payload
        gm,gc=load_global(payload)
        estimate=gaussian_distance_matrix(np.concatenate((means[:300],gm)),np.concatenate((covariances[:300],gc)),300)
        row=split_metrics(reference,estimate,truth_positions[:300],sources[:300])
        row.update(rank=rank,bytes=len(payload),passes=passes(row,max_error))
        rank_rows.append(row)
    eligible=[r for r in rank_rows if r['passes'] and r['bytes']<len(full)]
    chosen=min(eligible or rank_rows,key=lambda r:(r['bytes'],r['rank']))['rank']
    payloads['global_fp32']=global_options[chosen]
    payloads['global_fp16']=global_payload(chosen,np.float16)

    artifact_dir=Path('.runtime/www_fixed_index_v1')/cell
    artifact_dir.mkdir(parents=True,exist_ok=True)
    hashes={name:digest(payload) for name,payload in payloads.items()}
    for name,payload in payloads.items():
        path=artifact_dir/f'{name}.npz'
        if path.exists() and path.read_bytes()!=payload:
            raise RuntimeError(f'existing numeric artifact differs: {path}')
        path.write_bytes(payload)
    build_seconds=time.perf_counter()-started
    stages={}
    for label,seed in [('authorization',59),('final_test',71)]:
        stage_started=time.perf_counter()
        qm,qc,timing=moments(seed,label)
        section=splits[label]; qm,qc=qm[section],qc[section]
        ref=gaussian_distance_matrix(np.concatenate((qm,tm)),np.concatenate((qc,tc)),len(qm))
        rows={}
        for name in payloads:
            payload=(artifact_dir/f'{name}.npz').read_bytes()
            if digest(payload)!=hashes[name]:
                raise RuntimeError('frozen artifact digest mismatch')
            if name.startswith('full_'):
                im,ic=load_full_payload(payload)
            elif name.startswith('global_'):
                im,ic=load_global(payload)
            else:
                im,ic=load_representation_payload(payload)
            est=gaussian_distance_matrix(np.concatenate((qm,im)),np.concatenate((qc,ic)),len(qm))
            row=split_metrics(ref,est,truth_positions[section],sources[section])
            row['passes']=passes(row,max_error)
            row['artifact_sha256']=hashes[name]
            # Deployment chooses from authorization only, even if final test fails.
            approved=row['passes'] if label=='authorization' else stages['authorization']['methods'][name]['passes']
            row['authorization_effective_bytes']=len(payload) if approved else len(full)
            row['policy_flips']=row['flipped_query_count'] if approved else 0
            rows[name]=row
        stages[label]={'methods':rows,'moment_timing':timing,'total_seconds':time.perf_counter()-stage_started}
        print(f'[fixed-index] {cell} {label}: '+str({n:r['passes'] for n,r in rows.items()}),flush=True)
    result={
        'schema_version':'www-fixed-index-v1','cell':cell,'inputs':metadata,
        'protocol':{'query_split':[300,100,100],'candidate_count':len(targets),'truth_retention':1.0,
                    'target_seed':17,'source_seeds':[17,59,71],'fixed_numeric_index':True,
                    'budget_fraction_full_fp32':0.8,'max_relative_squared_w2_error':max_error,
                    'answer_cache_payload_bytes':4*len(sources),
                    'backing_full_index_counted_in_effective_bytes':False,
                    'effective_bytes_meaning':'one chosen resident index; a retained backing full copy would be additional'},
        'selection':maps,'global_rank_selection':rank_rows,'chosen_global_rank':chosen,
        'global_selection_pass':bool(eligible),
        'artifacts':{n:{'sha256':hashes[n],'bytes':len(p)} for n,p in payloads.items()},
        'stages':stages,'timing':{'selection_moments':selection_timing,'index_build_seconds':build_seconds,
          'total_seconds':time.perf_counter()-started+selection_timing['total_seconds']},
        'validation':{'fixed_hashes_across_stages':all(stages['authorization']['methods'][n]['artifact_sha256']==stages['final_test']['methods'][n]['artifact_sha256'] for n in payloads),
                      'byte_matching_passes':all(r['relative_budget_shortfall']<=0.005 for r in maps.values())},
    }
    atomic_write_json(output,result)
