"""Static grouped-query feasibility census; no scores/worlds/certificates.

Grouping uses exact degree-input incidence signatures and declared equal
probability endpoints. This is standard counting symmetry, not a novelty claim.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import time
import zipfile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / "nodes/09_vldb_query_certification/results/icde_prospective_20261107"
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_grouped_query_20261108/inventory_attempt1"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(obj, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def incidence_groups(incidence, m):
    signatures = [[] for _ in range(m)]
    for column, positions in enumerate(incidence):
        if len(set(map(int, positions))) != len(positions):
            raise ValueError("duplicate edge in an incidence coordinate")
        for edge in positions:
            if not 0 <= int(edge) < m:
                raise ValueError("edge index outside scope")
            signatures[int(edge)].append(column)
    grouped = defaultdict(list)
    for edge, signature in enumerate(signatures):
        if not signature:
            raise ValueError("scope contains a degree-invisible edge")
        grouped[tuple(signature)].append(edge)
    return tuple((signature, tuple(edges)) for signature, edges in sorted(grouped.items()))


def freeze(out):
    if out.exists():
        raise FileExistsError(out)
    paths = [OLD / "confirmation_protocol.json", OLD / "new_exact_reference/summary.json"]
    cases = []
    for graph in ("dw", "enfr"):
        paths.append(OLD / "prepared" / graph / "summary.json")
        for row in load(paths[-1])["records"]:
            name = OLD / "prepared" / graph / f"q{row['rank']:03d}.json"
            paths.extend((name, name.with_suffix(".npz")))
            cases.append({"graph": graph, **row})
    code = dict(load(OLD / "confirmation_protocol.json")["code_sha256"])
    code["scripts/icde_grouped_inventory_20261108.py"] = sha(Path(__file__))
    save(out / "protocol.json", {"kind": "static_existing_asset_inventory_not_new_confirmation",
        "cases": cases, "selection": "all 576 existing prepared queries; former pilot/confirmation labels retained; all are now known historical inputs",
        "candidate_limit_for_signature_census": 256, "scope_limit_for_signature_census": 10000,
        "prototype_limits": {"candidate_limit": 8, "scope_limit": 96, "count_states": 32768,
                             "tensor_multiply_add_estimate": 2000000, "minimum_large_scope": 20,
                             "per_graph_large_cases": 4},
        "prototype_selection": "eligible non-singletons: per graph sort by decreasing scope, then increasing count states, then rank; take first 4; append all 20 previously exact-enumerated tiny cases",
        "model": "configured independent retention q=.9, tau=.25; equal low/high endpoints for all edges; grouping invalid without these invariances",
        "scope": "static incidence only, no score evaluation, sampling or new certificate",
        "code_sha256": code, "input_sha256": {p.relative_to(ROOT).as_posix(): sha(p) for p in paths},
        "frozen_at_unix": time.time()})
    print(json.dumps({"frozen_queries": len(cases)}, ensure_ascii=False), flush=True)


def identities(protocol, crc=False):
    checked = 0
    for group in ("code_sha256", "input_sha256"):
        for name, digest in protocol[group].items():
            path = ROOT / name
            if sha(path) != digest:
                raise AssertionError(f"changed frozen identity: {name}")
            checked += 1
            if crc and name.endswith(".npz"):
                with zipfile.ZipFile(path) as archive:
                    if archive.testzip() is not None:
                        raise AssertionError("prepared-object CRC failure")
                checked += 1
    return checked


def preflight(out):
    protocol = load(out / "protocol.json")
    checked = identities(protocol, crc=True)
    if (out / "inventory.json").exists() or list(out.glob("*.pending")):
        raise ValueError("use a new explicit attempt for existing outputs")
    save(out / "recovery.json", {"status": "PASS", "checks": checked,
        "scope": "all consumed historical source/input identities and prepared CRCs; not a global filesystem audit"})
    print(f"Scoped recovery PASS: {checked}", flush=True)


def run(out):
    protocol = load(out / "protocol.json")
    if load(out / "recovery.json")["status"] != "PASS":
        raise AssertionError("need recovery audit")
    identities(protocol)
    rows = []
    started = time.perf_counter()
    limit = protocol["prototype_limits"]
    for case in protocol["cases"]:
        row = dict(case)
        k, m = row["retained_candidates"], row["scope_edges"]
        row["prototype_eligible"] = False
        if k == 1:
            row["inventory_status"] = "single_candidate_no_modal_competition"
        elif k > protocol["candidate_limit_for_signature_census"] or m > protocol["scope_limit_for_signature_census"]:
            row["inventory_status"] = "outside_frozen_static_limits"
        else:
            path = OLD / "prepared" / row["graph"] / f"q{row['rank']:03d}.npz"
            with np.load(path, allow_pickle=False) as arrays:
                incidence = tuple(arrays[f"inc_{i}"].copy() for i in range(2*(k+1)))
                groups = incidence_groups(incidence, m)
            sizes = [len(edges) for signature, edges in groups]
            states = math.prod(n + 1 for n in sizes)
            work = states * sum(n + 1 for n in sizes)
            # O(K*S) scores plus exact tensor work; this estimate is an
            # arithmetic-operation count, not wall time or bit complexity.
            row.update({"inventory_status": "grouped", "group_count": len(sizes),
                "group_sizes": sizes, "count_states": states, "world_state_log2": m,
                "count_state_log2": math.log2(states), "saved_binary_exponent": m - math.log2(states),
                "tensor_multiply_add_estimate_per_candidate": work,
                "naive_count_state_pair_estimate": states * states,
                "estimated_final_integer_bits": 54 * m + 2,
                "heterogeneous_unique_endpoint_stress_count_states_log2": m,
                "prototype_eligible": k <= limit["candidate_limit"] and m <= limit["scope_limit"]
                    and states <= limit["count_states"] and k * work <= limit["tensor_multiply_add_estimate"]})
        rows.append(row)
    selected = []
    for graph in ("dw", "enfr"):
        eligible = [r for r in rows if r["graph"] == graph and r["prototype_eligible"]
                    and r["scope_edges"] >= limit["minimum_large_scope"]]
        eligible.sort(key=lambda r: (-r["scope_edges"], r["count_states"], r["rank"]))
        selected += [{"graph": r["graph"], "rank": r["rank"], "role": "static_large_scope"}
                     for r in eligible[:limit["per_graph_large_cases"]]]
    tiny = sorted({(r["graph"], r["rank"]) for r in load(OLD / "new_exact_reference/summary.json")["references"]})
    selected += [{"graph": g, "rank": rank, "role": "exact_small_scope_audit"} for g, rank in tiny]
    checked = identities(protocol)
    result = {"status": "PASS", "rows": rows, "selected_for_prototype": selected,
        "queries": len(rows), "former_pilot_queries": sum(r["partition"] == "pilot" for r in rows),
        "former_confirmation_queries": sum(r["partition"] == "confirmation" for r in rows),
        "status_counts": dict(Counter(r["inventory_status"] for r in rows)),
        "eligible_queries": sum(r["prototype_eligible"] for r in rows),
        "eligible_large_queries": sum(r["prototype_eligible"] and r["scope_edges"] >= limit["minimum_large_scope"] for r in rows),
        "elapsed_seconds": time.perf_counter() - started, "post_identity_checks": checked,
        "protocol_sha256": sha(out / "protocol.json"), "score_evaluations": 0,
        "new_world_samples": 0, "new_certification_outputs": 0,
        "limitations": ["known historical inputs only", "equal independent endpoints and degree-incidence scorer",
            "count-state compression is not itself a novelty or total-cost advantage",
            "heterogeneous endpoint stress is a structural counterfactual, not a measured real probability model"]}
    save(out / "inventory.json", result)
    print(json.dumps({k: result[k] for k in ("status", "queries", "status_counts", "eligible_queries", "eligible_large_queries", "selected_for_prototype")}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("freeze", "preflight", "run"), required=True)
    parser.add_argument("--output", type=Path, default=BASE)
    args = parser.parse_args()
    {"freeze": freeze, "preflight": preflight, "run": run}[args.phase](args.output.resolve())
