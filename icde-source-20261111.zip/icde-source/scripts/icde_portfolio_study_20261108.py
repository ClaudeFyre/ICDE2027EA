"""Frozen historical workload: one-shot solver selection headroom, no selector."""
import argparse
import math
from pathlib import Path
import time

import numpy as np

import icde_prospective_20261107 as old
from icde_grouped_inventory_20261108 import ROOT, load, save, sha, identities
from icde_grouped_exact_20261108 import compile_counts, solve_counts, groups_for_box
from icde_partial_count_20261108 import execute as joint_execute, CountOracle
from icde_factor_partial_20261108 import execute as factor_execute
from icde_partial_count_study_20261108 import audit
from icde_portfolio_budget_20261108 import budgeted_call, REAL_COUNTER
from run_vldb_interval_gate_v1 import clipped_box

BASE = ROOT / 'nodes/09_vldb_query_certification/results/icde_portfolio_headroom_20261108/attempt1'
INVENTORY = ROOT / 'nodes/09_vldb_query_certification/results/icde_grouped_query_20261108/inventory_attempt1'
PARENT = ROOT / 'nodes/09_vldb_query_certification/results/icde_partial_count_20261108/factor_followup_attempt1'
POLICIES = ('dense_exact', 'partial_joint', 'partial_factor', 'mc_eager')


def freeze(out):
    if out.exists():
        raise FileExistsError(out)
    parent = load(PARENT / 'protocol.json')
    cases = [r for r in load(INVENTORY / 'inventory.json')['rows'] if r.get('prototype_eligible')]
    if len(cases) != 148:
        raise AssertionError('static inventory selection changed')
    code = dict(parent['code_sha256'])
    for name in ('icde_portfolio_budget_20261108.py', 'test_icde_portfolio_budget_20261108.py',
                 'icde_portfolio_study_20261108.py', 'icde_portfolio_report_20261108.py',
                 'test_icde_portfolio_report_20261108.py'):
        code['scripts/' + name] = sha(ROOT / 'scripts' / name)
    inputs = dict(parent['input_sha256'])
    for path in (INVENTORY/'inventory.json', INVENTORY/'protocol.json', PARENT/'summary.json'):
        inputs[path.relative_to(ROOT).as_posix()] = sha(path)
    for case in cases:
        path = old.BASE / 'prepared' / case['graph'] / f"q{case['rank']:03d}.json"
        for item in (path, path.with_suffix('.npz')):
            inputs[item.relative_to(ROOT).as_posix()] = sha(item)
    save(out/'protocol.json', {
        'kind': 'all_static_eligible_historical_query_solver_selection_headroom',
        'cases': cases, 'policies': list(POLICIES), 'seeds': [1009, 1013, 1019],
        'nominal': .9, 'tau': .25, 'state_cap': 32768, 'max_splits': 127,
        'max_parameter_splits': 31, 'run_budget_seconds': .1,
        'delivery_deadlines_ms': [1, 2, 5, 10, 20, 50, 100],
        'workload': 'all 148 prototype_eligible rows of frozen static inventory; historical development only',
        'method_order': 'rotate by query index plus repetition',
        'warmup': {'graph': 'enfr', 'rank': 175, 'all_four_methods_once': True},
        'timing': 'prepared compute incl grouping/root/numerical setup; loading, persistence, reference and audits excluded',
        'deadline': '100ms cooperative checkpoints; native calls can overrun, late answers discarded; smaller deadlines are delivery curves from these runs, not independent hard-budget execution',
        'reference': 'full count tensor exact rational endpoint-orbit evaluator, outside measured policies; never passed to solvers',
        'objectives': ['stable_certificate', 'complete_classification'],
        'query_oracle': 'one method per query selected in hindsight over three repeats, max timely successes then min capped loss; zero routing cost; no per-repeat switching',
        'cost_oracle': 'separate per-query minimum of three-repeat mean budget-capped loss',
        'loss': 'timely requested proof costs measured elapsed, all other outcomes cost deadline; not actual CPU expenditure',
        'feature_probe': 'groups_for_box and count-state product measured separately three times per query; already-loaded kernel only; no trained router',
        'risk': 'exact controls deterministic; MC .025 nominal+.025 event per query/run; no workload-wide or repeat-pooled .05 guarantee',
        'boundary': 'upper bound for one-shot selection among these four configured solvers only; not for new work-sharing hybrid algorithms',
        'code_sha256': code, 'input_sha256': inputs, 'frozen_at_unix': time.time()})
    print('Frozen 148 queries x 4 solvers x 3 repeats = 1776 runs', flush=True)


def preflight(out):
    p = load(out/'protocol.json')
    checks = identities(p, crc=True)
    if (out/'summary.json').exists() or (out/'cases').exists():
        raise ValueError('use a new attempt for existing outputs')
    save(out/'recovery.json', {'status': 'PASS', 'checks': checks,
         'scope': 'consumed source/input hashes and NPZ CRCs only'})
    print(f'Preflight PASS {checks}', flush=True)


def execute(kernel, meta, low, high, policy, p, seed):
    if policy == 'dense_exact':
        return joint_execute(kernel, low, high, 'dense_exact', p)
    if policy == 'partial_joint':
        return joint_execute(kernel, low, high, 'standard_mass', p)
    if policy == 'partial_factor':
        return factor_execute(kernel, low, high, 'factor_mass', p)
    oracle = CountOracle(kernel, low, high, p['state_cap'])
    mask = oracle.possible((0,)*len(oracle.shape), tuple(n-1 for n in oracle.shape))
    if mask & (mask-1) == 0:
        return {'status': 'stable', 'winner': mask.bit_length()-1,
                'kind': 'common_root_bound', 'worlds': 0}
    raw = old.execute_case(kernel, meta, p['tau'], seed, 'eager')
    return {**raw, 'native_status': raw['status'],
            'status': 'stable' if raw['certified'] else 'unresolved',
            'winner': kernel.candidates.index(raw['candidate']) if raw['certified'] else None,
            'kind': 'mc_eager'}


def validate_raw(raw, compiled, exact, k):
    if raw['kind'] == 'factorized_partial_regions':
        checks = audit({**raw, 'kind': 'partial_count_regions'}, compiled, exact, k)
        coverage = np.zeros(compiled['shape'], dtype=np.int16)
        for cell in raw['parameter_cells']:
            coverage[tuple(slice(a,b+1) for a,b in zip(cell['low'],cell['high']))] += 1
        if not np.all(coverage == 1):
            raise AssertionError('parameter cells do not partition full endpoint orbits')
        return checks + 1
    return audit(raw, compiled, exact, k)


def run(out):
    p = load(out/'protocol.json')
    if load(out/'recovery.json')['status'] != 'PASS':
        raise AssertionError('missing preflight')
    checks = identities(p)
    started = REAL_COUNTER()
    w = p['warmup']
    kernel, meta = old.read_query(w['graph'], w['rank'])
    low, high = clipped_box(np.full(len(kernel.edge_indices), p['nominal']), p['tau'])
    warm = []
    for policy in POLICIES:
        result = budgeted_call(lambda: execute(kernel,meta,low,high,policy,p,p['seeds'][0]), p['run_budget_seconds'])
        warm.append({k:v for k,v in {'policy':policy, **result}.items() if k != 'raw'})
    save(out/'warmup.json', warm)
    rows, references = [], []
    for index, case in enumerate(p['cases']):
        before = REAL_COUNTER()
        kernel, meta = old.read_query(case['graph'], case['rank'])
        loading = REAL_COUNTER()-before
        k, m = len(kernel.candidates), len(kernel.edge_indices)
        if (k, m) != (case['retained_candidates'], case['scope_edges']):
            raise AssertionError('inventory does not match prepared query')
        low, high = clipped_box(np.full(m,p['nominal']), p['tau'])
        feature_times = []
        for repeat in range(3):
            before = REAL_COUNTER()
            groups = groups_for_box(kernel,low,high)
            size = math.prod(len(edges)+1 for signature,edges,endpoint in groups)
            feature_times.append(REAL_COUNTER()-before)
        if size != case['count_states']:
            raise AssertionError('static state estimate changed')
        before = REAL_COUNTER()
        compiled = compile_counts(kernel,low,high,p['state_cap'])
        exact = solve_counts(compiled,k)
        ref = {**case, 'uniform_winners':exact['uniform_winners'],
               'reference_seconds':REAL_COUNTER()-before, 'loading_seconds':loading,
               'feature_seconds':feature_times}
        save(out/'references'/f"{case['graph']}_q{case['rank']:03d}.json",ref)
        references.append(ref)
        for repeat, seed in enumerate(p['seeds']):
            offset = (index+repeat)%len(POLICIES)
            for policy in POLICIES[offset:]+POLICIES[:offset]:
                result = budgeted_call(lambda: execute(kernel,meta,low,high,policy,p,seed),p['run_budget_seconds'])
                raw = result.pop('raw')
                if time.perf_counter is not REAL_COUNTER:
                    raise AssertionError('deadline clock leaked outside policy')
                checks += 1
                if result['timed_out']:
                    if raw is not None:
                        raise AssertionError('late proof was retained')
                    status, winner, details = 'timeout', None, {}
                else:
                    checks += validate_raw(raw,compiled,exact,k)
                    status,winner = raw['status'],raw['winner']
                    details = {a:b for a,b in raw.items() if a not in
                               ('trace','leaf_records','parameter_cells','witnesses','compute_seconds',
                                'status','winner','divergence_bounds')}
                row = {'graph':case['graph'],'rank':case['rank'],'query_id':case['query_id'],
                       'policy':policy,'repeat':repeat,'seed':seed,'status':status,'winner':winner,
                       **result,'details':details}
                save(out/'cases'/f"{case['graph']}_q{case['rank']:03d}_{policy}_r{repeat}.json",row)
                rows.append(row)
        if (index+1)%10 == 0 or index+1 == len(p['cases']):
            print(f'Completed {index+1}/148 queries, {len(rows)} runs',flush=True)
    checks += identities(p)
    if len(rows) != 1776 or len({(r['graph'],r['rank'],r['policy'],r['repeat']) for r in rows}) != 1776:
        raise AssertionError('incomplete or duplicate run matrix')
    save(out/'summary.json',{'status':'PASS','checks':checks,'rows':rows,'references':references,
        'protocol_sha256':sha(out/'protocol.json'),'elapsed_seconds':REAL_COUNTER()-started,
        'historical_inputs_unchanged':True})
    print(f'PASS {len(rows)} runs, {checks} checks',flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase',choices=('freeze','preflight','run'),required=True)
    parser.add_argument('--output',type=Path,default=BASE)
    args = parser.parse_args()
    {'freeze':freeze,'preflight':preflight,'run':run}[args.phase](args.output.resolve())
