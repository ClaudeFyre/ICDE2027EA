"""Freeze and execute V2 without mutating inherited experiment identities."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = (
    "scripts/run_vldb_budget_validation_v2.py", "scripts/run_vldb_budget_gate_v2.py",
    "scripts/vldb_difference_envelope_v2.py", "scripts/vldb_source_conditioned_v2.py",
    "scripts/vldb_event_bound_v2.py", "scripts/vldb_budget_policy_v2.py",
    "tests/test_vldb_difference_envelope_v2.py", "tests/test_vldb_source_conditioned_v2.py",
    "tests/test_vldb_event_bound_v2.py", "tests/test_vldb_budget_policy_v2.py",
    "tests/test_vldb_budget_gate_v2.py", "papers/vldb/BUDGET_METHOD_V2_20261104.md",
    "scripts/run_vldb_interval_gate_v1.py", "scripts/vldb_interval_envelope_v1.py",
    "scripts/vldb_capture_attribute_v0.py", "scripts/vldb_stream_frontier_v0.py",
    "src/pkgea/backbones/attribute.py", "src/pkgea/backbones/toy.py",
    "src/pkgea/query/index.py", "src/pkgea/scope.py", "src/pkgea/contracts.py",
    "src/pkgea/certified.py",
)


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def read(path: Path) -> dict:
    return json.loads(path.read_text("utf-8-sig"))


def write_new(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def verify(config: dict, protocol: Path, output: Path, create: bool) -> None:
    from pkgea.contracts import dataset_revision_digest

    parents = {}
    for key in ("parent_V0", "parent_V1"):
        folder = ROOT / config[key]
        frozen = read(folder / "protocol_freeze.json")
        for name, expected in frozen["code_sha256"].items():
            if digest(ROOT / name) != expected:
                raise ValueError(f"inherited frozen file changed: {name}")
        parents[config[key]] = digest(folder / "protocol_freeze.json")
    revisions = {}
    for specification in config["stream_manifests"]:
        path = (ROOT / specification["path"]).resolve()
        path.relative_to(ROOT)
        if digest(path) != specification["sha256"]:
            raise ValueError("changed V0 identity manifest")
        manifest = read(path)
        dataset = (ROOT / manifest["dataset_path"]).resolve()
        dataset.relative_to(ROOT)
        revision = dataset_revision_digest(dataset)
        if revision != manifest["dataset_revision"]:
            raise ValueError("changed input dataset")
        revisions[manifest["dataset_path"]] = revision
    identity = {"protocol_sha256": digest(protocol),
                "code_sha256": {name: digest(ROOT / name) for name in FILES},
                "dataset_revisions": revisions, "parent_freezes_sha256": parents}
    freeze_path = output / "protocol_freeze.json"
    if create:
        write_new(output / "protocol_snapshot.json", config)
        write_new(freeze_path, {**identity, "created_utc": datetime.now(timezone.utc).isoformat()})
    else:
        frozen = read(freeze_path)
        if any(frozen[key] != value for key, value in identity.items()):
            raise ValueError("V2 frozen protocol, code, inputs or ancestors changed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", default="configs/vldb_budget_v2_20261104.json")
    parser.add_argument("--stage", choices=("freeze", "run"), required=True)
    arguments = parser.parse_args()
    protocol = (ROOT / arguments.protocol).resolve()
    config = read(protocol)
    if os.environ.get("PYTHONHASHSEED") != config["required_pythonhashseed"]:
        raise ValueError("launch with the frozen Python hash seed")
    output = (ROOT / config["result_root"]).resolve()
    output.relative_to(ROOT)
    verify(config, protocol, output, arguments.stage == "freeze")
    if arguments.stage == "run":
        from run_vldb_budget_gate_v2 import run_budget_gate

        result = run_budget_gate(config, ROOT, output / "artifacts")
        verify(config, protocol, output, False)
        write_new(output / "budget_gate.json", result)
        write_new(output / "complete.json", {
            "status": "STAGE_EXECUTION_COMPLETE", "result_status": result["status"],
            "protocol_sha256": digest(protocol),
            "scientific_pass": "assess soundness, paid-work coverage and strong-baseline increments",
            "IJCAI_research_resumed": False,
        })
    print(json.dumps({"stage": arguments.stage, "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
