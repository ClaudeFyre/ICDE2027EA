"""Read-only aggregation/audit of durable ICDE scale and optional later gates.

Only new analysis artifacts are written. No scorer, training, RNG or world
generation is executed. Comparison/neural gates not supplied are PENDING;
the complete 9000-case scale gate can be audited independently.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import struct
from types import SimpleNamespace
import traceback

from icde_online_analysis_20261104 import (
    Analyzer, aggregate_rows, descriptive, scientific_identity, write_csv, write_json,
)
from icde_gate_scale_runner import canonical_digest, case_key, query_identity

ROOT = Path(__file__).resolve().parents[1]
METHODS = ("scope_full_risk", "difference_eager", "difference_lazy")
POLICIES = ("normal_nominal", "ppr_nominal", "eb_nominal", "normal_scope",
            "normal_event", "eb_scope", "eb_event")
LOOKS = (32, 64, 128, 256, 512)
FAMILIES = ("A_full_edge_box", "B_maintenance128")
PRIOR128 = ROOT / "nodes/09_vldb_query_certification/results/icde_online_scale128_20261104_attempt1"


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def inside(path, parent=ROOT):
    path = Path(path)
    path = path.resolve() if path.is_absolute() else (ROOT / path).resolve()
    path.relative_to(Path(parent).resolve())
    return path


def compact_row(row, stage):
    compact = {"stage": stage, **{key: row[key] for key in (
        "graph", "query_id", "seed", "method", "candidate_count", "scope_edge_count",
        "nominal_certified", "stable", "status", "samples_used", "event_samples_used",
        "event_count", "random_uniform_draws", "work_used", "work_budget")},
        **{f"seconds_{key}": value for key, value in row["seconds"].items()}}
    if stage == "inference_controls":
        compact.update({"stable": row["robust_certified"], "objective": row["objective"],
                        "objective_certified": row["certified"]})
    return compact


def aggregate_groups(rows):
    result = []
    graphs = sorted({row["graph"] for row in rows})
    methods = sorted({row["method"] for row in rows})
    for graph in ("ALL", *graphs):
        for method in methods:
            group = [row for row in rows if row["method"] == method and (graph == "ALL" or row["graph"] == graph)]
            if group:
                metrics = aggregate_rows(group)
                if "objective_certified" in group[0]:
                    metrics.update({"objective": group[0]["objective"],
                        "objective_certificates": sum(row["objective_certified"] for row in group),
                        "competitive_objective_certificates": sum(row["objective_certified"] for row in group if row["candidate_count"] > 1)})
                result.append({"graph": graph, "method": method, **metrics})
    return result


class Evidence:
    def __init__(self):
        self.base = Analyzer()
        self.audit = self.base.audit
        self.scale_rows = []
        self.comparison_rows = []
        self.shards = []
        self.neural_rows = []
        self.query_digests = {}
        self.comparison_prefixes = {}
        self.provenance = []

    def check_hashes(self, mapping, label):
        for relative, expected in mapping.items():
            path = inside(relative)
            self.audit.check(path.is_file() and self.base.sha(path) == expected,
                             "frozen_source_or_input_sha256", f"{label}:{relative}")

    def setup_identity(self, report, label):
        revision, hashes, pool = self.base.dataset(report["dataset_path"])
        self.audit.check(report["dataset_revision"] == revision and report["input_sha256"] == hashes,
                         "setup_input_identity", label)
        self.audit.nonnegative(report["seconds"], "setup_time_nonnegative", label)
        result = {}
        for metadata in report["query_setup"]:
            prepared = SimpleNamespace(graph=report["graph"], query_id=metadata["query_id"],
                dataset_revision=revision, metadata=metadata, scope_epsilon=metadata["scope_epsilon_upper"])
            identity = query_identity(prepared)
            key = (report["graph"], revision, metadata["query_id"])
            signature = scientific_identity(identity)
            if key in self.base.query_identities:
                self.audit.check(self.base.query_identities[key] == signature, "cross_gate_query_identity", label)
            else:
                self.base.query_identities[key] = signature
            result[report["graph"], metadata["query_id"]] = identity
            self.audit.check(metadata["candidate_audit"]["status"] == metadata["coupled_audit"]["status"] == "PASS"
                             and metadata["scope_certificate"]["exact"] is True,
                             "candidate_scope_diagnostics", f"{label}:{metadata['query_id']}")
        return result

    def scale(self, prefix, prior128):
        prefix = inside(prefix)
        all_keys, sources = set(), defaultdict(set)
        common_sources, common_config = None, None
        for shard in range(8):
            matches = sorted(path for path in prefix.parent.glob(prefix.name + f"{shard:02d}_attempt*") if path.is_dir())
            if len(matches) != 1:
                raise ValueError(f"expected exactly one fixed attempt for shard{shard}, found {len(matches)}")
            folder = matches[0]
            manifest_path, checkpoint_path = folder / "protocol_freeze.json", folder / "checkpoint.json"
            manifest, checkpoint = load(manifest_path), load(checkpoint_path)
            digest = canonical_digest(manifest)
            label = folder.name
            self.audit.check(manifest["shard"] == shard and manifest["shard_size"] == 64
                             and manifest["shard_count"] == 8, "scale_shard_partition", label)
            self.audit.check(checkpoint["status"] == "COMPLETE" and checkpoint["manifest_sha256"] == digest,
                             "scale_complete_checkpoint", label)
            self.check_hashes(manifest["source_sha256"], label)
            if common_sources is None:
                common_sources = manifest["source_sha256"]
            self.audit.check(common_sources == manifest["source_sha256"], "same_scale_execution_sources", label)
            config = manifest["effective_config"]
            self.audit.check(config["query_count"] == 500 and manifest["seeds"] == [61, 73, 89]
                             and tuple(manifest["methods"]) == METHODS and manifest["inference"] == "normal"
                             and manifest["actual_seed_purpose"] == "icde_online_worlds_v1",
                             "scale_frozen_algorithm", label)
            if common_config is None:
                common_config = config
            self.audit.check(common_config == config, "scale_same_config", label)
            queries = {}
            attempts = []
            for attempt_id in checkpoint["attempts"]:
                attempt_dir = folder / "attempts" / attempt_id
                setups = []
                for setup_path in sorted(attempt_dir.glob("setup_*.json")):
                    report = load(setup_path)
                    queries.update(self.setup_identity(report, f"{label}:{attempt_id}"))
                    setups.append({"graph": report["graph"], "path": str(setup_path.relative_to(ROOT)),
                        "sha256": self.base.sha(setup_path),
                        "graph_setup_seconds": report["seconds"]["graph_total_including_audits"]})
                complete_path = attempt_dir / "complete.json"
                complete = load(complete_path) if complete_path.is_file() else None
                if complete:
                    self.audit.nonnegative({key: complete[key] for key in (
                        "elapsed_seconds", "engine_import_seconds", "graph_setup_seconds")},
                        "shard_attempt_time_nonnegative", f"{label}:{attempt_id}")
                attempts.append({"attempt": attempt_id, "complete": complete, "setup_files": setups})
            expected_files = {}
            expected_case_count = 0
            for profile in manifest["profiles"]:
                revision, hashes, pool = self.base.dataset(profile["dataset_path"])
                ordered = sorted(pool, key=lambda source: (
                    hashlib.sha256(f"vldb-v0-20261104|{source}".encode()).digest(), source))
                selected = ordered[shard * 64:(shard + 1) * 64]
                graph = profile["graph"]
                self.audit.check(len(pool) == len(set(pool)) == 500 and profile["full500_source_order"] == ordered
                    and profile["selected_source_ids"] == selected and profile["global_rank_start"] == shard * 64,
                    "exact_500_source_partition", f"{label}:{graph}")
                self.audit.check(revision == profile["dataset_revision"] and hashes == profile["input_sha256"],
                                 "scale_manifest_input_identity", f"{label}:{graph}")
                self.base.graph_inputs[graph] = (profile["dataset_path"], revision, tuple(sorted(hashes.items())))
                for offset, query_id in enumerate(selected):
                    sources[graph].add(query_id)
                    for seed in manifest["seeds"]:
                        for method in manifest["methods"]:
                            name = case_key(graph, shard * 64 + offset, seed, method)
                            expected_files[name] = (graph, query_id, seed, method, shard * 64 + offset)
                            expected_case_count += 1
            self.audit.check(set(checkpoint["completed"]) == set(expected_files)
                and checkpoint["completed_cases"] == checkpoint["expected_cases"] == expected_case_count,
                "exact_shard_case_grid", label)
            present = {path.relative_to(folder / "cases").as_posix() for path in (folder / "cases").rglob("*.json")}
            self.audit.check(present == set(expected_files), "no_extra_or_missing_case_files", label)
            serving_by_attempt = Counter()
            case_bytes = 0
            for name, expected in expected_files.items():
                path = folder / "cases" / name
                record = checkpoint["completed"][name]
                self.audit.check(self.base.sha(path) == record["sha256"], "scale_case_file_hash", f"{label}:{name}")
                envelope = load(path)
                row, identity = envelope["row"], envelope["query_identity"]
                identity_digest = canonical_digest(identity)
                self.audit.check(envelope["status"] == "COMPLETE" and envelope["manifest_sha256"] == digest
                    and envelope["query_identity_sha256"] == record["query_identity_sha256"] == identity_digest,
                    "case_manifest_query_hash_binding", f"{label}:{name}")
                graph, qid, seed, method, rank = expected
                self.audit.check((row["graph"], row["query_id"], row["seed"], row["method"], envelope["global_query_rank"])
                    == expected and envelope["shard"] == shard, "case_grid_identity", f"{label}:{name}")
                self.audit.check((graph, qid) in queries and canonical_digest(queries[graph, qid]) == identity_digest,
                    "case_rebuilt_setup_identity", f"{label}:{name}")
                key = (graph, qid, seed, method)
                self.audit.check(key not in all_keys, "unique_scale_case", f"{label}:{name}")
                all_keys.add(key)
                self.base.validate_row(row, identity, config, f"{label}:{name}", "scale500_shards")
                self.scale_rows.append(compact_row(row, "scale500_shards"))
                serving_by_attempt[envelope["attempt"]] += row["seconds"]["query_serving_total"]
                case_bytes += path.stat().st_size
                del envelope, row, identity
            for attempt in attempts:
                complete = attempt["complete"]
                if complete:
                    serving = serving_by_attempt[attempt["attempt"]]
                    residual = complete["elapsed_seconds"] - complete["graph_setup_seconds"] - complete["engine_import_seconds"] - serving
                    self.audit.check(residual >= -1e-5, "elapsed_encloses_measured_stages", f"{label}:{attempt['attempt']}")
                    attempt["completed_case_serving_seconds"] = serving
                    attempt["unattributed_seconds_including_identity_serialization_hash_fsync_IO"] = residual
            self.shards.append({"shard": shard, "path": str(folder.relative_to(ROOT)),
                "cases": expected_case_count, "case_json_bytes": case_bytes,
                "all_output_bytes": sum(path.stat().st_size for path in folder.rglob("*") if path.is_file()),
                "attempts": attempts, "protocol_sha256": self.base.sha(manifest_path),
                "checkpoint_sha256": self.base.sha(checkpoint_path)})
        self.audit.check(len(all_keys) == len(self.scale_rows) == 9000 and len(sources) == 2
                         and all(len(values) == 500 for values in sources.values()), "full_9000_case_gate", "scale500")
        # This earlier worker uses identical sources/seeds as a nested subset,
        # hence agreement is a regression check, not independent confirmation.
        prior128 = inside(prior128)
        before = self.audit.check_counts["repeat_scientific_result_agreement"]
        self.base.batch(prior128)
        cross_checks = self.audit.check_counts["repeat_scientific_result_agreement"] - before
        self.audit.check(cross_checks == 128 * 2 * 3 * 3, "all_prior128_scientific_cases_matched", str(prior128))
        return {"status": "COMPLETE", "cases": len(all_keys), "distinct_sources": sum(map(len, sources.values())),
            "queries_per_graph": 500, "seeds": [61, 73, 89], "methods": list(METHODS),
            "aggregate": aggregate_groups(self.scale_rows), "shards": self.shards,
            "prior128": {"path": str(prior128.relative_to(ROOT)), "matched_cases": cross_checks,
                         "same_query_seed_scientific_identity_and_outcomes": True,
                         "times_required_equal": False, "independent_replication": False},
            "byte_semantics": "Final persisted file sizes, not cumulative bytes written by repeated checkpoint replacements.",
            "timing_warning": "Per-shard setup and durable fsync writes are actual costs. The sum is not unsharded cold pipeline latency; residual overhead is not a pure I/O measurement."}

    def comparison(self, folder):
        folder = inside(folder)
        freeze, summary = load(folder / "protocol_freeze.json"), load(folder / "summary.json")
        self.audit.check(summary["status"] == "COMPLETE", "comparison_complete", str(folder))
        self.check_hashes(freeze["code_sha256"], "comparison")
        from icde_gate_comparison_runner import prepare_settings, actual_checkpoints
        import icde_gate_inference as inference
        import vldb_event_bound_v2 as event_bounds
        settings = prepare_settings(freeze["config"], freeze["resolved_query_count"])
        checks = actual_checkpoints(settings)
        self.audit.check(list(checks) == freeze["actual_nominal_checkpoints"] and tuple(freeze["policies"]) == POLICIES
            and freeze["resolved_query_count"] == 16 and len(freeze["resolved_seeds"]) == 3,
            "comparison_frozen_grid", str(folder))
        queries = {}
        for item in summary["setup_files"]:
            path = inside(item["path"], folder)
            self.audit.check(self.base.sha(path) == item["sha256"], "comparison_setup_hash", str(path))
            report = load(path)
            queries.update(self.setup_identity(report, str(path)))
        expected = {(g, q, seed, policy) for g, q in queries for seed in freeze["resolved_seeds"] for policy in POLICIES}
        observed = set()
        for item in summary["case_files"]:
            path = inside(item["path"], folder)
            self.audit.check(self.base.sha(path) == item["sha256"], "comparison_case_hash", str(path))
            row = load(path)
            key = (row["graph"], row["query_id"], row["seed"], row["policy"])
            self.audit.check(key not in observed and key in expected, "comparison_case_grid_identity", str(path))
            observed.add(key)
            query = queries[row["graph"], row["query_id"]]
            self.comparison_case(row, query, settings, checks, inference, event_bounds, str(path))
            self.comparison_rows.append(compact_row(row, "inference_controls"))
        self.audit.check(observed == expected and len(observed) == summary["completed_cases"] == 672,
                         "seven_policies_96_cases_each", str(folder))
        self.audit.check({path.resolve() for path in (folder / "cases").glob("*.json")}
                         == {inside(item["path"]) for item in summary["case_files"]}, "comparison_no_extra_cases", str(folder))
        return {"status": "COMPLETE", "path": str(folder.relative_to(ROOT)), "cases": len(observed),
            "aggregate": aggregate_groups(self.comparison_rows),
            "seconds_before_summary": summary["seconds_before_summary"],
            "case_and_progress_serialization_seconds": summary["case_and_progress_serialization_seconds"],
            "timer_aliases": "serving_total and query_serving_total are identical parent totals; do not add them to child stage timers.",
            "semantic_warning": "PPR/normal/EB can stop at different samples and certify different counts. PPR is nominal-only; comparisons retain each declared objective and risk."}

    def comparison_case(self, row, query, settings, checks, inference, event_bounds, label):
        a = self.audit
        policy = row["policy"]
        nominal = policy.endswith("_nominal")
        event = policy.endswith("_event")
        ppr = policy == "ppr_nominal"
        delta = settings["delta_nominal"] if event else settings["delta_total"]
        rule = ({"name": "empirical_bernstein", "checkpoints": tuple(n for n in checks if n >= 2)}
                if policy.startswith("eb_") else {"name": "normal_mixture", "rho": settings["nominal"]["rho"]})
        n, m, k = row["samples_used"], row["scope_edge_count"], row["candidate_count"]
        winners = row["winner_indices"]
        a.check(k == query["candidate_count"] and m == query["scope_edge_count"]
                and row["dataset_revision"] == query["dataset_revision"], "comparison_query_contract", label)
        a.check(row["scope_epsilon_upper"] == query["scope_epsilon_upper"], "comparison_scope_bound_identity", label)
        a.check(row["objective"] == ("nominal" if nominal else "robust")
                and row["robust_certified"] == (row["certified"] and not nominal), "comparison_objective", label)
        a.close(row["nominal_delta"], delta, "comparison_nominal_risk", label)
        a.close(row["event_beta_total"], settings["beta_total"] if event else 0., "comparison_event_risk", label)
        a.check(row["actual_nominal_checkpoints"] == list(checks) and row["seed_purpose"] == settings["seed_purpose"],
                "comparison_actual_checks_seed_purpose", label)
        seed_payload = f"vldb-v0-20261104|{row['graph']}|{row['dataset_revision']}|{row['query_id']}|{row['seed']}|{settings['seed_purpose']}"
        seed = int.from_bytes(hashlib.sha256(seed_payload.encode()).digest()[:16], "big")
        a.check(row["rng_seed_hex"] == hex(seed), "comparison_rng_seed", label)
        a.check(len(winners) == n == row["worlds_generated"] == row["nominal_score_rows"]
                and row["random_uniform_draws"] == n * m and row["event_extra_random_draws"] == 0,
                "comparison_draws_counts", label)
        a.check(row["event_rows_computed"] == row["event_samples_used"] <= n
                and 0 <= row["event_count"] <= row["event_free_rows"] <= row["event_samples_used"],
                "comparison_complete_event_prefix", label)
        a.nonnegative(row["seconds"], "comparison_timing_nonnegative", label)
        a.check(row["retained_uniform_values"] == (n * m if event else 0)
                and row["retained_score_values"] == (n * k if event else 0), "comparison_retained_paid_state", label)
        counts = [0] * k
        previous_n = previous_event = 0
        model, fees = query["cost_model"], settings["work_model"]
        unit = max(1, m + model["original_incidence_entries"] + fees["nominal_candidate_units"] * k)
        worst = 2 * m + 2 * model["interval_incidence_entries"] + fees["interval_candidate_units"] * k
        budget = (int(settings["sample_count"] * settings["budget_fraction"]) + 1) * unit
        work = float(unit)
        winner_hash = hashlib.sha256()
        first_nominal_n = 0 if k == 1 else None
        first_nominal_candidate = 0 if k == 1 else None
        for index, point in enumerate(row["trace"]):
            tn, en = point["nominal_samples"], point["event_samples"]
            segment = winners[previous_n:tn]
            a.check(previous_n < tn <= n and tn in checks, "comparison_trace_checks", label)
            for winner in segment:
                if not 0 <= winner < k:
                    raise ValueError("winner outside frozen candidate universe")
                counts[winner] += 1
            winner_hash.update(struct.pack("<" + "q" * len(segment), *segment))
            a.check(winner_hash.hexdigest() == point["winner_prefix_sha256"], "comparison_raw_winner_hash", label)
            identity = (settings["seed_purpose"], row["graph"], row["dataset_revision"], row["query_id"], row["seed"], tn)
            hashes = (point["uniform_prefix_sha256"], point["winner_prefix_sha256"])
            if identity in self.comparison_prefixes:
                a.check(self.comparison_prefixes[identity] == hashes, "comparison_paired_prefix", label)
            else:
                self.comparison_prefixes[identity] = hashes
            if "lower_gap" in point:
                leader = max(range(k), key=lambda index: (counts[index], -index))
                a.check(point["leader_index"] == leader, "comparison_empirical_leader_identity", label)
                if ppr:
                    decision = inference.ppr_details(counts, tn, delta, prior="uniform", allocation="jain_mode")["certified"]
                    a.check(point["lower_gap"] is None, "ppr_not_positive_gap", label)
                else:
                    lower = inference.numerical_gap_bound(counts, tn, delta, rule)
                    a.check(point["lower_gap"] == lower, "comparison_exact_numerical_gap", label)
                    decision = lower > 0
                a.check(point["nominal_certified_now"] == decision, "comparison_nominal_decision", label)
                if decision and first_nominal_n is None:
                    first_nominal_n = tn
                    first_nominal_candidate = leader
            base = work + (tn - previous_n) * unit
            selected = point.get("event_upgrade_to")
            actual = point.get("actual_event_fee", 0.)
            admission = point.get("event_admission", "not_requested")
            if selected is not None:
                a.check(selected in settings["event_checkpoints"] and previous_event < selected <= tn,
                        "comparison_protected_event_look", label)
                a.close(point["static_event_fee"], (selected - previous_event) * worst * settings["interval_work_weight"],
                        "comparison_static_admission_fee", label)
            if admission == "approved":
                a.check(event and selected == en and base + point["static_event_fee"] <= budget + 1e-7
                        and 0 <= actual <= point["static_event_fee"], "comparison_admission_before_evidence", label)
            elif admission == "rejected_budget":
                a.check(en == previous_event and actual == 0 and base + point["static_event_fee"] > budget,
                        "comparison_rejection_preserves_evidence", label)
            else:
                a.check(en == previous_event and actual == 0, "comparison_uncomputed_evidence_unchanged", label)
            work = base + actual
            a.close(point["work_used"], work, "comparison_trace_work", label)
            a.check(work <= budget and en <= tn, "comparison_strict_work", label)
            previous_n, previous_event = tn, en
        a.check(counts == row["winner_counts"] and sum(counts) == n and previous_n == n,
                "comparison_final_counts", label)
        a.close(work, row["work_used"], "comparison_total_work", label)
        exact_work = unit * (n + 1) + settings["interval_work_weight"] * (
            2 * m * row["event_samples_used"] + (2 * model["interval_incidence_entries"]
                + fees["interval_candidate_units"] * k) * row["event_free_rows"])
        a.close(work, exact_work, "comparison_recomputed_final_event_cost", label)
        a.close(budget, row["work_budget"], "comparison_budget", label)
        a.check(row["work_used"] <= budget and row["work_overshoot"] == 0, "comparison_final_work_limit", label)
        a.check(row["nominal_certified"] == (first_nominal_n is not None)
                and row["nominal_certificate_samples"] == first_nominal_n
                and row["nominal_candidate_index"] == first_nominal_candidate, "comparison_first_nominal_freeze", label)
        a.check(row["winner_prefix_sha256"] == winner_hash.hexdigest(), "comparison_final_winner_hash", label)
        if row["trace"]:
            a.check(row["uniform_prefix_sha256"] == row["trace"][-1]["uniform_prefix_sha256"],
                    "comparison_final_uniform_hash", label)
        if not event:
            a.check(row["event_samples_used"] == row["event_count"] == 0, "comparison_non_event_policy", label)
        if row["event_samples_used"]:
            bound = event_bounds.fixed_n_binomial_upper(row["event_count"], row["event_samples_used"], settings["risk_plan"]["alpha_per_checkpoint"])
            a.check(row["event_upper"] == bound, "comparison_final_CP_bound", label)
        if row["certified"] and k > 1:
            ci = row["certified_candidate_index"]
            a.check(ci == max(range(k), key=lambda index: (counts[index], -index))
                and row["certified_candidate"] == query["candidate_ids"][ci], "comparison_returned_candidate_identity", label)
            if nominal:
                decision = (inference.ppr_certified(counts, n, delta, prior="uniform", allocation="jain_mode")
                    if ppr else inference.numerical_gap_bound(counts, n, delta, rule) > 0)
            else:
                decision = inference.numerical_gap_bound(counts, n, delta, rule) > 2 * min(row["scope_epsilon_upper"], row["event_upper"])
            a.check(decision, "comparison_returned_certificate", label)
        if ppr and row["ppr_final_test"] is not None:
            expected = inference.ppr_details(counts, n, delta, prior="uniform", allocation="jain_mode")
            a.check(all(row["ppr_final_test"][key] == expected[key] for key in (
                "certified", "candidate_index", "leader_count", "competitor_count", "alpha_exact", "prior", "allocation")),
                "comparison_exact_PPR_final", label)

    def neural(self, folder):
        import numpy as np
        import icde_gate_inference as inference
        from run_vldb_interval_gate_v1 import clipped_box, conservative_scope_tv
        folder = inside(folder)
        protocol, summary = load(folder / "protocol_before_draws.json"), load(folder / "summary.json")
        self.audit.check(summary["status"] == "COMPLETE" and protocol["requested_worlds"] == 512
            and protocol["primary_worlds"] == 256 and protocol["diagnostic_worlds"] == 512
            and protocol["looks"] == list(LOOKS), "neural_frozen_primary_diagnostic", str(folder))
        self.audit.check(protocol["world_seed"] == 107 and protocol["model_seed"] == 17
            and all(protocol["inference"][rule]["delta"] == .05 for rule in
                ("normal", "ppr_uniform_jain", "empirical_bernstein"))
            and protocol["inference"]["ppr_uniform_jain"]["allocation"] == "jain_mode"
            and protocol["inference"]["ppr_uniform_jain"]["positive_gap"] is False,
            "neural_rule_risk_and_stream_contract", str(folder))
        self.check_hashes(protocol["guarded_source_and_input_sha256"], "neural")
        self.check_hashes(protocol["vendor_sha256"], "neural_vendor")
        rows, measurements = [], []
        for key, identity in protocol["graphs"].items():
            graph_out = folder / key
            progress = load(graph_out / "progress.json")
            data_path = inside(identity["data_directory"])
            for filename, expected_sha in identity["data_sha256"].items():
                self.audit.check(self.base.sha(data_path / filename) == expected_sha, "neural_identity_data_hash", f"{key}:{filename}")
            with (data_path / "entities.tsv").open(encoding="utf-8-sig", newline="") as handle:
                entities = list(csv.DictReader(handle, delimiter="\t"))
            entity_position = {row["entity_id"]: index for index, row in enumerate(entities)}
            with (data_path / "alignments.tsv").open(encoding="utf-8-sig", newline="") as handle:
                test_sources = [row["source_entity_id"] for row in csv.DictReader(handle, delimiter="\t") if row["split"] == "test"]
            selected = sorted(set(test_sources), key=lambda source: hashlib.sha256(
                f"ICDE-20261104|rrea-applicability|{key}|test|{source}".encode()).hexdigest())[:32]
            self.audit.check(selected == identity["query_source_ids"]
                and [entity_position[source] for source in selected] == identity["query_source_indices"],
                "neural_static_label_independent_queries", key)
            self.audit.check(progress["status"] == "COMPLETE" and progress["completed_worlds"] == 512
                and progress["weights_unchanged"] is True and progress["audit"]["restore_max_abs_error"] <= 1e-6
                and progress["audit"]["restore_winner_changes"] == 0
                and progress["audit"]["old64_mask_prefix_equal"] is True
                and progress["audit"]["old64_winner_prefix_equal"] is True,
                "neural_complete_original_restore_prefix_audits", key)
            self.audit.nonnegative(progress["costs"], "neural_timing_nonnegative", key)
            masks_path = inside(folder / identity["law_masks_path"], folder)
            self.audit.check(self.base.sha(masks_path) == identity["law_masks_sha256"], "neural_frozen_masks_sha", key)
            with np.load(masks_path, allow_pickle=False) as archive:
                pinned = archive["pinned"].copy()
                optional = archive["optional_original_indices"].copy()
                maintenance = archive["maintenance_original_indices"].copy()
                q = archive["nominal_optional"].copy()
                low_a, high_a = archive["full_box_low_optional"].copy(), archive["full_box_high_optional"].copy()
                low_b, high_b = archive["maintenance_low"].copy(), archive["maintenance_high"].copy()
            heads, tails = [], []
            with (data_path / "triples.tsv").open(encoding="utf-8-sig", newline="") as handle:
                for triple in csv.DictReader(handle, delimiter="\t"):
                    heads.append(entity_position[triple["head_id"]])
                    tails.append(entity_position[triple["tail_id"]])
            first = np.full(len(entities), len(heads), dtype=np.int64)
            np.minimum.at(first, np.asarray(heads), np.arange(len(heads)))
            np.minimum.at(first, np.asarray(tails), np.arange(len(tails)))
            self.audit.check(np.all(first < len(heads)), "neural_no_original_isolated_entities", key)
            expected_pinned = np.zeros(len(heads), dtype=bool)
            expected_pinned[first[first < len(heads)]] = True
            self.audit.check(np.array_equal(pinned, expected_pinned), "neural_exact_G1_pinned_rule", key)
            self.audit.check(np.array_equal(optional, np.flatnonzero(~pinned)) and len(maintenance) == len(set(maintenance.tolist())) == 128
                and all(not pinned[index] for index in maintenance), "neural_optional_maintenance_mask", key)
            expected_maintenance = sorted(optional.tolist(), key=lambda index: (
                hashlib.sha256(f"icde-gate-maintenance-20261104|{key}|{index}".encode()).digest(), index))[:128]
            self.audit.check(maintenance.tolist() == expected_maintenance
                == identity["families"][FAMILIES[1]]["original_triple_indices"], "neural_label_independent_maintenance_selection", key)
            expected_low, expected_high = clipped_box(q, .001)
            self.audit.check(np.array_equal(q, np.full(len(optional), .9)) and np.array_equal(low_a, expected_low)
                and np.array_equal(high_a, expected_high), "neural_full_box_definition", key)
            q_b = np.full(128, .9, dtype=np.float64)
            expected_low, expected_high = clipped_box(q_b, .001)
            self.audit.check(np.array_equal(low_b, expected_low) and np.array_equal(high_b, expected_high),
                             "neural_maintenance_box_definition", key)
            epsilons = {FAMILIES[0]: conservative_scope_tv(q, low_a, high_a)[0],
                        FAMILIES[1]: conservative_scope_tv(q_b, low_b, high_b)[0]}
            for family, epsilon in epsilons.items():
                self.audit.close(epsilon, identity["families"][family]["scope_epsilon_upper"], "neural_conservative_TV", key)
            self.audit.check(epsilons[FAMILIES[0]] == 1. and 0 < epsilons[FAMILIES[1]] < .5,
                             "neural_full_vacuity_and_maintenance_nonvacuity", key)
            latest = inside(folder / progress["latest_prefix_archive"], folder)
            self.audit.check(self.base.sha(latest) == progress["latest_prefix_sha256"], "neural_latest_archive_sha", key)
            with np.load(latest, allow_pickle=False) as archive:
                full_winners = archive["winners"].copy()
                source_indices, target_order = archive["source_indices"].copy(), archive["target_order"].copy()
            self.audit.check(full_winners.shape == (512, 32) and np.all((0 <= full_winners) & (full_winners < 15000)),
                             "neural_winner_universe", key)
            self.audit.check(source_indices.tolist() == identity["query_source_indices"]
                and hashlib.sha256(target_order.tobytes()).hexdigest() == identity["target_order_sha256"],
                "neural_source_candidate_order", key)
            old = identity["old64_reference"]
            old_protocol = load(inside(old["protocol_path"]))
            old_progress = load(inside(old["progress_path"]))
            self.audit.check(self.base.sha(inside(old["protocol_path"])) == old["protocol_sha256"]
                and self.base.sha(inside(old["progress_path"])) == old["progress_sha256"]
                and old_protocol["graphs"][key]["checkpoint_sha256"] == identity["checkpoint_sha256"]
                and old_protocol["graphs"][key]["query_source_indices"] == identity["query_source_indices"]
                and old_progress["winner_trace"] == old["winner_trace"], "neural_frozen_prior64_identity", key)
            self.audit.check(old is not None and np.array_equal(full_winners[:64], np.asarray(old["winner_trace"], dtype=np.int32))
                and progress["snapshots"]["64"]["mask_prefix_sha256"] == old["mask_prefix_sha256"],
                "neural_raw_old64_prefix", key)
            first_nominal = {rule: [0] * 32 for rule in ("normal", "ppr_uniform_jain", "empirical_bernstein")}
            first_robust = {rule: {family: [0] * 32 for family in FAMILIES} for rule in ("normal", "empirical_bernstein")}
            first_winner = {rule: [None] * 32 for rule in first_nominal}
            robust_winner = {rule: {family: [None] * 32 for family in FAMILIES} for rule in first_robust}
            for n in LOOKS:
                prefix_path = graph_out / "prefixes" / f"prefix_{n:04d}.npz"
                with np.load(prefix_path, allow_pickle=False) as archive:
                    counts = archive["counts"].copy()
                    winners = archive["winners"].copy()
                    means = archive["mean_scores"].copy()
                self.audit.check(np.array_equal(winners, full_winners[:n]) and counts.shape == (32, 15000)
                    and np.all(counts.sum(1) == n) and means.shape == counts.shape and np.isfinite(means).all(),
                    "neural_complete_prefix_arrays", f"{key}:{n}")
                snapshot = progress["snapshots"][str(n)]
                self.audit.check(hashlib.sha256(winners.astype("<i4").tobytes()).hexdigest() == snapshot["winner_prefix_sha256"],
                                 "neural_winner_prefix_sha", f"{key}:{n}")
                for source in range(32):
                    expected_counts = np.bincount(full_winners[:n, source], minlength=15000)
                    self.audit.check(np.array_equal(counts[source], expected_counts), "neural_exact_categorical_counts", f"{key}:{n}:{source}")
                    leader = int(np.argmax(expected_counts))
                    gaps = {"normal": inference.numerical_gap_bound(expected_counts, n, .05, {"name": "normal_mixture", "rho": 64}),
                            "empirical_bernstein": inference.numerical_gap_bound(expected_counts, n, .05,
                                {"name": "empirical_bernstein", "checkpoints": list(LOOKS)})}
                    flags = {rule: gap > 0 for rule, gap in gaps.items()}
                    flags["ppr_uniform_jain"] = inference.ppr_certified(expected_counts, n, .05, prior="uniform", allocation="jain_mode")
                    for rule, flag in flags.items():
                        if flag and first_nominal[rule][source] == 0:
                            first_nominal[rule][source], first_winner[rule][source] = n, leader
                    for rule, gap in gaps.items():
                        self.audit.check(gap == snapshot["numerical_lower_gaps"][rule][source], "neural_exact_rule_lower_gap", f"{key}:{n}:{source}")
                        for family, epsilon in epsilons.items():
                            if gap > 2 * epsilon and first_robust[rule][family][source] == 0:
                                first_robust[rule][family][source], robust_winner[rule][family][source] = n, leader
                expected_certificates = {"nominal": {rule: sum(value > 0 for value in first) for rule, first in first_nominal.items()},
                    "robust": {rule: {family: sum(value > 0 for value in first) for family, first in families.items()}
                               for rule, families in first_robust.items()}}
                self.audit.check(snapshot["certificate_counts"] == expected_certificates, "neural_snapshot_certificate_counts", f"{key}:{n}")
                if n in (256, 512):
                    summary_key = "primary256" if n == 256 else "diagnostic512"
                    self.audit.check(summary["graphs"][key][summary_key] == expected_certificates,
                                     "neural_summary_snapshot_agreement", f"{key}:{n}")
                    rows.append({"graph": key, "worlds": n, "role": "primary" if n == 256 else "diagnostic",
                                 "cases": 32, "certificate_counts": expected_certificates, "epsilons": epsilons})
            for rule, first in first_nominal.items():
                self.audit.check(progress["first_nominal"][rule]["first_world"] == first
                    and progress["first_nominal"][rule]["candidate_position"] == first_winner[rule],
                    "neural_frozen_first_nominal", f"{key}:{rule}")
            for rule, families in first_robust.items():
                for family, first in families.items():
                    self.audit.check(progress["first_robust"][rule][family]["first_world"] == first
                        and progress["first_robust"][rule][family]["candidate_position"] == robust_winner[rule][family],
                        "neural_frozen_first_robust", f"{key}:{rule}:{family}")
            self.audit.check(progress["rng_coordinate_draws"] == 512 * len(pinned)
                and progress["effective_optional_draws"] == 512 * len(optional)
                and progress["world_encoder_calls"] == 512, "neural_draws_and_shared_encoder", key)
            measurements.append({"graph": key, "graph_total_seconds": progress["graph_total_seconds"],
                "costs": progress["costs"], "resources": progress["resources"],
                "peak_observed_process_rss_bytes": progress["peak_observed_process_rss_bytes"],
                "world_encoder_calls": progress["world_encoder_calls"],
                "rng_coordinate_draws": progress["rng_coordinate_draws"],
                "timer_hierarchy": "all_inference_seconds includes its normal/PPR/EB sub-timers; not additive"})
        self.neural_rows = rows
        return {"status": "COMPLETE", "path": str(folder.relative_to(ROOT)), "rows": rows,
            "measurements": measurements,
            "elapsed_seconds": summary["elapsed_seconds"], "protocol_sha256": self.base.sha(folder / "protocol_before_draws.json"),
            "scope_warning": "Maintenance128 restricts parameter updates; encoder/query scope remains full graph. Full edgebox remains vacuous. No fact calibration or adaptive encoder saving is established."}


def draft(result, chinese=False):
    audit = result["audit"]["status"]
    lines = ["# ICDE门槛证据核验" if chinese else "# ICDE gate evidence audit", "",
        (f"审计状态：**{audit}**。500查询门槛可独立核验；未提供的后续门槛标记为PENDING。" if chinese else
         f"Audit status: **{audit}**. The 500-query gate is audited independently; unspecified later gates remain PENDING."), "",
        ("每图500个不同查询，共1000个source；三个种子重复。三方法合计9000个case，不能称9000个独立查询。" if chinese else
         "There are 500 distinct queries per graph, 1000 sources total, repeated under three seeds. The three methods produce 9000 cases, not 9000 independent queries."), "",
        "| Graph | Method | Nominal | Robust | Competitive robust | Serving total s | Competitive p50/p95 ms |",
        "| --- | --- | ---: | ---: | ---: | ---: | ---: |"]
    for row in result["scale"]["aggregate"]:
        timings = row["competitive_serving_seconds"]
        latency = f"{1000*timings['median']:.4f}/{1000*timings['p95_linear']:.4f}" if timings["n"] else "n/a"
        lines.append(f"| {row['graph']} | {row['method']} | {row['nominal_certificates']}/{row['cases']} | {row['robust_certificates']}/{row['cases']} | {row['nontrivial_robust_certificates']}/{row['nontrivial_cases']} | {row['serving_seconds']['sum']:.4f} | {latency} |")
    lines += ["", ("计时包含实际分片设置与持久化成本；八片总和不是未分片cold延迟。未分解残差包含hash、序列化、fsync与I/O，不能当作纯I/O时间。" if chinese else
        "Shard elapsed times include their actual setup and durability overhead. Their sum is not unsharded cold latency. Residual overhead includes hashing, serialization, fsync and I/O and cannot be reported as pure I/O time."), "",
        "| Shard | Cases | Attempt elapsed s | Graph setup s | Case bytes |",
        "| ---: | ---: | ---: | ---: | ---: |"]
    for shard in result["scale"]["shards"]:
        completes = [attempt["complete"] for attempt in shard["attempts"] if attempt["complete"]]
        lines.append(f"| {shard['shard']} | {shard['cases']} | {sum(item['elapsed_seconds'] for item in completes):.3f} | {sum(item['graph_setup_seconds'] for item in completes):.3f} | {shard['case_json_bytes']} |")
    lines += ["", f"Comparison: **{result['comparison']['status']}**. Neural: **{result['neural']['status']}**."]
    if result["comparison"]["status"] == "COMPLETE":
        lines += ["", "| Policy | Objective certified | Nominal | Competitive certified | Serving s |",
                  "| --- | ---: | ---: | ---: | ---: |"]
        for row in result["comparison"]["aggregate"]:
            if row["graph"] == "ALL":
                lines.append(f"| {row['method']} | {row['objective_certificates']}/{row['cases']} | {row['nominal_certificates']}/{row['cases']} | {row['competitive_objective_certificates']}/{row['nontrivial_cases']} | {row['serving_seconds']['sum']:.4f} |")
        lines += ["", "PPR is nominal-only; its certified count is not a robust count. Distinct rules can validly stop at different prefixes."]
    if result["neural"]["status"] == "COMPLETE":
        lines += ["", "| Graph | Worlds | Role | Rule | Nominal/32 | Full-box robust/32 | Maintenance128 robust/32 |",
                  "| --- | ---: | --- | --- | ---: | ---: | ---: |"]
        for row in result["neural"]["rows"]:
            for rule, number in row["certificate_counts"]["nominal"].items():
                robust = row["certificate_counts"]["robust"].get(rule)
                lines.append(f"| {row['graph']} | {row['worlds']} | {row['role']} | {rule} | {number} | {robust[FAMILIES[0]] if robust else 'n/a'} | {robust[FAMILIES[1]] if robust else 'n/a'} |")
    lines += ["", ('[说明文本已清理]' if chinese else
        "Risk guarantees are per query, nominal stream and separately evaluated policy/rule, not workload-wide or post-hoc best-rule guarantees. The prior128 check is a nested same-source/seed regression. Localized parameter updates do not establish local GNN execution, and declared retention probabilities are not calibrated fact probabilities. This audit does not establish originality, deployment demand or submission readiness.")]
    if audit != "PASS":
        lines += ["", "**UNVERIFIED: resolve audit failures before using these tables as publication evidence.**"]
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scale-root-prefix", required=True, type=Path)
    parser.add_argument("--comparison", type=Path)
    parser.add_argument("--neural", type=Path)
    parser.add_argument("--prior128", type=Path, default=PRIOR128)
    parser.add_argument("--allow-missing-gates", action="store_true")
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    output = inside(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    try:
        evidence = Evidence()
        scale = evidence.scale(args.scale_root_prefix, args.prior128)
        later = {}
        for name, path in (("comparison", args.comparison), ("neural", args.neural)):
            if path is None:
                later[name] = {"status": "PENDING", "reason": "not supplied; no result assumed"}
            elif not (inside(path) / "summary.json").is_file():
                if not args.allow_missing_gates:
                    raise FileNotFoundError(f"{name} has no completed summary; omit it or use --allow-missing-gates")
                later[name] = {"status": "PENDING", "path": str(path), "reason": "completion summary missing"}
            else:
                later[name] = getattr(evidence, name)(path)
        report = {"status": "PASS" if not evidence.audit.error_counts else "FAIL",
            "check_counts": dict(evidence.audit.check_counts), "error_counts": dict(evidence.audit.error_counts),
            "error_examples": evidence.audit.examples, "warnings": evidence.audit.warnings,
            "paired_scale_prefixes": len(evidence.base.prefixes),
            "paired_comparison_prefixes": len(evidence.comparison_prefixes)}
        result = {"schema": "icde-integrated-gate-evidence-audit-v1", "audit": report,
            "scale": scale, **later,
            "all_three_gates_present": all(later[name]["status"] == "COMPLETE" for name in later),
            "provenance": {"analysis_script_sha256": evidence.base.sha(Path(__file__)),
                "reused_analysis_sha256": evidence.base.sha(ROOT / "scripts/icde_online_analysis_20261104.py"),
                "scope": "record/hash/count/fee/statistical-bound audit; no scorer rerun or world generation",
                "scientific_units": "source query with repeated seeds; not case files or timing repetitions",
                "scale_seed_purpose": "icde_online_worlds_v1",
                "comparison_seed_purpose": "read from its frozen protocol; separate paired stream",
                "neural_stream": "SeedSequence([107,graph_ordinal]); same old64 prefix",
                "timing": "per-shard setup and durability are charged; no unsharded cold reconstruction",
                "claims_not_closed": ["originality/full predecessor overlap", "real deployment demand", "real-fact calibration", "unmeasured adaptive neural encoder savings"]}}
        write_json(output / "summary.json", result)
        write_json(output / "validation.json", report)
        write_csv(output / "scale_cases.csv", evidence.scale_rows)
        write_csv(output / "comparison_cases.csv", evidence.comparison_rows)
        for chinese, name in ((False, "RESULTS_EN.md"), (True, "RESULTS_ZH.md")):
            with (output / name).open("x", encoding="utf-8") as handle:
                handle.write(draft(result, chinese))
        print(json.dumps({"output": str(output.relative_to(ROOT)), "audit": report["status"],
                          "scale_cases": scale["cases"], "comparison": later["comparison"]["status"],
                          "neural": later["neural"]["status"]}))
        if report["status"] != "PASS":
            raise SystemExit(1)
    except Exception as error:
        write_json(output / "analysis_failure.json", {"status": "FAILED", "error": str(error),
            "traceback": traceback.format_exc(), "no_publication_validation": True})
        raise


if __name__ == "__main__":
    main()
