"""Finite G1 development study, with a protocol frozen before new inference.

Uses the old 20 small-scope queries as DEVELOPMENT inputs, not prospective
confirmation. Each action is executed online; exhaustive references are only
used for independent audits and mechanism analysis outside service timing.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
from itertools import product
import hashlib
import json
from pathlib import Path
import time
import zipfile

import numpy as np

import icde_prospective_20261107 as old
from icde_gate_exact_review import tensor_vertex_transform
from icde_refinable_evidence_20261107 import DegreeRefiner, Evidence, exact_mask, members
from run_vldb_interval_gate_v1 import clipped_box


ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "nodes/09_vldb_query_certification/results/icde_refinable_g1_20261107/attempt1"
POLICIES = ("coarse", "fully_paid", "adaptive", "direct_pair_then_fully_paid")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def freeze(out):
    if out.exists():
        raise FileExistsError(out)
    source = old.load(old.BASE / "new_exact_reference/summary.json")
    cases = sorted({(r["graph"], r["rank"]) for r in source["references"]})
    files = [old.BASE / "new_exact_reference/summary.json", old.BASE / "confirmation_protocol.json"]
    selected = []
    for graph, rank in cases:
        path = old.BASE / "prepared" / graph / f"q{rank:03d}.json"
        metadata = old.load(path)
        selected.append({"graph": graph, "rank": rank, "scope_edges": metadata["scope_edges"],
                         "candidates": len(metadata["candidates"]), "query_id": metadata["query_id"]})
        files.extend((path, path.with_suffix(".npz")))
        for tau in (.05, .25, 1.):
            files.append(old.BASE / "new_exact_reference" / f"{graph}_q{rank:03d}_t{tau}.json")
    code = {path: digest for path, digest in old.load(old.BASE / "confirmation_protocol.json")["code_sha256"].items()}
    for name in ("icde_refinable_evidence_20261107.py", "icde_refinable_g1_20261107.py",
                 "icde_gate_exact_review.py", "test_icde_refinable_evidence_20261107.py"):
        code[f"scripts/{name}"] = sha(ROOT / "scripts" / name)
    save(out / "protocol.json", {
        "kind": "development_mechanism_gate_not_confirmation", "cases": selected,
        "selection": "all 20 previously enumerated confirmation queries with K>1 and full scope<=8; known data and prior outcomes",
        "taus": [.05, .25, 1.], "seeds": [541, 557], "max_worlds": 256,
        "pair_work_budget": 2048, "pair_state_cap": 2048, "adaptive_sample_batch": 16,
        "delta_exact": "1/20", "policies": list(POLICIES),
        "cost": "DP transitions plus final reachable-state score evaluations; coarse evaluation, sampling and inference reported separately in elapsed time",
        "policy_order": "rotate by case/tau/seed index; one process, no parallel timings",
        "direct": "all policies first use the same global score interval; extra control attempts pair-DP global proofs",
        "probability": "configured independent retention q=.9; not calibrated fact probabilities",
        "audit": "exhaustive winner map and full-box reference never supplied to a policy",
        "synthetic": "the design's scalar-information separation and quantifier-incompleteness examples",
        "code_sha256": code,
        "input_sha256": {path.relative_to(ROOT).as_posix(): sha(path) for path in files},
        "frozen_at_unix": time.time(), "scope_expansion": False})
    print(json.dumps({"frozen_cases": len(cases), "output": str(out)}, ensure_ascii=False), flush=True)


def preflight(out):
    protocol = old.load(out / "protocol.json")
    checks = 0
    for group in ("code_sha256", "input_sha256"):
        for path, digest in protocol[group].items():
            if sha(ROOT / path) != digest:
                raise AssertionError(f"changed frozen input/source: {path}")
            checks += 1
            if path.endswith(".npz"):
                with zipfile.ZipFile(ROOT / path) as archive:
                    if archive.testzip() is not None:
                        raise AssertionError("bad prepared artifact CRC")
                checks += 1
    if list(out.glob("*.pending")) or (out / "summary.json").exists():
        raise ValueError("partial or completed output needs an explicit new attempt")
    save(out / "recovery.json", {"status": "PASS", "scope": "all frozen inputs and numerical sources for this finite development task",
                                 "checks": checks, "whole_workspace_audit": False})
    print(f"Scoped recovery PASS: {checks} identities/CRC checks", flush=True)


def execute(kernel, uniforms, low, high, policy, protocol):
    started = time.perf_counter()
    refiner = DegreeRefiner(kernel, protocol["pair_state_cap"])
    evidence = Evidence(refiner.k, Q(protocol["delta_exact"]))
    prefix, lows, highs, nominal = [], [], [], []
    attempted = set()
    work = calls = excluded = 0
    statuses = Counter()
    winner, status = None, "unresolved"
    global_low, global_high = np.zeros(refiner.m, dtype=np.bool_), np.ones(refiner.m, dtype=np.bool_)
    direct = refiner.coarse(global_low, global_high)
    if direct & (direct - 1) == 0:
        winner, status = direct.bit_length() - 1, "direct_interval"

    def try_pair(i, w, d, lo, hi):
        nonlocal work, calls
        proof, spent, result = refiner.eliminate(w, d, lo, hi, protocol["pair_work_budget"] - work)
        work += spent
        calls += 1
        statuses[result] += 1
        return proof

    def check():
        nonlocal winner, status
        w, d, certified = evidence.best()
        if certified:
            winner, status = w, "betting"
        return w, d

    if winner is None and policy == "direct_pair_then_fully_paid":
        # Equal-cost additional strong control, not a free exhaustive oracle.
        for d in members(direct, refiner.k):
            for w in range(refiner.k):
                if w != d and try_pair(-1, w, d, global_low, global_high):
                    direct &= ~(1 << d)
                    break
        if direct & (direct - 1) == 0:
            winner, status = direct.bit_length() - 1, "direct_pair"

    while winner is None and len(prefix) < protocol["max_worlds"]:
        batch = protocol["adaptive_sample_batch"] if policy == "adaptive" else 1
        for _ in range(min(batch, protocol["max_worlds"] - len(prefix))):
            i = len(prefix)
            u = uniforms[i]
            lo, hi = u < low, u < high
            y = int(np.argmax(kernel.scores((u < .9)[None, :])[0]))
            mask = refiner.coarse(lo, hi)
            prefix.append(i)
            lows.append(lo)
            highs.append(hi)
            nominal.append(y)
            evidence.append(mask)
            check()
            if winner is not None:
                break
            if policy in ("fully_paid", "direct_pair_then_fully_paid"):
                for d in members(mask, refiner.k):
                    if d == y:
                        continue  # q is in the box: this category is attainable.
                    for w in [y] + [c for c in range(refiner.k) if c not in (y, d)]:
                        if try_pair(i, w, d, lo, hi):
                            evidence.refine(i, evidence.masks[i] & ~(1 << d))
                            excluded += 1
                            check()
                            break
                    if winner is not None or work >= protocol["pair_work_budget"]:
                        break
            if winner is not None:
                break
        if policy == "adaptive" and winner is None:
            while work < protocol["pair_work_budget"]:
                w, d = check()
                if winner is not None:
                    break
                choices = []
                for i, mask in enumerate(evidence.masks):
                    if mask & (mask - 1) == 0 or not mask & (1 << d) or nominal[i] == d:
                        continue
                    pivots = [w] + [c for c in [nominal[i]] + list(range(refiner.k)) if c not in (w, d)]
                    for pivot in dict.fromkeys(pivots):
                        if (i, pivot, d) not in attempted:
                            choices.append((nominal[i] != w, mask.bit_count(), i, pivot, d))
                if not choices:
                    break
                _, _, i, pivot, d = min(choices)
                attempted.add((i, pivot, d))
                if try_pair(i, pivot, d, lows[i], highs[i]):
                    evidence.refine(i, evidence.masks[i] & ~(1 << d))
                    excluded += 1
        if winner is None and len(prefix) == protocol["max_worlds"]:
            check()
    elapsed = time.perf_counter() - started
    return {"policy": policy, "winner": winner, "status": status, "worlds": len(prefix),
            "dp_work": work, "dp_calls": calls, "excluded": excluded,
            "dp_statuses": dict(statuses), "inference_checks": evidence.checks,
            "unique_scalar_evaluations": evidence.scalar_evaluations,
            "compute_seconds": elapsed, "final_masks": evidence.masks,
            "input_prefix_sha256": hashlib.sha256(uniforms[:len(prefix)].tobytes()).hexdigest()}


def mechanism(kernel, winners, low, high, reference):
    """Exact expectations by uniform-space regions, outside serving timing."""
    k, m = len(kernel.candidates), len(kernel.edge_indices)
    probabilities = [[1 - Q.from_float(float(h)), Q.from_float(float(l)),
                      Q.from_float(float(h)) - Q.from_float(float(l))] for l, h in zip(low, high)]
    singleton, contains = [Q(0)] * k, [Q(0)] * k
    total = Q(0)
    regions = 0
    for statuses in product(range(3), repeat=m):
        mass = Q(1)
        for e, state in enumerate(statuses):
            mass *= probabilities[e][state]
        if not mass:
            continue
        lo = np.asarray([s == 1 for s in statuses], dtype=np.bool_)
        hi = np.asarray([s != 0 for s in statuses], dtype=np.bool_)
        mask = exact_mask(winners, lo, hi)
        for d in members(mask, k):
            contains[d] += mass
        if mask & (mask - 1) == 0:
            singleton[mask.bit_length() - 1] += mass
        total += mass
        regions += 1
    if total != 1:
        raise AssertionError("uniform-region masses do not sum to one")
    abstract_gaps = [min(singleton[w] - contains[d] for d in range(k) if d != w) for w in range(k)]
    nominal = list(map(Q, reference["nominal_probabilities_exact"]))
    vertex = [tensor_vertex_transform([int(y == c) for y in winners], low, high) for c in range(k)]
    epsilon = max(abs(p - nominal[c]) for c in range(k) for p in vertex[c])
    nominal_winner = max(range(k), key=lambda c: (nominal[c], -c))
    nominal_gap = min(nominal[nominal_winner] - nominal[d] for d in range(k) if d != nominal_winner)
    exact_modes = reference["uniform_winners"]
    return {"positive_mass_regions": regions, "exact_uniform_winners": exact_modes,
            "directional_population_gaps_exact": list(map(str, abstract_gaps)),
            "directional_population_certifiable": any(g > 0 for g in abstract_gaps),
            "best_uniform_candidate_drift_exact": str(epsilon),
            "nominal_gap_exact": str(nominal_gap),
            "scalar_population_certifiable": nominal_gap > 2 * epsilon,
            "quantifier_incomplete": bool(exact_modes) and not any(g > 0 for g in abstract_gaps)}


def audit_compiler(kernel, winners, low, high, uniforms):
    refiner, checks, tighter, complete_mismatch = DegreeRefiner(kernel), 0, 0, 0
    total_work = 0
    # First 16 input draws plus one full Boolean cube; audit-only budget separate.
    states = [(u < low, u < high) for u in uniforms[:16]]
    states.append((np.zeros(refiner.m, dtype=np.bool_), np.ones(refiner.m, dtype=np.bool_)))
    for lo, hi in states:
        truth = exact_mask(winners, lo, hi)
        initial = mask = refiner.coarse(lo, hi)
        if truth & mask != truth:
            raise AssertionError("coarse candidate set excludes attainable winner")
        checks += 1
        for d in members(mask, refiner.k):
            for w in range(refiner.k):
                if w == d:
                    continue
                proof, work, status = refiner.eliminate(w, d, lo, hi, 1000000)
                total_work += work
                if status != "complete":
                    raise AssertionError("small-scope audit unexpectedly capped")
                # Independent direct Boolean-world pair dominance oracle.
                m = refiner.m
                fixed = sum(int(lo[e]) << e for e in range(m))
                free = [e for e in range(m) if hi[e] and not lo[e]]
                worlds = []
                for bits in range(1 << len(free)):
                    world = fixed | sum(((bits >> j) & 1) << e for j, e in enumerate(free))
                    worlds.append([(world >> e) & 1 for e in range(m)])
                scores = kernel.scores(np.asarray(worlds, dtype=np.bool_))
                dominates = (scores[:, w] > scores[:, d]) | ((scores[:, w] == scores[:, d]) & (w < d))
                if proof != bool(np.all(dominates)):
                    raise AssertionError("pair DP differs from independent exhaustive score comparison")
                checks += 1
                if proof:
                    mask &= ~(1 << d)
                    break
        if truth & mask != truth or mask & initial != mask:
            raise AssertionError("refinement unsound or non-monotone")
        tighter += mask != initial
        complete_mismatch += mask != truth
        checks += 1
    return {"checks": checks, "draws_plus_cube": len(states), "tighter_than_intervals": tighter,
            "refined_set_not_exact": complete_mismatch, "audit_dp_work": total_work}


def synthetic(protocol):
    rows = []
    for name in ("scalar_separation", "quantifier_incomplete"):
        for seed in protocol["seeds"]:
            rng = np.random.default_rng(seed)
            evidence = Evidence(3 if name == "scalar_separation" else 2)
            certified = None
            for i in range(1024):
                u = rng.random()
                mask = (1 if u < .6 else 6) if name == "scalar_separation" else (1 if u < .2 else 3)
                evidence.append(mask)
                w, _, good = evidence.best()
                if good:
                    certified = w
                    break
            if name == "scalar_separation" and certified != 0:
                raise AssertionError("prespecified positive example did not certify")
            if name == "quantifier_incomplete" and certified is not None:
                raise AssertionError("prespecified incompleteness example unexpectedly certified")
            rows.append({"name": name, "seed": seed, "winner": certified, "worlds": len(evidence.masks)})
    return rows


def run(out):
    protocol = old.load(out / "protocol.json")
    if old.load(out / "recovery.json")["status"] != "PASS":
        raise AssertionError("need successful scoped recovery")
    for group in ("code_sha256", "input_sha256"):
        for path, digest in protocol[group].items():
            if sha(ROOT / path) != digest:
                raise AssertionError(f"identity changed: {path}")
    rows, mechanisms, audits = [], [], []
    for case_index, case in enumerate(protocol["cases"]):
        kernel, metadata = old.read_query(case["graph"], case["rank"])
        m, k = len(kernel.edge_indices), len(kernel.candidates)
        all_states = ((np.arange(1 << m)[:, None] >> np.arange(m)) & 1).astype(np.bool_)
        winners = np.argmax(kernel.scores(all_states), axis=1).tolist()
        for tau_index, tau in enumerate(protocol["taus"]):
            low, high = clipped_box(np.full(m, .9), tau)
            reference = old.load(old.BASE / "new_exact_reference" / f"{case['graph']}_q{case['rank']:03d}_t{tau}.json")
            analysis = mechanism(kernel, winners, low, high, reference)
            mechanisms.append({**case, "tau": tau, **analysis})
            for seed_index, seed in enumerate(protocol["seeds"]):
                uniforms = np.random.default_rng(seed + 1009 * case_index).random((protocol["max_worlds"], m))
                shift = (case_index + tau_index + seed_index) % len(POLICIES)
                order = list(POLICIES[shift:] + POLICIES[:shift])
                if seed_index == 0:
                    audits.append({**case, "tau": tau, **audit_compiler(kernel, winners, low, high, uniforms)})
                for policy in order:
                    result = execute(kernel, uniforms, low, high, policy, protocol)
                    if result["dp_work"] > protocol["pair_work_budget"]:
                        raise AssertionError("declared DP work budget exceeded")
                    if result["winner"] is not None and result["winner"] not in reference["uniform_winners"]:
                        raise AssertionError("certificate fails the independent exact full-box reference")
                    for i, mask in enumerate(result["final_masks"]):
                        truth = exact_mask(winners, uniforms[i] < low, uniforms[i] < high)
                        if truth & mask != truth:
                            raise AssertionError("final evidence excludes attainable winner")
                    result.pop("final_masks")
                    rows.append({**case, "tau": tau, "seed": seed, **result})
        print(f"completed {case_index + 1}/{len(protocol['cases'])} development queries", flush=True)
    synthetic_rows = synthetic(protocol)
    aggregates = []
    for tau in protocol["taus"]:
        for policy in POLICIES:
            selected = [r for r in rows if r["tau"] == tau and r["policy"] == policy]
            aggregates.append({"tau": tau, "policy": policy, "cases": len(selected),
                               "certified": sum(r["winner"] is not None for r in selected),
                               "mean_seconds": sum(r["compute_seconds"] for r in selected) / len(selected),
                               "total_dp_work": sum(r["dp_work"] for r in selected),
                               "total_worlds": sum(r["worlds"] for r in selected),
                               "statuses": dict(Counter(r["status"] for r in selected))})
    for group in ("code_sha256", "input_sha256"):
        for path, digest in protocol[group].items():
            if sha(ROOT / path) != digest:
                raise AssertionError("frozen historical source/input changed during study")
    save(out / "summary.json", {"status": "PASS", "protocol_sha256": sha(out / "protocol.json"),
        "cases": rows, "aggregates": aggregates, "mechanisms": mechanisms, "compiler_audits": audits,
        "synthetic": synthetic_rows, "distinct_development_queries": len(protocol["cases"]),
        "false_certifications_observed": 0, "historical_inputs_unchanged": True,
        "limitations": ["development data only, not new prospective confirmation",
            "tiny-scope selected subset, not representative of the full workload",
            "elapsed timing is exploratory, no repeated cold-process speedup claim",
            "declared DP work budget is not a hard wall-clock budget or total system cost",
            "does not establish fact calibration, alignment accuracy, novelty or general completeness"]})
    print(json.dumps({"status": "PASS", "policy_runs": len(rows), "aggregates": aggregates}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("freeze", "preflight", "run"), required=True)
    parser.add_argument("--output", type=Path, default=DEFAULT)
    args = parser.parse_args()
    {"freeze": freeze, "preflight": preflight, "run": run}[args.phase](args.output.resolve())
