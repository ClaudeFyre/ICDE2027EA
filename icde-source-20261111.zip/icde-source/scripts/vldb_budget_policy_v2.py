"""Replay frozen service policies with complete prefix evidence and work costs.

The work model is explicit, not elapsed time.  A variable event block can
finish past its deadline; that block cannot issue an on-budget certificate.
Offline flags are only revealed as complete paid prefixes.  No skipped h is
counted as zero and no cost is shared between nominal-seed repetitions.
"""

from __future__ import annotations

from functools import lru_cache
from itertools import accumulate
import math

from vldb_event_bound_v2 import fixed_n_binomial_upper, validate_risk_plan
from vldb_stream_frontier_v0 import normal_radius


POLICIES = ("scope_full_risk", "scope_matched_risk", "difference_eager",
            "difference_lazy", "source_conditioned_lazy")


@lru_cache(maxsize=32768)
def _upper(count: int, n: int, alpha: float) -> float:
    return fixed_n_binomial_upper(count, n, alpha)


def _prefix(values):
    return [0, *accumulate(int(value) for value in values)]


def _run(query, tau_record, settings, plan, policy, fraction, interval_weight):
    k, m = query["candidate_count"], query["scope_edge_count"]
    cost = query["cost_model"]
    incidences = int(cost["original_incidence_entries"])
    interval_incidence = int(cost["interval_incidence_entries"])
    source_incidence = int(cost["source_incidence_entries"])
    # This is a declared accounting convention, not an instruction counter.
    nominal_unit = m + incidences + settings["work_model"]["nominal_candidate_units"] * k
    nominal_unit = max(1, nominal_unit)
    cap = len(query["winner_indices"])
    equivalent_worlds = int(cap * fraction)
    budget = (equivalent_worlds + 1) * nominal_unit
    work = float(nominal_unit)  # common query-plan initialization charge
    flags_key = "h_source_conditioned" if policy == "source_conditioned_lazy" else "h_difference"
    event_counts = _prefix(tau_record[flags_key])
    free_counts = _prefix(tau_record["free_flags"])
    conditional_rows = _prefix(tau_record["conditioning_degree_rows"])
    assignment_counts = _prefix(tau_record["conditioning_assignment_counts"])
    protected = tuple(plan["event_checkpoints"])
    alpha = plan["alpha_per_checkpoint"]
    interval_units = settings["work_model"]["interval_candidate_units"]
    conditioned_units = settings["work_model"]["conditioned_candidate_units"]

    def event_work(n):
        # Two endpoint tests per edge, lower/upper incidence sums only on free
        # worlds, outward candidate calculations; source refinement adds its
        # prepass, eligible degree boxes and enumerated candidate comparisons.
        value = 2 * m * n + (2 * interval_incidence + interval_units * k) * free_counts[n]
        if policy == "source_conditioned_lazy":
            value += 2 * source_incidence * n
            value += 2 * incidences * conditional_rows[n]
            value += conditioned_units * k * assignment_counts[n]
        return interval_weight * value

    nominal_risk = settings["delta_total"] if policy == "scope_full_risk" else settings["delta_nominal"]
    alpha_nominal = nominal_risk / max(k * (k - 1) // 2, 1)
    nominal = settings["nominal"]
    checks = set(range(nominal["minimum_samples"], cap + 1, nominal["check_every"]))
    checks.update((cap, equivalent_worlds))
    checks.update(n for n in protected if n <= cap)
    checks = sorted(n for n in checks if 0 < n <= cap)
    counts = [0] * k
    n, event_n, event_upper = 0, 0, 1.0
    lower = None
    leader = 0
    status = "unresolved_world_cap"
    trace = []
    certified = False
    scope_epsilon = float(tau_record["epsilon_scope_upper"])
    if k == 1:
        certified, status = work <= budget, "structurally_single_candidate"
    else:
        for next_n in checks:
            if work + (next_n - n) * nominal_unit > budget:
                status = "nominal_work_budget"
                break
            for winner in query["winner_indices"][n:next_n]:
                counts[winner] += 1
            work += (next_n - n) * nominal_unit
            n = next_n
            leader = max(range(k), key=lambda index: (counts[index], -index))
            competitor = max(counts[index] for index in range(k) if index != leader)
            lower = max(-1.0, (counts[leader] - competitor) / n
                        - normal_radius(n, alpha_nominal, nominal["rho"]))
            epsilon = min(scope_epsilon, event_upper)
            if lower > 2 * epsilon:
                certified, status = True, "certified"
            elif policy not in ("scope_full_risk", "scope_matched_risk"):
                candidates = [value for value in protected if event_n < value <= n]
                if policy.endswith("lazy"):
                    candidates = [value for value in candidates
                                  if lower > 0 and 2 * _upper(0, value, alpha) < lower]
                if candidates:
                    selected = candidates[0]
                    charge = event_work(selected) - event_work(event_n)
                    work += charge
                    if work > budget:
                        # The completed event block missed the work deadline.
                        # Do not use its answer or continue on free nominal data.
                        status = "event_block_past_budget"
                    else:
                        event_n = selected
                        event_upper = _upper(event_counts[event_n], event_n, alpha)
                        epsilon = min(scope_epsilon, event_upper)
                        if lower > 2 * epsilon:
                            certified, status = True, "certified"
            trace.append({"nominal_samples": n, "event_samples": event_n,
                          "work_completed": work, "lower_gap": lower,
                          "event_upper": event_upper, "status": status})
            if certified or work > budget:
                break
    return {
        "graph": query["graph"], "query_id": query["query_id"],
        "nominal_seed": query["nominal_seed"], "tau": tau_record["tau"],
        "policy": policy, "budget_fraction": fraction,
        "interval_work_weight": interval_weight,
        "candidate_count": k, "nontrivial_query": k > 1,
        "stable": certified, "status": status,
        "certified_candidate_index": leader if certified else None,
        "samples_used": n, "event_samples_used": event_n,
        "work_used": work, "work_budget": budget,
        "work_overshoot": max(0.0, work - budget),
        "nominal_unit_work": nominal_unit,
        "event_bernoulli_uniforms_added": 0,
        "event_ambiguity_upper": event_upper,
        "scope_epsilon_upper": scope_epsilon,
        "final_lower_gap": lower, "nominal_delta": nominal_risk,
        "trace": trace,
    }


def run_budget_policy(query_record: dict, settings: dict) -> list[dict]:
    plan = validate_risk_plan(settings)
    k = query_record["candidate_count"]
    winners = query_record["winner_indices"]
    if type(k) is not int or k < 1 or not winners or any(type(value) is not int or not 0 <= value < k for value in winners):
        raise ValueError("invalid candidate count or complete nominal winner prefix")
    for row in query_record["tau_records"]:
        if row["tau"] not in settings["tau_grid"]:
            raise ValueError("undeclared box")
        for key in ("h_difference", "h_source_conditioned", "free_flags",
                    "conditioning_degree_rows", "conditioning_assignment_counts"):
            if len(row[key]) != len(winners):
                raise ValueError("event and nominal prefixes differ in length")
        if any(new and not old for new, old in zip(row["h_source_conditioned"], row["h_difference"])):
            raise ValueError("conditioning flags must refine the strong baseline")
    for fraction in settings["budget_fractions"]:
        if not math.isfinite(fraction) or not 0 < fraction <= 1:
            raise ValueError("budget fractions must lie in (0,1]")
    for weight in settings["interval_work_weights"]:
        if not math.isfinite(weight) or weight <= 0:
            raise ValueError("interval work weights must be positive")
    return [_run(query_record, row, settings, plan, policy, fraction, weight)
            for row in query_record["tau_records"]
            for fraction in settings["budget_fractions"]
            for weight in settings["interval_work_weights"]
            for policy in POLICIES]
