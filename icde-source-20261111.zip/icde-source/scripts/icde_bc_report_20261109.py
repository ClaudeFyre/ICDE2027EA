"""Independent result accounting, final report and asset manifest; no inference."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import statistics
import time
import numpy as np

from icde_grouped_inventory_20261108 import ROOT, load, save, sha

BASE = ROOT / 'nodes/09_vldb_query_certification/results/icde_bc_pilot_20261109/attempt1'


def audit(out):
    p = load(out / 'protocol.json')
    c = load(out / 'c_static.json')
    b = load(out / 'b_analysis.json')
    v = load(out / 'b_validation.json')
    checks = 0
    for category in ('code_sha256', 'input_sha256'):
        for name, expected in p[category].items():
            if sha(ROOT / name) != expected:
                raise AssertionError(name)
            checks += 1
    expected_c = 1 - sum(r['shared_ideal_work'] for r in c['graphs'].values()) / sum(r['independent_work'] for r in c['graphs'].values())
    if abs(expected_c - c['theoretical_saving']) > 1e-12 or c['theory_pass'] != (expected_c >= .20):
        raise AssertionError('C gate mismatch')
    # Rebuild sharing accounting directly from saved arrays, without pilot grouping.
    for graph, result in c['graphs'].items():
        edge_union, degree_union, group_supports = set(), set(), []
        total_edges, total_degrees, candidates = 0, 0, 0
        for case in p['c_cases']:
            if case['graph'] != graph:
                continue
            stem = ROOT / f"nodes/09_vldb_query_certification/results/icde_prospective_20261107/prepared/{graph}/q{case['rank']:03d}"
            meta = load(stem.with_suffix('.json'))
            with np.load(stem.with_suffix('.npz'), allow_pickle=False) as arrays:
                edges = list(map(int, arrays['edges']))
                edge_union.update(edges)
                total_edges += len(edges)
                candidates += len(meta['candidates'])
                signatures = defaultdict(list)
                supports = [frozenset(edges[int(i)] for i in arrays[f'inc_{j}'])
                            for j in range(2 * (len(meta['candidates']) + 1))]
                for support in supports:
                    total_degrees += len(support)
                    if support:
                        degree_union.add(support)
                for edge in edges:
                    signatures[tuple(j for j, support in enumerate(supports) if edge in support)].append(edge)
                group_supports += [frozenset(xs) for xs in signatures.values()]
        expected = {'independent_edge_draws': total_edges, 'unique_edge_draws': len(edge_union),
                    'independent_degree_additions': total_degrees,
                    'unique_degree_additions': sum(map(len, degree_union)),
                    'candidate_work': 10 * candidates, 'count_groups': len(group_supports),
                    'unique_group_supports': len(set(group_supports))}
        for key, value in expected.items():
            if value != result[key]:
                raise AssertionError((graph, key, value, result[key]))
            checks += 1
    refs = {(r['graph'], r['rank'], r['change']): r for r in v['references']}
    expected_costs = defaultdict(float)
    counts = Counter()
    preparation = defaultdict(float)
    radii = Counter()
    unique_reuses = defaultdict(set)
    for case in p['b_cases']:
        record = load(out / 'b_queries' / f"{case['graph']}_q{case['rank']:03d}.json")
        if len(record['runs']) != 20:
            raise AssertionError('incomplete repeats')
        for method in ('all', 'scope', 'containment', 'margin_incremental'):
            runs = [r for r in record['runs'] if r['method'] == method]
            if sorted(r['repeat'] for r in runs) != list(range(5)):
                raise AssertionError('method repetition mismatch')
            expected_costs[method] += statistics.median(r['total_seconds'] for r in runs)
            preparation[method] += statistics.median(r['preparation_seconds'] for r in runs)
            if method == 'margin_incremental':
                if len({r['radius'] for r in runs}) != 1:
                    raise AssertionError('non-deterministic certified radius')
                radii[str(runs[0]['radius'])] += 1
            for run in runs:
                if len(run['rows']) != 40:
                    raise AssertionError('missing updates')
                if abs(run['total_seconds'] - run['preparation_seconds'] - run['maintenance_seconds']) > 1e-9:
                    raise AssertionError('amortization accounting')
                for row in run['rows']:
                    key = (case['graph'], case['rank'], row['change'])
                    truth = refs[key]['winners']
                    if row['winners'] is not None and truth is not None and row['winners'] != truth:
                        raise AssertionError(('answer mismatch', key))
                    if row['reused']:
                        unique_reuses[method].add(key)
                    counts[f"{method}:{row['status']}"] += 1
                    checks += 1
        checks += 1
    for method, value in expected_costs.items():
        if abs(value - b['cost_seconds_sum_query_medians'][method]) > 1e-9:
            raise AssertionError('reported cost mismatch')
        checks += 1
    measured = 1 - expected_costs['margin_incremental'] / expected_costs['containment']
    if abs(measured - b['saving']) > 1e-12:
        raise AssertionError('saving mismatch')
    predicted_pass = measured >= .20 and b['paired_descriptive_95pct'][0] > 0 and v['status'] == 'PASS'
    if predicted_pass != b['B_pass']:
        raise AssertionError('gate mismatch')
    save(out / 'accounting_audit.json', {'status': 'PASS', 'checks': checks,
         'costs': dict(expected_costs), 'preparation_seconds_sum_query_medians': dict(preparation),
         'status_counts': dict(counts), 'radius_query_counts': dict(radii),
         'unique_reused_query_updates': {k: len(s) for k, s in unique_reuses.items()},
         'reference_updates': len(refs), 'report_script_sha256': sha(Path(__file__)),
         'all_frozen_code_and_inputs_unchanged': True})
    print(f'Accounting and independent C audit PASS: {checks}', flush=True)


def report(out):
    p, c, b, v, a = [load(out / name) for name in ('protocol.json', 'c_static.json',
                              'b_analysis.json', 'b_validation.json', 'accounting_audit.json')]
    if a['status'] != 'PASS':
        raise AssertionError('audit required')
    cp = bool(c['theory_pass'])  # An implementation would be mandatory if true.
    if cp:
        raise AssertionError('C requires measured implementation before joint decision')
    bp = b['B_pass']
    status = 'SELECT_B_FOR_CONFIRMATION' if bp else 'STOP_BC_GATE1'
    costs = b['cost_seconds_sum_query_medians']
    lo, hi = b['paired_descriptive_95pct']
    completed_references = sum(r['winners'] is not None for r in v['references'])
    body = f"# B/C门槛一：完整试探结果\n\n2026-11-09，Asia/Shanghai。全部规则与输入在本轮测量前冻结。**决策：{status}[说明文本已清理]{c['theoretical_saving']:.2%} | 不通过，不实现 |\n| B含预计算的摊销总成本节省 | ≥20% | {b['saving']:.2%} | {('通过' if b['saving'] >= 0.2 else '不通过')} |\n| B配对描述性95%区间 | 下端>0 | [{lo:.2%}, {hi:.2%}] | {('通过' if lo > 0 else '不通过')} |\n| B错误/未核验复用 | 0 / 0 | {len(v['errors'])} / {len(v['unverified_reuse'])} | {('通过' if v['status'] == 'PASS' else '不通过')}[说明文本已清理]{costs['all']:.6f} |\n| scope失效判定 | {costs['scope']:.6f} |\n| scope加包含继承（主基线） | {costs['containment']:.6f} |\n| 预认证范围加增量收缩（含预计算） | {costs['margin_incremental']:.6f} |\n\n候选预计算总费用（各查询重复中位数之和）为{a['preparation_seconds_sum_query_medians']['margin_incremental']:.6f}秒，已经计入最后一行。加载和共同历史初始证书检查单列于b_timing.json，不将其当作B新增收益。存在{b['constant_queries']}个完整计数赢家张量恒定的查询，所有方法获得同一快捷判定。\n\n## 核验\n\n尝试完整重建并精确求解4,040个查询—更新，其中{completed_references:,}项取得完整参考，逐项核查全部方法与重复的输出；决定性极值另用标量sum-product交叉检查。核验状态{v['status']}，输出/标量检查{v['checks']:,}项。全部方法含重复的复用观察{v['reuse_observations_all_methods_and_repeats']:,}项；这是重复核验计数，不是独立证书数量。按方法的唯一复用查询—更新数见accounting_audit.json。\n\n独立费用/静态共享复核{a['checks']:,}[说明文本已清理]{('B通过试探，只允许冻结B实现并进入新查询确认，至少覆盖degree、GCN-Align、SEU；不得将本轮当作Regular核心已成立。' if bp else '[说明文本已清理]')}\n\n文件：protocol.json、updates.json、c_static.json、b_queries/（101份）、b_timing.json、b_validation.json、b_analysis.json、accounting_audit.json。本报告为这些原始结果的展示，不覆盖它们。\n"
    with (out / 'RESULTS_ZH.md').open('x', encoding='utf-8') as f:
        f.write(body)
    save(out / 'decision.json', {'status': status, 'C_pass': False, 'B_pass': bp,
         'A_remains_stopped': True, 'new_confirmation_started': False,
         'protocol_sha256': sha(out / 'protocol.json'),
         'results_sha256': {name: sha(out / name) for name in
              ('c_static.json', 'b_timing.json', 'b_analysis.json', 'b_validation.json',
               'accounting_audit.json', 'RESULTS_ZH.md')}, 'decided_at_unix': time.time()})
    paths = sorted(path for path in out.rglob('*') if path.is_file())
    resource_records = []
    for pattern in ('icde_bc_*20261109_a1.json', 'icde_b_*20261109_a1.json', 'icde_c_static_20261109_a1.json'):
        resource_records += list((ROOT / '.runtime/runs').glob(pattern))
    resources = {}
    for path in sorted(set(resource_records)):
        record = load(path)
        resources[path.relative_to(ROOT).as_posix()] = sha(path)
        log = Path(record['log_path'])
        if log.exists():
            resources[log.relative_to(ROOT).as_posix()] = sha(log)
    save(out / 'asset_manifest.json', {'kind': 'BC_result_archive_without_historical_rewrites',
         'decision': status, 'files': {p.relative_to(ROOT).as_posix(): sha(p) for p in paths},
         'upstream_assets': p['input_sha256'], 'frozen_code': p['code_sha256'],
         'completed_resource_records_and_logs': resources,
         'report_code_sha256': sha(Path(__file__)),
         'replay': 'verify identities/CRC; use a fresh explicit output directory; never overwrite current results'})
    print(status, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['audit', 'report'], required=True)
    parser.add_argument('--output', type=Path, default=BASE)
    args = parser.parse_args()
    {'audit': audit, 'report': report}[args.phase](args.output.resolve())
