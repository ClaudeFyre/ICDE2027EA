"""Independent artifact, matrix and aggregate checks; no solver reruns."""
import math
from collections import defaultdict
from pathlib import Path

from icde_grouped_inventory_20261108 import load,save,sha,identities
from icde_portfolio_study_20261108 import BASE


def main():
    p,s,a = [load(BASE/name) for name in ('protocol.json','summary.json','analysis.json')]
    checks = identities(p,crc=True)
    if s['protocol_sha256'] != sha(BASE/'protocol.json') or a['summary_sha256'] != sha(BASE/'summary.json'):
        raise AssertionError('broken output provenance')
    checks += 2
    refs = {(r['graph'],r['rank']):r for r in s['references']}
    if len(refs)!=148 or set(refs)!={(c['graph'],c['rank']) for c in p['cases']}:
        raise AssertionError('wrong query selection')
    table = defaultdict(list)
    keys = set()
    for r in s['rows']:
        q = r['graph'],r['rank']
        key = q+(r['policy'],r['repeat'])
        if key in keys or r['seed'] != p['seeds'][r['repeat']]:
            raise AssertionError('duplicate row or wrong seed')
        keys.add(key)
        file = BASE/'cases'/f"{r['graph']}_q{r['rank']:03d}_{r['policy']}_r{r['repeat']}.json"
        if load(file)!=r:
            raise AssertionError('summary differs from per-run artifact')
        elapsed = r['compute_seconds']
        if r['budget_seconds'] != .1 or elapsed<0 or not math.isfinite(elapsed):
            raise AssertionError('invalid time accounting')
        if not math.isclose(r['overrun_seconds'],max(0.,elapsed-.1),abs_tol=1e-12):
            raise AssertionError('invalid overrun')
        if (r['status']=='timeout') != r['timed_out'] or (elapsed>.1 and r['status']!='timeout'):
            raise AssertionError('late result delivered')
        if r['status']=='stable' and r['winner'] not in refs[q]['uniform_winners']:
            raise AssertionError('invalid stable certificate')
        if r['status']=='nonuniform' and refs[q]['uniform_winners']:
            raise AssertionError('invalid nonuniform proof')
        if r['status'] in ('timeout','unresolved','nonuniform') and r['winner'] is not None:
            raise AssertionError('failed proof has winner')
        table[q,r['policy']].append(r)
        checks += 8
    if len(keys)!=1776 or len(table)!=592 or any(len(v)!=3 for v in table.values()):
        raise AssertionError('run matrix incomplete')
    for curve in a['curves']+a['feature_adjusted_curves']:
        budget=curve['budget_ms']/1000
        scores={}
        for q in refs:
            for policy in p['policies']:
                good=[]
                losses=[]
                for r in table[q,policy]:
                    t=r['compute_seconds']+(refs[q]['feature_seconds'][r['repeat']] if curve['feature_cost_added'] else 0)
                    done=r['status']=='stable' or (curve['objective']=='complete_classification' and r['status']=='nonuniform')
                    hit=done and t<=budget
                    good.append(int(hit))
                    losses.append(t if hit else budget)
                scores[q,policy]=sum(good),math.fsum(losses)
        fixed_success=max(sum(scores[q,m][0] for q in refs) for m in p['policies'])
        query_success=sum(max(scores[q,m][0] for m in p['policies']) for q in refs)
        fixed_loss=min(math.fsum(scores[q,m][1] for q in refs) for m in p['policies'])/444*1000
        query_loss=math.fsum(min(scores[q,m][1] for m in p['policies']) for q in refs)/444*1000
        if (fixed_success,query_success)!=(curve['fixed_successes'],curve['oracle_successes']):
            raise AssertionError('coverage aggregate mismatch')
        if not math.isclose(fixed_loss,curve['fixed_capped_loss_ms'],abs_tol=1e-9):
            raise AssertionError('fixed capped cost mismatch')
        if not math.isclose(query_loss,curve['oracle_capped_loss_ms'],abs_tol=1e-9):
            raise AssertionError('oracle capped cost mismatch')
        for choice in curve['oracle_choices']:
            q=choice['graph'],choice['rank']
            if scores[q,choice['policy']][0]!=max(scores[q,m][0] for m in p['policies']):
                raise AssertionError('oracle chose wrong query-level policy')
            checks+=1
        checks+=3
    for name,values in a['measured_costs'].items():
        elapsed=math.fsum(r['compute_seconds'] for r in s['rows'] if r['policy']==name)
        if not math.isclose(elapsed,values['actual_total_seconds'],abs_tol=1e-9):
            raise AssertionError('actual cost differs from penalty accounting')
        checks+=1
    save(BASE/'validation.json',{'status':'PASS','checks':checks,'runs':len(keys),'queries':len(refs),
        'protocol_sha256':sha(BASE/'protocol.json'),'summary_sha256':sha(BASE/'summary.json'),
        'analysis_sha256':sha(BASE/'analysis.json'),'validator_sha256':sha(Path(__file__)),
        'scope':'frozen identities+NPZ CRC, exact full run matrix, per-run artifact equality, late discard, truth consistency, independent query-level oracle and capped-loss recomputation; no extra solver runs',
        'limitations':'shares the frozen exact reference and numerical kernels; not a second independent exact arithmetic implementation'})
    print(f'Independent validation PASS {checks} checks')


if __name__=='__main__':
    main()
