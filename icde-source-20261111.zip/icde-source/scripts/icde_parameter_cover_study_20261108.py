"""Frozen small-scope feasibility study of complete parameter covers.

Development data only; no new confirmation, training or large experiment.
Exact Boolean compilation is paid and shared by every compared solver.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import time
import zipfile

import numpy as np

import icde_prospective_20261107 as old
from icde_gate_exact_review import tensor_vertex_transform
from icde_parameter_cover_20261108 import BinaryLookup, Cell, execute, partition
from run_vldb_interval_gate_v1 import clipped_box


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "nodes/09_vldb_query_certification/results/icde_parameter_cover_20261108/attempt1"
G1 = ROOT / "nodes/09_vldb_query_certification/results/icde_refinable_g1_20261107/attempt1"
POLICIES = ("unsplit", "fixed_2", "fixed_4", "adaptive")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def freeze(out):
    if out.exists():
        raise FileExistsError(out)
    prior = old.load(G1 / "summary.json")
    cases = [("dw", 113, "known_quantifier_omission"), ("dw", 244, "known_quantifier_omission")]
    for graph in ("dw", "enfr"):
        eligible = [r for r in prior["mechanisms"] if r["graph"] == graph and r["tau"] == .25
                    and r["candidates"] == 2 and not r["exact_uniform_winners"]]
        if eligible:
            control = min(eligible, key=lambda r: r["rank"])
            cases.append((graph, control["rank"], "known_nonuniform_control"))
    inputs = [G1 / "summary.json", G1 / "protocol.json"]
    selected = []
    for graph, rank, role in cases:
        meta = old.BASE / "prepared" / graph / f"q{rank:03d}.json"
        info = old.load(meta)
        selected.append({"graph": graph, "rank": rank, "role": role,
                         "scope_edges": info["scope_edges"], "query_id": info["query_id"]})
        inputs.extend([meta, meta.with_suffix(".npz"), old.BASE / "new_exact_reference" / f"{graph}_q{rank:03d}_t0.25.json"])
    code = old.load(G1 / "protocol.json")["code_sha256"]
    for name in ("icde_parameter_cover_20261108.py", "icde_parameter_cover_study_20261108.py",
                 "test_icde_parameter_cover_20261108.py"):
        code[f"scripts/{name}"] = sha(ROOT / "scripts" / name)
    save(out / "protocol.json", {"kind": "targeted_development_repair_not_confirmation", "cases": selected,
        "selection": "two known failed-gap queries plus first known nonuniform binary query per graph from G1",
        "tau": .25, "seeds": [601, 613], "looks": [64, 128, 256, 512, 1024, 2048, 4096, 8192],
        "policies": list(POLICIES), "population_depths": list(range(7)), "delta_exact": "1/20",
        "max_leaves": 32, "max_depth": 12, "splits_per_look": 4,
        "risk_contract": "all cells certify the SAME candidate; threshold K/delta with no multiplicative cell-count penalty; fixed original family fully covered",
        "compiler": "enumerate complete 2^m frozen float64 winner map, prove essential-coordinate projection, build exact ternary-state lookup; costs reported and shared by all solvers",
        "timing": "common compilation plus per-policy prefix computation; excludes original corpus preparation, RNG array generation and persistence; single-process exploratory",
        "standard_control": "fixed covers use the SAME exact masks, projection, uniform-mixture test, global threshold and per-look checking as adaptive",
        "exact_control": "classical multilinear parameter-vertex transformation on the SAME paid compiled map",
        "code_sha256": code, "input_sha256": {p.relative_to(ROOT).as_posix(): sha(p) for p in inputs},
        "frozen_at_unix": time.time()})
    print(json.dumps({"frozen_queries": selected}, ensure_ascii=False), flush=True)


def identities(protocol):
    checks = 0
    for group in ("code_sha256", "input_sha256"):
        for name, digest in protocol[group].items():
            if sha(ROOT / name) != digest:
                raise AssertionError(f"changed identity: {name}")
            checks += 1
    return checks


def preflight(out):
    protocol = old.load(out / "protocol.json")
    checks = identities(protocol)
    for name in protocol["input_sha256"]:
        if name.endswith(".npz"):
            with zipfile.ZipFile(ROOT / name) as archive:
                if archive.testzip() is not None:
                    raise AssertionError("prepared object CRC failure")
            checks += 1
    if (out / "summary.json").exists() or list(out.glob("*.pending")):
        raise ValueError("completed/partial outputs need a new explicit attempt")
    save(out / "recovery.json", {"status": "PASS", "checks": checks,
        "scope": "all identities and prepared CRCs consumed by this finite study; not a whole-workspace scan"})
    print(f"Recovery PASS {checks}", flush=True)


def audit_cover(root, cells, splits, fixed_depth=None):
    if fixed_depth is not None:
        expected = partition(root, fixed_depth)
    else:
        leaves = {"": root}
        for event in splits:
            parent = leaves.pop(event["parent"])
            left, right, e = parent.split()
            if e != event["coordinate"] or left.high[e] != event["middle"]:
                raise AssertionError("split replay mismatch")
            leaves[left.path], leaves[right.path] = left, right
        expected = list(leaves.values())
    actual = {c["path"]: (tuple(c["low"]), tuple(c["high"])) for c in cells}
    if actual != {c.path: (c.low, c.high) for c in expected}:
        raise AssertionError("the final leaves do not form the declared complete cover")
    return True


def run(out):
    protocol = old.load(out / "protocol.json")
    identities(protocol)
    if old.load(out / "recovery.json")["status"] != "PASS":
        raise AssertionError("recovery audit required")
    compiler, population, exact_rows, rows = [], [], [], []
    checks = 0
    for case_index, case in enumerate(protocol["cases"]):
        kernel, meta = old.read_query(case["graph"], case["rank"])
        m = len(kernel.edge_indices)
        started = time.perf_counter()
        all_states = ((np.arange(1 << m)[:, None] >> np.arange(m)) & 1).astype(np.bool_)
        winners = np.argmax(kernel.scores(all_states), axis=1).tolist()
        lookup = BinaryLookup(winners, m)
        compile_seconds = time.perf_counter() - started
        low, high = clipped_box(np.full(m, .9), protocol["tau"])
        root = lookup.project_cell(low, high)
        reference = old.load(old.BASE / "new_exact_reference" / f"{case['graph']}_q{case['rank']:03d}_t0.25.json")
        compiler.append({**case, "compile_seconds": compile_seconds, "full_world_scores": 1 << m,
                         "active_coordinates": list(lookup.active), "projected_dimension": lookup.r,
                         "ternary_lookup_entries": len(lookup.table)})
        for depth in protocol["population_depths"]:
            started = time.perf_counter()
            cells = partition(root, depth)
            gaps = [lookup.population(cell) for cell in cells]
            global_gaps = [min(g[w] for g in gaps) for w in (0, 1)]
            certified = [w for w in (0, 1) if global_gaps[w] > 0]
            if any(w not in reference["uniform_winners"] for w in certified):
                raise AssertionError("population lower bound certifies an unsafe candidate")
            population.append({**case, "depth": depth, "leaves": len(cells),
                "global_abstract_gaps_exact": list(map(str, global_gaps)),
                "global_abstract_gaps": list(map(float, global_gaps)), "population_winners": certified,
                "analysis_seconds": time.perf_counter() - started})
            checks += 1
        # Strong classical exact baseline on the same paid Boolean map.
        started = time.perf_counter()
        vertex = [tensor_vertex_transform([int(y == w) for y in lookup.winners], root.low, root.high)
                  for w in (0, 1)]
        exact_gap = [min(a-b for a, b in zip(vertex[w], vertex[1-w])) for w in (0, 1)]
        exact_winners = [w for w, gap in enumerate(exact_gap) if gap > 0]
        exact_seconds = time.perf_counter() - started
        if exact_winners != reference["uniform_winners"]:
            raise AssertionError("projected exact baseline differs from frozen full-scope reference")
        for w in (0, 1):
            oldgap = min(Q(p["minimum_gap"]) for p in reference["candidate_results"][w]["pair_gap_ranges"])
            if exact_gap[w] != oldgap:
                raise AssertionError("projected exact minimum gap mismatch")
        checks += 3
        exact_rows.append({**case, "winners": exact_winners, "minimum_gaps_exact": list(map(str, exact_gap)),
                           "vertex_count": 1 << lookup.r, "exact_solve_seconds": exact_seconds,
                           "compile_plus_solve_seconds": compile_seconds + exact_seconds})
        for seed_index, seed in enumerate(protocol["seeds"]):
            uniforms = np.random.default_rng(seed + case_index * 1009).random((max(protocol["looks"]), lookup.r))
            shift = (case_index + seed_index) % len(POLICIES)
            for policy in POLICIES[shift:] + POLICIES[:shift]:
                result = execute(lookup, root, uniforms, policy, protocol)
                if result["winner"] is not None and result["winner"] not in reference["uniform_winners"]:
                    raise AssertionError("finite-sample cover output fails exact reference")
                fixed_depth = int(policy.split("_")[-1]) if policy.startswith("fixed_") else None
                audit_cover(root, result["final_cells"], result["splits"], fixed_depth)
                if result["worlds"] not in protocol["looks"] or result["leaves"] > (16 if policy == "fixed_4" else protocol["max_leaves"]):
                    raise AssertionError("prefix or cover bound violated")
                result["compile_plus_compute_seconds"] = compile_seconds + result["compute_seconds"]
                result["prefix_sha256"] = hashlib.sha256(uniforms[:result["worlds"]].tobytes()).hexdigest()
                rows.append({**case, "seed": seed, **result})
                checks += 3
        print(f"completed {case['graph']} q{case['rank']:03d}: full m={m}, essential r={lookup.r}", flush=True)
    checks += identities(protocol)
    save(out / "summary.json", {"status": "PASS", "checks": checks, "protocol_sha256": sha(out / "protocol.json"),
        "compilation": compiler, "population": population, "exact_baseline": exact_rows, "runs": rows,
        "false_certifications_observed": 0, "historical_inputs_unchanged": True,
        "limitations": ["targeted known development cases only", "binary outputs and full small-scope enumeration",
            "standard fixed-cover controls receive all the same statistical and compiler optimizations",
            "not a new generic abstraction or hypothesis-testing invention", "exploratory timing, no large-scale speed claim"]})
    print(json.dumps({"status": "PASS", "runs": len(rows), "checks": checks}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("freeze", "preflight", "run"), required=True)
    parser.add_argument("--output", type=Path, default=BASE)
    args = parser.parse_args()
    {"freeze": freeze, "preflight": preflight, "run": run}[args.phase](args.output.resolve())
