"""Standard factorized probability relaxation + two-space branch refinement.

No joint endpoint-orbit tensor is allocated. All parameter boxes are retained;
interval relaxation is tightened by partitioning their finite integer domains.
These are standard sum-product bounds and branch-and-bound ingredients.
"""
from dataclasses import dataclass
import math
import time
from icde_partial_count_20261108 import CountOracle


@dataclass
class FactorRegion:
    low: tuple
    high: tuple
    mask: int
    vectors: list
    serial: int
    max_mass: int

    @property
    def volume(self):
        return math.prod(b-a+1 for a,b in zip(self.low,self.high))


def mass_bounds(region, plow, phigh):
    parts = [v[a:b+1] for v,a,b in zip(region.vectors,plow,phigh)]
    return (math.prod(min(map(int,v)) for v in parts),
            math.prod(max(map(int,v)) for v in parts))


def probability_bounds(regions, plow, phigh, k, denominator):
    lower, excluded, possible = [0]*k,[0]*k,[0]*k
    for region in regions:
        minimum,maximum = mass_bounds(region,plow,phigh)
        for c in range(k):
            if region.mask == 1 << c:
                lower[c] += minimum
            if region.mask & (1 << c):
                possible[c] += maximum
            else:
                excluded[c] += minimum
    upper = [min(possible[c],denominator-excluded[c]) for c in range(k)]
    if any(not 0 <= lo <= hi <= denominator for lo,hi in zip(lower,upper)):
        raise AssertionError("invalid factorized probability enclosure")
    return lower,upper


def execute(kernel,low,high,policy,settings):
    started = time.perf_counter()
    oracle = CountOracle(kernel,low,high,settings["state_cap"])
    a,b = (0,)*len(oracle.shape),tuple(n-1 for n in oracle.shape)
    mask = oracle.possible(a,b)
    if mask & (mask-1) == 0:
        return {"status":"stable","winner":mask.bit_length()-1,"kind":"common_root_bound",
            "compute_seconds":time.perf_counter()-started,"point_score_states":oracle.point_scores,
            "count_states":oracle.size,"count_splits":0,"parameter_splits":0,
            "leaf_records":[],"parameter_cells":[],"witnesses":[],"probability_states_allocated":0}
    oracle.prepare_probabilities()
    den = oracle.denominator
    regions = {}
    unknown = {}
    def add(lo,hi,mask,serial):
        vectors = oracle.region_vectors(lo,hi)
        maximum = math.prod(max(map(int,v)) for v in vectors)
        node = FactorRegion(lo,hi,mask,vectors,serial,maximum)
        regions[serial] = node
        if mask & (mask-1):
            unknown[serial] = node
    add(a,b,mask,0)
    params = [(a,b,0)]
    next_region,next_param = 1,1
    count_splits,parameter_splits = 0,0
    bad = {}
    trace = []
    bound_seconds = inference_seconds = 0.
    status,winner = "unresolved",None
    while True:
        before = time.perf_counter()
        bounds = [probability_bounds(regions.values(),pa,pb,oracle.k,den) for pa,pb,pid in params]
        leaders = []
        for w in range(oracle.k):
            if w in bad:
                continue
            worst = None
            for j,(lower,upper) in enumerate(bounds):
                for d in range(oracle.k):
                    if d==w:
                        continue
                    if upper[w]-lower[d] <= 0:
                        bad[w] = {"candidate":w,"competitor":d,
                            "high_endpoint_counts":list(params[j][0]),
                            "upper_gap_numerator":str(upper[w]-lower[d])}
                        break
                    value = lower[w]-upper[d]
                    if worst is None or value < worst[0]:
                        worst = value,d,j
                if w in bad:
                    break
            if w not in bad:
                leaders.append((worst[0],-w,worst[1],worst[2]))
        inference_seconds += time.perf_counter()-before
        if not leaders:
            status,winner = "nonuniform",None
            break
        gap,negw,d,pindex = max(leaders)
        w = -negw
        if gap > 0:
            status,winner = "stable",w
            break
        trace.append({"count_splits":count_splits,"parameter_splits":parameter_splits,
                      "candidate":w,"competitor":d,"worst_parameter_cell":params[pindex][2]})
        can_count = bool(unknown) and count_splits < settings["max_splits"]
        can_param = any(pa!=pb for pa,pb,pid in params) and parameter_splits < settings["max_parameter_splits"]
        if not can_count and not can_param:
            break
        do_count = can_count and (not can_param or (count_splits+parameter_splits)%4 != 3)
        before = time.perf_counter()
        if do_count:
            if policy == "factor_mass":
                parent = max(unknown.values(),key=lambda r:(r.max_mass,r.volume,-r.serial))
            else:
                pa,pb,pid = params[pindex]
                def priority(r):
                    lo = int(r.mask == 1 << w)-int(bool(r.mask & (1 << d)))
                    hi = int(bool(r.mask & (1 << w)))-int(r.mask == 1 << d)
                    maximum = mass_bounds(r,pa,pb)[1]
                    return maximum*(hi-lo),r.max_mass,r.volume,-r.serial
                parent = max(unknown.values(),key=priority)
            axis = max(range(len(a)),key=lambda g:(parent.high[g]-parent.low[g],-g))
            middle = (parent.high[axis]+parent.low[axis])//2
            left_hi,right_lo = list(parent.high),list(parent.low)
            left_hi[axis],right_lo[axis] = middle,middle+1
            left_hi,right_lo = tuple(left_hi),tuple(right_lo)
            lm = oracle.possible(parent.low,left_hi,parent.mask)
            rm = oracle.possible(right_lo,parent.high,parent.mask)
            unknown.pop(parent.serial)
            regions.pop(parent.serial)
            add(parent.low,left_hi,lm,next_region)
            add(right_lo,parent.high,rm,next_region+1)
            next_region += 2
            count_splits += 1
        else:
            available = [j for j,(pa,pb,pid) in enumerate(params) if pa!=pb]
            j = min(available,key=lambda j:(bounds[j][0][w]-bounds[j][1][d],params[j][2]))
            pa,pb,pid = params[j]
            axis = max(range(len(a)),key=lambda g:(pb[g]-pa[g],-g))
            middle = (pa[axis]+pb[axis])//2
            left_hi,right_lo = list(pb),list(pa)
            left_hi[axis],right_lo[axis] = middle,middle+1
            params[j:j+1] = [(pa,tuple(left_hi),next_param),(tuple(right_lo),pb,next_param+1)]
            next_param += 2
            parameter_splits += 1
        bound_seconds += time.perf_counter()-before
    return {"status":status,"winner":winner,"kind":"factorized_partial_regions",
        "compute_seconds":time.perf_counter()-started,"count_states":oracle.size,
        "point_score_states":oracle.point_scores,"count_splits":count_splits,
        "parameter_splits":parameter_splits,"bound_calls":oracle.bound_calls,
        "leaf_records":[{"low":list(r.low),"high":list(r.high),"mask":r.mask} for r in regions.values()],
        "parameter_cells":[{"low":list(pa),"high":list(pb)} for pa,pb,pid in params],
        "witnesses":[bad[w] for w in sorted(bad)],"denominator_exact":str(den),
        "trace":trace,"probability_states_allocated":0,
        "times":{"bounds_and_refinement":bound_seconds,"inference":inference_seconds},
        "marginal_table_entries":sum(cdf.size for cdf in oracle.cdfs)}
