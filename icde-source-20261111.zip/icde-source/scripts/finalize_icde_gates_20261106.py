"""Publish the locally reviewed gate revision to current workspace entrypoints."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT=Path(__file__).resolve().parents[1]
PAPER=ROOT/'papers/icde/regular2027'
RESULT='nodes/09_vldb_query_certification/results/'

def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    build=ROOT/'output/pdf/icde_gate_revision_20261106_attempt5'
    final=ROOT/'output/pdf/ICDE_ScopeRace_gate_revision_20261106.pdf'
    if final.exists() and sha(final)!=sha(build/'main.pdf'):raise FileExistsError(final)
    shutil.copyfile(build/'main.pdf',final)
    gates=[
      {'name':'scale_direct_controls_neural','path':RESULT+'icde_gate_integrated_audit_20261105_attempt1/validation.json'},
      {'name':'exact_review_independent','path':RESULT+'icde_exact_review_audit_20261106_attempt1/validation.json'},
      {'name':'hybrid_records','path':'papers/icde/regular2027/figures/gates_20261106_attempt2/hybrid_validation.json'}]
    for item in gates:
        if read(ROOT/item['path'])['status']!='PASS':raise RuntimeError('gate not passed')
    plan=read(ROOT/'configs/icde_research_plan_20261104.json')
    plan.update(status='icde_gate_experiments_and_independent_audits_complete_author_review',last_updated='2026-11-06',gate_evidence=gates)
    plan['content'].update(pdf=str(final.relative_to(ROOT)).replace('\\','/'),pdf_build_directory=str(build.relative_to(ROOT)).replace('\\','/'),pdf_pages_total=13,pdf_main_pages=12,figures=7,tables=3,references=31,writing_validation='papers/icde/regular2027/WRITING_VALIDATION_gate_20261106_attempt1.json',gate_completion_report='papers/icde/regular2027/GATE_COMPLETION_REPORT_20261106.md')
    plan['established_evidence'].update(stdlib_tests_passed=159,new_gate_tests_passed=55,scale_unique_queries=1000,scale_query_seed_cases_per_policy=3000,scale_all_policy_cases=9000,scale_scope_robust=2180,scale_eager_robust=2396,scale_lazy_robust=2401,scale500_status='completed_eight_durable_shards_independently_audited',direct_PPR='90/96 same nominal completion;32160 vs39712 worlds',neural_primary_maintenance_robust='43/64 at256 worlds',neural_diagnostic_maintenance_robust='55/64 at512 worlds',neural_full_family_robust=0,exact_review_queries=32,exact_families=192,exact_policy_cases=1728,exact_observed_robust_false_clears=0,universal_cold_walltime_speedup=False)
    plan['readiness'].update(submission_ready=False,empirical_execution_gates_pass_in_declared_scope=True,author_review_ready=True,own_ICDM_formal_fulltext_review_complete=False,public_thesis_chapter5_review_complete=True,real_deployment_need_established=False,real_fact_calibration_established=False)
    for item in plan['work_packages']:
        item['status']={'I0':'complete_gate_revision_12_main_pages','I1':'public_thesis_full_chapter_compared_formal_paper_text_pending','I2':'complete_online_timing_and_direct_controls','I3':'complete500_load_restricted_family_RREA_and_independent_exact_review','I4':'empirical_gates_pass_author_originality_and_scope_review_pending','I5':'complete_layout_pending_author_metadata_and_external_artifact'}.get(item['id'],item['status'])
    plan['execution_policy']['completed_gate_protocols']=['configs/icde_gate_completion_20261104.json','configs/icde_gate_controls_20261105.json','configs/icde_gate_hybrid_20261105.json',RESULT+'icde_gate_rrea_20261105_attempt1/protocol_before_draws.json',RESULT+'icde_exact_review_20261105_attempt1/protocol_freeze.json']
    write(ROOT/'configs/icde_research_plan_20261104.json',plan)
    ledger=read(PAPER/'EVIDENCE_LEDGER_20261104.json')
    for item in ledger['sources']:
        if sha(ROOT/item['path'])!=item['sha256']:raise RuntimeError('earlier evidence changed:'+item['path'])
    paths=[x['path'] for x in gates]+[
      RESULT+'icde_gate_integrated_audit_20261105_attempt1/summary.json',
      RESULT+'icde_gate_controls_20261105_attempt1/summary.json',
      RESULT+'icde_gate_hybrid_20261105_attempt1/summary.json',
      RESULT+'icde_gate_rrea_20261105_attempt1/summary.json',
      RESULT+'icde_gate_rrea_20261105_attempt1/protocol_before_draws.json',
      RESULT+'icde_exact_review_20261105_attempt1/summary.json',
      RESULT+'icde_exact_review_20261105_attempt1/protocol_freeze.json',
      RESULT+'icde_exact_review_audit_20261106_attempt1/summary.json',
      'papers/icde/regular2027/figures/gates_20261106_attempt2/figure_provenance.json']
    for name in paths:
        if name not in {x['path'] for x in ledger['sources']}:ledger['sources'].append({'path':name,'sha256':sha(ROOT/name)})
    ledger['claims'].append({'id':'gate-completion-20261106','scale_unique_queries':1000,'query_seed_cases_per_policy':3000,'scope_eager_lazy_robust':[2180,2396,2401],'nominal_PPR_normal_worlds':[32160,39712],'neural_B_normal_robust_at256_and512':[43,55],'neural_A_robust':0,'exact_independent_reference_families':192,'exact_policy_cases':1728,'exact_observed_robust_false_clears':0,'all_methods_compared_with_their_own_query_run_risk':True})
    ledger['pending_submission_evidence']=['formal ICDM six-page full-text overlap check (public thesis chapter5 is read and compared)','author evaluation of complete ScopeRace novelty against direct predecessors','verified author names affiliations ORCIDs and actual concurrent-review status','externally accessible reproducibility package and final author review']
    ledger['closed_empirical_gates_in_current_scope']=['published PPR and variance-adaptive control','complete500query load (not graph-size scaling law)','nonempty restricted-family full-graph neural certification','independently exact controlled family-review decisions']
    write(PAPER/'EVIDENCE_LEDGER_20261104.json',ledger)
    report='[说明文本已清理]'
    (PAPER/'GATE_COMPLETION_REPORT_20261106.md').write_text(report,encoding='utf-8')
    review='[说明文本已清理]'
    (PAPER/'BUILD_REVIEW_20261104.md').write_text(review,encoding='utf-8')
    readme='[说明文本已清理]'
    (PAPER/'README.md').write_text(readme,encoding='utf-8')
    for name in ('CONTRIBUTION_CONTRACT_20261104.md','EXPERIMENT_PLAN_20261104.md'):
        p=PAPER/name;t=p.read_text('utf-8')
        note='\n更新2026-11-06：本文件保留初始合同与执行顺序；当前已完成的门槛、证据和剩余项以[门槛补充记录](GATE_COMPLETION_REPORT_20261106.md)为准。\n'
        p.write_text(t.split('\n',1)[0]+'\n'+note+t.split('\n',1)[1],encoding='utf-8')
    for p in PAPER.glob('*.md'):
        t=p.read_text('utf-8-sig')
        t=re.sub(r'\]\(/([A-Za-z]:/)',r'](\1',t)
        p.write_text(t,encoding='utf-8')
    status=ROOT/'nodes/09_vldb_query_certification/status.toml'
    t=status.read_text('utf-8').replace('tests_passed = 104','tests_passed = 159')
    t=re.sub(r'^substatus = .*$', 'substatus = "icde_gate_evidence_complete_author_review"',t,flags=re.M)
    t=re.sub(r'^next_action = .*$', 'next_action = "作者核对完整ScopeRace贡献和正式ICDM边界，补齐作者/ORCID与对外复现材料。"',t,flags=re.M)
    t=re.sub(r'^findings = .*$', 'findings = "../../papers/icde/regular2027/GATE_COMPLETION_REPORT_20261106.md"',t,flags=re.M)
    status.write_text(t,encoding='utf-8')
    print(json.dumps({'paper_main_pages':12,'total_pages':13,'gate_audits':'PASS','author_review_ready':True,'formal_submission_ready':False,'pdf_sha256':sha(final)}))

if __name__=='__main__':main()
