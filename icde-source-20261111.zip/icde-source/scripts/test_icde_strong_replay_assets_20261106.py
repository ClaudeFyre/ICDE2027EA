"""Synthetic adapter-integrity tests; no model, RNG stream, or experiment run."""
import hashlib
import json
from pathlib import Path
import struct
import tempfile
import unittest

import icde_strong_replay_assets_20261106 as assets


def _write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True), encoding="utf-8")


def _winner_hash(winners):
    return hashlib.sha256(b"".join(struct.pack("<q", value) for value in winners)).hexdigest()


def _protocol():
    return {"config": {"sample_count": 8, "event_checkpoints": [2, 4, 8],
            "beta_total": .025}, "seed": 151,
            "risk": "per policy/query/family", "sample_cap": 8}


def _setup(candidate_ids=None, scope=None):
    candidate_ids = ["a", "b"] if candidate_ids is None else candidate_ids
    scope = [10, 11] if scope is None else scope
    return {"graph": "G", "dataset_revision": "revision", "input_sha256": {"facts": "input-hash"},
        "query_setup": [{"query_id": "source", "candidate_ids": candidate_ids,
            "candidate_tie_order": "lexicographic_unicode_first", "scope_edge_indices": scope,
            "scope_certificate": {"certificate_sha256": "scope-hash"},
            "cost_model": {"original_incidence_entries": 2},
            "box_audit": {"q_sha256": hashlib.sha256(struct.pack("<dd", .5, .5)).hexdigest(),
                          "low_sha256": "low-hash", "high_sha256": "high-hash"}}]}


def _row(policy, winners, *, tau=.001, event=False, seed=97):
    n = len(winners)
    trace = []
    cumulative = 0
    for look in (value for value in (2, 4, 8) if value <= n):
        fee = 6 if event else 0
        cumulative += fee
        trace.append({"nominal_samples": look, "event_samples": look if event else 0,
            "event_upper": .9 if look == 2 else .8,
            "event_admission": "approved" if event else "not_requested",
            "static_event_fee": fee, "actual_event_fee": fee,
            "work_used": 10 + 10 * look + cumulative,
            "winner_prefix_sha256": _winner_hash(winners[:look]),
            "uniform_prefix_sha256": hashlib.sha256(f"uniform-{look}".encode()).hexdigest()})
    return {"graph": "G", "query_id": "source", "dataset_revision": "revision",
        "policy": policy, "method": policy, "objective": "robust", "inference_rule": "normal",
        "seed": seed, "seed_purpose": "paired-purpose", "rng_seed_hex": "0x123",
        "tau": tau, "candidate_count": 2, "scope_edge_count": 2,
        "winner_indices": list(winners), "winner_counts": [winners.count(0), winners.count(1)],
        "samples_used": n, "winner_prefix_sha256": _winner_hash(winners), "trace": trace,
        "event_samples_used": n if event else 0, "event_count": 1 if event else 0,
        "event_beta_total": .025 if event else 0., "nominal_delta": .025 if event else .05,
        "actual_nominal_checkpoints": [2, 4, 8], "certified": False, "robust_certified": False,
        "nominal_certified": True, "certified_candidate_index": None, "status": "world_cap",
        "scope_epsilon_upper": .1, "work_used": 10 + 10 * n + cumulative, "work_budget": 1000,
        "seconds": {"serving_total": .1}, "work_semantics": "modeled_variable_work"}


def _control_archive(directory, row, setup=None):
    _write(directory / "protocol_freeze.json", _protocol())
    _write(directory / "setup_g.json", _setup() if setup is None else setup)
    _write(directory / "cases" / (row["policy"] + ".json"), row)


class ControlAssetTests(unittest.TestCase):
    def test_longest_compatible_prefix_keeps_policy_specific_paid_evidence(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _control_archive(root / "controls", _row("normal_scope", [0, 1]))
            _control_archive(root / "hybrid", _row("normal_hybrid", [0, 1, 0, 0], event=True))
            group, = assets.iter_control_groups(root, "controls", "hybrid")
            self.assertEqual(group["winner_indices"], [0, 1, 0, 0])
            self.assertEqual(group["available_checks"], [2, 4])
            self.assertTrue(group["censored"])
            self.assertFalse(group["protected_event_by_n"]["controls:normal_scope"])
            paid = group["protected_event_by_n"]["hybrid:normal_hybrid"]
            self.assertIsNone(paid[2]["event_count"])
            self.assertEqual(paid[4]["event_count"], 1)
            self.assertEqual(paid[4]["cumulative_actual_event_fee"], 12)
            self.assertTrue(paid[4]["requires_charging_original_event_work"])
            self.assertFalse(paid[4]["cross_policy_minimum_protected"])

    def test_conflicting_common_winner_prefix_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _control_archive(root / "controls", _row("normal_scope", [0, 1]))
            _control_archive(root / "hybrid", _row("normal_hybrid", [1, 0, 0, 0], event=True))
            with self.assertRaisesRegex(ValueError, "common prefix"):
                list(assets.iter_control_groups(root, "controls", "hybrid"))

    def test_candidate_order_difference_is_rejected_even_when_indices_match(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _control_archive(root / "controls", _row("normal_scope", [0, 1]))
            _control_archive(root / "hybrid", _row("normal_hybrid", [0, 1]), _setup(["b", "a"]))
            with self.assertRaisesRegex(ValueError, "identities"):
                list(assets.iter_control_groups(root, "controls", "hybrid"))

    def test_same_size_different_scope_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _control_archive(root / "controls", _row("normal_scope", [0, 1]))
            _control_archive(root / "hybrid", _row("normal_hybrid", [0, 1]), _setup(scope=[10, 12]))
            with self.assertRaisesRegex(ValueError, "identities"):
                list(assets.iter_control_groups(root, "controls", "hybrid"))

    def test_unpaid_event_prefix_growth_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            row = _row("normal_event", [0, 1], event=True)
            row["trace"][0]["event_admission"] = "rejected_budget"
            _control_archive(root / "controls", row)
            with self.assertRaisesRegex(ValueError, "unpaid"):
                list(assets.iter_control_groups(root, "controls", "missing"))

    def test_corrupt_winner_hash_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            row = _row("normal_scope", [0, 1])
            row["winner_prefix_sha256"] = "incorrect"
            _control_archive(root / "controls", row)
            with self.assertRaisesRegex(ValueError, "winner-prefix hash"):
                list(assets.iter_control_groups(root, "controls", "missing"))

    def test_manifest_detects_source_mutation_after_read(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _control_archive(root / "controls", _row("normal_scope", [0, 1]))
            groups = list(assets.iter_control_groups(root, "controls", "missing"))
            manifest = assets.build_replay_manifest(groups, root)
            self.assertTrue(manifest["source_artifacts_verified"])
            self.assertEqual(manifest["new_model_calls"], 0)
            with (root / "controls/cases/normal_scope.json").open("a", encoding="utf-8") as handle:
                handle.write(" ")
            with self.assertRaisesRegex(ValueError, "changed after normalization"):
                assets.build_replay_manifest(groups, root)


def _exact_archive(directory):
    _write(directory / "protocol_freeze.json", _protocol())
    _write(directory / "setup_g.json", _setup())
    _write(directory / "winner_maps/map.json", {"graph": "G", "query_id": "source",
        "candidate_ids": ["a", "b"], "scope_edge_indices": [10, 11], "m": 2,
        "all_worlds": 4, "world_index_to_winner": [0, 0, 1, 1], "q_exact": ["1/2", "1/2"]})
    for index, tau in enumerate((.25, 1.)):
        reference = {"graph": "G", "query_id": "source", "tau": tau,
            "candidate_ids": ["a", "b"], "q_exact": ["1/2", "1/2"],
            "low_exact": ["1/4", "1/4"] if tau == .25 else ["0", "0"],
            "high_exact": ["3/4", "3/4"] if tau == .25 else ["1", "1"],
            "uniform_winners": [], "nominal_modes": [0, 1]}
        reference_path = directory / f"exact/reference{index}.json"
        _write(reference_path, reference)
        reference_sha = hashlib.sha256(reference_path.read_bytes()).hexdigest()
        for policy, winners in (("normal_scope", [0, 1]), ("normal_event", [0, 1, 0, 0])):
            row = _row(policy, winners, tau=tau, event=policy == "normal_event", seed=151)
            payload = {"graph": "G", "query_id": "source", "tau": tau, "policy": policy,
                "exact_reference_path": f"exact/reference{index}.json",
                "exact_reference_sha256": reference_sha, "approved": False,
                "uniform_safe": False, "false_clear": False, "row": row}
            _write(directory / f"cases/t{index}_{policy}.json", payload)
        _write(directory / f"cases/t{index}_point.json", {"graph": "G", "query_id": "source",
            "tau": tau, "policy": "point_all_present", "approved": True,
            "false_clear": True, "exact_reference_path": f"exact/reference{index}.json",
            "exact_reference_sha256": reference_sha})


class ExactAssetTests(unittest.TestCase):
    def test_widths_stay_separate_and_point_controls_are_not_mc_streams(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _exact_archive(root / "exact_gate")
            groups = list(assets.iter_exact_groups(root, "exact_gate"))
            self.assertEqual([group["tau"] for group in groups], [.25, 1.])
            self.assertNotEqual(groups[0]["family_identity_sha256"], groups[1]["family_identity_sha256"])
            for group in groups:
                self.assertEqual(group["winner_indices"], [0, 1, 0, 0])
                self.assertEqual(len(group["policies"]), 2)
                self.assertEqual(len(group["deterministic_controls"]), 1)
                self.assertEqual(group["winner_map"]["all_worlds"], 4)
                self.assertTrue(group["replay_only"])

    def test_changed_reference_is_rejected_before_replay(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _exact_archive(root / "exact_gate")
            path = root / "exact_gate/exact/reference0.json"
            value = json.loads(path.read_text(encoding="utf-8"))
            value["uniform_winners"] = [0]
            _write(path, value)
            with self.assertRaisesRegex(ValueError, "reference hash"):
                list(assets.iter_exact_groups(root, "exact_gate"))

    def test_winner_map_candidate_order_cannot_change(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _exact_archive(root / "exact_gate")
            path = root / "exact_gate/winner_maps/map.json"
            value = json.loads(path.read_text(encoding="utf-8"))
            value["candidate_ids"] = ["b", "a"]
            _write(path, value)
            with self.assertRaisesRegex(ValueError, "winner-map/setup"):
                list(assets.iter_exact_groups(root, "exact_gate"))

    def test_winner_map_nominal_probabilities_must_match_setup_hash(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            _exact_archive(root / "exact_gate")
            path = root / "exact_gate/winner_maps/map.json"
            value = json.loads(path.read_text(encoding="utf-8"))
            value["q_exact"] = ["1/4", "1/2"]
            _write(path, value)
            with self.assertRaisesRegex(ValueError, "nominal law mismatch"):
                list(assets.iter_exact_groups(root, "exact_gate"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
