"""Finite pricing-maintenance pilot with frozen inputs and full references.

The block methods receive vectors and summaries only. Dense score matrices are
used by the independent oracle and the explicitly named dense baselines.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import time
import zipfile

import numpy as np
import scipy
from scipy.optimize import linear_sum_assignment, linprog
from scipy.sparse import coo_matrix

from www_quality_recovery_v13_common import normalized, sha


ROOT = Path(__file__).resolve().parents[1]
TRAIN = ROOT / "nodes/04_www_distributional/results/quality_recovery_v13/windows_attempt1"
OUT = ROOT / "nodes/10_icde_incremental_matching/results/pilot_20261109/attempt1"
RULES = ROOT / "papers/icde/INCREMENTAL_MATCHING_PROTOCOL_20261109.md"
TAU = 0.4
TOL = 1e-9
CHECK_TOL = 1e-8
CONFIGS = [(family, size) for family in ("cap", "split") for size in (16, 64, 256)]


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def freeze():
    if OUT.exists():
        raise FileExistsError(OUT)
    seal_path = TRAIN / "validation_seal.json"
    seal = load(seal_path)
    inputs = {seal_path.relative_to(ROOT).as_posix(): sha(seal_path)}
    for graph in ("dw", "enfr"):
        for name in ("inputs.npz", "mask_restore.npz", "training_complete.json", "mask_restore.json"):
            path = TRAIN / "training" / (graph + "_s17") / name
            actual = sha(path)
            if actual != seal["cells"][graph + "_s17"][name]:
                raise AssertionError("sealed input differs " + str(path))
            inputs[path.relative_to(ROOT).as_posix()] = actual
    code = [Path(__file__), ROOT / "scripts/www_quality_recovery_v13_common.py",
            ROOT / "scripts/safe_run.py", ROOT / "configs/resource_profiles.json"]
    save(OUT / "protocol.json", {
        "kind": "new_incremental_matching_pricing_pilot",
        "authorization": "user requested continuous execution to stopping conditions",
        "rules_sha256": sha(RULES), "input_sha256": inputs,
        "code_sha256": {p.relative_to(ROOT).as_posix(): sha(p) for p in code},
        "graphs": ["dw", "enfr"], "source_sizes": [256, 1024],
        "configurations": CONFIGS, "tau": TAU, "violation_tolerance": TOL,
        "check_tolerance": CHECK_TOL, "bound_guard": 1e-11,
        "repeats": 3, "setup_amortization_R": 8,
        "source_salt": "icde-incmatch-20261109-v1",
        "fixtures": ["unchanged", "source_mix_1pct", "target_mix_1pct", "historical_edge_deletion"],
        "selection": "fixed configuration must pass both graphs; minimum total cost, cap then smaller block on ties",
        "gate": {"pair_saving_each_graph": .2, "cost_saving_each_graph": .2,
                 "paired_descriptive_95pct_lower_strictly_positive": True},
        "reference_limits": {"column_generation_rounds": 64, "LP_seconds_per_call": 120},
        "numpy": np.__version__, "scipy": scipy.__version__,
        "created_unix": time.time(), "no_label_access": True,
    })
    print("FROZEN", flush=True)


def identities():
    p = load(OUT / "protocol.json")
    if sha(RULES) != p["rules_sha256"]:
        raise AssertionError("scientific rules changed")
    checks = 1
    for category in ("input_sha256", "code_sha256"):
        for name, expected in p[category].items():
            if sha(ROOT / name) != expected:
                raise AssertionError("frozen identity changed " + name)
            checks += 1
    return checks


def recover():
    checks = identities()
    crc = []
    for name in load(OUT / "protocol.json")["input_sha256"]:
        if name.endswith(".npz"):
            with zipfile.ZipFile(ROOT / name) as archive:
                if archive.testzip() is not None:
                    raise AssertionError("NPZ CRC failed " + name)
            crc.append(name)
    save(OUT / "recovery.json", {"status": "PASS", "identity_checks": checks,
        "crc_checked": crc, "scope": "all consumed inputs and code; no unrelated historical repairs"})
    print("RECOVERY PASS", flush=True)


def dense_price(scores, a, b):
    values = scores - b[None, :]
    targets = np.argmax(values, axis=1)
    violation = values[np.arange(len(a)), targets] - a
    positive = violation > TOL
    return np.where(positive, violation, 0.0), np.where(positive, targets, -1)


def reference(scores):
    n, m = scores.shape
    edges = set()
    top = np.argpartition(scores, -min(16, m), axis=1)[:, -min(16, m):]
    edges.update((i, int(j)) for i in range(n) for j in top[i] if scores[i, j] > 0)
    if not edges:
        return np.zeros(n), np.zeros(m), np.full(n, -1, dtype=int), {"rounds": 0, "edges": 0, "objective": 0.0}
    for iteration in range(64):
        ordered = sorted(edges)
        row = np.array([e[0] for e in ordered])
        col = np.array([e[1] for e in ordered])
        edge_ids = np.arange(len(ordered))
        matrix = coo_matrix((np.ones(2 * len(row)),
            (np.r_[row, n + col], np.r_[edge_ids, edge_ids])), shape=(n + m, len(row))).tocsr()
        result = linprog(-scores[row, col], A_ub=matrix, b_ub=np.ones(n + m),
            bounds=(0, None), method="highs-ds", options={
                "primal_feasibility_tolerance": 1e-9,
                "dual_feasibility_tolerance": 1e-9, "time_limit": 120})
        if not result.success:
            raise RuntimeError("reference LP failed " + result.message)
        a = -result.ineqlin.marginals[:n]
        b = -result.ineqlin.marginals[n:]
        violation, target = dense_price(scores, a, b)
        if not np.any(violation > TOL):
            assigned = np.full(n, -1, dtype=int)
            selected = result.x > .5
            assigned[row[selected]] = col[selected]
            if np.max(np.minimum(abs(result.x), abs(result.x - 1))) > CHECK_TOL:
                raise AssertionError("LP reference is not integral")
            objective = float(scores[row[selected], col[selected]].sum())
            if abs(objective - float(a.sum() + b.sum())) > CHECK_TOL:
                raise AssertionError("reference primal-dual gap")
            augmented = np.concatenate([scores, np.zeros((n, n))], axis=1)
            ri, ci = linear_sum_assignment(augmented, maximize=True)
            independent = float(augmented[ri, ci].sum())
            if abs(objective - independent) > CHECK_TOL:
                raise AssertionError("independent full assignment disagrees")
            return a, b, assigned, {"rounds": iteration + 1, "edges": len(edges),
                "objective": objective, "independent_objective": independent,
                "global_dual_max_violation": float(np.max(violation))}
        new = {(int(i), int(target[i])) for i in np.flatnonzero(violation > TOL)}
        if new <= edges:
            raise AssertionError("LP violates an existing edge")
        edges.update(new)
    raise RuntimeError("reference column generation round limit")


def partition(projected, capacity):
    groups = []
    pending = [np.arange(len(projected))]
    while pending:
        ids = pending.pop()
        if len(ids) <= capacity:
            groups.append(ids)
            continue
        axis = int(np.argmax(np.var(projected[ids], axis=0)))
        order = np.argsort(projected[ids, axis], kind="stable")
        middle = len(ids) // 2
        pending.extend([ids[order[middle:]], ids[order[:middle]]])
    return groups


class BlockIndex:
    def __init__(self, q, targets, basis, family, capacity):
        self.family = family
        self.basis = basis[:, :64 if family == "split" else 16]
        self.tp = targets @ self.basis
        self.qp = q @ self.basis
        self.groups = partition(self.tp[:, :16], capacity)
        self.order = np.concatenate(self.groups)
        self.starts = np.r_[0, np.cumsum([len(ids) for ids in self.groups])[:-1]]
        self.membership = np.empty(len(targets), dtype=int)
        for block, ids in enumerate(self.groups):
            self.membership[ids] = block
        count = len(self.groups)
        self.centers = np.empty((count, q.shape[1]))
        self.center_norm = np.empty(count)
        self.radius = np.empty(count)
        self.cos_radius = np.empty(count)
        self.radius_p = np.empty(count)
        self.radius_r = np.empty(count)
        for block in range(count):
            self.summarize(block, targets)
        self.qdot = q @ self.centers.T

    def clone(self):
        result = copy.copy(self)
        for name in ("tp", "qp", "centers", "center_norm", "radius", "cos_radius",
                     "radius_p", "radius_r", "qdot"):
            setattr(result, name, getattr(self, name).copy())
        return result

    def summarize(self, block, targets):
        ids = self.groups[block]
        values = targets[ids]
        center = values.mean(axis=0)
        norm = float(np.linalg.norm(center))
        deviation = values - center
        norm2 = np.einsum("ij,ij->i", deviation, deviation)
        self.centers[block] = center
        self.center_norm[block] = norm
        self.radius[block] = math.sqrt(float(norm2.max()))
        self.cos_radius[block] = float(np.min(values @ (center / norm))) if norm > 1e-14 else -1.0
        if self.family == "split":
            projected = self.tp[ids] - self.tp[ids].mean(axis=0)
            p2 = np.einsum("ij,ij->i", projected, projected)
            self.radius_p[block] = math.sqrt(float(p2.max()))
            self.radius_r[block] = math.sqrt(float(np.maximum(norm2 - p2, 0).max()))
        else:
            self.radius_p[block] = self.radius_r[block] = 0.0

    def update(self, q, targets, changed_q, changed_t):
        touched = np.unique(self.membership[changed_t])
        if len(changed_t):
            self.tp[changed_t] = targets[changed_t] @ self.basis
            for block in touched:
                self.summarize(int(block), targets)
            self.qdot[:, touched] = q @ self.centers[touched].T
        if len(changed_q):
            self.qp[changed_q] = q[changed_q] @ self.basis
            self.qdot[changed_q] = q[changed_q] @ self.centers.T
        return len(touched)

    def upper(self):
        norms = np.maximum(self.center_norm, 1e-300)
        dot = np.clip(self.qdot / norms[None, :], -1, 1)
        cosine = np.clip(self.cos_radius, -1, 1)[None, :]
        angular = np.where(dot >= cosine, 1.0,
            dot * cosine + np.sqrt(np.maximum(0, (1 - dot * dot) * (1 - cosine * cosine))))
        angular[:, self.center_norm <= 1e-14] = 1.0
        bound = np.minimum(angular, self.qdot + self.radius[None, :])
        if self.family == "split":
            qp_norm = np.sqrt(np.einsum("ij,ij->i", self.qp, self.qp))
            qr_norm = np.sqrt(np.maximum(0, 1 - qp_norm * qp_norm))
            split = (self.qdot + qp_norm[:, None] * self.radius_p[None, :]
                     + qr_norm[:, None] * self.radius_r[None, :])
            bound = np.minimum(bound, split)
        return bound + 1e-11

    def price(self, q, targets, a, b):
        minimum_b = np.minimum.reduceat(b[self.order], self.starts)
        possible = self.upper() - TAU - a[:, None] - minimum_b[None, :] > TOL
        best = np.zeros(len(q))
        winner = np.full(len(q), -1, dtype=int)
        evaluated = 0
        for block, ids in enumerate(self.groups):
            rows = np.flatnonzero(possible[:, block])
            if not len(rows):
                continue
            values = q[rows] @ targets[ids].T - TAU - b[ids][None, :] - a[rows, None]
            positions = np.argmax(values, axis=1)
            local = values[np.arange(len(rows)), positions]
            better = (local > TOL) & (local > best[rows])
            selected = rows[better]
            best[selected] = local[better]
            winner[selected] = ids[positions[better]]
            evaluated += len(rows) * len(ids)
        return best, winner, {"exact_pairs": evaluated,
            "possible_source_blocks": int(possible.sum()), "blocks": len(self.groups)}


def check_price(scores, a, b, observed):
    expected, _ = dense_price(scores, a, b)
    violation, target = observed[:2]
    if np.max(np.abs(expected - violation)) > CHECK_TOL:
        raise AssertionError("pricing missed maximum violation")
    positive = target >= 0
    if np.any(positive):
        actual = scores[np.flatnonzero(positive), target[positive]] - a[positive] - b[target[positive]]
        if np.max(np.abs(actual - violation[positive])) > CHECK_TOL:
            raise AssertionError("invalid returned pricing candidate")
    if np.any((expected > CHECK_TOL) & ~positive):
        raise AssertionError("false no-violation claim")
    return int(len(expected) + np.count_nonzero(positive))


def self_check():
    identities()
    rng = np.random.default_rng(2026110917)
    checks = 0
    for trial in range(16):
        q = normalized(rng.normal(size=(7, 80)))
        targets = normalized(rng.normal(size=(23, 80)))
        if trial % 4 == 0:
            targets[1] = targets[0]
            targets[3] = -targets[2]
        basis = np.eye(80)
        scores = q @ targets.T - TAU
        a, b, _, _ = reference(scores)
        for family in ("cap", "split"):
            index = BlockIndex(q, targets, basis, family, 4)
            upper = index.upper()
            for block, ids in enumerate(index.groups):
                if np.max(q @ targets[ids].T - upper[:, block, None]) > CHECK_TOL:
                    raise AssertionError("unsafe block upper bound")
                checks += len(q) * len(ids)
            changed_q = np.array([1, 4])
            changed_t = np.array([2, 10])
            qnew, tnew = q.copy(), targets.copy()
            qnew[changed_q] = normalized(qnew[changed_q] + .4)
            tnew[changed_t] = normalized(tnew[changed_t] - .2)
            index.update(qnew, tnew, changed_q, changed_t)
            checks += check_price(qnew @ tnew.T - TAU, a, b, index.price(qnew, tnew, a, b))
    chain = np.array([[100, 99, 0], [0, 100, 99], [100, 0, 0]], dtype=float)
    a, b, assigned, ref = reference(chain)
    if ref["objective"] != 298 or assigned.tolist() != [1, 2, 0]:
        raise AssertionError("nonlocal replacement chain")
    reference(np.full((3, 5), -1.0))
    save(OUT / "self_check.json", {"status": "PASS", "checks": checks + 2,
        "tiny_vector_cases": 16, "nonlocal_chain_objective": 298,
        "scope": "bounds, changed sources/targets, repeated vectors, empty match, exact assignment and LP"})
    print("SELF CHECK PASS", checks + 2, flush=True)


def ordered_ids(ids, graph, kind):
    salt = "icde-incmatch-20261109-v1|" + graph + "|" + kind + "|"
    return np.array(sorted(range(len(ids)), key=lambda i:
        hashlib.sha256((salt + str(ids[i])).encode()).digest()), dtype=int)


def graph_inputs(graph):
    directory = TRAIN / "training" / (graph + "_s17")
    with np.load(directory / "inputs.npz", allow_pickle=False) as value:
        hidden = value["hidden"]
        ids = value["entity_ids"]
        ti = value["target_indices"]
        basis = value["basis"]
    with np.load(directory / "mask_restore.npz", allow_pickle=False) as value:
        if not np.array_equal(ids, value["entity_ids"]):
            raise AssertionError("snapshot entity order changed")
        original = normalized(value["original"])
        perturbed = normalized(value["perturbed"])
    if hidden.shape != (30000, 600) or len(ti) != 15000:
        raise AssertionError("unexpected full model shape")
    if np.max(np.abs(hidden - original)) > 1e-6:
        raise AssertionError("historical nominal snapshots differ")
    if np.max(np.abs(basis.T @ basis - np.eye(600))) > 1e-8:
        raise AssertionError("basis is not orthogonal")
    si = np.setdiff1d(np.arange(len(ids)), ti)
    # The source ordering is salted only by graph and entity ID, as frozen.
    salt = "icde-incmatch-20261109-v1|" + graph + "|"
    order = sorted(si, key=lambda i: hashlib.sha256((salt + str(ids[i])).encode()).digest())
    return original, perturbed, np.array(order), ti, ids, basis


def fixtures(q, targets, perturbed_q, perturbed_t, graph, qids, tids):
    empty = np.array([], dtype=int)
    yield "unchanged", q, targets, empty, empty
    source_order = ordered_ids(qids, graph, "source_update")
    changed = source_order[:max(1, math.ceil(.01 * len(q)))]
    donor = source_order[(np.arange(len(changed)) + 1) % len(q)]
    qnew = q.copy()
    qnew[changed] = normalized(.85 * q[changed] + .15 * q[donor])
    yield "source_mix_1pct", qnew, targets, changed, empty
    target_order = ordered_ids(tids, graph, "target_update")
    changed = target_order[:max(1, math.ceil(.01 * len(targets)))]
    donor = target_order[(np.arange(len(changed)) + 1) % len(targets)]
    tnew = targets.copy()
    tnew[changed] = normalized(.85 * targets[changed] + .15 * targets[donor])
    yield "target_mix_1pct", q, tnew, empty, changed
    changed_q = np.flatnonzero(np.any(perturbed_q != q, axis=1))
    changed_t = np.flatnonzero(np.any(perturbed_t != targets, axis=1))
    yield "historical_edge_deletion", perturbed_q, perturbed_t, changed_q, changed_t


def topk_diagnosis(scores, objective):
    n, m = scores.shape
    result = {}
    for k in (1, 4, 16, 64):
        top = np.argpartition(scores, -k, axis=1)[:, -k:]
        restricted = np.full((n, m + n), -1e6)
        restricted[:, m:] = 0
        restricted[np.arange(n)[:, None], top] = scores[np.arange(n)[:, None], top]
        rows, cols = linear_sum_assignment(restricted, maximize=True)
        observed = float(restricted[rows, cols].sum())
        result[str(k)] = {"objective": observed, "loss": objective - observed}
    return result


def run_p1():
    identities()
    if load(OUT / "self_check.json")["status"] != "PASS":
        raise AssertionError("P0 incomplete")
    records, references, setups, manifests = [], [], [], []
    started = time.perf_counter()
    for graph in ("dw", "enfr"):
        loading = time.perf_counter()
        original, perturbed, source_order, ti, ids, basis = graph_inputs(graph)
        manifests.append({"graph": graph, "source_ids_development": ids[source_order[:1024]].tolist(),
            "target_ids_sha256": hashlib.sha256(ids[ti].tobytes()).hexdigest(),
            "source_count": 15000, "target_count": len(ti), "dimension": 600,
            "load_and_normalize_seconds": time.perf_counter() - loading,
            "labels_opened": False, "confirmation_sources_accessed": False})
        for n in (256, 1024):
            qi = source_order[:n]
            q, targets = original[qi], original[ti]
            score = q @ targets.T - TAU
            ref_started = time.perf_counter()
            a, b, assigned, ref = reference(score)
            ref.update({"graph": graph, "sources": n,
                "reference_seconds": time.perf_counter() - ref_started,
                "independent_top1_collisions": n - len(np.unique(np.argmax(score, axis=1))),
                "matched_rows": int(np.count_nonzero(assigned >= 0)),
                "topk": topk_diagnosis(score, ref["objective"])})
            references.append(ref)
            indices = {}
            for family, capacity in CONFIGS:
                method = family + "_" + str(capacity)
                build_started = time.perf_counter()
                indices[method] = BlockIndex(q, targets, basis, family, capacity)
                setups.append({"graph": graph, "sources": n, "method": method,
                    "seconds": time.perf_counter() - build_started,
                    "blocks": len(indices[method].groups)})
            updates = list(fixtures(q, targets, perturbed[qi], perturbed[ti], graph, ids[qi], ids[ti]))
            for name, qnew, tnew, changed_q, changed_t in updates:
                full = qnew @ tnew.T - TAU
                expected = dense_price(full, a, b)
                methods = ["dense_recompute", "dense_cache"] + list(indices)
                for repeat in range(3):
                    shift = repeat % len(methods)
                    for method in methods[shift:] + methods[:shift]:
                        # Restore the same old state outside all timed paths.
                        if method == "dense_cache":
                            cached = score.copy()
                        elif method in indices:
                            index = indices[method].clone()
                        begin = time.perf_counter()
                        if method == "dense_recompute":
                            current = qnew @ tnew.T - TAU
                            observed = dense_price(current, a, b)
                            cost = {"exact_pairs": n * len(targets)}
                        elif method == "dense_cache":
                            if len(changed_q):
                                cached[changed_q] = qnew[changed_q] @ tnew.T - TAU
                            if len(changed_t):
                                unchanged_rows = np.setdiff1d(np.arange(n), changed_q)
                                cached[np.ix_(unchanged_rows, changed_t)] = qnew[unchanged_rows] @ tnew[changed_t].T - TAU
                            observed = dense_price(cached, a, b)
                            cost = {"exact_pairs": len(changed_q) * len(targets)
                                    + (n - len(changed_q)) * len(changed_t)}
                        else:
                            touched = index.update(qnew, tnew, changed_q, changed_t)
                            observed = index.price(qnew, tnew, a, b)
                            cost = dict(observed[2], touched_target_blocks=touched)
                        elapsed = time.perf_counter() - begin
                        checks = check_price(full, a, b, observed)
                        records.append({"graph": graph, "sources": n, "update": name,
                            "repeat": repeat, "method": method, "seconds": elapsed,
                            "changed_sources": len(changed_q), "changed_targets": len(changed_t),
                            "checks": checks, "violating_rows": int(np.count_nonzero(expected[0])),
                            "status": "PASS", **cost})
                save(OUT / "cases" / f"{graph}_{n}_{name}.json",
                     {"graph": graph, "sources": n, "update": name,
                      "records": records[-3 * len(methods):]})
                print(graph, n, name, "PASS", "changed", len(changed_q), len(changed_t), flush=True)
            del indices, score, full
        del original, perturbed
    save(OUT / "p1_results.json", {"status": "COMPLETE", "records": records,
        "references": references, "setups": setups, "inputs": manifests,
        "seconds": time.perf_counter() - started,
        "scope": "pricing kernel using old optimal duals; LP repair outside timed pricing; no end-to-end speedup claim"})


def analyze():
    identities()
    data = load(OUT / "p1_results.json")
    rows = [r for r in data["records"] if r["update"] != "unchanged"]
    methods = [family + "_" + str(size) for family, size in CONFIGS]
    medians = {}
    for row in rows:
        key = (row["graph"], row["sources"], row["update"], row["method"])
        medians.setdefault(key, []).append(row["seconds"])
    medians = {key: float(np.median(values)) for key, values in medians.items()}
    setup = {(r["graph"], r["sources"], r["method"]): r["seconds"] for r in data["setups"]}
    comparisons = []
    for method in methods:
        blocks, by_graph = [], {}
        for graph in ("dw", "enfr"):
            base_cost = cost = evaluated = universe = 0.0
            for n in (256, 1024):
                for update in ("source_mix_1pct", "target_mix_1pct", "historical_edge_deletion"):
                    base = medians[graph, n, update, "dense_cache"]
                    proposed = medians[graph, n, update, method] + setup[graph, n, method] / 8
                    base_cost += base
                    cost += proposed
                    row = next(r for r in rows if (r["graph"], r["sources"], r["update"], r["method"]) == (graph, n, update, method))
                    evaluated += row["exact_pairs"]
                    universe += n * 15000
                    blocks.append((graph, base, proposed))
            by_graph[graph] = {"baseline_seconds": base_cost, "method_seconds_with_setup": cost,
                "cost_saving": 1 - cost / base_cost, "pair_saving": 1 - evaluated / universe}
        rng = np.random.default_rng(2026110923)
        bootstrap = np.zeros(10000)
        total_base = np.zeros(10000)
        for graph in ("dw", "enfr"):
            values = np.array([(base, proposed) for g, base, proposed in blocks if g == graph])
            sampled = rng.integers(0, len(values), size=(10000, len(values)))
            total_base += values[sampled, 0].sum(axis=1)
            bootstrap += values[sampled, 1].sum(axis=1)
        interval = np.quantile(1 - bootstrap / total_base, [.025, .975]).tolist()
        passed = (all(r["cost_saving"] >= .2 and r["pair_saving"] >= .2 for r in by_graph.values())
                  and interval[0] > 0)
        comparisons.append({"method": method, "by_graph": by_graph,
            "paired_descriptive_95pct_saving": interval, "pass": passed,
            "total_seconds": sum(r["method_seconds_with_setup"] for r in by_graph.values())})
    eligible = [r for r in comparisons if r["pass"]]
    selected = min(eligible, key=lambda r: (r["total_seconds"], methods.index(r["method"]))) if eligible else None
    decision = {"status": "P1_PASS_REQUIRES_P2" if selected else "STOP_P1_NO_ECONOMIC_PRICING",
        "selected": selected["method"] if selected else None, "comparisons": comparisons,
        "correctness_checks": sum(r["checks"] for r in data["records"]),
        "all_pricing_checks_passed": all(r["status"] == "PASS" for r in data["records"]),
        "scope": "fixed cap/split index families on historical RREA vectors; no general impossibility claim",
        "protocol_sha256": sha(OUT / "protocol.json")}
    save(OUT / "decision.json", decision)
    print(json.dumps(decision, ensure_ascii=False, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("freeze", "recover", "self_check", "p1", "analyze"))
    args = parser.parse_args()
    {"freeze": freeze, "recover": recover, "self_check": self_check, "p1": run_p1,
     "analyze": analyze}[args.phase]()


if __name__ == "__main__":
    main()
