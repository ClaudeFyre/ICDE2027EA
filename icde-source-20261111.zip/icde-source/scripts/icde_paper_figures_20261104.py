"""Produce paper figures from frozen evidence; never synthesize observations."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

ROOT = Path(__file__).resolve().parents[1]
COLORS = ["#355f8d", "#20908d", "#db8c31", "#81548d"]


def load(path):
    return json.loads(path.read_text("utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=False)
    plt.rcParams.update({"font.family":"DejaVu Serif", "font.size":8,
        "axes.labelsize":8,"axes.titlesize":8,"legend.fontsize":7,
        "xtick.labelsize":7,"ytick.labelsize":7,"pdf.fonttype":42})
    sources = [ROOT / p for p in (
        "nodes/03_wsdm/results/scale500_evidence/scale500_evidence.json",
        "nodes/09_vldb_query_certification/results/budget_v2_hard_20261104_attempt1/hard_budget_gate.json",
        "nodes/09_vldb_query_certification/results/budget_v2_20261104_attempt1/budget_gate.json")]
    nominal, hard, paired = map(load, sources)
    outputs = []

    def save(fig, name):
        fig.savefig(out / (name+".pdf"), bbox_inches="tight", pad_inches=.03)
        fig.savefig(out / (name+".png"), dpi=180, bbox_inches="tight", pad_inches=.03)
        plt.close(fig)
        outputs.append({"name":name,"pdf_sha256":sha(out/(name+".pdf"))})

    fig, ax = plt.subplots(figsize=(7.0,1.95))
    ax.set(xlim=(0,10),ylim=(0,2.7)); ax.axis("off")
    boxes = [(.05,1.48,1.8,.86,"Frozen query\nscorer / candidates\njoint world law"),
             (2.2,1.48,1.65,.86,"Complete scope\nprune safely\ncompile or fall back"),
             (4.2,1.48,1.65,.86,"Admit work\nsample a block\nevaluate winner"),
             (6.2,1.48,1.65,.86,"Nominal CS\nprotected gaps\ncheck stopping"),
             (8.2,1.48,1.7,.86,"Return evidence\nnominal / robust\nor unresolved"),
             (4.2,.1,3.65,.8,"Paid event prefix, same uniforms\nInterval envelope + binomial upper bound")]
    for idx,(x,y,w,h,label) in enumerate(boxes):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=.04",fc="#edf4f7" if idx<5 else "#e6f2eb",ec=COLORS[0],lw=.8))
        ax.text(x+w/2,y+h/2,label,ha="center",va="center",fontsize=6.4)
    for a,b in [(1.9,2.13),(3.9,4.13),(5.9,6.13),(7.9,8.13)]:
        ax.add_patch(FancyArrowPatch((a,1.91),(b,1.91),arrowstyle="-|>",mutation_scale=9,lw=.8))
    ax.add_patch(FancyArrowPatch((5.02,1.43),(5.02,.95),arrowstyle="-|>",mutation_scale=9,lw=.8))
    ax.add_patch(FancyArrowPatch((7.02,.95),(7.02,1.43),arrowstyle="-|>",mutation_scale=9,lw=.8))
    ax.text(6.05,1.12,"complete prefixes; no extra event draws",ha="center",fontsize=7)
    save(fig,"execution_contract")

    fig, axes = plt.subplots(1,2,figsize=(7.0,2.25),sharey=True)
    for ax,graph in zip(axes,("D-W","EN-FR")):
        cells={r["scorer"]:r for r in nominal["cells"] if r["graph"]==graph}
        x=np.arange(3); width=.35
        for j,method in enumerate(("uniform","gap_cost")):
            vals=[100*cells[s]["strategies"][method]["stable_coverage"] for s in ("attribute","propagation","relation-aware")]
            bars=ax.bar(x+(j-.5)*width,vals,width,color=COLORS[j],label=("Uniform" if j==0 else "Gap and cost"))
            for bar,v in zip(bars,vals):
                ax.text(bar.get_x()+bar.get_width()/2,v+1,f"{v:.1f}",ha="center",fontsize=6.5)
        ax.set_xticks(x,["Attribute","Propagation","Relation-aware"])
        ax.set_title(graph);ax.set_ylim(0,105);ax.grid(axis="y",alpha=.18);ax.set_axisbelow(True)
    axes[0].set_ylabel("Nominal certified coverage (%)")
    axes[1].legend(loc="upper right",frameon=False)
    fig.tight_layout(pad=.7)
    save(fig,"nominal_scheduling")

    fig, axes=plt.subplots(1,2,figsize=(7.0,2.3),sharey=True)
    for ax,graph in zip(axes,("D-W","EN-FR")):
        for idx,policy in enumerate(("scope_full_risk","difference_eager","difference_lazy","source_conditioned_lazy")):
            rows=[r for r in hard["aggregate"] if r["graph"]==graph and r["tau"]==.001 and r["budget_fraction"]==1 and r["policy"]==policy]
            rows.sort(key=lambda r:r["interval_work_weight"])
            ax.plot([r["interval_work_weight"] for r in rows],[r["stable_count"]/r["query_seed_cases"]*100 for r in rows],marker=("o","s","^","x")[idx],color=COLORS[idx],label=("Scope only","Shared eager","Shared lazy","Source lazy")[idx],lw=1.2)
        ax.set_xticks([.5,1,2]); ax.set_xlabel("Declared relative interval charge")
        ax.set_title(graph);ax.grid(alpha=.2)
    axes[0].set_ylabel("Robust certified cases (%)")
    axes[0].set_ylim(60,102)
    axes[1].legend(loc="lower left",frameon=False,ncol=2,columnspacing=.7,handlelength=1.6)
    fig.tight_layout(pad=.7)
    save(fig,"interval_cost_sensitivity")

    audits=paired["query_audits"]
    fig,axes=plt.subplots(1,2,figsize=(7.0,2.25))
    graph_edges={"D-W":10153,"EN-FR":11101}
    fractions=[];ks=[]
    for graph in ("D-W","EN-FR"):
        rows=[r for r in audits if r["graph"]==graph]
        # The query audits contain one entry per query, not per seed.
        unique={r["query_id"]:r for r in rows}.values()
        fractions.append([r["compilation"]["scope_edges"]/graph_edges[graph]*100 for r in unique])
        ks.append([r["compilation"]["candidate_count"] for r in unique])
    for ax,vals,label in zip(axes,(fractions,ks),("Complete scope / full edges (%)","Retained candidates")):
        ax.boxplot(vals,labels=["D-W","EN-FR"],widths=.45,showfliers=False)
        for i,v in enumerate(vals,1):
            ax.scatter(i+np.linspace(-.13,.13,len(v)),v,s=11,color=COLORS[i-1],alpha=.8,zorder=3)
        ax.set_ylabel(label);ax.grid(axis="y",alpha=.2)
    axes[0].set_yscale("symlog",linthresh=.1)
    axes[1].set_yscale("log")
    fig.tight_layout(pad=.7)
    save(fig,"scope_candidates")
    (out/"figure_provenance.json").write_text(json.dumps({"source_files":[{"path":str(p.relative_to(ROOT)),"sha256":sha(p)} for p in sources],"outputs":outputs,"interpretation":"Descriptive frozen measurements. No confidence intervals fabricated from aggregate seeds. Diagram is algorithm structure, not performance data."},indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":
    main()
