"""Draw completed ICDE gate evidence and independently audit hybrid records.

No scorer, random generator, training, model inference, or new world capture is
executed. Deterministic source-box bounds, statistical bounds and fee arithmetic
are reconstructed from saved observations before any performance figure is made.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np

from run_vldb_interval_gate_v1 import clipped_box, conservative_scope_tv
import icde_gate_inference as inference
import vldb_event_bound_v2 as event_bounds
from icde_gate_comparison_runner import prepare_settings, actual_checkpoints
from vldb_capture_attribute_v0 import stream_seed


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "nodes/09_vldb_query_certification/results"
GRAPHS = ("D-W", "EN-FR")
SCALE_METHODS = ("scope_full_risk", "difference_eager", "difference_lazy")
COLORS = ("#555555", "#205c8a", "#b46a22")
RULE_COLORS = {"normal": COLORS[0], "ppr": COLORS[1], "eb": COLORS[2]}


def inside(value):
    path = Path(value)
    path = (path if path.is_absolute() else ROOT / path).resolve()
    path.relative_to(ROOT)
    return path


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class Sources:
    def __init__(self):
        self.records = {}

    def add(self, path, role):
        path = inside(path)
        key = path.relative_to(ROOT).as_posix()
        if key not in self.records:
            self.records[key] = {"path": key, "sha256": sha(path),
                                 "bytes": path.stat().st_size, "roles": []}
        if role not in self.records[key]["roles"]:
            self.records[key]["roles"].append(role)
        return self.records[key]

    def json(self, path, role):
        self.add(path, role)
        with inside(path).open(encoding="utf-8-sig") as handle:
            return json.load(handle)


class Checks:
    def __init__(self):
        self.counts = Counter()
        self.errors = []

    def require(self, condition, name, label=""):
        self.counts[name] += 1
        if not condition and len(self.errors) < 50:
            self.errors.append({"check": name, "record": label})

    def close(self, actual, expected, name, label=""):
        self.require(math.isfinite(float(actual)) and math.isfinite(float(expected))
                     and math.isclose(float(actual), float(expected), rel_tol=1e-12, abs_tol=1e-7), name, label)


def array_sha(value):
    return hashlib.sha256(value.tobytes(order="C")).hexdigest()


def combined_bound(scope, source, event):
    exact = Fraction.from_float(source) + Fraction.from_float(event)
    if exact >= 1:
        total = 1.
    else:
        total = float(exact)
        if Fraction.from_float(total) < exact:
            total = math.nextafter(total, math.inf)
    return min(scope, total, 1.)


def aggregate_raw(rows):
    groups = []
    for graph in ("ALL", *GRAPHS):
        for policy in sorted({row["policy"] for row in rows}):
            selected = [row for row in rows if row["policy"] == policy
                        and (graph == "ALL" or row["graph"] == graph)]
            if selected:
                groups.append({"graph": graph, "method": policy, "cases": len(selected),
                    "distinct_sources": len({(row["graph"], row["query_id"]) for row in selected}),
                    "objective_certificates": sum(row["certified"] for row in selected),
                    "nominal_certificates": sum(row["nominal_certified"] for row in selected),
                    "nontrivial_cases": sum(row["candidate_count"] > 1 for row in selected),
                    "competitive_objective_certificates": sum(row["certified"] and row["candidate_count"] > 1
                                                               for row in selected),
                    "worlds": sum(row["samples_used"] for row in selected),
                    "event_rows": sum(row["event_samples_used"] for row in selected),
                    "work_used": sum(row["work_used"] for row in selected),
                    "serving_seconds": {"sum": sum(row["seconds"]["query_serving_total"] for row in selected)}})
    return groups


def validate_hybrid(comparison_dir, hybrid_dir, sources):
    checks = Checks()
    comparison_dir, hybrid_dir = inside(comparison_dir), inside(hybrid_dir)
    controls = sources.json(comparison_dir / "summary.json", "completed_comparison_summary")
    control_freeze = sources.json(comparison_dir / "protocol_freeze.json", "comparison_frozen_protocol")
    summary = sources.json(hybrid_dir / "summary.json", "completed_hybrid_summary")
    freeze = sources.json(hybrid_dir / "protocol_freeze.json", "hybrid_frozen_protocol")
    checks.require(controls["status"] == summary["status"] == "COMPLETE", "complete_gate_summaries")
    for relative, expected in freeze["code_sha256"].items():
        path = inside(relative)
        checks.require(path.is_file() and sha(path) == expected, "hybrid_frozen_code_sha", relative)
    config = {**freeze["config"], "policies": ["normal_event", "eb_event"]}
    settings = prepare_settings(config, freeze["resolved_query_count"])
    checkpoints = actual_checkpoints(settings)
    checks.require(list(checkpoints) == freeze["actual_nominal_checkpoints"], "actual_gap_checkpoint_union")
    checks.require(freeze["actual_seed_purpose"] == control_freeze["actual_seed_purpose"], "same_actual_stream_purpose")
    checks.require(freeze["seeds"] == control_freeze["resolved_seeds"] == [97, 109, 127], "same_three_MC_seeds")
    control_setups = {}
    for item in controls["setup_files"]:
        path = inside(item["path"])
        checks.require(sources.add(path, "comparison_query_identity")["sha256"] == item["sha256"], "control_setup_sha")
        report = sources.json(path, "comparison_query_identity")
        for query in report["query_setup"]:
            control_setups[report["graph"], query["query_id"]] = query
    queries = {}
    setup_seconds = 0.
    for item in summary["setup_files"]:
        path = inside(item["path"])
        checks.require(sources.add(path, "hybrid_query_and_partition_identity")["sha256"] == item["sha256"], "hybrid_setup_sha")
        report = sources.json(path, "hybrid_query_and_partition_identity")
        setup_seconds += report["hybrid_preparation_seconds"]
        dataset = inside(report["dataset_path"])
        for filename, expected in report["input_sha256"].items():
            source = sources.add(dataset / filename, "hybrid_original_input_identity")
            checks.require(source["sha256"] == expected, "hybrid_dataset_file_sha", filename)
        with (dataset / "triples.tsv").open(encoding="utf-8-sig", newline="") as handle:
            triples = list(csv.DictReader(handle, delimiter="\t"))
        for query in report["query_setup"]:
            key = report["graph"], query["query_id"]
            original = control_setups[key]
            for field in ("candidate_ids", "scope_edge_indices", "scope_certificate"):
                checks.require(query[field] == original[field], "same_control_query_identity", str(key) + ":" + field)
            scope = query["scope_edge_indices"]
            q = np.asarray([float(triples[index]["confidence"]) for index in scope], dtype=np.float64)
            low, high = clipped_box(q, settings["tau"])
            source_positions = tuple(position for position, index in enumerate(scope)
                                     if triples[index]["head_id"] == query["query_id"]
                                     or triples[index]["tail_id"] == query["query_id"])
            indices = np.asarray(source_positions, dtype=np.intp)
            low_t, high_t = low.copy(), high.copy()
            low_t[indices], high_t[indices] = q[indices], q[indices]
            epsilon_s = conservative_scope_tv(q[indices], low[indices], high[indices])[0]
            epsilon = conservative_scope_tv(q, low, high)[0]
            metadata = report["hybrid_preparation"][query["query_id"]]
            checks.require(tuple(metadata["source_positions"]) == source_positions, "source_incident_partition", str(key))
            for field, array in (("nominal_probability_sha256", q), ("original_low_sha256", low),
                                 ("original_high_sha256", high), ("hybrid_low_sha256", low_t), ("hybrid_high_sha256", high_t)):
                checks.require(metadata[field] == array_sha(array), "original_and_hybrid_box_sha", str(key) + ":" + field)
            checks.require(metadata["epsilon_source_upper"] == epsilon_s
                           and metadata["epsilon_scope_upper"] == epsilon == query["scope_epsilon_upper"],
                           "outward_source_and_full_scope_TV", str(key))
            queries[key] = {"query": query, "hybrid": metadata, "epsilon_source": epsilon_s,
                            "epsilon_scope": epsilon, "revision": report["dataset_revision"]}
    baseline = {}
    for item in controls["case_files"]:
        if item["policy"] not in ("normal_event", "eb_event"):
            continue
        path = inside(item["path"])
        checks.require(sources.add(path, "paired_generic_control_case")["sha256"] == item["sha256"], "generic_case_sha")
        row = sources.json(path, "paired_generic_control_case")
        baseline[row["graph"], row["query_id"], row["seed"], row["policy"]] = row
    rows, seen, paired_prefixes = [], set(), 0
    for item in summary["case_files"]:
        path = inside(item["path"])
        checks.require(sources.add(path, "hybrid_online_case")["sha256"] == item["sha256"], "hybrid_case_sha")
        row = sources.json(path, "hybrid_online_case")
        label = path.name
        key = row["graph"], row["query_id"], row["seed"], row["policy"]
        checks.require(key not in seen, "unique_hybrid_case", label)
        seen.add(key)
        identity = queries[row["graph"], row["query_id"]]
        query, hybrid = identity["query"], identity["hybrid"]
        checks.require(row["hybrid_metadata"] == hybrid, "case_partition_metadata_binding", label)
        checks.require(row["dataset_revision"] == identity["revision"]
                       and row["epsilon_source_upper"] == identity["epsilon_source"]
                       and row["scope_epsilon_upper"] == identity["epsilon_scope"], "case_source_and_scope_bounds", label)
        method = row["policy"].replace("_hybrid", "_event")
        reference = baseline[row["graph"], row["query_id"], row["seed"], method]
        expected_seed = stream_seed(row["graph"], row["dataset_revision"], row["query_id"],
                                    row["seed"], freeze["actual_seed_purpose"])
        checks.require(row["rng_seed_hex"] == reference["rng_seed_hex"] == hex(expected_seed), "paired_actual_rng_identity", label)
        reference_trace = {entry["nominal_samples"]: entry for entry in reference["trace"]}
        for entry in row["trace"]:
            if entry["nominal_samples"] in reference_trace:
                other = reference_trace[entry["nominal_samples"]]
                checks.require(entry["uniform_prefix_sha256"] == other["uniform_prefix_sha256"]
                               and entry["winner_prefix_sha256"] == other["winner_prefix_sha256"], "paired_common_prefix", label)
                paired_prefixes += 1
        n, k, m = row["samples_used"], row["candidate_count"], row["scope_edge_count"]
        checks.require(k == len(query["candidate_ids"]) and m == len(query["scope_edge_indices"]),
                       "case_candidate_and_scope_dimensions", label)
        winners = np.asarray(row["winner_indices"], dtype=np.int64)
        checks.require(len(winners) == n <= settings["sample_count"]
                       and np.all((0 <= winners) & (winners < k)), "observed_winner_universe", label)
        checks.require(np.array_equal(np.bincount(winners, minlength=k), np.asarray(row["winner_counts"]))
                       and row["nominal_score_rows"] == row["worlds_generated"] == n
                       and row["random_uniform_draws"] == n * m
                       and row["event_extra_random_draws"] == 0, "exact_counts_worlds_draws", label)
        checks.require(array_sha(winners) == row["winner_prefix_sha256"], "saved_winner_sequence_hash", label)
        event_n = row["event_samples_used"]
        checks.require(event_n in (0, *settings["risk_plan"]["event_checkpoints"])
                       and 0 <= row["event_count"] <= row["event_free_rows"] <= event_n <= n
                       and row["event_rows_computed"] == event_n, "complete_protected_event_prefix", label)
        event_upper = row["event_upper"]
        checks.require(0 <= event_upper <= 1 and (event_n > 0 or event_upper == 1.),
                       "stored_event_upper_range_and_prefix", label)
        # Validate the stored upper bound; never request a new SciPy proposal
        # in this plotting environment. A bound of1 is trivially conservative.
        if event_n and event_upper < 1:
            tail = event_bounds.binomial_cdf_upper(row["event_count"], event_n, event_upper)
            checks.require(tail <= Decimal.from_float(settings["risk_plan"]["alpha_per_checkpoint"]),
                           "stored_event_upper_outward_tail_verified_without_SciPy", label)
        expected_effective = combined_bound(identity["epsilon_scope"], identity["epsilon_source"], event_upper)
        checks.require(row["effective_epsilon_upper"] == expected_effective, "source_TV_plus_CP_effective_bound", label)
        checks.require(row["nominal_delta"] == settings["delta_nominal"]
                       and row["event_beta_total"] == settings["beta_total"]
                       and row["actual_nominal_checkpoints"] == list(checkpoints), "risk_and_checkpoint_contract", label)
        cost = query["cost_model"]
        candidate_units = settings["work_model"]["interval_candidate_units"]
        nominal_unit = max(1, m + cost["original_incidence_entries"]
                           + settings["work_model"]["nominal_candidate_units"] * k)
        variable_unit = 2 * cost["interval_incidence_entries"] + candidate_units * k
        weight = settings["interval_work_weight"]
        expected_work = (n + 1) * nominal_unit + weight * (2 * m * event_n + variable_unit * row["event_free_rows"])
        expected_budget = (int(settings["sample_count"] * settings["budget_fraction"]) + 1) * nominal_unit
        checks.close(row["work_used"], expected_work, "reconstructed_full_width_work", label)
        checks.require(row["work_budget"] == expected_budget and row["work_used"] <= expected_budget
                       and row["work_overshoot"] == 0, "strict_logical_budget", label)
        previous_n = previous_event = 0
        previous_work = float(nominal_unit)
        for entry in row["trace"]:
            current_n = entry["nominal_samples"]
            before_event = previous_work + (current_n - previous_n) * nominal_unit
            if "lower_gap" in entry:
                lower = inference.numerical_gap_bound(np.bincount(winners[:current_n], minlength=k),
                                                      current_n, settings["delta_nominal"], row["inference_rule"])
                checks.require(entry["lower_gap"] == lower, "recomputed_numerical_lower_gap", label)
                effective = combined_bound(identity["epsilon_scope"], identity["epsilon_source"], entry["event_upper"])
                checks.require(entry["effective_epsilon_upper"] == effective, "every_look_source_plus_CP", label)
                selected = entry["event_upgrade_to"]
                static = ((selected - previous_event) * (2 * m + variable_unit) * weight if selected is not None else 0.)
                checks.close(entry["static_event_fee"], static, "unchanged_generic_static_admission_fee", label)
                admission = entry["event_admission"]
                if admission == "approved":
                    checks.require(before_event + static <= expected_budget
                                   and entry["actual_event_fee"] <= static
                                   and entry["event_samples"] == selected, "preexecution_admission", label)
                elif admission == "rejected_budget":
                    checks.require(before_event + static > expected_budget and entry["actual_event_fee"] == 0
                                   and entry["event_samples"] == previous_event, "rejection_no_charge_or_evidence", label)
                else:
                    checks.require(entry["actual_event_fee"] == 0 and entry["event_samples"] == previous_event,
                                   "no_unrequested_event_work", label)
                checks.close(entry["work_used"], before_event + entry["actual_event_fee"], "trace_work_reconstruction", label)
            previous_n, previous_event, previous_work = current_n, entry["event_samples"], entry["work_used"]
        if k > 1:
            lower = inference.numerical_gap_bound(row["winner_counts"], n, settings["delta_nominal"], row["inference_rule"])
            checks.require(row["final_lower_gap"] == lower, "final_numerical_gap", label)
            checks.require(not row["certified"] or (lower > 2 * expected_effective
                           and row["certified_candidate_index"] == int(np.argmax(row["winner_counts"]))), "strict_robust_release", label)
        checks.require(row["certified"] == row["robust_certified"] == row["stable"]
                       and (not row["certified"] or row["nominal_certified"]), "certificate_status_semantics", label)
        rows.append(row)
    expected = {(graph, query_id, seed, policy) for graph, query_id in queries
                for seed in freeze["seeds"] for policy in freeze["resolved_policies"]}
    checks.require(seen == expected and len(rows) == summary["completed_cases"], "complete_hybrid_case_grid")
    validation = {"status": "PASS" if not checks.errors else "FAIL", "check_counts": dict(checks.counts),
                  "errors": checks.errors, "hybrid_cases": len(rows), "paired_common_prefixes": paired_prefixes,
                  "scope": "saved source/box identity, exact winner counts, bounds and fees; no scorer or RNG execution",
                  "stored_event_bound_check": "outward_binomial_CDF_at_saved_upper_no_SciPy_quantile_reestimation",
                  "limitations": ["Raw U matrices and h_T sequences are not persisted and are not regenerated here.",
                                  "Pointwise event-envelope soundness relies on the frozen implementation and exact tests."],
                  "generic_hybrid_best_of_policy_guarantee_claim": False}
    return validation, aggregate_raw(rows), setup_seconds


def one(rows, graph, method):
    selected = [row for row in rows if row["graph"] == graph and row["method"] == method]
    if len(selected) != 1:
        raise ValueError(f"expected one aggregate for {graph}/{method}")
    return selected[0]


def save_figure(figure, output, name):
    result = []
    for extension in ("pdf", "png"):
        path = output / f"{name}.{extension}"
        figure.savefig(path, dpi=300, metadata={"Creator": "ICDE recorded-evidence figure script"})
        result.append({"path": path.relative_to(ROOT).as_posix(), "sha256": sha(path), "bytes": path.stat().st_size})
    plt.close(figure)
    return result


def clean(axis):
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(axis="y", color=".9", linewidth=.45)
    axis.set_axisbelow(True)


def figure_scale(audit, output):
    figure, axes = plt.subplots(1, 2, figsize=(7, 2.4))
    figure.subplots_adjust(left=.075, right=.985, bottom=.21, top=.80, wspace=.28)
    x, width = np.arange(2), .23
    labels = ("Scope only", "Shared event, eager", "Shared event, lazy")
    handles = []
    for index, method in enumerate(SCALE_METHODS):
        rows = [one(audit["scale"]["aggregate"], graph, method) for graph in GRAPHS]
        coverage = [100 * row["robust_certificates"] / row["cases"] for row in rows]
        serving = [row["serving_seconds"]["sum"] for row in rows]
        bars = axes[0].bar(x + (index - 1) * width, coverage, width, color=COLORS[index], label=labels[index])
        axes[1].bar(x + (index - 1) * width, serving, width, color=COLORS[index])
        axes[0].bar_label(bars, fmt="%.1f", padding=2, fontsize=8)
        handles.append(bars)
    for axis in axes:
        axis.set_xticks(x, ("D–W", "EN–FR"))
        clean(axis)
    axes[0].set_ylim(0, 100)
    axes[0].set_ylabel("Robust certificates (%)")
    axes[1].set_ylim(bottom=0)
    axes[1].set_ylabel("Serving total (s)")
    figure.legend(handles, labels, ncol=3, loc="upper center", frameon=False)
    return save_figure(figure, output, "gate_scale500")


def figure_controls(audit, hybrid, output):
    figure, axes = plt.subplots(1, 2, figsize=(7, 2.4))
    figure.subplots_adjust(left=.08, right=.985, bottom=.26, top=.84, wspace=.25)
    nominal = ("normal_nominal", "ppr_nominal", "eb_nominal")
    robust = ("normal_event", "normal_hybrid", "eb_event", "eb_hybrid")
    for index, methods in enumerate((nominal, robust)):
        rows = [one(hybrid if method.endswith("hybrid") else audit["comparison"]["aggregate"],
                    "ALL", method) for method in methods]
        colors = [RULE_COLORS["ppr" if method.startswith("ppr") else "eb" if method.startswith("eb") else "normal"]
                  for method in methods]
        for position, (method, row) in enumerate(zip(methods, rows)):
            bar = axes[index].bar(position, row["worlds"] / 1000, .66, color=colors[position],
                                   hatch="//" if method.endswith("hybrid") else None)
            axes[index].bar_label(bar, labels=[f"{row['objective_certificates']}/{row['cases']}"],
                                 padding=3, fontsize=8)
        clean(axes[index])
        axes[index].set_ylim(0, max(row["worlds"] / 1000 for row in rows) * 1.22)
    axes[0].set_xticks(range(3), ("Normal", "PPR-1v1", "Emp. Bernstein"))
    axes[1].set_xticks(range(4), ("Normal\ngeneric", "Normal\nhybrid", "EB\ngeneric", "EB\nhybrid"))
    axes[0].set_title("Nominal objective", pad=5)
    axes[1].set_title("Robust objective", pad=5)
    axes[0].set_ylabel("World evaluations (thousands)")
    axes[1].set_ylabel("World evaluations (thousands)")
    return save_figure(figure, output, "gate_mode_controls")


def figure_neural(audit, output):
    figure, axes = plt.subplots(1, 2, figsize=(7, 2.4), sharey=True)
    figure.subplots_adjust(left=.07, right=.985, bottom=.28, top=.78, wspace=.15)
    rules = ("normal", "ppr_uniform_jain", "empirical_bernstein")
    positions = (0., 1.05, 2.45, 3.5)
    for column, graph in enumerate(("dw", "enfr")):
        axis = axes[column]
        for pair_index, worlds in enumerate((256, 512)):
            rows = [row for row in audit["neural"]["rows"] if row["graph"] == graph and row["worlds"] == worlds]
            if len(rows) != 1:
                raise ValueError("missing neural primary/diagnostic row")
            counts = rows[0]["certificate_counts"]
            if any(families["A_full_edge_box"] != 0 for families in counts["robust"].values()):
                raise ValueError("full-family-zero annotation no longer describes the saved results")
            for index, rule in enumerate(rules):
                bar = axis.bar(positions[pair_index] + (index - 1) * .22,
                               counts["nominal"][rule], .2, color=COLORS[index])
                axis.bar_label(bar, padding=1.5, fontsize=8)
            for index, rule in enumerate(("normal", "empirical_bernstein")):
                bar = axis.bar(positions[pair_index + 2] + (index - .5) * .25,
                               counts["robust"][rule]["B_maintenance128"], .22,
                               color=COLORS[0 if index == 0 else 2], hatch="//")
                axis.bar_label(bar, padding=1.5, fontsize=8)
        axis.set_xticks(positions, ("N 256\nprimary", "N 512\ndiag.", "B 256\nprimary", "B 512\ndiag."))
        axis.set_title(GRAPHS[column], pad=4)
        axis.set_ylim(0, 37)
        axis.set_yticks((0, 8, 16, 24, 32))
        clean(axis)
    axes[0].set_ylabel("Certified queries / 32")
    figure.legend([Patch(color=color) for color in COLORS], ("Normal", "PPR-1v1 (nominal only)", "Emp. Bernstein"),
                  loc="upper center", ncol=3, frameon=False)
    figure.text(.52, .018, "N: nominal. B: maintenance128 family. Full edge-box family A: 0 robust at both budgets.",
                ha="center", fontsize=8)
    return save_figure(figure, output, "gate_neural_family")


def optional_decision(path, sources, output):
    if path is None:
        return {"status": "PENDING", "reason": "no completed exact decision-value source supplied"}, []
    path = inside(path)
    path = path / "summary.json" if path.is_dir() else path
    if not path.is_file():
        return {"status": "PENDING", "reason": "requested exact decision-value summary does not exist"}, []
    summary = sources.json(path, "optional_exact_decision_value_summary")
    if summary.get("status") != "COMPLETE":
        return {"status": "PENDING", "reason": "exact decision-value summary is not complete"}, []
    if (path.parent / "protocol_freeze.json").is_file():
        sources.add(path.parent / "protocol_freeze.json", "exact_review_frozen_protocol")
    selected_methods = ("point_all_present", "ppr_nominal", "point_margin_gt_0.05", "normal_scope", "normal_event", "normal_hybrid")
    table = summary["review_table"]
    groups = defaultdict(lambda: Counter())
    for row in table:
        if row["policy"] not in selected_methods:
            continue
        if (row["uniform_safe"] + row["false_clear"] != row["approved"]
                or row["approved"] + row["reviewed"] != row["cases"]
                or not 0 <= row["avoidable_review"] <= row["reviewed"]):
            raise ValueError("invalid exact review accounting")
        for field in ("cases", "false_clear", "avoidable_review"):
            groups[row["policy"], row["tau"]][field] += row[field]
    figure, axes = plt.subplots(1, 2, figsize=(7, 2.4))
    figure.subplots_adjust(left=.08, right=.985, bottom=.23, top=.69, wspace=.28)
    names = {"point_all_present": "All-present point", "ppr_nominal": "PPR nominal shortcut", "point_margin_gt_0.05": "Point margin > .05",
             "normal_scope": "Scope", "normal_event": "Generic event", "normal_hybrid": "Hybrid"}
    colors = ("#999999", "#397d53", "#7d7098", COLORS[0], COLORS[1], COLORS[2])
    handles, legend = [], []
    points = []
    for index, method in enumerate(selected_methods):
        rows = sorted((tau, value) for (policy, tau), value in groups.items() if policy == method)
        if not rows:
            continue
        for panel, field in enumerate(("false_clear", "avoidable_review")):
            line, = axes[panel].plot([tau for tau, value in rows],
                                    [100 * value[field] / value["cases"] for tau, value in rows],
                                    color=colors[index], marker=("o", "x", "s", "^", "D", "v")[index],
                                    linestyle="--" if method == "ppr_nominal" else "-")
            if panel == 0:
                handles.append(line)
                legend.append(names[method])
        points.extend({"method": method, "tau": tau, **dict(value)} for tau, value in rows)
    if not points:
        raise ValueError("no recognized policies in completed exact review source")
    for index, axis in enumerate(axes):
        axis.set_xscale("log")
        axis.set_xlabel("Probability half-width")
        axis.set_ylabel(("Unsafe clearances (%)", "Avoidable review (%)")[index])
        axis.set_ylim(bottom=0)
        clean(axis)
    figure.legend(handles, legend, ncol=3, loc="upper center", frameon=False, fontsize=7)
    return {"status": "COMPLETE", "points": points,
            "scope": "controlled exact whole-box reference; no measured human savings",
            "rate_denominator": "all selected query/family cases at that half-width"}, save_figure(figure, output, "gate_exact_decision_value")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit-dir", default=str(RESULTS / "icde_gate_integrated_audit_20261105_attempt1"))
    parser.add_argument("--comparison-dir", default=str(RESULTS / "icde_gate_controls_20261105_attempt1"))
    parser.add_argument("--hybrid-dir", default=str(RESULTS / "icde_gate_hybrid_20261105_attempt1"))
    parser.add_argument("--neural-dir", default=str(RESULTS / "icde_gate_rrea_20261105_attempt1"))
    parser.add_argument("--decision-value")
    parser.add_argument("--output-dir", default="papers/icde/regular2027/figures/gates_20261105_attempt1")
    args = parser.parse_args()
    output = inside(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    sources = Sources()
    audit_dir = inside(args.audit_dir)
    audit = sources.json(audit_dir / "summary.json", "PASS_integrated_evidence_audit")
    validation = sources.json(audit_dir / "validation.json", "integrated_validation_counts")
    if audit["audit"]["status"] != "PASS" or validation["status"] != "PASS" or not audit["all_three_gates_present"]:
        raise ValueError("all integrated gates must have passed before plotting")
    if (audit["scale"]["cases"] != 9000 or audit["scale"]["distinct_sources"] != 1000
            or any(one(audit["scale"]["aggregate"], "ALL", method)["cases"] != 3000 for method in SCALE_METHODS)):
        raise ValueError("scale figure denominators differ from the1000-query/3000-case contract")
    for filename in ("scale_cases.csv", "comparison_cases.csv"):
        sources.add(audit_dir / filename, "integrated_case_level_records")
    for filename in ("summary.json", "protocol_before_draws.json", "dw/progress.json", "enfr/progress.json"):
        sources.add(inside(args.neural_dir) / filename, "neural_raw_summary_protocol_and_progress")
    hybrid_validation, hybrid_groups, hybrid_setup = validate_hybrid(args.comparison_dir, args.hybrid_dir, sources)
    with (output / "hybrid_validation.json").open("x", encoding="utf-8") as handle:
        json.dump(hybrid_validation, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    if hybrid_validation["status"] != "PASS":
        raise ValueError("hybrid record validation failed; no figures drawn")
    plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"],
                         "font.size": 8, "axes.titlesize": 8, "axes.labelsize": 8,
                         "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 8,
                         "axes.linewidth": .6, "lines.linewidth": 1.1, "lines.markersize": 3.5,
                         "pdf.fonttype": 42, "ps.fonttype": 42})
    figures = figure_scale(audit, output) + figure_controls(audit, hybrid_groups, output) + figure_neural(audit, output)
    decision, additional = optional_decision(args.decision_value, sources, output)
    figures += additional
    sources.add(Path(__file__), "plotting_and_saved_record_validation_code")
    aggregates = {"scale": audit["scale"]["aggregate"], "comparison": audit["comparison"]["aggregate"],
                  "hybrid": hybrid_groups, "hybrid_extra_setup_seconds": hybrid_setup,
                  "neural": audit["neural"]["rows"], "decision_value": decision}
    with (output / "aggregates.json").open("x", encoding="utf-8") as handle:
        json.dump(aggregates, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    manifest = {"schema": "icde-gate-figure-provenance-20261105-v1", "figures": figures,
        "source_files": sorted(sources.records.values(), key=lambda row: row["path"]),
        "hybrid_validation": hybrid_validation, "aggregation_file": "aggregates.json",
        "aggregation_sha256": sha(output / "aggregates.json"),
        "hybrid_validation_sha256": sha(output / "hybrid_validation.json"),
        "captions": {
            "gate_scale500": "Five hundred distinct sources per graph (1000 unique queries overall), each repeated under three MC seeds: 3000 query-seed cases per method. Bars compare robust coverage and recorded serving totals. Serving excludes separately reported shard setup and durable file publication; the sharded aggregate is not an unsharded cold latency.",
            "gate_mode_controls": "Direct nominal and robust controls on32 distinct queries and three paired MC seeds. Bar height is total world evaluations; labels give objective certificates/96. Nominal controls use delta .05; robust event controls use .025 nominal plus .025 event risk. Hybrid source setup is separate. Small hybrid differences do not establish a major novel algorithm.",
            "gate_neural_family": "Full-graph RREA on32 queries per graph. N denotes nominal certification, B the prespecified128-coordinate maintenance family; 256 worlds is primary and512 diagnostic. PPR supplies only nominal decisions. The full edge-box family A has zero robust certificates and is a different model family, not a competing inference algorithm. No adaptive encoder saving or real-fact calibration is claimed.",
            "gate_exact_decision_value": "Optional controlled exact whole-box review study. Unsafe clearance and avoidable review are fractions of all selected cases at each half-width, aggregated over the two graph profiles. No measured human-review saving or deployed probability calibration is implied.",
        },
        "scientific_units": "unique source queries with repeated MC streams; not independent case-file replicates",
        "uncertainty_intervals": "none fabricated", "novelty_claim": False,
        "new_worlds_training_or_scorer_execution": False,
        "optional_decision_value_status": decision["status"]}
    with (output / "figure_provenance.json").open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    print(json.dumps({"output": output.relative_to(ROOT).as_posix(), "hybrid_validation": hybrid_validation["status"],
                      "hybrid_cases": hybrid_validation["hybrid_cases"], "figures": figures,
                      "optional_decision_value": decision["status"]}))


if __name__ == "__main__":
    main()
