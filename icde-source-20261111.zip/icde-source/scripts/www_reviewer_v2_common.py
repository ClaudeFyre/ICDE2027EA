"""Freeze and preserve targeted reviewer reruns without editing v1 evidence."""
from __future__ import annotations
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def freeze(files):
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    pinned = {}
    for name in files:
        data = (ROOT / name).read_bytes()
        saved = subprocess.check_output(["git", "show", f"{commit}:{name}"], cwd=ROOT)
        if data.replace(b"\r\n", b"\n") != saved.replace(b"\r\n", b"\n"):
            raise RuntimeError(f"STOP: implementation not frozen in HEAD: {name}")
        pinned[name] = hashlib.sha256(data).hexdigest()
    import numpy as np
    packages = {}
    for name in ("torch", "mpmath", "psutil"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    return {"freeze_commit": commit, "implementations": pinned,
            "environment": {"python": sys.version, "numpy": np.__version__,
                            "platform": platform.platform(), "processor": platform.processor(),
                            "packages": packages, "thread_environment": {
                                key: os.environ.get(key) for key in
                                ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")}}}


def save_once(path, value):
    path = Path(path)
    text = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if path.exists():
        if json.loads(path.read_text(encoding="utf-8")) != value:
            raise RuntimeError(f"STOP: existing evidence differs: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(text, encoding="utf-8", newline="\n")
    temp.replace(path)
