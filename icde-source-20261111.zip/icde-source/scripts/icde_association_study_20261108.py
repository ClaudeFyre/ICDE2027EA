"""Frozen bounded response to parameter-association research-priority revision."""
import argparse
from collections import Counter,defaultdict
from fractions import Fraction as Q
import math
from pathlib import Path
import time

import numpy as np

import icde_prospective_20261107 as old
from icde_grouped_inventory_20261108 import ROOT,load,save,sha,identities
from icde_grouped_exact_20261108 import compile_counts,solve_counts
from icde_parameter_association_20261108 import pointwise_population,audit_masks
from icde_alignment_signal_20261108 import diagnose
from run_vldb_interval_gate_v1 import clipped_box

BASE=ROOT/'nodes/09_vldb_query_certification/results/icde_parameter_association_20261108/attempt1'
INVENTORY=ROOT/'nodes/09_vldb_query_certification/results/icde_grouped_query_20261108/inventory_attempt1'
PARENT=ROOT/'nodes/09_vldb_query_certification/results/icde_portfolio_headroom_20261108/attempt1'


def freeze(out):
    if out.exists():raise FileExistsError(out)
    inv=load(INVENTORY/'inventory.json')
    parent=load(PARENT/'protocol.json')
    code=dict(parent['code_sha256'])
    for name in ('icde_parameter_association_20261108.py','test_icde_parameter_association_20261108.py',
                 'icde_alignment_signal_20261108.py','test_icde_alignment_signal_20261108.py',
                 'icde_association_study_20261108.py'):
        code['scripts/'+name]=sha(ROOT/'scripts'/name)
    inputs=dict(load(INVENTORY/'protocol.json')['input_sha256'])
    for path in (INVENTORY/'inventory.json',INVENTORY/'protocol.json',PARENT/'summary.json',
                 ROOT/'nodes/09_vldb_query_certification/results/icde_refinable_g1_20261107/attempt1/summary.json'):
        inputs[path.relative_to(ROOT).as_posix()]=sha(path)
    for graph in ('dw','enfr'):
        for name in ('triples.tsv','alignments.tsv'):
            path=old.DATA/graph/name
            inputs[path.relative_to(ROOT).as_posix()]=sha(path)
    cases=[]
    for path in sorted((old.BASE/'confirmation').glob('primary_*/summary.json')):
        inputs[path.relative_to(ROOT).as_posix()]=sha(path)
        for row in load(path)['rows']:
            if row['policy']=='eager':
                cases.append({**row,'run_summary':path.relative_to(ROOT).as_posix()})
                if sha(ROOT/row['case'])!=row['case_sha256']:
                    raise AssertionError('historical eager artifact changed')
                inputs[row['case']]=row['case_sha256']
    if len(cases)!=1536 or len(inv['rows'])!=576:
        raise AssertionError('historical matrix selection changed')
    save(out/'protocol.json',{
        'kind':'historical_exact_quantifier_gap_census_static_exclusion_and_alignment_signal',
        'all_cases':inv['rows'],'eligible_queries':148,'historical_eager_cases':cases,
        'nominal':.9,'tau':.25,'state_cap':32768,
        'quantifier_endpoint':'all 148 prototype_eligible; exact optimal pointwise directional population gaps under original uniform coupling, compared with exact whole-box truth',
        'shortcut':'all high endpoints exactly 1; count suffix winner union weighted by fixed-one Binomial(low), exact rational arithmetic',
        'no_novelty_inference':'negative population gap separates this pointwise sufficient condition, not every abstract Monte Carlo or credal-circuit method',
        'static_endpoint':'all 576 queries; reconstruct incidence signatures from original edge IDs and original triples; distinguish trivial singletons, resource filters, skipped static census; not a hardness classification',
        'signal_endpoint':'all 512 historical confirmation query IDs x old 3 seeds, eager only; fixed answer is old MC leader, expected-score fallback only when no sample',
        'signal_features':['signed_expected_margin','retained_softmax','mc_frequency','log_candidates','log_worlds','is_enfr'],
        'signal_added_feature':'raw robust certified flag; prediction itself held fixed between models',
        'signal_protocol':'five source-hash folds, all seeds of same source together; train-only standardization; ridge logistic sum-loss penalty=1, no tuning; baseline vs +stability',
        'signal_metrics':['OOF Brier','OOF logloss','OOF AURC','AUROC','risk-coverage; score ties averaged'],
        'signal_uncertainty':'1000 paired source bootstrap reps stratified by graph, fixed OOF fits; descriptive only; graph dependence and refitting uncertainty not covered',
        'no_new_confirmation':'all inputs historical and now development; no new random worlds or scorer training',
        'code_sha256':code,'input_sha256':inputs,'frozen_at_unix':time.time()})
    print('Frozen: 148 exact mechanism queries; 576 static diagnoses; 1536 historical query-seed signal cases',flush=True)


def preflight(out):
    p=load(out/'protocol.json')
    checks=identities(p,False)
    if (out/'summary.json').exists() or (out/'mechanisms').exists():
        raise ValueError('new attempt needed for existing outputs')
    save(out/'recovery.json',{'status':'PASS','checks':checks,
        'scope':'all consumed source/input byte hashes; inherited prepared-artifact CRC audits; no whole-workspace scan'})
    print(f'Preflight PASS {checks}',flush=True)


def original_graph(graph):
    triples=old.tsv(old.DATA/graph/'triples.tsv')
    edges=[(r['head_id'],r['tail_id']) for r in triples]
    degrees=defaultdict(lambda:[0,0])
    for head,tail in edges:
        degrees[head][0]+=1;degrees[tail][1]+=1
    truth={r['source_entity_id']:r['target_entity_id'] for r in old.tsv(old.DATA/graph/'alignments.tsv') if r['split']=='test'}
    return edges,degrees,truth


def static_and_scores(case,edges,degrees):
    path=old.BASE/'prepared'/case['graph']/f"q{case['rank']:03d}.npz"
    meta=load(path.with_suffix('.json'))
    if sha(path)!=meta['kernel_sha256']:raise AssertionError('prepared arrays changed')
    with np.load(path,allow_pickle=False) as arrays:
        active_edges=arrays['edges'].copy()
        attribute,lexical=arrays['attribute'].copy(),arrays['lexical'].copy()
    relevant=(meta['query_id'],)+tuple(meta['candidates'])
    coordinates={entity:2*i for i,entity in enumerate(relevant)}
    groups=Counter()
    for e in active_edges:
        head,tail=edges[int(e)]
        signature=[]
        if head in coordinates:signature.append(coordinates[head])
        if tail in coordinates:signature.append(coordinates[tail]+1)
        if not signature:raise AssertionError('scope edge invisible to every degree')
        groups[tuple(sorted(signature))]+=1
    sizes=[groups[sig] for sig in sorted(groups)]
    if case['inventory_status']=='grouped' and sizes!=case['group_sizes']:
        raise AssertionError('original graph reconstruction differs from frozen incidence census')
    k,m=case['retained_candidates'],case['scope_edges']
    if (len(attribute),len(active_edges))!=(k,m):raise AssertionError('prepared shape changed')
    logstates=sum(math.log2(n+1) for n in sizes)
    states=math.prod(n+1 for n in sizes) if logstates<4096 else None
    logwork=math.log2(k)+logstates+math.log2(sum(n+1 for n in sizes))
    failures=[]
    if k>8:failures.append('candidate_cap_gt8')
    if m>96:failures.append('scope_cap_gt96')
    if states is None or states>32768:failures.append('count_state_cap_gt32768')
    if states is None or k*states*sum(n+1 for n in sizes)>2000000:failures.append('tensor_arithmetic_cap_gt2000000')
    eligible=k>1 and not failures
    if eligible!=case['prototype_eligible']:raise AssertionError('eligibility reconstruction changed')
    row={**case,'reconstructed_group_count':len(sizes),'reconstructed_count_state_log2':logstates,
         'count_states_exact':states,'estimated_total_tensor_work_log2':logwork,
         'resource_filters_failed':failures,'group_size_histogram':dict(Counter(sizes)),
         'diagnostic_category':'trivial_single_candidate' if k==1 else ('eligible_competitive' if eligible else 'outside_prototype_resource_limits'),
         'census_extension':'new structural census' if case['inventory_status']=='outside_frozen_static_limits' else 'matches prior static census'}
    source=np.asarray(degrees[meta['query_id']],dtype=float)*.9
    target=np.asarray([degrees[c] for c in meta['candidates']],dtype=float)*.9
    distance=np.abs(target-source[None,:]).sum(axis=1)
    score=.8*attribute+(1.-.8)*(.6*lexical+.4*(1./(1.+distance)))
    return row,meta,score


def run(out):
    p=load(out/'protocol.json')
    if load(out/'recovery.json')['status']!='PASS':raise AssertionError('missing preflight')
    checks=identities(p,False);started=time.perf_counter()
    static=[];metadata={};scores={};truth={}
    for graph in ('dw','enfr'):
        edges,degrees,gold=original_graph(graph)
        for case in [r for r in p['all_cases'] if r['graph']==graph]:
            row,meta,score=static_and_scores(case,edges,degrees)
            key=graph,case['rank'];static.append(row);metadata[key]=meta;scores[key]=score
            truth[key]=gold[meta['query_id']]
            checks+=3
        print(f'Static reconstruction completed {graph}',flush=True)
    static_summary={'queries':len(static),'categories':dict(Counter(r['diagnostic_category'] for r in static)),
        'excluded_resource_overlap':dict(Counter(f for r in static if r['retained_candidates']>1 and not r['prototype_eligible'] for f in r['resource_filters_failed'])),
        'excluded_filter_combinations':dict(Counter('|'.join(r['resource_filters_failed']) for r in static if r['retained_candidates']>1 and not r['prototype_eligible'])),
        'rows':static,'warning':'resource exclusions are not infeasibility or hardness proofs; same scorer class throughout'}
    save(out/'static_diagnosis.json',static_summary)
    mechanisms=[]
    previous={(r['graph'],r['rank']):r for r in load(PARENT/'summary.json')['references']}
    for index,case in enumerate(r for r in p['all_cases'] if r['prototype_eligible']):
        key=case['graph'],case['rank'];kernel,meta=old.read_query(*key)
        low,high=clipped_box(np.full(case['scope_edges'],p['nominal']),p['tau'])
        before=time.perf_counter()
        compiled=compile_counts(kernel,low,high,p['state_cap'])
        exact=solve_counts(compiled,len(kernel.candidates))
        directional,masks=pointwise_population(compiled,exact,len(kernel.candidates))
        checks+=audit_masks(compiled,masks)
        if exact['uniform_winners']!=previous[key]['uniform_winners']:
            raise AssertionError('exact reference changed')
        true_min=[min(Q(r['minimum_gap_exact']) for r in exact['pairs'] if r['candidate']==w) for w in range(len(kernel.candidates))]
        if any(Q(g)>t for g,t in zip(directional['minimum_gaps_exact'],true_min)):
            raise AssertionError('pointwise lower gap exceeds true robust gap')
        safe=exact['uniform_winners']
        if any(w not in safe for w in directional['pointwise_certifiable_winners']):
            raise AssertionError('pointwise condition wrongly certifies')
        row={**case,'uniform_winners':safe,'true_minimum_gaps_exact':list(map(str,true_min)),
             'true_minimum_gaps':list(map(float,true_min)),**directional,
             'quantifier_omission':bool(safe) and not directional['pointwise_certifiable_winners'],
             'compute_seconds':time.perf_counter()-before}
        save(out/'mechanisms'/f"{case['graph']}_q{case['rank']:03d}.json",row)
        mechanisms.append(row);checks+=3
        if (index+1)%25==0:print(f'Exact mechanism census {index+1}/148',flush=True)
    mechanism_summary={}
    for name,keep in [('all',lambda r:True),('dw',lambda r:r['graph']=='dw'),('enfr',lambda r:r['graph']=='enfr'),
                      ('scope_ge20',lambda r:r['scope_edges']>=20)]:
        subset=[r for r in mechanisms if keep(r)]
        robust=sum(bool(r['uniform_winners']) for r in subset)
        omission=sum(r['quantifier_omission'] for r in subset)
        mechanism_summary[name]={'queries':len(subset),'robust_queries':robust,'pointwise_omissions':omission,
            'fraction_of_all':omission/len(subset),'fraction_of_robust':omission/robust if robust else None}
    save(out/'quantifier_census.json',{'summary':mechanism_summary,'rows':mechanisms})
    signal_rows=[]
    for case in p['historical_eager_cases']:
        raw=load(ROOT/case['case']);key=case['graph'],case['rank'];meta=metadata[key];score=scores[key]
        counts=raw['winner_counts'];k=len(counts);n=raw['worlds']
        if sum(counts)!=n or k!=len(score):raise AssertionError('MC prefix shape mismatch')
        chosen=int(np.argmax(counts)) if n else int(np.argmax(score))
        if k==1:
            margin=1.;softmax=1.;frequency=1.
        else:
            competing=score.copy();competing[chosen]=-np.inf
            margin=float(score[chosen]-np.max(competing))
            softmax=float(np.exp(score[chosen]-np.max(score))/np.exp(score-np.max(score)).sum())
            frequency=counts[chosen]/n if n else 0.
        candidate=meta['candidates'][chosen]
        if raw['certified'] and raw['candidate']!=candidate:
            raise AssertionError('certificate and fixed answer differ')
        signal_rows.append({'graph':key[0],'rank':key[1],'query_id':meta['query_id'],'seed':case['seed'],
            'prediction':candidate,'correct':candidate==truth[key],'truth_retained':truth[key] in meta['candidates'],
            'retained_candidates':k,'stable':bool(raw['certified']),
            'delivered_within_old_budget':case['delivered_within_budget'],'no_mc_evidence':n==0 and k>1,
            'features':{'signed_expected_margin':margin,'retained_softmax':softmax,'mc_frequency':frequency,
                        'log_candidates':math.log1p(k),'log_worlds':math.log1p(n),'is_enfr':float(key[0]=='enfr')}})
        checks+=2
    signal=diagnose(signal_rows,1000)
    save(out/'alignment_signal.json',signal)
    checks+=identities(p,False)
    save(out/'summary.json',{'status':'PASS','protocol_sha256':sha(out/'protocol.json'),'checks':checks,
         'mechanism_summary':mechanism_summary,'static_categories':static_summary['categories'],
         'signal_differences':signal['differences'],'elapsed_seconds':time.perf_counter()-started,
         'outputs_sha256':{name:sha(out/name) for name in ('quantifier_census.json','static_diagnosis.json','alignment_signal.json')},
         'historical_sources_unchanged':True,'new_random_worlds':0,'new_prospective_queries':0})
    print({'status':'PASS','mechanism':mechanism_summary,'static':static_summary['categories'],
           'signal':signal['differences']},flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=('freeze','preflight','run'),required=True)
    parser.add_argument('--output',type=Path,default=BASE)
    args=parser.parse_args()
    {'freeze':freeze,'preflight':preflight,'run':run}[args.phase](args.output.resolve())
