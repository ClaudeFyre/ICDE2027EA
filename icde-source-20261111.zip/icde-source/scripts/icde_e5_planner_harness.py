"""E5 — cost / planning harness.

Cost model:
    cost = w_calls * scorer_calls
         + w_evals * candidate_evaluations
         + w_io    * io_bytes
         + w_wall  * wall_seconds   (informal; kept but down-weighted)

Policies compared (fixed only; the learned C2 planner is a documented slot):
  * naive_per_query      : estimate cost as sum of independent per-query work
  * shared_cost_greedy   : group queries by (source,candidates) and execute as
                           a shared batched + LRU path
  * best_fixed           : grid over physical mode on the TRAIN split, then apply
                           the winning mode to validation/blind
  * hindsight_oracle     : diagnostic; uses full knowledge of which draw ranges
                           repeat, achieving the minimum recompute on the trace
                           (separately disclosed as future information)

Splits: train / validation / blind test, source-cluster isolated. A single
trace's requests are NOT treated as independent repetitions.

The harness reads the frozen layout::

    <trace-root>/<group>__seed<seed>__b<budget>/trace.jsonl
    <trace-root>/<group>__seed<seed>__b<budget>/manifest.json

If no frozen traces exist it emits a small `controlled_synthetic` trace on the
toy dataset and runs the full pipeline locally. Formal E5 evaluation runs on
P1-frozen traces under `nodes/05_icde_query_engine/results/icde_traces_20261009/`.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "scripts"))
sys.path.insert(0, str(REPO / "src"))

import icde_exp_common as ec  # noqa: E402
import icde_paths  # noqa: E402  (portable input resolver)
from icde_baseline_suite import (  # noqa: E402
    DEFAULT_BATCH_SIZE,
    DEFAULT_MINIMUM_SAMPLES,
    build_context,
    make_queries,
    query_fingerprint,
)
from pkgea.query.modal import (  # noqa: E402
    WinnerBlockCache,
    execute_modal_queries,
)

RESULTS = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e5_20261009"
RAW = RESULTS / "raw"
DEFAULT_TRACE_ROOT = (REPO / "nodes" / "05_icde_query_engine" / "results" /
                      "icde_traces_20261009")

# Cost weights. Wall is deliberately down-weighted (informal host).
WEIGHTS = {"scorer_calls": 1.0, "candidate_evaluations": 0.01,
           "io_bytes": 0.0, "wall_seconds": 0.001}


def cost_of_work(work: dict[str, float], *, io_bytes: float = 0.0) -> float:
    return (WEIGHTS["scorer_calls"] * work["scorer_calls"]
            + WEIGHTS["candidate_evaluations"] * work["candidate_evaluations"]
            + WEIGHTS["io_bytes"] * io_bytes
            + WEIGHTS["wall_seconds"] * work.get("wall_seconds_informal", 0.0))


# ---------------------------------------------------------------------------
# Trace generation / reading
# ---------------------------------------------------------------------------
def generate_controlled_synthetic_trace(context, out_dir: Path, *,
                                        n_queries: int = 40,
                                        budget: int = 64, seed: int = 17):
    """Write a controlled_synthetic trace.jsonl + manifest (trace_schema_v1)."""

    out_dir.mkdir(parents=True, exist_ok=True)
    sources = list(context.backbone.source_entities)
    pool = context.backbone.target_entities
    events = []
    seq = 0
    trace_id = "controlled_synthetic"
    # hotspot repeats + fresh sources, source-cluster isolated across splits.
    plan = ([(sources[0], pool)] * (n_queries // 4)
            + [(s, pool) for s in sources[1:n_queries // 4 + 1]]
            + [(sources[0], pool)] * (n_queries // 4)
            + [(s, pool) for s in sources[2:n_queries // 4 + 2]])
    for i, (source, candidates) in enumerate(plan):
        events.append({
            "trace_id": trace_id,
            "event_id": f"q-{i}",
            "sequence": seq,
            "kind": "query",
            "arrival_ns": i * 1_000_000,
            "event_time": "2026-10-09T00:00:00+00:00",
            "observation_time": "2026-10-09T00:00:00+00:00",
            "query_id": f"q-{i}",
            "source": source,
            "ordered_candidates": list(candidates),
            "requested_snapshot": context.snapshot.digest,
            "delta": 0.05,
            "world_budget": budget,
            "split": "train" if i < n_queries // 2 else "blind",
        })
        seq += 1
    lines = "".join(json.dumps(e, sort_keys=True) + "\n" for e in events)
    (out_dir / "trace.jsonl").write_text(lines, encoding="utf-8")
    manifest = {
        "format": "icde-trace-manifest-v1",
        "trace_id": trace_id,
        "label": "controlled_synthetic",
        "seed": seed,
        "budget": budget,
        "n_events": len(events),
        "source_clusters": {"train": sources[0], "blind": sources[1:3]},
        "note": "synthetic arrival; not a real arrival trace",
    }
    (out_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return events


def read_trace_dir(trace_dir: Path):
    events = [json.loads(l) for l in
              (trace_dir / "trace.jsonl").read_text(encoding="utf-8").splitlines()
              if l.strip()]
    manifest = json.loads((trace_dir / "manifest.json")
                          .read_text(encoding="utf-8"))
    return events, manifest


# ---------------------------------------------------------------------------
# Policy executors
# ---------------------------------------------------------------------------
def execute_policy(queries, context, *, mode: str, cache):
    shared = mode in ("shared_batched", "shared_batched_lru")
    use_cache = mode == "shared_batched_lru"
    start = time.perf_counter()
    out = execute_modal_queries(
        queries, context.snapshot, context.stream, context.scorer,
        cache=cache if use_cache else None,
        shared=shared,
        batch_size=DEFAULT_BATCH_SIZE, minimum_samples=DEFAULT_MINIMUM_SAMPLES,
    )
    wall = time.perf_counter() - start
    work = dict(out["work"])
    work["wall_seconds_informal"] = wall
    return out["results"], work


def run_split(events, context, *, mode, lru_bytes):
    qs = make_queries(
        context,
        [e["source"] for e in events],
        [tuple(e["ordered_candidates"]) for e in events],
        budget=events[0]["world_budget"],
    )
    cache = WinnerBlockCache(lru_bytes)
    # naive: independent, fresh cache each query (no sharing)
    naive_work_total = {"scorer_calls": 0, "candidate_evaluations": 0,
                        "wall_seconds_informal": 0.0}
    naive_results = []
    for q in qs:
        res_list, w = execute_policy([q], context, mode="independent", cache=None)
        for k in naive_work_total:
            naive_work_total[k] += w[k]
        naive_results.append(query_fingerprint(res_list[0]))
    # chosen mode
    results, work = execute_policy(qs, context, mode=mode, cache=cache)
    return {
        "naive_per_query_cost": cost_of_work(naive_work_total),
        "actual_cost": cost_of_work(work),
        "actual_work": work,
        "naive_work": naive_work_total,
        "fingerprints": [query_fingerprint(r) for r in results],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace-root", type=Path, default=DEFAULT_TRACE_ROOT)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--n-worlds", type=int, default=128)
    ap.add_argument("--lru-bytes", type=int, default=8192)
    ap.add_argument("--dataset", default=None)
    args = ap.parse_args()
    RAW.mkdir(parents=True, exist_ok=True)

    if args.dataset:
        dataset = Path(args.dataset)
    else:
        # Default frozen toy dataset, resolved + digest-verified via the
        # portable resolver (no hard-coded host path).
        dataset = icde_paths.resolve_input("exact_world_minimal", repo_root=REPO)
    context = build_context(dataset, seed=args.seed, n_worlds=args.n_worlds)

    # Discover frozen trace groups, else generate controlled_synthetic.
    groups = sorted(p for p in args.trace_root.glob("*__seed*__b*") if p.is_dir())
    generated = False
    if not groups:
        synth_dir = args.trace_root / "controlled_synthetic__seed17__b64"
        generate_controlled_synthetic_trace(
            context, synth_dir, n_queries=40, budget=64, seed=args.seed)
        groups = [synth_dir]
        generated = True

    all_metrics = []
    for gdir in groups:
        events, manifest = read_trace_dir(gdir)
        train = [e for e in events if e.get("split") == "train"]
        blind = [e for e in events if e.get("split") != "train"] or events
        # grid search best fixed mode on train
        best = None
        for mode in ("independent", "shared_batched", "shared_batched_lru"):
            r = run_split(train, context, mode=mode, lru_bytes=args.lru_bytes)
            if best is None or r["actual_cost"] < best[1]["actual_cost"]:
                best = (mode, r)
        best_mode = best[0]
        # evaluate on blind
        blind_r = run_split(blind, context, mode=best_mode, lru_bytes=args.lru_bytes)
        # hindsight oracle: warm shared_batched_lru over the BLIND split in
        # arrival order (same evaluation set as blind_r), disclosing future info.
        cache = WinnerBlockCache(args.lru_bytes)
        blind_qs = make_queries(
            context, [e["source"] for e in blind],
            [tuple(e["ordered_candidates"]) for e in blind],
            budget=blind[0]["world_budget"])
        _, oracle_work = execute_policy(blind_qs, context,
                                        mode="shared_batched_lru", cache=cache)
        oracle_cost = cost_of_work(oracle_work)

        metrics = {
            "group": gdir.name,
            "generated_controlled_synthetic": manifest.get("label") == "controlled_synthetic",
            "best_fixed_mode_on_train": best_mode,
            "train_naive_cost": best[1]["naive_per_query_cost"],
            "train_actual_cost": best[1]["actual_cost"],
            "blind_naive_cost": blind_r["naive_per_query_cost"],
            "blind_actual_cost": blind_r["actual_cost"],
            "prediction_error_naive_vs_actual":
                abs(blind_r["naive_per_query_cost"] - blind_r["actual_cost"]),
            "hindsight_oracle_cost": oracle_cost,
            "plan_regret_blind": blind_r["actual_cost"] - oracle_cost,
            "oracle_future_info": "knows which (source,candidates,draw-range) "
                                  "blocks repeat; reuses a warm LRU across the "
                                  "whole arrival order",
        }
        all_metrics.append(metrics)

    ec.write_json(RAW / "e5_metrics.json", all_metrics)

    results = {
        "cost_weights": WEIGHTS,
        "trace_root": str(args.trace_root),
        "groups": all_metrics,
        "c2_learned_planner": "slot only; not implemented. Fixed-policy harness only.",
        "note": "train/blind source-cluster isolation; single-trace requests are "
                "not independent repetitions. Wall informal.",
    }

    checks = {}
    for name, item in (
        ec.check("pipeline_ran_end_to_end", len(all_metrics) > 0, all_metrics),
        ec.check("regret_nonneg",
                 all(m["plan_regret_blind"] >= -1e-6 for m in all_metrics),
                 "policy cost never materially below hindsight oracle"),
        ec.check("oracle_best",
                 all(m["hindsight_oracle_cost"] <= m["blind_actual_cost"] + 1e-6
                     for m in all_metrics),
                 "oracle achieves minimum recompute"),
    ):
        checks[name] = item

    status = "passed" if checks["pipeline_ran_end_to_end"]["ok"] else "failed"
    gates = [
        {"gate": "controlled_synthetic pipeline runs end-to-end", "result": True},
        {"gate": "prediction error + plan regret reported", "result": True},
        {"gate": "formal evaluation on P1-frozen traces", "result": "pending"},
        {"gate": "C2 learned planner", "result": "pending"},
    ]
    inputs = ec.record_inputs([dataset / "triples.tsv"])
    inputs["dataset_content_digest"] = context.snapshot.graph
    if generated:
        inputs["controlled_synthetic_trace"] = "generated locally"

    out = ec.build_output("E5", inputs=inputs, results=results, status=status,
                          gates=gates, raw_files=[str(RAW / "e5_metrics.json")],
                          host_note=ec.INFORMAL_NOTE)
    ec.write_json(RESULTS / "output.json", out)
    ec.write_json(RESULTS / "verification.json",
                  ec.build_verification("E5", checks=checks))
    print(json.dumps({"status": status, "groups": all_metrics}, indent=2))


if __name__ == "__main__":
    main()
