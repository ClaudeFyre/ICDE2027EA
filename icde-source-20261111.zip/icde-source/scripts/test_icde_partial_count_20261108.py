"""Independent region coverage, probability and complete-reference checks."""
from dataclasses import replace
from fractions import Fraction as Q
from itertools import product
import unittest
import numpy as np

from icde_partial_count_20261108 import CountOracle, execute
from icde_grouped_exact_20261108 import compile_counts, solve_counts
from test_icde_grouped_exact_20261108 import kernel


def competing():
    model = kernel(3)
    return replace(model, attribute=np.zeros(3), lexical=np.zeros(3))


class PartialTests(unittest.TestCase):
    def test_outward_region_masks_contain_every_exact_winner(self):
        model = competing()
        low,high = np.zeros(6),np.ones(6)
        oracle = CountOracle(model,low,high)
        full = compile_counts(model,low,high)
        rng = np.random.default_rng(919)
        for _ in range(64):
            a,b = [],[]
            for n in oracle.shape:
                x,y = sorted(map(int,rng.integers(0,n,2)))
                a.append(x)
                b.append(y)
            possible = oracle.possible(tuple(a),tuple(b))
            for state in product(*(range(x,y+1) for x,y in zip(a,b))):
                self.assertTrue(possible & (1 << int(full["winners"][state])))

    def test_exact_rectangle_probability_partition_and_maximum(self):
        model = competing()
        oracle = CountOracle(model,np.full(6,.25),np.full(6,.75))
        oracle.prepare_probabilities()
        a,b = (0,)*len(oracle.shape),tuple(n-1 for n in oracle.shape)
        parent,maximum = oracle.mass(a,b)
        self.assertTrue(all(int(v)==oracle.denominator for v in parent.flat))
        left_hi,right_lo = list(b),list(a)
        left_hi[0] = 0
        right_lo[0] = 1
        left,lmax = oracle.mass(a,tuple(left_hi))
        right,rmax = oracle.mass(tuple(right_lo),b)
        self.assertTrue(np.array_equal(left+right,parent))
        self.assertEqual(lmax,max(map(int,left.flat)))
        self.assertEqual(rmax,max(map(int,right.flat)))

    def test_full_refinement_matches_complete_tensor_and_witnesses(self):
        model = competing()
        low,high = np.full(6,.25),np.full(6,.75)
        compiled = compile_counts(model,low,high)
        exact = solve_counts(compiled,3)
        for policy in ("standard_mass","certificate"):
            result = execute(model,low,high,policy,{"state_cap":32768,"max_splits":1000})
            expected = "stable" if exact["uniform_winners"] else "nonuniform"
            self.assertEqual(result["status"],expected)
            coverage = np.zeros(compiled["shape"],dtype=np.int64)
            for leaf in result["leaf_records"]:
                sl = tuple(slice(a,b+1) for a,b in zip(leaf["low"],leaf["high"]))
                coverage[sl] += 1
                true = compiled["winners"][sl]
                self.assertTrue(all(leaf["mask"] & (1 << int(w)) for w in true.flat))
            self.assertTrue(np.all(coverage==1))
            for proof in result["witnesses"]:
                point = tuple(proof["high_endpoint_counts"])
                actual = int(exact["numerators"][proof["candidate"]][point])-int(exact["numerators"][proof["competitor"]][point])
                self.assertLessEqual(actual,int(proof["upper_gap_numerator"]))
                self.assertLessEqual(int(proof["upper_gap_numerator"]),0)

    def test_zero_budget_keeps_unknown_mass(self):
        model = competing()
        result = execute(model,np.zeros(6),np.ones(6),"certificate",{"state_cap":32768,"max_splits":0})
        self.assertEqual(result["status"],"unresolved")
        self.assertEqual(result["splits"],0)
        self.assertEqual(result["point_score_states"],0)
        self.assertEqual(result["unresolved_count_state_volume"],result["count_states"])

    def test_representation_budget_precedes_probability_allocation(self):
        with self.assertRaises(ValueError):
            CountOracle(competing(),np.zeros(6),np.ones(6),state_cap=1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
