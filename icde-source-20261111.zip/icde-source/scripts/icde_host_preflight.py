"""Record the target host before any ICDE measurement; CPU pilot is GPU-free."""

import argparse
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--require-4090", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("use a fresh preflight output")
    packages = {}
    for name in ("numpy", "pytest", "torch", "pkgea"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    cuda = {"available": False, "devices": []}
    try:
        import torch

        cuda.update(
            {
                "torch_cuda_build": torch.version.cuda,
                "available": torch.cuda.is_available(),
                "torch_cpu_threads": torch.get_num_threads(),
            }
        )
        if cuda["available"]:
            cuda["devices"] = [
                {
                    "index": i,
                    "name": torch.cuda.get_device_name(i),
                    "vram_bytes": torch.cuda.get_device_properties(i).total_memory,
                }
                for i in range(torch.cuda.device_count())
            ]
    except ImportError:
        cuda["torch_status"] = "not_installed"
    except (OSError, RuntimeError) as error:
        cuda["error"] = str(error)
    driver = None
    try:
        driver = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    payload = {
        "format": "icde-host-preflight-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "python": sys.version,
        "logical_cpus": os.cpu_count(),
        "packages": packages,
        "thread_environment": {
            k: os.environ.get(k)
            for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")
        },
        "cuda": cuda,
        "nvidia_smi": driver,
        "measurement_ready": False,
        "remaining_inventory": [
            "physical CPU/NUMA",
            "RAM",
            "storage/NVMe",
            "background CPU",
            "exclusive resource budget",
            "page-cache protocol",
        ],
        "boundary": "Inventory only; no benchmark and no formal measurement authorization.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n")
    print(
        json.dumps(
            {"platform": payload["platform"], "cuda": cuda, "output": str(args.output)}, indent=2
        )
    )
    if args.require_4090 and not any("4090" in d["name"] for d in cuda["devices"]):
        raise SystemExit("CUDA-visible 4090 family device required for this preflight")


if __name__ == "__main__":
    main()
