"""WWW moment-propagation validation against exact possible worlds."""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from pkgea.distributional import (
    GaussianMoments,
    aggregate_bernoulli_messages,
    diagonal_bhattacharyya,
    diagonal_wasserstein_squared,
    propagate_relu_network,
    symmetric_diagonal_kl,
)
from pkgea.samplers import exact_worlds, monte_carlo_worlds


def _hash_hidden_vector(token: str, dimension: int) -> np.ndarray:
    vector = np.empty(dimension, dtype=np.float64)
    for index in range(dimension):
        digest = hashlib.sha256(
            f"{token}|{index}".encode("utf-8")
        ).digest()
        vector[index] = 1.0 if digest[0] & 1 else -1.0
    return vector / math.sqrt(dimension)


def run_toy_moment_validation(dataset_dir: str | Path) -> dict[str, object]:
    root = Path(dataset_dir).resolve()
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    messages = [
        (1.0, 0.0) if row["graph_id"] == "source" else (0.0, 1.0)
        for row in triples
    ]
    analytic = aggregate_bernoulli_messages(messages, probabilities)

    exact_mean = [0.0, 0.0]
    exact_second = [[0.0, 0.0], [0.0, 0.0]]
    for world in exact_worlds(probabilities):
        total = [
            sum(message[coordinate] for active, message in zip(world.state, messages, strict=True) if active)
            for coordinate in range(2)
        ]
        for coordinate in range(2):
            exact_mean[coordinate] += world.weight * total[coordinate]
        for row in range(2):
            for column in range(2):
                exact_second[row][column] += (
                    world.weight * total[row] * total[column]
                )
    exact_covariance = [
        [
            exact_second[row][column] - exact_mean[row] * exact_mean[column]
            for column in range(2)
        ]
        for row in range(2)
    ]
    mean_error = max(
        abs(left - right) for left, right in zip(analytic.mean, exact_mean, strict=True)
    )
    covariance_error = max(
        abs(analytic.covariance[row][column] - exact_covariance[row][column])
        for row in range(2)
        for column in range(2)
    )
    return {
        "analytic_mean": list(analytic.mean),
        "exact_mean": exact_mean,
        "analytic_covariance": [list(row) for row in analytic.covariance],
        "exact_covariance": exact_covariance,
        "max_mean_error": mean_error,
        "max_covariance_error": covariance_error,
        "analytic_edge_passes": len(triples),
        "exact_edge_passes": len(triples) * (2 ** len(triples)),
    }


def _relu_layer(
    vector: list[float],
    weights: list[list[float]],
    bias: list[float],
) -> list[float]:
    return [
        max(
            sum(weight * value for weight, value in zip(row, vector, strict=True))
            + bias[index],
            0.0,
        )
        for index, row in enumerate(weights)
    ]


def run_toy_multilayer_validation(dataset_dir: str | Path) -> dict[str, object]:
    """Compare two nonlinear moment-matching layers with exact possible worlds."""

    root = Path(dataset_dir).resolve()
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    messages = [
        (1.0, 0.25) if row["graph_id"] == "source" else (0.25, 1.0)
        for row in triples
    ]
    layer_specs = [
        ([[0.8, -0.4], [0.3, 0.7], [-0.5, 0.6]], [0.1, -0.2, 0.05]),
        ([[0.6, -0.2, 0.5], [-0.3, 0.9, 0.2]], [-0.1, 0.15]),
    ]
    initial = aggregate_bernoulli_messages(messages, probabilities)
    analytic_layers = propagate_relu_network(initial, layer_specs)

    exact_values: list[list[tuple[float, list[float]]]] = [
        [] for _ in layer_specs
    ]
    for world in exact_worlds(probabilities):
        vector = [
            sum(
                message[coordinate]
                for active, message in zip(world.state, messages, strict=True)
                if active
            )
            for coordinate in range(2)
        ]
        for layer_index, (weights, bias) in enumerate(layer_specs):
            vector = _relu_layer(vector, weights, bias)
            exact_values[layer_index].append((world.weight, vector))

    layers: list[dict[str, object]] = []
    for layer_index, (analytic, weighted_values) in enumerate(
        zip(analytic_layers, exact_values, strict=True),
        start=1,
    ):
        dimension = len(analytic.mean)
        exact_mean = [
            sum(weight * value[index] for weight, value in weighted_values)
            for index in range(dimension)
        ]
        exact_variance = [
            sum(
                weight * (value[index] - exact_mean[index]) ** 2
                for weight, value in weighted_values
            )
            for index in range(dimension)
        ]
        layers.append(
            {
                "layer": layer_index,
                "analytic_mean": list(analytic.mean),
                "exact_mean": exact_mean,
                "analytic_variance": list(analytic.variance),
                "exact_variance": exact_variance,
                "max_mean_error": max(
                    abs(left - right)
                    for left, right in zip(
                        analytic.mean, exact_mean, strict=True
                    )
                ),
                "max_variance_error": max(
                    abs(left - right)
                    for left, right in zip(
                        analytic.variance, exact_variance, strict=True
                    )
                ),
            }
        )
    return {
        "layers": layers,
        "approximation": (
            "Gaussian moment matching with diagonal covariance after ReLU"
        ),
        "world_count": 2 ** len(triples),
        "analytic_edge_passes": len(triples),
        "exact_edge_passes": len(triples) * (2 ** len(triples)),
    }


def run_real_distributional_validation(
    dataset_dir: str | Path,
    *,
    sample_count: int = 4096,
    seed: int = 17,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Validate analytic entity degree moments and distribution matching."""

    if sample_count <= 1:
        raise ValueError("sample_count must be greater than one")
    root = Path(dataset_dir).resolve()
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (root / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    metadata = json.loads(
        (root / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    probabilities = [float(row["confidence"]) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    dependence = metadata.get("edge_dependence", {})
    rho = (
        float(metadata.get("generation", {}).get("shared_strength", 0.0))
        if dependence.get("assumption") == "grouped_shared_latent"
        and any(groups)
        else 0.0
    )
    query_entities = tuple(
        dict.fromkeys(
            [
                *(row["source_entity_id"] for row in alignments),
                *(row["target_entity_id"] for row in alignments),
            ]
        )
    )
    analytic: dict[str, GaussianMoments] = {}
    analytic_edge_passes = 0
    for entity in query_entities:
        edge_indices = [
            index
            for index, row in enumerate(triples)
            if row["head_id"] == entity or row["tail_id"] == entity
        ]
        messages = [
            (
                float(triples[index]["head_id"] == entity),
                float(triples[index]["tail_id"] == entity),
            )
            for index in edge_indices
        ]
        analytic_edge_passes += len(edge_indices)
        analytic[entity] = (
            aggregate_bernoulli_messages(
                messages,
                [probabilities[index] for index in edge_indices],
                dependency_groups=[groups[index] for index in edge_indices],
                common_shock_probability=rho,
            )
            if edge_indices
            else GaussianMoments(
                mean=(0.0, 0.0),
                covariance=((0.0, 0.0), (0.0, 0.0)),
            )
        )

    worlds = monte_carlo_worlds(
        probabilities,
        sample_count,
        seed,
        dependency_groups=groups,
        common_shock_probability=rho,
    )
    entity_index = {
        entity: position for position, entity in enumerate(query_entities)
    }
    sums = [[0.0, 0.0] for _ in query_entities]
    squares = [[0.0, 0.0] for _ in query_entities]
    for world in worlds:
        degrees = [[0.0, 0.0] for _ in query_entities]
        for active, row in zip(world.state, triples, strict=True):
            if not active:
                continue
            if row["head_id"] in entity_index:
                degrees[entity_index[row["head_id"]]][0] += 1.0
            if row["tail_id"] in entity_index:
                degrees[entity_index[row["tail_id"]]][1] += 1.0
        for index, degree in enumerate(degrees):
            for coordinate in range(2):
                sums[index][coordinate] += degree[coordinate]
                squares[index][coordinate] += degree[coordinate] ** 2
    empirical = {}
    for index, entity in enumerate(query_entities):
        mean = tuple(value / sample_count for value in sums[index])
        variance = tuple(
            squares[index][coordinate] / sample_count - mean[coordinate] ** 2
            for coordinate in range(2)
        )
        empirical[entity] = GaussianMoments(
            mean=mean,
            covariance=(
                (max(variance[0], 0.0), 0.0),
                (0.0, max(variance[1], 0.0)),
            ),
        )

    source_entities = tuple(
        dict.fromkeys(row["source_entity_id"] for row in alignments)
    )
    target_entities = tuple(
        dict.fromkeys(row["target_entity_id"] for row in alignments)
    )
    truth = {
        row["source_entity_id"]: row["target_entity_id"]
        for row in alignments
    }
    distances = {
        "wasserstein": diagonal_wasserstein_squared,
        "symmetric_kl": symmetric_diagonal_kl,
        "bhattacharyya": diagonal_bhattacharyya,
    }
    matching = {}
    for name, distance in distances.items():
        analytic_winners = {}
        empirical_winners = {}
        for source in source_entities:
            analytic_winners[source] = min(
                target_entities,
                key=lambda target: (
                    distance(analytic[source], analytic[target]),
                    target,
                ),
            )
            empirical_winners[source] = min(
                target_entities,
                key=lambda target: (
                    distance(empirical[source], empirical[target]),
                    target,
                ),
            )
        matching[name] = {
            "analytic_top1_accuracy": sum(
                analytic_winners[source] == truth[source]
                for source in source_entities
            )
            / len(source_entities),
            "empirical_top1_accuracy": sum(
                empirical_winners[source] == truth[source]
                for source in source_entities
            )
            / len(source_entities),
            "analytic_empirical_winner_agreement": sum(
                analytic_winners[source] == empirical_winners[source]
                for source in source_entities
            )
            / len(source_entities),
        }
    result = {
        "dataset_dir": str(root),
        "sample_count": sample_count,
        "seed": seed,
        "edge_dependence_assumption": dependence.get(
            "assumption", "unspecified"
        ),
        "common_shock_probability": rho,
        "entity_count": len(query_entities),
        "max_mean_error": max(
            abs(
                analytic[entity].mean[coordinate]
                - empirical[entity].mean[coordinate]
            )
            for entity in query_entities
            for coordinate in range(2)
        ),
        "max_variance_error": max(
            abs(
                analytic[entity].variance[coordinate]
                - empirical[entity].variance[coordinate]
            )
            for entity in query_entities
            for coordinate in range(2)
        ),
        "matching": matching,
        "complexity": {
            "analytic_incident_edge_passes": analytic_edge_passes,
            "mc_sampled_edge_evaluations": sample_count * len(triples),
            "edge_count": len(triples),
        },
        "representation": "two-dimensional random out-degree/in-degree moments",
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def run_hidden_representation_validation(
    dataset_dir: str | Path,
    *,
    sample_count: int = 2048,
    seed: int = 17,
    dimension: int = 16,
    depth: int = 3,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Validate nonlinear moments of relation/attribute hidden representations."""

    if sample_count <= 1:
        raise ValueError("sample_count must be greater than one")
    if dimension <= 1:
        raise ValueError("dimension must be greater than one")
    if not 1 <= depth <= 8:
        raise ValueError("depth must be in [1, 8]")
    root = Path(dataset_dir).resolve()
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (root / "relations.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        relations = list(csv.DictReader(handle, delimiter="\t"))
    with (root / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    metadata = json.loads(
        (root / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    probabilities = [float(row["confidence"]) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    dependence = metadata.get("edge_dependence", {})
    rho = (
        float(metadata.get("generation", {}).get("shared_strength", 0.0))
        if dependence.get("assumption") == "grouped_shared_latent"
        and any(groups)
        else 0.0
    )
    source_entities = tuple(
        dict.fromkeys(row["source_entity_id"] for row in alignments)
    )
    target_entities = tuple(
        dict.fromkeys(row["target_entity_id"] for row in alignments)
    )
    query_entities = (*source_entities, *target_entities)
    entity_index = {
        entity: index for index, entity in enumerate(query_entities)
    }
    truth = {
        row["source_entity_id"]: row["target_entity_id"]
        for row in alignments
    }
    relation_labels = {
        row["relation_id"]: row["label"].casefold() for row in relations
    }
    relation_vectors = {
        relation_id: _hash_hidden_vector(label, dimension)
        for relation_id, label in relation_labels.items()
    }

    static = np.zeros(
        (len(query_entities), dimension), dtype=np.float64
    )
    attribute_counts = np.zeros(len(query_entities), dtype=np.int64)
    attribute_path = root / "attributes.tsv"
    if attribute_path.is_file():
        with attribute_path.open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            for row in csv.DictReader(handle, delimiter="\t"):
                index = entity_index.get(row["entity_id"])
                if index is None:
                    continue
                static[index] += _hash_hidden_vector(
                    f"{row['attribute_id']}={row['value'].casefold()}",
                    dimension,
                )
                attribute_counts[index] += 1
    for index, count in enumerate(attribute_counts):
        if count:
            static[index] *= 0.25 / math.sqrt(float(count))

    incident: list[list[tuple[int, np.ndarray]]] = [
        [] for _ in query_entities
    ]
    for edge_index, triple in enumerate(triples):
        vector = relation_vectors[triple["relation_id"]]
        head_index = entity_index.get(triple["head_id"])
        tail_index = entity_index.get(triple["tail_id"])
        if head_index is not None:
            incident[head_index].append((edge_index, vector))
        if tail_index is not None:
            incident[tail_index].append((edge_index, -vector))

    initial_moments = []
    analytic_edge_passes = 0
    zero_covariance = tuple(
        tuple(0.0 for _ in range(dimension))
        for _ in range(dimension)
    )
    for entity_position, items in enumerate(incident):
        if not items:
            initial_moments.append(
                GaussianMoments(
                    tuple(float(value) for value in static[entity_position]),
                    zero_covariance,
                )
            )
            continue
        edge_indices = [item[0] for item in items]
        analytic_edge_passes += len(edge_indices)
        moments = aggregate_bernoulli_messages(
            [item[1] for item in items],
            [probabilities[index] for index in edge_indices],
            dependency_groups=[groups[index] for index in edge_indices],
            common_shock_probability=rho,
        )
        initial_moments.append(
            GaussianMoments(
                tuple(
                    moments.mean[coordinate]
                    + float(static[entity_position, coordinate])
                    for coordinate in range(dimension)
                ),
                moments.covariance,
            )
        )

    rng = np.random.default_rng(991)
    layer_specs = []
    for layer_index in range(depth):
        weights = rng.normal(
            0.0, 1.0 / math.sqrt(dimension), (dimension, dimension)
        )
        # A small deterministic bias creates nontrivial ReLU truncation.
        bias = rng.normal(0.0, 0.05, dimension)
        layer_specs.append((weights, bias))
    analytic_by_depth: list[list[GaussianMoments]] = [
        initial_moments
    ]
    current = initial_moments
    for weights, bias in layer_specs:
        current = [
            propagate_relu_network(
                moments,
                ((weights.tolist(), bias.tolist()),),
            )[0]
            for moments in current
        ]
        analytic_by_depth.append(current)

    worlds = monte_carlo_worlds(
        probabilities,
        sample_count,
        seed,
        dependency_groups=groups,
        common_shock_probability=rho,
    )
    sums = [
        np.zeros((len(query_entities), dimension), dtype=np.float64)
        for _ in range(depth + 1)
    ]
    squares = [np.zeros_like(array) for array in sums]
    for world in worlds:
        hidden = static.copy()
        for entity_position, items in enumerate(incident):
            for edge_index, message in items:
                if world.state[edge_index]:
                    hidden[entity_position] += message
        sums[0] += hidden
        squares[0] += hidden * hidden
        for layer_index, (weights, bias) in enumerate(layer_specs, start=1):
            hidden = np.maximum(hidden @ weights.T + bias, 0.0)
            sums[layer_index] += hidden
            squares[layer_index] += hidden * hidden

    empirical_by_depth = []
    for layer_index in range(depth + 1):
        mean = sums[layer_index] / sample_count
        variance = np.maximum(
            squares[layer_index] / sample_count - mean * mean, 0.0
        )
        empirical_by_depth.append(
            [
                GaussianMoments(
                    tuple(float(value) for value in mean[entity_position]),
                    tuple(
                        tuple(
                            float(variance[entity_position, row])
                            if row == column
                            else 0.0
                            for column in range(dimension)
                        )
                        for row in range(dimension)
                    ),
                )
                for entity_position in range(len(query_entities))
            ]
        )

    layers = []
    for layer_index in range(depth + 1):
        analytic = analytic_by_depth[layer_index]
        empirical = empirical_by_depth[layer_index]
        mean_errors = [
            analytic[entity].mean[coordinate]
            - empirical[entity].mean[coordinate]
            for entity in range(len(query_entities))
            for coordinate in range(dimension)
        ]
        variance_errors = [
            analytic[entity].variance[coordinate]
            - empirical[entity].variance[coordinate]
            for entity in range(len(query_entities))
            for coordinate in range(dimension)
        ]

        def winners(moments: list[GaussianMoments]) -> dict[str, str]:
            return {
                source: min(
                    target_entities,
                    key=lambda target: (
                        diagonal_wasserstein_squared(
                            moments[entity_index[source]],
                            moments[entity_index[target]],
                        ),
                        target,
                    ),
                )
                for source in source_entities
            }

        analytic_winners = winners(analytic)
        empirical_winners = winners(empirical)
        layers.append(
            {
                "depth": layer_index,
                "max_absolute_mean_error": max(
                    abs(value) for value in mean_errors
                ),
                "mean_rmse": math.sqrt(
                    sum(value * value for value in mean_errors)
                    / len(mean_errors)
                ),
                "max_absolute_variance_error": max(
                    abs(value) for value in variance_errors
                ),
                "variance_rmse": math.sqrt(
                    sum(value * value for value in variance_errors)
                    / len(variance_errors)
                ),
                "analytic_top1_accuracy": sum(
                    analytic_winners[source] == truth[source]
                    for source in source_entities
                )
                / len(source_entities),
                "empirical_top1_accuracy": sum(
                    empirical_winners[source] == truth[source]
                    for source in source_entities
                )
                / len(source_entities),
                "winner_agreement": sum(
                    analytic_winners[source]
                    == empirical_winners[source]
                    for source in source_entities
                )
                / len(source_entities),
            }
        )
    entropy = sum(
        -(
            probability * math.log2(probability)
            + (1.0 - probability) * math.log2(1.0 - probability)
        )
        if 0.0 < probability < 1.0
        else 0.0
        for probability in probabilities
    ) / len(probabilities)
    result = {
        "dataset_dir": str(root),
        "sample_count": sample_count,
        "seed": seed,
        "dimension": dimension,
        "maximum_depth": depth,
        "mean_binary_entropy": entropy,
        "edge_dependence_assumption": dependence.get(
            "assumption", "unspecified"
        ),
        "common_shock_probability": rho,
        "query_entity_count": len(query_entities),
        "entities_with_attributes": int(np.count_nonzero(attribute_counts)),
        "layers": layers,
        "complexity": {
            "analytic_incident_edge_passes": analytic_edge_passes,
            "mc_sampled_edge_evaluations": sample_count * len(triples),
            "edge_count": len(triples),
        },
        "representation": (
            "signed relation-direction hash messages plus deterministic "
            "attribute hash vector; fixed dense ReLU layers"
        ),
        "approximation": (
            "full covariance before layer 1; diagonal Gaussian moment "
            "matching after every ReLU"
        ),
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result
