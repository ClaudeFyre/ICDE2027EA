"""Variance-guided local world allocation for the WSDM prototype."""

from __future__ import annotations

import math
import statistics
from collections import defaultdict
from dataclasses import dataclass
from typing import Callable, Hashable, Mapping, Sequence

from pkgea.samplers.core import WorldSample, monte_carlo_worlds


Candidate = tuple[Hashable, Hashable]
ScoreFunction = Callable[
    [Hashable, tuple[bool, ...]],
    Mapping[Candidate, float],
]


@dataclass(frozen=True)
class AdaptiveSamplingConfig:
    total_budget: int = 1024
    pilot_samples_per_source: int = 16
    minimum_samples_per_source: int = 16
    batch_size: int = 8
    delta: float = 0.05
    common_shock_probability: float = 0.0
    enable_early_stopping: bool = True

    def validate(self, source_count: int) -> None:
        minimum = max(self.pilot_samples_per_source, self.minimum_samples_per_source)
        if source_count <= 0:
            raise ValueError("At least one source is required")
        if self.total_budget < source_count * minimum:
            raise ValueError(
                "total_budget is smaller than the required per-source minimum"
            )
        if self.batch_size <= 0:
            raise ValueError("batch_size must be positive")
        if not 0.0 < self.delta < 1.0:
            raise ValueError("delta must be in (0, 1)")


@dataclass(frozen=True)
class SourceSamplingResult:
    source: Hashable
    allocated_worlds: int
    used_worlds: int
    sampled_edges: int
    stopped_early: bool
    winner: Hashable
    winner_probability: float
    runner_up_probability: float
    pilot_margin_variance: float
    sampled_edge_indices: tuple[int, ...]
    candidate_win_probabilities: tuple[tuple[Hashable, float], ...]


@dataclass(frozen=True)
class AdaptiveSamplingResult:
    sources: tuple[SourceSamplingResult, ...]
    total_allocated_worlds: int
    total_used_worlds: int
    total_sampled_edges: int

    def as_dict(self) -> dict[str, object]:
        return {
            "sources": [
                {
                    "source": str(item.source),
                    "allocated_worlds": item.allocated_worlds,
                    "used_worlds": item.used_worlds,
                    "sampled_edges": item.sampled_edges,
                    "stopped_early": item.stopped_early,
                    "winner": str(item.winner),
                    "winner_probability": item.winner_probability,
                    "runner_up_probability": item.runner_up_probability,
                    "pilot_margin_variance": item.pilot_margin_variance,
                    "sampled_edge_indices": list(item.sampled_edge_indices),
                    "candidate_win_probabilities": {
                        str(candidate): probability
                        for candidate, probability in item.candidate_win_probabilities
                    },
                }
                for item in self.sources
            ],
            "total_allocated_worlds": self.total_allocated_worlds,
            "total_used_worlds": self.total_used_worlds,
            "total_sampled_edges": self.total_sampled_edges,
        }


def _candidate_scores(
    source: Hashable,
    candidates: Sequence[Hashable],
    world: WorldSample,
    score_function: ScoreFunction,
) -> list[tuple[Hashable, float]]:
    scores = score_function(source, world.state)
    return sorted(
        ((candidate, scores[(source, candidate)]) for candidate in candidates),
        key=lambda item: (-item[1], str(item[0])),
    )


def _pilot_variance(
    source: Hashable,
    candidates: Sequence[Hashable],
    worlds: Sequence[WorldSample],
    score_function: ScoreFunction,
) -> float:
    margins = []
    for world in worlds:
        ordered = _candidate_scores(source, candidates, world, score_function)
        if len(ordered) < 2:
            margins.append(ordered[0][1] if ordered else 0.0)
        else:
            margins.append(ordered[0][1] - ordered[1][1])
    return statistics.variance(margins) if len(margins) > 1 else 0.0


def _allocate_budget(
    variances: Mapping[Hashable, float],
    total_budget: int,
    minimum_per_source: int,
) -> dict[Hashable, int]:
    sources = list(variances)
    allocations = {source: minimum_per_source for source in sources}
    remaining = total_budget - minimum_per_source * len(sources)
    if remaining <= 0:
        return allocations
    weights = {source: math.sqrt(max(variance, 0.0)) + 1e-9 for source, variance in variances.items()}
    total_weight = sum(weights.values())
    fractional = {
        source: remaining * weights[source] / total_weight for source in sources
    }
    for source in sources:
        allocations[source] += int(fractional[source])
    leftovers = total_budget - sum(allocations.values())
    for source in sorted(
        sources,
        key=lambda item: fractional[item] - int(fractional[item]),
        reverse=True,
    )[:leftovers]:
        allocations[source] += 1
    return allocations


def adaptive_local_sampling(
    probabilities: Sequence[float],
    score_function: ScoreFunction,
    candidates_by_source: Mapping[Hashable, Sequence[Hashable]],
    local_edges_by_source: Mapping[Hashable, set[int]],
    config: AdaptiveSamplingConfig,
    *,
    seed: int = 17,
    dependency_groups: Sequence[str] | None = None,
) -> AdaptiveSamplingResult:
    """Allocate worlds by pilot margin variance and stop stable sources early."""

    sources = tuple(candidates_by_source)
    config.validate(len(sources))
    if set(sources) != set(local_edges_by_source):
        raise ValueError("local_edges_by_source must contain exactly the source keys")

    minimum = max(config.pilot_samples_per_source, config.minimum_samples_per_source)
    pilots: dict[Hashable, list[WorldSample]] = {}
    variances: dict[Hashable, float] = {}
    for index, source in enumerate(sources):
        pilots[source] = monte_carlo_worlds(
            probabilities,
            config.pilot_samples_per_source,
            seed + 1009 * (index + 1),
            dependency_groups=dependency_groups,
            common_shock_probability=config.common_shock_probability,
            local_edge_indices=local_edges_by_source[source],
        )
        variances[source] = _pilot_variance(
            source,
            candidates_by_source[source],
            pilots[source],
            score_function,
        )

    allocations = _allocate_budget(variances, config.total_budget, minimum)
    results: list[SourceSamplingResult] = []
    for index, source in enumerate(sources):
        allocation = allocations[source]
        worlds = list(pilots[source])
        additional = allocation - len(worlds)
        if additional > 0:
            worlds.extend(
                monte_carlo_worlds(
                    probabilities,
                    additional,
                    seed + 7919 * (index + 1),
                    dependency_groups=dependency_groups,
                    common_shock_probability=config.common_shock_probability,
                    local_edge_indices=local_edges_by_source[source],
                )
            )

        wins: defaultdict[Hashable, int] = defaultdict(int)
        used = 0
        stopped = False
        for world in worlds:
            ordered = _candidate_scores(
                source, candidates_by_source[source], world, score_function
            )
            if not ordered:
                raise ValueError(f"Source {source!r} has no candidates")
            wins[ordered[0][0]] += 1
            used += 1
            if (
                not config.enable_early_stopping
                or used < minimum
                or used % config.batch_size
            ):
                continue
            ranked_wins = sorted(
                wins.items(), key=lambda item: (-item[1], str(item[0]))
            )
            leader_count = ranked_wins[0][1]
            runner_count = ranked_wins[1][1] if len(ranked_wins) > 1 else 0
            radius = math.sqrt(math.log(2.0 / config.delta) / (2.0 * used))
            if (leader_count - runner_count) / used > 2.0 * radius:
                stopped = True
                break

        ranked_wins = sorted(wins.items(), key=lambda item: (-item[1], str(item[0])))
        winner, winner_count = ranked_wins[0]
        runner_count = ranked_wins[1][1] if len(ranked_wins) > 1 else 0
        results.append(
            SourceSamplingResult(
                source=source,
                allocated_worlds=allocation,
                used_worlds=used,
                sampled_edges=used * len(local_edges_by_source[source]),
                stopped_early=stopped and used < allocation,
                winner=winner,
                winner_probability=winner_count / used,
                runner_up_probability=runner_count / used,
                pilot_margin_variance=variances[source],
                sampled_edge_indices=tuple(
                    sorted(local_edges_by_source[source])
                ),
                candidate_win_probabilities=tuple(
                    (
                        candidate,
                        wins.get(candidate, 0) / used,
                    )
                    for candidate in candidates_by_source[source]
                ),
            )
        )

    return AdaptiveSamplingResult(
        sources=tuple(results),
        total_allocated_worlds=sum(item.allocated_worlds for item in results),
        total_used_worlds=sum(item.used_worlds for item in results),
        total_sampled_edges=sum(item.sampled_edges for item in results),
    )
