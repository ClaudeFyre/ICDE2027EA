"""Shared-factor (common-shock) factor law for possible-world generation.

The grouped-edge common-shock sampler already lives in
:func:`pkgea.samplers.core.monte_carlo_worlds`: edges that share a dependency
group and fire a per-world common shock draw a *shared* uniform, so their joint
law is genuinely correlated instead of a product of independent Bernoullis.

What was missing after the P1 review was the glue that binds that sampler knob
to the rest of the identity machinery:

* a named, hashable factor law whose **identity string** is exactly the value
  bound into the ``ModalSnapshot.factors`` field (so a factor-law change yields a
  *new* snapshot digest and old state is refused, not just a relabelled reuse);
* a world-generation call that *actually uses* the law (so the joint law really
  changes, rather than the string changing while the independent MC keeps
  running);
* an optional fragment bound into the ``IIDWorldStream`` digest.

Backward compatibility is deliberate: the trivial (no-group) law must produce the
byte-identical ``"independent"`` factors string and a byte-identical stream digest,
so the frozen v1 traces and the existing regression suite keep replaying.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Sequence

from pkgea.samplers.core import monte_carlo_worlds


def _canonical_identity(payload: object) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class FactorLaw:
    """A shared-factor law over the edges of one graph.

    ``dependency_groups`` has one entry per edge; an empty string means the edge
    takes its own independent Bernoulli draw. Edges with the same non-empty
    group label share a per-world common shock: with probability
    ``common_shock_probability`` a single uniform drives every edge in the group,
    otherwise the edges draw independently.
    """

    dependency_groups: tuple[str, ...]
    common_shock_probability: float

    def __post_init__(self) -> None:
        if not isinstance(self.dependency_groups, tuple) or not self.dependency_groups:
            raise ValueError("dependency_groups must be a nonempty tuple of per-edge labels")
        for group in self.dependency_groups:
            if not isinstance(group, str):
                raise ValueError("dependency group labels must be strings")
        if not 0.0 <= self.common_shock_probability <= 1.0:
            raise ValueError("common_shock_probability must lie in [0, 1]")

    @staticmethod
    def independent(n_edges: int) -> "FactorLaw":
        """The v1 product law: every edge independent, no shared shock."""

        if n_edges <= 0:
            raise ValueError("n_edges must be positive")
        return FactorLaw(("",) * n_edges, 0.0)

    @property
    def n_edges(self) -> int:
        return len(self.dependency_groups)

    @property
    def is_independent(self) -> bool:
        """True when the law reduces to the v1 independent product law."""

        return self.common_shock_probability == 0.0 or not any(self.dependency_groups)

    def identity(self) -> str:
        """Canonical string bound into ``ModalSnapshot.factors``.

        The trivial law returns the literal ``"independent"`` so frozen v1
        snapshot digests are byte-identical. Any non-trivial shared-factor law
        returns a distinct, content-addressed string, so changing the factor law
        changes the snapshot digest and refuses reuse of old observations.
        """

        if self.is_independent:
            return "independent"
        return "factor-law-v1:" + _canonical_identity({
            "dependency_groups": list(self.dependency_groups),
            "common_shock_probability": self.common_shock_probability,
        })

    def build_worlds(self, probabilities: Sequence[float], sample_count: int, seed: int):
        """Sample worlds under this law (returns ``WorldSample`` list).

        For the independent law this is the exact v1 call (no grouped-shock
        kwargs), so bit-for-bit reproducibility of the frozen traces is kept.
        """

        probs = tuple(float(p) for p in probabilities)
        if len(probs) != self.n_edges:
            raise ValueError("probability length must match the factor-law edge count")
        if self.is_independent:
            return monte_carlo_worlds(probs, sample_count, seed)
        return monte_carlo_worlds(
            probs,
            sample_count,
            seed,
            dependency_groups=self.dependency_groups,
            common_shock_probability=self.common_shock_probability,
        )

    def stream_config(self) -> tuple:
        """Opaque identity fragment bound into the stream digest.

        Empty tuple for the independent law (so the v1 stream digest is
        unchanged); otherwise the serialized grouped-shock parameters, so two
        streams with the same seed but a different factor law have different
        digests and old blocks are structurally unreadable.
        """

        if self.is_independent:
            return ()
        return ("factor-law-v1", self.dependency_groups,
                float(self.common_shock_probability))
