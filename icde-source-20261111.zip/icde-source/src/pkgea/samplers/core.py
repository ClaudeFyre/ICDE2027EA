"""Possible-world samplers shared by the WSDM and ICDE nodes."""

from __future__ import annotations

import itertools
import math
import random
from dataclasses import dataclass
from typing import Iterable, Sequence


@dataclass(frozen=True)
class WorldSample:
    state: tuple[bool, ...]
    weight: float
    sampled_edge_count: int
    origin: str


def _validate_probabilities(probabilities: Sequence[float]) -> None:
    if not probabilities:
        raise ValueError("At least one edge probability is required")
    for probability in probabilities:
        if not 0.0 <= probability <= 1.0:
            raise ValueError(f"Probability outside [0, 1]: {probability}")


def normalize_weights(worlds: Iterable[WorldSample]) -> list[WorldSample]:
    materialized = list(worlds)
    total = sum(world.weight for world in materialized)
    if total <= 0:
        raise ValueError("World weights must have positive total mass")
    return [
        WorldSample(
            state=world.state,
            weight=world.weight / total,
            sampled_edge_count=world.sampled_edge_count,
            origin=world.origin,
        )
        for world in materialized
    ]


def exact_worlds(
    probabilities: Sequence[float], max_uncertain_edges: int = 20
) -> list[WorldSample]:
    """S0: enumerate independent Bernoulli worlds."""

    _validate_probabilities(probabilities)
    if len(probabilities) > max_uncertain_edges:
        raise ValueError(
            f"Refusing to enumerate 2^{len(probabilities)} worlds; "
            f"limit is {max_uncertain_edges}"
        )
    worlds: list[WorldSample] = []
    for bits in itertools.product((False, True), repeat=len(probabilities)):
        mass = math.prod(
            probability if active else 1.0 - probability
            for active, probability in zip(bits, probabilities, strict=True)
        )
        worlds.append(
            WorldSample(
                state=bits,
                weight=mass,
                sampled_edge_count=len(probabilities),
                origin="S0_exact",
            )
        )
    return worlds


def monte_carlo_worlds(
    probabilities: Sequence[float],
    sample_count: int,
    seed: int,
    *,
    dependency_groups: Sequence[str] | None = None,
    common_shock_probability: float = 0.0,
    local_edge_indices: set[int] | None = None,
) -> list[WorldSample]:
    """S1/S2/S4 sampler.

    Grouped edges preserve their Bernoulli marginals: with probability ``rho``
    a group shares a uniform draw, otherwise each edge draws independently.
    S4 local mode samples selected edges and plugs in the median world
    (``p >= 0.5``) for the rest. This is exact only for a scorer certified not to
    read the unselected edges; otherwise it is an approximation. Shared latent
    draws are keyed by dependency group, so selected edges preserve their joint
    group distribution even when another member of the group is out of scope.
    """

    _validate_probabilities(probabilities)
    if sample_count <= 0:
        raise ValueError("sample_count must be positive")
    if not 0.0 <= common_shock_probability <= 1.0:
        raise ValueError("common_shock_probability must be in [0, 1]")
    groups = tuple(dependency_groups or ("",) * len(probabilities))
    if len(groups) != len(probabilities):
        raise ValueError("dependency_groups length must match probabilities")
    selected = (
        set(range(len(probabilities)))
        if local_edge_indices is None
        else local_edge_indices
    )
    if any(index < 0 or index >= len(probabilities) for index in selected):
        raise ValueError("local_edge_indices contains an invalid index")

    rng = random.Random(seed)
    worlds: list[WorldSample] = []
    for _ in range(sample_count):
        group_uniforms: dict[str, float] = {}
        group_uses_shock: dict[str, bool] = {}
        state: list[bool] = []
        for index, (probability, group) in enumerate(
            zip(probabilities, groups, strict=True)
        ):
            if index not in selected:
                state.append(probability >= 0.5)
                continue
            use_shock = bool(group) and group_uses_shock.setdefault(
                group, rng.random() < common_shock_probability
            )
            uniform = (
                group_uniforms.setdefault(group, rng.random())
                if use_shock
                else rng.random()
            )
            state.append(uniform < probability)
        worlds.append(
            WorldSample(
                state=tuple(state),
                weight=1.0 / sample_count,
                sampled_edge_count=len(selected),
                origin="S4_local" if local_edge_indices is not None else "S1_MC",
            )
        )
    return worlds


def stratified_worlds(
    probabilities: Sequence[float], sample_count: int, seed: int
) -> list[WorldSample]:
    """S3: Latin-hypercube marginal stratification."""

    _validate_probabilities(probabilities)
    if sample_count <= 0:
        raise ValueError("sample_count must be positive")
    rng = random.Random(seed)
    columns: list[list[float]] = []
    for _ in probabilities:
        uniforms = [(index + rng.random()) / sample_count for index in range(sample_count)]
        rng.shuffle(uniforms)
        columns.append(uniforms)
    return [
        WorldSample(
            state=tuple(
                columns[edge][sample] < probabilities[edge]
                for edge in range(len(probabilities))
            ),
            weight=1.0 / sample_count,
            sampled_edge_count=len(probabilities),
            origin="S3_stratified",
        )
        for sample in range(sample_count)
    ]


def importance_worlds(
    probabilities: Sequence[float],
    proposal_probabilities: Sequence[float],
    sample_count: int,
    seed: int,
) -> list[WorldSample]:
    """S3: self-normalized importance sampling with a factorized proposal."""

    _validate_probabilities(probabilities)
    _validate_probabilities(proposal_probabilities)
    if len(probabilities) != len(proposal_probabilities):
        raise ValueError("Proposal length must match probabilities")
    if any(probability in {0.0, 1.0} for probability in proposal_probabilities):
        raise ValueError("Proposal probabilities must be strictly inside (0, 1)")
    rng = random.Random(seed)
    worlds: list[WorldSample] = []
    for _ in range(sample_count):
        state = tuple(rng.random() < proposal for proposal in proposal_probabilities)
        target_mass = math.prod(
            probability if active else 1.0 - probability
            for active, probability in zip(state, probabilities, strict=True)
        )
        proposal_mass = math.prod(
            proposal if active else 1.0 - proposal
            for active, proposal in zip(
                state, proposal_probabilities, strict=True
            )
        )
        worlds.append(
            WorldSample(
                state=state,
                weight=target_mass / proposal_mass,
                sampled_edge_count=len(probabilities),
                origin="S3_importance",
            )
        )
    return normalize_weights(worlds)


def representative_worlds(
    probabilities: Sequence[float],
    representative_count: int,
    candidate_count: int,
    seed: int,
) -> list[WorldSample]:
    """S5: weighted medoids selected from an MC candidate pool.

    This is an engineering baseline, not a claim of a novel coreset method.
    """

    if representative_count <= 0 or candidate_count < representative_count:
        raise ValueError("Require 0 < representative_count <= candidate_count")
    candidates = monte_carlo_worlds(probabilities, candidate_count, seed)
    unique_states = list(dict.fromkeys(world.state for world in candidates))
    if len(unique_states) <= representative_count:
        mass = 1.0 / len(unique_states)
        return [
            WorldSample(state, mass, len(probabilities), "S5_representative")
            for state in unique_states
        ]

    def distance(left: tuple[bool, ...], right: tuple[bool, ...]) -> int:
        return sum(a != b for a, b in zip(left, right, strict=True))

    selected = [unique_states[0]]
    while len(selected) < representative_count:
        next_state = max(
            (state for state in unique_states if state not in selected),
            key=lambda state: min(distance(state, chosen) for chosen in selected),
        )
        selected.append(next_state)

    cluster_counts = [0] * len(selected)
    for candidate in candidates:
        nearest = min(
            range(len(selected)),
            key=lambda index: distance(candidate.state, selected[index]),
        )
        cluster_counts[nearest] += 1
    return [
        WorldSample(
            state=state,
            weight=count / candidate_count,
            sampled_edge_count=len(probabilities),
            origin="S5_representative",
        )
        for state, count in zip(selected, cluster_counts, strict=True)
        if count
    ]
