"""WSDM prototype runner over the canonical toy dataset."""

from __future__ import annotations

import csv
import json
import time
from pathlib import Path

from pkgea.backbones import AttributeStructuralBackbone, ToyStructuralBackbone
from pkgea.query import StaticCandidateIndex
from pkgea.samplers import AdaptiveSamplingConfig, adaptive_local_sampling


def run_toy_adaptive_sampling(
    dataset_dir: str | Path,
    *,
    total_budget: int = 192,
    seed: int = 17,
    backbone_name: str = "toy",
    early_stopping: bool = True,
    evaluation_split: str | None = None,
    candidate_top_k: int | None = None,
    measure_latency: bool = False,
) -> dict[str, object]:
    root = Path(dataset_dir).resolve()
    if backbone_name == "toy":
        backbone = ToyStructuralBackbone.from_dataset(root)
    elif backbone_name == "attribute":
        backbone = AttributeStructuralBackbone.from_dataset(root)
    else:
        raise ValueError(f"Unsupported backbone: {backbone_name}")
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (root / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    metadata = json.loads(
        (root / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    dependence = metadata.get("edge_dependence", {})
    generation = metadata.get("generation", {})
    common_shock_probability = 0.0
    if (
        dependence.get("assumption") == "grouped_shared_latent"
        and any(groups)
    ):
        common_shock_probability = float(
            generation.get("shared_strength", 0.0)
        )

    if evaluation_split is None:
        evaluated_sources = backbone.source_entities
        evaluation_alignments = alignments
    else:
        evaluation_alignments = [
            row for row in alignments if row["split"] == evaluation_split
        ]
        if not evaluation_alignments:
            raise ValueError(
                f"No alignments found for evaluation split: {evaluation_split}"
            )
        evaluated_sources = tuple(
            dict.fromkeys(
                row["source_entity_id"] for row in evaluation_alignments
            )
        )
    candidate_selections = {}
    if candidate_top_k is not None:
        if not isinstance(backbone, AttributeStructuralBackbone):
            raise ValueError("candidate pruning requires the attribute backbone")
        if not 0 < candidate_top_k <= len(backbone.target_entities):
            raise ValueError("candidate_top_k must be within the candidate scope")
        static_index = StaticCandidateIndex.from_attribute_backbone(backbone)
        candidate_selections = {
            source: static_index.select(source, candidate_top_k)
            for source in evaluated_sources
        }
    candidates = {
        source: (
            candidate_selections[source].candidates
            if source in candidate_selections
            else backbone.target_entities
        )
        for source in evaluated_sources
    }
    incident_edges: dict[str, set[int]] = {}
    for edge_index, triple in enumerate(triples):
        incident_edges.setdefault(triple["head_id"], set()).add(edge_index)
        incident_edges.setdefault(triple["tail_id"], set()).add(edge_index)
    local_edges: dict[str, set[int]] = {}
    candidate_local_subgraphs: dict[str, list[dict[str, object]]] = {}
    for source in evaluated_sources:
        source_edges = incident_edges.get(source, set())
        candidate_subgraphs = []
        relevant = set(source_edges)
        for candidate in candidates[source]:
            target_edges = incident_edges.get(candidate, set())
            pair_edges = tuple(sorted(source_edges | target_edges))
            relevant.update(target_edges)
            candidate_subgraphs.append(
                {
                    "candidate": candidate,
                    "edge_count": len(pair_edges),
                    "edge_indices": list(pair_edges),
                }
            )
        # Degree-based scores depend only on edges incident to the source and
        # retained candidates. Candidate-independent target edges are excluded.
        local_edges[source] = relevant
        candidate_local_subgraphs[source] = candidate_subgraphs

    score_function = (
        lambda source, state: backbone.score_subset(
            state,
            (source,),
            candidates[source],
        )
    )
    started = time.perf_counter()
    result = adaptive_local_sampling(
        probabilities,
        score_function,
        candidates,
        local_edges,
        AdaptiveSamplingConfig(
            total_budget=total_budget,
            pilot_samples_per_source=16,
            minimum_samples_per_source=16,
            batch_size=8,
            delta=0.05,
            common_shock_probability=common_shock_probability,
            enable_early_stopping=early_stopping,
        ),
        seed=seed,
        dependency_groups=groups,
    )
    elapsed_seconds = time.perf_counter() - started
    report = result.as_dict()
    ground_truth = {
        row["source_entity_id"]: row["target_entity_id"]
        for row in evaluation_alignments
    }
    correct = sum(
        ground_truth.get(str(item.source)) == str(item.winner)
        for item in result.sources
    )
    ranks = []
    retained_truth = 0
    for item in result.sources:
        truth = ground_truth.get(str(item.source))
        probabilities_by_candidate = dict(item.candidate_win_probabilities)
        if truth not in probabilities_by_candidate:
            ranks.append(len(backbone.target_entities) + 1)
            continue
        retained_truth += 1
        ordered = sorted(
            probabilities_by_candidate,
            key=lambda candidate: (
                -probabilities_by_candidate[candidate], str(candidate)
            ),
        )
        ranks.append(ordered.index(truth) + 1)
    report.update(
        {
            "backbone": backbone_name,
            "early_stopping": early_stopping,
            "evaluation_split": evaluation_split,
            "edge_dependence_assumption": dependence.get(
                "assumption", "unspecified"
            ),
            "common_shock_probability": common_shock_probability,
            "correct_winners": correct,
            "ground_truth_top1_accuracy": correct / len(result.sources),
            "ranking_metrics": {
                "hits_at_1": sum(rank <= 1 for rank in ranks) / len(ranks),
                "hits_at_3": sum(rank <= 3 for rank in ranks) / len(ranks),
                "hits_at_10": sum(rank <= 10 for rank in ranks) / len(ranks),
                "mrr": sum(1.0 / rank for rank in ranks) / len(ranks),
                "truth_retained_rate": retained_truth / len(ranks),
                "rank_semantics": "ranking by estimated candidate winner probability",
            },
            "early_stopped_sources": sum(
                item.stopped_early for item in result.sources
            ),
            "full_graph_sampled_edge_baseline": (
                result.total_used_worlds * len(probabilities)
            ),
            "local_edge_fraction": (
                result.total_sampled_edges
                / (result.total_used_worlds * len(probabilities))
            ),
            "candidate_local_subgraphs": candidate_local_subgraphs,
            "candidate_pruning": {
                "enabled": candidate_top_k is not None,
                "requested_top_k": candidate_top_k,
                "original_candidates_per_source": len(backbone.target_entities),
                "retained_candidates_per_source": {
                    str(source): len(candidates[source])
                    for source in evaluated_sources
                },
                "total_pruned_candidates": sum(
                    selection.pruned
                    for selection in candidate_selections.values()
                ),
                "guarantee": (
                    "Static world-uniform lower/upper bounds; a candidate is "
                    "removed only when its upper bound is below the kth lower bound."
                    if candidate_top_k is not None
                    else "disabled"
                ),
            },
            "subgraph_semantics": (
                "Each candidate rectangle lists source-incident union "
                "candidate-incident edge slots. Actual S4 sampling uses the "
                "union across model-decision-preserving retained candidates, "
                "recorded per source as sampled_edge_indices. This does not "
                "guarantee ground-truth candidate retention."
            ),
        }
    )
    if measure_latency:
        report["latency"] = {
            "total_seconds": elapsed_seconds,
            "seconds_per_query": elapsed_seconds / len(result.sources),
        }
    return report
