"""Incremental maintenance of Bernoulli message moments.

The low-level index owns the numerical state.  ``VersionedStreamingMomentIndex``
adds arrival/event-time semantics, dependency-aware cache invalidation, and
bounded rollback without changing the moment equations.
"""

from __future__ import annotations

import math
import threading
from dataclasses import dataclass
from typing import Hashable, Sequence

from pkgea.distributional import GaussianMoments, aggregate_bernoulli_messages


class PropagationDependencyIndex:
    """Topology index for hop-aware score/embedding cache invalidation.

    The index assumes that ``edge_endpoints`` describes the topology used by
    the scorer.  A caller that adds or physically removes an edge must rebuild
    the index before evaluating the new revision.
    """

    def __init__(
        self,
        edge_endpoints: Sequence[tuple[Hashable, Hashable]],
    ) -> None:
        self.edge_endpoints = tuple(edge_endpoints)
        adjacency: dict[Hashable, set[Hashable]] = {}
        for head, tail in self.edge_endpoints:
            adjacency.setdefault(head, set()).add(tail)
            adjacency.setdefault(tail, set()).add(head)
        self.adjacency = {
            entity: frozenset(neighbors)
            for entity, neighbors in adjacency.items()
        }

    def affected_entities(
        self,
        affected_edges: Sequence[int],
        propagation_depth: int,
        *,
        normalization_hops: int = 0,
    ) -> frozenset[Hashable]:
        """Return entities whose representations can change after an update.

        Without topology-dependent normalization, a one-layer model is
        affected at the updated edge's endpoints and each additional layer
        expands by one hop. Symmetric degree normalization changes all
        normalized incident weights at the endpoints, so callers must add
        one ``normalization_hops`` expansion for that operator.
        """

        if propagation_depth <= 0:
            raise ValueError("propagation_depth must be positive")
        if normalization_hops < 0:
            raise ValueError("normalization_hops cannot be negative")

        affected: set[Hashable] = set()
        for edge_index in affected_edges:
            if edge_index < 0 or edge_index >= len(self.edge_endpoints):
                raise IndexError("affected edge index out of range")
            affected.update(self.edge_endpoints[edge_index])

        frontier = set(affected)
        for _ in range(propagation_depth - 1 + normalization_hops):
            expanded = {
                neighbor
                for entity in frontier
                for neighbor in self.adjacency.get(entity, ())
                if neighbor not in affected
            }
            if not expanded:
                break
            affected.update(expanded)
            frontier = expanded
        return frozenset(affected)


def propagation_affected_entities(
    edge_endpoints: Sequence[tuple[Hashable, Hashable]],
    affected_edges: Sequence[int],
    propagation_depth: int,
    *,
    normalization_hops: int = 0,
) -> frozenset[Hashable]:
    """Convenience wrapper for one-off hop-aware invalidation checks."""

    return PropagationDependencyIndex(edge_endpoints).affected_entities(
        affected_edges,
        propagation_depth,
        normalization_hops=normalization_hops,
    )


@dataclass(frozen=True)
class LocalEmbeddingRefreshPolicy:
    """Conservative affected-scope crossover for local GNN refresh."""

    total_entities: int
    max_local_entities: int
    minimum_observed_speedup: float
    calibration_points: int

    def choose(self, affected_entities: int) -> str:
        if not 0 <= affected_entities <= self.total_entities:
            raise ValueError("affected_entities is outside entity scope")
        return (
            "local_recompute"
            if affected_entities <= self.max_local_entities
            else "full_forward"
        )

    def as_dict(self) -> dict[str, int | float | str]:
        return {
            "format": "pkgea-local-embedding-refresh-policy-v1",
            "total_entities": self.total_entities,
            "max_local_entities": self.max_local_entities,
            "max_local_fraction": self.max_local_entities
            / self.total_entities,
            "minimum_observed_speedup": self.minimum_observed_speedup,
            "calibration_points": self.calibration_points,
            "above_cutoff_action": "full_forward",
        }

    @classmethod
    def from_dict(cls, value: dict[str, object]) -> "LocalEmbeddingRefreshPolicy":
        if value.get("format") != "pkgea-local-embedding-refresh-policy-v1":
            raise ValueError("unsupported local embedding refresh policy")
        return cls(
            total_entities=int(value["total_entities"]),
            max_local_entities=int(value["max_local_entities"]),
            minimum_observed_speedup=float(value["minimum_observed_speedup"]),
            calibration_points=int(value["calibration_points"]),
        )


def calibrate_local_embedding_refresh(
    samples: Sequence[tuple[int, float]],
    *,
    total_entities: int,
    minimum_speedup: float = 1.05,
) -> LocalEmbeddingRefreshPolicy:
    """Fit a no-regret local/full cutoff from measured refresh samples.

    The largest observed affected scope is accepted only when every calibration
    sample at or below that scope meets ``minimum_speedup``.  This monotone,
    conservative rule avoids extrapolating a local win beyond measured data.
    """

    if total_entities <= 0:
        raise ValueError("total_entities must be positive")
    if not math.isfinite(minimum_speedup) or minimum_speedup < 1.0:
        raise ValueError("minimum_speedup must be finite and at least one")
    if not samples:
        raise ValueError("at least one calibration sample is required")
    normalized = []
    for affected, speedup in samples:
        if not 0 <= affected <= total_entities:
            raise ValueError("calibration affected scope is invalid")
        if not math.isfinite(speedup) or speedup <= 0.0:
            raise ValueError("calibration speedup must be finite and positive")
        normalized.append((int(affected), float(speedup)))

    cutoff = 0
    for candidate in sorted({affected for affected, _ in normalized}):
        if all(
            speedup >= minimum_speedup
            for affected, speedup in normalized
            if affected <= candidate
        ):
            cutoff = candidate
        else:
            break
    accepted_speedups = [
        speedup for affected, speedup in normalized if affected <= cutoff
    ]
    return LocalEmbeddingRefreshPolicy(
        total_entities=total_entities,
        max_local_entities=cutoff,
        minimum_observed_speedup=(
            min(accepted_speedups) if accepted_speedups else 0.0
        ),
        calibration_points=len(normalized),
    )


@dataclass(frozen=True)
class ProbabilityUpdate:
    edge_index: int
    old_probability: float
    new_probability: float
    affected_edges: tuple[int, ...]


@dataclass(frozen=True)
class FactEvent:
    action: str
    edge_index: int | None = None
    probability: float | None = None
    message: tuple[float, ...] = ()
    dependency_group: str = ""
    event_time: float | None = None
    observation_time: float | None = None
    event_id: str = ""


@dataclass(frozen=True)
class FactMutation:
    action: str
    edge_index: int
    affected_edges: tuple[int, ...]


@dataclass(frozen=True)
class MomentIndexSnapshot:
    """Serializable-in-memory state used by bounded rollback."""

    messages: tuple[tuple[float, ...], ...]
    probabilities: tuple[float, ...]
    dependency_groups: tuple[str, ...]
    moments: GaussianMoments
    common_shock_probability: float = 0.0


@dataclass(frozen=True)
class VersionedMutation:
    """Audit record for one event applied in observation-time order."""

    version: int
    event_id: str
    action: str
    event_time: float
    observation_time: float
    lateness: float
    late_beyond_watermark: bool
    watermark_before: float
    mutation: ProbabilityUpdate | FactMutation
    invalidated_cache_keys: tuple[Hashable, ...]


@dataclass(frozen=True)
class VersionedReadSnapshot:
    """Immutable numerical view pinned to one committed stream version."""

    version: int
    state: MomentIndexSnapshot


class RevisionConflictError(RuntimeError):
    """Raised when a conditional stream write targets a stale version."""


class IncrementalMomentIndex:
    """Maintain first/second moments after confidence updates.

    Independent edges update in O(d²); grouped common-shock edges update in
    O(|group| d²), rather than rebuilding every edge contribution.
    """

    def __init__(
        self,
        messages: Sequence[Sequence[float]],
        probabilities: Sequence[float],
        *,
        dependency_groups: Sequence[str] | None = None,
        common_shock_probability: float = 0.0,
    ) -> None:
        self.messages = [tuple(message) for message in messages]
        self.probabilities = list(probabilities)
        self.groups = list(dependency_groups or ("",) * len(probabilities))
        self.rho = common_shock_probability
        self._moments = aggregate_bernoulli_messages(
            self.messages,
            self.probabilities,
            dependency_groups=self.groups,
            common_shock_probability=self.rho,
        )

    @property
    def moments(self) -> GaussianMoments:
        return self._moments

    def snapshot(self) -> MomentIndexSnapshot:
        """Capture an immutable state for validation or rollback."""

        return MomentIndexSnapshot(
            tuple(self.messages),
            tuple(self.probabilities),
            tuple(self.groups),
            self._moments,
            self.rho,
        )

    def restore(self, snapshot: MomentIndexSnapshot) -> None:
        """Restore a snapshot produced by :meth:`snapshot`."""

        self.messages = list(snapshot.messages)
        self.probabilities = list(snapshot.probabilities)
        self.groups = list(snapshot.dependency_groups)
        self._moments = snapshot.moments
        self.rho = snapshot.common_shock_probability

    def update(self, edge_index: int, new_probability: float) -> ProbabilityUpdate:
        if not 0 <= edge_index < len(self.probabilities):
            raise ValueError("Invalid edge index")
        if not 0.0 <= new_probability <= 1.0:
            raise ValueError("new_probability must be in [0, 1]")
        old_probability = self.probabilities[edge_index]
        if new_probability == old_probability:
            return ProbabilityUpdate(
                edge_index, old_probability, new_probability, (edge_index,)
            )

        message = self.messages[edge_index]
        dimension = len(message)
        mean = list(self._moments.mean)
        covariance = [list(row) for row in self._moments.covariance]
        delta = new_probability - old_probability
        for coordinate in range(dimension):
            mean[coordinate] += delta * message[coordinate]

        old_variance = old_probability * (1.0 - old_probability)
        new_variance = new_probability * (1.0 - new_probability)
        for row in range(dimension):
            for column in range(dimension):
                covariance[row][column] += (
                    new_variance - old_variance
                ) * message[row] * message[column]

        group = self.groups[edge_index]
        affected = [edge_index]
        if group and self.rho:
            for other_index, other_group in enumerate(self.groups):
                if other_index == edge_index or other_group != group:
                    continue
                affected.append(other_index)
                other_probability = self.probabilities[other_index]
                old_cross = self.rho * (
                    min(old_probability, other_probability)
                    - old_probability * other_probability
                )
                new_cross = self.rho * (
                    min(new_probability, other_probability)
                    - new_probability * other_probability
                )
                other_message = self.messages[other_index]
                cross_delta = new_cross - old_cross
                for row in range(dimension):
                    for column in range(dimension):
                        covariance[row][column] += cross_delta * (
                            message[row] * other_message[column]
                            + other_message[row] * message[column]
                        )

        self.probabilities[edge_index] = new_probability
        self._moments = GaussianMoments(
            tuple(mean), tuple(tuple(row) for row in covariance)
        )
        return ProbabilityUpdate(
            edge_index,
            old_probability,
            new_probability,
            tuple(sorted(affected)),
        )

    def add(
        self,
        message: Sequence[float],
        probability: float,
        *,
        dependency_group: str = "",
    ) -> FactMutation:
        """Append a fact and incrementally add its moment contribution."""

        if not 0.0 <= probability <= 1.0:
            raise ValueError("probability must be in [0, 1]")
        vector = tuple(message)
        if len(vector) != len(self._moments.mean):
            raise ValueError("message dimension does not match the index")

        edge_index = len(self.probabilities)
        mean = list(self._moments.mean)
        covariance = [list(row) for row in self._moments.covariance]
        dimension = len(vector)
        for coordinate in range(dimension):
            mean[coordinate] += probability * vector[coordinate]
        variance = probability * (1.0 - probability)
        for row in range(dimension):
            for column in range(dimension):
                covariance[row][column] += (
                    variance * vector[row] * vector[column]
                )

        affected = [edge_index]
        if dependency_group and self.rho:
            for other_index, other_group in enumerate(self.groups):
                if other_group != dependency_group:
                    continue
                affected.append(other_index)
                other_probability = self.probabilities[other_index]
                cross = self.rho * (
                    min(probability, other_probability)
                    - probability * other_probability
                )
                other_message = self.messages[other_index]
                for row in range(dimension):
                    for column in range(dimension):
                        covariance[row][column] += cross * (
                            vector[row] * other_message[column]
                            + other_message[row] * vector[column]
                        )

        self.messages.append(vector)
        self.probabilities.append(probability)
        self.groups.append(dependency_group)
        self._moments = GaussianMoments(
            tuple(mean), tuple(tuple(row) for row in covariance)
        )
        return FactMutation("add", edge_index, tuple(sorted(affected)))

    def delete(self, edge_index: int) -> FactMutation:
        """Tombstone a fact by setting its existence probability to zero."""

        update = self.update(edge_index, 0.0)
        return FactMutation("delete", edge_index, update.affected_edges)

    def apply_events(
        self,
        events: Sequence[FactEvent],
    ) -> tuple[ProbabilityUpdate | FactMutation, ...]:
        """Apply an ordered batch of add, update, and delete events."""

        results: list[ProbabilityUpdate | FactMutation] = []
        for event in events:
            if event.action == "add":
                if event.probability is None or not event.message:
                    raise ValueError("add event requires probability and message")
                results.append(
                    self.add(
                        event.message,
                        event.probability,
                        dependency_group=event.dependency_group,
                    )
                )
            elif event.action == "update":
                if event.edge_index is None or event.probability is None:
                    raise ValueError("update event requires edge_index and probability")
                results.append(self.update(event.edge_index, event.probability))
            elif event.action == "delete":
                if event.edge_index is None:
                    raise ValueError("delete event requires edge_index")
                results.append(self.delete(event.edge_index))
            else:
                raise ValueError(f"Unsupported fact event: {event.action}")
        return tuple(results)


class VersionedStreamingMomentIndex:
    """Apply timestamped fact events with versioning and cache coherence.

    ``event_time`` records when the fact became true in the modeled domain;
    ``observation_time`` records when the system received that information.
    Events must arrive in non-decreasing observation time.  A watermark is
    computed as ``max_event_time_seen - allowed_lateness``.  By default a
    correction older than that watermark is applied and marked, rather than
    silently discarded.

    Cache entries declare the edge slots they depend on.  Only entries whose
    dependency set intersects the mutation's affected edges are invalidated.
    Passing ``None`` declares a global dependency.
    """

    def __init__(
        self,
        index: IncrementalMomentIndex,
        *,
        allowed_lateness: float = 0.0,
        late_policy: str = "apply",
        max_history: int = 128,
    ) -> None:
        if allowed_lateness < 0.0 or not math.isfinite(allowed_lateness):
            raise ValueError("allowed_lateness must be finite and non-negative")
        if late_policy not in {"apply", "reject"}:
            raise ValueError("late_policy must be 'apply' or 'reject'")
        if max_history <= 0:
            raise ValueError("max_history must be positive")
        self._lock = threading.RLock()
        self.index = index
        self.allowed_lateness = allowed_lateness
        self.late_policy = late_policy
        self.max_history = max_history
        self.version = 0
        self._last_observation_time = -math.inf
        self._max_event_time = -math.inf
        self._snapshots: dict[int, MomentIndexSnapshot] = {
            0: index.snapshot()
        }
        self._records: list[VersionedMutation] = []
        self._cache: dict[
            Hashable, tuple[object, frozenset[int] | None]
        ] = {}

    @property
    def watermark(self) -> float:
        with self._lock:
            if self._max_event_time == -math.inf:
                return -math.inf
            return self._max_event_time - self.allowed_lateness

    @property
    def records(self) -> tuple[VersionedMutation, ...]:
        with self._lock:
            return tuple(self._records)

    def read_snapshot(
        self, version: int | None = None
    ) -> VersionedReadSnapshot:
        """Pin a reader to one fully committed immutable version."""

        with self._lock:
            resolved = self.version if version is None else version
            state = self._snapshots.get(resolved)
            if state is None:
                raise ValueError("requested version is outside retained history")
            return VersionedReadSnapshot(resolved, state)

    def put_cached(
        self,
        key: Hashable,
        value: object,
        *,
        depends_on_edges: Sequence[int] | None = None,
    ) -> None:
        dependencies = (
            None
            if depends_on_edges is None
            else frozenset(depends_on_edges)
        )
        with self._lock:
            self._cache[key] = (value, dependencies)

    def get_cached(self, key: Hashable) -> object | None:
        with self._lock:
            entry = self._cache.get(key)
            return None if entry is None else entry[0]

    def apply_event(self, event: FactEvent) -> VersionedMutation:
        """Apply one timestamped event and create an auditable new version."""

        with self._lock:
            return self._apply_event_locked(event)

    def apply_event_if_version(
        self,
        event: FactEvent,
        *,
        expected_version: int,
    ) -> VersionedMutation:
        """Compare-and-swap commit for concurrent writers."""

        with self._lock:
            if expected_version != self.version:
                raise RevisionConflictError(
                    "stream revision conflict: expected "
                    f"{expected_version}, active {self.version}"
                )
            return self._apply_event_locked(event)

    def _apply_event_locked(self, event: FactEvent) -> VersionedMutation:
        if event.event_time is None or event.observation_time is None:
            raise ValueError(
                "versioned events require event_time and observation_time"
            )
        if not math.isfinite(event.event_time) or not math.isfinite(
            event.observation_time
        ):
            raise ValueError("event and observation times must be finite")
        if event.observation_time < event.event_time:
            raise ValueError("observation_time cannot precede event_time")
        if event.observation_time < self._last_observation_time:
            raise ValueError(
                "events must be applied in non-decreasing observation time"
            )

        watermark_before = self.watermark
        is_late = event.event_time < watermark_before
        if is_late and self.late_policy == "reject":
            raise ValueError("event is older than the current watermark")

        mutation = self.index.apply_events((event,))[0]
        affected = frozenset(mutation.affected_edges)
        invalidated = []
        for key, (_, dependencies) in tuple(self._cache.items()):
            if dependencies is None or dependencies & affected:
                invalidated.append(key)
                del self._cache[key]

        self.version += 1
        self._last_observation_time = event.observation_time
        self._max_event_time = max(self._max_event_time, event.event_time)
        record = VersionedMutation(
            version=self.version,
            event_id=event.event_id or f"event-{self.version}",
            action=event.action,
            event_time=event.event_time,
            observation_time=event.observation_time,
            lateness=event.observation_time - event.event_time,
            late_beyond_watermark=is_late,
            watermark_before=watermark_before,
            mutation=mutation,
            invalidated_cache_keys=tuple(
                sorted(invalidated, key=str)
            ),
        )
        self._records.append(record)
        self._snapshots[self.version] = self.index.snapshot()
        while len(self._snapshots) > self.max_history + 1:
            oldest = min(self._snapshots)
            del self._snapshots[oldest]
        return record

    def rollback(self, version: int) -> tuple[Hashable, ...]:
        """Restore a retained version and invalidate every derived cache."""

        with self._lock:
            return self._rollback_locked(version)

    def _rollback_locked(self, version: int) -> tuple[Hashable, ...]:
        if version not in self._snapshots:
            raise ValueError("requested version is outside retained history")
        self.index.restore(self._snapshots[version])
        invalidated = tuple(sorted(self._cache, key=str))
        self._cache.clear()
        self.version = version
        self._records = [
            record for record in self._records if record.version <= version
        ]
        for candidate in tuple(self._snapshots):
            if candidate > version:
                del self._snapshots[candidate]
        if self._records:
            self._last_observation_time = self._records[-1].observation_time
            self._max_event_time = max(
                record.event_time for record in self._records
            )
        else:
            self._last_observation_time = -math.inf
            self._max_event_time = -math.inf
        return invalidated

    def prune_records(self, minimum_observation_time: float) -> int:
        """Drop old audit records while retaining numerical state/snapshots."""

        with self._lock:
            before = len(self._records)
            self._records = [
                record
                for record in self._records
                if record.observation_time >= minimum_observation_time
            ]
            return before - len(self._records)
