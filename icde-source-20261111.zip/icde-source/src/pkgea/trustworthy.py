"""Calibration metrics, temperature scaling, and conformal candidate sets."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Hashable, Mapping, Sequence


def _clip(probability: float) -> float:
    return min(max(probability, 1e-12), 1.0 - 1e-12)


def brier_score(probabilities: Sequence[float], labels: Sequence[int]) -> float:
    if len(probabilities) != len(labels) or not probabilities:
        raise ValueError("probabilities and labels must have equal non-zero length")
    return sum(
        (probability - label) ** 2
        for probability, label in zip(probabilities, labels, strict=True)
    ) / len(labels)


def log_loss(probabilities: Sequence[float], labels: Sequence[int]) -> float:
    if len(probabilities) != len(labels) or not probabilities:
        raise ValueError("probabilities and labels must have equal non-zero length")
    return -sum(
        label * math.log(_clip(probability))
        + (1 - label) * math.log(1.0 - _clip(probability))
        for probability, label in zip(probabilities, labels, strict=True)
    ) / len(labels)


def expected_calibration_error(
    probabilities: Sequence[float], labels: Sequence[int], bins: int = 10
) -> float:
    if len(probabilities) != len(labels) or not probabilities:
        raise ValueError("probabilities and labels must have equal non-zero length")
    if bins <= 0:
        raise ValueError("bins must be positive")
    total = len(labels)
    error = 0.0
    for index in range(bins):
        lower = index / bins
        upper = (index + 1) / bins
        members = [
            (probability, label)
            for probability, label in zip(probabilities, labels, strict=True)
            if lower <= probability < upper
            or (index == bins - 1 and probability == 1.0)
        ]
        if not members:
            continue
        confidence = sum(item[0] for item in members) / len(members)
        accuracy = sum(item[1] for item in members) / len(members)
        error += len(members) / total * abs(confidence - accuracy)
    return error


def apply_temperature(probability: float, temperature: float) -> float:
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    probability = _clip(probability)
    logit = math.log(probability / (1.0 - probability))
    return 1.0 / (1.0 + math.exp(-logit / temperature))


def fit_temperature(
    probabilities: Sequence[float],
    labels: Sequence[int],
    grid: Sequence[float] | None = None,
) -> float:
    candidates = tuple(grid or (0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0))
    if not candidates:
        raise ValueError("Temperature grid cannot be empty")
    return min(
        candidates,
        key=lambda temperature: log_loss(
            [apply_temperature(value, temperature) for value in probabilities],
            labels,
        ),
    )


def softmax_probabilities(
    logits: Sequence[float], temperature: float = 1.0
) -> tuple[float, ...]:
    """Convert one candidate row into a numerically stable probability vector."""

    if not logits:
        raise ValueError("logits cannot be empty")
    if temperature <= 0.0 or not math.isfinite(temperature):
        raise ValueError("temperature must be finite and positive")
    scaled = [value / temperature for value in logits]
    maximum = max(scaled)
    weights = [math.exp(value - maximum) for value in scaled]
    total = sum(weights)
    return tuple(weight / total for weight in weights)


def multiclass_log_loss(
    probability_rows: Sequence[Sequence[float]],
    true_indices: Sequence[int],
) -> float:
    """Mean negative log probability assigned to the true candidate."""

    if len(probability_rows) != len(true_indices) or not probability_rows:
        raise ValueError("rows and true_indices must have equal non-zero length")
    losses = []
    for row, true_index in zip(
        probability_rows, true_indices, strict=True
    ):
        if not 0 <= true_index < len(row):
            raise ValueError("true candidate index is outside a row")
        losses.append(-math.log(_clip(row[true_index])))
    return sum(losses) / len(losses)


def multiclass_brier_score(
    probability_rows: Sequence[Sequence[float]],
    true_indices: Sequence[int],
) -> float:
    """Mean multiclass Brier score, summed over candidates per query."""

    if len(probability_rows) != len(true_indices) or not probability_rows:
        raise ValueError("rows and true_indices must have equal non-zero length")
    total = 0.0
    for row, true_index in zip(
        probability_rows, true_indices, strict=True
    ):
        if not 0 <= true_index < len(row):
            raise ValueError("true candidate index is outside a row")
        total += sum(
            (probability - float(index == true_index)) ** 2
            for index, probability in enumerate(row)
        )
    return total / len(probability_rows)


def fit_multiclass_temperature(
    logit_rows: Sequence[Sequence[float]],
    true_indices: Sequence[int],
    grid: Sequence[float] | None = None,
) -> float:
    """Fit a scalar softmax temperature on a query-disjoint split."""

    if len(logit_rows) != len(true_indices) or not logit_rows:
        raise ValueError("rows and true_indices must have equal non-zero length")
    candidates = tuple(
        grid
        or (
            0.01,
            0.025,
            0.05,
            0.1,
            0.2,
            0.5,
            1.0,
            2.0,
            4.0,
            8.0,
        )
    )
    if any(value <= 0.0 for value in candidates):
        raise ValueError("temperature grid values must be positive")
    return min(
        candidates,
        key=lambda temperature: multiclass_log_loss(
            [
                softmax_probabilities(row, temperature)
                for row in logit_rows
            ],
            true_indices,
        ),
    )


@dataclass(frozen=True)
class ConformalSet:
    candidates: tuple[Hashable, ...]
    score_threshold: float
    quantile: float


@dataclass(frozen=True)
class ConformalCoverageReport:
    target_coverage: float
    empirical_coverage: float
    average_set_size: float
    empty_set_rate: float
    test_queries: int


@dataclass(frozen=True)
class AdaptiveConformalSet:
    """Rank-adaptive prediction set using APS/RAPS nonconformity."""

    candidates: tuple[Hashable, ...]
    quantile: float
    regularization: float
    regularization_rank: int


@dataclass(frozen=True)
class MarginConformalSet:
    candidates: tuple[Hashable, ...]
    quantile: float


@dataclass(frozen=True)
class AssignmentPruningResult:
    candidate_sets: tuple[frozenset[int], ...]
    feasible: bool
    removed_edges: int


def prune_to_injective_assignment_support(
    candidate_sets: Sequence[Sequence[int]],
    column_count: int,
) -> AssignmentPruningResult:
    """Keep only edges occurring in some full injective set assignment.

    This is a structural projection of a collection of prediction sets.  It
    does not turn marginal conformal coverage into simultaneous coverage.
    """

    if not candidate_sets or column_count <= 0:
        raise ValueError("candidate sets and column_count must be positive")
    normalized = tuple(frozenset(row) for row in candidate_sets)
    if any(
        not row
        or any(column < 0 or column >= column_count for column in row)
        for row in normalized
    ):
        raise ValueError("candidate sets contain an empty or invalid row")

    def has_matching(
        fixed_row: int | None = None,
        fixed_column: int | None = None,
    ) -> bool:
        owners = [-1] * column_count
        if fixed_row is not None:
            assert fixed_column is not None
            owners[fixed_column] = fixed_row
        rows = sorted(
            (
                row
                for row in range(len(normalized))
                if row != fixed_row
            ),
            key=lambda row: (len(normalized[row]), row),
        )

        def augment(row: int, visited: set[int]) -> bool:
            for column in sorted(normalized[row]):
                if column in visited:
                    continue
                visited.add(column)
                owner = owners[column]
                if owner == fixed_row:
                    continue
                if owner == -1 or augment(owner, visited):
                    owners[column] = row
                    return True
            return False

        return all(augment(row, set()) for row in rows)

    if not has_matching():
        return AssignmentPruningResult(normalized, False, 0)
    supported = tuple(
        frozenset(
            column
            for column in row
            if has_matching(row_index, column)
        )
        for row_index, row in enumerate(normalized)
    )
    return AssignmentPruningResult(
        candidate_sets=supported,
        feasible=True,
        removed_edges=sum(map(len, normalized)) - sum(map(len, supported)),
    )


def margin_conformal_candidate_set(
    calibration_rows: Sequence[Sequence[float]],
    calibration_true_indices: Sequence[int],
    candidate_scores: Mapping[Hashable, float],
    *,
    alpha: float = 0.1,
) -> MarginConformalSet:
    """Split-conformal set using top-score minus candidate-score margins."""

    if not calibration_rows or not candidate_scores:
        raise ValueError("Calibration rows and candidates cannot be empty")
    if len(calibration_rows) != len(calibration_true_indices):
        raise ValueError("Calibration rows and labels must have equal length")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    width = len(candidate_scores)
    if any(len(row) != width for row in calibration_rows):
        raise ValueError("Calibration and test candidate widths must match")
    margins = sorted(
        max(row) - row[true_index]
        for row, true_index in zip(
            calibration_rows,
            calibration_true_indices,
            strict=True,
        )
    )
    rank = math.ceil((len(margins) + 1) * (1.0 - alpha))
    quantile = margins[min(rank, len(margins)) - 1]
    maximum = max(candidate_scores.values())
    selected = tuple(
        candidate
        for candidate, score in sorted(
            candidate_scores.items(),
            key=lambda item: (-item[1], str(item[0])),
        )
        if maximum - score <= quantile
    )
    return MarginConformalSet(selected, quantile)


def _adaptive_nonconformity(
    probabilities: Sequence[float],
    candidate_index: int,
    *,
    regularization: float,
    regularization_rank: int,
) -> float:
    order = sorted(
        range(len(probabilities)),
        key=lambda index: (-probabilities[index], index),
    )
    cumulative = 0.0
    for rank, index in enumerate(order, start=1):
        cumulative += probabilities[index]
        score = cumulative + regularization * max(
            rank - regularization_rank,
            0,
        )
        if index == candidate_index:
            return score
    raise ValueError("candidate_index is outside the probability row")


def adaptive_conformal_candidate_set(
    calibration_rows: Sequence[Sequence[float]],
    calibration_true_indices: Sequence[int],
    candidate_scores: Mapping[Hashable, float],
    *,
    alpha: float = 0.1,
    regularization: float = 0.0,
    regularization_rank: int = 5,
) -> AdaptiveConformalSet:
    """Construct an APS/RAPS set from multiclass probability rows.

    ``regularization=0`` gives APS. Positive regularization gives deterministic
    RAPS with hyperparameters fixed independently of the test queries.
    """

    if not calibration_rows or not candidate_scores:
        raise ValueError("Calibration rows and candidates cannot be empty")
    if len(calibration_rows) != len(calibration_true_indices):
        raise ValueError("Calibration rows and labels must have equal length")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    if regularization < 0.0 or regularization_rank < 0:
        raise ValueError("Invalid RAPS regularization")
    candidate_items = list(candidate_scores.items())
    candidate_probabilities = [float(score) for _, score in candidate_items]
    width = len(candidate_probabilities)
    if any(len(row) != width for row in calibration_rows):
        raise ValueError("Calibration and test candidate widths must match")
    calibration_scores = sorted(
        _adaptive_nonconformity(
            row,
            true_index,
            regularization=regularization,
            regularization_rank=regularization_rank,
        )
        for row, true_index in zip(
            calibration_rows,
            calibration_true_indices,
            strict=True,
        )
    )
    rank = math.ceil(
        (len(calibration_scores) + 1) * (1.0 - alpha)
    )
    quantile = calibration_scores[
        min(rank, len(calibration_scores)) - 1
    ]
    selected = tuple(
        candidate
        for index, (candidate, _) in enumerate(candidate_items)
        if _adaptive_nonconformity(
            candidate_probabilities,
            index,
            regularization=regularization,
            regularization_rank=regularization_rank,
        )
        <= quantile
    )
    return AdaptiveConformalSet(
        candidates=selected,
        quantile=quantile,
        regularization=regularization,
        regularization_rank=regularization_rank,
    )


def conformal_candidate_set(
    calibration_true_scores: Sequence[float],
    candidate_scores: Mapping[Hashable, float],
    *,
    alpha: float = 0.1,
) -> ConformalSet:
    """Split-conformal set using nonconformity ``1 - true_candidate_score``."""

    if not calibration_true_scores or not candidate_scores:
        raise ValueError("Calibration scores and candidates cannot be empty")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    scores = sorted(1.0 - _clip(value) for value in calibration_true_scores)
    rank = math.ceil((len(scores) + 1) * (1.0 - alpha))
    quantile = scores[min(rank, len(scores)) - 1]
    threshold = 1.0 - quantile
    selected = tuple(
        candidate
        for candidate, score in sorted(
            candidate_scores.items(), key=lambda item: (-item[1], str(item[0]))
        )
        if score >= threshold
    )
    return ConformalSet(selected, threshold, quantile)


def evaluate_conformal_coverage(
    calibration_true_scores: Sequence[float],
    test_queries: Sequence[
        tuple[Hashable, Mapping[Hashable, float]]
    ],
    *,
    alpha: float = 0.1,
) -> ConformalCoverageReport:
    """Evaluate split-conformal coverage on a disjoint query collection."""

    if not test_queries:
        raise ValueError("test_queries cannot be empty")
    covered = 0
    total_size = 0
    empty = 0
    for true_candidate, candidate_scores in test_queries:
        if true_candidate not in candidate_scores:
            raise ValueError("Each true candidate must appear in its candidate scores")
        candidate_set = conformal_candidate_set(
            calibration_true_scores,
            candidate_scores,
            alpha=alpha,
        )
        covered += true_candidate in candidate_set.candidates
        total_size += len(candidate_set.candidates)
        empty += not candidate_set.candidates
    count = len(test_queries)
    return ConformalCoverageReport(
        target_coverage=1.0 - alpha,
        empirical_coverage=covered / count,
        average_set_size=total_size / count,
        empty_set_rate=empty / count,
        test_queries=count,
    )


def maximum_weight_injective_assignment(
    row_scores: Sequence[Sequence[float]],
) -> tuple[int, ...]:
    """Maximum-weight one-to-one row→column assignment via Hungarian method.

    The number of columns must be at least the number of rows.  Returned column
    indices are unique and ordered by input row.
    """

    if not row_scores:
        raise ValueError("row_scores cannot be empty")
    column_count = len(row_scores[0])
    if column_count < len(row_scores):
        raise ValueError("injective assignment requires columns >= rows")
    if column_count == 0 or any(
        len(row) != column_count for row in row_scores
    ):
        raise ValueError("score rows must have equal non-zero width")
    if any(
        not math.isfinite(value)
        for row in row_scores
        for value in row
    ):
        raise ValueError("assignment scores must be finite")

    row_count = len(row_scores)
    # Standard O(rows^2 * columns) rectangular Hungarian minimization.
    u = [0.0] * (row_count + 1)
    v = [0.0] * (column_count + 1)
    matched_row = [0] * (column_count + 1)
    predecessor = [0] * (column_count + 1)
    for row_index in range(1, row_count + 1):
        matched_row[0] = row_index
        minimum = [float("inf")] * (column_count + 1)
        used = [False] * (column_count + 1)
        column = 0
        while True:
            used[column] = True
            current_row = matched_row[column]
            delta = float("inf")
            next_column = 0
            for candidate in range(1, column_count + 1):
                if used[candidate]:
                    continue
                cost = (
                    -row_scores[current_row - 1][candidate - 1]
                    - u[current_row]
                    - v[candidate]
                )
                if cost < minimum[candidate]:
                    minimum[candidate] = cost
                    predecessor[candidate] = column
                if minimum[candidate] < delta:
                    delta = minimum[candidate]
                    next_column = candidate
            for candidate in range(column_count + 1):
                if used[candidate]:
                    u[matched_row[candidate]] += delta
                    v[candidate] -= delta
                else:
                    minimum[candidate] -= delta
            column = next_column
            if matched_row[column] == 0:
                break
        while True:
            previous = predecessor[column]
            matched_row[column] = matched_row[previous]
            column = previous
            if column == 0:
                break

    assignment = [-1] * row_count
    for column in range(1, column_count + 1):
        if matched_row[column]:
            assignment[matched_row[column] - 1] = column - 1
    if any(column < 0 for column in assignment):
        raise AssertionError("Hungarian assignment left a row unmatched")
    return tuple(assignment)
