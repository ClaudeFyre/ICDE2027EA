"""A dependency-free scorer for world-sampling integration tests."""

from __future__ import annotations

import csv
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path

from pkgea.contracts import validate_dataset


@dataclass
class ToyStructuralBackbone:
    triples: list[dict[str, str]]
    source_entities: tuple[str, ...]
    target_entities: tuple[str, ...]
    all_entities: tuple[str, ...]
    labels: dict[str, str]
    lexical_scores: dict[tuple[str, str], float]

    @classmethod
    def from_dataset(cls, dataset_dir: str | Path) -> "ToyStructuralBackbone":
        root = Path(dataset_dir).resolve()
        validate_dataset(root)
        with (root / "entities.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            entities = list(csv.DictReader(handle, delimiter="\t"))
        with (root / "triples.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            triples = list(csv.DictReader(handle, delimiter="\t"))
        with (root / "alignments.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            alignments = list(csv.DictReader(handle, delimiter="\t"))
        source_entities = tuple(
            dict.fromkeys(row["source_entity_id"] for row in alignments)
        )
        target_entities = tuple(
            dict.fromkeys(row["target_entity_id"] for row in alignments)
        )
        labels = {row["entity_id"]: row["label"] for row in entities}
        lexical_scores = {
            (source, target): SequenceMatcher(
                None,
                labels[source].casefold(),
                labels[target].casefold(),
            ).ratio()
            for source in source_entities
            for target in target_entities
        }
        return cls(
            triples=triples,
            source_entities=source_entities,
            target_entities=target_entities,
            all_entities=tuple(row["entity_id"] for row in entities),
            labels=labels,
            lexical_scores=lexical_scores,
        )

    def _score_weighted(
        self, edge_weights: tuple[float, ...]
    ) -> dict[tuple[str, str], float]:
        return self._score_subset_weighted(
            edge_weights,
            self.source_entities,
            self.target_entities,
        )

    def _score_subset_weighted(
        self,
        edge_weights: tuple[float, ...],
        sources: tuple[str, ...],
        targets: tuple[str, ...],
    ) -> dict[tuple[str, str], float]:
        if len(edge_weights) != len(self.triples):
            raise ValueError("Edge weight length does not match triple count")
        if not set(sources) <= set(self.source_entities):
            raise ValueError("Unknown source in score subset")
        if not set(targets) <= set(self.target_entities):
            raise ValueError("Unknown target in score subset")
        degrees = {entity: [0.0, 0.0] for entity in self.all_entities}
        for weight, triple in zip(edge_weights, self.triples, strict=True):
            degrees[triple["head_id"]][0] += weight
            degrees[triple["tail_id"]][1] += weight

        scores: dict[tuple[str, str], float] = {}
        for source in sources:
            for target in targets:
                lexical = self.lexical_scores[(source, target)]
                source_degree = degrees[source]
                target_degree = degrees[target]
                degree_distance = abs(source_degree[0] - target_degree[0]) + abs(
                    source_degree[1] - target_degree[1]
                )
                structural = 1.0 / (1.0 + degree_distance)
                scores[(source, target)] = 0.6 * lexical + 0.4 * structural
        return scores

    def score(self, state: tuple[bool, ...]) -> dict[tuple[str, str], float]:
        return self._score_weighted(tuple(float(active) for active in state))

    def score_subset(
        self,
        state: tuple[bool, ...],
        sources: tuple[str, ...],
        targets: tuple[str, ...],
    ) -> dict[tuple[str, str], float]:
        """Score only a requested query rectangle."""

        return self._score_subset_weighted(
            tuple(float(active) for active in state),
            sources,
            targets,
        )

    def score_expected(
        self, edge_probabilities: tuple[float, ...]
    ) -> dict[tuple[str, str], float]:
        """Score the expected adjacency, a deterministic nonlinear baseline."""

        if any(not 0.0 <= value <= 1.0 for value in edge_probabilities):
            raise ValueError("Edge probabilities must be in [0, 1]")
        return self._score_weighted(edge_probabilities)
