"""A lightweight attribute-and-structure EA backbone for real-data probes."""

from __future__ import annotations

import csv
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

from pkgea.backbones.toy import ToyStructuralBackbone


_DATATYPE = re.compile(r"\^\^<[^>]+>$")
_LANGUAGE = re.compile(r"@[A-Za-z-]+$")
_NON_WORD = re.compile(r"[^\w]+", re.UNICODE)


def normalize_attribute_value(value: str) -> str:
    """Normalize an RDF literal without using gold entity links."""

    value = _DATATYPE.sub("", value.strip())
    value = _LANGUAGE.sub("", value)
    return " ".join(value.strip('"').casefold().split())


def _character_ngrams(values: list[str]) -> Counter[str]:
    features: Counter[str] = Counter()
    for value in values:
        text = f" {_NON_WORD.sub(' ', value)} "
        for width in (2, 3, 4):
            features.update(
                text[index : index + width]
                for index in range(max(0, len(text) - width + 1))
            )
    return features


def _tfidf_cosine(
    left: Counter[str],
    right: Counter[str],
    document_frequency: Counter[str],
    document_count: int,
) -> float:
    common = left.keys() & right.keys()

    def weight(feature: str) -> float:
        return math.log((document_count + 1) / (document_frequency[feature] + 1)) + 1

    dot = sum(
        left[feature] * right[feature] * weight(feature) ** 2
        for feature in common
    )
    left_norm = sum(
        count**2 * weight(feature) ** 2 for feature, count in left.items()
    )
    right_norm = sum(
        count**2 * weight(feature) ** 2 for feature, count in right.items()
    )
    if not left_norm or not right_norm:
        return 0.0
    return dot / math.sqrt(left_norm * right_norm)


@dataclass
class AttributeStructuralBackbone:
    """Static TF-IDF attribute evidence plus world-dependent degree evidence."""

    structural: ToyStructuralBackbone
    attribute_scores: dict[tuple[str, str], float]
    attribute_weight: float = 0.8

    @classmethod
    def from_dataset(
        cls,
        dataset_dir: str | Path,
        *,
        attribute_weight: float = 0.8,
    ) -> "AttributeStructuralBackbone":
        if not 0.0 <= attribute_weight <= 1.0:
            raise ValueError("attribute_weight must be in [0, 1]")
        root = Path(dataset_dir).resolve()
        structural = ToyStructuralBackbone.from_dataset(root)
        values: defaultdict[str, list[str]] = defaultdict(list)
        attribute_path = root / "attributes.tsv"
        if attribute_path.is_file():
            with attribute_path.open(
                "r", encoding="utf-8-sig", newline=""
            ) as handle:
                for row in csv.DictReader(handle, delimiter="\t"):
                    normalized = normalize_attribute_value(row["value"])
                    if normalized:
                        values[row["entity_id"]].append(normalized)

        query_entities = (
            *structural.source_entities,
            *structural.target_entities,
        )
        vectors = {
            entity: _character_ngrams(values[entity])
            for entity in query_entities
        }
        document_frequency: Counter[str] = Counter(
            feature for vector in vectors.values() for feature in vector
        )
        document_count = len(vectors)
        scores = {
            (source, target): _tfidf_cosine(
                vectors[source],
                vectors[target],
                document_frequency,
                document_count,
            )
            for source in structural.source_entities
            for target in structural.target_entities
        }
        return cls(
            structural=structural,
            attribute_scores=scores,
            attribute_weight=attribute_weight,
        )

    @property
    def triples(self) -> list[dict[str, str]]:
        return self.structural.triples

    @property
    def source_entities(self) -> tuple[str, ...]:
        return self.structural.source_entities

    @property
    def target_entities(self) -> tuple[str, ...]:
        return self.structural.target_entities

    def score(self, state: tuple[bool, ...]) -> dict[tuple[str, str], float]:
        structural_scores = self.structural.score(state)
        return self._combine_scores(structural_scores)

    def score_subset(
        self,
        state: tuple[bool, ...],
        sources: tuple[str, ...],
        targets: tuple[str, ...],
    ) -> dict[tuple[str, str], float]:
        structural_scores = self.structural.score_subset(
            state,
            sources,
            targets,
        )
        return self._combine_scores(structural_scores)

    def score_expected(
        self, edge_probabilities: tuple[float, ...]
    ) -> dict[tuple[str, str], float]:
        structural_scores = self.structural.score_expected(edge_probabilities)
        return self._combine_scores(structural_scores)

    def _combine_scores(
        self, structural_scores: dict[tuple[str, str], float]
    ) -> dict[tuple[str, str], float]:
        structural_weight = 1.0 - self.attribute_weight
        return {
            pair: self.attribute_weight * self.attribute_scores[pair]
            + structural_weight * structural_score
            for pair, structural_score in structural_scores.items()
        }
