"""Multi-view seeded label propagation for world-sensitive EA."""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from pkgea.backbones.attribute import AttributeStructuralBackbone
from pkgea.backbones.toy import ToyStructuralBackbone
from pkgea.contracts import validate_dataset


@dataclass
class LabelPropagationBackbone:
    triples: list[dict[str, str]]
    entity_index: dict[str, int]
    source_entities: tuple[str, ...]
    target_entities: tuple[str, ...]
    seed_labels: np.ndarray
    attribute_scores: dict[tuple[str, str], float]
    structural: ToyStructuralBackbone
    steps: int = 4
    restart: float = 0.25
    attribute_weight: float = 0.6
    structural_weight: float = 0.15

    @classmethod
    def from_dataset(
        cls,
        dataset_dir: str | Path,
        *,
        steps: int = 4,
        restart: float = 0.25,
        attribute_weight: float = 0.6,
        structural_weight: float = 0.15,
    ) -> "LabelPropagationBackbone":
        if steps <= 0:
            raise ValueError("steps must be positive")
        if not 0.0 < restart <= 1.0:
            raise ValueError("restart must be in (0, 1]")
        if not 0.0 <= attribute_weight <= 1.0:
            raise ValueError("attribute_weight must be in [0, 1]")
        if not 0.0 <= structural_weight <= 1.0:
            raise ValueError("structural_weight must be in [0, 1]")
        if attribute_weight + structural_weight > 1.0:
            raise ValueError("attribute and structural weights must sum to <= 1")
        root = Path(dataset_dir).resolve()
        validate_dataset(root)
        with (root / "entities.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            entities = list(csv.DictReader(handle, delimiter="\t"))
        with (root / "triples.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            triples = list(csv.DictReader(handle, delimiter="\t"))
        with (root / "alignments.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            alignments = list(csv.DictReader(handle, delimiter="\t"))
        index = {
            row["entity_id"]: position for position, row in enumerate(entities)
        }
        anchors = [row for row in alignments if row["split"] == "train"]
        if not anchors:
            raise ValueError("Label propagation requires train alignment anchors")
        seed_labels = np.zeros(
            (len(entities), len(anchors)), dtype=np.float64
        )
        for column, row in enumerate(anchors):
            seed_labels[index[row["source_entity_id"]], column] = 1.0
            seed_labels[index[row["target_entity_id"]], column] = 1.0
        attribute = AttributeStructuralBackbone.from_dataset(root)
        return cls(
            triples=triples,
            entity_index=index,
            source_entities=tuple(
                dict.fromkeys(row["source_entity_id"] for row in alignments)
            ),
            target_entities=tuple(
                dict.fromkeys(row["target_entity_id"] for row in alignments)
            ),
            seed_labels=seed_labels,
            attribute_scores=attribute.attribute_scores,
            structural=attribute.structural,
            steps=steps,
            restart=restart,
            attribute_weight=attribute_weight,
            structural_weight=structural_weight,
        )

    def _propagate(self, state: tuple[bool, ...]) -> np.ndarray:
        if len(state) != len(self.triples):
            raise ValueError("World state length does not match triple count")
        neighbors: list[list[int]] = [
            [] for _ in range(len(self.entity_index))
        ]
        for active, triple in zip(state, self.triples, strict=True):
            if active:
                head = self.entity_index[triple["head_id"]]
                tail = self.entity_index[triple["tail_id"]]
                neighbors[head].append(tail)
                neighbors[tail].append(head)
        labels = self.seed_labels.copy()
        for _ in range(self.steps):
            propagated = np.zeros_like(labels)
            for node, adjacent in enumerate(neighbors):
                if adjacent:
                    propagated[node] = labels[adjacent].mean(axis=0)
            labels = (
                self.restart * self.seed_labels
                + (1.0 - self.restart) * propagated
            )
        norms = np.linalg.norm(labels, axis=1, keepdims=True)
        return labels / np.maximum(norms, 1e-12)

    def score(self, state: tuple[bool, ...]) -> dict[tuple[str, str], float]:
        return self.score_subset(state, self.source_entities, self.target_entities)

    def score_subset(
        self,
        state: tuple[bool, ...],
        sources: tuple[str, ...],
        targets: tuple[str, ...],
    ) -> dict[tuple[str, str], float]:
        """Score a frozen query rectangle under one possible world."""

        if not set(sources) <= set(self.source_entities):
            raise ValueError("Unknown source in score subset")
        if not set(targets) <= set(self.target_entities):
            raise ValueError("Unknown target in score subset")
        labels = self._propagate(state)
        propagation_weight = (
            1.0 - self.attribute_weight - self.structural_weight
        )
        structural_scores = self.structural.score(state)
        scores = {}
        for source in sources:
            source_vector = labels[self.entity_index[source]]
            for target in targets:
                propagation = float(
                    np.dot(
                        source_vector,
                        labels[self.entity_index[target]],
                    )
                )
                attribute = self.attribute_scores[(source, target)]
                value = (
                    self.attribute_weight * attribute
                    + propagation_weight * propagation
                    + self.structural_weight
                    * structural_scores[(source, target)]
                )
                if not math.isfinite(value):
                    raise ValueError("Non-finite label-propagation score")
                scores[(source, target)] = value
        return scores
