"""Project-owned relation-translation alignment baseline."""

from __future__ import annotations

import csv
import hashlib
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from pkgea.contracts import validate_dataset


def _signed_hash_vector(label: str, dimension: int) -> np.ndarray:
    values = np.empty(dimension, dtype=np.float64)
    for index in range(dimension):
        digest = hashlib.sha256(
            f"{label}|{index}".encode("utf-8")
        ).digest()
        values[index] = 1.0 if digest[0] & 1 else -1.0
    return values / np.sqrt(dimension)


@dataclass
class RelationTranslationBackbone:
    """Align signed relation-translation profiles with seeded Procrustes.

    For an active triple ``h --r--> t``, the head receives ``+r`` and the tail
    ``-r``.  Train anchors fit an orthogonal source→target map on the expected
    adjacency.  Every possible world recomputes entity profiles before scoring.
    This is a project baseline, not an official TransE implementation.
    """

    triples: list[dict[str, str]]
    entity_index: dict[str, int]
    relation_vectors: dict[str, np.ndarray]
    source_entities: tuple[str, ...]
    target_entities: tuple[str, ...]
    mapping: np.ndarray
    dimension: int
    training_summary: dict[str, float | int | str]

    @classmethod
    def from_dataset(
        cls,
        dataset_dir: str | Path,
        *,
        dimension: int = 64,
        margin_epochs: int = 0,
        margin: float = 0.2,
        learning_rate: float = 0.05,
        seed: int = 17,
    ) -> "RelationTranslationBackbone":
        if dimension <= 0:
            raise ValueError("dimension must be positive")
        if margin_epochs < 0:
            raise ValueError("margin_epochs must be nonnegative")
        if margin <= 0.0 or learning_rate <= 0.0:
            raise ValueError("margin and learning_rate must be positive")
        root = Path(dataset_dir).resolve()
        validate_dataset(root)
        with (root / "entities.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            entities = list(csv.DictReader(handle, delimiter="\t"))
        with (root / "relations.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            relations = list(csv.DictReader(handle, delimiter="\t"))
        with (root / "triples.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            triples = list(csv.DictReader(handle, delimiter="\t"))
        with (root / "alignments.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            alignments = list(csv.DictReader(handle, delimiter="\t"))
        anchors = [row for row in alignments if row["split"] == "train"]
        if not anchors:
            raise ValueError("translation alignment requires train anchors")
        entity_index = {
            row["entity_id"]: index for index, row in enumerate(entities)
        }
        relation_labels = {
            row["relation_id"]: row["label"].casefold()
            for row in relations
        }
        relation_vectors = {
            relation_id: _signed_hash_vector(label, dimension)
            for relation_id, label in relation_labels.items()
        }

        expected = np.zeros((len(entities), dimension), dtype=np.float64)
        for triple in triples:
            weight = float(triple["confidence"])
            vector = relation_vectors[triple["relation_id"]]
            expected[entity_index[triple["head_id"]]] += weight * vector
            expected[entity_index[triple["tail_id"]]] -= weight * vector
        source_anchor = np.vstack(
            [expected[entity_index[row["source_entity_id"]]] for row in anchors]
        )
        target_anchor = np.vstack(
            [expected[entity_index[row["target_entity_id"]]] for row in anchors]
        )
        covariance = source_anchor.T @ target_anchor
        left, _, right = np.linalg.svd(covariance, full_matrices=False)
        mapping = left @ right
        target_entities = tuple(
            dict.fromkeys(row["target_entity_id"] for row in alignments)
        )

        def normalize(matrix: np.ndarray) -> np.ndarray:
            norms = np.linalg.norm(matrix, axis=1, keepdims=True)
            return matrix / np.maximum(norms, 1e-12)

        normalized_source = normalize(source_anchor)
        normalized_target_anchor = normalize(target_anchor)
        candidate_target = normalize(
            np.vstack(
                [expected[entity_index[target]] for target in target_entities]
            )
        )
        candidate_index = {
            target: index for index, target in enumerate(target_entities)
        }
        positive_indices = [
            candidate_index[row["target_entity_id"]] for row in anchors
        ]

        def hinge_diagnostics(current: np.ndarray) -> tuple[float, float]:
            losses = []
            violations = 0
            for row_index, source_vector in enumerate(normalized_source):
                mapped = source_vector @ current
                scores = candidate_target @ mapped
                positive_index = positive_indices[row_index]
                positive_score = float(scores[positive_index])
                scores = scores.copy()
                scores[positive_index] = -np.inf
                negative_score = float(np.max(scores))
                loss = max(0.0, margin + negative_score - positive_score)
                losses.append(loss)
                violations += loss > 0.0
            return float(np.mean(losses)), violations / len(losses)

        initial_loss, initial_violation_rate = hinge_diagnostics(mapping)
        updates = 0
        if margin_epochs:
            rng = random.Random(seed)
            order = list(range(len(anchors)))
            for _ in range(margin_epochs):
                rng.shuffle(order)
                for row_index in order:
                    source_vector = normalized_source[row_index]
                    mapped = source_vector @ mapping
                    scores = candidate_target @ mapped
                    positive_index = positive_indices[row_index]
                    positive_score = float(scores[positive_index])
                    scores = scores.copy()
                    scores[positive_index] = -np.inf
                    negative_index = int(np.argmax(scores))
                    if (
                        margin
                        + float(scores[negative_index])
                        - positive_score
                        <= 0.0
                    ):
                        continue
                    direction = (
                        normalized_target_anchor[row_index]
                        - candidate_target[negative_index]
                    )
                    mapping += learning_rate * np.outer(
                        source_vector, direction
                    )
                    updates += 1
                # Project back to the orthogonal manifold so an apparent
                # margin gain cannot come only from increasing matrix norm.
                left, _, right = np.linalg.svd(
                    mapping, full_matrices=False
                )
                mapping = left @ right
        final_loss, final_violation_rate = hinge_diagnostics(mapping)
        return cls(
            triples=triples,
            entity_index=entity_index,
            relation_vectors=relation_vectors,
            source_entities=tuple(
                dict.fromkeys(row["source_entity_id"] for row in alignments)
            ),
            target_entities=target_entities,
            mapping=mapping,
            dimension=dimension,
            training_summary={
                "mode": (
                    "hard_negative_margin"
                    if margin_epochs
                    else "orthogonal_procrustes"
                ),
                "epochs": margin_epochs,
                "margin": margin,
                "learning_rate": learning_rate,
                "seed": seed,
                "updates": updates,
                "initial_hinge_loss": initial_loss,
                "final_hinge_loss": final_loss,
                "initial_violation_rate": initial_violation_rate,
                "final_violation_rate": final_violation_rate,
            },
        )

    def _profiles(self, state: tuple[bool, ...]) -> np.ndarray:
        if len(state) != len(self.triples):
            raise ValueError("World state length does not match triple count")
        profiles = np.zeros(
            (len(self.entity_index), self.dimension), dtype=np.float64
        )
        for active, triple in zip(state, self.triples, strict=True):
            if not active:
                continue
            vector = self.relation_vectors[triple["relation_id"]]
            profiles[self.entity_index[triple["head_id"]]] += vector
            profiles[self.entity_index[triple["tail_id"]]] -= vector
        return profiles

    def score(
        self, state: tuple[bool, ...]
    ) -> dict[tuple[str, str], float]:
        profiles = self._profiles(state)
        source_matrix = np.vstack(
            [profiles[self.entity_index[source]] for source in self.source_entities]
        ) @ self.mapping
        target_matrix = np.vstack(
            [profiles[self.entity_index[target]] for target in self.target_entities]
        )
        source_norm = np.linalg.norm(source_matrix, axis=1, keepdims=True)
        target_norm = np.linalg.norm(target_matrix, axis=1, keepdims=True)
        normalized_source = source_matrix / np.maximum(source_norm, 1e-12)
        normalized_target = target_matrix / np.maximum(target_norm, 1e-12)
        cosine = normalized_source @ normalized_target.T
        bounded = np.clip((cosine + 1.0) / 2.0, 0.0, 1.0)
        return {
            (source, target): float(bounded[row, column])
            for row, source in enumerate(self.source_entities)
            for column, target in enumerate(self.target_entities)
        }
