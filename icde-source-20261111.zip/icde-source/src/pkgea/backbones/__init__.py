"""Adapters for deterministic entity-alignment encoders."""

from pkgea.backbones.attribute import AttributeStructuralBackbone
from pkgea.backbones.adapter import CheckpointDescriptor, SubprocessBackboneAdapter
from pkgea.backbones.label_propagation import LabelPropagationBackbone
from pkgea.backbones.translation import RelationTranslationBackbone
from pkgea.backbones.toy import ToyStructuralBackbone

__all__ = [
    "AttributeStructuralBackbone",
    "CheckpointDescriptor",
    "SubprocessBackboneAdapter",
    "LabelPropagationBackbone",
    "RelationTranslationBackbone",
    "ToyStructuralBackbone",
]
