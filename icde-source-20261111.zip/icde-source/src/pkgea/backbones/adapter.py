"""Validated JSON-lines subprocess boundary for external EA backbones."""

from __future__ import annotations

import hashlib
import json
import math
import subprocess
from dataclasses import dataclass
from pathlib import Path


REQUIRED_DESCRIPTOR_FIELDS = {
    "adapter_id",
    "method_family",
    "framework",
    "source_commit",
    "checkpoint_path",
    "checkpoint_sha256",
    "dataset_id",
    "train_split_checksum",
    "seed",
    "device",
    "probability_handling",
    "score_semantics",
    "code_license",
    "artifact_license",
    "command",
}
OPTIONAL_DESCRIPTOR_FIELDS = {
    "dataset_revision",
    "dataset_license_status",
    "entity_feature_mode",
    "relation_parameter_sharing",
    "selection_split",
    "selection_metric",
    "training_probability_handling",
    "effective_training_pair_digest",
    "validation_split_checksum",
    "validation_source",
}
PROBABILITY_HANDLING = {
    "ignored",
    "expected_weight",
    "threshold",
    "sampled_world",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class CheckpointDescriptor:
    adapter_id: str
    method_family: str
    framework: str
    source_commit: str
    checkpoint_path: Path
    checkpoint_sha256: str
    dataset_id: str
    dataset_revision: str | None
    train_split_checksum: str
    seed: int
    device: str
    probability_handling: str
    score_semantics: str
    code_license: str
    artifact_license: str
    command: tuple[str, ...]

    @classmethod
    def load(cls, descriptor_path: str | Path) -> "CheckpointDescriptor":
        path = Path(descriptor_path).resolve()
        payload = json.loads(path.read_text(encoding="utf-8"))
        missing = sorted(REQUIRED_DESCRIPTOR_FIELDS - payload.keys())
        if missing:
            raise ValueError(
                f"Checkpoint descriptor missing fields: {', '.join(missing)}"
            )
        extra = sorted(
            payload.keys()
            - REQUIRED_DESCRIPTOR_FIELDS
            - OPTIONAL_DESCRIPTOR_FIELDS
        )
        if extra:
            raise ValueError(
                f"Checkpoint descriptor has unsupported fields: {', '.join(extra)}"
            )
        command = payload["command"]
        if (
            not isinstance(command, list)
            or not command
            or any(not isinstance(part, str) or not part for part in command)
        ):
            raise ValueError("command must be a non-empty list of strings")
        checkpoint = Path(payload["checkpoint_path"])
        if not checkpoint.is_absolute():
            checkpoint = (path.parent / checkpoint).resolve()
        descriptor = cls(
            adapter_id=str(payload["adapter_id"]),
            method_family=str(payload["method_family"]),
            framework=str(payload["framework"]),
            source_commit=str(payload["source_commit"]),
            checkpoint_path=checkpoint,
            checkpoint_sha256=str(payload["checkpoint_sha256"]).lower(),
            dataset_id=str(payload["dataset_id"]),
            dataset_revision=(
                str(payload["dataset_revision"]).lower()
                if payload.get("dataset_revision") is not None
                else None
            ),
            train_split_checksum=str(payload["train_split_checksum"]).lower(),
            seed=int(payload["seed"]),
            device=str(payload["device"]),
            probability_handling=str(payload["probability_handling"]),
            score_semantics=str(payload["score_semantics"]),
            code_license=str(payload["code_license"]),
            artifact_license=str(payload["artifact_license"]),
            command=tuple(command),
        )
        descriptor.validate()
        return descriptor

    def validate(self) -> None:
        if self.probability_handling not in PROBABILITY_HANDLING:
            raise ValueError(
                f"Unsupported probability_handling: {self.probability_handling}"
            )
        if not self.checkpoint_path.is_file():
            raise ValueError(f"Checkpoint does not exist: {self.checkpoint_path}")
        observed = _sha256(self.checkpoint_path)
        if observed != self.checkpoint_sha256:
            raise ValueError(
                "Checkpoint SHA-256 mismatch: "
                f"expected {self.checkpoint_sha256}, observed {observed}"
            )
        if len(self.source_commit) < 7:
            raise ValueError("source_commit must identify an immutable revision")
        if len(self.train_split_checksum) != 64:
            raise ValueError("train_split_checksum must be a full SHA-256 digest")
        if (
            self.dataset_revision is not None
            and len(self.dataset_revision) != 64
        ):
            raise ValueError("dataset_revision must be a full SHA-256 digest")
        if self.code_license.casefold() == "unresolved":
            raise ValueError("External adapter code license must be resolved before use")
        if self.artifact_license.casefold() == "unresolved":
            raise ValueError(
                "External checkpoint artifact license must be resolved before use"
            )


@dataclass
class SubprocessBackboneAdapter:
    """Invoke an immutable external scorer through one JSON request/response."""

    descriptor: CheckpointDescriptor
    source_entities: tuple[str, ...]
    target_entities: tuple[str, ...]
    edge_count: int
    timeout_seconds: float = 120.0

    def _invoke(self, request: dict[str, object]) -> dict[str, object]:
        completed = subprocess.run(
            self.descriptor.command,
            input=json.dumps(request, ensure_ascii=False) + "\n",
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=self.timeout_seconds,
            check=False,
        )
        if completed.returncode:
            raise RuntimeError(
                f"Adapter exited {completed.returncode}: {completed.stderr.strip()}"
            )
        try:
            return json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise ValueError("Adapter did not return one valid JSON object") from exc

    def _validate_scores(
        self, rows: object
    ) -> dict[tuple[str, str], float]:
        if not isinstance(rows, list):
            raise ValueError("Adapter response scores must be a list")
        scores: dict[tuple[str, str], float] = {}
        for row in rows:
            pair = (str(row["source"]), str(row["target"]))
            value = float(row["score"])
            if pair in scores or not math.isfinite(value):
                raise ValueError("Adapter returned duplicate or non-finite score")
            scores[pair] = value
        expected = {
            (source, target)
            for source in self.source_entities
            for target in self.target_entities
        }
        if set(scores) != expected:
            missing = len(expected - scores)
            extra = len(set(scores) - expected)
            raise ValueError(
                f"Adapter score matrix mismatch: {missing} missing, {extra} extra"
            )
        return scores

    def score(self, state: tuple[bool, ...]) -> dict[tuple[str, str], float]:
        if len(state) != self.edge_count:
            raise ValueError("World state length does not match adapter edge_count")
        response = self._invoke(
            {
                "protocol_version": "pkgea-backbone-v1",
                "adapter_id": self.descriptor.adapter_id,
                "checkpoint_path": str(self.descriptor.checkpoint_path),
                "state": [int(active) for active in state],
                "sources": list(self.source_entities),
                "targets": list(self.target_entities),
            }
        )
        if response.get("protocol_version") != "pkgea-backbone-v1":
            raise ValueError("Adapter protocol_version mismatch")
        return self._validate_scores(response.get("scores"))

    def score_batch(
        self,
        states: tuple[tuple[bool, ...], ...] | list[tuple[bool, ...]],
    ) -> list[dict[tuple[str, str], float]]:
        """Score an ordered world batch in one immutable subprocess."""

        if not states:
            raise ValueError("World batch must be non-empty")
        if any(len(state) != self.edge_count for state in states):
            raise ValueError("World state length does not match adapter edge_count")
        response = self._invoke(
            {
                "protocol_version": "pkgea-backbone-v2",
                "adapter_id": self.descriptor.adapter_id,
                "checkpoint_path": str(self.descriptor.checkpoint_path),
                "states": [
                    [int(active) for active in state] for state in states
                ],
                "sources": list(self.source_entities),
                "targets": list(self.target_entities),
            }
        )
        if response.get("protocol_version") != "pkgea-backbone-v2":
            raise ValueError("Adapter batch protocol_version mismatch")
        batches = response.get("score_batches")
        if not isinstance(batches, list) or len(batches) != len(states):
            raise ValueError("Adapter batch response count mismatch")
        ordered: list[dict[tuple[str, str], float] | None] = [
            None for _ in states
        ]
        for item in batches:
            if not isinstance(item, dict):
                raise ValueError("Adapter score batch must be an object")
            world_index = int(item.get("world_index", -1))
            if (
                world_index < 0
                or world_index >= len(states)
                or ordered[world_index] is not None
            ):
                raise ValueError("Adapter returned invalid/duplicate world_index")
            ordered[world_index] = self._validate_scores(item.get("scores"))
        if any(scores is None for scores in ordered):
            raise ValueError("Adapter omitted one or more world batches")
        return [scores for scores in ordered if scores is not None]
