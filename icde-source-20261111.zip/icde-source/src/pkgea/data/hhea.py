"""Convert a Simple-HHEA temporal graph pair (ICEWS-WIKI, ICEWS-YAGO).

Source: https://github.com/DataArcTech/Simple-HHEA (Jiang et al., WWW 2024,
"Rethinking GNN-based Entity Alignment on Heterogeneous Knowledge Graphs:
New Datasets and A New Method"). Two GitHub orgs were checked for the
canonical repo: `IDEA-FinAI/Simple-HHEA` returns HTTP 404 (does not exist);
`DataArcTech/Simple-HHEA` exists, is not a fork, and is the one used here.

Unlike the task brief's assumption, the datasets are **not** hosted on
Google Drive -- both `icews_wiki.zip` and the split `icews_yago.z01`/
`.z02`/`.zip` ship directly inside `data/` in the git repository (~25 MB
and ~31 MB respectively).

Format is the same GCN-Align/JAPE numeric-id convention as
`pkgea.data.daea` (`ent_ids_{1,2}`, `rel_ids_{1,2}`, `sup_pairs` = train,
`ref_pairs` = test; verified against `main_SimpleHHEA.py` lines 128-129:
``train_alignments = load_alignments(sup_pairs)``,
``dev_alignments = load_alignments(ref_pairs)``), extended with a
**temporal** dimension unique to this dataset family: `triples_{1,2}` rows
are 5 columns, `(head_id, relation_id, tail_id, time_start_id,
time_end_id)`, and a `time_id` file maps those ids to `"YYYY-MM"` strings
(or a value starting with ``-`` / an empty string, both of which
`utils.py`'s own loader treats as "unknown/open", denoted ``~`` there).
This module encodes both bounds into the canonical contract's single
`timestamp` column as `"{start}/{end}"` (each side `~` if unresolved)
rather than dropping the interval information or fabricating a single
point estimate.

Entity/relation "ids" on the ICEWS side are already human-readable text
(e.g. ``"Make pessimistic comment"``), not URIs, unlike every other base
graph this project has integrated so far; the Wikipedia side uses full
`https://en.wikipedia.org/wiki/...` URLs. Because the two sides are not
both URI-shaped, canonical entity/relation ids are synthesized as
`f"{dataset_id}:{graph_id}:{numeric_id}"` for both sides uniformly, and
the original text/URL is preserved verbatim as the `label`.
"""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

from pkgea.contracts import validate_dataset


def _id_text_rows(path: Path) -> list[tuple[str, str]]:
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.rstrip("\n")
            if not line:
                continue
            parts = line.split("\t", 1)
            if len(parts) != 2:
                raise ValueError(f"{path}:{line_number} expected 2 tab-separated fields")
            rows.append((parts[0], parts[1]))
    return rows


def _quintuple_rows(path: Path) -> list[tuple[str, str, str, str, str]]:
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for line_number, row in enumerate(csv.reader(handle, delimiter="\t"), start=1):
            if len(row) != 5:
                raise ValueError(f"{path}:{line_number} expected 5 columns, got {len(row)}")
            rows.append((row[0], row[1], row[2], row[3], row[4]))
    return rows


def _pair_rows(path: Path) -> list[tuple[str, str]]:
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for line_number, row in enumerate(csv.reader(handle, delimiter="\t"), start=1):
            if len(row) != 2:
                raise ValueError(f"{path}:{line_number} expected 2 columns, got {len(row)}")
            rows.append((row[0], row[1]))
    return rows


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write(path: Path, fields: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def convert_hhea_temporal(
    input_dir: str | Path,
    output_dir: str | Path,
    *,
    dataset_id: str,
    source_note: str = "",
) -> Path:
    """Convert one Simple-HHEA temporal pair (e.g. icews_wiki) to the contract."""

    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")

    required = [
        source / "ent_ids_1",
        source / "ent_ids_2",
        source / "rel_ids_1",
        source / "rel_ids_2",
        source / "triples_1",
        source / "triples_2",
        source / "sup_pairs",
        source / "ref_pairs",
        source / "time_id",
    ]
    missing = [path for path in required if not path.is_file()]
    if missing:
        raise ValueError(f"HHEA input files missing: {', '.join(map(str, missing))}")

    id_to_text = {
        "source": dict(_id_text_rows(source / "ent_ids_1")),
        "target": dict(_id_text_rows(source / "ent_ids_2")),
    }
    rel_id_to_text = {
        "source": dict(_id_text_rows(source / "rel_ids_1")),
        "target": dict(_id_text_rows(source / "rel_ids_2")),
    }
    time_id_to_text = dict(_id_text_rows(source / "time_id"))

    def resolve_time(time_id: str) -> str:
        text = time_id_to_text.get(time_id, "")
        if text == "" or text.startswith("-"):
            return "~"
        return text

    def entity_id(graph_id: str, raw: str) -> str:
        return f"{dataset_id}:{graph_id}:{raw}"

    def relation_id(graph_id: str, raw: str) -> str:
        return f"{dataset_id}:{graph_id}:rel:{raw}"

    triples_by_graph = {
        "source": _quintuple_rows(source / "triples_1"),
        "target": _quintuple_rows(source / "triples_2"),
    }
    triple_rows = []
    time_span_stats = {"resolved_both": 0, "unresolved_start": 0, "unresolved_end": 0}
    for graph_id, quintuples in triples_by_graph.items():
        for index, (head, relation, tail, time_start, time_end) in enumerate(quintuples):
            start_text = resolve_time(time_start)
            end_text = resolve_time(time_end)
            if start_text == "~":
                time_span_stats["unresolved_start"] += 1
            if end_text == "~":
                time_span_stats["unresolved_end"] += 1
            if start_text != "~" and end_text != "~":
                time_span_stats["resolved_both"] += 1
            triple_rows.append(
                {
                    "graph_id": graph_id,
                    "head_id": entity_id(graph_id, head),
                    "relation_id": relation_id(graph_id, relation),
                    "tail_id": entity_id(graph_id, tail),
                    "confidence": "1",
                    "confidence_type": "calibrated_probability",
                    "confidence_source": "deterministic_hhea_temporal_base",
                    "normalization_method": "identity",
                    "timestamp": f"{start_text}/{end_text}",
                    "dependency_group": "",
                    "evidence_id": f"hhea:{dataset_id}:{graph_id}:{index}",
                }
            )

    entity_ids_referenced = {"source": set(), "target": set()}
    relation_ids_referenced = {"source": set(), "target": set()}
    for graph_id, quintuples in triples_by_graph.items():
        for head, relation, tail, _ts, _te in quintuples:
            entity_ids_referenced[graph_id].update((head, tail))
            relation_ids_referenced[graph_id].add(relation)

    train_pairs = _pair_rows(source / "sup_pairs")
    test_pairs = _pair_rows(source / "ref_pairs")
    alignment_rows = []
    for split_label, pairs in (("train", train_pairs), ("test", test_pairs)):
        for left_id, right_id in pairs:
            entity_ids_referenced["source"].add(left_id)
            entity_ids_referenced["target"].add(right_id)
            alignment_rows.append(
                {
                    "source_entity_id": entity_id("source", left_id),
                    "target_entity_id": entity_id("target", right_id),
                    "split": split_label,
                    "confidence": "1",
                }
            )

    entity_rows = [
        {
            "graph_id": graph_id,
            "entity_id": entity_id(graph_id, raw),
            "label": id_to_text[graph_id].get(raw, raw),
        }
        for graph_id in ("source", "target")
        for raw in sorted(entity_ids_referenced[graph_id], key=lambda v: int(v))
    ]
    relation_rows = [
        {
            "graph_id": graph_id,
            "relation_id": relation_id(graph_id, raw),
            "label": rel_id_to_text[graph_id].get(raw, raw),
        }
        for graph_id in ("source", "target")
        for raw in sorted(relation_ids_referenced[graph_id], key=lambda v: int(v))
    ]

    output.mkdir(parents=True)
    _write(output / "entities.tsv", ["graph_id", "entity_id", "label"], entity_rows)
    _write(output / "relations.tsv", ["graph_id", "relation_id", "label"], relation_rows)
    _write(
        output / "triples.tsv",
        [
            "graph_id",
            "head_id",
            "relation_id",
            "tail_id",
            "confidence",
            "confidence_type",
            "confidence_source",
            "normalization_method",
            "timestamp",
            "dependency_group",
            "evidence_id",
        ],
        triple_rows,
    )
    _write(
        output / "alignments.tsv",
        ["source_entity_id", "target_entity_id", "split", "confidence"],
        alignment_rows,
    )
    metadata = {
        "dataset_id": f"hhea-{dataset_id}",
        "version": "Simple-HHEA-2024-github-bundled",
        "probability_semantics": (
            "Deterministic real-world temporal base graph; confidence 1 denotes a "
            "fact materialized in the released triples file."
        ),
        "edge_dependence": {"assumption": "deterministic", "dependency_groups": []},
        "generation": {
            "converter": "pkgea.data.hhea.convert_hhea_temporal",
            "source_note": source_note,
            "input_checksums_sha256": {
                str(path.relative_to(source)): _sha256(path) for path in required
            },
            "timestamp_encoding": (
                "\"{start}/{end}\" using time_id-resolved YYYY-MM strings; "
                "'~' denotes an id that time_id records as unresolved/open "
                "(empty string or a value starting with '-', following "
                "utils.py's own convention in the Simple-HHEA repo)."
            ),
            "time_span_stats": time_span_stats,
        },
        "source": "https://github.com/DataArcTech/Simple-HHEA",
        "license_status": (
            "Unresolved. No LICENSE file was found in the DataArcTech/Simple-HHEA "
            "repository at clone time. ICEWS event data and Wikipedia/Wikidata-"
            "derived content each carry their own upstream terms that were not "
            "independently verified in this pass. Treat as local-research-only."
        ),
        "known_limitations": [
            "Entity/relation ids are synthesized as f'{dataset_id}:{graph}:{raw_id}' "
            "because ICEWS-side labels are plain text, not URIs, unlike this "
            "project's other base graphs; the original text/URL is preserved as label.",
            "Train/test only (sup_pairs/ref_pairs); no validation split in the "
            "released data.",
            "Temporal bounds are encoded as a single 'start/end' timestamp string "
            "rather than as two separate contract columns, since the shared "
            "contract schema has one timestamp field.",
            "IDEA-FinAI/Simple-HHEA (the other org name that surfaced in search) "
            "returns HTTP 404 and does not exist; DataArcTech/Simple-HHEA was used "
            "as the sole verified canonical repo.",
        ],
    }
    (output / "confidence_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    validate_dataset(output)
    return output
