"""Convert a DAEA real-world dataset (DOREMUS, AGROLD) to the canonical contract.

Source: https://github.com/yangxiaoxiaoly/DAEA (Yang et al., COLING 2025,
"DAEA: Enhancing Entity Alignment in Real-World Knowledge Graphs Through
Multi-Source Domain Adaptation"). The repository itself ships no dataset
files -- only a single combined Google Drive archive
(`data.zip`, 531 MB, https://drive.google.com/file/d/1OXzwPve7PT1jRHfdZajNro2MYM4I7Lc0)
covering DBP15K plus two "real-world" pairs, `data/doremus_en/` and
`data/agrold_en/`. Only those two real-world pairs are handled here; DBP15K
is already covered by `pkgea.data.jape`.

Both real-world pairs use the GCN-Align/JAPE numeric-id convention:
`ent_ids_{1,2}` and `rel_ids_{1,2}` map integer ids to URIs, `triples_{1,2}`
are `(head_id, relation_id, tail_id)` rows, `sup_pairs`/`ref_pairs` are
`(id_1, id_2)` alignment pairs. `DAEA/basic_bert_unit/Read_data_func.py`
and `interaction_model/read_data_func.py` both read `sup_pairs` as the
train seed alignment and `ref_pairs` as the held-out test alignment; that
convention is preserved here (train/test only, no validation split, same
as `pkgea.data.jape`'s DBP15K 0_3 split).

Attribute triples ship as loose N-Triples-style lines
(`<subject> <predicate> "literal"[@lang] .`), one file per graph side
(e.g. `doremus_att_triples` for graph 1, `en_att_triples` for graph 2 in
the DOREMUS pair). Rather than trust the filename-to-graph mapping, rows
are routed by checking which graph's `ent_ids_*` set contains the subject
URI (verified: for the DOREMUS pair this routing is unambiguous -- every
sampled row belongs to exactly one graph, never both, never neither).

Both DOREMUS and AGROLD graphs share a striking property worth flagging
explicitly: entity URIs on both sides of the pair sit in the *same*
namespace (e.g. both `data.doremus.org`/`erlangen-crm.org` for DOREMUS,
both `southgreen.fr`/`purl.obolibrary.org`/`identifiers.org` for AGROLD).
Sampled `ref_pairs`/`sup_pairs` rows resolve to two distinct URIs (distinct
UUIDs/local names) for what the alignment file asserts is the same
real-world entity. This looks like within-source duplicate-record
resolution over an aggregated catalog (DOREMUS aggregates multiple
contributing institutions' catalogs; AGROLD fuses several agronomy
ontologies/databases) rather than a cross-KG pairing in the DBpedia-vs-
Wikidata sense OpenEA/DBP15K/EventEA use. It is still a real alignment
problem over real, independently-curated source records -- just a
different flavor of "real" than the other base graphs in this project.
See the DOREMUS/AGROLD dataset cards for the full discussion.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path

from pkgea.contracts import validate_dataset

_ATTRIBUTE_LINE = re.compile(r"^<([^>]+)>\s+<([^>]+)>\s+(.*)\s+\.\s*$")
_TRAILING_LANG_OR_TYPE = re.compile(r'^"(.*)"(?:@[A-Za-z-]+|\^\^<[^>]+>)?$')


def _id_uri_rows(path: Path) -> list[tuple[str, str]]:
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for line_number, row in enumerate(csv.reader(handle, delimiter="\t"), start=1):
            if len(row) != 2:
                raise ValueError(f"{path}:{line_number} expected 2 columns, got {len(row)}")
            rows.append((row[0], row[1]))
    return rows


def _triple_rows(path: Path) -> list[tuple[str, str, str]]:
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for line_number, row in enumerate(csv.reader(handle, delimiter="\t"), start=1):
            if len(row) != 3:
                raise ValueError(f"{path}:{line_number} expected 3 columns, got {len(row)}")
            rows.append((row[0], row[1], row[2]))
    return rows


def _pair_rows(path: Path) -> list[tuple[str, str]]:
    return [(a, b) for a, b in _id_uri_rows(path)]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _uri_label(uri: str) -> str:
    tail = uri.rsplit("/", 1)[-1].rsplit("#", 1)[-1]
    return tail.replace("_", " ")


def _parse_attribute_literal(raw: str) -> str:
    """Best-effort literal extraction from an N-Triples-style object.

    Strips a trailing language tag (``@en``) or datatype IRI (``^^<...>``)
    and the surrounding quotes. This is not a full N-Triples parser: it
    does not unescape backslash sequences inside the literal. Values are
    otherwise preserved verbatim, matching this project's convention of
    not fabricating cleaner data than what was released.
    """

    match = _TRAILING_LANG_OR_TYPE.match(raw.strip())
    if match:
        return match.group(1)
    return raw.strip()


def _write(path: Path, fields: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def convert_daea_realworld(
    input_dir: str | Path,
    output_dir: str | Path,
    *,
    dataset_id: str,
    graph1_attribute_file: str,
    graph2_attribute_file: str,
    source_note: str = "",
) -> Path:
    """Convert one DAEA real-world pair (DOREMUS or AGROLD) to the contract."""

    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")

    required = [
        source / "ent_ids_1",
        source / "ent_ids_2",
        source / "rel_ids_1",
        source / "rel_ids_2",
        source / "triples_1",
        source / "triples_2",
        source / "sup_pairs",
        source / "ref_pairs",
    ]
    missing = [path for path in required if not path.is_file()]
    if missing:
        raise ValueError(f"DAEA input files missing: {', '.join(map(str, missing))}")

    id_to_uri = {
        "source": dict(_id_uri_rows(source / "ent_ids_1")),
        "target": dict(_id_uri_rows(source / "ent_ids_2")),
    }
    rel_id_to_uri = {
        "source": dict(_id_uri_rows(source / "rel_ids_1")),
        "target": dict(_id_uri_rows(source / "rel_ids_2")),
    }
    triples_by_graph = {
        "source": _triple_rows(source / "triples_1"),
        "target": _triple_rows(source / "triples_2"),
    }

    entity_uris = {"source": set(id_to_uri["source"].values()), "target": set(id_to_uri["target"].values())}
    relation_uris = {"source": set(), "target": set()}
    triple_rows = []
    for graph_id, triples in triples_by_graph.items():
        for index, (head_id, relation_id, tail_id) in enumerate(triples):
            head_uri = id_to_uri[graph_id][head_id]
            tail_uri = id_to_uri[graph_id][tail_id]
            relation_uri = rel_id_to_uri[graph_id][relation_id]
            relation_uris[graph_id].add(relation_uri)
            triple_rows.append(
                {
                    "graph_id": graph_id,
                    "head_id": head_uri,
                    "relation_id": relation_uri,
                    "tail_id": tail_uri,
                    "confidence": "1",
                    "confidence_type": "calibrated_probability",
                    "confidence_source": "deterministic_daea_realworld_base",
                    "normalization_method": "identity",
                    "timestamp": "",
                    "dependency_group": "",
                    "evidence_id": f"daea:{dataset_id}:{graph_id}:{index}",
                }
            )

    train_pairs = _pair_rows(source / "sup_pairs")
    test_pairs = _pair_rows(source / "ref_pairs")
    alignment_rows = []
    for split_label, pairs in (("train", train_pairs), ("test", test_pairs)):
        for left_id, right_id in pairs:
            left_uri = id_to_uri["source"][left_id]
            right_uri = id_to_uri["target"][right_id]
            alignment_rows.append(
                {
                    "source_entity_id": left_uri,
                    "target_entity_id": right_uri,
                    "split": split_label,
                    "confidence": "1",
                }
            )

    entity_rows = [
        {"graph_id": graph_id, "entity_id": uri, "label": _uri_label(uri)}
        for graph_id in ("source", "target")
        for uri in sorted(entity_uris[graph_id])
    ]
    relation_rows = [
        {"graph_id": graph_id, "relation_id": uri, "label": _uri_label(uri)}
        for graph_id in ("source", "target")
        for uri in sorted(relation_uris[graph_id])
    ]

    attribute_rows: list[dict[str, str]] = []
    attribute_file_stats = {}
    for filename in {graph1_attribute_file, graph2_attribute_file}:
        path = source / filename
        if not path.is_file():
            raise ValueError(f"DAEA attribute file missing: {path}")
        matched = {"source": 0, "target": 0, "unmatched": 0}
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                match = _ATTRIBUTE_LINE.match(line.rstrip("\n"))
                if not match:
                    matched["unmatched"] += 1
                    continue
                subject, predicate, literal = match.groups()
                if subject in entity_uris["source"]:
                    graph_id = "source"
                elif subject in entity_uris["target"]:
                    graph_id = "target"
                else:
                    matched["unmatched"] += 1
                    continue
                matched[graph_id] += 1
                attribute_rows.append(
                    {
                        "graph_id": graph_id,
                        "entity_id": subject,
                        "attribute_id": predicate,
                        "value": _parse_attribute_literal(literal),
                    }
                )
        attribute_file_stats[filename] = matched

    output.mkdir(parents=True)
    _write(output / "entities.tsv", ["graph_id", "entity_id", "label"], entity_rows)
    _write(output / "relations.tsv", ["graph_id", "relation_id", "label"], relation_rows)
    _write(
        output / "triples.tsv",
        [
            "graph_id",
            "head_id",
            "relation_id",
            "tail_id",
            "confidence",
            "confidence_type",
            "confidence_source",
            "normalization_method",
            "timestamp",
            "dependency_group",
            "evidence_id",
        ],
        triple_rows,
    )
    _write(
        output / "alignments.tsv",
        ["source_entity_id", "target_entity_id", "split", "confidence"],
        alignment_rows,
    )
    if attribute_rows:
        _write(
            output / "attributes.tsv",
            ["graph_id", "entity_id", "attribute_id", "value"],
            attribute_rows,
        )
    metadata = {
        "dataset_id": f"daea-{dataset_id}",
        "version": "DAEA-realworld-2024-drive-archive",
        "probability_semantics": (
            "Deterministic real-world base graph; confidence 1 denotes a fact "
            "materialized in the released triples file."
        ),
        "edge_dependence": {"assumption": "deterministic", "dependency_groups": []},
        "generation": {
            "converter": "pkgea.data.daea.convert_daea_realworld",
            "source_note": source_note,
            "input_checksums_sha256": {
                str(path.relative_to(source)): _sha256(path) for path in required
            },
            "attribute_triples": len(attribute_rows),
            "attribute_file_routing": attribute_file_stats,
        },
        "source": "https://github.com/yangxiaoxiaoly/DAEA",
        "license_status": (
            "Unresolved. The DAEA repository states no dataset license (its code "
            "is unlicensed on GitHub). The real-world pairs are attributed in the "
            "DAEA README to https://github.com/EnsiyehRaoufi/Create_Input_Data_to_EA_Models, "
            "which was not independently checked for a license. DOREMUS's own linked-data "
            "platform and AGROLD's underlying ontologies/databases each carry their own "
            "upstream terms that were not verified in this pass. Treat as local-research-only."
        ),
        "known_limitations": [
            "Train/test only; the original sup_pairs/ref_pairs split has no validation set.",
            (
                "Entity URIs on both graph sides sit in the same source namespace "
                "(not a DBpedia-vs-Wikidata-style cross-KG pairing); sampled aligned "
                "pairs resolve to two distinct URIs for what ref_pairs/sup_pairs assert "
                "is one real-world entity, consistent with within-source duplicate-"
                "record resolution rather than classic cross-KG EA. See the dataset card."
            ),
            (
                "Attribute literals are extracted with a best-effort N-Triples-style "
                "regex (strips outer quotes and a trailing @lang/^^datatype); it does "
                "not unescape backslash sequences inside the literal."
            ),
            "Attribute-to-graph routing is by entity-URI membership, not filename; "
            "verified unambiguous on a full pass (see attribute_file_routing above).",
        ],
    }
    (output / "confidence_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    validate_dataset(output)
    return output
