"""Extract a deterministic aligned probe from a large canonical dataset."""

from __future__ import annotations

import csv
import json
import random
from collections import deque
from pathlib import Path

from pkgea.contracts import provenance_path, validate_dataset


def _read_tsv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        return list(reader.fieldnames or []), list(reader)


def _write_tsv(
    path: Path, fieldnames: list[str], rows: list[dict[str, str]]
) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(rows)


def _shortest_paths(
    adjacency: dict[str, list[tuple[str, int]]],
    start: str,
    max_hops: int,
) -> tuple[dict[str, int], dict[str, tuple[str, int]]]:
    distances = {start: 0}
    parents: dict[str, tuple[str, int]] = {}
    queue = deque([start])
    while queue:
        node = queue.popleft()
        if distances[node] >= max_hops:
            continue
        for neighbor, edge_index in adjacency.get(node, []):
            if neighbor in distances:
                continue
            distances[neighbor] = distances[node] + 1
            parents[neighbor] = (node, edge_index)
            queue.append(neighbor)
    return distances, parents


def _path_edges(
    parents: dict[str, tuple[str, int]],
    start: str,
    end: str,
) -> set[int]:
    edges: set[int] = set()
    cursor = end
    while cursor != start:
        parent, edge_index = parents[cursor]
        edges.add(edge_index)
        cursor = parent
    return edges


def extract_aligned_probe(
    input_dir: str | Path,
    output_dir: str | Path,
    *,
    pair_count: int = 32,
    max_edges_per_graph: int = 128,
    split: str = "test",
    anchor_count: int = 0,
    anchor_split: str = "train",
    anchor_selection: str = "random",
    connection_hops: int = 4,
    seed: int = 17,
) -> Path:
    """Select aligned query pairs and bounded incident neighborhoods."""

    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    validate_dataset(source)
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")
    if pair_count <= 0 or max_edges_per_graph <= 0 or anchor_count < 0:
        raise ValueError(
            "pair_count/max_edges_per_graph must be positive and anchor_count nonnegative"
        )
    if anchor_count and anchor_split == split:
        raise ValueError("anchor_split must differ from query split")
    if anchor_selection not in {"random", "nearest_joint"}:
        raise ValueError("anchor_selection must be random or nearest_joint")
    if connection_hops <= 0:
        raise ValueError("connection_hops must be positive")

    entity_fields, entities = _read_tsv(source / "entities.tsv")
    relation_fields, relations = _read_tsv(source / "relations.tsv")
    triple_fields, triples = _read_tsv(source / "triples.tsv")
    alignment_fields, alignments = _read_tsv(source / "alignments.tsv")
    attribute_fields: list[str] = []
    attributes: list[dict[str, str]] = []
    if (source / "attributes.tsv").is_file():
        attribute_fields, attributes = _read_tsv(source / "attributes.tsv")
    eligible = [row for row in alignments if row["split"] == split]
    if len(eligible) < pair_count:
        raise ValueError(
            f"Requested {pair_count} {split} pairs, only {len(eligible)} available"
        )
    rng = random.Random(seed)
    query_alignments = rng.sample(eligible, pair_count)
    anchor_eligible = [
        row for row in alignments if row["split"] == anchor_split
    ]
    if len(anchor_eligible) < anchor_count:
        raise ValueError(
            f"Requested {anchor_count} {anchor_split} anchors, "
            f"only {len(anchor_eligible)} available"
        )
    required_edge_indices: set[int] = set()
    if anchor_selection == "nearest_joint" and anchor_count:
        adjacency: dict[str, dict[str, list[tuple[str, int]]]] = {
            "source": {},
            "target": {},
        }
        for edge_index, row in enumerate(triples):
            graph = adjacency[row["graph_id"]]
            graph.setdefault(row["head_id"], []).append(
                (row["tail_id"], edge_index)
            )
            graph.setdefault(row["tail_id"], []).append(
                (row["head_id"], edge_index)
            )
        for graph in adjacency.values():
            for neighbors in graph.values():
                neighbors.sort(key=lambda item: (item[0], item[1]))

        ranked_per_query: list[
            list[
                tuple[
                    tuple[int, int, str, str],
                    dict[str, str],
                    set[int],
                ]
            ]
        ] = []
        for query in query_alignments:
            source_distances, source_parents = _shortest_paths(
                adjacency["source"],
                query["source_entity_id"],
                connection_hops,
            )
            target_distances, target_parents = _shortest_paths(
                adjacency["target"],
                query["target_entity_id"],
                connection_hops,
            )
            ranked = []
            for anchor in anchor_eligible:
                source_anchor = anchor["source_entity_id"]
                target_anchor = anchor["target_entity_id"]
                if (
                    source_anchor not in source_distances
                    or target_anchor not in target_distances
                ):
                    continue
                source_distance = source_distances[source_anchor]
                target_distance = target_distances[target_anchor]
                path = _path_edges(
                    source_parents,
                    query["source_entity_id"],
                    source_anchor,
                )
                path.update(
                    _path_edges(
                        target_parents,
                        query["target_entity_id"],
                        target_anchor,
                    )
                )
                ranked.append(
                    (
                        (
                            max(source_distance, target_distance),
                            source_distance + target_distance,
                            source_anchor,
                            target_anchor,
                        ),
                        anchor,
                        path,
                    )
                )
            ranked.sort(key=lambda item: item[0])
            ranked_per_query.append(ranked)

        anchor_alignments = []
        selected_anchor_keys: set[tuple[str, str]] = set()
        cursors = [0 for _ in ranked_per_query]
        while len(anchor_alignments) < anchor_count:
            added = False
            for query_index, ranked in enumerate(ranked_per_query):
                while cursors[query_index] < len(ranked):
                    _, anchor, path = ranked[cursors[query_index]]
                    cursors[query_index] += 1
                    key = (
                        anchor["source_entity_id"],
                        anchor["target_entity_id"],
                    )
                    if key not in selected_anchor_keys:
                        selected_anchor_keys.add(key)
                        anchor_alignments.append(anchor)
                        required_edge_indices.update(path)
                        added = True
                        break
                if len(anchor_alignments) == anchor_count:
                    break
            if not added:
                raise ValueError(
                    f"Could connect only {len(anchor_alignments)} unique "
                    f"anchors within {connection_hops} hops; requested "
                    f"{anchor_count}"
                )
    else:
        anchor_alignments = rng.sample(anchor_eligible, anchor_count)
    selected_alignments = [*anchor_alignments, *query_alignments]
    selected_ids = {
        "source": {row["source_entity_id"] for row in selected_alignments},
        "target": {row["target_entity_id"] for row in selected_alignments},
    }

    selected_triples: list[dict[str, str]] = []
    for graph_id in ("source", "target"):
        required = [
            row
            for edge_index, row in enumerate(triples)
            if edge_index in required_edge_indices
            and row["graph_id"] == graph_id
        ]
        required_keys = {
            (row["head_id"], row["relation_id"], row["tail_id"])
            for row in required
        }
        incident = [
            row
            for row in triples
            if row["graph_id"] == graph_id
            and (
                row["head_id"] in selected_ids[graph_id]
                or row["tail_id"] in selected_ids[graph_id]
            )
            and (
                row["head_id"],
                row["relation_id"],
                row["tail_id"],
            )
            not in required_keys
        ]
        incident.sort(
            key=lambda row: (
                row["head_id"],
                row["relation_id"],
                row["tail_id"],
            )
        )
        if len(required) > max_edges_per_graph:
            raise ValueError(
                f"Required {len(required)} {graph_id} path edges exceed "
                f"max_edges_per_graph={max_edges_per_graph}"
            )
        remaining = max_edges_per_graph - len(required)
        if len(incident) > remaining:
            incident = rng.sample(incident, remaining)
        graph_triples = [*required, *incident]
        graph_triples.sort(
            key=lambda row: (
                row["head_id"],
                row["relation_id"],
                row["tail_id"],
            )
        )
        selected_triples.extend(graph_triples)
        for row in graph_triples:
            selected_ids[graph_id].update((row["head_id"], row["tail_id"]))

    selected_relations = {
        (row["graph_id"], row["relation_id"]) for row in selected_triples
    }
    selected_entities = [
        row
        for row in entities
        if row["entity_id"] in selected_ids[row["graph_id"]]
    ]
    selected_relation_rows = [
        row
        for row in relations
        if (row["graph_id"], row["relation_id"]) in selected_relations
    ]

    output.mkdir(parents=True)
    _write_tsv(output / "entities.tsv", entity_fields, selected_entities)
    _write_tsv(output / "relations.tsv", relation_fields, selected_relation_rows)
    _write_tsv(output / "triples.tsv", triple_fields, selected_triples)
    _write_tsv(
        output / "alignments.tsv", alignment_fields, selected_alignments
    )
    if attributes:
        selected_attributes = [
            row
            for row in attributes
            if row["entity_id"] in selected_ids[row["graph_id"]]
        ]
        _write_tsv(
            output / "attributes.tsv", attribute_fields, selected_attributes
        )
    metadata = {
        "dataset_id": (
            f"{source.name}-probe-q{pair_count}-a{anchor_count}-seed{seed}"
        ),
        "version": "0.1.0",
        "base_dataset": provenance_path(source),
        "probability_semantics": (
            "Probe preserves the canonical base graph confidence semantics."
        ),
        "edge_dependence": {"assumption": "inherited_from_base"},
        "generation": {
            "kind": "aligned_incident_probe",
            "pair_count": pair_count,
            "query_pair_count": pair_count,
            "anchor_count": anchor_count,
            "anchor_split": anchor_split,
            "anchor_selection": anchor_selection,
            "connection_hops": connection_hops,
            "required_connection_edges": len(required_edge_indices),
            "max_edges_per_graph": max_edges_per_graph,
            "split": split,
            "seed": seed,
        },
        "source": "deterministic extraction from canonical dataset",
        "license_status": "inherits base dataset",
        "known_limitations": [
            "Incident-edge cap changes degree distributions.",
            "Only selected query pairs and training anchors are retained.",
            "Attributes are retained only for entities present in the probe.",
            (
                "nearest_joint preserves bounded shortest paths from queries "
                "to selected anchors, not the complete induced neighborhood."
            ),
        ],
    }
    with (output / "confidence_metadata.json").open(
        "w", encoding="utf-8", newline="\n"
    ) as handle:
        json.dump(metadata, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    validate_dataset(output)
    return output
