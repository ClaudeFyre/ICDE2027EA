"""Explicit heuristic-score mappings for probability sensitivity analysis."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import shutil
from pathlib import Path

from pkgea.contracts import provenance_path, validate_dataset


def _temperature_map(score: float, temperature: float) -> float:
    clipped = min(max(score, 1e-9), 1.0 - 1e-9)
    logit = math.log(clipped / (1.0 - clipped))
    return 1.0 / (1.0 + math.exp(-logit / temperature))


def map_heuristic_confidences(
    input_dir: str | Path,
    output_dir: str | Path,
    *,
    temperature: float,
) -> Path:
    """Map heuristic weights monotonically without claiming calibration."""

    if temperature <= 0.0 or not math.isfinite(temperature):
        raise ValueError("temperature must be finite and positive")
    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    validate_dataset(source)
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")
    output.mkdir(parents=True)
    for filename in (
        "entities.tsv",
        "relations.tsv",
        "alignments.tsv",
        "attributes.tsv",
    ):
        path = source / filename
        if path.is_file():
            shutil.copy2(path, output / filename)
    with (source / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        fields = list(reader.fieldnames or [])
        rows = list(reader)
    observed_types = {row["confidence_type"] for row in rows}
    if observed_types != {"normalized_heuristic_weight"}:
        raise ValueError(
            "Heuristic mapping requires only normalized_heuristic_weight inputs"
        )
    with (output / "triples.tsv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        for row in rows:
            mapped = _temperature_map(
                float(row["confidence"]),
                temperature,
            )
            updated = dict(row)
            updated["confidence"] = f"{mapped:.12g}"
            updated["confidence_type"] = "assumed_probability_mapping"
            updated["confidence_source"] = (
                f"{row['confidence_source']}; unsupervised sensitivity mapping"
            )
            updated["normalization_method"] = (
                f"heuristic_logit_temperature_T={temperature:g}"
            )
            writer.writerow(updated)
    metadata = json.loads(
        (source / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    metadata["dataset_id"] = (
        f"{metadata['dataset_id']}-heuristic-temperature-{temperature:g}"
    )
    metadata["base_dataset"] = provenance_path(source)
    metadata["probability_semantics"] = (
        "Mapped values are assumed Bernoulli probabilities for sensitivity "
        "analysis only; no calibration labels or probability guarantee exist."
    )
    metadata["confidence_mapping"] = {
        "input_type": "normalized_heuristic_weight",
        "output_type": "assumed_probability_mapping",
        "method": "logit_temperature",
        "temperature": temperature,
        "supervised_calibration": False,
        "monotonic_rank_preserving": True,
    }
    limitations = list(metadata.get("known_limitations", []))
    limitations.append(
        "The heuristic-to-probability mapping is an assumption axis, not a "
        "fitted or validated calibration model."
    )
    metadata["known_limitations"] = limitations
    (output / "confidence_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    validate_dataset(output)
    return output


def mask_cross_graph_entity_labels(
    input_dir: str | Path,
    output_dir: str | Path,
) -> Path:
    """Replace labels with graph-salted opaque identifiers."""

    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    validate_dataset(source)
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")
    output.mkdir(parents=True)
    for filename in (
        "relations.tsv",
        "triples.tsv",
        "alignments.tsv",
        "attributes.tsv",
    ):
        path = source / filename
        if path.is_file():
            shutil.copy2(path, output / filename)
    with (source / "entities.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        fields = list(reader.fieldnames or [])
        entities = list(reader)
    with (output / "entities.tsv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        for row in entities:
            updated = dict(row)
            updated["label"] = hashlib.sha256(
                f"{row['graph_id']}\0{row['entity_id']}".encode("utf-8")
            ).hexdigest()
            writer.writerow(updated)
    metadata = json.loads(
        (source / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    metadata["dataset_id"] = f"{metadata['dataset_id']}-opaque-labels"
    metadata["base_dataset"] = provenance_path(source)
    metadata["entity_label_view"] = {
        "mode": "graph_salted_sha256",
        "cross_graph_lexical_signal": False,
        "purpose": "structure/probability sensitivity control",
    }
    limitations = list(metadata.get("known_limitations", []))
    limitations.append(
        "Opaque labels remove real lexical evidence and are only a controlled "
        "ablation."
    )
    metadata["known_limitations"] = limitations
    (output / "confidence_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    validate_dataset(output)
    return output
