"""Construct two evidence views from a scored uncertain knowledge graph."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

from pkgea.contracts import validate_dataset


def _read_id_map(path: Path) -> dict[str, str]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows or len(rows[0]) != 2:
        raise ValueError(f"Expected a two-column ID map: {path}")
    label_column, id_column = tuple(rows[0])
    return {row[id_column]: row[label_column] for row in rows}


def _fraction(token: str) -> float:
    digest = hashlib.sha256(token.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") / 2**64


def _raw_id_sort_key(value: str) -> tuple[int, object]:
    """Sort numeric raw ids numerically; fall back to string order otherwise.

    Some packagings (e.g. CN15K/PPI5K via BEUrRE/unKR) use bare integer raw
    ids. Others (e.g. NL27K's own UKGE release) use the entity/relation
    string itself as the raw id, with no numeric id map at all. Both must
    sort deterministically without raising.
    """

    try:
        return (0, int(value))
    except ValueError:
        return (1, value)


def _write_tsv(
    path: Path, fieldnames: list[str], rows: list[dict[str, str]]
) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def convert_scored_ukg_to_views(
    input_dir: str | Path,
    output_dir: str | Path,
    *,
    entity_map_name: str,
    relation_map_name: str,
    dataset_id: str,
    seed: int = 17,
    source_retention: float = 0.8,
    target_retention: float = 0.8,
    train_ratio: float = 0.2,
    validation_ratio: float = 0.1,
) -> Path:
    """Create two reproducible partial graph views with identity alignments.

    Input split files are headerless ``head relation tail score`` TSV files.
    Released scores are preserved as normalized heuristic weights.  They are
    never relabeled as calibrated probabilities.
    """

    if not 0.0 < source_retention <= 1.0:
        raise ValueError("source_retention must be in (0, 1]")
    if not 0.0 < target_retention <= 1.0:
        raise ValueError("target_retention must be in (0, 1]")
    if not 0.0 < train_ratio < 1.0:
        raise ValueError("train_ratio must be in (0, 1)")
    if not 0.0 <= validation_ratio < 1.0:
        raise ValueError("validation_ratio must be in [0, 1)")
    if train_ratio + validation_ratio >= 1.0:
        raise ValueError("train and validation ratios must sum to < 1")
    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")
    entity_labels = _read_id_map(source / entity_map_name)
    relation_labels = _read_id_map(source / relation_map_name)

    facts: dict[tuple[str, str, str], float] = {}
    input_checksums = {}
    for split_name in ("train.tsv", "val.tsv", "test.tsv"):
        path = source / split_name
        input_checksums[split_name] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            for line_number, row in enumerate(
                csv.reader(handle, delimiter="\t"), start=1
            ):
                if len(row) != 4:
                    raise ValueError(
                        f"{split_name}:{line_number} must have four columns"
                    )
                head, relation, tail, raw_score = row
                if head not in entity_labels or tail not in entity_labels:
                    raise ValueError(
                        f"{split_name}:{line_number} references unknown entity"
                    )
                if relation not in relation_labels:
                    raise ValueError(
                        f"{split_name}:{line_number} references unknown relation"
                    )
                score = float(raw_score)
                if not 0.0 <= score <= 1.0:
                    raise ValueError(
                        f"{split_name}:{line_number} score is outside [0, 1]"
                    )
                key = (head, relation, tail)
                facts[key] = max(facts.get(key, 0.0), score)

    graph_facts: dict[str, list[tuple[tuple[str, str, str], float]]] = {
        "source": [],
        "target": [],
    }
    retentions = {
        "source": source_retention,
        "target": target_retention,
    }
    for key, score in sorted(facts.items()):
        signature = "\t".join(key)
        for graph_id in ("source", "target"):
            if _fraction(f"{seed}|{graph_id}|{signature}") < retentions[graph_id]:
                graph_facts[graph_id].append((key, score))
    if any(not rows for rows in graph_facts.values()):
        raise ValueError("retention configuration produced an empty graph view")

    graph_entities = {
        graph_id: {
            entity
            for (head, _, tail), _ in rows
            for entity in (head, tail)
        }
        for graph_id, rows in graph_facts.items()
    }
    graph_relations = {
        graph_id: {relation for (_, relation, _), _ in rows}
        for graph_id, rows in graph_facts.items()
    }

    def entity_id(graph_id: str, raw: str) -> str:
        return f"{dataset_id}:{graph_id}:entity:{raw}"

    def relation_id(graph_id: str, raw: str) -> str:
        return f"{dataset_id}:{graph_id}:relation:{raw}"

    entity_rows = [
        {
            "graph_id": graph_id,
            "entity_id": entity_id(graph_id, raw),
            "label": entity_labels[raw],
        }
        for graph_id in ("source", "target")
        for raw in sorted(graph_entities[graph_id], key=_raw_id_sort_key)
    ]
    relation_rows = [
        {
            "graph_id": graph_id,
            "relation_id": relation_id(graph_id, raw),
            "label": relation_labels[raw],
        }
        for graph_id in ("source", "target")
        for raw in sorted(graph_relations[graph_id], key=_raw_id_sort_key)
    ]
    triple_rows = []
    shared_evidence_count = 0
    occurrence = {
        graph_id: {key for key, _ in rows}
        for graph_id, rows in graph_facts.items()
    }
    for graph_id in ("source", "target"):
        for key, score in graph_facts[graph_id]:
            head, relation, tail = key
            evidence = hashlib.sha256(
                "\t".join(key).encode("utf-8")
            ).hexdigest()
            shared = key in occurrence["source"] and key in occurrence["target"]
            if graph_id == "source" and shared:
                shared_evidence_count += 1
            triple_rows.append(
                {
                    "graph_id": graph_id,
                    "head_id": entity_id(graph_id, head),
                    "relation_id": relation_id(graph_id, relation),
                    "tail_id": entity_id(graph_id, tail),
                    "confidence": f"{score:.17g}",
                    "confidence_type": "normalized_heuristic_weight",
                    "confidence_source": f"{dataset_id} released score",
                    "normalization_method": "preserved_without_recalibration",
                    "timestamp": "",
                    "dependency_group": (
                        f"shared-evidence:{evidence}" if shared else ""
                    ),
                    "evidence_id": evidence,
                }
            )

    shared_entities = sorted(
        graph_entities["source"] & graph_entities["target"],
        key=_raw_id_sort_key,
    )
    alignment_rows = []
    split_counts = {"train": 0, "validation": 0, "test": 0}
    for raw in shared_entities:
        draw = _fraction(f"{seed}|alignment|{raw}")
        if draw < train_ratio:
            split = "train"
        elif draw < train_ratio + validation_ratio:
            split = "validation"
        else:
            split = "test"
        split_counts[split] += 1
        alignment_rows.append(
            {
                "source_entity_id": entity_id("source", raw),
                "target_entity_id": entity_id("target", raw),
                "split": split,
                "confidence": "1",
            }
        )

    output.mkdir(parents=True)
    _write_tsv(
        output / "entities.tsv",
        ["graph_id", "entity_id", "label"],
        entity_rows,
    )
    _write_tsv(
        output / "relations.tsv",
        ["graph_id", "relation_id", "label"],
        relation_rows,
    )
    _write_tsv(
        output / "triples.tsv",
        [
            "graph_id",
            "head_id",
            "relation_id",
            "tail_id",
            "confidence",
            "confidence_type",
            "confidence_source",
            "normalization_method",
            "timestamp",
            "dependency_group",
            "evidence_id",
        ],
        triple_rows,
    )
    _write_tsv(
        output / "alignments.tsv",
        ["source_entity_id", "target_entity_id", "split", "confidence"],
        alignment_rows,
    )
    metadata = {
        "dataset_id": dataset_id,
        "version": "semi-synthetic-dual-view-v1",
        "probability_semantics": (
            "Released UKG scores are preserved as normalized heuristic "
            "weights; no calibrated-probability claim is made."
        ),
        "edge_dependence": {
            "assumption": "paired_views_shared_evidence",
            "group_column": "dependency_group",
            "shared_evidence_groups": shared_evidence_count,
        },
        "generation": {
            "converter": "pkgea.data.ukg_views.convert_scored_ukg_to_views",
            "seed": seed,
            "source_retention": source_retention,
            "target_retention": target_retention,
            "train_ratio": train_ratio,
            "validation_ratio": validation_ratio,
            "deduplicated_input_facts": len(facts),
            "view_fact_counts": {
                graph_id: len(rows)
                for graph_id, rows in graph_facts.items()
            },
            "alignment_split_counts": split_counts,
            "input_checksums_sha256": input_checksums,
        },
        "source": str(source),
        "license_status": (
            f"Unresolved for derived {dataset_id} redistribution; local research "
            "artifact only until source/derivative permission is confirmed."
        ),
        "known_limitations": [
            "The two views are deterministic hash subsamples of one UKG.",
            "Identity alignment is inherited from shared original entity IDs.",
            "Released confidence scores are not assumed calibrated.",
            "View construction does not model independent real data sources.",
        ],
    }
    (output / "confidence_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    validate_dataset(output)
    return output

