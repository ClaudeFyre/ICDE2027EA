"""Convert an OpenEA graph pair into the canonical PKG-EA contract."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from urllib.parse import unquote

from pkgea.contracts import validate_dataset


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_rows(path: Path, columns: int) -> list[tuple[str, ...]]:
    rows: list[tuple[str, ...]] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, delimiter="\t")
        for line_number, row in enumerate(reader, start=1):
            if len(row) != columns:
                raise ValueError(
                    f"{path.name}:{line_number} expected {columns} columns, got {len(row)}"
                )
            rows.append(tuple(row))
    return rows


def _label(uri: str) -> str:
    tail = uri.rsplit("/", 1)[-1].rsplit("#", 1)[-1]
    return unquote(tail).replace("_", " ")


def _write_tsv(
    path: Path, fieldnames: list[str], rows: list[dict[str, str]]
) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(rows)


def convert_openea(
    input_dir: str | Path,
    output_dir: str | Path,
    *,
    fold: int = 1,
    source_archive_sha512: str = "",
    split_dir: str | Path | None = None,
    dataset_version: str = "OpenEA_dataset_v2.0",
    source_url: str = "https://figshare.com/ndownloader/files/34234391",
    license_status: str = (
        "OpenEA dataset record: CC BY 4.0; preserve attribution and document "
        "upstream DBpedia 2016-10 CC BY-SA 3.0/GFDL and Wikidata CC0 terms"
    ),
) -> Path:
    """Convert one OpenEA-family dataset folder and preserve its official split.

    ``split_dir`` overrides where ``train_links``/``valid_links``/``test_links``
    are read from. It defaults to OpenEA's own ``721_5fold/{fold}`` layout;
    pass the dataset root directly for OpenEA-family releases (e.g. EventEA)
    that ship a single flat split instead of 5-fold subdirectories.
    """

    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    if not source.is_dir():
        raise ValueError(f"OpenEA input directory does not exist: {source}")
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")
    if fold not in {1, 2, 3, 4, 5}:
        raise ValueError("OpenEA fold must be between 1 and 5")

    resolved_split_dir = (
        Path(split_dir).resolve()
        if split_dir is not None
        else source / "721_5fold" / str(fold)
    )
    required = [
        source / "rel_triples_1",
        source / "rel_triples_2",
        source / "ent_links",
        resolved_split_dir / "train_links",
        resolved_split_dir / "valid_links",
        resolved_split_dir / "test_links",
    ]
    missing = [path for path in required if not path.is_file()]
    if missing:
        raise ValueError(f"OpenEA input files missing: {', '.join(map(str, missing))}")

    triples_by_graph = {
        "source": _read_rows(source / "rel_triples_1", 3),
        "target": _read_rows(source / "rel_triples_2", 3),
    }
    attribute_files = {
        "source": source / "attr_triples_1",
        "target": source / "attr_triples_2",
    }
    attributes_by_graph = {
        graph_id: _read_rows(path, 3)
        for graph_id, path in attribute_files.items()
        if path.is_file()
    }
    split_files = {
        "train": resolved_split_dir / "train_links",
        "validation": resolved_split_dir / "valid_links",
        "test": resolved_split_dir / "test_links",
    }
    split_links = {
        split: _read_rows(path, 2) for split, path in split_files.items()
    }

    entity_ids = {"source": set(), "target": set()}
    relation_ids = {"source": set(), "target": set()}
    triple_rows: list[dict[str, str]] = []
    for graph_id, triples in triples_by_graph.items():
        for index, (head, relation, tail) in enumerate(triples):
            entity_ids[graph_id].update((head, tail))
            relation_ids[graph_id].add(relation)
            triple_rows.append(
                {
                    "graph_id": graph_id,
                    "head_id": head,
                    "relation_id": relation,
                    "tail_id": tail,
                    "confidence": "1",
                    "confidence_type": "calibrated_probability",
                    "confidence_source": "deterministic_openea_base",
                    "normalization_method": "identity",
                    "timestamp": "",
                    "dependency_group": "",
                    "evidence_id": f"openea:{graph_id}:{index}",
                }
            )

    alignment_rows: list[dict[str, str]] = []
    for split, links in split_links.items():
        for source_entity, target_entity in links:
            entity_ids["source"].add(source_entity)
            entity_ids["target"].add(target_entity)
            alignment_rows.append(
                {
                    "source_entity_id": source_entity,
                    "target_entity_id": target_entity,
                    "split": split,
                    "confidence": "1",
                }
            )

    entity_rows = [
        {
            "graph_id": graph_id,
            "entity_id": entity_id,
            "label": _label(entity_id),
        }
        for graph_id in ("source", "target")
        for entity_id in sorted(entity_ids[graph_id])
    ]
    relation_rows = [
        {
            "graph_id": graph_id,
            "relation_id": relation_id,
            "label": _label(relation_id),
        }
        for graph_id in ("source", "target")
        for relation_id in sorted(relation_ids[graph_id])
    ]
    attribute_rows = [
        {
            "graph_id": graph_id,
            "entity_id": entity_id,
            "attribute_id": attribute_id,
            "value": value,
        }
        for graph_id in ("source", "target")
        for entity_id, attribute_id, value in attributes_by_graph.get(graph_id, [])
        if entity_id in entity_ids[graph_id]
    ]

    output.mkdir(parents=True)
    _write_tsv(output / "entities.tsv", ["graph_id", "entity_id", "label"], entity_rows)
    _write_tsv(
        output / "relations.tsv",
        ["graph_id", "relation_id", "label"],
        relation_rows,
    )
    _write_tsv(
        output / "triples.tsv",
        [
            "graph_id",
            "head_id",
            "relation_id",
            "tail_id",
            "confidence",
            "confidence_type",
            "confidence_source",
            "normalization_method",
            "timestamp",
            "dependency_group",
            "evidence_id",
        ],
        triple_rows,
    )
    _write_tsv(
        output / "alignments.tsv",
        ["source_entity_id", "target_entity_id", "split", "confidence"],
        alignment_rows,
    )
    if attribute_rows:
        _write_tsv(
            output / "attributes.tsv",
            ["graph_id", "entity_id", "attribute_id", "value"],
            attribute_rows,
        )
    metadata = {
        "dataset_id": source.name,
        "version": dataset_version,
        "probability_semantics": (
            "Deterministic EA base graph; confidence 1 means the fact is materialized "
            "in the released OpenEA graph."
        ),
        "edge_dependence": {"assumption": "deterministic", "dependency_groups": []},
        "generation": {
            "converter": "pkgea.data.openea.convert_openea",
            "fold": fold,
            "source_archive_sha512": source_archive_sha512,
            "input_checksums_sha256": {
                str(path.relative_to(source)): _sha256(path)
                for path in [
                    *required,
                    *(path for path in attribute_files.values() if path.is_file()),
                ]
            },
            "attribute_triples": len(attribute_rows),
        },
        "source": source_url,
        "license_status": license_status,
        "known_limitations": [
            "Labels are derived from encoded URI tails.",
            "Attribute values are preserved verbatim and can contain typed literals.",
            "Attribute predicate alignment is left to downstream models.",
        ],
    }
    with (output / "confidence_metadata.json").open(
        "w", encoding="utf-8", newline="\n"
    ) as handle:
        json.dump(metadata, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    validate_dataset(output)
    return output
