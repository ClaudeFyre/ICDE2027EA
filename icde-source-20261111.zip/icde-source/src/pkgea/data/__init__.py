"""Dataset ingestion and normalization interfaces."""

from pkgea.data.openea import convert_openea
from pkgea.data.jape import convert_jape_dbp15k
from pkgea.data.calibration import (
    map_heuristic_confidences,
    mask_cross_graph_entity_labels,
)
from pkgea.data.probe import extract_aligned_probe
from pkgea.data.ukg_views import convert_scored_ukg_to_views

__all__ = [
    "convert_openea",
    "convert_jape_dbp15k",
    "map_heuristic_confidences",
    "mask_cross_graph_entity_labels",
    "convert_scored_ukg_to_views",
    "extract_aligned_probe",
]
