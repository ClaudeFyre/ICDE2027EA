"""Convert a JAPE DBP15K language pair to the canonical PKG-EA contract."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from urllib.parse import unquote

from pkgea.contracts import validate_dataset


def _rows(path: Path, width: int | None = None) -> list[tuple[str, ...]]:
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for line_number, row in enumerate(
            csv.reader(handle, delimiter="\t"),
            start=1,
        ):
            if width is not None and len(row) != width:
                raise ValueError(
                    f"{path}:{line_number} expected {width} columns, "
                    f"got {len(row)}"
                )
            if not row:
                raise ValueError(f"{path}:{line_number} is empty")
            rows.append(tuple(row))
    return rows


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _uri_label(uri: str) -> str:
    tail = uri.rsplit("/", 1)[-1].rsplit("#", 1)[-1]
    return unquote(tail).replace("_", " ")


def _write(
    path: Path,
    fields: list[str],
    rows: list[dict[str, str]],
) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def convert_jape_dbp15k(
    input_dir: str | Path,
    output_dir: str | Path,
    *,
    split_name: str = "0_3",
    source_archive_sha256: str = "",
) -> Path:
    """Convert one JAPE pair while preserving its 30/70 experiment split."""

    source = Path(input_dir).resolve()
    output = Path(output_dir).resolve()
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")
    split = source / split_name
    required = [
        source / "s_triples",
        source / "t_triples",
        source / "s_labels",
        source / "t_labels",
        source / "training_attrs_1",
        source / "training_attrs_2",
        split / "ent_ids_1",
        split / "ent_ids_2",
        split / "sup_ent_ids",
        split / "ref_ents",
    ]
    missing = [path for path in required if not path.is_file()]
    if missing:
        raise ValueError(
            f"JAPE input files missing: {', '.join(map(str, missing))}"
        )

    triples = {
        "source": _rows(source / "s_triples", 3),
        "target": _rows(source / "t_triples", 3),
    }
    label_rows = {
        "source": _rows(source / "s_labels", 3),
        "target": _rows(source / "t_labels", 3),
    }
    labels = {
        graph: {row[0]: row[1] for row in rows}
        for graph, rows in label_rows.items()
    }
    entity_ids = {"source": set(), "target": set()}
    relation_ids = {"source": set(), "target": set()}
    triple_rows = []
    for graph, graph_triples in triples.items():
        for index, (head, relation, tail) in enumerate(graph_triples):
            entity_ids[graph].update((head, tail))
            relation_ids[graph].add(relation)
            triple_rows.append(
                {
                    "graph_id": graph,
                    "head_id": head,
                    "relation_id": relation,
                    "tail_id": tail,
                    "confidence": "1",
                    "confidence_type": "calibrated_probability",
                    "confidence_source": "deterministic_jape_base",
                    "normalization_method": "identity",
                    "timestamp": "",
                    "dependency_group": "",
                    "evidence_id": f"jape:{source.name}:{graph}:{index}",
                }
            )

    left_id_to_uri = dict(_rows(split / "ent_ids_1", 2))
    right_id_to_uri = dict(_rows(split / "ent_ids_2", 2))
    train_links = [
        (left_id_to_uri[left], right_id_to_uri[right])
        for left, right in _rows(split / "sup_ent_ids", 2)
    ]
    test_links = _rows(split / "ref_ents", 2)
    alignment_rows = []
    for split_label, links in (("train", train_links), ("test", test_links)):
        for left, right in links:
            entity_ids["source"].add(left)
            entity_ids["target"].add(right)
            alignment_rows.append(
                {
                    "source_entity_id": left,
                    "target_entity_id": right,
                    "split": split_label,
                    "confidence": "1",
                }
            )

    entity_rows = [
        {
            "graph_id": graph,
            "entity_id": entity,
            "label": labels[graph].get(entity, _uri_label(entity)),
        }
        for graph in ("source", "target")
        for entity in sorted(entity_ids[graph])
    ]
    relation_rows = [
        {
            "graph_id": graph,
            "relation_id": relation,
            "label": _uri_label(relation),
        }
        for graph in ("source", "target")
        for relation in sorted(relation_ids[graph])
    ]
    attribute_rows = []
    for graph, filename in (
        ("source", "training_attrs_1"),
        ("target", "training_attrs_2"),
    ):
        for row in _rows(source / filename):
            entity = row[0]
            if entity not in entity_ids[graph]:
                continue
            attribute_rows.extend(
                {
                    "graph_id": graph,
                    "entity_id": entity,
                    "attribute_id": attribute,
                    "value": "present",
                }
                for attribute in row[1:]
            )

    output.mkdir(parents=True)
    _write(output / "entities.tsv", ["graph_id", "entity_id", "label"], entity_rows)
    _write(
        output / "relations.tsv",
        ["graph_id", "relation_id", "label"],
        relation_rows,
    )
    _write(
        output / "triples.tsv",
        [
            "graph_id",
            "head_id",
            "relation_id",
            "tail_id",
            "confidence",
            "confidence_type",
            "confidence_source",
            "normalization_method",
            "timestamp",
            "dependency_group",
            "evidence_id",
        ],
        triple_rows,
    )
    _write(
        output / "alignments.tsv",
        ["source_entity_id", "target_entity_id", "split", "confidence"],
        alignment_rows,
    )
    _write(
        output / "attributes.tsv",
        ["graph_id", "entity_id", "attribute_id", "value"],
        attribute_rows,
    )
    metadata = {
        "dataset_id": f"DBP15K_JAPE_{source.name}",
        "version": f"JAPE-master-{split_name}",
        "probability_semantics": (
            "Deterministic popularity-filtered DBP15K base graph; confidence "
            "1 denotes a materialized fact."
        ),
        "edge_dependence": {
            "assumption": "deterministic",
            "dependency_groups": [],
        },
        "generation": {
            "converter": "pkgea.data.jape.convert_jape_dbp15k",
            "split": split_name,
            "source_archive_sha256": source_archive_sha256,
            "input_checksums_sha256": {
                str(path.relative_to(source)): _sha256(path)
                for path in required
            },
            "attribute_presence_rows": len(attribute_rows),
        },
        "source": "https://github.com/nju-websoft/JAPE",
        "license_status": (
            "JAPE repository MIT; exact multilingual DBpedia source version "
            "and upstream content obligations require separate attribution."
        ),
        "known_limitations": [
            "This is JAPE's popularity-filtered subset, not full DBP15K.",
            "The released training_attrs files contain predicate presence but "
            "not literal values; conversion stores value='present'.",
            "Translated third-column labels are deliberately excluded to "
            "avoid cross-lingual label leakage.",
            "The original 0_3 split has train/test only and no validation set.",
        ],
    }
    (output / "confidence_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    validate_dataset(output)
    return output

