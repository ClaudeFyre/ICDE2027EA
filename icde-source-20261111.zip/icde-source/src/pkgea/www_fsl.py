"""Utilities for the WWW fidelity--storage--latency experiment.

The functions in this module are deliberately target-specific.  They evaluate
Gaussian summaries of learned hidden states and construct the exact stochastic
scope required by the project-owned two-layer symmetrically-normalized GCN.
They do not implement WSDM's categorical winner confidence sequence.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from typing import Sequence

import numpy as np

from pkgea.distributional import (
    approximate_covariance,
    gaussian_wasserstein_squared,
)


def serving_workload_digest(
    sources: Sequence[str],
    candidates: Sequence[str],
    *,
    ranking_operation: str = "gaussian_w2_top1_frozen_candidate_order",
) -> str:
    """Return a path-independent digest for the ordered serving workload.

    Authorization is meaningful only for the exact ordered source set,
    candidate pool, and ranking operation that were checked.  JSON provides a
    stable, explicit encoding while UTF-8 keeps the digest platform neutral.
    """

    payload = {
        "schema_version": "pkgea-serving-workload-v1",
        "ranking_operation": ranking_operation,
        "sources": list(sources),
        "candidates": list(candidates),
    }
    return hashlib.sha256(
        json.dumps(
            payload,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()


@dataclass(frozen=True)
class TwoLayerGCNScope:
    """Exact dependency scope for a batch of requested output rows."""

    output_positions: tuple[int, ...]
    layer1_positions: tuple[int, ...]
    degree_positions: tuple[int, ...]
    sampled_edge_indices: tuple[int, ...]
    layer1_edge_indices: tuple[int, ...]
    layer2_edge_indices: tuple[int, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "output_entity_count": len(self.output_positions),
            "layer1_entity_count": len(self.layer1_positions),
            "degree_entity_count": len(self.degree_positions),
            "sampled_edge_count": len(self.sampled_edge_indices),
            "layer1_edge_count": len(self.layer1_edge_indices),
            "layer2_edge_count": len(self.layer2_edge_indices),
            "certificate": (
                "For two GCN layers with symmetric degree normalization, "
                "sample all edges incident to the two-hop degree boundary; "
                "compute layer 1 on outputs plus one-hop neighbors and layer "
                "2 on requested outputs. Dependency-group latent variables "
                "are retained by the local sampler."
            ),
        }


def build_two_layer_gcn_scope(
    node_count: int,
    heads: Sequence[int],
    tails: Sequence[int],
    output_positions: Sequence[int],
) -> TwoLayerGCNScope:
    """Return the exact edge/node scope for requested two-layer GCN rows."""

    if node_count <= 0:
        raise ValueError("node_count must be positive")
    if len(heads) != len(tails):
        raise ValueError("heads and tails must have equal length")
    outputs = set(int(position) for position in output_positions)
    if not outputs:
        raise ValueError("at least one output position is required")
    if any(position < 0 or position >= node_count for position in outputs):
        raise ValueError("output position outside graph")
    adjacency: list[set[int]] = [set() for _ in range(node_count)]
    for head, tail in zip(heads, tails, strict=True):
        if not (0 <= head < node_count and 0 <= tail < node_count):
            raise ValueError("edge endpoint outside graph")
        adjacency[head].add(tail)
        adjacency[tail].add(head)

    layer1 = set(outputs)
    for position in tuple(outputs):
        layer1.update(adjacency[position])
    degree = set(layer1)
    for position in tuple(layer1):
        degree.update(adjacency[position])

    sampled_edges = []
    layer1_edges = []
    layer2_edges = []
    for edge_index, (head, tail) in enumerate(
        zip(heads, tails, strict=True)
    ):
        if head in degree or tail in degree:
            sampled_edges.append(edge_index)
        if head in layer1 or tail in layer1:
            layer1_edges.append(edge_index)
        if head in outputs or tail in outputs:
            layer2_edges.append(edge_index)
    return TwoLayerGCNScope(
        output_positions=tuple(sorted(outputs)),
        layer1_positions=tuple(sorted(layer1)),
        degree_positions=tuple(sorted(degree)),
        sampled_edge_indices=tuple(sampled_edges),
        layer1_edge_indices=tuple(layer1_edges),
        layer2_edge_indices=tuple(layer2_edges),
    )


def empirical_gaussian(
    samples: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute per-entity empirical means and unbiased covariances."""

    values = np.asarray(samples, dtype=np.float64)
    if values.ndim != 3:
        raise ValueError("samples must have shape (world, entity, dimension)")
    if values.shape[0] < 3:
        raise ValueError("at least three worlds are required")
    means = values.mean(axis=0)
    centered = values - means[None, :, :]
    covariances = np.einsum(
        "wed,wef->edf", centered, centered, optimize=True
    ) / (values.shape[0] - 1)
    return means, covariances


def psd_batch(covariances: np.ndarray) -> np.ndarray:
    """Symmetrize and clip a batch of covariance matrices to the PSD cone."""

    values = np.asarray(covariances, dtype=np.float64)
    if values.ndim != 3 or values.shape[1] != values.shape[2]:
        raise ValueError("covariances must have shape (entity, d, d)")
    symmetric = (values + np.swapaxes(values, 1, 2)) / 2.0
    eigenvalues, eigenvectors = np.linalg.eigh(symmetric)
    return np.einsum(
        "eik,ek,ejk->eij",
        eigenvectors,
        np.maximum(eigenvalues, 0.0),
        eigenvectors,
        optimize=True,
    )


def gaussian_distance_matrix(
    means: np.ndarray,
    covariances: np.ndarray,
    source_count: int,
) -> np.ndarray:
    """Compute exact Gaussian W2 squared distances with batched eigensolvers."""

    mean_values = np.asarray(means, dtype=np.float64)
    covariance_values = psd_batch(covariances)
    if mean_values.ndim != 2:
        raise ValueError("means must have shape (entity, dimension)")
    if covariance_values.shape != (
        mean_values.shape[0],
        mean_values.shape[1],
        mean_values.shape[1],
    ):
        raise ValueError("mean/covariance shape mismatch")
    if not 0 < source_count < mean_values.shape[0]:
        raise ValueError("source_count must split source and target entities")
    source_means = mean_values[:source_count]
    target_means = mean_values[source_count:]
    source_covariances = covariance_values[:source_count]
    target_covariances = covariance_values[source_count:]
    target_traces = np.trace(target_covariances, axis1=1, axis2=2)
    distances = np.empty(
        (source_count, target_means.shape[0]), dtype=np.float64
    )
    for source_position, (source_mean, source_covariance) in enumerate(
        zip(source_means, source_covariances, strict=True)
    ):
        eigenvalues, eigenvectors = np.linalg.eigh(source_covariance)
        source_sqrt = (
            eigenvectors * np.sqrt(np.maximum(eigenvalues, 0.0))
        ) @ eigenvectors.T
        middle = np.einsum(
            "ij,tjk,kl->til",
            source_sqrt,
            target_covariances,
            source_sqrt,
            optimize=True,
        )
        middle = (middle + np.swapaxes(middle, 1, 2)) / 2.0
        middle_eigenvalues = np.linalg.eigvalsh(middle)
        covariance_term = (
            np.trace(source_covariance)
            + target_traces
            - 2.0
            * np.sqrt(np.maximum(middle_eigenvalues, 0.0)).sum(axis=1)
        )
        mean_term = np.square(target_means - source_mean).sum(axis=1)
        distances[source_position] = np.maximum(
            mean_term + covariance_term, 0.0
        )
    return distances


def approximate_covariance_batch(
    covariances: np.ndarray,
    mode: str,
    *,
    rank: int = 2,
    block_size: int = 4,
) -> np.ndarray:
    """Apply one storage family to every entity covariance."""

    return np.stack(
        [
            approximate_covariance(
                covariance,
                mode,
                rank=rank,
                block_size=block_size,
            )
            for covariance in np.asarray(covariances)
        ]
    )


def winner_indices(distances: np.ndarray) -> np.ndarray:
    """Return deterministic top-1 indices for a distance matrix."""

    values = np.asarray(distances, dtype=np.float64)
    if values.ndim != 2 or not values.size:
        raise ValueError("distances must be a non-empty matrix")
    return np.argmin(values, axis=1)


def truth_preserving_candidate_subset(
    targets: Sequence[str],
    sources: Sequence[str],
    truth: dict[str, str],
    limit: int | None,
) -> tuple[str, ...]:
    """Return a nested truth-preserving subset in frozen target order."""

    frozen = tuple(targets)
    if len(set(frozen)) != len(frozen):
        raise ValueError("targets must be unique and in frozen order")
    if limit is None:
        return frozen
    if limit < len(sources):
        raise ValueError("candidate limit must be at least the source count")
    if limit > len(frozen):
        raise ValueError("candidate limit exceeds the full target count")
    required = {truth[source] for source in sources}
    missing = required - set(frozen)
    if missing:
        raise ValueError("truth targets missing from the full candidate pool")
    selected = set(required)
    for target in frozen:
        if len(selected) == limit:
            break
        selected.add(target)
    result = tuple(target for target in frozen if target in selected)
    if len(result) != limit or not required.issubset(result):
        raise AssertionError("truth-preserving candidate construction failed")
    return result


def slack_diagnostics(
    full_distances: np.ndarray,
    approximate_distances: np.ndarray,
    *,
    relative_tolerance: float = 1e-12,
    absolute_scale_floor: float = 1.0,
) -> dict[str, object]:
    """Explain top-1 changes without replacing the authoritative argmin label."""

    full = np.asarray(full_distances, dtype=np.float64)
    approximate = np.asarray(approximate_distances, dtype=np.float64)
    if full.shape != approximate.shape or full.ndim != 2 or full.shape[1] < 2:
        raise ValueError("distance matrices must match and have competitors")
    full_winners = winner_indices(full)
    approximate_winners = winner_indices(approximate)
    winner_distances = full[np.arange(full.shape[0]), full_winners]
    winner_scale = float(np.median(np.abs(winner_distances)))
    tau = float(relative_tolerance * max(winner_scale, absolute_scale_floor))
    rows: list[dict[str, object]] = []
    agreements = 0
    all_disturbances: list[float] = []
    for source_index, winner in enumerate(full_winners):
        delta = approximate[source_index] - full[source_index]
        all_disturbances.extend(float(value) for value in delta)
        margin = full[source_index] - full[source_index, winner]
        slack = margin - (delta[winner] - delta)
        competitor_mask = np.ones(full.shape[1], dtype=bool)
        competitor_mask[winner] = False
        competitors = np.flatnonzero(competitor_mask)
        competitor_slack = slack[competitors]
        zero = competitors[np.abs(competitor_slack) <= tau]
        negative = competitors[competitor_slack < -tau]
        diagnostic_flip = bool(
            negative.size or np.any(zero < winner)
        )
        authoritative_flip = bool(
            approximate_winners[source_index] != winner
        )
        agreements += int(diagnostic_flip == authoritative_flip)
        min_value = float(np.min(competitor_slack))
        minimizers = competitors[np.abs(competitor_slack - min_value) <= tau]
        stable_order = np.argsort(
            full[source_index], kind="stable"
        )
        full_ranks = np.empty(full.shape[1], dtype=np.int64)
        full_ranks[stable_order] = np.arange(1, full.shape[1] + 1)
        slack_category = (
            "strict_negative"
            if min_value < -tau
            else "zero"
            if abs(min_value) <= tau
            else "positive"
        )
        rows.append(
            {
                "source_index": source_index,
                "full_winner_index": int(winner),
                "approximate_winner_index": int(
                    approximate_winners[source_index]
                ),
                "authoritative_flipped": authoritative_flip,
                "diagnostic_predicted_flipped": diagnostic_flip,
                "diagnostic_matches_authoritative": (
                    diagnostic_flip == authoritative_flip
                ),
                "minimum_slack": min_value,
                "minimum_slack_category": slack_category,
                "minimum_margin": float(np.min(margin[competitor_mask])),
                "minimizer_indices": [int(value) for value in minimizers],
                "minimizer_full_distance_ranks": [
                    int(full_ranks[value]) for value in minimizers
                ],
                "zero_slack_indices": [int(value) for value in zero],
                "negative_slack_indices": [int(value) for value in negative],
                "zero_slack_count": int(zero.size),
            }
        )
    minimum_slacks = np.asarray(
        [row["minimum_slack"] for row in rows], dtype=np.float64
    )
    minimum_margins = np.asarray(
        [row["minimum_margin"] for row in rows], dtype=np.float64
    )
    disturbances = np.asarray(all_disturbances, dtype=np.float64)
    return {
        "tau_slack": tau,
        "median_absolute_winner_distance": winner_scale,
        "absolute_floor_triggered": winner_scale < absolute_scale_floor,
        "strict_negative_source_count": int(np.sum(minimum_slacks < -tau)),
        "zero_source_count": int(np.sum(np.abs(minimum_slacks) <= tau)),
        "positive_source_count": int(np.sum(minimum_slacks > tau)),
        "multiple_zero_slack_source_count": int(
            sum(int(row["zero_slack_count"] > 1) for row in rows)
        ),
        "diagnostic_authoritative_agreement": agreements / len(rows),
        "diagnostic_authoritative_disagreement_count": len(rows) - agreements,
        "authoritative_flipped_source_count": int(
            sum(int(row["authoritative_flipped"]) for row in rows)
        ),
        "minimum_slack_summary": {
            "min": float(np.min(minimum_slacks)),
            "p10": float(np.percentile(minimum_slacks, 10)),
            "median": float(np.median(minimum_slacks)),
        },
        "minimum_margin_summary": {
            "min": float(np.min(minimum_margins)),
            "p10": float(np.percentile(minimum_margins, 10)),
            "median": float(np.median(minimum_margins)),
        },
        "distance_disturbance_summary": {
            "min": float(np.min(disturbances)),
            "p10": float(np.percentile(disturbances, 10)),
            "median": float(np.median(disturbances)),
            "p90": float(np.percentile(disturbances, 90)),
            "max": float(np.max(disturbances)),
        },
        "minimizer_full_distance_ranks": [
            rank
            for row in rows
            for rank in row["minimizer_full_distance_ranks"]
        ],
        "sources": rows,
    }


def select_entity_adaptive_ranks(
    covariances: np.ndarray,
    *,
    candidate_ranks: Sequence[int] = (1, 2, 4),
    residual_threshold: float = 0.0025,
    zero_tolerance: float = 1e-12,
) -> dict[str, object]:
    """Select per-entity ranks from covariance residuals on selection data."""

    values = psd_batch(covariances)
    ranks = tuple(sorted(set(int(rank) for rank in candidate_ranks)))
    if not ranks or min(ranks) <= 0:
        raise ValueError("candidate ranks must be positive")
    selections: list[int | None] = []
    entities: list[dict[str, object]] = []
    anomalous_count = 0
    degenerate_entities: set[int] = set()
    for entity_index, covariance in enumerate(values):
        denominator = float(np.linalg.norm(covariance, ord="fro"))
        residuals: list[dict[str, object]] = []
        entity_anomalous = False
        passing: list[int] = []
        for rank in ranks:
            approximation = approximate_covariance(
                covariance, "low_rank", rank=rank
            )
            numerator = float(
                np.linalg.norm(covariance - approximation, ord="fro")
            )
            status, relative = classify_covariance_residual(
                denominator, numerator, zero_tolerance=zero_tolerance
            )
            if status == "degenerate":
                degenerate_entities.add(entity_index)
            elif status == "anomalous":
                entity_anomalous = True
            if relative is not None and relative <= residual_threshold:
                passing.append(rank)
            residuals.append(
                {
                    "rank": rank,
                    "numerator_frobenius": numerator,
                    "relative_residual": relative,
                    "status": status,
                }
            )
        if entity_anomalous:
            selected = None
            anomalous_count += 1
        else:
            selected = min(passing) if passing else 0
        selections.append(selected)
        entities.append(
            {
                "entity_index": entity_index,
                "covariance_frobenius": denominator,
                "selected_rank": selected,
                "selected_storage_mode": (
                    "anomalous"
                    if selected is None
                    else "full"
                    if selected == 0
                    else "low_rank"
                ),
                "residuals": residuals,
            }
        )
    covariance_norms = np.asarray(
        [row["covariance_frobenius"] for row in entities], dtype=np.float64
    )
    return {
        "candidate_ranks": list(ranks),
        "residual_threshold": residual_threshold,
        "zero_tolerance": zero_tolerance,
        "selected_ranks": selections,
        "degenerate_entity_count": len(degenerate_entities),
        "anomalous_entity_count": anomalous_count,
        "selection_paused": anomalous_count > 0,
        "covariance_frobenius_summary": {
            "min": float(np.min(covariance_norms)),
            "p10": float(np.percentile(covariance_norms, 10)),
            "median": float(np.median(covariance_norms)),
            "p90": float(np.percentile(covariance_norms, 90)),
            "max": float(np.max(covariance_norms)),
        },
        "zero_threshold_neighborhood": {
            "below_tau_over_10": int(
                np.sum(covariance_norms <= zero_tolerance / 10.0)
            ),
            "at_or_below_tau": int(
                np.sum(covariance_norms <= zero_tolerance)
            ),
            "at_or_below_10_tau": int(
                np.sum(covariance_norms <= zero_tolerance * 10.0)
            ),
        },
        "entities": entities,
    }


def classify_covariance_residual(
    denominator: float,
    numerator: float,
    *,
    zero_tolerance: float = 1e-12,
) -> tuple[str, float | None]:
    """Apply the frozen normal/degenerate/anomalous residual contract."""

    if denominator < 0 or numerator < 0 or zero_tolerance <= 0:
        raise ValueError("norms must be nonnegative and tolerance positive")
    if denominator > zero_tolerance:
        return "ok", numerator / denominator
    if numerator <= zero_tolerance:
        return "degenerate", 0.0
    return "anomalous", None


def apply_entity_adaptive_ranks(
    covariances: np.ndarray, selected_ranks: Sequence[int | None]
) -> np.ndarray:
    """Apply a frozen per-entity rank map; zero denotes full covariance."""

    values = psd_batch(covariances)
    if len(values) != len(selected_ranks):
        raise ValueError("rank map length must match entity count")
    approximations = []
    for covariance, rank in zip(values, selected_ranks, strict=True):
        if rank is None:
            raise ValueError("anomalous entity has no authorized rank")
        approximations.append(
            covariance
            if rank == 0
            else approximate_covariance(covariance, "low_rank", rank=rank)
        )
    return np.stack(approximations)


def margin_criticalities(
    squared_distances: np.ndarray,
) -> dict[str, object]:
    """Return source and target criticalities from one selection-only stream.

    Distances produced by :func:`gaussian_distance_matrix` are squared W2
    distances.  The metric-space certificate used here needs W2 itself.  A
    source receives its winner--runner-up margin.  Every target is covered:
    when it is the winner it receives the same winner margin, otherwise it
    receives its candidate-specific margin to the winner.  Taking the minimum
    over sources prevents a third-or-lower candidate from being silently
    relaxed merely because it never appears in a top-two pair.
    """

    squared = np.asarray(squared_distances, dtype=np.float64)
    if squared.ndim != 2 or squared.shape[0] == 0 or squared.shape[1] < 2:
        raise ValueError("distances must contain sources and at least two targets")
    if np.any(squared < -1e-12):
        raise ValueError("squared distances must be nonnegative")
    distances = np.sqrt(np.maximum(squared, 0.0))
    source_count, target_count = distances.shape
    source_values = np.empty(source_count, dtype=np.float64)
    target_values = np.full(target_count, np.inf, dtype=np.float64)
    winner_indices_value = np.argmin(distances, axis=1)
    zero_margin_sources = 0
    for source_index, winner in enumerate(winner_indices_value):
        order = np.argsort(distances[source_index], kind="stable")
        runner = int(order[1])
        winner_distance = float(distances[source_index, winner])
        gamma = max(
            0.0,
            float(distances[source_index, runner]) - winner_distance,
        )
        source_values[source_index] = gamma
        zero_margin_sources += int(gamma == 0.0)
        for target_index in range(target_count):
            criticality = (
                gamma
                if target_index == winner
                else max(
                    0.0,
                    float(distances[source_index, target_index])
                    - winner_distance,
                )
            )
            target_values[target_index] = min(
                target_values[target_index], criticality
            )
    if not np.all(np.isfinite(target_values)):
        raise AssertionError("every target must receive finite criticality")
    combined = np.concatenate((source_values, target_values))
    return {
        "distance_metric": "gaussian_w2_not_squared",
        "source_criticalities": source_values.tolist(),
        "target_criticalities": target_values.tolist(),
        "entity_criticalities": combined.tolist(),
        "winner_indices": winner_indices_value.astype(int).tolist(),
        "zero_margin_source_count": zero_margin_sources,
        "minimum": float(np.min(combined)),
        "median": float(np.median(combined)),
        "maximum": float(np.max(combined)),
    }


def apply_entity_representations(
    covariances: np.ndarray,
    representations: Sequence[str],
) -> np.ndarray:
    """Apply diagonal/rank-plus-diagonal/full choices entity by entity."""

    values = psd_batch(covariances)
    if len(values) != len(representations):
        raise ValueError("representation map length must match entity count")
    approximations = []
    for covariance, representation in zip(values, representations, strict=True):
        if representation == "full":
            approximation = covariance
        elif representation == "diagonal":
            approximation = approximate_covariance(covariance, "diagonal")
        elif representation.startswith("rank_"):
            rank = int(representation.removeprefix("rank_"))
            if rank not in (1, 2, 4):
                raise ValueError(f"unsupported service rank: {rank}")
            approximation = approximate_covariance(
                covariance, "low_rank", rank=rank
            )
        else:
            raise ValueError(f"unsupported representation: {representation}")
        approximations.append(approximation)
    return np.stack(approximations)


def select_margin_aware_representations(
    covariances: np.ndarray,
    selection_squared_distances: np.ndarray,
    *,
    source_count: int,
    target_storage_scalars: int,
    storage_tolerance: float = 0.005,
) -> dict[str, object]:
    """Calibrate a decision-aligned map to a frozen logical-storage target.

    The candidate artifact for entity ``e`` and representation ``r`` has
    self-distortion ``rho_e(r) = W2(N(0,Sigma_e), N(0,Sigma_hat_e(r)))``.
    The cheapest representation satisfying ``rho_e(r) <= lambda*kappa_e`` is
    selected.  Lambda is not tuned for gate success: it is chosen solely from
    the selection stream to match ``target_storage_scalars`` as closely as the
    discrete representation set permits.  A cell is paused if the predeclared
    0.5% storage-neutrality tolerance cannot be met.
    """

    values = psd_batch(covariances)
    distances = np.asarray(selection_squared_distances, dtype=np.float64)
    if distances.shape[0] != source_count:
        raise ValueError("source count does not match distance rows")
    if len(values) != source_count + distances.shape[1]:
        raise ValueError("covariance order must be sources followed by targets")
    if target_storage_scalars <= 0:
        raise ValueError("storage target must be positive")
    if not 0.0 <= storage_tolerance <= 0.05:
        raise ValueError("storage tolerance must lie in [0, 0.05]")

    criticality = margin_criticalities(distances)
    kappas = np.asarray(
        criticality["entity_criticalities"], dtype=np.float64
    )
    dimension = int(values.shape[1])
    representations = ("diagonal", "rank_1", "rank_2", "rank_4")
    scalar_costs = {
        "diagonal": stored_scalars_per_entity(dimension, "diagonal"),
        "rank_1": stored_scalars_per_entity(
            dimension, "low_rank", rank=1
        ),
        "rank_2": stored_scalars_per_entity(
            dimension, "low_rank", rank=2
        ),
        "rank_4": stored_scalars_per_entity(
            dimension, "low_rank", rank=4
        ),
        "full": stored_scalars_per_entity(dimension, "full"),
    }
    distortions = np.empty(
        (len(values), len(representations)), dtype=np.float64
    )
    zero = np.zeros(dimension, dtype=np.float64)
    for entity_index, covariance in enumerate(values):
        for representation_index, representation in enumerate(representations):
            approximation = apply_entity_representations(
                covariance[None, :, :], [representation]
            )[0]
            distortions[entity_index, representation_index] = math.sqrt(
                gaussian_wasserstein_squared(
                    zero, covariance, zero, approximation
                )
            )
    ratios = np.full_like(distortions, np.inf)
    positive = kappas > 0.0
    ratios[positive] = distortions[positive] / kappas[positive, None]
    ratios[(~positive)[:, None] & (distortions <= 1e-15)] = 0.0

    def choose(lambda_value: float) -> tuple[list[str], int]:
        selected: list[str] = []
        total = 0
        for entity_ratios in ratios:
            representation = "full"
            for candidate, ratio in zip(
                representations, entity_ratios, strict=True
            ):
                if ratio <= lambda_value:
                    representation = candidate
                    break
            selected.append(representation)
            total += scalar_costs[representation]
        return selected, total

    finite_breakpoints = np.unique(ratios[np.isfinite(ratios)])
    if finite_breakpoints.size == 0:
        finite_breakpoints = np.asarray([0.0])
    low = 0
    high = len(finite_breakpoints) - 1
    first_not_over = len(finite_breakpoints)
    while low <= high:
        middle = (low + high) // 2
        _, total = choose(float(finite_breakpoints[middle]))
        if total <= target_storage_scalars:
            first_not_over = middle
            high = middle - 1
        else:
            low = middle + 1
    candidate_indices = {
        max(0, min(len(finite_breakpoints) - 1, first_not_over + offset))
        for offset in (-1, 0, 1)
    }
    candidates = []
    for index in sorted(candidate_indices):
        lambda_value = float(finite_breakpoints[index])
        selected, total = choose(lambda_value)
        candidates.append((lambda_value, selected, total))
    lambda_value, selected, total = min(
        candidates,
        key=lambda row: (
            abs(row[2] - target_storage_scalars),
            row[2] > target_storage_scalars,
            row[0],
        ),
    )
    deviation = abs(total - target_storage_scalars) / target_storage_scalars
    counts = {
        representation: selected.count(representation)
        for representation in (*representations, "full")
    }
    return {
        "selection_data_contract": "selection_seed_only_no_test_stream_input",
        "criterion": "rho_e_representation_le_lambda_times_kappa_e",
        "lambda": lambda_value,
        "strict_quarter_certificate_on_selection_stream": lambda_value < 0.25,
        "storage_tolerance": storage_tolerance,
        "target_storage_scalars": int(target_storage_scalars),
        "selected_storage_scalars": int(total),
        "storage_relative_deviation": float(deviation),
        "storage_neutrality_passes": bool(deviation <= storage_tolerance),
        "selection_paused": bool(deviation > storage_tolerance),
        "selected_representations": selected,
        "representation_counts": counts,
        "scalar_costs": scalar_costs,
        "criticality": criticality,
        "self_distortion_summary": {
            representation: {
                "min": float(np.min(distortions[:, index])),
                "median": float(np.median(distortions[:, index])),
                "max": float(np.max(distortions[:, index])),
            }
            for index, representation in enumerate(representations)
        },
    }


def winner_agreement(left: np.ndarray, right: np.ndarray) -> float:
    """Fraction of sources with identical top-1 candidates."""

    left_winners = winner_indices(left)
    right_winners = winner_indices(right)
    if left_winners.shape != right_winners.shape:
        raise ValueError("distance matrices must have the same source count")
    return float(np.mean(left_winners == right_winners))


def mean_relative_distance_error(
    estimate: np.ndarray, reference: np.ndarray
) -> float:
    """Mean elementwise relative distance error with a stable denominator."""

    estimate_values = np.asarray(estimate, dtype=np.float64)
    reference_values = np.asarray(reference, dtype=np.float64)
    if estimate_values.shape != reference_values.shape:
        raise ValueError("estimate/reference distance shape mismatch")
    denominator = np.maximum(np.abs(reference_values), 1e-12)
    return float(np.mean(np.abs(estimate_values - reference_values) / denominator))


def stored_scalars_per_entity(
    dimension: int, mode: str, *, rank: int = 2, block_size: int = 4
) -> int:
    """Logical mean-plus-covariance storage for one Gaussian entity."""

    if dimension <= 0:
        raise ValueError("dimension must be positive")
    if mode == "full":
        covariance = dimension * (dimension + 1) // 2
    elif mode == "diagonal":
        covariance = dimension
    elif mode == "block":
        if block_size <= 0:
            raise ValueError("block_size must be positive")
        covariance = sum(
            size * (size + 1) // 2
            for size in (
                min(block_size, dimension - start)
                for start in range(0, dimension, block_size)
            )
        )
    elif mode == "low_rank":
        if rank <= 0:
            raise ValueError("rank must be positive")
        covariance = dimension * rank + dimension
    else:
        raise ValueError(f"unsupported storage mode: {mode}")
    return dimension + covariance
