"""Validation for the repository's canonical PKG-EA dataset contract."""

from __future__ import annotations

import csv
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path


REQUIRED_FILES = {
    "entities.tsv",
    "relations.tsv",
    "triples.tsv",
    "alignments.tsv",
    "confidence_metadata.json",
}

REQUIRED_COLUMNS = {
    "entities.tsv": {"graph_id", "entity_id", "label"},
    "relations.tsv": {"graph_id", "relation_id", "label"},
    "triples.tsv": {
        "graph_id",
        "head_id",
        "relation_id",
        "tail_id",
        "confidence",
        "confidence_type",
        "confidence_source",
        "normalization_method",
        "timestamp",
        "dependency_group",
        "evidence_id",
    },
    "alignments.tsv": {
        "source_entity_id",
        "target_entity_id",
        "split",
        "confidence",
    },
}

OPTIONAL_COLUMNS = {
    "attributes.tsv": {"graph_id", "entity_id", "attribute_id", "value"},
}


def dataset_revision_digest(dataset_dir: str | Path) -> str:
    """Hash every canonical input that can change a query/model artifact."""

    root = Path(dataset_dir).resolve()
    digest = hashlib.sha256()
    digest.update(b"pkgea-dataset-revision-v1\0")
    for filename in (
        "entities.tsv",
        "relations.tsv",
        "triples.tsv",
        "alignments.tsv",
        "attributes.tsv",
        "confidence_metadata.json",
    ):
        path = root / filename
        if not path.is_file():
            continue
        digest.update(filename.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()

_REPO_ROOT = Path(__file__).resolve().parents[2]


def provenance_path(path: str | Path) -> str:
    """Render a dataset path for metadata without pinning it to one machine.

    Repo-relative POSIX when the path is inside the checkout, otherwise the
    directory name alone.  An absolute path here made every generated dataset's
    byte content host-specific.
    """

    resolved = Path(path).resolve()
    try:
        return resolved.relative_to(_REPO_ROOT).as_posix()
    except ValueError:
        return resolved.name


# Fields that record where a dataset was built rather than what it contains.
# They differ between machines and must never enter a portable digest.
NON_PORTABLE_METADATA_FIELDS = ("base_dataset",)

CONTENT_DIGEST_FILES = (
    "entities.tsv",
    "relations.tsv",
    "triples.tsv",
    "alignments.tsv",
    "attributes.tsv",
    "latent_truth.tsv",
)


def dataset_content_digest(dataset_dir: str | Path) -> str:
    """Hash a dataset's content in a machine-independent way.

    ``dataset_revision_digest`` hashes raw bytes, so it also captures where the
    dataset was built and which platform wrote it: an absolute source path in
    the metadata, or CRLF line endings from a Windows text-mode write, both
    change it.  That is fine for pinning a local artifact to a local run, and it
    is what every frozen contract already records, so it is left alone.

    It cannot be compared across machines, which is what this digest is for.
    Line endings are normalized, provenance path fields are dropped, and the
    metadata is re-serialized canonically.  ``latent_truth.tsv`` is included --
    it determines the sampled worlds -- so this covers strictly more content
    than the revision digest.
    """

    root = Path(dataset_dir).resolve()
    digest = hashlib.sha256()
    digest.update(b"pkgea-dataset-content-v1\0")
    for filename in CONTENT_DIGEST_FILES:
        path = root / filename
        if not path.is_file():
            continue
        digest.update(filename.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes().replace(b"\r\n", b"\n"))
        digest.update(b"\0")
    metadata_path = root / "confidence_metadata.json"
    if metadata_path.is_file():
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        for field in NON_PORTABLE_METADATA_FIELDS:
            metadata.pop(field, None)
        digest.update(b"confidence_metadata.json\0")
        digest.update(
            json.dumps(
                metadata, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            ).encode("utf-8")
        )
        digest.update(b"\0")
    return digest.hexdigest()


CONFIDENCE_TYPES = {
    "calibrated_probability",
    "model_score",
    "frequency",
    "expert_belief",
    "source_reliability",
    "normalized_heuristic_weight",
    "assumed_probability_mapping",
    "empirical_occurrence_rate",
}

ALIGNMENT_SPLITS = {"train", "validation", "test"}


@dataclass(frozen=True)
class ValidationReport:
    dataset_dir: Path
    entity_count: int
    relation_count: int
    triple_count: int
    alignment_count: int
    confidence_types: tuple[str, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "dataset_dir": str(self.dataset_dir),
            "entity_count": self.entity_count,
            "relation_count": self.relation_count,
            "triple_count": self.triple_count,
            "alignment_count": self.alignment_count,
            "confidence_types": list(self.confidence_types),
        }


def _read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        fieldnames = set(reader.fieldnames or [])
        missing = REQUIRED_COLUMNS[path.name] - fieldnames
        if missing:
            names = ", ".join(sorted(missing))
            raise ValueError(f"{path.name} is missing required columns: {names}")
        return list(reader)


def _read_optional_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        fieldnames = set(reader.fieldnames or [])
        missing = OPTIONAL_COLUMNS[path.name] - fieldnames
        if missing:
            names = ", ".join(sorted(missing))
            raise ValueError(f"{path.name} is missing required columns: {names}")
        return list(reader)


def _parse_confidence(raw: str, location: str) -> float:
    try:
        value = float(raw)
    except ValueError as exc:
        raise ValueError(f"{location} has non-numeric confidence: {raw!r}") from exc
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"{location} confidence must be in [0, 1], got {value}")
    return value


def validate_dataset(dataset_dir: str | Path) -> ValidationReport:
    """Validate files, references, confidence semantics, and metadata."""

    root = Path(dataset_dir).resolve()
    if not root.is_dir():
        raise ValueError(f"Dataset directory does not exist: {root}")

    missing_files = sorted(name for name in REQUIRED_FILES if not (root / name).is_file())
    if missing_files:
        raise ValueError(f"Dataset is missing files: {', '.join(missing_files)}")

    entities = _read_tsv(root / "entities.tsv")
    relations = _read_tsv(root / "relations.tsv")
    triples = _read_tsv(root / "triples.tsv")
    alignments = _read_tsv(root / "alignments.tsv")
    attributes = (
        _read_optional_tsv(root / "attributes.tsv")
        if (root / "attributes.tsv").is_file()
        else []
    )

    entity_keys = {(row["graph_id"], row["entity_id"]) for row in entities}
    relation_keys = {(row["graph_id"], row["relation_id"]) for row in relations}

    confidence_types: set[str] = set()
    for index, row in enumerate(triples, start=2):
        location = f"triples.tsv:{index}"
        confidence_type = row["confidence_type"]
        if confidence_type not in CONFIDENCE_TYPES:
            raise ValueError(f"{location} has unsupported confidence_type: {confidence_type!r}")
        confidence_types.add(confidence_type)
        _parse_confidence(row["confidence"], location)

        graph_id = row["graph_id"]
        if (graph_id, row["head_id"]) not in entity_keys:
            raise ValueError(f"{location} references unknown head entity")
        if (graph_id, row["tail_id"]) not in entity_keys:
            raise ValueError(f"{location} references unknown tail entity")
        if (graph_id, row["relation_id"]) not in relation_keys:
            raise ValueError(f"{location} references unknown relation")

    source_entities = {entity for graph, entity in entity_keys if graph == "source"}
    target_entities = {entity for graph, entity in entity_keys if graph == "target"}
    for index, row in enumerate(attributes, start=2):
        if (row["graph_id"], row["entity_id"]) not in entity_keys:
            raise ValueError(f"attributes.tsv:{index} references unknown entity")
    for index, row in enumerate(alignments, start=2):
        location = f"alignments.tsv:{index}"
        if row["split"] not in ALIGNMENT_SPLITS:
            raise ValueError(f"{location} has unsupported split: {row['split']!r}")
        _parse_confidence(row["confidence"], location)
        if row["source_entity_id"] not in source_entities:
            raise ValueError(f"{location} references unknown source entity")
        if row["target_entity_id"] not in target_entities:
            raise ValueError(f"{location} references unknown target entity")

    with (root / "confidence_metadata.json").open("r", encoding="utf-8") as handle:
        metadata = json.load(handle)
    for key in ("dataset_id", "version", "probability_semantics", "edge_dependence"):
        if key not in metadata:
            raise ValueError(f"confidence_metadata.json is missing key: {key}")

    return ValidationReport(
        dataset_dir=root,
        entity_count=len(entities),
        relation_count=len(relations),
        triple_count=len(triples),
        alignment_count=len(alignments),
        confidence_types=tuple(sorted(confidence_types)),
    )
