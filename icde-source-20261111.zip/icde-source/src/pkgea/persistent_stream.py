"""Durable SQLite compare-and-swap storage for streaming snapshots."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Callable

from pkgea.distributional import GaussianMoments
from pkgea.streaming import (
    MomentIndexSnapshot,
    RevisionConflictError,
    VersionedReadSnapshot,
)


def _encode_snapshot(snapshot: MomentIndexSnapshot) -> str:
    return json.dumps(
        {
            "messages": snapshot.messages,
            "probabilities": snapshot.probabilities,
            "dependency_groups": snapshot.dependency_groups,
            "common_shock_probability": snapshot.common_shock_probability,
            "mean": snapshot.moments.mean,
            "covariance": snapshot.moments.covariance,
        },
        ensure_ascii=False,
        separators=(",", ":"),
        allow_nan=False,
    )


def _decode_snapshot(payload: str) -> MomentIndexSnapshot:
    value = json.loads(payload)
    return MomentIndexSnapshot(
        messages=tuple(tuple(float(item) for item in row) for row in value["messages"]),
        probabilities=tuple(float(item) for item in value["probabilities"]),
        dependency_groups=tuple(str(item) for item in value["dependency_groups"]),
        moments=GaussianMoments(
            mean=tuple(float(item) for item in value["mean"]),
            covariance=tuple(
                tuple(float(item) for item in row)
                for row in value["covariance"]
            ),
        ),
        common_shock_probability=float(
            value.get("common_shock_probability", 0.0)
        ),
    )


class SQLiteSnapshotStore:
    """Externally durable snapshot history with transactional CAS commits.

    Each instance owns one SQLite connection. Independent processes/connections
    coordinate through ``BEGIN IMMEDIATE`` and a version-guarded ``UPDATE``.
    """

    def __init__(self, path: str | Path, *, timeout: float = 5.0) -> None:
        if timeout <= 0.0:
            raise ValueError("timeout must be positive")
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(
            self.path,
            timeout=timeout,
            isolation_level=None,
        )
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA synchronous=FULL")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS stream_head (
                stream_id TEXT PRIMARY KEY,
                version INTEGER NOT NULL,
                snapshot_json TEXT NOT NULL,
                event_id TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS stream_history (
                stream_id TEXT NOT NULL,
                version INTEGER NOT NULL,
                snapshot_json TEXT NOT NULL,
                event_id TEXT NOT NULL,
                PRIMARY KEY (stream_id, version)
            );
            """
        )

    def close(self) -> None:
        self.connection.close()

    def __enter__(self) -> "SQLiteSnapshotStore":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def initialize(
        self,
        stream_id: str,
        snapshot: MomentIndexSnapshot,
    ) -> bool:
        """Create version zero without overwriting an existing stream."""

        if not stream_id:
            raise ValueError("stream_id cannot be empty")
        payload = _encode_snapshot(snapshot)
        self.connection.execute("BEGIN IMMEDIATE")
        try:
            cursor = self.connection.execute(
                """
                INSERT OR IGNORE INTO stream_head
                    (stream_id, version, snapshot_json, event_id)
                VALUES (?, 0, ?, 'initialize')
                """,
                (stream_id, payload),
            )
            created = cursor.rowcount == 1
            if created:
                self.connection.execute(
                    """
                    INSERT INTO stream_history
                        (stream_id, version, snapshot_json, event_id)
                    VALUES (?, 0, ?, 'initialize')
                    """,
                    (stream_id, payload),
                )
            self.connection.execute("COMMIT")
            return created
        except BaseException:
            self.connection.execute("ROLLBACK")
            raise

    def read(
        self,
        stream_id: str,
        version: int | None = None,
    ) -> VersionedReadSnapshot:
        if version is None:
            row = self.connection.execute(
                "SELECT version, snapshot_json FROM stream_head WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()
        else:
            row = self.connection.execute(
                """
                SELECT version, snapshot_json FROM stream_history
                WHERE stream_id = ? AND version = ?
                """,
                (stream_id, version),
            ).fetchone()
        if row is None:
            raise ValueError("stream/version does not exist")
        return VersionedReadSnapshot(int(row[0]), _decode_snapshot(row[1]))

    def compare_and_swap(
        self,
        stream_id: str,
        *,
        expected_version: int,
        snapshot: MomentIndexSnapshot,
        event_id: str,
        _before_commit_hook: Callable[[], None] | None = None,
    ) -> int:
        """Atomically install ``snapshot`` iff the durable head matches."""

        if expected_version < 0:
            raise ValueError("expected_version cannot be negative")
        if not event_id:
            raise ValueError("event_id cannot be empty")
        payload = _encode_snapshot(snapshot)
        next_version = expected_version + 1
        self.connection.execute("BEGIN IMMEDIATE")
        try:
            cursor = self.connection.execute(
                """
                UPDATE stream_head
                SET version = ?, snapshot_json = ?, event_id = ?
                WHERE stream_id = ? AND version = ?
                """,
                (
                    next_version,
                    payload,
                    event_id,
                    stream_id,
                    expected_version,
                ),
            )
            if cursor.rowcount != 1:
                raise RevisionConflictError(
                    "durable stream revision conflict: expected "
                    f"{expected_version}"
                )
            self.connection.execute(
                """
                INSERT INTO stream_history
                    (stream_id, version, snapshot_json, event_id)
                VALUES (?, ?, ?, ?)
                """,
                (stream_id, next_version, payload, event_id),
            )
            if _before_commit_hook is not None:
                _before_commit_hook()
            self.connection.execute("COMMIT")
            return next_version
        except BaseException:
            self.connection.execute("ROLLBACK")
            raise

    def event_version(self, stream_id: str, event_id: str) -> int | None:
        """Return the committed version for an idempotency key, if present."""

        row = self.connection.execute(
            """
            SELECT version FROM stream_history
            WHERE stream_id = ? AND event_id = ?
            ORDER BY version LIMIT 1
            """,
            (stream_id, event_id),
        ).fetchone()
        return None if row is None else int(row[0])

    def history_versions(self, stream_id: str) -> tuple[int, ...]:
        return tuple(
            int(row[0])
            for row in self.connection.execute(
                """
                SELECT version FROM stream_history
                WHERE stream_id = ? ORDER BY version
                """,
                (stream_id,),
            )
        )
