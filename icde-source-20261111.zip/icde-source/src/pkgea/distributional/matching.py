"""Distances between diagonal Gaussian entity representations."""

from __future__ import annotations

import math

from pkgea.distributional.moments import GaussianMoments


def _validated_variances(
    left: GaussianMoments, right: GaussianMoments
) -> tuple[tuple[float, ...], tuple[float, ...]]:
    if len(left.mean) != len(right.mean):
        raise ValueError("Distribution dimensions must match")
    epsilon = 1e-12
    return (
        tuple(max(value, epsilon) for value in left.variance),
        tuple(max(value, epsilon) for value in right.variance),
    )


def diagonal_wasserstein_squared(
    left: GaussianMoments, right: GaussianMoments
) -> float:
    left_variance, right_variance = _validated_variances(left, right)
    return sum(
        (left_mean - right_mean) ** 2
        + (math.sqrt(left_var) - math.sqrt(right_var)) ** 2
        for left_mean, right_mean, left_var, right_var in zip(
            left.mean,
            right.mean,
            left_variance,
            right_variance,
            strict=True,
        )
    )


def symmetric_diagonal_kl(
    left: GaussianMoments, right: GaussianMoments
) -> float:
    left_variance, right_variance = _validated_variances(left, right)

    def kl(
        mean_a: float, variance_a: float, mean_b: float, variance_b: float
    ) -> float:
        return 0.5 * (
            math.log(variance_b / variance_a)
            + (variance_a + (mean_a - mean_b) ** 2) / variance_b
            - 1.0
        )

    forward = sum(
        kl(a, va, b, vb)
        for a, b, va, vb in zip(
            left.mean, right.mean, left_variance, right_variance, strict=True
        )
    )
    reverse = sum(
        kl(b, vb, a, va)
        for a, b, va, vb in zip(
            left.mean, right.mean, left_variance, right_variance, strict=True
        )
    )
    return 0.5 * (forward + reverse)


def diagonal_bhattacharyya(
    left: GaussianMoments, right: GaussianMoments
) -> float:
    """Bhattacharyya distance between diagonal Gaussian distributions."""

    left_variance, right_variance = _validated_variances(left, right)
    total = 0.0
    for left_mean, right_mean, left_var, right_var in zip(
        left.mean,
        right.mean,
        left_variance,
        right_variance,
        strict=True,
    ):
        average = 0.5 * (left_var + right_var)
        total += (
            0.125 * (left_mean - right_mean) ** 2 / average
            + 0.5
            * math.log(
                average / math.sqrt(left_var * right_var)
            )
        )
    return total
