"""Moment corrections for stochastic symmetric degree normalization."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class DegreeNormalizedDeltaResult:
    plugin_mean: np.ndarray
    delta_mean: np.ndarray
    local_edge_counts: tuple[int, ...]
    covariance_ranks: tuple[int, ...]


def degree_normalized_message_delta_mean(
    features: np.ndarray,
    heads: Sequence[int],
    tails: Sequence[int],
    probabilities: Sequence[float],
    query_positions: Sequence[int],
    *,
    dependency_groups: Sequence[str] | None = None,
    common_shock_probability: float = 0.0,
    finite_difference_step: float = 1e-2,
) -> DegreeNormalizedDeltaResult:
    """Approximate ``E[D^-1/2 (A+I) D^-1/2 X]`` by a delta method.

    The plug-in path normalizes the expected weighted graph.  The correction
    contracts a numerical Hessian with the exact local Bernoulli/common-shock
    edge covariance. Only edges that can change the query row or the degrees of
    its possible neighbors enter each local Hessian.
    """

    values = np.asarray(features, dtype=np.float64)
    head_array = np.asarray(heads, dtype=np.int64)
    tail_array = np.asarray(tails, dtype=np.int64)
    probability_array = np.asarray(probabilities, dtype=np.float64)
    if values.ndim != 2 or values.shape[0] == 0 or values.shape[1] == 0:
        raise ValueError("features must be a non-empty matrix")
    if (
        head_array.shape != tail_array.shape
        or head_array.shape != probability_array.shape
        or head_array.ndim != 1
        or len(head_array) == 0
    ):
        raise ValueError("edge arrays must have equal non-zero length")
    if (
        np.any(head_array < 0)
        or np.any(tail_array < 0)
        or np.any(head_array >= len(values))
        or np.any(tail_array >= len(values))
    ):
        raise ValueError("edge endpoint is outside feature scope")
    if np.any(probability_array < 0.0) or np.any(probability_array > 1.0):
        raise ValueError("probabilities must lie in [0, 1]")
    if not 0.0 <= common_shock_probability <= 1.0:
        raise ValueError("common_shock_probability must lie in [0, 1]")
    if not np.isfinite(finite_difference_step) or finite_difference_step <= 0:
        raise ValueError("finite_difference_step must be finite and positive")
    groups = tuple(dependency_groups or ("",) * len(head_array))
    if len(groups) != len(head_array):
        raise ValueError("dependency_groups length mismatch")
    queries = tuple(int(position) for position in query_positions)
    if not queries or any(position < 0 or position >= len(values) for position in queries):
        raise ValueError("query_positions are outside feature scope")

    incident: list[list[int]] = [[] for _ in range(len(values))]
    for edge_index, (head, tail) in enumerate(
        zip(head_array, tail_array, strict=True)
    ):
        incident[int(head)].append(edge_index)
        incident[int(tail)].append(edge_index)

    def degrees(weights: np.ndarray) -> np.ndarray:
        result = np.ones(len(values), dtype=np.float64)
        np.add.at(result, head_array, weights)
        np.add.at(result, tail_array, weights)
        return result

    def message(position: int, weights: np.ndarray) -> np.ndarray:
        degree = degrees(weights)
        output = values[position] / degree[position]
        source_scale = degree[position] ** -0.5
        for edge_index in incident[position]:
            head = int(head_array[edge_index])
            tail = int(tail_array[edge_index])
            neighbor = tail if head == position else head
            output = output + (
                weights[edge_index]
                * source_scale
                * degree[neighbor] ** -0.5
                * values[neighbor]
            )
        return output

    plugin_rows = []
    delta_rows = []
    local_counts = []
    ranks = []
    for position in queries:
        local_edges = set(incident[position])
        for edge_index in incident[position]:
            head = int(head_array[edge_index])
            tail = int(tail_array[edge_index])
            neighbor = tail if head == position else head
            local_edges.update(incident[neighbor])
        local = np.asarray(sorted(local_edges), dtype=np.int64)
        base = message(position, probability_array)
        covariance = np.diag(
            probability_array[local] * (1.0 - probability_array[local])
        )
        if common_shock_probability > 0.0:
            for left in range(len(local)):
                left_edge = int(local[left])
                if not groups[left_edge]:
                    continue
                for right in range(left + 1, len(local)):
                    right_edge = int(local[right])
                    if groups[left_edge] != groups[right_edge]:
                        continue
                    covariance_value = common_shock_probability * (
                        min(
                            probability_array[left_edge],
                            probability_array[right_edge],
                        )
                        - probability_array[left_edge]
                        * probability_array[right_edge]
                    )
                    covariance[left, right] = covariance_value
                    covariance[right, left] = covariance_value
        eigenvalues, eigenvectors = np.linalg.eigh(covariance)
        correction = np.zeros(values.shape[1], dtype=np.float64)
        positive = np.flatnonzero(eigenvalues > 1e-12)
        for direction_index in positive:
            direction = eigenvectors[:, direction_index]
            plus = probability_array.copy()
            minus = probability_array.copy()
            plus[local] += finite_difference_step * direction
            minus[local] -= finite_difference_step * direction
            directional_second = (
                message(position, plus)
                - 2.0 * base
                + message(position, minus)
            ) / (finite_difference_step**2)
            correction += eigenvalues[direction_index] * directional_second
        plugin_rows.append(base)
        delta_rows.append(base + 0.5 * correction)
        local_counts.append(len(local))
        ranks.append(len(positive))
    return DegreeNormalizedDeltaResult(
        plugin_mean=np.stack(plugin_rows),
        delta_mean=np.stack(delta_rows),
        local_edge_counts=tuple(local_counts),
        covariance_ranks=tuple(ranks),
    )
