"""Moment propagation for Bernoulli-gated graph messages."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence


@dataclass(frozen=True)
class GaussianMoments:
    mean: tuple[float, ...]
    covariance: tuple[tuple[float, ...], ...]

    @property
    def variance(self) -> tuple[float, ...]:
        return tuple(self.covariance[index][index] for index in range(len(self.mean)))


def _outer(left: Sequence[float], right: Sequence[float]) -> list[list[float]]:
    return [[x * y for y in right] for x in left]


def aggregate_bernoulli_messages(
    messages: Sequence[Sequence[float]],
    probabilities: Sequence[float],
    *,
    dependency_groups: Sequence[str] | None = None,
    common_shock_probability: float = 0.0,
) -> GaussianMoments:
    """Propagate first and second moments through ``M = sum_i Z_i m_i``.

    Edges in the same non-empty group use the marginal-preserving common-shock
    model from the sampler. For a shared uniform draw,
    ``Cov(Z_i,Z_j) = min(p_i,p_j) - p_i p_j``; the mixture scales it by rho.
    """

    if not messages or len(messages) != len(probabilities):
        raise ValueError("messages and probabilities must have equal non-zero length")
    dimension = len(messages[0])
    if dimension == 0 or any(len(message) != dimension for message in messages):
        raise ValueError("All messages must have the same positive dimension")
    if any(not 0.0 <= probability <= 1.0 for probability in probabilities):
        raise ValueError("Probabilities must lie in [0, 1]")
    if not 0.0 <= common_shock_probability <= 1.0:
        raise ValueError("common_shock_probability must lie in [0, 1]")
    groups = tuple(dependency_groups or ("",) * len(probabilities))
    if len(groups) != len(probabilities):
        raise ValueError("dependency_groups length must match probabilities")

    mean = [0.0] * dimension
    covariance = [[0.0] * dimension for _ in range(dimension)]
    for message, probability in zip(messages, probabilities, strict=True):
        for coordinate, value in enumerate(message):
            mean[coordinate] += probability * value
        self_covariance = _outer(message, message)
        scale = probability * (1.0 - probability)
        for row in range(dimension):
            for column in range(dimension):
                covariance[row][column] += scale * self_covariance[row][column]

    for left in range(len(messages)):
        for right in range(left + 1, len(messages)):
            if not groups[left] or groups[left] != groups[right]:
                continue
            edge_covariance = common_shock_probability * (
                min(probabilities[left], probabilities[right])
                - probabilities[left] * probabilities[right]
            )
            cross_lr = _outer(messages[left], messages[right])
            cross_rl = _outer(messages[right], messages[left])
            for row in range(dimension):
                for column in range(dimension):
                    covariance[row][column] += edge_covariance * (
                        cross_lr[row][column] + cross_rl[row][column]
                    )

    return GaussianMoments(
        mean=tuple(mean),
        covariance=tuple(tuple(row) for row in covariance),
    )


def relu_gaussian_moments(moments: GaussianMoments) -> GaussianMoments:
    """Coordinate-wise Gaussian moment matching through ReLU.

    Off-diagonal covariance is conservatively dropped. This is an explicit
    diagonal approximation and must be reported as such in experiments.
    """

    means: list[float] = []
    variances: list[float] = []
    for mean, variance in zip(moments.mean, moments.variance, strict=True):
        if variance <= 1e-15:
            transformed = max(mean, 0.0)
            means.append(transformed)
            variances.append(0.0)
            continue
        std = math.sqrt(variance)
        alpha = mean / std
        phi = math.exp(-0.5 * alpha * alpha) / math.sqrt(2.0 * math.pi)
        cdf = 0.5 * (1.0 + math.erf(alpha / math.sqrt(2.0)))
        transformed_mean = std * phi + mean * cdf
        second_moment = (mean * mean + variance) * cdf + mean * std * phi
        means.append(transformed_mean)
        variances.append(max(second_moment - transformed_mean**2, 0.0))
    covariance = tuple(
        tuple(
            variances[row] if row == column else 0.0
            for column in range(len(variances))
        )
        for row in range(len(variances))
    )
    return GaussianMoments(tuple(means), covariance)


def linear_gaussian_moments(
    moments: GaussianMoments,
    weights: Sequence[Sequence[float]],
    bias: Sequence[float] | None = None,
) -> GaussianMoments:
    """Exact first/second-moment propagation through ``Y = W X + b``."""

    input_dimension = len(moments.mean)
    if not weights or any(len(row) != input_dimension for row in weights):
        raise ValueError("Each weight row must match the input dimension")
    output_dimension = len(weights)
    offsets = tuple(bias or (0.0,) * output_dimension)
    if len(offsets) != output_dimension:
        raise ValueError("bias length must match the number of weight rows")

    mean = tuple(
        sum(weight * value for weight, value in zip(row, moments.mean, strict=True))
        + offsets[index]
        for index, row in enumerate(weights)
    )
    covariance = []
    for left in weights:
        output_row = []
        for right in weights:
            output_row.append(
                sum(
                    left[row]
                    * moments.covariance[row][column]
                    * right[column]
                    for row in range(input_dimension)
                    for column in range(input_dimension)
                )
            )
        covariance.append(tuple(output_row))
    return GaussianMoments(mean, tuple(covariance))


def propagate_relu_network(
    moments: GaussianMoments,
    layers: Sequence[
        tuple[Sequence[Sequence[float]], Sequence[float] | None]
    ],
) -> tuple[GaussianMoments, ...]:
    """Propagate a diagonal-Gaussian approximation through ReLU layers."""

    outputs: list[GaussianMoments] = []
    current = moments
    for weights, bias in layers:
        current = relu_gaussian_moments(
            linear_gaussian_moments(current, weights, bias)
        )
        outputs.append(current)
    return tuple(outputs)
