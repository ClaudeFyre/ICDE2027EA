"""Full, block-diagonal, and low-rank Gaussian covariance operators."""

from __future__ import annotations

import numpy as np


def positive_semidefinite(matrix: np.ndarray) -> np.ndarray:
    """Symmetrize and clip numerical negative eigenvalues."""

    symmetric = (matrix + matrix.T) / 2.0
    values, vectors = np.linalg.eigh(symmetric)
    return (vectors * np.maximum(values, 0.0)) @ vectors.T


def approximate_covariance(
    covariance: np.ndarray,
    mode: str,
    *,
    block_size: int = 8,
    rank: int = 8,
) -> np.ndarray:
    """Return a PSD covariance approximation under a fixed storage family."""

    covariance = positive_semidefinite(np.asarray(covariance, dtype=np.float64))
    dimension = covariance.shape[0]
    if covariance.shape != (dimension, dimension):
        raise ValueError("covariance must be square")
    if mode == "full":
        return covariance
    if mode == "diagonal":
        return np.diag(np.diag(covariance))
    if mode == "block":
        if block_size <= 0:
            raise ValueError("block_size must be positive")
        result = np.zeros_like(covariance)
        for start in range(0, dimension, block_size):
            stop = min(start + block_size, dimension)
            result[start:stop, start:stop] = covariance[
                start:stop, start:stop
            ]
        return positive_semidefinite(result)
    if mode == "low_rank":
        factor, residual = low_rank_plus_diagonal(covariance, rank=rank)
        return positive_semidefinite(factor @ factor.T + np.diag(residual))
    raise ValueError(f"Unsupported covariance approximation: {mode}")


def low_rank_plus_diagonal(
    covariance: np.ndarray,
    *,
    rank: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Factor a covariance as ``F Fᵀ + diag(residual)``."""

    if rank <= 0:
        raise ValueError("rank must be positive")
    covariance = positive_semidefinite(np.asarray(covariance, dtype=np.float64))
    dimension = covariance.shape[0]
    values, vectors = np.linalg.eigh(covariance)
    selected = np.argsort(values)[-min(rank, dimension) :]
    factor = vectors[:, selected] * np.sqrt(
        np.maximum(values[selected], 0.0)
    )
    low_rank = factor @ factor.T
    residual = np.maximum(
        np.diag(covariance) - np.diag(low_rank),
        0.0,
    )
    return factor, residual


def gaussian_wasserstein_squared(
    left_mean: np.ndarray,
    left_covariance: np.ndarray,
    right_mean: np.ndarray,
    right_covariance: np.ndarray,
) -> float:
    """Squared 2-Wasserstein distance between two Gaussian distributions."""

    left = positive_semidefinite(left_covariance)
    right = positive_semidefinite(right_covariance)
    values, vectors = np.linalg.eigh(right)
    right_sqrt = (
        vectors * np.sqrt(np.maximum(values, 0.0))
    ) @ vectors.T
    middle = positive_semidefinite(right_sqrt @ left @ right_sqrt)
    middle_values = np.linalg.eigvalsh(middle)
    covariance_term = (
        np.trace(left)
        + np.trace(right)
        - 2.0 * np.sum(np.sqrt(np.maximum(middle_values, 0.0)))
    )
    mean_difference = np.asarray(left_mean) - np.asarray(right_mean)
    return max(
        0.0,
        float(mean_difference @ mean_difference + covariance_term),
    )
