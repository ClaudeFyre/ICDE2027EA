"""Anytime-valid top-1 winner certification and cross-query scheduling.

One possible world reveals a categorical winner for every candidate in a
query.  The resulting pairwise observation is in ``{-1, 0, 1}``.  We use a
two-sided normal-mixture confidence sequence for its mean and a union bound
over all unordered candidate pairs.  Cross-query scheduling is predictable:
it uses only observations and costs revealed before the next batch.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Hashable, Mapping, Sequence


def normal_mixture_radius(
    sample_count: int,
    alpha: float,
    *,
    rho: float = 64.0,
) -> float:
    """Return a time-uniform radius for the mean of observations in [-1, 1].

    Hoeffding's lemma makes the centered partial sum 1-sub-Gaussian. Mixing
    its exponential supermartingales with ``N(0, 1/rho)`` and applying
    Ville's inequality yields

    ``|mean_n - mean| <= sqrt((n+rho) log((n+rho)/(rho alpha^2))) / n``

    simultaneously for every ``n >= 1`` with probability at least
    ``1-alpha``. ``rho`` is a fixed tuning parameter and does not affect
    validity.
    """

    if sample_count <= 0:
        raise ValueError("sample_count must be positive")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    if not math.isfinite(rho) or rho <= 0.0:
        raise ValueError("rho must be finite and positive")
    n = float(sample_count)
    return math.sqrt(
        (n + rho) * math.log((n + rho) / (rho * alpha * alpha))
    ) / n


def informative_subsequence_radius(
    informative_count: int,
    alpha: float,
    *,
    rho: float = 64.0,
) -> float:
    """Return a time-uniform radius for ``pi_c - pi_c'`` on informative worlds.

    The pairwise observation ``D_t`` is zero unless the world winner is ``c``
    or ``c'``.  For i.i.d. worlds, the informative worlds form a subsequence of
    i.i.d. Bernoulli draws with success probability
    ``p = pi_c / (pi_c + pi_c')``, so a confidence sequence indexed by the
    informative count ``m = N_c + N_c'`` is valid by the same optional-skipping
    argument that protects predictable interleaving.  A ``[0, 1]``-valued draw
    is ``1/2``-sub-Gaussian, giving

    ``|p_hat - p| <= sqrt((m+rho) log((m+rho)/(rho alpha^2))) / (2m)``

    and ``mu = 2p - 1`` doubles that radius.

    Since ``mu = 2p - 1``, doubling the ``p`` radius returns exactly
    ``normal_mixture_radius`` evaluated at ``m``.  The saving comes from the
    paired estimate: this radius must be compared against the *conditional*
    gap ``(N_c - N_c') / m``, not the marginal ``(N_c - N_c') / n``.  Writing
    ``q = (pi_c + pi_c')`` for the informative fraction, certification of a
    marginal gap ``Delta`` then needs ``O(q Delta^-2)`` worlds rather than
    ``O(Delta^-2)`` -- a large saving whenever the winner law is spread over
    many candidates, which is the regime where the range-only variance proxy
    ``sigma^2 = 1`` is worst.
    """

    if informative_count <= 0:
        raise ValueError("informative_count must be positive")
    return normal_mixture_radius(informative_count, alpha, rho=rho)


DEFAULT_BETTING_FRACTIONS = tuple(2.0 ** (-power) for power in range(1, 11))

UNION_BOUND_RULES = ("all_pairs", "winner_pairs")


def pairwise_alpha(
    candidate_count: int,
    delta: float,
    *,
    union_bound: str = "all_pairs",
    directed: bool = False,
) -> float:
    """Return the per-pair risk level under the requested union bound.

    ``all_pairs`` splits ``delta`` over every candidate pair and reproduces the
    frozen runs.  ``winner_pairs`` splits it over the ``|C| - 1`` pairs that
    contain the modal winner, which is all the correctness argument needs: an
    incorrect certificate must clear the comparison against ``c*``, and the
    remaining pairs enter the stopping rule only as extra separation
    requirements, so their failure can delay a certificate but never create
    one.  ``c*`` is unknown but fixed, so the family is chosen before any data
    is seen and one level is still applied to every pair.
    """

    if candidate_count < 1:
        raise ValueError("candidate_count must be positive")
    if not 0.0 < delta < 1.0:
        raise ValueError("delta must be in (0, 1)")
    if union_bound not in UNION_BOUND_RULES:
        raise ValueError(f"unsupported union bound: {union_bound}")
    if union_bound == "winner_pairs":
        divisor = max(candidate_count - 1, 1)
    elif directed:
        divisor = max(candidate_count * (candidate_count - 1), 1)
    else:
        divisor = max(candidate_count * (candidate_count - 1) // 2, 1)
    return delta / divisor


def categorical_betting_log_evalue(
    leader_count: int,
    competitor_count: int,
    *,
    betting_fractions: Sequence[float] = DEFAULT_BETTING_FRACTIONS,
) -> float:
    """Return a mixture betting log e-value for ``pi_leader <= pi_competitor``.

    For a fixed predictable fraction ``lambda`` and pairwise observation
    ``D_t in {-1, 0, 1}``, ``prod_t (1 + lambda D_t)`` is a nonnegative
    supermartingale whenever ``E[D_t | F_{t-1}] <= 0``.  A fixed mixture over
    fractions is therefore an e-process as well.  Counts are sufficient because
    zero observations contribute a factor of one.
    """

    if leader_count < 0 or competitor_count < 0:
        raise ValueError("counts must be nonnegative")
    fractions = tuple(float(value) for value in betting_fractions)
    if not fractions:
        raise ValueError("betting_fractions must be non-empty")
    if any(not math.isfinite(value) or not 0.0 < value < 1.0 for value in fractions):
        raise ValueError("every betting fraction must be finite and in (0, 1)")
    log_capitals = [
        leader_count * math.log1p(value)
        + competitor_count * math.log1p(-value)
        for value in fractions
    ]
    maximum = max(log_capitals)
    return maximum + math.log(
        sum(math.exp(value - maximum) for value in log_capitals) / len(log_capitals)
    )


@dataclass(frozen=True)
class PairwiseBound:
    leader: Hashable
    competitor: Hashable
    estimate: float
    lower: float
    upper: float
    alpha: float

    @property
    def width(self) -> float:
        return self.upper - self.lower

    def as_dict(self) -> dict[str, object]:
        return {
            "leader": str(self.leader),
            "competitor": str(self.competitor),
            "estimate": self.estimate,
            "lower": self.lower,
            "upper": self.upper,
            "alpha": self.alpha,
        }


@dataclass(frozen=True)
class CertifiedWinnerResult:
    query_id: Hashable
    status: str
    estimated_winner: Hashable
    certified_winner: Hashable | None
    samples_used: int
    delta: float
    pair_alpha: float
    confidence_sequence: str
    winner_probabilities: tuple[tuple[Hashable, float], ...]
    pairwise_bounds: tuple[PairwiseBound, ...]

    @property
    def stable(self) -> bool:
        return self.status == "stable"

    def as_dict(self) -> dict[str, object]:
        return {
            "query_id": str(self.query_id),
            "status": self.status,
            "estimated_winner": str(self.estimated_winner),
            "certified_winner": (
                str(self.certified_winner)
                if self.certified_winner is not None
                else None
            ),
            "samples_used": self.samples_used,
            "delta": self.delta,
            "pair_alpha": self.pair_alpha,
            "confidence_sequence": self.confidence_sequence,
            "winner_probabilities": {
                str(candidate): probability
                for candidate, probability in self.winner_probabilities
            },
            "pairwise_bounds": [bound.as_dict() for bound in self.pairwise_bounds],
        }


@dataclass
class PairwiseWinnerState:
    """Sufficient statistics for one categorical top-1 winner query."""

    query_id: Hashable
    candidates: tuple[Hashable, ...]
    delta: float = 0.05
    rho: float = 64.0
    union_bound: str = "all_pairs"
    clock: str = "all_worlds"
    counts: dict[Hashable, int] = field(init=False)
    samples: int = field(default=0, init=False)
    certified_winner: Hashable | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        if not self.candidates:
            raise ValueError("candidates must be non-empty")
        if len(set(self.candidates)) != len(self.candidates):
            raise ValueError("candidates must be unique")
        if not 0.0 < self.delta < 1.0:
            raise ValueError("delta must be in (0, 1)")
        if not math.isfinite(self.rho) or self.rho <= 0.0:
            raise ValueError("rho must be finite and positive")
        if self.union_bound not in UNION_BOUND_RULES:
            raise ValueError(f"unsupported union bound: {self.union_bound}")
        if self.clock not in {"all_worlds", "informative"}:
            raise ValueError(f"unsupported clock: {self.clock}")
        self.counts = {candidate: 0 for candidate in self.candidates}

    @property
    def pair_count(self) -> int:
        return max(len(self.candidates) * (len(self.candidates) - 1) // 2, 1)

    @property
    def pair_alpha(self) -> float:
        return pairwise_alpha(
            len(self.candidates), self.delta, union_bound=self.union_bound
        )

    @property
    def stable(self) -> bool:
        return self.certified_winner is not None

    @property
    def estimated_winner(self) -> Hashable:
        return min(
            self.candidates,
            key=lambda candidate: (-self.counts[candidate], str(candidate)),
        )

    def update(
        self,
        winners: Sequence[Hashable],
        *,
        evaluate_certificate: bool = True,
    ) -> None:
        if self.stable:
            raise ValueError("cannot update an already certified query")
        if len(winners) == 0:
            raise ValueError("winners must be non-empty")
        for winner in winners:
            if winner not in self.counts:
                raise ValueError(f"winner {winner!r} is outside the candidate set")
            self.counts[winner] += 1
            self.samples += 1
        if evaluate_certificate:
            self._refresh_certificate()

    def _bound(self, leader: Hashable, competitor: Hashable) -> PairwiseBound:
        if self.samples <= 0:
            raise ValueError("at least one observation is required")
        difference = self.counts[leader] - self.counts[competitor]
        if self.clock == "informative":
            # Read the pair on the subsequence of worlds that separate it.  The
            # estimate becomes the conditional gap ``2p - 1`` and the radius is
            # indexed by the informative count, so the two stay on one clock.
            informative = self.counts[leader] + self.counts[competitor]
            if informative <= 0:
                return PairwiseBound(
                    leader=leader,
                    competitor=competitor,
                    estimate=0.0,
                    lower=-1.0,
                    upper=1.0,
                    alpha=self.pair_alpha,
                )
            estimate = difference / informative
            radius = informative_subsequence_radius(
                informative, self.pair_alpha, rho=self.rho
            )
        else:
            estimate = difference / self.samples
            radius = normal_mixture_radius(
                self.samples,
                self.pair_alpha,
                rho=self.rho,
            )
        return PairwiseBound(
            leader=leader,
            competitor=competitor,
            estimate=estimate,
            lower=max(-1.0, estimate - radius),
            upper=min(1.0, estimate + radius),
            alpha=self.pair_alpha,
        )

    def leader_bounds(self) -> tuple[PairwiseBound, ...]:
        if self.samples <= 0:
            return ()
        leader = self.estimated_winner
        return tuple(
            sorted(
                (
                    self._bound(leader, competitor)
                    for competitor in self.candidates
                    if competitor != leader
                ),
                key=lambda bound: (bound.lower, str(bound.competitor)),
            )
        )

    def hardest_bound(self) -> PairwiseBound | None:
        if self.samples <= 0 or len(self.candidates) <= 1:
            return None
        leader = self.estimated_winner
        return min(
            (
                self._bound(leader, competitor)
                for competitor in self.candidates
                if competitor != leader
            ),
            key=lambda bound: (bound.lower, str(bound.competitor)),
        )

    def _refresh_certificate(self) -> None:
        if len(self.candidates) == 1:
            self.certified_winner = self.candidates[0]
            return
        hardest = self.hardest_bound()
        if hardest is not None and hardest.lower > 0.0:
            self.certified_winner = self.estimated_winner

    def result(self, *, exhausted: bool = False) -> CertifiedWinnerResult:
        if self.samples <= 0:
            raise ValueError("cannot report an unobserved query")
        status = "stable" if self.stable else "budget_exhausted"
        if not self.stable and not exhausted:
            status = "running"
        return CertifiedWinnerResult(
            query_id=self.query_id,
            status=status,
            estimated_winner=self.estimated_winner,
            certified_winner=self.certified_winner,
            samples_used=self.samples,
            delta=self.delta,
            pair_alpha=self.pair_alpha,
            confidence_sequence=(
                "normal-mixture-hoeffding-pairwise-v1"
                if self.clock == "all_worlds" and self.union_bound == "all_pairs"
                else f"normal-mixture-{self.clock}-{self.union_bound}-v2"
            ),
            winner_probabilities=tuple(
                (candidate, self.counts[candidate] / self.samples)
                for candidate in self.candidates
            ),
            pairwise_bounds=self.leader_bounds(),
        )


@dataclass(frozen=True)
class BettingPairEvidence:
    leader: Hashable
    competitor: Hashable
    estimate: float
    log_e_value: float
    alpha: float

    @property
    def rejects_nonpositive_gap(self) -> bool:
        return self.log_e_value >= math.log(1.0 / self.alpha)

    def as_dict(self) -> dict[str, object]:
        return {
            "leader": str(self.leader),
            "competitor": str(self.competitor),
            "estimate": self.estimate,
            "log_e_value": self.log_e_value,
            "alpha": self.alpha,
            "rejects_nonpositive_gap": self.rejects_nonpositive_gap,
        }


@dataclass
class PairwiseBettingWinnerState:
    """Anytime-valid categorical winner test using directed betting e-processes."""

    query_id: Hashable
    candidates: tuple[Hashable, ...]
    delta: float = 0.05
    betting_fractions: tuple[float, ...] = DEFAULT_BETTING_FRACTIONS
    union_bound: str = "all_pairs"
    counts: dict[Hashable, int] = field(init=False)
    samples: int = field(default=0, init=False)
    certified_winner: Hashable | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        if not self.candidates:
            raise ValueError("candidates must be non-empty")
        if len(set(self.candidates)) != len(self.candidates):
            raise ValueError("candidates must be unique")
        if not 0.0 < self.delta < 1.0:
            raise ValueError("delta must be in (0, 1)")
        if self.union_bound not in UNION_BOUND_RULES:
            raise ValueError(f"unsupported union bound: {self.union_bound}")
        # Reuse the public function's strict fraction validation.
        categorical_betting_log_evalue(
            0, 0, betting_fractions=self.betting_fractions
        )
        self.counts = {candidate: 0 for candidate in self.candidates}

    @property
    def directed_pair_count(self) -> int:
        return max(len(self.candidates) * (len(self.candidates) - 1), 1)

    @property
    def pair_alpha(self) -> float:
        return pairwise_alpha(
            len(self.candidates),
            self.delta,
            union_bound=self.union_bound,
            directed=True,
        )

    @property
    def stable(self) -> bool:
        return self.certified_winner is not None

    @property
    def estimated_winner(self) -> Hashable:
        return min(
            self.candidates,
            key=lambda candidate: (-self.counts[candidate], str(candidate)),
        )

    def update(
        self,
        winners: Sequence[Hashable],
        *,
        evaluate_certificate: bool = True,
    ) -> None:
        if self.stable:
            raise ValueError("cannot update an already certified query")
        if len(winners) == 0:
            raise ValueError("winners must be non-empty")
        for winner in winners:
            if winner not in self.counts:
                raise ValueError(f"winner {winner!r} is outside the candidate set")
            self.counts[winner] += 1
            self.samples += 1
        if evaluate_certificate:
            self._refresh_certificate()

    def leader_evidence(self) -> tuple[BettingPairEvidence, ...]:
        if self.samples <= 0:
            return ()
        leader = self.estimated_winner
        evidence = []
        for competitor in self.candidates:
            if competitor == leader:
                continue
            evidence.append(
                BettingPairEvidence(
                    leader=leader,
                    competitor=competitor,
                    estimate=(
                        self.counts[leader] - self.counts[competitor]
                    ) / self.samples,
                    log_e_value=categorical_betting_log_evalue(
                        self.counts[leader],
                        self.counts[competitor],
                        betting_fractions=self.betting_fractions,
                    ),
                    alpha=self.pair_alpha,
                )
            )
        return tuple(
            sorted(
                evidence,
                key=lambda item: (item.log_e_value, str(item.competitor)),
            )
        )

    def _refresh_certificate(self) -> None:
        if len(self.candidates) == 1:
            self.certified_winner = self.candidates[0]
            return
        evidence = self.leader_evidence()
        if evidence and all(item.rejects_nonpositive_gap for item in evidence):
            self.certified_winner = self.estimated_winner


def certify_winner_sequence(
    query_id: Hashable,
    candidates: Sequence[Hashable],
    winner_sequence: Sequence[Hashable],
    *,
    delta: float = 0.05,
    batch_size: int = 16,
    minimum_samples: int = 32,
    rho: float = 64.0,
    union_bound: str = "all_pairs",
    clock: str = "all_worlds",
) -> CertifiedWinnerResult:
    """Certify one query over a finite prefix, otherwise return exhaustion."""

    if len(winner_sequence) == 0:
        raise ValueError("winner_sequence must be non-empty")
    if batch_size <= 0 or minimum_samples <= 0:
        raise ValueError("batch_size and minimum_samples must be positive")
    state = PairwiseWinnerState(
        query_id=query_id,
        candidates=tuple(candidates),
        delta=delta,
        rho=rho,
        union_bound=union_bound,
        clock=clock,
    )
    offset = 0
    while offset < len(winner_sequence):
        stop = min(offset + batch_size, len(winner_sequence))
        state.update(
            winner_sequence[offset:stop],
            evaluate_certificate=stop >= minimum_samples,
        )
        offset = stop
        if state.samples >= minimum_samples and state.stable:
            return state.result()
    return state.result(exhausted=True)


@dataclass(frozen=True)
class CertifiedSchedulerConfig:
    global_budget: float
    strategy: str = "gap_cost"
    pilot_samples_per_query: int = 32
    batch_size: int = 16
    delta: float = 0.05
    rho: float = 64.0
    maximum_samples_per_query: int | None = None
    aging_weight: float = 0.01
    max_consecutive_batches: int = 4
    record_allocation_trace: bool = True
    union_bound: str = "all_pairs"
    clock: str = "all_worlds"

    def validate(self, query_count: int, pilot_cost: float) -> None:
        if query_count <= 0:
            raise ValueError("at least one query is required")
        if self.strategy not in {
            "uniform",
            "uncertainty_only",
            "cost_only",
            "gap_cost",
            "gap_cost_known_gap",
        }:
            raise ValueError(f"unsupported scheduling strategy: {self.strategy}")
        if self.global_budget < pilot_cost:
            raise ValueError("global_budget is smaller than the mandatory pilot cost")
        if self.pilot_samples_per_query <= 0 or self.batch_size <= 0:
            raise ValueError("pilot and batch sizes must be positive")
        if self.maximum_samples_per_query is not None and (
            self.maximum_samples_per_query < self.pilot_samples_per_query
        ):
            raise ValueError("maximum_samples_per_query is smaller than the pilot")
        if self.aging_weight < 0.0 or self.max_consecutive_batches <= 0:
            raise ValueError("invalid aging or consecutive-batch setting")
        if self.union_bound not in UNION_BOUND_RULES:
            raise ValueError(f"unsupported union bound: {self.union_bound}")
        if self.clock not in {"all_worlds", "informative"}:
            raise ValueError(f"unsupported clock: {self.clock}")


@dataclass(frozen=True)
class CertifiedSchedulingResult:
    strategy: str
    queries: tuple[CertifiedWinnerResult, ...]
    total_worlds: int
    total_cost: float
    global_budget: float
    allocation_trace: tuple[dict[str, object], ...]

    @property
    def stable_queries(self) -> int:
        return sum(result.stable for result in self.queries)

    def as_dict(self) -> dict[str, object]:
        return {
            "strategy": self.strategy,
            "queries": [result.as_dict() for result in self.queries],
            "stable_queries": self.stable_queries,
            "stable_coverage": self.stable_queries / len(self.queries),
            "total_worlds": self.total_worlds,
            "total_cost": self.total_cost,
            "global_budget": self.global_budget,
            "allocation_trace": list(self.allocation_trace),
        }


def schedule_certified_winner_streams(
    winner_streams: Mapping[Hashable, Sequence[Hashable]],
    candidates_by_query: Mapping[Hashable, Sequence[Hashable]],
    local_costs: Mapping[Hashable, float],
    config: CertifiedSchedulerConfig,
    *,
    generating_gaps: Mapping[Hashable, float] | None = None,
) -> CertifiedSchedulingResult:
    """Schedule certified query batches under a shared measured-cost budget.

    The ``gap_cost`` strategy is intentionally labelled a heuristic. It plugs
    the observed hardest-competitor gap into the confidence-sequence shrinkage
    rate, estimates the remaining worlds needed for separation, and prioritizes
    the inverse remaining local cost. Aging and a consecutive-batch cap prevent
    starvation. Correctness follows from the per-query confidence sequences and
    predictable scheduling; no global allocation optimality is claimed.
    """

    query_ids = tuple(winner_streams)
    if set(query_ids) != set(candidates_by_query) or set(query_ids) != set(local_costs):
        raise ValueError("streams, candidates, and costs must have identical keys")
    if config.strategy == "gap_cost_known_gap":
        if generating_gaps is None or set(query_ids) != set(generating_gaps):
            raise ValueError(
                "gap_cost_known_gap requires generating_gaps with identical keys"
            )
        if any(
            not math.isfinite(float(generating_gaps[query]))
            or float(generating_gaps[query]) < 0.0
            for query in query_ids
        ):
            raise ValueError("generating gaps must be finite and nonnegative")
    costs = {query: float(local_costs[query]) for query in query_ids}
    if any(not math.isfinite(cost) or cost <= 0.0 for cost in costs.values()):
        raise ValueError("local costs must be finite and positive")
    pilot_cost = sum(
        config.pilot_samples_per_query * costs[query] for query in query_ids
    )
    config.validate(len(query_ids), pilot_cost)
    if any(
        len(winner_streams[query]) < config.pilot_samples_per_query
        for query in query_ids
    ):
        raise ValueError("every winner stream must cover the mandatory pilot")

    states = {
        query: PairwiseWinnerState(
            query_id=query,
            candidates=tuple(candidates_by_query[query]),
            delta=config.delta,
            rho=config.rho,
            union_bound=config.union_bound,
            clock=config.clock,
        )
        for query in query_ids
    }
    offsets = dict.fromkeys(query_ids, 0)
    positions = {query: position for position, query in enumerate(query_ids)}
    ages = dict.fromkeys(query_ids, 0)
    trace: list[dict[str, object]] = []
    spent = 0.0

    for query in query_ids:
        stop = config.pilot_samples_per_query
        states[query].update(winner_streams[query][:stop])
        offsets[query] = stop
        cost = stop * costs[query]
        spent += cost
        if config.record_allocation_trace:
            trace.append(
                {
                    "phase": "pilot",
                    "query_id": str(query),
                    "samples": stop,
                    "cost": cost,
                    "cumulative_cost": spent,
                }
            )

    round_robin_cursor = 0
    previous: Hashable | None = None
    consecutive = 0
    tolerance = max(1e-12, abs(config.global_budget) * 1e-12)

    def eligible(query: Hashable) -> bool:
        if states[query].stable or offsets[query] >= len(winner_streams[query]):
            return False
        if (
            config.maximum_samples_per_query is not None
            and states[query].samples >= config.maximum_samples_per_query
        ):
            return False
        return spent + costs[query] <= config.global_budget + tolerance

    def base_priority(query: Hashable) -> float:
        bound = states[query].hardest_bound()
        width = bound.width if bound is not None else 0.0
        overlap = max(0.0, -bound.lower) if bound is not None else 0.0
        if config.strategy == "uncertainty_only":
            base = overlap + 0.5 * width
        elif config.strategy == "cost_only":
            base = 1.0 / costs[query]
        else:
            assert bound is not None
            state = states[query]
            # The gap estimate and the radius must be read on the same clock:
            # under the informative clock both are indexed by the number of
            # worlds that separated the hardest pair, and the resulting
            # requirement is converted back to worlds by the observed
            # informative rate.
            if config.clock == "informative":
                clock_count = max(
                    state.counts[bound.leader] + state.counts[bound.competitor], 1
                )
                radius = informative_subsequence_radius(
                    clock_count, state.pair_alpha, rho=state.rho
                )
            else:
                clock_count = state.samples
                radius = normal_mixture_radius(
                    clock_count, state.pair_alpha, rho=state.rho
                )
            # The radius is approximately proportional to n^{-1/2}.  Plugging
            # in the observed hardest-pair gap gives a transparent remaining-
            # sample proxy.  A 1/n floor avoids an infinite priority inversion
            # at empirical ties without pretending that ties are identifiable.
            estimated_gap = (
                float(generating_gaps[query])
                if config.strategy == "gap_cost_known_gap"
                else bound.estimate
            )
            gap = max(estimated_gap, 1.0 / clock_count)
            target = clock_count * (radius / gap) ** 2
            remaining = max(0.0, target - clock_count)
            if config.clock == "informative":
                # Worlds needed = informative worlds needed / informative rate.
                rate = max(clock_count / state.samples, 1.0 / state.samples)
                remaining /= rate
            remaining_samples = max(float(config.batch_size), remaining)
            base = 1.0 / (remaining_samples * costs[query])
        return base

    base_priorities = {
        query: base_priority(query)
        for query in query_ids
        if not states[query].stable
    }

    def priority(query: Hashable) -> float:
        return base_priorities[query] * (1.0 + config.aging_weight * ages[query])

    while True:
        available = [query for query in query_ids if eligible(query)]
        if not available:
            break
        available_set = set(available)
        if previous in available_set and consecutive >= config.max_consecutive_batches:
            alternatives = [query for query in available if query != previous]
            if alternatives:
                available = alternatives
                available_set = set(available)

        selected_priority: float | None = None
        if config.strategy == "uniform":
            selected = next(
                query_ids[(round_robin_cursor + step) % len(query_ids)]
                for step in range(len(query_ids))
                if query_ids[(round_robin_cursor + step) % len(query_ids)] in available_set
            )
            round_robin_cursor = (positions[selected] + 1) % len(query_ids)
        else:
            selected_priority, _, selected = max(
                (
                    (priority(query), -positions[query], query)
                    for query in available
                ),
                key=lambda item: (item[0], item[1]),
            )

        remaining_affordable = int(
            math.floor((config.global_budget - spent + tolerance) / costs[selected])
        )
        stream_remaining = len(winner_streams[selected]) - offsets[selected]
        cap_remaining = stream_remaining
        if config.maximum_samples_per_query is not None:
            cap_remaining = min(
                cap_remaining,
                config.maximum_samples_per_query - states[selected].samples,
            )
        batch = min(config.batch_size, remaining_affordable, cap_remaining)
        if batch <= 0:
            break
        start = offsets[selected]
        stop = start + batch
        states[selected].update(winner_streams[selected][start:stop])
        offsets[selected] = stop
        if not states[selected].stable:
            base_priorities[selected] = base_priority(selected)
        cost = batch * costs[selected]
        spent += cost
        for query in available:
            ages[query] = ages[query] + 1 if query != selected else 0
        if selected == previous:
            consecutive += 1
        else:
            previous = selected
            consecutive = 1
        if config.record_allocation_trace:
            trace.append(
                {
                    "phase": "adaptive",
                    "query_id": str(selected),
                    "samples": batch,
                    "cost": cost,
                    "priority": selected_priority,
                    "cumulative_cost": spent,
                    "stable_after_batch": states[selected].stable,
                }
            )

    results = tuple(states[query].result(exhausted=True) for query in query_ids)
    return CertifiedSchedulingResult(
        strategy=config.strategy,
        queries=results,
        total_worlds=sum(result.samples_used for result in results),
        total_cost=spent,
        global_budget=config.global_budget,
        allocation_trace=tuple(trace),
    )
