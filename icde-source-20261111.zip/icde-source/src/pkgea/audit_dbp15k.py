"""Independent structural audit for the JAPE DBP15K release."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def _rows(path: Path, width: int) -> list[tuple[str, ...]]:
    rows = []
    with path.open("r", encoding="utf-8-sig") as handle:
        for line_number, line in enumerate(handle, start=1):
            fields = tuple(line.rstrip("\r\n").split("\t"))
            if len(fields) != width:
                raise ValueError(
                    f"{path}:{line_number} has {len(fields)} columns; "
                    f"expected {width}"
                )
            rows.append(fields)
    return rows


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _audit_pair(pair_dir: Path, split_name: str) -> dict[str, object]:
    uri_left = _rows(pair_dir / "s_triples", 3)
    uri_right = _rows(pair_dir / "t_triples", 3)
    alignments = _rows(pair_dir / "ent_ILLs", 2)
    split = pair_dir / split_name
    left_ids = dict(_rows(split / "ent_ids_1", 2))
    right_ids = dict(_rows(split / "ent_ids_2", 2))
    left_rel_ids = dict(_rows(split / "rel_ids_1", 2))
    right_rel_ids = dict(_rows(split / "rel_ids_2", 2))
    selected_left = _rows(split / "triples_1", 3)
    selected_right = _rows(split / "triples_2", 3)
    support = set(_rows(split / "sup_ent_ids", 2))
    reference = set(_rows(split / "ref_ent_ids", 2))

    left_selected_entities = {
        value for row in selected_left for value in (row[0], row[2])
    }
    right_selected_entities = {
        value for row in selected_right for value in (row[0], row[2])
    }
    left_selected_relations = {row[1] for row in selected_left}
    right_selected_relations = {row[1] for row in selected_right}
    errors = []
    if support & reference:
        errors.append("support/reference encoded pairs overlap")
    if len(support) + len(reference) != len(alignments):
        errors.append("support/reference counts do not cover ent_ILLs")
    if not left_selected_entities <= set(left_ids):
        errors.append("triples_1 references an unknown selected entity id")
    if not right_selected_entities <= set(right_ids):
        errors.append("triples_2 references an unknown selected entity id")
    if not left_selected_relations <= set(left_rel_ids):
        errors.append("triples_1 references an unknown relation id")
    if not right_selected_relations <= set(right_rel_ids):
        errors.append("triples_2 references an unknown relation id")

    def graph_stats(rows: list[tuple[str, ...]]) -> dict[str, int]:
        return {
            "triples": len(rows),
            "entities": len(
                {value for row in rows for value in (row[0], row[2])}
            ),
            "relations": len({row[1] for row in rows}),
        }

    return {
        "pair": pair_dir.name,
        "popular_entity_uri_release": {
            "left": graph_stats(uri_left),
            "right": graph_stats(uri_right),
            "alignment_pairs": len(alignments),
        },
        "selected": {
            "split": split_name,
            "left": {
                "entities": len(left_ids),
                "relations": len(left_rel_ids),
                "triples": len(selected_left),
            },
            "right": {
                "entities": len(right_ids),
                "relations": len(right_rel_ids),
                "triples": len(selected_right),
            },
            "shared_entity_ids": len(set(left_ids) & set(right_ids)),
            "support_pairs": len(support),
            "reference_pairs": len(reference),
            "support_reference_overlap": len(support & reference),
        },
        "encoded_vs_uri_consistency": {
            "left_triple_count_ratio": len(selected_left) / len(uri_left),
            "right_triple_count_ratio": len(selected_right) / len(uri_right),
        },
        "ok": not errors,
        "errors": errors,
    }


def audit_dbp15k(
    dataset_dir: str | Path,
    *,
    split_name: str = "0_3",
    archive_path: str | Path | None = None,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Audit all three DBP15K language pairs without trusting paper counts."""

    root = Path(dataset_dir).resolve()
    pairs = [
        _audit_pair(root / pair, split_name)
        for pair in ("zh_en", "ja_en", "fr_en")
    ]
    archive = Path(archive_path).resolve() if archive_path else None
    result = {
        "dataset_dir": str(root),
        "release": "JAPE popular-entity subset; full DBP15K is not bundled",
        "pair_count": len(pairs),
        "pairs": pairs,
        "all_pairs_valid": all(pair["ok"] for pair in pairs),
        "archive": (
            {
                "path": str(archive),
                "bytes": archive.stat().st_size,
                "sha256": _sha256(archive),
            }
            if archive
            else None
        ),
        "interpretation": (
            "s_triples/t_triples are already the popularity-filtered JAPE "
            "release; split triples are its ID encoding. Statistics reported "
            "for the larger full DBP15K source must not be assigned to this "
            "experimental subset."
        ),
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result
