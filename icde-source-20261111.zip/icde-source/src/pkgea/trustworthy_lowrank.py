"""Conformal evaluation for revisioned learned low-rank query artifacts."""

from __future__ import annotations

import csv
import json
import random
import statistics
from pathlib import Path

import numpy as np

from pkgea.contracts import dataset_revision_digest
from pkgea.query import LearnedLowRankCovarianceIndex
from pkgea.trustworthy import (
    conformal_candidate_set,
    margin_conformal_candidate_set,
    maximum_weight_injective_assignment,
    prune_to_injective_assignment_support,
)


def _coverage_summary(
    calibration_indices: list[int],
    test_indices: list[int],
    score_rows: list[list[float]],
    true_indices: list[int],
    targets: tuple[str, ...],
    *,
    alpha: float,
    method: str,
) -> dict[str, float | int | str]:
    calibration_rows = [score_rows[index] for index in calibration_indices]
    calibration_true = [true_indices[index] for index in calibration_indices]
    calibration_true_scores = [
        score_rows[index][true_indices[index]]
        for index in calibration_indices
    ]
    covered = 0
    sizes = []
    for index in test_indices:
        candidate_scores = dict(zip(targets, score_rows[index], strict=True))
        if method == "fixed_score":
            candidate_set = conformal_candidate_set(
                calibration_true_scores,
                candidate_scores,
                alpha=alpha,
            ).candidates
        elif method == "margin":
            candidate_set = margin_conformal_candidate_set(
                calibration_rows,
                calibration_true,
                candidate_scores,
                alpha=alpha,
            ).candidates
        else:
            raise ValueError(f"Unsupported conformal method: {method}")
        covered += targets[true_indices[index]] in candidate_set
        sizes.append(len(candidate_set))
    return {
        "method": method,
        "calibration_queries": len(calibration_indices),
        "test_queries": len(test_indices),
        "target_coverage": 1.0 - alpha,
        "empirical_coverage": covered / len(test_indices),
        "average_set_size": statistics.mean(sizes),
        "maximum_set_size": max(sizes),
        "empty_set_rate": sum(size == 0 for size in sizes) / len(sizes),
    }


def _uncertainty_mondrian_margin(
    calibration_indices: list[int],
    test_indices: list[int],
    score_rows: list[list[float]],
    true_indices: list[int],
    targets: tuple[str, ...],
    radii: list[float],
    *,
    alpha: float,
) -> dict[str, object]:
    ordered = sorted(radii[index] for index in calibration_indices)
    thresholds = (
        ordered[len(ordered) // 3],
        ordered[2 * len(ordered) // 3],
    )

    def group(index: int) -> int:
        if radii[index] <= thresholds[0]:
            return 0
        if radii[index] <= thresholds[1]:
            return 1
        return 2

    calibration_groups = {
        group_index: [
            index
            for index in calibration_indices
            if group(index) == group_index
        ]
        for group_index in range(3)
    }
    covered = 0
    sizes = []
    per_group = {}
    for group_index in range(3):
        calibration = calibration_groups[group_index]
        tests = [
            index for index in test_indices if group(index) == group_index
        ]
        if not calibration or not tests:
            continue
        summary = _coverage_summary(
            calibration,
            tests,
            score_rows,
            true_indices,
            targets,
            alpha=alpha,
            method="margin",
        )
        per_group[str(group_index)] = summary
        covered += round(
            float(summary["empirical_coverage"]) * len(tests)
        )
        sizes.extend(
            [float(summary["average_set_size"])] * len(tests)
        )
    group_sizes = [len(value) for value in calibration_groups.values()]
    return {
        "method": "source-uncertainty-tertile Mondrian margin",
        "thresholds": thresholds,
        "calibration_group_sizes": {
            str(key): len(value)
            for key, value in calibration_groups.items()
        },
        "target_coverage": 1.0 - alpha,
        "empirical_coverage": covered / len(test_indices),
        "average_set_size": statistics.mean(sizes),
        "per_group": per_group,
        "guarantee_boundary": (
            "Mondrian marginal coverage requires exchangeability within each "
            "predefined uncertainty group; observed calibration group sizes "
            f"range from {min(group_sizes)} to {max(group_sizes)}."
        ),
    }


def run_lowrank_conformal_validation(
    dataset_dir: str | Path,
    artifact_path: str | Path,
    *,
    alpha: float = 0.1,
    seed: int = 17,
    repeat_count: int = 25,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Calibrate only on model-unseen sources and evaluate disjoint tests."""

    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    if repeat_count <= 0:
        raise ValueError("repeat_count must be positive")
    dataset = Path(dataset_dir).resolve()
    index = LearnedLowRankCovarianceIndex.from_artifact(artifact_path)
    metadata = json.loads(
        (dataset / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    if index.metadata.get("dataset_id") != metadata.get("dataset_id"):
        raise ValueError("Learned covariance artifact dataset_id mismatch")
    if index.metadata.get("dataset_revision") != dataset_revision_digest(dataset):
        raise ValueError("Learned covariance artifact is stale")
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    alignment_by_source = {
        row["source_entity_id"]: row for row in alignments
    }
    targets = index.target_entities
    target_index = {
        target: position for position, target in enumerate(targets)
    }
    sources = list(index.source_entities)
    if any(
        alignment_by_source[source]["split"] not in {"validation", "test"}
        for source in sources
    ):
        raise ValueError(
            "Conformal artifact sources must exclude model-training anchors"
        )
    score_rows = []
    true_indices = []
    radii = []
    for source in sources:
        result = index.query(source, k=len(targets))
        scores = {
            str(candidate.candidate): candidate.similarity
            for candidate in result.top_k
        }
        score_rows.append([scores[target] for target in targets])
        true_indices.append(
            target_index[alignment_by_source[source]["target_entity_id"]]
        )
        source_position = index.entity_index[source]
        radii.append(
            float(np.sqrt(np.trace(index.covariances[source_position])))
        )
    calibration_indices = [
        position
        for position, source in enumerate(sources)
        if alignment_by_source[source]["split"] == "validation"
    ]
    test_indices = [
        position
        for position, source in enumerate(sources)
        if alignment_by_source[source]["split"] == "test"
    ]
    if not calibration_indices or not test_indices:
        raise ValueError("Both validation and test sources are required")
    fixed = _coverage_summary(
        calibration_indices,
        test_indices,
        score_rows,
        true_indices,
        targets,
        alpha=alpha,
        method="fixed_score",
    )
    margin = _coverage_summary(
        calibration_indices,
        test_indices,
        score_rows,
        true_indices,
        targets,
        alpha=alpha,
        method="margin",
    )
    mondrian = _uncertainty_mondrian_margin(
        calibration_indices,
        test_indices,
        score_rows,
        true_indices,
        targets,
        radii,
        alpha=alpha,
    )
    test_rows = [score_rows[index] for index in test_indices]
    independent_winners = [
        max(range(len(row)), key=lambda column: (row[column], -column))
        for row in test_rows
    ]
    independent_accuracy = sum(
        independent_winners[position] == true_indices[index]
        for position, index in enumerate(test_indices)
    ) / len(test_indices)
    assignment = maximum_weight_injective_assignment(test_rows)
    assignment_accuracy = sum(
        assignment[position] == true_indices[index]
        for position, index in enumerate(test_indices)
    ) / len(test_indices)
    calibration_rows = [
        score_rows[index] for index in calibration_indices
    ]
    calibration_true = [
        true_indices[index] for index in calibration_indices
    ]
    margin_sets = []
    for index in test_indices:
        selected = margin_conformal_candidate_set(
            calibration_rows,
            calibration_true,
            dict(zip(targets, score_rows[index], strict=True)),
            alpha=alpha,
        ).candidates
        margin_sets.append(
            [target_index[target] for target in selected]
        )
    assignment_support = prune_to_injective_assignment_support(
        margin_sets,
        len(targets),
    )
    support_coverage = sum(
        true_indices[index]
        in assignment_support.candidate_sets[position]
        for position, index in enumerate(test_indices)
    ) / len(test_indices)

    repeat_fixed = []
    repeat_margin = []
    pool = list(range(len(sources)))
    for repeat in range(repeat_count):
        order = pool.copy()
        random.Random(seed + 1009 * repeat).shuffle(order)
        calibration = order[: len(calibration_indices)]
        test = order[len(calibration_indices) :]
        repeat_fixed.append(
            _coverage_summary(
                calibration,
                test,
                score_rows,
                true_indices,
                targets,
                alpha=alpha,
                method="fixed_score",
            )
        )
        repeat_margin.append(
            _coverage_summary(
                calibration,
                test,
                score_rows,
                true_indices,
                targets,
                alpha=alpha,
                method="margin",
            )
        )

    def aggregate(reports: list[dict[str, float | int | str]]) -> dict[str, float]:
        coverages = [float(report["empirical_coverage"]) for report in reports]
        sizes = [float(report["average_set_size"]) for report in reports]
        return {
            "coverage_mean": statistics.mean(coverages),
            "coverage_min": min(coverages),
            "coverage_max": max(coverages),
            "average_set_size_mean": statistics.mean(sizes),
        }

    result = {
        "dataset_dir": str(dataset),
        "artifact_path": str(Path(artifact_path).resolve()),
        "alpha": alpha,
        "model_training_queries_excluded": True,
        "calibration_split": "validation",
        "test_split": "test",
        "fixed_split": {
            "fixed_score": fixed,
            "margin": margin,
            "uncertainty_mondrian_margin": mondrian,
            "independent_point_accuracy": independent_accuracy,
            "hungarian_point_accuracy": assignment_accuracy,
            "assignment_support_pruning": {
                "full_matching_feasible": assignment_support.feasible,
                "removed_candidate_edges": (
                    assignment_support.removed_edges
                ),
                "average_set_size_before": statistics.mean(
                    len(row) for row in margin_sets
                ),
                "average_set_size_after": statistics.mean(
                    len(row)
                    for row in assignment_support.candidate_sets
                ),
                "coverage_before": margin["empirical_coverage"],
                "coverage_after": support_coverage,
                "guarantee_boundary": (
                    "Support pruning preserves the joint event only when all "
                    "row-wise true labels are simultaneously present and "
                    "truth is injective. Marginal split-conformal coverage "
                    "alone does not guarantee that joint event."
                ),
            },
        },
        "repeated_unseen_source_splits": {
            "repeat_count": repeat_count,
            "calibration_queries": len(calibration_indices),
            "test_queries": len(test_indices),
            "fixed_score": aggregate(repeat_fixed),
            "margin": aggregate(repeat_margin),
        },
        "claim_boundary": (
            "Split-conformal marginal coverage relies on exchangeability of "
            "model-unseen validation/test sources. Repeated splits are a "
            "sensitivity audit, not simultaneous conditional coverage."
        ),
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result
