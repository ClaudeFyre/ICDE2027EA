"""End-to-end durable streaming worker for moment and refresh decisions."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Hashable, Sequence

from pkgea.persistent_stream import SQLiteSnapshotStore
from pkgea.streaming import (
    IncrementalMomentIndex,
    LocalEmbeddingRefreshPolicy,
    PropagationDependencyIndex,
    RevisionConflictError,
)


@dataclass(frozen=True)
class StreamWorkerResult:
    event_id: str
    version: int
    duplicate: bool
    refresh_action: str
    affected_edges: int
    affected_entities: int

    def as_dict(self) -> dict[str, object]:
        return {
            "event_id": self.event_id,
            "version": self.version,
            "duplicate": self.duplicate,
            "refresh_action": self.refresh_action,
            "affected_edges": self.affected_edges,
            "affected_entities": self.affected_entities,
        }


class DurableStreamingWorker:
    """Apply one probability event, choose local/full refresh, and CAS commit."""

    def __init__(
        self,
        database: str | Path,
        stream_id: str,
        edge_endpoints: Sequence[tuple[Hashable, Hashable]],
        refresh_policy: LocalEmbeddingRefreshPolicy,
        *,
        propagation_depth: int,
        normalization_hops: int = 0,
        timeout: float = 5.0,
    ) -> None:
        if not stream_id:
            raise ValueError("stream_id cannot be empty")
        if len(edge_endpoints) > refresh_policy.total_entities * 100:
            raise ValueError("edge scope is inconsistent with refresh policy")
        self.database = Path(database).resolve()
        self.stream_id = stream_id
        self.dependencies = PropagationDependencyIndex(edge_endpoints)
        self.refresh_policy = refresh_policy
        self.propagation_depth = propagation_depth
        self.normalization_hops = normalization_hops
        self.timeout = timeout

    def initialize(self, index: IncrementalMomentIndex) -> bool:
        if len(index.messages) != len(self.dependencies.edge_endpoints):
            raise ValueError("moment and topology edge scopes do not match")
        with SQLiteSnapshotStore(self.database, timeout=self.timeout) as store:
            return store.initialize(self.stream_id, index.snapshot())

    def apply_probability_update(
        self,
        edge_index: int,
        probability: float,
        event_id: str,
        *,
        expected_version: int | None = None,
        _before_commit_hook: Callable[[], None] | None = None,
    ) -> StreamWorkerResult:
        if not event_id:
            raise ValueError("event_id cannot be empty")
        with SQLiteSnapshotStore(self.database, timeout=self.timeout) as store:
            committed = store.event_version(self.stream_id, event_id)
            if committed is not None:
                return StreamWorkerResult(
                    event_id=event_id,
                    version=committed,
                    duplicate=True,
                    refresh_action="already_committed",
                    affected_edges=0,
                    affected_entities=0,
                )
            head = store.read(self.stream_id)
            if expected_version is not None and head.version != expected_version:
                raise RevisionConflictError(
                    f"worker revision conflict: expected {expected_version}, "
                    f"observed {head.version}"
                )
            index = IncrementalMomentIndex(
                head.state.messages,
                head.state.probabilities,
                dependency_groups=head.state.dependency_groups,
                common_shock_probability=(
                    head.state.common_shock_probability
                ),
            )
            update = index.update(edge_index, probability)
            affected = self.dependencies.affected_entities(
                update.affected_edges,
                self.propagation_depth,
                normalization_hops=self.normalization_hops,
            )
            action = self.refresh_policy.choose(len(affected))
            version = store.compare_and_swap(
                self.stream_id,
                expected_version=head.version,
                snapshot=index.snapshot(),
                event_id=event_id,
                _before_commit_hook=_before_commit_hook,
            )
        return StreamWorkerResult(
            event_id=event_id,
            version=version,
            duplicate=False,
            refresh_action=action,
            affected_edges=len(update.affected_edges),
            affected_entities=len(affected),
        )
