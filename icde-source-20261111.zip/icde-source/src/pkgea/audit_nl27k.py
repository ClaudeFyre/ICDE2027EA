"""Cross-repository audit for the published NL27K relation-count mismatch."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _relations(path: Path) -> list[str]:
    relations: list[str] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, delimiter="\t")
        for line_number, row in enumerate(reader, start=1):
            if len(row) < 3:
                raise ValueError(
                    f"{path}:{line_number} expected at least 3 columns"
                )
            relations.append(row[1])
    return relations


def _split_report(root: Path) -> tuple[dict[str, object], Counter[str]]:
    relation_counts: Counter[str] = Counter()
    splits: dict[str, object] = {}
    for filename in ("train.tsv", "val.tsv", "test.tsv"):
        path = root / filename
        if not path.is_file():
            raise ValueError(f"Missing NL27K split: {path}")
        relations = _relations(path)
        relation_counts.update(relations)
        splits[filename.removesuffix(".tsv")] = {
            "rows": len(relations),
            "relations": len(set(relations)),
            "sha256": _sha256(path),
        }
    return splits, relation_counts


def audit_nl27k_replicas(
    ukge_dir: str | Path,
    unkr_dir: str | Path,
    beurre_dir: str | Path,
    *,
    published_relation_count: int = 404,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Compare released NL27K copies and classify the count discrepancy."""

    ukge = Path(ukge_dir).resolve()
    unkr = Path(unkr_dir).resolve()
    beurre = Path(beurre_dir).resolve()
    ukge_splits, ukge_counts = _split_report(ukge)
    unkr_splits, unkr_counts = _split_report(unkr)
    train_relations = set(_relations(ukge / "train.tsv"))
    union_relations = set(ukge_counts)
    heldout_only = sorted(union_relations - train_relations)

    relation_vocab = beurre / "relation_id.csv"
    if not relation_vocab.is_file():
        raise ValueError(f"Missing BEUrRE relation vocabulary: {relation_vocab}")
    with relation_vocab.open("r", encoding="utf-8-sig", newline="") as handle:
        beurre_relation_count = sum(1 for _ in csv.DictReader(handle))

    byte_identical = {
        split: ukge_splits[split]["sha256"] == unkr_splits[split]["sha256"]
        for split in ("train", "val", "test")
    }
    evidence_consistent = (
        len(union_relations) == 417
        and len(unkr_counts) == 417
        and beurre_relation_count == 417
        and all(byte_identical.values())
    )
    result = {
        "published_relation_count": published_relation_count,
        "classification": (
            "released-data-versus-publication-metadata-mismatch"
            if evidence_consistent
            else "unresolved-replica-disagreement"
        ),
        "ukge": {
            "splits": ukge_splits,
            "union_relations": len(union_relations),
        },
        "unkr": {
            "splits": unkr_splits,
            "union_relations": len(unkr_counts),
            "byte_identical_to_ukge": byte_identical,
        },
        "beurre": {
            "relation_vocabulary_rows": beurre_relation_count,
            "relation_vocabulary_sha256": _sha256(relation_vocab),
        },
        "heldout_only_relations": [
            {
                "relation": relation,
                "released_fact_count": ukge_counts[relation],
            }
            for relation in heldout_only
        ],
        "heldout_only_relation_count": len(heldout_only),
        "all_heldout_only_are_singletons": all(
            ukge_counts[relation] == 1 for relation in heldout_only
        ),
        "conclusion": (
            "The released files require 417 relation identifiers. The 404 figure "
            "cannot be reproduced from train, validation, test, or the BEUrRE "
            "vocabulary. The exact upstream extraction cause remains unavailable."
        ),
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", encoding="utf-8") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    return result
