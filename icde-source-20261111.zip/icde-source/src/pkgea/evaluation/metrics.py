"""Estimator and ranking-stability metrics without third-party dependencies."""

from __future__ import annotations

import math
from collections.abc import Hashable, Mapping


def mae(reference: Mapping[Hashable, float], estimate: Mapping[Hashable, float]) -> float:
    keys = set(reference) | set(estimate)
    if not keys:
        raise ValueError("Cannot compute MAE on empty mappings")
    return sum(abs(reference.get(key, 0.0) - estimate.get(key, 0.0)) for key in keys) / len(keys)


def rmse(reference: Mapping[Hashable, float], estimate: Mapping[Hashable, float]) -> float:
    keys = set(reference) | set(estimate)
    if not keys:
        raise ValueError("Cannot compute RMSE on empty mappings")
    return math.sqrt(
        sum((reference.get(key, 0.0) - estimate.get(key, 0.0)) ** 2 for key in keys)
        / len(keys)
    )


def top_k(
    scores: Mapping[Hashable, float], k: int
) -> tuple[Hashable, ...]:
    if k <= 0:
        raise ValueError("k must be positive")
    return tuple(
        key
        for key, _ in sorted(scores.items(), key=lambda item: (-item[1], str(item[0])))[:k]
    )


def top_k_overlap(
    reference: Mapping[Hashable, float], estimate: Mapping[Hashable, float], k: int
) -> float:
    left = set(top_k(reference, k))
    right = set(top_k(estimate, k))
    return len(left & right) / max(len(left | right), 1)


def winner_preserved(
    reference: Mapping[Hashable, float], estimate: Mapping[Hashable, float]
) -> bool:
    return top_k(reference, 1) == top_k(estimate, 1)

