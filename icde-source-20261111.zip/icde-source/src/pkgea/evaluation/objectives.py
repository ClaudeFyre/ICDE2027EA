"""World-level EA objectives: expectation, wins, thresholds, and tail rank risk."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Callable, Hashable, Mapping, Sequence

from pkgea.samplers import WorldSample, normalize_weights


Candidate = tuple[Hashable, Hashable]
ScoreFunction = Callable[[tuple[bool, ...]], Mapping[Candidate, float]]


@dataclass(frozen=True)
class ObjectiveEstimate:
    expected_score: dict[Candidate, float]
    winner_probability: dict[Candidate, float]
    threshold_probability: dict[Candidate, float]
    rank_cvar: dict[Candidate, float]
    world_count: int
    sampled_edge_evaluations: int


def _weighted_cvar(values: list[tuple[float, float]], tail_mass: float) -> float:
    if not 0.0 < tail_mass <= 1.0:
        raise ValueError("tail_mass must be in (0, 1]")
    remaining = tail_mass
    total = 0.0
    for value, weight in sorted(values, reverse=True):
        take = min(weight, remaining)
        total += value * take
        remaining -= take
        if remaining <= 1e-15:
            break
    return total / tail_mass


def estimate_objectives(
    worlds: Sequence[WorldSample],
    score_function: ScoreFunction,
    *,
    threshold: float = 0.5,
    cvar_tail_mass: float = 0.1,
) -> ObjectiveEstimate:
    normalized = normalize_weights(worlds)
    expected: defaultdict[Candidate, float] = defaultdict(float)
    wins: defaultdict[Candidate, float] = defaultdict(float)
    thresholds: defaultdict[Candidate, float] = defaultdict(float)
    rank_samples: defaultdict[Candidate, list[tuple[float, float]]] = defaultdict(list)

    for world in normalized:
        scores = dict(score_function(world.state))
        by_source: defaultdict[Hashable, list[tuple[Candidate, float]]] = defaultdict(list)
        for candidate, score in scores.items():
            expected[candidate] += world.weight * score
            thresholds[candidate] += world.weight * float(score >= threshold)
            by_source[candidate[0]].append((candidate, score))

        for candidates in by_source.values():
            ordered = sorted(candidates, key=lambda item: (-item[1], str(item[0][1])))
            if ordered:
                wins[ordered[0][0]] += world.weight
            for rank, (candidate, _) in enumerate(ordered, start=1):
                rank_samples[candidate].append((float(rank), world.weight))

    rank_cvar = {
        candidate: _weighted_cvar(samples, cvar_tail_mass)
        for candidate, samples in rank_samples.items()
    }
    return ObjectiveEstimate(
        expected_score=dict(expected),
        winner_probability=dict(wins),
        threshold_probability=dict(thresholds),
        rank_cvar=rank_cvar,
        world_count=len(normalized),
        sampled_edge_evaluations=sum(
            world.sampled_edge_count for world in normalized
        ),
    )

