"""Statistical summary for generated benchmark instances."""

from __future__ import annotations

import csv
import math
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

from pkgea.contracts import validate_dataset


@dataclass(frozen=True)
class BenchmarkReport:
    dataset_dir: str
    fact_count: int
    mean_true_probability: float
    mean_observed_confidence: float
    mean_binary_entropy: float
    confidence_distortion_mae: float
    dependency_group_count: int
    multi_edge_dependency_group_count: int
    grouped_edge_count: int

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


def _binary_entropy(probability: float) -> float:
    if probability in {0.0, 1.0}:
        return 0.0
    return -probability * math.log2(probability) - (
        1.0 - probability
    ) * math.log2(1.0 - probability)


def summarize_benchmark(dataset_dir: str | Path) -> BenchmarkReport:
    root = Path(dataset_dir).resolve()
    validate_dataset(root)
    truth_path = root / "latent_truth.tsv"
    if not truth_path.is_file():
        raise ValueError(f"Generated benchmark is missing latent_truth.tsv: {root}")

    count = 0
    true_sum = 0.0
    observed_sum = 0.0
    entropy_sum = 0.0
    distortion_sum = 0.0
    groups: Counter[str] = Counter()
    with truth_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        for row in reader:
            truth = float(row["true_probability"])
            observed = float(row["observed_confidence"])
            count += 1
            true_sum += truth
            observed_sum += observed
            entropy_sum += _binary_entropy(truth)
            distortion_sum += abs(truth - observed)
            if row["dependency_group"]:
                groups[row["dependency_group"]] += 1
    if not count:
        raise ValueError("Generated benchmark contains no facts")
    return BenchmarkReport(
        dataset_dir=str(root),
        fact_count=count,
        mean_true_probability=true_sum / count,
        mean_observed_confidence=observed_sum / count,
        mean_binary_entropy=entropy_sum / count,
        confidence_distortion_mae=distortion_sum / count,
        dependency_group_count=len(groups),
        multi_edge_dependency_group_count=sum(value > 1 for value in groups.values()),
        grouped_edge_count=sum(groups.values()),
    )

