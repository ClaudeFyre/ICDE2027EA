"""Versioned benchmark design presets for controlled PKG-EA sweeps."""

from __future__ import annotations

import itertools
import json
import math
from pathlib import Path


PRESET_VERSION = "1.0.0"

ENTROPY_PRESETS = (
    ("h1_very_low", 0.15, 0.15),
    ("h2_low", 0.40, 0.40),
    ("h3_medium", 1.00, 1.00),
    ("h4_high", 3.00, 3.00),
    ("h5_very_high", 12.00, 12.00),
)
MISSINGNESS_PRESETS = (
    ("m1_none", 0.00),
    ("m2_moderate", 0.15),
    ("m3_severe", 0.35),
)
CORRELATION_PRESETS = (
    ("c1_weak", 0.25),
    ("c2_medium", 0.55),
    ("c3_strong", 0.85),
)
SEED_RATIO_PRESETS = (
    ("s1_low", 0.05),
    ("s2_medium", 0.20),
    ("s3_high", 0.50),
)


def _digamma(value: float) -> float:
    """Dependency-free positive-domain digamma approximation."""

    result = 0.0
    while value < 8.0:
        result -= 1.0 / value
        value += 1.0
    inverse = 1.0 / value
    inverse_squared = inverse * inverse
    result += (
        math.log(value)
        - 0.5 * inverse
        - inverse_squared
        * (
            1.0 / 12.0
            - inverse_squared
            * (1.0 / 120.0 - inverse_squared * (1.0 / 252.0))
        )
    )
    return result


def expected_normalized_binary_entropy(alpha: float, beta: float) -> float:
    """Return E[H_2(P)] for P ~ Beta(alpha, beta)."""

    if alpha <= 0.0 or beta <= 0.0:
        raise ValueError("Beta parameters must be positive")
    total = alpha + beta
    entropy_nats = (
        _digamma(total + 1.0)
        - (alpha / total) * _digamma(alpha + 1.0)
        - (beta / total) * _digamma(beta + 1.0)
    )
    return entropy_nats / math.log(2.0)


def build_benchmark_preset_manifest() -> dict[str, object]:
    """Build the frozen v1 full-factorial benchmark design.

    The 135 profiles span uncertainty entropy, structural missingness,
    shared-latent correlation strength, and alignment seed ratio. Mechanism
    choice remains an explicit experimental axis so independent settings do
    not misleadingly claim that ``shared_strength`` induces dependence.
    """

    entropy = [
        {
            "id": name,
            "beta_alpha": alpha,
            "beta_beta": beta,
            "expected_normalized_binary_entropy": (
                expected_normalized_binary_entropy(alpha, beta)
            ),
        }
        for name, alpha, beta in ENTROPY_PRESETS
    ]
    missingness = [
        {"id": name, "missingness_rate": rate}
        for name, rate in MISSINGNESS_PRESETS
    ]
    correlation = [
        {"id": name, "shared_strength": strength}
        for name, strength in CORRELATION_PRESETS
    ]
    seed_ratios = [
        {
            "id": name,
            "train_seed_ratio": ratio,
            "validation_ratio": 0.10,
            "test_ratio": 0.90 - ratio,
        }
        for name, ratio in SEED_RATIO_PRESETS
    ]

    profiles = []
    for entropy_item, missing_item, correlation_item, seed_item in itertools.product(
        entropy, missingness, correlation, seed_ratios
    ):
        profile_id = "-".join(
            (
                entropy_item["id"],
                missing_item["id"],
                correlation_item["id"],
                seed_item["id"],
            )
        )
        profiles.append(
            {
                "id": profile_id,
                "beta_alpha": entropy_item["beta_alpha"],
                "beta_beta": entropy_item["beta_beta"],
                "missingness_rate": missing_item["missingness_rate"],
                "shared_strength": correlation_item["shared_strength"],
                "seed_ratio": seed_item["train_seed_ratio"],
                "validation_ratio": seed_item["validation_ratio"],
            }
        )

    return {
        "preset_version": PRESET_VERSION,
        "design": "full_factorial",
        "profile_count": len(profiles),
        "mechanisms": [
            "independent",
            "structural_correlated",
            "cross_kg_correlated",
            "calibration_distortion",
        ],
        "dimensions": {
            "entropy": entropy,
            "missingness": missingness,
            "correlation": correlation,
            "seed_ratio": seed_ratios,
        },
        "profiles": profiles,
        "interpretation": {
            "entropy": (
                "Expected normalized Bernoulli entropy under the configured Beta prior."
            ),
            "missingness": "Fraction of relation triples removed before model exposure.",
            "correlation": (
                "Mixture weight of the shared group latent; applicable only to "
                "structural/cross-KG correlated mechanisms."
            ),
            "seed_ratio": (
                "Fraction of alignment pairs assigned to train; validation is fixed "
                "at 0.10 and the remainder is test."
            ),
        },
    }


def write_benchmark_preset_manifest(output_path: str | Path) -> Path:
    """Write the frozen preset matrix without overwriting existing artifacts."""

    output = Path(output_path).resolve()
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as handle:
        json.dump(
            build_benchmark_preset_manifest(),
            handle,
            ensure_ascii=False,
            indent=2,
        )
        handle.write("\n")
    return output
