"""Reproducible probability injection for canonical deterministic EA datasets."""

from __future__ import annotations

import csv
import json
import math
import random
import shutil
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

from pkgea.contracts import provenance_path, validate_dataset


MECHANISMS = {
    "independent",
    "structural_correlated",
    "cross_kg_correlated",
    "calibration_distortion",
}


@dataclass(frozen=True)
class BenchmarkGeneratorConfig:
    mechanism: str
    seed: int = 17
    beta_alpha: float = 2.0
    beta_beta: float = 2.0
    shared_strength: float = 0.7
    missingness_rate: float = 0.0
    distortion: str = "overconfidence"
    temperature: float = 0.5
    seed_ratio: float | None = None
    validation_ratio: float = 0.1

    def validate(self) -> None:
        if self.mechanism not in MECHANISMS:
            raise ValueError(f"Unsupported mechanism: {self.mechanism}")
        if self.beta_alpha <= 0 or self.beta_beta <= 0:
            raise ValueError("Beta parameters must be positive")
        if not 0.0 <= self.shared_strength <= 1.0:
            raise ValueError("shared_strength must be in [0, 1]")
        if not 0.0 <= self.missingness_rate < 1.0:
            raise ValueError("missingness_rate must be in [0, 1)")
        if self.temperature <= 0:
            raise ValueError("temperature must be positive")
        if self.distortion not in {"overconfidence", "underconfidence"}:
            raise ValueError(f"Unsupported distortion: {self.distortion}")
        if self.seed_ratio is not None:
            if not 0.0 < self.seed_ratio < 1.0:
                raise ValueError("seed_ratio must be in (0, 1)")
            if not 0.0 <= self.validation_ratio < 1.0:
                raise ValueError("validation_ratio must be in [0, 1)")
            if self.seed_ratio + self.validation_ratio >= 1.0:
                raise ValueError("seed_ratio + validation_ratio must be less than 1")


def _read_tsv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        return list(reader.fieldnames or []), list(reader)


def _write_tsv(path: Path, fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(rows)


def _bounded_probability(value: float) -> float:
    return min(max(value, 1e-6), 1.0 - 1e-6)


def _temperature_distort(probability: float, temperature: float) -> float:
    probability = _bounded_probability(probability)
    logit = math.log(probability / (1.0 - probability))
    return 1.0 / (1.0 + math.exp(-logit / temperature))


def _alignment_map(alignments: list[dict[str, str]]) -> dict[str, str]:
    return {
        row["source_entity_id"]: row["target_entity_id"]
        for row in alignments
        if float(row["confidence"]) == 1.0
    }


def _structural_group(row: dict[str, str]) -> str:
    return f"{row['graph_id']}|relation|{row['relation_id']}"


def _cross_graph_group(
    row: dict[str, str],
    source_to_target: dict[str, str],
    paired_signatures: set[tuple[str, str]],
) -> str | None:
    if row["graph_id"] == "target":
        signature = (row["head_id"], row["tail_id"])
    else:
        mapped_head = source_to_target.get(row["head_id"])
        mapped_tail = source_to_target.get(row["tail_id"])
        if not mapped_head or not mapped_tail:
            return None
        signature = (mapped_head, mapped_tail)
    if signature in paired_signatures:
        return f"aligned-neighborhood|{signature[0]}|{signature[1]}"
    return None


def _resplit_alignments(
    alignments: list[dict[str, str]],
    *,
    seed_ratio: float,
    validation_ratio: float,
    seed: int,
) -> list[dict[str, str]]:
    """Assign exact, reproducible train/validation/test pair counts."""

    total = len(alignments)
    train_count = round(total * seed_ratio)
    validation_count = round(total * validation_ratio)
    if total and train_count == 0:
        train_count = 1
    if train_count + validation_count >= total and total > 1:
        overflow = train_count + validation_count - total + 1
        validation_count = max(0, validation_count - overflow)

    shuffled = list(range(total))
    random.Random(seed ^ 0x5EED5EED).shuffle(shuffled)
    train_indices = set(shuffled[:train_count])
    validation_indices = set(
        shuffled[train_count : train_count + validation_count]
    )
    result = []
    for index, row in enumerate(alignments):
        updated = dict(row)
        if index in train_indices:
            updated["split"] = "train"
        elif index in validation_indices:
            updated["split"] = "validation"
        else:
            updated["split"] = "test"
        result.append(updated)
    return result


def generate_benchmark(
    base_dataset_dir: str | Path,
    output_dir: str | Path,
    config: BenchmarkGeneratorConfig,
) -> Path:
    """Inject uncertainty into a canonical dual-KG dataset.

    The function refuses to overwrite an existing output directory. It writes a
    ``latent_truth.tsv`` sidecar so calibration distortion remains auditable.
    """

    config.validate()
    base = Path(base_dataset_dir).resolve()
    output = Path(output_dir).resolve()
    validate_dataset(base)
    if output.exists():
        raise ValueError(f"Output already exists; refusing to overwrite: {output}")
    output.mkdir(parents=True)

    triple_fields, triples = _read_tsv(base / "triples.tsv")
    _, alignments = _read_tsv(base / "alignments.tsv")
    if config.seed_ratio is not None:
        alignments = _resplit_alignments(
            alignments,
            seed_ratio=config.seed_ratio,
            validation_ratio=config.validation_ratio,
            seed=config.seed,
        )
    source_to_target = _alignment_map(alignments)
    source_signatures = {
        (source_to_target[row["head_id"]], source_to_target[row["tail_id"]])
        for row in triples
        if row["graph_id"] == "source"
        and row["head_id"] in source_to_target
        and row["tail_id"] in source_to_target
    }
    target_signatures = {
        (row["head_id"], row["tail_id"])
        for row in triples
        if row["graph_id"] == "target"
    }
    paired_signatures = source_signatures & target_signatures
    rng = random.Random(config.seed)
    group_latents: dict[str, float] = {}
    output_rows: list[dict[str, str]] = []
    truth_rows: list[dict[str, str]] = []

    for row in triples:
        if rng.random() < config.missingness_rate:
            continue

        group: str | None = None
        if config.mechanism == "structural_correlated":
            group = _structural_group(row)
        elif config.mechanism == "cross_kg_correlated":
            group = _cross_graph_group(
                row, source_to_target, paired_signatures
            )

        local_probability = rng.betavariate(config.beta_alpha, config.beta_beta)
        if group:
            shared_probability = group_latents.setdefault(
                group, rng.betavariate(config.beta_alpha, config.beta_beta)
            )
            true_probability = (
                config.shared_strength * shared_probability
                + (1.0 - config.shared_strength) * local_probability
            )
        else:
            true_probability = local_probability
        true_probability = _bounded_probability(true_probability)

        observed_confidence = true_probability
        confidence_type = "calibrated_probability"
        normalization_method = "identity"
        if config.mechanism == "calibration_distortion":
            effective_temperature = config.temperature
            if config.distortion == "underconfidence" and effective_temperature < 1.0:
                effective_temperature = 1.0 / effective_temperature
            observed_confidence = _temperature_distort(
                true_probability, effective_temperature
            )
            confidence_type = "normalized_heuristic_weight"
            normalization_method = (
                f"temperature_distortion(T={effective_temperature:g},"
                f"type={config.distortion})"
            )

        updated = dict(row)
        updated.update(
            {
                "confidence": f"{observed_confidence:.12g}",
                "confidence_type": confidence_type,
                "confidence_source": f"generator:{config.mechanism}",
                "normalization_method": normalization_method,
                "dependency_group": group or "",
                "evidence_id": (
                    f"generated:{config.seed}:{row['graph_id']}:"
                    f"{row['head_id']}:{row['relation_id']}:{row['tail_id']}"
                ),
            }
        )
        output_rows.append(updated)
        truth_rows.append(
            {
                "graph_id": row["graph_id"],
                "head_id": row["head_id"],
                "relation_id": row["relation_id"],
                "tail_id": row["tail_id"],
                "true_probability": f"{true_probability:.12g}",
                "observed_confidence": f"{observed_confidence:.12g}",
                "dependency_group": group or "",
            }
        )

    for filename in ("entities.tsv", "relations.tsv"):
        shutil.copy2(base / filename, output / filename)
    _write_tsv(
        output / "alignments.tsv",
        ["source_entity_id", "target_entity_id", "split", "confidence"],
        alignments,
    )
    if (base / "attributes.tsv").is_file():
        shutil.copy2(base / "attributes.tsv", output / "attributes.tsv")
    _write_tsv(output / "triples.tsv", triple_fields, output_rows)
    _write_tsv(
        output / "latent_truth.tsv",
        [
            "graph_id",
            "head_id",
            "relation_id",
            "tail_id",
            "true_probability",
            "observed_confidence",
            "dependency_group",
        ],
        truth_rows,
    )

    realized_group_counts = Counter(
        row["dependency_group"]
        for row in truth_rows
        if row["dependency_group"]
    )
    grouped_mechanism = config.mechanism in {
        "structural_correlated",
        "cross_kg_correlated",
    }
    dependence_assumption = (
        "grouped_shared_latent"
        if grouped_mechanism and realized_group_counts
        else (
            "independent_no_realized_groups"
            if grouped_mechanism
            else "independent"
        )
    )
    split_counts = {
        split: sum(row["split"] == split for row in alignments)
        for split in ("train", "validation", "test")
    }
    split_suffix = (
        f"-split{split_counts['train']}-{split_counts['validation']}-"
        f"{split_counts['test']}"
        if config.seed_ratio is not None
        else ""
    )
    metadata = {
        "dataset_id": (
            f"{base.name}-{config.mechanism}-seed{config.seed}{split_suffix}"
        ),
        "version": "0.1.0",
        "base_dataset": provenance_path(base),
        "probability_semantics": (
            "latent_truth.tsv stores Bernoulli edge-existence probabilities; "
            "triples.tsv stores the confidence exposed to the model"
        ),
        "edge_dependence": {
            "assumption": dependence_assumption,
            "group_column": "dependency_group",
            "realized_group_count": len(realized_group_counts),
            "multi_edge_group_count": sum(
                count > 1 for count in realized_group_counts.values()
            ),
            "grouped_edge_count": sum(realized_group_counts.values()),
        },
        "generation": asdict(config),
        "alignment_split_counts": split_counts,
        "source": "synthetic probability injection over canonical EA base graph",
        "license_status": "inherits base dataset; verify before redistribution",
        "known_limitations": [
            "Shared latent groups encode positive dependence but are not a complete causal model.",
            "Synthetic confidence does not establish real-world validity.",
        ],
    }
    with (output / "confidence_metadata.json").open(
        "w", encoding="utf-8", newline="\n"
    ) as handle:
        json.dump(metadata, handle, ensure_ascii=False, indent=2)
        handle.write("\n")

    validate_dataset(output)
    return output
