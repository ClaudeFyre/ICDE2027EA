"""Streaming audit helpers for upstream headerless uncertain-KG quadruples."""

from __future__ import annotations

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class QuadAuditReport:
    dataset_dir: Path
    files: tuple[str, ...]
    checksums: dict[str, str]
    fact_count: int
    entity_count: int
    relation_count: int
    confidence_min: float
    confidence_max: float
    confidence_mean: float

    def as_dict(self) -> dict[str, object]:
        return {
            "dataset_dir": str(self.dataset_dir),
            "files": list(self.files),
            "checksums": self.checksums,
            "fact_count": self.fact_count,
            "entity_count": self.entity_count,
            "relation_count": self.relation_count,
            "confidence_min": self.confidence_min,
            "confidence_max": self.confidence_max,
            "confidence_mean": self.confidence_mean,
        }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def audit_headerless_quads(
    dataset_dir: str | Path,
    filenames: Iterable[str] = ("train.tsv", "val.tsv", "test.tsv"),
) -> QuadAuditReport:
    """Audit ``head relation tail confidence`` files without loading them in memory."""

    root = Path(dataset_dir).resolve()
    selected = tuple(filenames)
    if not root.is_dir():
        raise ValueError(f"Dataset directory does not exist: {root}")
    if not selected:
        raise ValueError("At least one input filename is required")

    entities: set[str] = set()
    relations: set[str] = set()
    fact_count = 0
    confidence_sum = 0.0
    confidence_min = float("inf")
    confidence_max = float("-inf")
    checksums: dict[str, str] = {}

    for filename in selected:
        path = root / filename
        if not path.is_file():
            raise ValueError(f"Input file does not exist: {path}")
        checksums[filename] = _sha256(path)
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle, delimiter="\t")
            for line_number, row in enumerate(reader, start=1):
                if len(row) != 4:
                    raise ValueError(
                        f"{filename}:{line_number} expected 4 columns, got {len(row)}"
                    )
                head, relation, tail, raw_confidence = row
                try:
                    confidence = float(raw_confidence)
                except ValueError as exc:
                    raise ValueError(
                        f"{filename}:{line_number} invalid confidence {raw_confidence!r}"
                    ) from exc
                if not 0.0 <= confidence <= 1.0:
                    raise ValueError(
                        f"{filename}:{line_number} confidence outside [0, 1]: {confidence}"
                    )
                entities.update((head, tail))
                relations.add(relation)
                fact_count += 1
                confidence_sum += confidence
                confidence_min = min(confidence_min, confidence)
                confidence_max = max(confidence_max, confidence)

    if fact_count == 0:
        raise ValueError("No facts found")

    return QuadAuditReport(
        dataset_dir=root,
        files=selected,
        checksums=checksums,
        fact_count=fact_count,
        entity_count=len(entities),
        relation_count=len(relations),
        confidence_min=confidence_min,
        confidence_max=confidence_max,
        confidence_mean=confidence_sum / fact_count,
    )

