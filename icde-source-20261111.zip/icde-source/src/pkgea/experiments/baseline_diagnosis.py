"""Deterministic-baseline and first-order edge-variance diagnostics."""

from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path
from typing import Mapping

from pkgea.backbones import AttributeStructuralBackbone, ToyStructuralBackbone


Scores = Mapping[tuple[str, str], float]


def _winner_and_margin(
    scores: Scores,
    source: str,
    candidates: tuple[str, ...],
) -> tuple[str, float]:
    ordered = sorted(
        ((target, scores[(source, target)]) for target in candidates),
        key=lambda item: (-item[1], item[0]),
    )
    runner_score = ordered[1][1] if len(ordered) > 1 else 0.0
    return ordered[0][0], ordered[0][1] - runner_score


def reference_winners(reference: dict[str, object]) -> tuple[dict[str, str], dict[str, float]]:
    winner_maps = [
        run["points"][-1]["source_winners"]
        for run in reference["runs"]
    ]
    sources = sorted(winner_maps[0])
    winners: dict[str, str] = {}
    consensus: dict[str, float] = {}
    for source in sources:
        counts = Counter(mapping[source] for mapping in winner_maps)
        winner, count = sorted(
            counts.items(), key=lambda item: (-item[1], item[0])
        )[0]
        winners[source] = winner
        consensus[source] = count / len(winner_maps)
    return winners, consensus


def _baseline_summary(
    scores: Scores,
    sources: tuple[str, ...],
    candidates: tuple[str, ...],
    truth: Mapping[str, str],
    reference: Mapping[str, str],
) -> tuple[dict[str, object], dict[str, str], dict[str, float]]:
    winners: dict[str, str] = {}
    margins: dict[str, float] = {}
    for source in sources:
        winners[source], margins[source] = _winner_and_margin(
            scores, source, candidates
        )
    return (
        {
            "top1_accuracy": sum(
                winners[source] == truth.get(source) for source in sources
            )
            / len(sources),
            "reference_agreement": sum(
                winners[source] == reference[source] for source in sources
            )
            / len(sources),
            "mean_top_margin": sum(margins.values()) / len(margins),
        },
        winners,
        margins,
    )


def diagnose_deterministic_baselines(
    dataset_dir: str | Path,
    reference_path: str | Path,
    *,
    backbone_name: str = "attribute",
    top_edge_count: int = 20,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Compare deterministic approximations and rank edge variance proxies."""

    dataset = Path(dataset_dir).resolve()
    reference_file = Path(reference_path).resolve()
    reference_payload = json.loads(reference_file.read_text(encoding="utf-8"))
    reference_targets, reference_consensus = reference_winners(reference_payload)

    if backbone_name == "attribute":
        backbone = AttributeStructuralBackbone.from_dataset(dataset)
    elif backbone_name == "toy":
        backbone = ToyStructuralBackbone.from_dataset(dataset)
    else:
        raise ValueError(f"Unsupported backbone: {backbone_name}")

    with (dataset / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        truth = {
            row["source_entity_id"]: row["target_entity_id"]
            for row in csv.DictReader(handle, delimiter="\t")
        }

    probabilities = tuple(float(row["confidence"]) for row in triples)
    sources = backbone.source_entities
    candidates = backbone.target_entities
    expected_scores = backbone.score_expected(probabilities)
    threshold_scores = backbone.score(
        tuple(probability >= 0.5 for probability in probabilities)
    )
    all_edge_scores = backbone.score(tuple(True for _ in probabilities))

    expected_summary, expected_winners, expected_margins = _baseline_summary(
        expected_scores, sources, candidates, truth, reference_targets
    )
    threshold_summary, threshold_winners, _ = _baseline_summary(
        threshold_scores, sources, candidates, truth, reference_targets
    )
    all_edge_summary, all_edge_winners, _ = _baseline_summary(
        all_edge_scores, sources, candidates, truth, reference_targets
    )

    # Compare the MC-consensus winner against its strongest expected-adjacency
    # competitor. p(1-p) * delta_margin^2 is a first-order variance proxy.
    competitors = {}
    for source in sources:
        competitors[source] = sorted(
            (
                (target, expected_scores[(source, target)])
                for target in candidates
                if target != reference_targets[source]
            ),
            key=lambda item: (-item[1], item[0]),
        )[0][0]

    source_variance = {source: 0.0 for source in sources}
    edge_variance = []
    for edge_index, (probability, triple) in enumerate(
        zip(probabilities, triples, strict=True)
    ):
        off = list(probabilities)
        on = list(probabilities)
        off[edge_index] = 0.0
        on[edge_index] = 1.0
        off_scores = backbone.score_expected(tuple(off))
        on_scores = backbone.score_expected(tuple(on))
        total_contribution = 0.0
        for source in sources:
            reference_target = reference_targets[source]
            competitor = competitors[source]
            off_margin = (
                off_scores[(source, reference_target)]
                - off_scores[(source, competitor)]
            )
            on_margin = (
                on_scores[(source, reference_target)]
                - on_scores[(source, competitor)]
            )
            contribution = (
                probability
                * (1.0 - probability)
                * (on_margin - off_margin) ** 2
            )
            source_variance[source] += contribution
            total_contribution += contribution
        edge_variance.append(
            {
                "edge_index": edge_index,
                "graph_id": triple["graph_id"],
                "head_id": triple["head_id"],
                "relation_id": triple["relation_id"],
                "tail_id": triple["tail_id"],
                "probability": probability,
                "variance_proxy": total_contribution,
            }
        )

    edge_variance.sort(
        key=lambda item: (-item["variance_proxy"], item["edge_index"])
    )
    source_difficulty = [
        {
            "source": source,
            "reference_winner": reference_targets[source],
            "ground_truth_target": truth.get(source),
            "reference_correct": reference_targets[source] == truth.get(source),
            "reference_consensus": reference_consensus[source],
            "expected_adjacency_winner": expected_winners[source],
            "expected_adjacency_agrees": (
                expected_winners[source] == reference_targets[source]
            ),
            "threshold_winner": threshold_winners[source],
            "all_edges_winner": all_edge_winners[source],
            "expected_top_margin": expected_margins[source],
            "margin_variance_proxy": source_variance[source],
        }
        for source in sources
    ]
    source_difficulty.sort(
        key=lambda item: (
            item["reference_consensus"],
            item["expected_top_margin"],
            -item["margin_variance_proxy"],
            item["source"],
        )
    )

    result = {
        "dataset_dir": str(dataset),
        "reference_path": str(reference_file),
        "reference": {
            "seed_count": len(reference_payload["seeds"]),
            "budget": reference_payload["aggregate"][-1]["budget"],
            "early_stopping": reference_payload["early_stopping"],
        },
        "backbone": backbone_name,
        "baselines": {
            "expected_adjacency_confidence_as_weight": expected_summary,
            "threshold_0.5": threshold_summary,
            "all_edges": all_edge_summary,
        },
        "source_difficulty": source_difficulty,
        "top_edge_variance_proxies": edge_variance[:top_edge_count],
        "variance_proxy_definition": (
            "p*(1-p)*(change in reference-vs-competitor margin when edge is "
            "forced on versus off)^2; first-order diagnostic, not a causal effect"
        ),
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", encoding="utf-8") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    return result
