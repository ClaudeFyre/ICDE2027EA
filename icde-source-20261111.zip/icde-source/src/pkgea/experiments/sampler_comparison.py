"""Equal-edge-draw comparison of S1, S3, and S5 on real probes."""

from __future__ import annotations

import csv
import json
import statistics
import time
from pathlib import Path
from typing import Callable, Sequence

from pkgea.backbones import AttributeStructuralBackbone, ToyStructuralBackbone
from pkgea.evaluation import estimate_objectives
from pkgea.experiments.baseline_diagnosis import reference_winners
from pkgea.samplers import (
    WorldSample,
    monte_carlo_worlds,
    representative_worlds,
    stratified_worlds,
)


def _effective_sample_size(worlds: Sequence[WorldSample]) -> float:
    total = sum(world.weight for world in worlds)
    return total * total / sum(world.weight * world.weight for world in worlds)


def _estimated_winners(
    winner_probabilities: dict[tuple[str, str], float],
    sources: tuple[str, ...],
    candidates: tuple[str, ...],
) -> dict[str, str]:
    return {
        source: sorted(
            (
                (candidate, winner_probabilities.get((source, candidate), 0.0))
                for candidate in candidates
            ),
            key=lambda item: (-item[1], item[0]),
        )[0][0]
        for source in sources
    }


def run_sampler_comparison(
    dataset_dir: str | Path,
    reference_path: str | Path,
    *,
    sample_count: int,
    seeds: Sequence[int],
    representative_count: int = 32,
    backbone_name: str = "attribute",
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Compare samplers with the same number of Bernoulli edge draws."""

    if sample_count <= 0:
        raise ValueError("sample_count must be positive")
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("seeds must be non-empty and unique")
    if not 0 < representative_count <= sample_count:
        raise ValueError("representative_count must be in [1, sample_count]")

    dataset = Path(dataset_dir).resolve()
    reference_file = Path(reference_path).resolve()
    reference_payload = json.loads(reference_file.read_text(encoding="utf-8"))
    reference, _ = reference_winners(reference_payload)

    if backbone_name == "attribute":
        backbone = AttributeStructuralBackbone.from_dataset(dataset)
    elif backbone_name == "toy":
        backbone = ToyStructuralBackbone.from_dataset(dataset)
    else:
        raise ValueError(f"Unsupported backbone: {backbone_name}")

    with (dataset / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        truth = {
            row["source_entity_id"]: row["target_entity_id"]
            for row in csv.DictReader(handle, delimiter="\t")
        }
    probabilities = [float(row["confidence"]) for row in triples]

    factories: dict[str, Callable[[int], list[WorldSample]]] = {
        "S1_monte_carlo": lambda seed: monte_carlo_worlds(
            probabilities, sample_count, seed
        ),
        "S3_latin_hypercube": lambda seed: stratified_worlds(
            probabilities, sample_count, seed
        ),
        "S5_representative": lambda seed: representative_worlds(
            probabilities,
            representative_count=representative_count,
            candidate_count=sample_count,
            seed=seed,
        ),
    }

    runs = []
    for seed in seeds:
        for method, factory in factories.items():
            started = time.perf_counter()
            worlds = factory(seed)
            estimate = estimate_objectives(worlds, backbone.score)
            winners = _estimated_winners(
                estimate.winner_probability,
                backbone.source_entities,
                backbone.target_entities,
            )
            runs.append(
                {
                    "method": method,
                    "seed": seed,
                    "top1_accuracy": sum(
                        winners[source] == truth.get(source)
                        for source in backbone.source_entities
                    )
                    / len(backbone.source_entities),
                    "reference_agreement": sum(
                        winners[source] == reference[source]
                        for source in backbone.source_entities
                    )
                    / len(backbone.source_entities),
                    "winner_count": len(set(winners.values())),
                    "scored_world_count": len(worlds),
                    "effective_sample_size": _effective_sample_size(worlds),
                    "sampled_edge_draws": sample_count * len(probabilities),
                    "scored_edge_evaluations": (
                        estimate.sampled_edge_evaluations
                    ),
                    "source_winners": winners,
                    "elapsed_seconds": time.perf_counter() - started,
                }
            )

    aggregate = []
    for method in factories:
        method_runs = [run for run in runs if run["method"] == method]
        aggregate.append(
            {
                "method": method,
                "top1_accuracy_mean": statistics.mean(
                    run["top1_accuracy"] for run in method_runs
                ),
                "top1_accuracy_std": (
                    statistics.stdev(
                        run["top1_accuracy"] for run in method_runs
                    )
                    if len(method_runs) > 1
                    else 0.0
                ),
                "reference_agreement_mean": statistics.mean(
                    run["reference_agreement"] for run in method_runs
                ),
                "effective_sample_size_mean": statistics.mean(
                    run["effective_sample_size"] for run in method_runs
                ),
                "scored_world_count_mean": statistics.mean(
                    run["scored_world_count"] for run in method_runs
                ),
                "elapsed_seconds_mean": statistics.mean(
                    run["elapsed_seconds"] for run in method_runs
                ),
                "sampled_edge_draws": sample_count * len(probabilities),
            }
        )

    result = {
        "dataset_dir": str(dataset),
        "reference_path": str(reference_file),
        "backbone": backbone_name,
        "sample_count": sample_count,
        "representative_count": representative_count,
        "seeds": list(seeds),
        "budget_definition": (
            "All methods construct candidates with sample_count full Bernoulli "
            "edge draws; S5 subsequently scores only representative_count medoids."
        ),
        "aggregate": aggregate,
        "runs": runs,
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", encoding="utf-8") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    return result
