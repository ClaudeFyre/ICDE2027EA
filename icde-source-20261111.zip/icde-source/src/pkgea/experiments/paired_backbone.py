"""S2 common-random-number comparisons between EA backbones."""

from __future__ import annotations

import csv
import json
import math
import statistics
import time
from pathlib import Path
from typing import Sequence

from pkgea.backbones import (
    AttributeStructuralBackbone,
    LabelPropagationBackbone,
    ToyStructuralBackbone,
)
from pkgea.samplers import monte_carlo_worlds


def _world_accuracy(backbone, state: tuple[bool, ...], truth: dict[str, str]) -> float:
    scores = backbone.score(state)
    correct = 0
    for source in backbone.source_entities:
        winner = sorted(
            (
                (target, scores[(source, target)])
                for target in backbone.target_entities
            ),
            key=lambda item: (-item[1], item[0]),
        )[0][0]
        correct += winner == truth.get(source)
    return correct / len(backbone.source_entities)


def run_paired_backbone_comparison(
    dataset_dir: str | Path,
    *,
    sample_count: int,
    seeds: Sequence[int],
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Compare toy structural and attribute-structural backbones on shared worlds."""

    if sample_count < 2:
        raise ValueError("sample_count must be at least 2")
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("seeds must be non-empty and unique")
    dataset = Path(dataset_dir).resolve()
    toy = ToyStructuralBackbone.from_dataset(dataset)
    attribute = AttributeStructuralBackbone.from_dataset(dataset)
    with (dataset / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    metadata_path = dataset / "confidence_metadata.json"
    metadata = (
        json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata_path.is_file()
        else {}
    )
    dependence = metadata.get("edge_dependence", {})
    rho = (
        float(metadata.get("generation", {}).get("shared_strength", 0.0))
        if dependence.get("assumption") == "grouped_shared_latent"
        and any(groups)
        else 0.0
    )
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        truth = {
            row["source_entity_id"]: row["target_entity_id"]
            for row in csv.DictReader(handle, delimiter="\t")
        }

    runs = []
    for seed in seeds:
        started = time.perf_counter()
        worlds = monte_carlo_worlds(
            probabilities,
            sample_count,
            seed,
            dependency_groups=groups,
            common_shock_probability=rho,
        )
        toy_accuracy = [
            _world_accuracy(toy, world.state, truth) for world in worlds
        ]
        attribute_accuracy = [
            _world_accuracy(attribute, world.state, truth) for world in worlds
        ]
        differences = [
            right - left
            for left, right in zip(
                toy_accuracy, attribute_accuracy, strict=True
            )
        ]
        toy_variance = statistics.variance(toy_accuracy)
        attribute_variance = statistics.variance(attribute_accuracy)
        difference_variance = statistics.variance(differences)
        unpaired_variance = toy_variance + attribute_variance
        runs.append(
            {
                "seed": seed,
                "toy_accuracy_mean": statistics.mean(toy_accuracy),
                "attribute_accuracy_mean": statistics.mean(attribute_accuracy),
                "paired_difference_mean": statistics.mean(differences),
                "paired_difference_std": math.sqrt(difference_variance),
                "paired_standard_error": math.sqrt(
                    difference_variance / sample_count
                ),
                "unpaired_standard_error_proxy": math.sqrt(
                    unpaired_variance / sample_count
                ),
                "variance_ratio_paired_over_unpaired": (
                    difference_variance / unpaired_variance
                    if unpaired_variance
                    else 0.0
                ),
                "elapsed_seconds": time.perf_counter() - started,
            }
        )

    result = {
        "dataset_dir": str(dataset),
        "sample_count": sample_count,
        "seeds": list(seeds),
        "design": (
            "S2 common random numbers: both backbones score the exact same "
            "possible-world sequence for each seed"
        ),
        "edge_dependence_assumption": dependence.get(
            "assumption", "unspecified"
        ),
        "common_shock_probability": rho,
        "aggregate": {
            key: statistics.mean(run[key] for run in runs)
            for key in (
                "toy_accuracy_mean",
                "attribute_accuracy_mean",
                "paired_difference_mean",
                "paired_standard_error",
                "unpaired_standard_error_proxy",
                "variance_ratio_paired_over_unpaired",
                "elapsed_seconds",
            )
        },
        "runs": runs,
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", encoding="utf-8") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    return result


def run_formal_backbone_crn(
    dataset_dir: str | Path,
    *,
    sample_count: int,
    seed: int = 17,
    split: str = "test",
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Compare attribute and formal propagation backbones on shared worlds."""

    if sample_count < 2:
        raise ValueError("sample_count must be at least 2")
    dataset = Path(dataset_dir).resolve()
    attribute = AttributeStructuralBackbone.from_dataset(dataset)
    propagation = LabelPropagationBackbone.from_dataset(dataset)
    with (dataset / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    metadata_path = dataset / "confidence_metadata.json"
    metadata = (
        json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata_path.is_file()
        else {}
    )
    dependence = metadata.get("edge_dependence", {})
    rho = (
        float(metadata.get("generation", {}).get("shared_strength", 0.0))
        if dependence.get("assumption") == "grouped_shared_latent"
        and any(groups)
        else 0.0
    )
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        rows = [
            row
            for row in csv.DictReader(handle, delimiter="\t")
            if row["split"] == split
        ]
    if not rows:
        raise ValueError(f"No alignment queries found for split: {split}")
    truth = {
        row["source_entity_id"]: row["target_entity_id"] for row in rows
    }
    worlds = monte_carlo_worlds(
        probabilities,
        sample_count,
        seed,
        dependency_groups=groups,
        common_shock_probability=rho,
    )

    def accuracy(scores: dict[tuple[str, str], float]) -> float:
        correct = 0
        for source, target in truth.items():
            winner = min(
                propagation.target_entities,
                key=lambda candidate: (
                    -scores[(source, candidate)],
                    candidate,
                ),
            )
            correct += winner == target
        return correct / len(truth)

    attribute_accuracy = []
    propagation_accuracy = []
    winner_agreement = []
    attribute_seconds = 0.0
    propagation_seconds = 0.0
    for world in worlds:
        started = time.perf_counter()
        attribute_scores = attribute.score(world.state)
        attribute_seconds += time.perf_counter() - started
        started = time.perf_counter()
        propagation_scores = propagation.score(world.state)
        propagation_seconds += time.perf_counter() - started
        attribute_accuracy.append(accuracy(attribute_scores))
        propagation_accuracy.append(accuracy(propagation_scores))
        agreements = 0
        for source in truth:
            attribute_winner = min(
                propagation.target_entities,
                key=lambda candidate: (
                    -attribute_scores[(source, candidate)],
                    candidate,
                ),
            )
            propagation_winner = min(
                propagation.target_entities,
                key=lambda candidate: (
                    -propagation_scores[(source, candidate)],
                    candidate,
                ),
            )
            agreements += attribute_winner == propagation_winner
        winner_agreement.append(agreements / len(truth))

    differences = [
        right - left
        for left, right in zip(
            attribute_accuracy, propagation_accuracy, strict=True
        )
    ]
    difference_variance = statistics.variance(differences)
    unpaired_variance = statistics.variance(
        attribute_accuracy
    ) + statistics.variance(propagation_accuracy)
    result = {
        "dataset_dir": str(dataset),
        "sample_count": sample_count,
        "seed": seed,
        "split": split,
        "query_count": len(truth),
        "candidate_count": len(propagation.target_entities),
        "edge_dependence_assumption": dependence.get(
            "assumption", "unspecified"
        ),
        "common_shock_probability": rho,
        "design": (
            "S2 common random numbers: both backbones score the exact same "
            "ordered possible-world sequence"
        ),
        "backbones": {
            "attribute_structural": {
                "accuracy_mean": statistics.mean(attribute_accuracy),
                "accuracy_std": statistics.stdev(attribute_accuracy),
                "score_seconds": attribute_seconds,
            },
            "seeded_multiview_label_propagation": {
                "accuracy_mean": statistics.mean(propagation_accuracy),
                "accuracy_std": statistics.stdev(propagation_accuracy),
                "score_seconds": propagation_seconds,
            },
        },
        "paired": {
            "accuracy_difference_mean": statistics.mean(differences),
            "accuracy_difference_std": math.sqrt(difference_variance),
            "paired_standard_error": math.sqrt(
                difference_variance / sample_count
            ),
            "unpaired_standard_error_proxy": math.sqrt(
                unpaired_variance / sample_count
            ),
            "variance_ratio_paired_over_unpaired": (
                difference_variance / unpaired_variance
                if unpaired_variance
                else 0.0
            ),
            "winner_agreement_mean": statistics.mean(winner_agreement),
        },
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result
