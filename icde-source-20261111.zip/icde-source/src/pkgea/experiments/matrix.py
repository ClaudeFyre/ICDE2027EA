"""Manifest-driven, resumable experiment matrix execution."""

from __future__ import annotations

import hashlib
import json
import math
import re
import statistics
import time
from pathlib import Path
from typing import Any

from pkgea.contracts import dataset_revision_digest, validate_dataset
from pkgea.experiments.external_adapter import run_external_backbone_crn
from pkgea.experiments.inprocess_smoke import run_translation_smoke
from pkgea.experiments.paired_backbone import run_formal_backbone_crn


_SAFE_ID = re.compile(r"^[A-Za-z0-9_.-]+$")
_RUNNERS = {"formal_crn", "external_crn", "translation_smoke"}


def _resolve(base: Path, value: str) -> Path:
    path = Path(value)
    return (base / path).resolve() if not path.is_absolute() else path.resolve()


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _expand_manifest(
    manifest_path: Path,
    manifest: dict[str, Any],
) -> tuple[Path, list[dict[str, Any]]]:
    if manifest.get("schema_version") != 1:
        raise ValueError("matrix manifest schema_version must be 1")
    jobs = manifest.get("jobs")
    if not isinstance(jobs, list) or not jobs:
        raise ValueError("matrix manifest jobs must be a non-empty list")
    output_value = manifest.get("output_dir", "matrix-results")
    if not isinstance(output_value, str) or not output_value:
        raise ValueError("matrix output_dir must be a non-empty string")
    output_dir = _resolve(manifest_path.parent, output_value)

    tasks = []
    seen_task_ids: set[str] = set()
    for job in jobs:
        if not isinstance(job, dict):
            raise ValueError("each matrix job must be an object")
        job_id = job.get("id")
        runner = job.get("runner")
        dataset_value = job.get("dataset_dir")
        if not isinstance(job_id, str) or not _SAFE_ID.fullmatch(job_id):
            raise ValueError("matrix job id must use [A-Za-z0-9_.-]+")
        if runner not in _RUNNERS:
            raise ValueError(f"unsupported matrix runner: {runner}")
        if not isinstance(dataset_value, str) or not dataset_value:
            raise ValueError(f"job {job_id} requires dataset_dir")
        dataset = _resolve(manifest_path.parent, dataset_value)
        validate_dataset(dataset)
        seeds = job.get("seeds", [17])
        if (
            not isinstance(seeds, list)
            or not seeds
            or any(not isinstance(seed, int) for seed in seeds)
            or len(set(seeds)) != len(seeds)
        ):
            raise ValueError(f"job {job_id} seeds must be unique integers")

        descriptor = None
        descriptor_sha256 = None
        if runner == "external_crn":
            descriptor_value = job.get("descriptor")
            if not isinstance(descriptor_value, str) or not descriptor_value:
                raise ValueError(
                    f"external job {job_id} requires descriptor"
                )
            descriptor = _resolve(manifest_path.parent, descriptor_value)
            if not descriptor.is_file():
                raise ValueError(f"descriptor does not exist: {descriptor}")
            descriptor_sha256 = _file_sha256(descriptor)

        for seed in seeds:
            task_id = f"{job_id}__{runner}__s{seed}"
            if task_id in seen_task_ids:
                raise ValueError(f"duplicate expanded task id: {task_id}")
            seen_task_ids.add(task_id)
            task = {
                "task_id": task_id,
                "job_id": job_id,
                "runner": runner,
                "dataset_dir": str(dataset),
                "dataset_revision": dataset_revision_digest(dataset),
                "seed": seed,
                "split": str(job.get("split", "test")),
                "sample_count": int(job.get("sample_count", 64)),
                "margin_epochs": int(job.get("margin_epochs", 0)),
                "margin": float(job.get("margin", 0.2)),
                "learning_rate": float(job.get("learning_rate", 0.05)),
                "descriptor": str(descriptor) if descriptor else None,
                "descriptor_sha256": descriptor_sha256,
            }
            if task["sample_count"] < 2 and runner != "translation_smoke":
                raise ValueError(
                    f"job {job_id} sample_count must be at least 2"
                )
            tasks.append(task)
    return output_dir, tasks


def _execute_task(task: dict[str, Any]) -> dict[str, object]:
    if task["runner"] == "formal_crn":
        return run_formal_backbone_crn(
            task["dataset_dir"],
            sample_count=task["sample_count"],
            seed=task["seed"],
            split=task["split"],
        )
    if task["runner"] == "external_crn":
        return run_external_backbone_crn(
            task["dataset_dir"],
            task["descriptor"],
            sample_count=task["sample_count"],
            seed=task["seed"],
            split=task["split"],
        )
    if task["runner"] == "translation_smoke":
        return run_translation_smoke(
            task["dataset_dir"],
            margin_epochs=task["margin_epochs"],
            margin=task["margin"],
            learning_rate=task["learning_rate"],
            seed=task["seed"],
        )
    raise AssertionError(f"unhandled runner: {task['runner']}")


def _aggregate_completed_artifacts(
    records: list[dict[str, object]],
) -> dict[str, object]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in records:
        artifact = Path(str(row["artifact"]))
        payload = json.loads(artifact.read_text(encoding="utf-8"))
        if payload.get("status") != "completed":
            continue
        grouped.setdefault(payload["task"]["job_id"], []).append(payload)

    aggregates: dict[str, object] = {}
    for job_id, payloads in sorted(grouped.items()):
        runner = payloads[0]["task"]["runner"]
        if runner in {"formal_crn", "external_crn"}:
            grouped_moments = [
                (
                    int(payload["task"]["sample_count"]),
                    float(
                        payload["result"]["paired"][
                            "accuracy_difference_mean"
                        ]
                    ),
                    float(
                        payload["result"]["paired"][
                            "accuracy_difference_std"
                        ]
                    ),
                )
                for payload in payloads
            ]
            observation_count = sum(row[0] for row in grouped_moments)
            difference_mean = sum(
                count * mean for count, mean, _ in grouped_moments
            ) / observation_count
            sum_squares = sum(
                (count - 1) * std * std
                + count * (mean - difference_mean) ** 2
                for count, mean, std in grouped_moments
            )
            difference_std = math.sqrt(
                sum_squares / max(observation_count - 1, 1)
            )
            standard_error = difference_std / math.sqrt(observation_count)
            z_score = (
                difference_mean / standard_error
                if standard_error
                else math.inf
            )
            aggregates[job_id] = {
                "runner": runner,
                "seed_count": len(payloads),
                "world_observation_count": observation_count,
                "paired_accuracy_difference_mean": difference_mean,
                "paired_standard_error": standard_error,
                "normal_95_interval": [
                    difference_mean - 1.96 * standard_error,
                    difference_mean + 1.96 * standard_error,
                ],
                "normal_approximation_two_sided_p": (
                    math.erfc(abs(z_score) / math.sqrt(2.0))
                    if math.isfinite(z_score)
                    else 0.0
                ),
                "inference_scope": (
                    "Conditional Monte Carlo uncertainty on this frozen "
                    "dataset/checkpoint; not cross-dataset significance."
                ),
            }
        else:
            split_names = sorted(
                {
                    split
                    for payload in payloads
                    for split in payload["result"]["split_metrics"]
                }
            )
            aggregates[job_id] = {
                "runner": runner,
                "seed_count": len(payloads),
                "split_top1_accuracy_mean": {
                    split: statistics.mean(
                        payload["result"]["split_metrics"][split][
                            "top1_accuracy"
                        ]
                        for payload in payloads
                        if split in payload["result"]["split_metrics"]
                    )
                    for split in split_names
                },
            }
    return aggregates


def run_experiment_matrix(
    manifest_file: str | Path,
    *,
    resume: bool = True,
) -> dict[str, object]:
    """Execute every expanded task sequentially and persist resumable records."""

    manifest_path = Path(manifest_file).resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise ValueError("matrix manifest root must be an object")
    output_dir, tasks = _expand_manifest(manifest_path, manifest)
    output_dir.mkdir(parents=True, exist_ok=True)
    continue_on_error = bool(manifest.get("continue_on_error", True))
    records = []

    for task in tasks:
        artifact = output_dir / f"{task['task_id']}.json"
        if resume and artifact.is_file():
            prior = json.loads(artifact.read_text(encoding="utf-8"))
            if (
                prior.get("task") == task
                and prior.get("status") == "completed"
            ):
                records.append(
                    {
                        "task_id": task["task_id"],
                        "status": "skipped_existing",
                        "artifact": str(artifact),
                        "elapsed_seconds": prior.get("elapsed_seconds", 0.0),
                    }
                )
                continue
            raise ValueError(
                f"existing matrix artifact does not match task: {artifact}"
            )

        started = time.perf_counter()
        try:
            result = _execute_task(task)
            record = {
                "task": task,
                "status": "completed",
                "elapsed_seconds": time.perf_counter() - started,
                "result": result,
            }
        except Exception as exc:
            record = {
                "task": task,
                "status": "failed",
                "elapsed_seconds": time.perf_counter() - started,
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
        artifact.write_text(
            json.dumps(record, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        records.append(
            {
                "task_id": task["task_id"],
                "status": record["status"],
                "artifact": str(artifact),
                "elapsed_seconds": record["elapsed_seconds"],
            }
        )
        if record["status"] == "failed" and not continue_on_error:
            break

    counts = {
        status: sum(row["status"] == status for row in records)
        for status in ("completed", "skipped_existing", "failed")
    }
    summary = {
        "manifest": str(manifest_path),
        "manifest_sha256": _file_sha256(manifest_path),
        "output_dir": str(output_dir),
        "expanded_task_count": len(tasks),
        "executed_record_count": len(records),
        "resume": resume,
        "continue_on_error": continue_on_error,
        "counts": counts,
        "records": records,
        "job_aggregates": _aggregate_completed_artifacts(records),
    }
    (output_dir / "matrix_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return summary
