"""Reproducible experiment runners."""

from pkgea.experiments.budget_curve import (
    run_budget_curve,
    run_multi_seed_budget_curve,
)
from pkgea.experiments.baseline_diagnosis import diagnose_deterministic_baselines
from pkgea.experiments.sampler_comparison import run_sampler_comparison
from pkgea.experiments.paired_backbone import (
    run_formal_backbone_crn,
    run_paired_backbone_comparison,
)
from pkgea.experiments.external_adapter import (
    run_external_adapter_smoke,
    run_external_backbone_crn,
)
from pkgea.experiments.inprocess_smoke import (
    run_label_propagation_smoke,
    run_translation_smoke,
)
from pkgea.experiments.matrix import run_experiment_matrix

__all__ = [
    "diagnose_deterministic_baselines",
    "run_budget_curve",
    "run_multi_seed_budget_curve",
    "run_sampler_comparison",
    "run_paired_backbone_comparison",
    "run_formal_backbone_crn",
    "run_external_adapter_smoke",
    "run_external_backbone_crn",
    "run_label_propagation_smoke",
    "run_translation_smoke",
    "run_experiment_matrix",
]
