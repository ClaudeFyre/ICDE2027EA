"""Smoke-test external checkpoint adapters on two possible worlds."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import time
from pathlib import Path

from pkgea.backbones import (
    AttributeStructuralBackbone,
    CheckpointDescriptor,
    SubprocessBackboneAdapter,
)
from pkgea.contracts import dataset_revision_digest, validate_dataset
from pkgea.samplers import monte_carlo_worlds


def _train_split_checksum(rows: list[dict[str, str]]) -> str:
    ordered = sorted(
        (
            row["source_entity_id"],
            row["target_entity_id"],
            row["confidence"],
        )
        for row in rows
        if row["split"] == "train"
    )
    payload = "\n".join("\t".join(row) for row in ordered).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _validate_descriptor_scope(
    dataset: Path,
    descriptor: CheckpointDescriptor,
    alignments: list[dict[str, str]],
) -> None:
    metadata = json.loads(
        (dataset / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    if descriptor.dataset_id != metadata["dataset_id"]:
        raise ValueError(
            f"Descriptor dataset_id {descriptor.dataset_id!r} does not match "
            f"{metadata['dataset_id']!r}"
        )
    if descriptor.train_split_checksum != _train_split_checksum(alignments):
        raise ValueError("Descriptor train split checksum mismatch")
    if (
        descriptor.dataset_revision is not None
        and descriptor.dataset_revision != dataset_revision_digest(dataset)
    ):
        raise ValueError("Descriptor dataset revision mismatch")


def run_external_adapter_smoke(
    dataset_dir: str | Path,
    descriptor_path: str | Path,
    *,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    dataset = Path(dataset_dir).resolve()
    validate_dataset(dataset)
    descriptor = CheckpointDescriptor.load(descriptor_path)
    with (dataset / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    _validate_descriptor_scope(dataset, descriptor, alignments)
    sources = tuple(
        dict.fromkeys(row["source_entity_id"] for row in alignments)
    )
    targets = tuple(
        dict.fromkeys(row["target_entity_id"] for row in alignments)
    )
    adapter = SubprocessBackboneAdapter(
        descriptor,
        source_entities=sources,
        target_entities=targets,
        edge_count=len(triples),
    )
    median_state = tuple(float(row["confidence"]) >= 0.5 for row in triples)
    perturbed_state = list(median_state)
    uncertain = [
        index
        for index, row in enumerate(triples)
        if 0.0 < float(row["confidence"]) < 1.0
    ]
    if not uncertain:
        raise ValueError("Smoke test requires at least one uncertain edge")
    changed_edge = uncertain[0]
    perturbed_state[changed_edge] = not perturbed_state[changed_edge]
    median_scores = adapter.score(median_state)
    perturbed_scores = adapter.score(tuple(perturbed_state))

    def winners(scores: dict[tuple[str, str], float]) -> dict[str, str]:
        return {
            source: sorted(
                ((target, scores[(source, target)]) for target in targets),
                key=lambda item: (-item[1], item[0]),
            )[0][0]
            for source in sources
        }

    median_winners = winners(median_scores)
    deltas = {
        pair: abs(median_scores[pair] - perturbed_scores[pair])
        for pair in median_scores
    }
    split_metrics = {}
    for split in ("train", "validation", "test"):
        rows = [row for row in alignments if row["split"] == split]
        if rows:
            split_metrics[split] = {
                "pair_count": len(rows),
                "top1_accuracy": sum(
                    median_winners[row["source_entity_id"]]
                    == row["target_entity_id"]
                    for row in rows
                )
                / len(rows),
            }
    result = {
        "dataset_dir": str(dataset),
        "descriptor_path": str(Path(descriptor_path).resolve()),
        "adapter_id": descriptor.adapter_id,
        "framework": descriptor.framework,
        "checkpoint_sha256": descriptor.checkpoint_sha256,
        "probability_handling": descriptor.probability_handling,
        "score_matrix_shape": [len(sources), len(targets)],
        "split_metrics": split_metrics,
        "perturbation": {
            "edge_index": changed_edge,
            "graph_id": triples[changed_edge]["graph_id"],
            "relation_id": triples[changed_edge]["relation_id"],
            "changed_score_count": sum(delta > 1e-12 for delta in deltas.values()),
            "max_absolute_score_change": max(deltas.values()),
            "winner_flip_count": sum(
                median_winners[source] != winners(perturbed_scores)[source]
                for source in sources
            ),
        },
    }
    if result["perturbation"]["changed_score_count"] == 0:
        raise ValueError("Adapter is insensitive to a sampled-world edge change")
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def run_external_backbone_crn(
    dataset_dir: str | Path,
    descriptor_path: str | Path,
    *,
    sample_count: int,
    seed: int = 17,
    split: str = "test",
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Compare an external checkpoint and attribute baseline on shared worlds."""

    if sample_count < 2:
        raise ValueError("sample_count must be at least 2")
    dataset = Path(dataset_dir).resolve()
    validate_dataset(dataset)
    descriptor = CheckpointDescriptor.load(descriptor_path)
    metadata = json.loads(
        (dataset / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    with (dataset / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    _validate_descriptor_scope(dataset, descriptor, alignments)
    evaluation = [row for row in alignments if row["split"] == split]
    if not evaluation:
        raise ValueError(f"No alignment queries found for split: {split}")
    sources = tuple(
        dict.fromkeys(row["source_entity_id"] for row in evaluation)
    )
    targets = tuple(
        dict.fromkeys(row["target_entity_id"] for row in alignments)
    )
    truth = {
        row["source_entity_id"]: row["target_entity_id"]
        for row in evaluation
    }
    probabilities = [float(row["confidence"]) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    dependence = metadata.get("edge_dependence", {})
    rho = (
        float(metadata.get("generation", {}).get("shared_strength", 0.0))
        if dependence.get("assumption") == "grouped_shared_latent"
        and any(groups)
        else 0.0
    )
    worlds = monte_carlo_worlds(
        probabilities,
        sample_count,
        seed,
        dependency_groups=groups,
        common_shock_probability=rho,
    )
    states = [world.state for world in worlds]
    adapter = SubprocessBackboneAdapter(
        descriptor,
        source_entities=sources,
        target_entities=targets,
        edge_count=len(triples),
    )
    started = time.perf_counter()
    external_scores = adapter.score_batch(states)
    external_seconds = time.perf_counter() - started
    attribute = AttributeStructuralBackbone.from_dataset(dataset)
    started = time.perf_counter()
    attribute_scores = [
        attribute.score_subset(state, sources, targets) for state in states
    ]
    attribute_seconds = time.perf_counter() - started

    def winners(
        scores: dict[tuple[str, str], float]
    ) -> dict[str, str]:
        return {
            source: min(
                targets,
                key=lambda target: (-scores[(source, target)], target),
            )
            for source in sources
        }

    external_accuracies = []
    attribute_accuracies = []
    agreements = []
    for external_matrix, attribute_matrix in zip(
        external_scores, attribute_scores, strict=True
    ):
        external_winners = winners(external_matrix)
        attribute_winners = winners(attribute_matrix)
        external_accuracies.append(
            sum(external_winners[source] == truth[source] for source in sources)
            / len(sources)
        )
        attribute_accuracies.append(
            sum(attribute_winners[source] == truth[source] for source in sources)
            / len(sources)
        )
        agreements.append(
            sum(
                external_winners[source] == attribute_winners[source]
                for source in sources
            )
            / len(sources)
        )
    differences = [
        external - baseline
        for external, baseline in zip(
            external_accuracies, attribute_accuracies, strict=True
        )
    ]
    paired_variance = statistics.variance(differences)
    unpaired_variance = statistics.variance(
        external_accuracies
    ) + statistics.variance(attribute_accuracies)
    result = {
        "dataset_dir": str(dataset),
        "descriptor_path": str(Path(descriptor_path).resolve()),
        "adapter_id": descriptor.adapter_id,
        "sample_count": sample_count,
        "seed": seed,
        "split": split,
        "query_count": len(sources),
        "candidate_count": len(targets),
        "edge_dependence_assumption": dependence.get(
            "assumption", "unspecified"
        ),
        "common_shock_probability": rho,
        "protocol": (
            "pkgea-backbone-v2: one checkpoint load and one ordered batch "
            "response for all shared worlds"
        ),
        "backbones": {
            "attribute_structural": {
                "accuracy_mean": statistics.mean(attribute_accuracies),
                "accuracy_std": statistics.stdev(attribute_accuracies),
                "score_seconds": attribute_seconds,
            },
            "external_checkpoint": {
                "accuracy_mean": statistics.mean(external_accuracies),
                "accuracy_std": statistics.stdev(external_accuracies),
                "score_seconds": external_seconds,
            },
        },
        "paired": {
            "accuracy_difference_mean": statistics.mean(differences),
            "accuracy_difference_std": math.sqrt(paired_variance),
            "paired_standard_error": math.sqrt(
                paired_variance / sample_count
            ),
            "unpaired_standard_error_proxy": math.sqrt(
                unpaired_variance / sample_count
            ),
            "variance_ratio_paired_over_unpaired": (
                paired_variance / unpaired_variance
                if unpaired_variance
                else 0.0
            ),
            "winner_agreement_mean": statistics.mean(agreements),
        },
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result
