"""Budget-accuracy-efficiency curves for the adaptive WSDM prototype."""

from __future__ import annotations

import json
import math
import statistics
import time
from pathlib import Path
from typing import Sequence

from pkgea.wsdm import run_toy_adaptive_sampling


def run_budget_curve(
    dataset_dir: str | Path,
    budgets: Sequence[int],
    *,
    seed: int = 17,
    backbone_name: str = "attribute",
    early_stopping: bool = True,
    evaluation_split: str | None = None,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Run ordered budgets and optionally persist a JSON artifact."""

    if not budgets or any(budget <= 0 for budget in budgets):
        raise ValueError("budgets must contain positive integers")
    if list(budgets) != sorted(set(budgets)):
        raise ValueError("budgets must be unique and increasing")

    dataset = Path(dataset_dir).resolve()
    points: list[dict[str, object]] = []
    for budget in budgets:
        started = time.perf_counter()
        report = run_toy_adaptive_sampling(
            dataset,
            total_budget=budget,
            seed=seed,
            backbone_name=backbone_name,
            early_stopping=early_stopping,
            evaluation_split=evaluation_split,
        )
        source_winners = {
            item["source"]: item["winner"] for item in report["sources"]
        }
        points.append(
            {
                "budget": budget,
                "allocated_worlds": report["total_allocated_worlds"],
                "used_worlds": report["total_used_worlds"],
                "sampled_edges": report["total_sampled_edges"],
                "top1_accuracy": report["ground_truth_top1_accuracy"],
                "correct_winners": report["correct_winners"],
                "early_stopped_sources": report["early_stopped_sources"],
                "local_edge_fraction": report["local_edge_fraction"],
                "edge_dependence_assumption": report[
                    "edge_dependence_assumption"
                ],
                "common_shock_probability": report[
                    "common_shock_probability"
                ],
                "source_winners": source_winners,
                "elapsed_seconds": time.perf_counter() - started,
            }
        )

    result = {
        "dataset_dir": str(dataset),
        "backbone": backbone_name,
        "seed": seed,
        "early_stopping": early_stopping,
        "evaluation_split": evaluation_split,
        "points": points,
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", encoding="utf-8") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    return result


def _winner_stability(
    winner_maps: Sequence[dict[str, str]],
) -> tuple[float, int]:
    sources = sorted(winner_maps[0]) if winner_maps else []
    if any(sorted(mapping) != sources for mapping in winner_maps):
        raise ValueError("All seeds must evaluate the same source entities")
    consensus_fractions = []
    unanimous = 0
    for source in sources:
        winners = [mapping[source] for mapping in winner_maps]
        mode_count = max(winners.count(winner) for winner in set(winners))
        consensus_fractions.append(mode_count / len(winners))
        unanimous += len(set(winners)) == 1
    return (
        statistics.mean(consensus_fractions) if consensus_fractions else 1.0,
        unanimous,
    )


def run_multi_seed_budget_curve(
    dataset_dir: str | Path,
    budgets: Sequence[int],
    seeds: Sequence[int],
    *,
    backbone_name: str = "attribute",
    early_stopping: bool = True,
    evaluation_split: str | None = None,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Run replicated curves and aggregate accuracy and ranking stability."""

    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("seeds must be non-empty and unique")
    runs = [
        run_budget_curve(
            dataset_dir,
            budgets,
            seed=seed,
            backbone_name=backbone_name,
            early_stopping=early_stopping,
            evaluation_split=evaluation_split,
        )
        for seed in seeds
    ]

    aggregate = []
    for point_index, budget in enumerate(budgets):
        points = [run["points"][point_index] for run in runs]
        accuracies = [float(point["top1_accuracy"]) for point in points]
        accuracy_mean = statistics.mean(accuracies)
        accuracy_std = statistics.stdev(accuracies) if len(accuracies) > 1 else 0.0
        half_width = 1.96 * accuracy_std / math.sqrt(len(accuracies))
        stability, unanimous = _winner_stability(
            [point["source_winners"] for point in points]
        )
        aggregate.append(
            {
                "budget": budget,
                "top1_accuracy_mean": accuracy_mean,
                "top1_accuracy_std": accuracy_std,
                "top1_accuracy_ci95": [
                    max(0.0, accuracy_mean - half_width),
                    min(1.0, accuracy_mean + half_width),
                ],
                "winner_consensus_mean": stability,
                "unanimous_source_count": unanimous,
                "source_count": len(points[0]["source_winners"]),
                "used_worlds_mean": statistics.mean(
                    float(point["used_worlds"]) for point in points
                ),
                "sampled_edges_mean": statistics.mean(
                    float(point["sampled_edges"]) for point in points
                ),
                "elapsed_seconds_mean": statistics.mean(
                    float(point["elapsed_seconds"]) for point in points
                ),
            }
        )

    result = {
        "dataset_dir": str(Path(dataset_dir).resolve()),
        "backbone": backbone_name,
        "seeds": list(seeds),
        "early_stopping": early_stopping,
        "evaluation_split": evaluation_split,
        "aggregate": aggregate,
        "runs": runs,
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("w", encoding="utf-8") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    return result
