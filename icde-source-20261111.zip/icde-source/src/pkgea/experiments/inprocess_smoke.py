"""World-sensitivity smoke tests for in-process formal backbones."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from pkgea.backbones import (
    LabelPropagationBackbone,
    RelationTranslationBackbone,
)


def run_label_propagation_smoke(
    dataset_dir: str | Path,
    *,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    dataset = Path(dataset_dir).resolve()
    backbone = LabelPropagationBackbone.from_dataset(dataset)
    with (dataset / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    state = tuple(float(row["confidence"]) >= 0.5 for row in triples)
    perturbed = list(state)
    edge_index = next(
        index
        for index, row in enumerate(triples)
        if 0.0 < float(row["confidence"]) < 1.0
    )
    perturbed[edge_index] = not perturbed[edge_index]
    scores = backbone.score(state)
    changed_scores = backbone.score(tuple(perturbed))

    winners = {
        source: sorted(
            (
                (target, scores[(source, target)])
                for target in backbone.target_entities
            ),
            key=lambda item: (-item[1], item[0]),
        )[0][0]
        for source in backbone.source_entities
    }
    split_metrics = {}
    for split in ("train", "validation", "test"):
        rows = [row for row in alignments if row["split"] == split]
        if rows:
            split_metrics[split] = {
                "pair_count": len(rows),
                "top1_accuracy": sum(
                    winners[row["source_entity_id"]]
                    == row["target_entity_id"]
                    for row in rows
                )
                / len(rows),
            }
    deltas = [
        abs(scores[pair] - changed_scores[pair]) for pair in scores
    ]
    result = {
        "dataset_dir": str(dataset),
        "backbone": "project/seeded-multiview-label-propagation-v1",
        "score_matrix_shape": [
            len(backbone.source_entities),
            len(backbone.target_entities),
        ],
        "split_metrics": split_metrics,
        "perturbation": {
            "edge_index": edge_index,
            "changed_score_count": sum(delta > 1e-12 for delta in deltas),
            "max_absolute_score_change": max(deltas),
        },
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def run_translation_smoke(
    dataset_dir: str | Path,
    *,
    margin_epochs: int = 0,
    margin: float = 0.2,
    learning_rate: float = 0.05,
    seed: int = 17,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Validate the project relation-translation baseline on a real probe."""

    dataset = Path(dataset_dir).resolve()
    backbone = RelationTranslationBackbone.from_dataset(
        dataset,
        margin_epochs=margin_epochs,
        margin=margin,
        learning_rate=learning_rate,
        seed=seed,
    )
    with (dataset / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    with (dataset / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    state = tuple(float(row["confidence"]) >= 0.5 for row in triples)
    edge_index = next(
        index
        for index, row in enumerate(triples)
        if 0.0 < float(row["confidence"]) < 1.0
    )
    changed = list(state)
    changed[edge_index] = not changed[edge_index]
    scores = backbone.score(state)
    changed_scores = backbone.score(tuple(changed))
    winners = {
        source: min(
            backbone.target_entities,
            key=lambda target: (-scores[(source, target)], target),
        )
        for source in backbone.source_entities
    }
    split_metrics = {}
    for split in ("train", "validation", "test"):
        rows = [row for row in alignments if row["split"] == split]
        if rows:
            split_metrics[split] = {
                "pair_count": len(rows),
                "top1_accuracy": sum(
                    winners[row["source_entity_id"]]
                    == row["target_entity_id"]
                    for row in rows
                )
                / len(rows),
            }
    deltas = [
        abs(scores[pair] - changed_scores[pair]) for pair in scores
    ]
    result = {
        "dataset_dir": str(dataset),
        "backbone": "project/relation-translation-procrustes-v1",
        "training": backbone.training_summary,
        "score_matrix_shape": [
            len(backbone.source_entities),
            len(backbone.target_entities),
        ],
        "split_metrics": split_metrics,
        "perturbation": {
            "edge_index": edge_index,
            "changed_score_count": sum(delta > 1e-12 for delta in deltas),
            "max_absolute_score_change": max(deltas),
        },
        "claim_boundary": (
            "Project-owned relation-profile translation baseline with optional "
            "hard-negative margin refinement; not an official TransE "
            "implementation."
        ),
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result
