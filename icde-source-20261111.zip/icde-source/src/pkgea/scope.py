"""Machine-readable dependency-aware local scoring certificates."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from typing import Callable, Hashable, Mapping, Sequence


def _digest(payload: object) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def candidate_set_digest(candidates: Sequence[Hashable]) -> str:
    if not candidates:
        raise ValueError("candidate set must be non-empty")
    return _digest([str(candidate) for candidate in candidates])


@dataclass(frozen=True)
class LocalScopeCertificate:
    scorer_id: str
    scorer_version: str
    checkpoint_sha256: str | None
    dataset_revision: str
    query_id: str
    candidate_set_sha256: str
    edge_ids: tuple[str, ...]
    edge_variable_ids: tuple[str, ...]
    dependency_factor_ids: tuple[str, ...]
    global_state_dependencies: tuple[str, ...]
    normalization_scope: tuple[str, ...]
    exact: bool
    certificate_sha256: str

    @classmethod
    def create(
        cls,
        *,
        scorer_id: str,
        scorer_version: str,
        checkpoint_sha256: str | None,
        dataset_revision: str,
        query_id: Hashable,
        candidates: Sequence[Hashable],
        edge_ids: Sequence[Hashable],
        edge_variable_ids: Sequence[Hashable],
        dependency_factor_ids: Sequence[Hashable] = (),
        global_state_dependencies: Sequence[Hashable] = (),
        normalization_scope: Sequence[Hashable] = (),
        exact: bool,
    ) -> "LocalScopeCertificate":
        payload = {
            "scorer_id": scorer_id,
            "scorer_version": scorer_version,
            "checkpoint_sha256": checkpoint_sha256,
            "dataset_revision": dataset_revision,
            "query_id": str(query_id),
            "candidate_set_sha256": candidate_set_digest(candidates),
            "edge_ids": sorted(str(item) for item in edge_ids),
            "edge_variable_ids": sorted(str(item) for item in edge_variable_ids),
            "dependency_factor_ids": sorted(
                str(item) for item in dependency_factor_ids
            ),
            "global_state_dependencies": sorted(
                str(item) for item in global_state_dependencies
            ),
            "normalization_scope": sorted(str(item) for item in normalization_scope),
            "exact": bool(exact),
        }
        return cls(
            scorer_id=scorer_id,
            scorer_version=scorer_version,
            checkpoint_sha256=checkpoint_sha256,
            dataset_revision=dataset_revision,
            query_id=str(query_id),
            candidate_set_sha256=payload["candidate_set_sha256"],
            edge_ids=tuple(payload["edge_ids"]),
            edge_variable_ids=tuple(payload["edge_variable_ids"]),
            dependency_factor_ids=tuple(payload["dependency_factor_ids"]),
            global_state_dependencies=tuple(payload["global_state_dependencies"]),
            normalization_scope=tuple(payload["normalization_scope"]),
            exact=bool(exact),
            certificate_sha256=_digest(payload),
        )

    def unsigned_payload(self) -> dict[str, object]:
        return {
            "scorer_id": self.scorer_id,
            "scorer_version": self.scorer_version,
            "checkpoint_sha256": self.checkpoint_sha256,
            "dataset_revision": self.dataset_revision,
            "query_id": self.query_id,
            "candidate_set_sha256": self.candidate_set_sha256,
            "edge_ids": list(self.edge_ids),
            "edge_variable_ids": list(self.edge_variable_ids),
            "dependency_factor_ids": list(self.dependency_factor_ids),
            "global_state_dependencies": list(self.global_state_dependencies),
            "normalization_scope": list(self.normalization_scope),
            "exact": self.exact,
        }

    def validate(self) -> None:
        if not self.scorer_id or not self.scorer_version or not self.query_id:
            raise ValueError("scorer identity, version, and query id are required")
        if len(self.dataset_revision) != 64:
            raise ValueError("dataset_revision must be a SHA-256 digest")
        if self.checkpoint_sha256 is not None and len(self.checkpoint_sha256) != 64:
            raise ValueError("checkpoint_sha256 must be null or a SHA-256 digest")
        if len(self.candidate_set_sha256) != 64:
            raise ValueError("candidate_set_sha256 must be a SHA-256 digest")
        if len(set(self.edge_ids)) != len(self.edge_ids):
            raise ValueError("edge_ids must be unique")
        if len(set(self.edge_variable_ids)) != len(self.edge_variable_ids):
            raise ValueError("edge_variable_ids must be unique")
        if len(self.edge_ids) != len(self.edge_variable_ids):
            raise ValueError("each scoped edge must have one existence variable")
        observed = _digest(self.unsigned_payload())
        if observed != self.certificate_sha256:
            raise ValueError("scope certificate SHA-256 mismatch")

    def as_dict(self) -> dict[str, object]:
        payload = self.unsigned_payload()
        payload["certificate_sha256"] = self.certificate_sha256
        return payload


def build_incident_degree_certificate(
    triples: Sequence[Mapping[str, str]],
    *,
    dataset_revision: str,
    query_id: Hashable,
    candidates: Sequence[Hashable],
    scorer_id: str,
    scorer_version: str,
    checkpoint_sha256: str | None = None,
) -> tuple[LocalScopeCertificate, set[int]]:
    """Build an exact incident-edge scope for a degree-local scorer."""

    entities = {str(query_id), *(str(candidate) for candidate in candidates)}
    selected = {
        index
        for index, triple in enumerate(triples)
        if triple["head_id"] in entities or triple["tail_id"] in entities
    }
    edge_ids = [
        f"edge:{index}:{triples[index].get('evidence_id', '')}" for index in selected
    ]
    edge_variables = [f"Z:{edge_id}" for edge_id in edge_ids]
    groups = {
        triples[index].get("dependency_group", "")
        for index in selected
        if triples[index].get("dependency_group", "")
    }
    certificate = LocalScopeCertificate.create(
        scorer_id=scorer_id,
        scorer_version=scorer_version,
        checkpoint_sha256=checkpoint_sha256,
        dataset_revision=dataset_revision,
        query_id=query_id,
        candidates=candidates,
        edge_ids=edge_ids,
        edge_variable_ids=edge_variables,
        dependency_factor_ids=[f"U:dependency_group:{group}" for group in groups],
        global_state_dependencies=(),
        normalization_scope=("query-and-candidate-incident-degree",),
        exact=True,
    )
    certificate.validate()
    return certificate, selected


def influence_edge_indices(
    triples: Sequence[Mapping[str, str]],
    roots: Sequence[Hashable],
    *,
    message_passing_steps: int,
) -> set[int]:
    """Return the complete edge frontier needed by root embeddings.

    A synchronous ``L``-step message-passing scorer needs every incident edge
    of nodes at graph distance ``0, ..., L - 1`` from a scored root.  Including
    the complete incident frontier is important for active-neighbor/degree
    normalization: retaining only paths that happened to be active in one
    world would make the scope itself world dependent.
    """

    if message_passing_steps <= 0:
        raise ValueError("message_passing_steps must be positive")
    frontier = {str(root) for root in roots}
    if not frontier:
        raise ValueError("roots must be non-empty")
    expanded: set[str] = set()
    selected: set[int] = set()
    for _ in range(message_passing_steps):
        active_frontier = frontier - expanded
        if not active_frontier:
            break
        next_frontier: set[str] = set()
        for index, triple in enumerate(triples):
            head = triple["head_id"]
            tail = triple["tail_id"]
            if head in active_frontier or tail in active_frontier:
                selected.add(index)
                next_frontier.add(head)
                next_frontier.add(tail)
        expanded.update(active_frontier)
        frontier = next_frontier
    return selected


def build_message_passing_certificate(
    triples: Sequence[Mapping[str, str]],
    *,
    dataset_revision: str,
    query_id: Hashable,
    candidates: Sequence[Hashable],
    message_passing_steps: int,
    scorer_id: str,
    scorer_version: str,
    checkpoint_sha256: str | None = None,
    global_state_dependencies: Sequence[Hashable] = (),
    normalization_scope: Sequence[Hashable] = (),
) -> tuple[LocalScopeCertificate, set[int]]:
    """Build an exact scope certificate for finite-depth message passing.

    The caller remains responsible for declaring every frozen non-edge input
    (for example seed labels or checkpoint features) and for verifying that
    the scorer has no graph-global, batch-global, or cross-query operation.
    """

    roots = (query_id, *candidates)
    selected = influence_edge_indices(
        triples,
        roots,
        message_passing_steps=message_passing_steps,
    )
    edge_ids = [
        f"edge:{index}:{triples[index].get('evidence_id', '')}"
        for index in selected
    ]
    groups = {
        triples[index].get("dependency_group", "")
        for index in selected
        if triples[index].get("dependency_group", "")
    }
    certificate = LocalScopeCertificate.create(
        scorer_id=scorer_id,
        scorer_version=scorer_version,
        checkpoint_sha256=checkpoint_sha256,
        dataset_revision=dataset_revision,
        query_id=query_id,
        candidates=candidates,
        edge_ids=edge_ids,
        edge_variable_ids=[f"Z:{edge_id}" for edge_id in edge_ids],
        dependency_factor_ids=[f"U:dependency_group:{group}" for group in groups],
        global_state_dependencies=global_state_dependencies,
        normalization_scope=(
            f"complete-incident-frontier:depth-{message_passing_steps}",
            *normalization_scope,
        ),
        exact=True,
    )
    certificate.validate()
    return certificate, selected


@dataclass(frozen=True)
class ScopeEquivalenceResult:
    checked_worlds: int
    checked_scores: int
    score_mismatch_worlds: int
    winner_mismatch_worlds: int
    maximum_absolute_error: float
    tolerance: float
    exact: bool

    def as_dict(self) -> dict[str, object]:
        return {
            "checked_worlds": self.checked_worlds,
            "checked_scores": self.checked_scores,
            "score_mismatch_worlds": self.score_mismatch_worlds,
            "winner_mismatch_worlds": self.winner_mismatch_worlds,
            "maximum_absolute_error": self.maximum_absolute_error,
            "tolerance": self.tolerance,
            "exact": self.exact,
        }


def validate_full_local_score_equivalence(
    certificate: LocalScopeCertificate,
    full_states: Sequence[tuple[bool, ...]],
    local_states: Sequence[tuple[bool, ...]],
    score_function: Callable[[tuple[bool, ...]], Mapping[Hashable, float]],
    *,
    tolerance: float = 0.0,
) -> ScopeEquivalenceResult:
    """Compare all-candidate score vectors on paired full/local states."""

    certificate.validate()
    if len(full_states) != len(local_states) or not full_states:
        raise ValueError("paired full/local states must have equal non-zero length")
    if not math.isfinite(tolerance) or tolerance < 0.0:
        raise ValueError("tolerance must be finite and non-negative")
    score_mismatches = 0
    winner_mismatches = 0
    checked_scores = 0
    maximum_error = 0.0
    for full_state, local_state in zip(full_states, local_states, strict=True):
        full_scores = dict(score_function(full_state))
        local_scores = dict(score_function(local_state))
        if full_scores.keys() != local_scores.keys() or not full_scores:
            raise ValueError("full/local score keys must be identical and non-empty")
        world_mismatch = False
        for candidate in full_scores:
            error = abs(float(full_scores[candidate]) - float(local_scores[candidate]))
            maximum_error = max(maximum_error, error)
            checked_scores += 1
            if error > tolerance:
                world_mismatch = True
        score_mismatches += world_mismatch
        full_winner = min(
            full_scores,
            key=lambda candidate: (-full_scores[candidate], str(candidate)),
        )
        local_winner = min(
            local_scores,
            key=lambda candidate: (-local_scores[candidate], str(candidate)),
        )
        winner_mismatches += full_winner != local_winner
    return ScopeEquivalenceResult(
        checked_worlds=len(full_states),
        checked_scores=checked_scores,
        score_mismatch_worlds=score_mismatches,
        winner_mismatch_worlds=winner_mismatches,
        maximum_absolute_error=maximum_error,
        tolerance=tolerance,
        exact=score_mismatches == 0 and winner_mismatches == 0,
    )
