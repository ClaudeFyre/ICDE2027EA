"""Small dependency-free command line entrypoint for repository checks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.10 compatibility.
    import tomli as tomllib

from pkgea.audit import audit_headerless_quads
from pkgea.audit_nl27k import audit_nl27k_replicas
from pkgea.audit_dbp15k import audit_dbp15k
from pkgea.benchmark_report import summarize_benchmark
from pkgea.contracts import validate_dataset
from pkgea.diagnostics import run_toy_diagnostic
from pkgea.data import (
    convert_openea,
    convert_jape_dbp15k,
    map_heuristic_confidences,
    mask_cross_graph_entity_labels,
    convert_scored_ukg_to_views,
    extract_aligned_probe,
)
from pkgea.generators import (
    BenchmarkGeneratorConfig,
    generate_benchmark,
    write_benchmark_preset_manifest,
)
from pkgea.worlds import enumerate_independent_worlds
from pkgea.wsdm import run_toy_adaptive_sampling
from pkgea.www import (
    run_hidden_representation_validation,
    run_real_distributional_validation,
    run_toy_moment_validation,
    run_toy_multilayer_validation,
)
from pkgea.icde import (
    run_batch_queries,
    run_distributional_queries,
    run_planned_batch_queries,
    run_query_operator_comparison,
    run_toy_query,
)
from pkgea.query import (
    benchmark_mmap_concurrency,
    benchmark_score_cache_formats,
    build_mmap_autotune_policy,
    tune_mmap_source_batch,
)
from pkgea.extensions import (
    run_hop_invalidation_audit,
    run_snapshot_isolation_audit,
    run_streaming_batch_toy,
    run_streaming_query_trace,
    run_streaming_trace,
    run_streaming_toy,
    run_trustworthy_demo,
    run_trustworthy_real_validation,
)
from pkgea.trustworthy_lowrank import run_lowrank_conformal_validation
from pkgea.experiments import (
    diagnose_deterministic_baselines,
    run_budget_curve,
    run_multi_seed_budget_curve,
    run_external_adapter_smoke,
    run_external_backbone_crn,
    run_experiment_matrix,
    run_formal_backbone_crn,
    run_label_propagation_smoke,
    run_paired_backbone_comparison,
    run_sampler_comparison,
    run_translation_smoke,
)


EXPECTED_NODES = (
    "00_audit",
    "01_benchmark",
    "02_sampling_diagnosis",
    "03_wsdm",
    "04_www_distributional",
    "05_icde_query_engine",
    "06_streaming",
    "07_trustworthy",
)

ALLOWED_NODE_STATUSES = {"not_started", "in_progress", "blocked", "completed"}


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def check_layout(root: Path | None = None) -> dict[str, object]:
    root = (root or project_root()).resolve()
    required_paths = [
        root / "ROADMAP.md",
        root / "docs" / "data_contract.md",
        root / "data" / "toy" / "exact_world_minimal",
        *(root / "nodes" / node / "status.toml" for node in EXPECTED_NODES),
        *(root / "nodes" / node / "README.md" for node in EXPECTED_NODES),
    ]
    missing = [str(path.relative_to(root)) for path in required_paths if not path.exists()]
    errors: list[str] = []
    node_records: dict[str, dict[str, object]] = {}

    if not missing:
        for node in EXPECTED_NODES:
            status_path = root / "nodes" / node / "status.toml"
            with status_path.open("rb") as handle:
                record = tomllib.load(handle)
            node_records[node] = record
            if record.get("id") != node:
                errors.append(f"{node}/status.toml has mismatched id")
            if record.get("status") not in ALLOWED_NODE_STATUSES:
                errors.append(f"{node}/status.toml has unsupported status")

        for node, record in node_records.items():
            dependencies = record.get("depends_on", [])
            if not isinstance(dependencies, list):
                errors.append(f"{node}/status.toml depends_on must be a list")
                continue
            for dependency in dependencies:
                if dependency not in node_records:
                    errors.append(f"{node} depends on unknown node: {dependency}")

    return {
        "root": str(root),
        "ok": not missing and not errors,
        "missing": missing,
        "errors": errors,
        "node_statuses": {
            node: record.get("status") for node, record in node_records.items()
        },
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pkgea")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("check-layout", help="check node and documentation layout")

    validate = subparsers.add_parser(
        "validate-dataset", help="validate a canonical PKG-EA dataset directory"
    )
    validate.add_argument("dataset_dir", type=Path)

    enumerate_parser = subparsers.add_parser(
        "enumerate-worlds", help="enumerate a small independent-edge dataset"
    )
    enumerate_parser.add_argument("dataset_dir", type=Path)
    enumerate_parser.add_argument("--max-uncertain-edges", type=int, default=20)

    audit = subparsers.add_parser(
        "audit-quads", help="audit headerless head/relation/tail/confidence TSV files"
    )
    audit.add_argument("dataset_dir", type=Path)
    audit.add_argument(
        "--files",
        nargs="+",
        default=["train.tsv", "val.tsv", "test.tsv"],
        help="filenames relative to dataset_dir",
    )

    nl27k_audit = subparsers.add_parser(
        "audit-nl27k-replicas",
        help="compare UKGE, unKR, and BEUrRE NL27K relation vocabularies",
    )
    nl27k_audit.add_argument("ukge_dir", type=Path)
    nl27k_audit.add_argument("unkr_dir", type=Path)
    nl27k_audit.add_argument("beurre_dir", type=Path)
    nl27k_audit.add_argument("--output", type=Path)

    dbp15k_audit = subparsers.add_parser(
        "audit-dbp15k",
        help="audit JAPE DBP15K full and popularity-filtered releases",
    )
    dbp15k_audit.add_argument("dataset_dir", type=Path)
    dbp15k_audit.add_argument("--split", default="0_3")
    dbp15k_audit.add_argument("--archive", type=Path)
    dbp15k_audit.add_argument("--output", type=Path)

    jape_convert = subparsers.add_parser(
        "convert-jape-dbp15k",
        help="convert one JAPE DBP15K language pair",
    )
    jape_convert.add_argument("input_dir", type=Path)
    jape_convert.add_argument("output_dir", type=Path)
    jape_convert.add_argument("--split", default="0_3")
    jape_convert.add_argument("--archive-sha256", default="")

    generate = subparsers.add_parser(
        "generate-benchmark", help="inject a reproducible uncertainty mechanism"
    )
    generate.add_argument("base_dataset_dir", type=Path)
    generate.add_argument("output_dir", type=Path)
    generate.add_argument("--mechanism", choices=sorted({
        "independent",
        "structural_correlated",
        "cross_kg_correlated",
        "calibration_distortion",
    }), required=True)
    generate.add_argument("--seed", type=int, default=17)
    generate.add_argument("--beta-alpha", type=float, default=2.0)
    generate.add_argument("--beta-beta", type=float, default=2.0)
    generate.add_argument("--shared-strength", type=float, default=0.7)
    generate.add_argument("--missingness-rate", type=float, default=0.0)
    generate.add_argument(
        "--distortion",
        choices=("overconfidence", "underconfidence"),
        default="overconfidence",
    )
    generate.add_argument("--temperature", type=float, default=0.5)
    generate.add_argument("--seed-ratio", type=float)
    generate.add_argument("--validation-ratio", type=float, default=0.1)

    presets = subparsers.add_parser(
        "benchmark-presets",
        help="write the frozen entropy/missingness/correlation/seed-ratio matrix",
    )
    presets.add_argument("output", type=Path)

    diagnose = subparsers.add_parser(
        "diagnose-toy", help="compare S0, S1, S3, and S5 on a small dataset"
    )
    diagnose.add_argument("dataset_dir", type=Path)
    diagnose.add_argument("--samples", type=int, default=256)
    diagnose.add_argument("--seed", type=int, default=17)

    adaptive = subparsers.add_parser(
        "adaptive-toy", help="run the WSDM budgeted local sampler prototype"
    )
    adaptive.add_argument("dataset_dir", type=Path)
    adaptive.add_argument("--budget", type=int, default=192)
    adaptive.add_argument("--seed", type=int, default=17)
    adaptive.add_argument(
        "--backbone", choices=("toy", "attribute"), default="toy"
    )
    adaptive.add_argument(
        "--split", choices=("train", "validation", "test")
    )
    adaptive.add_argument("--candidate-top-k", type=int)
    adaptive.add_argument("--output", type=Path)

    moments = subparsers.add_parser(
        "moments-toy", help="validate WWW analytic moments against S0"
    )
    moments.add_argument("dataset_dir", type=Path)

    multilayer = subparsers.add_parser(
        "moments-multilayer-toy",
        help="validate two nonlinear moment-matching layers against S0",
    )
    multilayer.add_argument("dataset_dir", type=Path)

    real_moments = subparsers.add_parser(
        "moments-real",
        help="compare analytic entity moments/matching with high-budget MC",
    )
    real_moments.add_argument("dataset_dir", type=Path)
    real_moments.add_argument("--samples", type=int, default=4096)
    real_moments.add_argument("--seed", type=int, default=17)
    real_moments.add_argument("--output", type=Path)

    hidden_moments = subparsers.add_parser(
        "hidden-moments-real",
        help="validate relation/attribute hidden moments across ReLU depth",
    )
    hidden_moments.add_argument("dataset_dir", type=Path)
    hidden_moments.add_argument("--samples", type=int, default=2048)
    hidden_moments.add_argument("--seed", type=int, default=17)
    hidden_moments.add_argument("--dimension", type=int, default=16)
    hidden_moments.add_argument("--depth", type=int, default=3)
    hidden_moments.add_argument("--output", type=Path)

    query = subparsers.add_parser(
        "query-toy", help="run the ICDE progressive top-k prototype"
    )
    query.add_argument("dataset_dir", type=Path)
    query.add_argument("--source", required=True)
    query.add_argument("--k", type=int, default=1)
    query.add_argument("--budget", type=int, default=256)
    query.add_argument("--seed", type=int, default=17)

    batch_query = subparsers.add_parser(
        "query-batch", help="run batch top-k queries with a persistent world cache"
    )
    batch_query.add_argument("dataset_dir", type=Path)
    batch_query.add_argument("--sources", nargs="+", required=True)
    batch_query.add_argument("--k", type=int, default=1)
    batch_query.add_argument("--budget", type=int, default=256)
    batch_query.add_argument("--seed", type=int, default=17)
    batch_query.add_argument(
        "--backbone", choices=("toy", "attribute"), default="toy"
    )
    batch_query.add_argument("--cache", type=Path)
    batch_query.add_argument("--score-cache", type=Path)
    batch_query.add_argument(
        "--bound-method",
        choices=(
            "hoeffding",
            "empirical_bernstein",
            "paired_empirical_bernstein",
        ),
        default="hoeffding",
    )
    batch_query.add_argument("--output", type=Path)

    distributional_query = subparsers.add_parser(
        "query-distributional",
        help="execute analytic distribution-distance batch top-k",
    )
    distributional_query.add_argument("dataset_dir", type=Path)
    distributional_query.add_argument("--sources", nargs="+", required=True)
    distributional_query.add_argument("--k", type=int, default=1)
    distributional_query.add_argument("--output", type=Path)

    planned_query = subparsers.add_parser(
        "query-planned",
        help="plan and execute distributional or adaptive batch top-k",
    )
    planned_query.add_argument("dataset_dir", type=Path)
    planned_query.add_argument("--sources", nargs="+", required=True)
    planned_query.add_argument("--k", type=int, default=1)
    planned_query.add_argument("--budget", type=int, default=256)
    planned_query.add_argument("--seed", type=int, default=17)
    planned_query.add_argument(
        "--backbone", choices=("toy", "attribute"), default="attribute"
    )
    planned_query.add_argument("--target-error", type=float, default=0.1)
    planned_query.add_argument("--latency-budget", type=float)
    planned_query.add_argument(
        "--distributional-validation-error", type=float
    )
    planned_query.add_argument(
        "--distributional-operator",
        choices=("degree_diagonal", "learned_low_rank"),
        default="degree_diagonal",
    )
    planned_query.add_argument("--distributional-artifact", type=Path)
    planned_query.add_argument(
        "--bound-method",
        choices=(
            "hoeffding",
            "empirical_bernstein",
            "paired_empirical_bernstein",
        ),
        default="hoeffding",
    )
    planned_query.add_argument("--output", type=Path)

    operator_comparison = subparsers.add_parser(
        "query-operator-comparison",
        help="compare distributional and adaptive sampling on one batch",
    )
    operator_comparison.add_argument("dataset_dir", type=Path)
    operator_comparison.add_argument("--sources", nargs="+", required=True)
    operator_comparison.add_argument("--k", type=int, default=1)
    operator_comparison.add_argument("--budget", type=int, default=256)
    operator_comparison.add_argument("--seed", type=int, default=17)
    operator_comparison.add_argument(
        "--backbone", choices=("toy", "attribute"), default="attribute"
    )
    operator_comparison.add_argument("--output", type=Path)

    stream = subparsers.add_parser(
        "stream-toy", help="incrementally update one edge probability"
    )
    stream.add_argument("dataset_dir", type=Path)
    stream.add_argument("--edge-index", type=int, required=True)
    stream.add_argument("--probability", type=float, required=True)

    stream_batch = subparsers.add_parser(
        "stream-batch-toy", help="apply update/add/delete fact events"
    )
    stream_batch.add_argument("dataset_dir", type=Path)

    stream_trace = subparsers.add_parser(
        "stream-trace",
        help="benchmark a timestamped update trace against full rebuilding",
    )
    stream_trace.add_argument("dataset_dir", type=Path)
    stream_trace.add_argument("--events", type=int, default=128)
    stream_trace.add_argument("--seed", type=int, default=17)
    stream_trace.add_argument("--allowed-lateness", type=float, default=6.0)
    stream_trace.add_argument("--retention-window", type=float, default=64.0)
    stream_trace.add_argument("--output", type=Path)

    stream_query = subparsers.add_parser(
        "stream-query-trace",
        help="measure version-safe score-cache updates and stale-read rejection",
    )
    stream_query.add_argument("dataset_dir", type=Path)
    stream_query.add_argument("--events", type=int, default=24)
    stream_query.add_argument("--world-budget", type=int, default=64)
    stream_query.add_argument("--seed", type=int, default=17)
    stream_query.add_argument("--propagation-depth", type=int, default=1)
    stream_query.add_argument("--normalization-hops", type=int, default=0)
    stream_query.add_argument("--output", type=Path)

    stream_hop = subparsers.add_parser(
        "stream-hop-audit",
        help="audit query-cache invalidations across propagation depths",
    )
    stream_hop.add_argument("dataset_dir", type=Path)
    stream_hop.add_argument("--max-depth", type=int, default=4)
    stream_hop.add_argument("--normalization-hops", type=int, default=0)
    stream_hop.add_argument("--output", type=Path)

    stream_snapshot = subparsers.add_parser(
        "stream-snapshot-audit",
        help="stress concurrent immutable read snapshots and stream writes",
    )
    stream_snapshot.add_argument("--updates", type=int, default=1000)
    stream_snapshot.add_argument("--readers", type=int, default=4)
    stream_snapshot.add_argument("--output", type=Path)

    subparsers.add_parser(
        "trustworthy-demo", help="run calibration and conformal-set primitives"
    )
    trustworthy_real = subparsers.add_parser(
        "trustworthy-real",
        help="audit real-probe calibration and conformal coverage under shift",
    )
    trustworthy_real.add_argument("dataset_dir", type=Path)
    trustworthy_real.add_argument("shifted_dataset_dir", type=Path)
    trustworthy_real.add_argument("--alpha", type=float, default=0.1)
    trustworthy_real.add_argument("--seed", type=int, default=17)
    trustworthy_real.add_argument("--repeats", type=int, default=25)
    trustworthy_real.add_argument("--output", type=Path)

    trustworthy_lowrank = subparsers.add_parser(
        "trustworthy-lowrank",
        help="calibrate conformal sets on a learned low-rank query artifact",
    )
    trustworthy_lowrank.add_argument("dataset_dir", type=Path)
    trustworthy_lowrank.add_argument("artifact", type=Path)
    trustworthy_lowrank.add_argument("--alpha", type=float, default=0.1)
    trustworthy_lowrank.add_argument("--seed", type=int, default=17)
    trustworthy_lowrank.add_argument("--repeats", type=int, default=25)
    trustworthy_lowrank.add_argument("--output", type=Path)

    convert = subparsers.add_parser(
        "convert-openea", help="convert one OpenEA graph pair to the canonical contract"
    )
    convert.add_argument("input_dir", type=Path)
    convert.add_argument("output_dir", type=Path)
    convert.add_argument("--fold", type=int, default=1)
    convert.add_argument("--archive-sha512", default="")

    ukg_views = subparsers.add_parser(
        "convert-ukg-views",
        help="construct two scored evidence views from a headerless UKG",
    )
    ukg_views.add_argument("input_dir", type=Path)
    ukg_views.add_argument("output_dir", type=Path)
    ukg_views.add_argument("--entity-map", required=True)
    ukg_views.add_argument("--relation-map", required=True)
    ukg_views.add_argument("--dataset-id", required=True)
    ukg_views.add_argument("--seed", type=int, default=17)
    ukg_views.add_argument("--source-retention", type=float, default=0.8)
    ukg_views.add_argument("--target-retention", type=float, default=0.8)
    ukg_views.add_argument("--train-ratio", type=float, default=0.2)
    ukg_views.add_argument("--validation-ratio", type=float, default=0.1)

    summarize = subparsers.add_parser(
        "summarize-benchmark",
        help="summarize latent truth, distortion, entropy, and dependency groups",
    )
    summarize.add_argument("dataset_dir", type=Path)

    map_heuristic = subparsers.add_parser(
        "map-heuristic-confidence",
        help="map heuristic scores to assumed probabilities for sensitivity",
    )
    map_heuristic.add_argument("input_dir", type=Path)
    map_heuristic.add_argument("output_dir", type=Path)
    map_heuristic.add_argument("--temperature", type=float, required=True)

    mask_labels = subparsers.add_parser(
        "mask-cross-graph-labels",
        help="replace cross-graph entity labels with independent opaque ids",
    )
    mask_labels.add_argument("input_dir", type=Path)
    mask_labels.add_argument("output_dir", type=Path)

    probe = subparsers.add_parser(
        "extract-probe", help="extract bounded incident neighborhoods for aligned pairs"
    )
    probe.add_argument("input_dir", type=Path)
    probe.add_argument("output_dir", type=Path)
    probe.add_argument("--pairs", type=int, default=32)
    probe.add_argument("--max-edges-per-graph", type=int, default=128)
    probe.add_argument("--split", choices=("train", "validation", "test"), default="test")
    probe.add_argument("--anchors", type=int, default=0)
    probe.add_argument(
        "--anchor-split",
        choices=("train", "validation", "test"),
        default="train",
    )
    probe.add_argument(
        "--anchor-selection",
        choices=("random", "nearest_joint"),
        default="random",
    )
    probe.add_argument("--connection-hops", type=int, default=4)
    probe.add_argument("--seed", type=int, default=17)

    curve = subparsers.add_parser(
        "budget-curve", help="run an adaptive-sampling budget curve"
    )
    curve.add_argument("dataset_dir", type=Path)
    curve.add_argument("--budgets", nargs="+", type=int, required=True)
    curve.add_argument("--seed", type=int, default=17)
    curve.add_argument(
        "--backbone", choices=("toy", "attribute"), default="attribute"
    )
    curve.add_argument("--output", type=Path)
    curve.add_argument(
        "--split",
        choices=("train", "validation", "test"),
    )

    multi_curve = subparsers.add_parser(
        "multi-seed-budget-curve",
        help="run replicated adaptive-sampling curves with stability intervals",
    )
    multi_curve.add_argument("dataset_dir", type=Path)
    multi_curve.add_argument("--budgets", nargs="+", type=int, required=True)
    multi_curve.add_argument("--seeds", nargs="+", type=int, required=True)
    multi_curve.add_argument(
        "--backbone", choices=("toy", "attribute"), default="attribute"
    )
    multi_curve.add_argument("--no-early-stopping", action="store_true")
    multi_curve.add_argument("--output", type=Path)
    multi_curve.add_argument(
        "--split",
        choices=("train", "validation", "test"),
    )

    baseline_diagnosis = subparsers.add_parser(
        "baseline-diagnosis",
        help="compare deterministic approximations and rank edge variance proxies",
    )
    baseline_diagnosis.add_argument("dataset_dir", type=Path)
    baseline_diagnosis.add_argument("reference_path", type=Path)
    baseline_diagnosis.add_argument(
        "--backbone", choices=("toy", "attribute"), default="attribute"
    )
    baseline_diagnosis.add_argument("--top-edges", type=int, default=20)
    baseline_diagnosis.add_argument("--output", type=Path)

    sampler_comparison = subparsers.add_parser(
        "sampler-comparison",
        help="compare S1, S3, and S5 under equal edge-draw budgets",
    )
    sampler_comparison.add_argument("dataset_dir", type=Path)
    sampler_comparison.add_argument("reference_path", type=Path)
    sampler_comparison.add_argument("--samples", type=int, required=True)
    sampler_comparison.add_argument("--seeds", nargs="+", type=int, required=True)
    sampler_comparison.add_argument("--representatives", type=int, default=32)
    sampler_comparison.add_argument(
        "--backbone", choices=("toy", "attribute"), default="attribute"
    )
    sampler_comparison.add_argument("--output", type=Path)

    paired_backbone = subparsers.add_parser(
        "paired-backbone-comparison",
        help="compare toy and attribute backbones with shared possible worlds",
    )
    paired_backbone.add_argument("dataset_dir", type=Path)
    paired_backbone.add_argument("--samples", type=int, required=True)
    paired_backbone.add_argument("--seeds", nargs="+", type=int, required=True)
    paired_backbone.add_argument("--output", type=Path)

    formal_crn = subparsers.add_parser(
        "formal-backbone-crn",
        help="compare formal propagation and attribute backbones on shared worlds",
    )
    formal_crn.add_argument("dataset_dir", type=Path)
    formal_crn.add_argument("--samples", type=int, default=64)
    formal_crn.add_argument("--seed", type=int, default=17)
    formal_crn.add_argument("--split", default="test")
    formal_crn.add_argument("--output", type=Path)

    adapter_smoke = subparsers.add_parser(
        "adapter-smoke",
        help="validate an external checkpoint descriptor on two possible worlds",
    )
    adapter_smoke.add_argument("dataset_dir", type=Path)
    adapter_smoke.add_argument("descriptor", type=Path)
    adapter_smoke.add_argument("--output", type=Path)

    external_crn = subparsers.add_parser(
        "external-backbone-crn",
        help="batch-score an external checkpoint on shared possible worlds",
    )
    external_crn.add_argument("dataset_dir", type=Path)
    external_crn.add_argument("descriptor", type=Path)
    external_crn.add_argument("--samples", type=int, default=64)
    external_crn.add_argument("--seed", type=int, default=17)
    external_crn.add_argument("--split", default="test")
    external_crn.add_argument("--output", type=Path)

    label_smoke = subparsers.add_parser(
        "label-propagation-smoke",
        help="evaluate the seeded multi-view label-propagation backbone",
    )
    label_smoke.add_argument("dataset_dir", type=Path)
    label_smoke.add_argument("--output", type=Path)

    translation_smoke = subparsers.add_parser(
        "translation-smoke",
        help="run the project relation-translation backbone smoke test",
    )
    translation_smoke.add_argument("dataset_dir", type=Path)
    translation_smoke.add_argument("--margin-epochs", type=int, default=0)
    translation_smoke.add_argument("--margin", type=float, default=0.2)
    translation_smoke.add_argument("--learning-rate", type=float, default=0.05)
    translation_smoke.add_argument("--seed", type=int, default=17)
    translation_smoke.add_argument("--output", type=Path)

    experiment_matrix = subparsers.add_parser(
        "experiment-matrix",
        help="run a manifest-defined resumable backbone/profile/seed matrix",
    )
    experiment_matrix.add_argument("manifest", type=Path)
    experiment_matrix.add_argument(
        "--no-resume", action="store_true", help="reject existing task artifacts"
    )

    mmap_scores = subparsers.add_parser(
        "score-cache-mmap",
        help="convert a gzip JSON score cache to a memory-mapped float32 index",
    )
    mmap_scores.add_argument("score_cache", type=Path)
    mmap_scores.add_argument("output_dir", type=Path)
    mmap_scores.add_argument("--repeats", type=int, default=5)

    mmap_throughput = subparsers.add_parser(
        "score-mmap-throughput",
        help="benchmark warm concurrent memory-mapped rectangle reads",
    )
    mmap_throughput.add_argument("mmap_dir", type=Path)
    mmap_throughput.add_argument("--queries", type=int, default=512)
    mmap_throughput.add_argument("--repeats", type=int, default=5)
    mmap_throughput.add_argument("--output", type=Path)

    mmap_autotune = subparsers.add_parser(
        "score-mmap-autotune",
        help="calibrate source micro-batching for one mmap rectangle shape",
    )
    mmap_autotune.add_argument("mmap_dir", type=Path)
    mmap_autotune.add_argument("--world-count", type=int, required=True)
    mmap_autotune.add_argument("--queries", type=int, default=256)
    mmap_autotune.add_argument("--repeats", type=int, default=3)
    mmap_autotune.add_argument(
        "--batch-sizes", type=int, nargs="+", default=[1, 2, 4, 8, 16, 32]
    )
    mmap_autotune.add_argument("--output", type=Path)

    mmap_policy = subparsers.add_parser(
        "score-mmap-policy",
        help="build a revision-bound mmap source-batch policy cache",
    )
    mmap_policy.add_argument("mmap_directory", type=Path)
    mmap_policy.add_argument("tuning_artifacts", nargs="+", type=Path)
    mmap_policy.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "check-layout":
            result = check_layout()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result["ok"] else 1
        if args.command == "validate-dataset":
            result = validate_dataset(args.dataset_dir).as_dict()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "enumerate-worlds":
            result = enumerate_independent_worlds(
                args.dataset_dir, args.max_uncertain_edges
            ).as_dict()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "audit-quads":
            result = audit_headerless_quads(args.dataset_dir, args.files).as_dict()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "audit-nl27k-replicas":
            result = audit_nl27k_replicas(
                args.ukge_dir,
                args.unkr_dir,
                args.beurre_dir,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "audit-dbp15k":
            result = audit_dbp15k(
                args.dataset_dir,
                split_name=args.split,
                archive_path=args.archive,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "convert-jape-dbp15k":
            output = convert_jape_dbp15k(
                args.input_dir,
                args.output_dir,
                split_name=args.split,
                source_archive_sha256=args.archive_sha256,
            )
            print(
                json.dumps(
                    {"ok": True, "output_dir": str(output)},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        if args.command == "generate-benchmark":
            config = BenchmarkGeneratorConfig(
                mechanism=args.mechanism,
                seed=args.seed,
                beta_alpha=args.beta_alpha,
                beta_beta=args.beta_beta,
                shared_strength=args.shared_strength,
                missingness_rate=args.missingness_rate,
                distortion=args.distortion,
                temperature=args.temperature,
                seed_ratio=args.seed_ratio,
                validation_ratio=args.validation_ratio,
            )
            output = generate_benchmark(
                args.base_dataset_dir, args.output_dir, config
            )
            print(
                json.dumps(
                    {"ok": True, "output_dir": str(output), "config": vars(args)},
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return 0
        if args.command == "benchmark-presets":
            output = write_benchmark_preset_manifest(args.output)
            print(
                json.dumps(
                    {"ok": True, "output": str(output)},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        if args.command == "diagnose-toy":
            result = run_toy_diagnostic(
                args.dataset_dir, sample_count=args.samples, seed=args.seed
            ).as_dict()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "adaptive-toy":
            result = run_toy_adaptive_sampling(
                args.dataset_dir,
                total_budget=args.budget,
                seed=args.seed,
                backbone_name=args.backbone,
                evaluation_split=args.split,
                candidate_top_k=args.candidate_top_k,
                measure_latency=True,
            )
            if args.output is not None:
                output = args.output.resolve()
                if output.exists():
                    raise ValueError(
                        f"Output already exists; refusing to overwrite: {output}"
                    )
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(
                    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8",
                )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "moments-toy":
            result = run_toy_moment_validation(args.dataset_dir)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "moments-multilayer-toy":
            result = run_toy_multilayer_validation(args.dataset_dir)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "moments-real":
            result = run_real_distributional_validation(
                args.dataset_dir,
                sample_count=args.samples,
                seed=args.seed,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "hidden-moments-real":
            result = run_hidden_representation_validation(
                args.dataset_dir,
                sample_count=args.samples,
                seed=args.seed,
                dimension=args.dimension,
                depth=args.depth,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "query-toy":
            result = run_toy_query(
                args.dataset_dir,
                args.source,
                k=args.k,
                max_samples=args.budget,
                seed=args.seed,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "query-batch":
            result = run_batch_queries(
                args.dataset_dir,
                args.sources,
                k=args.k,
                max_samples=args.budget,
                seed=args.seed,
                backbone_name=args.backbone,
                cache_path=args.cache,
                score_cache_path=args.score_cache,
                bound_method=args.bound_method,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "query-distributional":
            result = run_distributional_queries(
                args.dataset_dir,
                args.sources,
                k=args.k,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "query-planned":
            result = run_planned_batch_queries(
                args.dataset_dir,
                args.sources,
                k=args.k,
                max_samples=args.budget,
                seed=args.seed,
                backbone_name=args.backbone,
                target_absolute_error=args.target_error,
                latency_budget=args.latency_budget,
                distributional_validation_error=(
                    args.distributional_validation_error
                ),
                distributional_operator=args.distributional_operator,
                distributional_artifact=args.distributional_artifact,
                bound_method=args.bound_method,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "query-operator-comparison":
            result = run_query_operator_comparison(
                args.dataset_dir,
                args.sources,
                k=args.k,
                max_samples=args.budget,
                seed=args.seed,
                backbone_name=args.backbone,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "stream-toy":
            result = run_streaming_toy(
                args.dataset_dir, args.edge_index, args.probability
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "stream-batch-toy":
            result = run_streaming_batch_toy(args.dataset_dir)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "stream-trace":
            result = run_streaming_trace(
                args.dataset_dir,
                event_count=args.events,
                seed=args.seed,
                allowed_lateness=args.allowed_lateness,
                retention_window=args.retention_window,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "stream-query-trace":
            result = run_streaming_query_trace(
                args.dataset_dir,
                event_count=args.events,
                world_budget=args.world_budget,
                seed=args.seed,
                propagation_depth=args.propagation_depth,
                normalization_hops=args.normalization_hops,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "stream-hop-audit":
            result = run_hop_invalidation_audit(
                args.dataset_dir,
                max_depth=args.max_depth,
                normalization_hops=args.normalization_hops,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "stream-snapshot-audit":
            result = run_snapshot_isolation_audit(
                update_count=args.updates,
                reader_count=args.readers,
            )
            if args.output is not None:
                output = args.output.resolve()
                if output.exists():
                    raise ValueError(
                        f"Output already exists; refusing to overwrite: {output}"
                    )
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(
                    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8",
                )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "trustworthy-demo":
            print(
                json.dumps(
                    run_trustworthy_demo(), ensure_ascii=False, indent=2
                )
            )
            return 0
        if args.command == "trustworthy-real":
            result = run_trustworthy_real_validation(
                args.dataset_dir,
                args.shifted_dataset_dir,
                alpha=args.alpha,
                seed=args.seed,
                repeat_count=args.repeats,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "trustworthy-lowrank":
            result = run_lowrank_conformal_validation(
                args.dataset_dir,
                args.artifact,
                alpha=args.alpha,
                seed=args.seed,
                repeat_count=args.repeats,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "convert-openea":
            output = convert_openea(
                args.input_dir,
                args.output_dir,
                fold=args.fold,
                source_archive_sha512=args.archive_sha512,
            )
            print(
                json.dumps(
                    {"ok": True, "output_dir": str(output)},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        if args.command == "convert-ukg-views":
            output = convert_scored_ukg_to_views(
                args.input_dir,
                args.output_dir,
                entity_map_name=args.entity_map,
                relation_map_name=args.relation_map,
                dataset_id=args.dataset_id,
                seed=args.seed,
                source_retention=args.source_retention,
                target_retention=args.target_retention,
                train_ratio=args.train_ratio,
                validation_ratio=args.validation_ratio,
            )
            print(
                json.dumps(
                    {"ok": True, "output_dir": str(output)},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        if args.command == "summarize-benchmark":
            result = summarize_benchmark(args.dataset_dir).as_dict()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "map-heuristic-confidence":
            output = map_heuristic_confidences(
                args.input_dir,
                args.output_dir,
                temperature=args.temperature,
            )
            print(
                json.dumps(
                    {"ok": True, "output_dir": str(output)},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        if args.command == "mask-cross-graph-labels":
            output = mask_cross_graph_entity_labels(
                args.input_dir,
                args.output_dir,
            )
            print(
                json.dumps(
                    {"ok": True, "output_dir": str(output)},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        if args.command == "extract-probe":
            output = extract_aligned_probe(
                args.input_dir,
                args.output_dir,
                pair_count=args.pairs,
                max_edges_per_graph=args.max_edges_per_graph,
                split=args.split,
                anchor_count=args.anchors,
                anchor_split=args.anchor_split,
                anchor_selection=args.anchor_selection,
                connection_hops=args.connection_hops,
                seed=args.seed,
            )
            print(
                json.dumps(
                    {"ok": True, "output_dir": str(output)},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        if args.command == "budget-curve":
            result = run_budget_curve(
                args.dataset_dir,
                args.budgets,
                seed=args.seed,
                backbone_name=args.backbone,
                evaluation_split=args.split,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "multi-seed-budget-curve":
            result = run_multi_seed_budget_curve(
                args.dataset_dir,
                args.budgets,
                args.seeds,
                backbone_name=args.backbone,
                early_stopping=not args.no_early_stopping,
                evaluation_split=args.split,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "baseline-diagnosis":
            result = diagnose_deterministic_baselines(
                args.dataset_dir,
                args.reference_path,
                backbone_name=args.backbone,
                top_edge_count=args.top_edges,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "sampler-comparison":
            result = run_sampler_comparison(
                args.dataset_dir,
                args.reference_path,
                sample_count=args.samples,
                seeds=args.seeds,
                representative_count=args.representatives,
                backbone_name=args.backbone,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "paired-backbone-comparison":
            result = run_paired_backbone_comparison(
                args.dataset_dir,
                sample_count=args.samples,
                seeds=args.seeds,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "formal-backbone-crn":
            result = run_formal_backbone_crn(
                args.dataset_dir,
                sample_count=args.samples,
                seed=args.seed,
                split=args.split,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "adapter-smoke":
            result = run_external_adapter_smoke(
                args.dataset_dir,
                args.descriptor,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "external-backbone-crn":
            result = run_external_backbone_crn(
                args.dataset_dir,
                args.descriptor,
                sample_count=args.samples,
                seed=args.seed,
                split=args.split,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "label-propagation-smoke":
            result = run_label_propagation_smoke(
                args.dataset_dir,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "translation-smoke":
            result = run_translation_smoke(
                args.dataset_dir,
                margin_epochs=args.margin_epochs,
                margin=args.margin,
                learning_rate=args.learning_rate,
                seed=args.seed,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "experiment-matrix":
            result = run_experiment_matrix(
                args.manifest,
                resume=not args.no_resume,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "score-cache-mmap":
            result = benchmark_score_cache_formats(
                args.score_cache,
                args.output_dir,
                repeats=args.repeats,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "score-mmap-throughput":
            result = benchmark_mmap_concurrency(
                args.mmap_dir,
                query_count=args.queries,
                repeats=args.repeats,
            )
            if args.output is not None:
                output = args.output.resolve()
                if output.exists():
                    raise ValueError(
                        f"Output already exists; refusing to overwrite: {output}"
                    )
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(
                    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8",
                )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "score-mmap-autotune":
            result = tune_mmap_source_batch(
                args.mmap_dir,
                world_count=args.world_count,
                batch_sizes=args.batch_sizes,
                calibration_queries=args.queries,
                repeats=args.repeats,
            )
            if args.output is not None:
                output = args.output.resolve()
                if output.exists():
                    raise ValueError(
                        f"Output already exists; refusing to overwrite: {output}"
                    )
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(
                    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8",
                )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "score-mmap-policy":
            result = build_mmap_autotune_policy(
                args.mmap_directory,
                args.tuning_artifacts,
                output_path=args.output,
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2
    raise AssertionError(f"Unhandled command: {args.command}")
