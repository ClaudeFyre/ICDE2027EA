"""ICDE progressive-query prototype over the canonical toy dataset."""

from __future__ import annotations

import csv
import hashlib
import json
import time
from pathlib import Path

from pkgea.backbones import AttributeStructuralBackbone, ToyStructuralBackbone
from pkgea.contracts import dataset_revision_digest
from pkgea.query import (
    DistributionalDegreeIndex,
    LearnedLowRankCovarianceIndex,
    QueryWorkload,
    ScoreCache,
    StaticCandidateIndex,
    WorldCache,
    choose_execution_plan,
    progressive_top_k,
    progressive_top_k_from_scores,
)


def _artifact_context_digest(root: Path, backbone_name: str) -> str:
    """Bind cached scores to exact graph, probability, attribute, and code scope."""

    digest = hashlib.sha256()
    digest.update(b"pkgea-score-context-v2\0")
    digest.update(backbone_name.encode("utf-8"))
    for filename in (
        "entities.tsv",
        "relations.tsv",
        "triples.tsv",
        "alignments.tsv",
        "attributes.tsv",
        "confidence_metadata.json",
    ):
        path = root / filename
        if not path.is_file():
            continue
        digest.update(b"\0")
        digest.update(filename.encode("utf-8"))
        digest.update(b"\0")
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    return digest.hexdigest()


def run_toy_query(
    dataset_dir: str | Path,
    source: str,
    *,
    k: int = 1,
    max_samples: int = 256,
    seed: int = 17,
) -> dict[str, object]:
    root = Path(dataset_dir).resolve()
    backbone = ToyStructuralBackbone.from_dataset(root)
    if source not in backbone.source_entities:
        raise ValueError(f"Unknown source entity: {source}")
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    cache = WorldCache()
    result = progressive_top_k(
        probabilities,
        backbone.score,
        source,
        backbone.target_entities,
        k=k,
        max_samples=max_samples,
        batch_size=16,
        delta=0.05,
        seed=seed,
        dependency_groups=groups,
        cache=cache,
    )
    entropy_terms = [
        -(p * math_log2(p) + (1.0 - p) * math_log2(1.0 - p))
        for p in probabilities
    ]
    workload = QueryWorkload(
        uncertain_edges=len(probabilities),
        candidate_count=len(backbone.target_entities),
        normalized_entropy=sum(entropy_terms) / len(entropy_terms),
        latency_budget=float(max_samples * len(probabilities)),
        target_absolute_error=0.1,
    )
    return {
        "query": result.as_dict(),
        "plan": choose_execution_plan(workload).as_dict(),
    }


def run_batch_queries(
    dataset_dir: str | Path,
    sources: list[str],
    *,
    k: int = 1,
    max_samples: int = 256,
    seed: int = 17,
    backbone_name: str = "toy",
    cache_path: str | Path | None = None,
    score_cache_path: str | Path | None = None,
    target_absolute_error: float = 0.05,
    latency_budget: float | None = None,
    bound_method: str = "hoeffding",
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Execute multiple sources against a shared, optionally persistent cache."""

    root = Path(dataset_dir).resolve()
    if backbone_name == "toy":
        backbone = ToyStructuralBackbone.from_dataset(root)
    elif backbone_name == "attribute":
        backbone = AttributeStructuralBackbone.from_dataset(root)
    else:
        raise ValueError(f"Unsupported backbone: {backbone_name}")
    unknown = sorted(set(sources) - set(backbone.source_entities))
    if unknown:
        raise ValueError(f"Unknown source entities: {', '.join(unknown)}")
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    metadata = json.loads(
        (root / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    dependence = metadata.get("edge_dependence", {})
    common_shock_probability = (
        float(metadata.get("generation", {}).get("shared_strength", 0.0))
        if dependence.get("assumption") == "grouped_shared_latent"
        and any(groups)
        else 0.0
    )
    persistent = Path(cache_path).resolve() if cache_path is not None else None
    load_started = time.perf_counter()
    cache = WorldCache.load(persistent) if persistent and persistent.is_file() else WorldCache()
    cache_load_seconds = time.perf_counter() - load_started
    world_started = time.perf_counter()
    shared_worlds, persistent_world_reused = cache.get(
        probabilities,
        max_samples,
        seed,
        dependency_groups=groups,
        common_shock_probability=common_shock_probability,
    )
    shared_world_seconds = time.perf_counter() - world_started
    persistent_scores = (
        Path(score_cache_path).resolve()
        if score_cache_path is not None
        else None
    )
    score_cache_load_started = time.perf_counter()
    score_cache = (
        ScoreCache.load(persistent_scores)
        if persistent_scores and persistent_scores.is_file()
        else ScoreCache()
    )
    score_cache_load_seconds = (
        time.perf_counter() - score_cache_load_started
    )
    score_started = time.perf_counter()
    artifact_context_digest = _artifact_context_digest(root, backbone_name)
    shared_scores, persistent_score_reused = score_cache.get(
        shared_worlds,
        backbone_name,
        backbone.source_entities,
        backbone.target_entities,
        backbone.score,
        context_digest=artifact_context_digest,
    )
    shared_score_seconds = time.perf_counter() - score_started
    results = []
    latencies = []
    candidate_index = (
        StaticCandidateIndex.from_attribute_backbone(backbone)
        if isinstance(backbone, AttributeStructuralBackbone)
        else None
    )
    selections = []
    for index, source in enumerate(sources):
        selection = (
            candidate_index.select(source, k)
            if candidate_index is not None
            else None
        )
        candidates = (
            selection.candidates
            if selection is not None
            else backbone.target_entities
        )
        selections.append(selection)
        started = time.perf_counter()
        results.append(progressive_top_k_from_scores(
            shared_scores,
            source,
            candidates,
            k=k,
            batch_size=16,
            delta=0.05,
            cache_reused=persistent_world_reused or index > 0,
            bound_method=bound_method,
        ))
        latencies.append(time.perf_counter() - started)
    save_seconds = 0.0
    score_cache_save_seconds = 0.0
    if persistent and not persistent_world_reused:
        save_started = time.perf_counter()
        cache.save(persistent, overwrite=persistent.exists())
        save_seconds = time.perf_counter() - save_started
    if persistent_scores and not persistent_score_reused:
        save_started = time.perf_counter()
        score_cache.save(
            persistent_scores, overwrite=persistent_scores.exists()
        )
        score_cache_save_seconds = time.perf_counter() - save_started
    entropy_terms = [
        -(p * math_log2(p) + (1.0 - p) * math_log2(1.0 - p))
        for p in probabilities
    ]
    workload = QueryWorkload(
        uncertain_edges=len(probabilities),
        candidate_count=len(backbone.target_entities),
        normalized_entropy=sum(entropy_terms) / len(entropy_terms),
        latency_budget=(
            float(latency_budget)
            if latency_budget is not None
            else float(max_samples * len(probabilities))
        ),
        target_absolute_error=target_absolute_error,
    )
    plan = choose_execution_plan(workload)
    report = {
        "backbone": backbone_name,
        "bound_method": bound_method,
        "query_count": len(results),
        "stable_queries": sum(result.stable for result in results),
        "cache_hits": sum(result.cache_reused for result in results),
        "total_samples_used": sum(result.samples_used for result in results),
        "cache_path": str(persistent) if persistent else None,
        "score_cache_path": (
            str(persistent_scores) if persistent_scores else None
        ),
        "cache_load_seconds": cache_load_seconds,
        "cache_save_seconds": save_seconds,
        "score_cache_load_seconds": score_cache_load_seconds,
        "score_cache_save_seconds": score_cache_save_seconds,
        "persistent_score_cache_hit": persistent_score_reused,
        "artifact_context_digest": artifact_context_digest,
        "static_candidate_index": {
            "enabled": candidate_index is not None,
            "original_candidates_per_query": len(backbone.target_entities),
            "total_pruned": sum(
                selection.pruned
                for selection in selections
                if selection is not None
            ),
            "survivors_per_query": [
                (
                    len(selection.candidates)
                    if selection is not None
                    else len(backbone.target_entities)
                )
                for selection in selections
            ],
            "bound_semantics": (
                "world-uniform lower/upper score bounds"
                if candidate_index is not None
                else None
            ),
        },
        "shared_world_generation_seconds": shared_world_seconds,
        "shared_score_seconds": shared_score_seconds,
        "query_elapsed_seconds": latencies,
        "total_query_elapsed_seconds": sum(latencies),
        "total_execution_elapsed_seconds": (
            shared_world_seconds
            + shared_score_seconds
            + sum(latencies)
        ),
        "end_to_end_elapsed_seconds": (
            cache_load_seconds
            + score_cache_load_seconds
            + shared_world_seconds
            + shared_score_seconds
            + sum(latencies)
            + save_seconds
            + score_cache_save_seconds
        ),
        "mean_query_elapsed_seconds": sum(latencies) / len(latencies),
        "edge_dependence_assumption": dependence.get(
            "assumption", "unspecified"
        ),
        "common_shock_probability": common_shock_probability,
        "planner": plan.as_dict(),
        "executed_operator": "adaptive_sampling",
        "planner_matches_executed_operator": (
            plan.operator == "adaptive_sampling"
        ),
        "observed_seconds_per_estimated_cost_unit": (
            (
                shared_world_seconds
                + shared_score_seconds
                + sum(latencies)
            )
            / plan.estimated_cost
            if plan.operator == "adaptive_sampling"
            and plan.estimated_cost
            else None
        ),
        "queries": [
            {
                **result.as_dict(),
                "elapsed_seconds": latency,
                "static_pruned_candidates": (
                    selection.pruned if selection is not None else 0
                ),
                "static_kth_lower_bound": (
                    selection.kth_lower_bound
                    if selection is not None
                    else None
                ),
            }
            for result, latency, selection in zip(
                results, latencies, selections, strict=True
            )
        ],
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return report


def run_distributional_queries(
    dataset_dir: str | Path,
    sources: list[str],
    *,
    k: int = 1,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Execute analytic distribution-distance top-k queries."""

    root = Path(dataset_dir).resolve()
    build_started = time.perf_counter()
    index = DistributionalDegreeIndex.from_dataset(root)
    build_seconds = time.perf_counter() - build_started
    unknown = sorted(set(sources) - set(index.source_entities))
    if unknown:
        raise ValueError(f"Unknown source entities: {', '.join(unknown)}")
    results = []
    latencies = []
    for source in sources:
        started = time.perf_counter()
        results.append(index.query(source, k=k))
        latencies.append(time.perf_counter() - started)
    report = {
        "dataset_dir": str(root),
        "executed_operator": "distributional",
        "operator_variant": "analytic_in_out_degree_gaussian_wasserstein",
        "query_count": len(results),
        "candidate_count": len(index.target_entities),
        "index_build_seconds": build_seconds,
        "query_elapsed_seconds": latencies,
        "total_query_elapsed_seconds": sum(latencies),
        "total_execution_elapsed_seconds": build_seconds + sum(latencies),
        "mean_query_elapsed_seconds": sum(latencies) / len(latencies),
        "analytic_incident_edge_passes": index.edge_passes,
        "edge_dependence_assumption": index.edge_dependence_assumption,
        "common_shock_probability": index.common_shock_probability,
        "guarantee": (
            "Exact first/second degree moments under the declared dependence "
            "model; no finite-sample top-k confidence guarantee."
        ),
        "queries": [
            {
                **result.as_dict(),
                "elapsed_seconds": latency,
            }
            for result, latency in zip(results, latencies, strict=True)
        ],
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return report


def run_learned_covariance_queries(
    dataset_dir: str | Path,
    artifact_path: str | Path,
    sources: list[str],
    *,
    k: int = 1,
) -> dict[str, object]:
    """Execute a validated learned low-rank Gaussian top-k artifact."""

    root = Path(dataset_dir).resolve()
    metadata = json.loads(
        (root / "confidence_metadata.json").read_text(encoding="utf-8")
    )
    build_started = time.perf_counter()
    index = LearnedLowRankCovarianceIndex.from_artifact(artifact_path)
    build_seconds = time.perf_counter() - build_started
    if index.metadata.get("dataset_id") != metadata.get("dataset_id"):
        raise ValueError("Learned covariance artifact dataset_id mismatch")
    expected_revision = dataset_revision_digest(root)
    if index.metadata.get("dataset_revision") != expected_revision:
        raise ValueError(
            "Learned covariance artifact is stale for the active dataset revision"
        )
    checkpoint_sha256 = str(
        index.metadata.get("checkpoint_sha256", "")
    )
    if len(checkpoint_sha256) != 64:
        raise ValueError("Learned covariance artifact lacks model revision")
    unknown = sorted(set(sources) - set(index.source_entities))
    if unknown:
        raise ValueError(f"Unknown source entities: {', '.join(unknown)}")
    results = []
    latencies = []
    for source in sources:
        started = time.perf_counter()
        results.append(index.query(source, k=k))
        latencies.append(time.perf_counter() - started)
    return {
        "dataset_dir": str(root),
        "artifact_path": str(Path(artifact_path).resolve()),
        "executed_operator": "distributional_low_rank",
        "operator_variant": "learned_hidden_rank_plus_diagonal_gaussian_wasserstein",
        "query_count": len(results),
        "candidate_count": len(index.target_entities),
        "index_build_seconds": build_seconds,
        "query_elapsed_seconds": latencies,
        "total_query_elapsed_seconds": sum(latencies),
        "total_execution_elapsed_seconds": build_seconds + sum(latencies),
        "mean_query_elapsed_seconds": sum(latencies) / len(latencies),
        "validation_mean_relative_distance_error": index.metadata.get(
            "validation_mean_relative_distance_error"
        ),
        "validation_winner_agreement": index.metadata.get(
            "validation_winner_agreement"
        ),
        "guarantee": (
            "Empirically validation-gated learned-hidden low-rank covariance; "
            "no finite-sample top-k confidence guarantee."
        ),
        "queries": [
            {
                **result.as_dict(),
                "elapsed_seconds": latency,
            }
            for result, latency in zip(results, latencies, strict=True)
        ],
    }


def run_planned_batch_queries(
    dataset_dir: str | Path,
    sources: list[str],
    *,
    k: int = 1,
    max_samples: int = 256,
    seed: int = 17,
    backbone_name: str = "attribute",
    target_absolute_error: float = 0.1,
    latency_budget: float | None = None,
    distributional_validation_error: float | None = None,
    distributional_operator: str = "degree_diagonal",
    distributional_artifact: str | Path | None = None,
    bound_method: str = "hoeffding",
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Choose a plan first, then execute the selected operator family."""

    root = Path(dataset_dir).resolve()
    if backbone_name == "attribute":
        backbone = AttributeStructuralBackbone.from_dataset(root)
    elif backbone_name == "toy":
        backbone = ToyStructuralBackbone.from_dataset(root)
    else:
        raise ValueError(f"Unsupported backbone: {backbone_name}")
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    entropy_terms = [
        -(p * math_log2(p) + (1.0 - p) * math_log2(1.0 - p))
        for p in probabilities
    ]
    declared_latency = (
        float(latency_budget)
        if latency_budget is not None
        else float(max_samples * len(probabilities))
    )
    effective_validation_error = distributional_validation_error
    if distributional_operator == "learned_low_rank":
        if distributional_artifact is None:
            raise ValueError(
                "learned_low_rank plan requires distributional_artifact"
            )
        artifact_index = LearnedLowRankCovarianceIndex.from_artifact(
            distributional_artifact
        )
        artifact_error = float(
            artifact_index.metadata[
                "validation_mean_relative_distance_error"
            ]
        )
        if (
            distributional_validation_error is not None
            and abs(distributional_validation_error - artifact_error) > 1e-12
        ):
            raise ValueError(
                "Declared validation error does not match operator artifact"
            )
        effective_validation_error = artifact_error
    workload = QueryWorkload(
        uncertain_edges=len(probabilities),
        candidate_count=len(backbone.target_entities),
        normalized_entropy=sum(entropy_terms) / len(entropy_terms),
        latency_budget=declared_latency,
        target_absolute_error=target_absolute_error,
        distributional_validation_error=effective_validation_error,
        distributional_operator=distributional_operator,
    )
    plan = choose_execution_plan(workload)
    if plan.operator == "distributional":
        report = run_distributional_queries(root, sources, k=k)
    elif plan.operator == "distributional_low_rank":
        if distributional_artifact is None:
            raise ValueError(
                "learned_low_rank plan requires distributional_artifact"
            )
        report = run_learned_covariance_queries(
            root,
            distributional_artifact,
            sources,
            k=k,
        )
    elif plan.operator == "adaptive_sampling":
        report = run_batch_queries(
            root,
            sources,
            k=k,
            max_samples=max_samples,
            seed=seed,
            backbone_name=backbone_name,
            target_absolute_error=target_absolute_error,
            latency_budget=declared_latency,
            bound_method=bound_method,
        )
    else:
        raise ValueError(
            "Exact operator selected but planned batch exact execution is not "
            "implemented for this path; use enumerate-worlds on a toy graph."
        )
    report["planner"] = plan.as_dict()
    report["planner_matches_executed_operator"] = (
        report["executed_operator"] == plan.operator
    )
    report["declared_workload"] = {
        "uncertain_edges": workload.uncertain_edges,
        "candidate_count": workload.candidate_count,
        "normalized_entropy": workload.normalized_entropy,
        "latency_budget": workload.latency_budget,
        "target_absolute_error": workload.target_absolute_error,
        "distributional_validation_error": (
            workload.distributional_validation_error
        ),
        "distributional_operator": workload.distributional_operator,
        "distributional_artifact": (
            str(Path(distributional_artifact).resolve())
            if distributional_artifact is not None
            else None
        ),
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return report


def run_query_operator_comparison(
    dataset_dir: str | Path,
    sources: list[str],
    *,
    k: int = 1,
    max_samples: int = 256,
    seed: int = 17,
    backbone_name: str = "attribute",
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Compare analytic distributional and adaptive sampling on one workload."""

    root = Path(dataset_dir).resolve()
    distributional = run_distributional_queries(root, sources, k=k)
    sampling = run_batch_queries(
        root,
        sources,
        k=k,
        max_samples=max_samples,
        seed=seed,
        backbone_name=backbone_name,
        target_absolute_error=0.05,
    )
    with (root / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        truth = {
            row["source_entity_id"]: row["target_entity_id"]
            for row in csv.DictReader(handle, delimiter="\t")
        }
    distributional_winners = {
        query["source"]: query["top_k"][0]["candidate"]
        for query in distributional["queries"]
    }
    sampling_winners = {
        query["source"]: query["top_k"][0]["candidate"]
        for query in sampling["queries"]
    }
    agreement = sum(
        distributional_winners[source] == sampling_winners[source]
        for source in sources
    ) / len(sources)
    distributional_accuracy = sum(
        distributional_winners[source] == truth[source]
        for source in sources
    ) / len(sources)
    sampling_accuracy = sum(
        sampling_winners[source] == truth[source] for source in sources
    ) / len(sources)
    distributional_seconds = float(
        distributional["total_execution_elapsed_seconds"]
    )
    sampling_seconds = float(sampling["total_execution_elapsed_seconds"])
    result = {
        "dataset_dir": str(root),
        "query_count": len(sources),
        "k": k,
        "sampling_budget": max_samples,
        "seed": seed,
        "winner_agreement": agreement,
        "distributional_top1_accuracy": distributional_accuracy,
        "sampling_top1_accuracy": sampling_accuracy,
        "distributional_total_seconds": distributional_seconds,
        "sampling_total_seconds": sampling_seconds,
        "distributional_speedup": (
            sampling_seconds / distributional_seconds
            if distributional_seconds
            else float("inf")
        ),
        "stable_sampling_queries": sampling["stable_queries"],
        "distributional_mean_distance_margin": sum(
            float(query["distance_margin"])
            for query in distributional["queries"]
        )
        / len(sources),
        "guarantee_boundary": {
            "distributional": distributional["guarantee"],
            "sampling": (
                "Hoeffding stability is reported per query; unstable queries "
                "exhaust the budget without a separation claim."
            ),
        },
        "operator_summaries": {
            "distributional": distributional,
            "adaptive_sampling": sampling,
        },
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def math_log2(value: float) -> float:
    if value in {0.0, 1.0}:
        return 0.0
    import math

    return math.log2(value)
