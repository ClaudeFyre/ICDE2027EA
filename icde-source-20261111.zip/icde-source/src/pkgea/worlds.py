"""Exact enumeration utilities for small independent-edge toy graphs."""

from __future__ import annotations

import csv
import itertools
from dataclasses import dataclass
from pathlib import Path

from pkgea.contracts import validate_dataset


@dataclass(frozen=True)
class WorldSummary:
    uncertain_edge_count: int
    world_count: int
    total_probability_mass: float
    expected_active_edges: float

    def as_dict(self) -> dict[str, int | float]:
        return {
            "uncertain_edge_count": self.uncertain_edge_count,
            "world_count": self.world_count,
            "total_probability_mass": self.total_probability_mass,
            "expected_active_edges": self.expected_active_edges,
        }


def _edge_probabilities(dataset_dir: Path) -> list[float]:
    with (dataset_dir / "triples.tsv").open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))

    dependency_groups = {row["dependency_group"] for row in rows if row["dependency_group"]}
    if dependency_groups:
        groups = ", ".join(sorted(dependency_groups))
        raise ValueError(
            "Exact enumerator currently supports independent edges only; "
            f"found dependency groups: {groups}"
        )
    if any(row["confidence_type"] != "calibrated_probability" for row in rows):
        raise ValueError(
            "Exact enumeration requires calibrated_probability for every triple"
        )
    return [float(row["confidence"]) for row in rows]


def enumerate_independent_worlds(
    dataset_dir: str | Path, max_uncertain_edges: int = 20
) -> WorldSummary:
    """Enumerate all independent-edge worlds and summarize their probability mass."""

    root = Path(dataset_dir).resolve()
    validate_dataset(root)
    probabilities = _edge_probabilities(root)
    edge_count = len(probabilities)
    if edge_count > max_uncertain_edges:
        raise ValueError(
            f"Refusing to enumerate 2^{edge_count} worlds; "
            f"limit is {max_uncertain_edges} uncertain edges"
        )

    total_probability_mass = 0.0
    weighted_active_edges = 0.0
    world_count = 0
    for state in itertools.product((0, 1), repeat=edge_count):
        mass = 1.0
        for active, probability in zip(state, probabilities, strict=True):
            mass *= probability if active else 1.0 - probability
        total_probability_mass += mass
        weighted_active_edges += mass * sum(state)
        world_count += 1

    return WorldSummary(
        uncertain_edge_count=edge_count,
        world_count=world_count,
        total_probability_mass=total_probability_mass,
        expected_active_edges=weighted_active_edges,
    )

