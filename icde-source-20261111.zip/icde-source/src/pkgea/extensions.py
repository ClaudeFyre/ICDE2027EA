"""Runnable prototypes for streaming and trustworthy extension nodes."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
import json
import random
import statistics
import threading
import time
from pathlib import Path

from pkgea.backbones import AttributeStructuralBackbone
from pkgea.distributional import aggregate_bernoulli_messages
from pkgea.streaming import (
    FactEvent,
    IncrementalMomentIndex,
    PropagationDependencyIndex,
    VersionedStreamingMomentIndex,
)
from pkgea.query import (
    ScoreCache,
    StaleCacheRevisionError,
    StaticCandidateIndex,
    VersionedScoreCache,
    WorldCache,
    progressive_top_k_from_scores,
)
from pkgea.trustworthy import (
    adaptive_conformal_candidate_set,
    apply_temperature,
    brier_score,
    conformal_candidate_set,
    evaluate_conformal_coverage,
    expected_calibration_error,
    fit_multiclass_temperature,
    fit_temperature,
    log_loss,
    margin_conformal_candidate_set,
    maximum_weight_injective_assignment,
    multiclass_brier_score,
    multiclass_log_loss,
    softmax_probabilities,
)


def run_streaming_toy(
    dataset_dir: str | Path, edge_index: int, new_probability: float
) -> dict[str, object]:
    root = Path(dataset_dir).resolve()
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    messages = [
        (1.0, 0.0) if row["graph_id"] == "source" else (0.0, 1.0)
        for row in triples
    ]
    groups = [row["dependency_group"] for row in triples]
    index = IncrementalMomentIndex(
        messages, probabilities, dependency_groups=groups
    )
    update = index.update(edge_index, new_probability)
    probabilities[edge_index] = new_probability
    rebuilt = aggregate_bernoulli_messages(
        messages, probabilities, dependency_groups=groups
    )
    mean_error = max(
        abs(left - right)
        for left, right in zip(index.moments.mean, rebuilt.mean, strict=True)
    )
    covariance_error = max(
        abs(index.moments.covariance[row][column] - rebuilt.covariance[row][column])
        for row in range(len(rebuilt.mean))
        for column in range(len(rebuilt.mean))
    )
    return {
        "edge_index": update.edge_index,
        "old_probability": update.old_probability,
        "new_probability": update.new_probability,
        "affected_edges": list(update.affected_edges),
        "incremental_mean": list(index.moments.mean),
        "max_rebuild_mean_error": mean_error,
        "max_rebuild_covariance_error": covariance_error,
    }


def run_streaming_batch_toy(dataset_dir: str | Path) -> dict[str, object]:
    """Exercise update, add, and delete events against a full rebuild."""

    root = Path(dataset_dir).resolve()
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    messages = [
        (1.0, 0.0) if row["graph_id"] == "source" else (0.0, 1.0)
        for row in triples
    ]
    groups = [row["dependency_group"] for row in triples]
    index = IncrementalMomentIndex(
        messages, probabilities, dependency_groups=groups
    )
    events = [
        FactEvent("update", edge_index=0, probability=0.4),
        FactEvent("add", probability=0.3, message=(0.5, 0.5)),
        FactEvent("delete", edge_index=1),
    ]
    mutations = index.apply_events(events)
    rebuilt = aggregate_bernoulli_messages(
        index.messages,
        index.probabilities,
        dependency_groups=index.groups,
    )
    mean_error = max(
        abs(left - right)
        for left, right in zip(index.moments.mean, rebuilt.mean, strict=True)
    )
    covariance_error = max(
        abs(index.moments.covariance[row][column] - rebuilt.covariance[row][column])
        for row in range(len(rebuilt.mean))
        for column in range(len(rebuilt.mean))
    )
    return {
        "events": [
            {
                "action": event.action,
                "edge_index": mutation.edge_index,
                "affected_edges": list(mutation.affected_edges),
            }
            for event, mutation in zip(events, mutations, strict=True)
        ],
        "edge_slots_after_batch": len(index.probabilities),
        "active_probability_count": sum(
            probability > 0.0 for probability in index.probabilities
        ),
        "max_rebuild_mean_error": mean_error,
        "max_rebuild_covariance_error": covariance_error,
    }


def _stream_message(row: dict[str, str], dimension: int) -> tuple[float, ...]:
    """Create a deterministic, bounded message without Python hash seeding."""

    vector = [0.0] * dimension
    vector[0 if row["graph_id"] == "source" else 1] = 1.0
    digest = hashlib.sha256(row["relation_id"].encode("utf-8")).digest()
    bucket = 2 + int.from_bytes(digest[:2], "big") % (dimension - 2)
    vector[bucket] = 1.0
    return tuple(vector)


def run_streaming_trace(
    dataset_dir: str | Path,
    *,
    event_count: int = 128,
    seed: int = 17,
    allowed_lateness: float = 6.0,
    retention_window: float = 64.0,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Benchmark a deterministic timestamped trace against full rebuilding."""

    if event_count < 16:
        raise ValueError("event_count must be at least 16")
    if retention_window <= 0.0:
        raise ValueError("retention_window must be positive")
    root = Path(dataset_dir).resolve()
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    if not triples:
        raise ValueError("streaming trace requires at least one triple")

    dimension = 16
    probabilities = [float(row["confidence"]) for row in triples]
    messages = [_stream_message(row, dimension) for row in triples]
    groups = [row["dependency_group"] for row in triples]
    rho = 0.0
    metadata_path = root / "confidence_metadata.json"
    assumption = "unspecified"
    if metadata_path.is_file():
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        dependence = metadata.get("edge_dependence", {})
        assumption = str(dependence.get("assumption", "unspecified"))
        if (
            assumption == "grouped_shared_latent"
            and any(groups)
        ):
            rho = float(
                metadata.get("generation", {}).get(
                    "shared_strength", 0.0
                )
            )

    index = IncrementalMomentIndex(
        messages,
        probabilities,
        dependency_groups=groups,
        common_shock_probability=rho,
    )
    stream = VersionedStreamingMomentIndex(
        index,
        allowed_lateness=allowed_lateness,
        late_policy="apply",
        max_history=event_count + 2,
    )

    segment_size = max(1, len(probabilities) // 16)
    for start in range(0, len(probabilities), segment_size):
        edges = tuple(
            range(start, min(start + segment_size, len(probabilities)))
        )
        stream.put_cached(
            f"segment-{start // segment_size}",
            index.moments.mean,
            depends_on_edges=edges,
        )
    stream.put_cached("global-ranking", index.moments.mean)

    rng = random.Random(seed)
    edge_order = list(range(len(probabilities)))
    rng.shuffle(edge_order)
    planned: list[FactEvent] = []
    for position in range(event_count):
        event_time = float(position + 1)
        observation_time = event_time + float(rng.randrange(0, 13))
        if position % 17 == 0:
            relation = f"stream:add:{position}"
            row = {"graph_id": "source", "relation_id": relation}
            planned.append(
                FactEvent(
                    "add",
                    probability=0.2 + 0.6 * rng.random(),
                    message=_stream_message(row, dimension),
                    event_time=event_time,
                    observation_time=observation_time,
                    event_id=f"add-{position}",
                )
            )
            continue
        edge_index = edge_order[position % len(edge_order)]
        if position % 11 == 0:
            planned.append(
                FactEvent(
                    "delete",
                    edge_index=edge_index,
                    event_time=event_time,
                    observation_time=observation_time,
                    event_id=f"delete-{position}",
                )
            )
        else:
            old = probabilities[edge_index]
            direction = -1.0 if position % 2 else 1.0
            probability = min(max(old + direction * 0.2, 0.01), 0.99)
            planned.append(
                FactEvent(
                    "update",
                    edge_index=edge_index,
                    probability=probability,
                    event_time=event_time,
                    observation_time=observation_time,
                    event_id=f"update-{position}",
                )
            )
    planned.sort(
        key=lambda event: (
            event.observation_time,
            event.event_time,
            event.event_id,
        )
    )

    incremental_times: list[float] = []
    rebuild_times: list[float] = []
    mean_drifts: list[float] = []
    max_mean_error = 0.0
    max_covariance_error = 0.0
    invalidations = 0
    previous_mean = index.moments.mean
    for event in planned:
        started = time.perf_counter()
        record = stream.apply_event(event)
        incremental_times.append(time.perf_counter() - started)
        invalidations += len(record.invalidated_cache_keys)

        started = time.perf_counter()
        rebuilt = aggregate_bernoulli_messages(
            index.messages,
            index.probabilities,
            dependency_groups=index.groups,
            common_shock_probability=rho,
        )
        rebuild_times.append(time.perf_counter() - started)
        max_mean_error = max(
            max_mean_error,
            max(
                abs(left - right)
                for left, right in zip(
                    index.moments.mean, rebuilt.mean, strict=True
                )
            ),
        )
        max_covariance_error = max(
            max_covariance_error,
            max(
                abs(index.moments.covariance[row][column]
                    - rebuilt.covariance[row][column])
                for row in range(dimension)
                for column in range(dimension)
            ),
        )
        mean_drifts.append(
            sum(
                abs(left - right)
                for left, right in zip(
                    previous_mean, index.moments.mean, strict=True
                )
            )
        )
        previous_mean = index.moments.mean

        for key in record.invalidated_cache_keys:
            if key == "global-ranking":
                stream.put_cached(key, index.moments.mean)
            elif str(key).startswith("segment-"):
                segment = int(str(key).split("-")[1])
                start = segment * segment_size
                stream.put_cached(
                    key,
                    index.moments.mean,
                    depends_on_edges=range(
                        start,
                        min(start + segment_size, len(index.probabilities)),
                    ),
                )

    final_snapshot = index.snapshot()
    replay_count = 8
    rollback_version = stream.version - replay_count
    replay_events = planned[-replay_count:]
    rollback_invalidations = len(stream.rollback(rollback_version))
    for event in replay_events:
        stream.apply_event(event)
    replay_snapshot = index.snapshot()
    rollback_replay_exact = (
        replay_snapshot.probabilities == final_snapshot.probabilities
        and replay_snapshot.messages == final_snapshot.messages
        and max(
            abs(left - right)
            for left, right in zip(
                replay_snapshot.moments.mean,
                final_snapshot.moments.mean,
                strict=True,
            )
        )
        < 1e-12
    )

    late_count = sum(record.late_beyond_watermark for record in stream.records)
    maximum_observation = max(
        event.observation_time for event in planned
        if event.observation_time is not None
    )
    pruned_records = stream.prune_records(
        maximum_observation - retention_window
    )
    incremental_total = sum(incremental_times)
    rebuild_total = sum(rebuild_times)
    result = {
        "dataset_dir": str(root),
        "trace": {
            "seed": seed,
            "event_count": event_count,
            "actions": {
                action: sum(event.action == action for event in planned)
                for action in ("update", "add", "delete")
            },
            "event_time_semantics": "modeled fact/correction time",
            "observation_time_semantics": "system arrival time",
            "allowed_lateness": allowed_lateness,
            "late_beyond_watermark_count": late_count,
            "maximum_arrival_delay": max(
                event.observation_time - event.event_time
                for event in planned
                if event.observation_time is not None
                and event.event_time is not None
            ),
        },
        "dependence": {
            "assumption": assumption,
            "common_shock_probability": rho,
        },
        "correctness": {
            "max_rebuild_mean_error": max_mean_error,
            "max_rebuild_covariance_error": max_covariance_error,
            "rollback_version": rollback_version,
            "rollback_replay_events": replay_count,
            "rollback_replay_exact": rollback_replay_exact,
        },
        "latency": {
            "incremental_total_seconds": incremental_total,
            "full_rebuild_total_seconds": rebuild_total,
            "speedup": (
                rebuild_total / incremental_total
                if incremental_total
                else float("inf")
            ),
            "incremental_median_ms": 1000.0
            * statistics.median(incremental_times),
            "incremental_p95_ms": 1000.0
            * sorted(incremental_times)[
                min(
                    len(incremental_times) - 1,
                    int(0.95 * len(incremental_times)),
                )
            ],
            "full_rebuild_median_ms": 1000.0
            * statistics.median(rebuild_times),
        },
        "stability": {
            "median_l1_mean_drift_per_event": statistics.median(mean_drifts),
            "max_l1_mean_drift_per_event": max(mean_drifts),
        },
        "cache_and_retention": {
            "dependency_aware_invalidations": invalidations,
            "rollback_invalidations": rollback_invalidations,
            "retention_window": retention_window,
            "pruned_audit_records": pruned_records,
            "retained_audit_records": len(stream.records),
        },
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def _stream_context_digest(
    dataset_dir: Path,
    probabilities: list[float],
    version: int,
) -> str:
    digest = hashlib.sha256()
    digest.update(b"pkgea-stream-score-revision-v1\0")
    digest.update(str(version).encode("ascii"))
    for filename in ("triples.tsv", "attributes.tsv", "alignments.tsv"):
        path = dataset_dir / filename
        if path.is_file():
            digest.update(filename.encode("utf-8"))
            digest.update(path.read_bytes())
    for probability in probabilities:
        digest.update(f"{probability:.17g}\n".encode("ascii"))
    return digest.hexdigest()


def run_streaming_query_trace(
    dataset_dir: str | Path,
    *,
    event_count: int = 24,
    world_budget: int = 64,
    seed: int = 17,
    propagation_depth: int = 1,
    normalization_hops: int = 0,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Measure version-safe score-cache behavior after confidence updates."""

    if event_count < 4:
        raise ValueError("event_count must be at least 4")
    if world_budget <= 0:
        raise ValueError("world_budget must be positive")
    if propagation_depth <= 0:
        raise ValueError("propagation_depth must be positive")
    if normalization_hops < 0:
        raise ValueError("normalization_hops cannot be negative")
    root = Path(dataset_dir).resolve()
    backbone = AttributeStructuralBackbone.from_dataset(root)
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    probabilities = [float(row["confidence"]) for row in triples]
    edge_endpoints = [
        (row["head_id"], row["tail_id"]) for row in triples
    ]
    propagation_dependencies = PropagationDependencyIndex(edge_endpoints)
    groups = [row["dependency_group"] for row in triples]
    messages = [_stream_message(row, 16) for row in triples]
    index = IncrementalMomentIndex(
        messages, probabilities, dependency_groups=groups
    )
    stream = VersionedStreamingMomentIndex(
        index,
        allowed_lateness=4.0,
        late_policy="apply",
        max_history=event_count + 2,
    )
    world_cache = WorldCache()
    initial_revision = _stream_context_digest(root, probabilities, 0)
    score_cache = ScoreCache()
    guarded = VersionedScoreCache(
        score_cache, active_revision=initial_revision
    )
    candidate_index = StaticCandidateIndex.from_attribute_backbone(backbone)
    source = backbone.source_entities[0]
    selection = candidate_index.select(source, 1)

    initial_worlds = world_cache.get(
        probabilities, world_budget, seed
    )[0]
    initial_scores, initial_hit = guarded.get(
        initial_revision,
        initial_worlds,
        "attribute",
        backbone.source_entities,
        backbone.target_entities,
        backbone.score,
    )
    if initial_hit:
        raise AssertionError("new versioned cache unexpectedly hit")
    local_score_cache = ScoreCache()
    local_guarded = VersionedScoreCache(
        local_score_cache,
        active_revision=initial_revision,
    )
    local_sources = (source,)
    local_targets = tuple(selection.candidates)
    initial_local_scores, initial_local_hit = local_guarded.get(
        initial_revision,
        initial_worlds,
        "attribute-local",
        local_sources,
        local_targets,
        lambda state: backbone.score_subset(
            state,
            local_sources,
            local_targets,
        ),
    )
    if initial_local_hit:
        raise AssertionError("new local versioned cache unexpectedly hit")
    initial_query = progressive_top_k_from_scores(
        initial_local_scores,
        source,
        selection.candidates,
        k=1,
        batch_size=16,
    )

    rng = random.Random(seed)
    query_entities = {source, *selection.candidates}
    relevant_edges = [
        edge_index
        for edge_index in range(len(triples))
        if propagation_dependencies.affected_entities(
            (edge_index,), propagation_depth,
            normalization_hops=normalization_hops,
        )
        & query_entities
    ]
    unrelated_edges = [
        edge_index
        for edge_index in range(len(triples))
        if not (
            propagation_dependencies.affected_entities(
                (edge_index,), propagation_depth,
                normalization_hops=normalization_hops,
            )
            & query_entities
        )
    ]
    rng.shuffle(relevant_edges)
    rng.shuffle(unrelated_edges)
    if relevant_edges and unrelated_edges:
        edge_order = [
            (
                relevant_edges[(position // 4) % len(relevant_edges)]
                if position % 4 == 0
                else unrelated_edges[
                    (position - position // 4 - 1)
                    % len(unrelated_edges)
                ]
            )
            for position in range(event_count)
        ]
    else:
        edge_order = relevant_edges or unrelated_edges
    planned = []
    for position in range(event_count):
        edge_index = edge_order[position % len(edge_order)]
        old = probabilities[edge_index]
        direction = 1.0 if position % 2 == 0 else -1.0
        planned.append(
            FactEvent(
                "update",
                edge_index=edge_index,
                probability=min(max(old + direction * 0.15, 0.01), 0.99),
                event_time=float(position + 1),
                observation_time=float(position + 1 + rng.randrange(0, 9)),
                event_id=f"query-update-{position}",
            )
        )
    planned.sort(
        key=lambda event: (
            event.observation_time,
            event.event_time,
            event.event_id,
        )
    )

    update_query_latencies = []
    score_compute_latencies = []
    repeated_lookup_latencies = []
    local_refresh_latencies = []
    local_reuse_latencies = []
    local_recompute_latencies = []
    full_refresh_latencies = []
    local_reuse_count = 0
    local_recompute_count = 0
    max_local_score_error = 0.0
    stale_reads_blocked = 0
    fresh_misses = 0
    same_revision_hits = 0
    winners = [initial_query.top_k[0].candidate]
    revisions = {0: initial_revision}
    for event in planned:
        old_revision = guarded.active_revision
        old_worlds = world_cache.get(
            index.probabilities, world_budget, seed
        )[0]
        started = time.perf_counter()
        mutation_record = stream.apply_event(event)
        probabilities = list(index.probabilities)
        revision = _stream_context_digest(
            root, probabilities, stream.version
        )
        revisions[stream.version] = revision
        guarded.advance(revision)
        local_guarded.advance(revision)
        try:
            guarded.get(
                old_revision,
                old_worlds,
                "attribute",
                backbone.source_entities,
                backbone.target_entities,
                backbone.score,
            )
        except StaleCacheRevisionError:
            stale_reads_blocked += 1

        worlds = world_cache.get(
            probabilities, world_budget, seed
        )[0]
        score_started = time.perf_counter()
        scores, reused = guarded.get(
            revision,
            worlds,
            "attribute",
            backbone.source_entities,
            backbone.target_entities,
            backbone.score,
        )
        score_compute_latencies.append(
            time.perf_counter() - score_started
        )
        full_refresh_latencies.append(score_compute_latencies[-1])
        fresh_misses += not reused

        affected_entities = propagation_dependencies.affected_entities(
            mutation_record.mutation.affected_edges,
            propagation_depth,
            normalization_hops=normalization_hops,
        )
        local_started = time.perf_counter()
        if affected_entities.isdisjoint(query_entities):
            local_scores = initial_local_scores
            local_guarded.put(
                revision,
                worlds,
                "attribute-local",
                local_sources,
                local_targets,
                local_scores,
            )
            local_reuse_count += 1
            local_path_reused = True
        else:
            local_scores, local_reused = local_guarded.get(
                revision,
                worlds,
                "attribute-local",
                local_sources,
                local_targets,
                lambda state: backbone.score_subset(
                    state,
                    local_sources,
                    local_targets,
                ),
            )
            if local_reused:
                raise AssertionError("fresh local revision unexpectedly hit")
            initial_local_scores = local_scores
            local_recompute_count += 1
            local_path_reused = False
        local_elapsed = time.perf_counter() - local_started
        local_refresh_latencies.append(local_elapsed)
        (
            local_reuse_latencies
            if local_path_reused
            else local_recompute_latencies
        ).append(local_elapsed)
        for full_matrix, local_matrix in zip(
            scores,
            local_scores,
            strict=True,
        ):
            for pair, local_score in local_matrix.items():
                max_local_score_error = max(
                    max_local_score_error,
                    abs(local_score - full_matrix[pair]),
                )
        query = progressive_top_k_from_scores(
            local_scores,
            source,
            selection.candidates,
            k=1,
            batch_size=16,
        )
        winners.append(query.top_k[0].candidate)
        update_query_latencies.append(time.perf_counter() - started)

        lookup_started = time.perf_counter()
        _, reused_same = guarded.get(
            revision,
            worlds,
            "attribute",
            backbone.source_entities,
            backbone.target_entities,
            backbone.score,
        )
        repeated_lookup_latencies.append(
            time.perf_counter() - lookup_started
        )
        same_revision_hits += reused_same

    rollback_distance = 4
    rollback_version = stream.version - rollback_distance
    rollback_started = time.perf_counter()
    stream.rollback(rollback_version)
    rollback_revision = revisions[rollback_version]
    guarded.advance(rollback_revision)
    local_guarded.advance(rollback_revision)
    rollback_worlds = world_cache.get(
        index.probabilities, world_budget, seed
    )[0]
    _, rollback_cache_hit = guarded.get(
        rollback_revision,
        rollback_worlds,
        "attribute",
        backbone.source_entities,
        backbone.target_entities,
        backbone.score,
    )
    _, local_rollback_cache_hit = local_guarded.get(
        rollback_revision,
        rollback_worlds,
        "attribute-local",
        local_sources,
        local_targets,
        lambda state: backbone.score_subset(
            state,
            local_sources,
            local_targets,
        ),
    )
    rollback_recovery_seconds = time.perf_counter() - rollback_started

    result = {
        "dataset_dir": str(root),
        "query": {
            "source": source,
            "original_candidates": len(backbone.target_entities),
            "bound_survivors": len(selection.candidates),
            "world_budget": world_budget,
        },
        "trace": {
            "event_count": event_count,
            "seed": seed,
            "fresh_revision_misses": fresh_misses,
            "same_revision_hits": same_revision_hits,
            "stale_reads_attempted": event_count,
            "stale_reads_blocked": stale_reads_blocked,
            "retained_score_revisions": len(score_cache.context_digests),
            "local_reuses": local_reuse_count,
            "local_recomputes": local_recompute_count,
        },
        "latency": {
            "median_update_to_query_ms": 1000.0
            * statistics.median(update_query_latencies),
            "p95_update_to_query_ms": 1000.0
            * sorted(update_query_latencies)[
                min(
                    len(update_query_latencies) - 1,
                    int(0.95 * len(update_query_latencies)),
                )
            ],
            "median_fresh_score_compute_ms": 1000.0
            * statistics.median(score_compute_latencies),
            "median_same_revision_lookup_ms": 1000.0
            * statistics.median(repeated_lookup_latencies),
            "rollback_recovery_ms": 1000.0 * rollback_recovery_seconds,
            "median_local_refresh_ms": 1000.0
            * statistics.median(local_refresh_latencies),
            "median_local_reuse_ms": (
                1000.0 * statistics.median(local_reuse_latencies)
                if local_reuse_latencies
                else None
            ),
            "median_local_recompute_ms": (
                1000.0 * statistics.median(local_recompute_latencies)
                if local_recompute_latencies
                else None
            ),
            "localized_vs_full_refresh_speedup": (
                statistics.median(full_refresh_latencies)
                / max(statistics.median(local_refresh_latencies), 1e-12)
            ),
        },
        "rollback": {
            "distance": rollback_distance,
            "restored_version": rollback_version,
            "retained_revision_cache_hit": rollback_cache_hit,
            "local_retained_revision_cache_hit": local_rollback_cache_hit,
        },
        "ranking": {
            "initial_winner": str(winners[0]),
            "final_pre_rollback_winner": str(winners[-1]),
            "winner_change_count": sum(
                left != right
                for left, right in zip(winners, winners[1:])
            ),
        },
        "cache_contract": {
            "context_components": [
                "graph triples",
                "attributes",
                "alignment scope",
                "ordered probabilities",
                "stream version",
            ],
            "old_revisions_retained_for_rollback": True,
            "non_active_revision_reads": "rejected",
        },
        "local_refresh": {
            "scope": "one source and statically surviving targets",
            "propagation_depth": propagation_depth,
            "normalization_hops": normalization_hops,
            "dependency_rule": (
                "recompute iff the propagation-depth expansion of affected "
                "edge endpoints intersects the query source/candidate set"
            ),
            "max_score_error_vs_full_recompute": max_local_score_error,
        },
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def run_hop_invalidation_audit(
    dataset_dir: str | Path,
    *,
    max_depth: int = 4,
    normalization_hops: int = 0,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Measure cache invalidations required by increasing GNN depth.

    Every edge slot is treated as a possible confidence update.  If it belongs
    to a dependency group, all slots in that group are included in the
    mutation, matching ``IncrementalMomentIndex`` semantics.
    """

    if max_depth <= 0:
        raise ValueError("max_depth must be positive")
    if normalization_hops < 0:
        raise ValueError("normalization_hops cannot be negative")
    root = Path(dataset_dir).resolve()
    backbone = AttributeStructuralBackbone.from_dataset(root)
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    endpoints = [(row["head_id"], row["tail_id"]) for row in triples]
    dependencies = PropagationDependencyIndex(endpoints)
    groups: dict[str, list[int]] = {}
    for edge_index, row in enumerate(triples):
        group = row["dependency_group"]
        if group:
            groups.setdefault(group, []).append(edge_index)

    source = backbone.source_entities[0]
    selection = StaticCandidateIndex.from_attribute_backbone(backbone).select(
        source, 1
    )
    query_entities = {source, *selection.candidates}
    mutation_edges = [
        tuple(groups[row["dependency_group"]])
        if row["dependency_group"]
        else (edge_index,)
        for edge_index, row in enumerate(triples)
    ]
    endpoint_invalidations = {
        edge_index
        for edge_index, affected_edges in enumerate(mutation_edges)
        if dependencies.affected_entities(affected_edges, 1) & query_entities
    }

    depth_rows = []
    previous: set[int] = set()
    for depth in range(1, max_depth + 1):
        invalidations = {
            edge_index
            for edge_index, affected_edges in enumerate(mutation_edges)
            if dependencies.affected_entities(
                affected_edges,
                depth,
                normalization_hops=normalization_hops,
            )
            & query_entities
        }
        missed_by_endpoint_rule = invalidations - endpoint_invalidations
        depth_rows.append(
            {
                "depth": depth,
                "invalidating_edge_updates": len(invalidations),
                "safely_reusable_edge_updates": len(triples)
                - len(invalidations),
                "additional_vs_previous_depth": len(invalidations - previous),
                "missed_by_endpoint_rule": len(missed_by_endpoint_rule),
                "endpoint_rule_false_negative_rate": (
                    len(missed_by_endpoint_rule) / len(invalidations)
                    if invalidations
                    else 0.0
                ),
            }
        )
        previous = invalidations

    result = {
        "dataset_dir": str(root),
        "query": {
            "source": source,
            "candidate_count": len(selection.candidates),
            "query_entity_count": len(query_entities),
        },
        "edge_slots": len(triples),
        "dependency_group_count": len(groups),
        "normalization_hops": normalization_hops,
        "depths": depth_rows,
        "semantics": (
            "An update invalidates a query rectangle when an affected edge "
            "endpoint reaches a source/candidate entity within "
            "depth-1+normalization_hops undirected topology hops."
        ),
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def run_snapshot_isolation_audit(
    *,
    update_count: int = 1000,
    reader_count: int = 4,
) -> dict[str, object]:
    """Stress immutable stream snapshots under concurrent readers and writes."""

    if update_count <= 0:
        raise ValueError("update_count must be positive")
    if reader_count <= 0:
        raise ValueError("reader_count must be positive")
    messages = [(1.0, 0.0), (0.0, 2.0)]
    index = IncrementalMomentIndex(messages, [0.4, 0.7])
    stream = VersionedStreamingMomentIndex(index, max_history=32)
    held_version_zero = stream.read_snapshot()
    finished = threading.Event()
    start_barrier = threading.Barrier(reader_count + 1)

    def writer() -> None:
        start_barrier.wait()
        for position in range(update_count):
            stream.apply_event(
                FactEvent(
                    "update",
                    edge_index=position % 2,
                    probability=0.1 + 0.1 * (position % 9),
                    event_time=float(position + 1),
                    observation_time=float(position + 1),
                    event_id=f"snapshot-update-{position}",
                )
            )
        finished.set()

    def reader() -> tuple[int, int, float]:
        start_barrier.wait()
        reads = 0
        violations = 0
        max_rebuild_error = 0.0
        while True:
            snapshot = stream.read_snapshot()
            rebuilt = aggregate_bernoulli_messages(
                snapshot.state.messages,
                snapshot.state.probabilities,
                dependency_groups=snapshot.state.dependency_groups,
            )
            moment_error = max(
                [
                    abs(left - right)
                    for left, right in zip(
                        rebuilt.mean,
                        snapshot.state.moments.mean,
                        strict=True,
                    )
                ]
                + [
                    abs(left - right)
                    for rebuilt_row, snapshot_row in zip(
                        rebuilt.covariance,
                        snapshot.state.moments.covariance,
                        strict=True,
                    )
                    for left, right in zip(
                        rebuilt_row, snapshot_row, strict=True
                    )
                ]
            )
            reads += 1
            max_rebuild_error = max(max_rebuild_error, moment_error)
            violations += moment_error > 1e-12
            if finished.is_set():
                return reads, violations, max_rebuild_error

    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=reader_count + 1) as executor:
        reader_futures = [
            executor.submit(reader) for _ in range(reader_count)
        ]
        writer_future = executor.submit(writer)
        writer_future.result()
        reader_results = [future.result() for future in reader_futures]
    elapsed = time.perf_counter() - started
    try:
        stream.read_snapshot(0)
        version_zero_retained = True
    except ValueError:
        version_zero_retained = False

    return {
        "update_count": update_count,
        "reader_count": reader_count,
        "snapshot_reads": sum(row[0] for row in reader_results),
        "commit_consistency_violations": sum(
            row[1] for row in reader_results
        ),
        "max_rebuild_moment_error": max(
            row[2] for row in reader_results
        ),
        "final_version": stream.read_snapshot().version,
        "elapsed_seconds": elapsed,
        "held_old_snapshot": {
            "version": held_version_zero.version,
            "probabilities": list(held_version_zero.state.probabilities),
            "still_immutable": (
                held_version_zero.version == 0
                and held_version_zero.state.probabilities == (0.4, 0.7)
            ),
            "version_zero_still_in_retained_history": version_zero_retained,
        },
        "contract": (
            "Readers pin an immutable committed MomentIndexSnapshot; writers "
            "publish a new version atomically under the stream lock."
        ),
    }


def run_trustworthy_demo() -> dict[str, object]:
    calibration_probabilities = [0.95, 0.82, 0.76, 0.65, 0.35, 0.22, 0.12, 0.05]
    calibration_labels = [1, 1, 1, 1, 0, 0, 0, 0]
    temperature = fit_temperature(calibration_probabilities, calibration_labels)
    calibrated = [
        apply_temperature(probability, temperature)
        for probability in calibration_probabilities
    ]
    candidate_set = conformal_candidate_set(
        [0.95, 0.82, 0.76, 0.65],
        {"t:alice": 0.84, "t:bob": 0.31, "t:city": 0.14},
        alpha=0.2,
    )
    coverage = evaluate_conformal_coverage(
        [0.95, 0.82, 0.76, 0.65],
        [
            ("a", {"a": 0.91, "b": 0.44, "c": 0.18}),
            ("b", {"a": 0.35, "b": 0.79, "c": 0.21}),
            ("c", {"a": 0.72, "b": 0.61, "c": 0.68}),
            ("a", {"a": 0.62, "b": 0.58, "c": 0.17}),
            ("b", {"a": 0.81, "b": 0.64, "c": 0.12}),
        ],
        alpha=0.2,
    )
    return {
        "temperature": temperature,
        "before": {
            "brier": brier_score(
                calibration_probabilities, calibration_labels
            ),
            "log_loss": log_loss(
                calibration_probabilities, calibration_labels
            ),
            "ece": expected_calibration_error(
                calibration_probabilities, calibration_labels, bins=4
            ),
        },
        "after": {
            "brier": brier_score(calibrated, calibration_labels),
            "log_loss": log_loss(calibrated, calibration_labels),
            "ece": expected_calibration_error(
                calibrated, calibration_labels, bins=4
            ),
        },
        "conformal_candidates": [str(value) for value in candidate_set.candidates],
        "conformal_score_threshold": candidate_set.score_threshold,
        "alpha": 0.2,
        "coverage": {
            "target": coverage.target_coverage,
            "empirical": coverage.empirical_coverage,
            "average_set_size": coverage.average_set_size,
            "empty_set_rate": coverage.empty_set_rate,
            "test_queries": coverage.test_queries,
        },
    }


def _alignment_probability_rows(
    dataset_dir: Path,
) -> tuple[
    list[str],
    list[str],
    dict[str, str],
    list[tuple[float, ...]],
    dict[str, int],
]:
    backbone = AttributeStructuralBackbone.from_dataset(dataset_dir)
    probabilities = tuple(
        float(row["confidence"]) for row in backbone.triples
    )
    scores = backbone.score_expected(probabilities)
    sources = list(backbone.source_entities)
    targets = list(backbone.target_entities)
    with (dataset_dir / "alignments.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        alignments = list(csv.DictReader(handle, delimiter="\t"))
    truth = {
        row["source_entity_id"]: row["target_entity_id"]
        for row in alignments
    }
    rows = [
        tuple(scores[(source, target)] for target in targets)
        for source in sources
    ]
    degrees = {source: 0 for source in sources}
    for triple in backbone.triples:
        if triple["head_id"] in degrees:
            degrees[triple["head_id"]] += 1
        if triple["tail_id"] in degrees:
            degrees[triple["tail_id"]] += 1
    return sources, targets, truth, rows, degrees


def _multiclass_metrics(
    rows: list[tuple[float, ...]],
    true_indices: list[int],
) -> dict[str, float]:
    top_confidences = [max(row) for row in rows]
    correct = [
        int(max(range(len(row)), key=row.__getitem__) == true_index)
        for row, true_index in zip(rows, true_indices, strict=True)
    ]
    return {
        "top1_accuracy": sum(correct) / len(correct),
        "top_label_ece": expected_calibration_error(
            top_confidences, correct, bins=10
        ),
        "multiclass_brier": multiclass_brier_score(rows, true_indices),
        "multiclass_log_loss": multiclass_log_loss(rows, true_indices),
        "mean_true_candidate_probability": sum(
            row[true_index]
            for row, true_index in zip(rows, true_indices, strict=True)
        )
        / len(rows),
    }


def _input_confidence_distortion(dataset_dir: Path) -> dict[str, object]:
    truth_path = dataset_dir / "latent_truth.tsv"
    if not truth_path.is_file():
        return {
            "available": False,
            "interpretation": (
                "No latent probability file; input-confidence calibration "
                "cannot be audited from deterministic triples alone."
            ),
        }
    with truth_path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    errors = [
        abs(float(row["observed_confidence"])
            - float(row["true_probability"]))
        for row in rows
    ]
    return {
        "available": True,
        "fact_count": len(rows),
        "mean_absolute_probability_distortion": sum(errors) / len(errors),
        "maximum_absolute_probability_distortion": max(errors),
        "interpretation": (
            "This compares exposed fact confidence with latent edge "
            "probability; it is not output alignment calibration."
        ),
    }


def _conformal_scenario(
    sources: list[str],
    targets: list[str],
    truth: dict[str, str],
    probability_rows: list[tuple[float, ...]],
    calibration_indices: list[int],
    test_indices: list[int],
    *,
    alpha: float,
) -> dict[str, object]:
    target_index = {target: index for index, target in enumerate(targets)}
    calibration_true_scores = [
        probability_rows[index][target_index[truth[sources[index]]]]
        for index in calibration_indices
    ]
    queries = [
        (
            truth[sources[index]],
            dict(zip(targets, probability_rows[index], strict=True)),
        )
        for index in test_indices
    ]
    coverage = evaluate_conformal_coverage(
        calibration_true_scores, queries, alpha=alpha
    )

    candidate_sets = {}
    ranked_edges = []
    for index, (_, candidate_scores) in zip(
        test_indices, queries, strict=True
    ):
        source = sources[index]
        candidate_set = conformal_candidate_set(
            calibration_true_scores, candidate_scores, alpha=alpha
        )
        candidate_sets[source] = candidate_set.candidates
        ranked_edges.extend(
            (candidate_scores[target], source, target)
            for target in candidate_set.candidates
        )
    assigned_sources: set[str] = set()
    assigned_targets: set[str] = set()
    assignment: dict[str, str] = {}
    for _, source, target in sorted(
        ranked_edges, key=lambda item: (-item[0], item[1], item[2])
    ):
        if source in assigned_sources or target in assigned_targets:
            continue
        assigned_sources.add(source)
        assigned_targets.add(target)
        assignment[source] = target

    return {
        "target_coverage": coverage.target_coverage,
        "empirical_coverage": coverage.empirical_coverage,
        "average_set_size": coverage.average_set_size,
        "empty_set_rate": coverage.empty_set_rate,
        "test_queries": coverage.test_queries,
        "score_threshold": conformal_candidate_set(
            calibration_true_scores,
            dict(zip(targets, probability_rows[test_indices[0]], strict=True)),
            alpha=alpha,
        ).score_threshold,
        "greedy_one_to_one_point_assignment": {
            "assigned_queries": len(assignment),
            "top1_accuracy": sum(
                assignment.get(source) == truth[source]
                for source in (sources[index] for index in test_indices)
            )
            / len(test_indices),
            "warning": (
                "Greedy global uniqueness is a post-hoc heuristic and does "
                "not inherit the marginal conformal coverage guarantee."
            ),
        },
    }


def _grouped_conformal_scenario(
    sources: list[str],
    targets: list[str],
    truth: dict[str, str],
    probability_rows: list[tuple[float, ...]],
    calibration_indices: list[int],
    test_indices: list[int],
    groups: dict[int, str],
    *,
    alpha: float,
) -> dict[str, object]:
    target_index = {target: index for index, target in enumerate(targets)}
    calibration_scores: dict[str, list[float]] = {}
    for index in calibration_indices:
        calibration_scores.setdefault(groups[index], []).append(
            probability_rows[index][target_index[truth[sources[index]]]]
        )
    per_group = {}
    total_covered = 0
    total_size = 0
    total_empty = 0
    for group in sorted(set(groups[index] for index in test_indices)):
        members = [index for index in test_indices if groups[index] == group]
        if group not in calibration_scores:
            raise ValueError(
                f"no conformal calibration queries for group: {group}"
            )
        queries = [
            (
                truth[sources[index]],
                dict(zip(targets, probability_rows[index], strict=True)),
            )
            for index in members
        ]
        report = evaluate_conformal_coverage(
            calibration_scores[group], queries, alpha=alpha
        )
        per_group[group] = {
            "calibration_queries": len(calibration_scores[group]),
            "test_queries": len(members),
            "empirical_coverage": report.empirical_coverage,
            "average_set_size": report.average_set_size,
            "empty_set_rate": report.empty_set_rate,
        }
        total_covered += round(report.empirical_coverage * len(members))
        total_size += report.average_set_size * len(members)
        total_empty += round(report.empty_set_rate * len(members))
    count = len(test_indices)
    return {
        "target_coverage": 1.0 - alpha,
        "empirical_coverage": total_covered / count,
        "average_set_size": total_size / count,
        "empty_set_rate": total_empty / count,
        "conditioning": "source-degree tertile (Mondrian split conformal)",
        "per_group": per_group,
    }


def _adaptive_conformal_scenario(
    targets: list[str],
    true_indices: list[int],
    calibration_rows: list[tuple[float, ...]],
    test_rows: list[tuple[float, ...]],
    calibration_indices: list[int],
    test_indices: list[int],
    *,
    alpha: float,
    regularization: float,
    regularization_rank: int,
) -> dict[str, object]:
    calibration_subset = [
        calibration_rows[index] for index in calibration_indices
    ]
    calibration_truth = [
        true_indices[index] for index in calibration_indices
    ]
    covered = 0
    total_size = 0
    empty = 0
    quantile = None
    for index in test_indices:
        candidate_set = adaptive_conformal_candidate_set(
            calibration_subset,
            calibration_truth,
            dict(zip(targets, test_rows[index], strict=True)),
            alpha=alpha,
            regularization=regularization,
            regularization_rank=regularization_rank,
        )
        quantile = candidate_set.quantile
        covered += targets[true_indices[index]] in candidate_set.candidates
        total_size += len(candidate_set.candidates)
        empty += not candidate_set.candidates
    count = len(test_indices)
    return {
        "method": "APS" if regularization == 0.0 else "RAPS",
        "target_coverage": 1.0 - alpha,
        "empirical_coverage": covered / count,
        "average_set_size": total_size / count,
        "empty_set_rate": empty / count,
        "test_queries": count,
        "quantile": quantile,
        "regularization": regularization,
        "regularization_rank": regularization_rank,
    }


def _margin_conformal_scenario(
    targets: list[str],
    true_indices: list[int],
    calibration_rows: list[tuple[float, ...]],
    test_rows: list[tuple[float, ...]],
    calibration_indices: list[int],
    test_indices: list[int],
    *,
    alpha: float,
) -> dict[str, object]:
    calibration_subset = [
        calibration_rows[index] for index in calibration_indices
    ]
    calibration_truth = [
        true_indices[index] for index in calibration_indices
    ]
    covered = 0
    total_size = 0
    quantile = None
    for index in test_indices:
        candidate_set = margin_conformal_candidate_set(
            calibration_subset,
            calibration_truth,
            dict(zip(targets, test_rows[index], strict=True)),
            alpha=alpha,
        )
        quantile = candidate_set.quantile
        covered += targets[true_indices[index]] in candidate_set.candidates
        total_size += len(candidate_set.candidates)
    count = len(test_indices)
    return {
        "method": "top-score margin split conformal",
        "target_coverage": 1.0 - alpha,
        "empirical_coverage": covered / count,
        "average_set_size": total_size / count,
        "empty_set_rate": 0.0,
        "test_queries": count,
        "quantile": quantile,
    }


def _strict_assignment_metrics(
    probability_rows: list[tuple[float, ...]],
    true_indices: list[int],
) -> dict[str, object]:
    assignment = maximum_weight_injective_assignment(probability_rows)
    correct = sum(
        column == true_index
        for column, true_index in zip(
            assignment, true_indices, strict=True
        )
    )
    unconstrained = sum(
        max(range(len(row)), key=row.__getitem__) == true_index
        for row, true_index in zip(
            probability_rows, true_indices, strict=True
        )
    )
    return {
        "query_count": len(probability_rows),
        "unique_assigned_targets": len(set(assignment)),
        "unconstrained_top1_accuracy": unconstrained
        / len(probability_rows),
        "maximum_weight_one_to_one_accuracy": correct
        / len(probability_rows),
        "singleton_set_coverage": correct / len(probability_rows),
        "coverage_warning": (
            "A strict global point assignment has set size one but does not "
            "inherit split-conformal marginal coverage."
        ),
    }


def run_trustworthy_real_validation(
    dataset_dir: str | Path,
    shifted_dataset_dir: str | Path,
    *,
    alpha: float = 0.1,
    seed: int = 17,
    repeat_count: int = 25,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Audit alignment calibration and conformal coverage under dataset shift."""

    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha must be in (0, 1)")
    if repeat_count <= 0:
        raise ValueError("repeat_count must be positive")
    base = Path(dataset_dir).resolve()
    shifted = Path(shifted_dataset_dir).resolve()
    (
        sources,
        targets,
        truth,
        base_logits,
        degrees,
    ) = _alignment_probability_rows(base)
    (
        shifted_sources,
        shifted_targets,
        shifted_truth,
        shifted_logits,
        _,
    ) = _alignment_probability_rows(shifted)
    if (
        sources != shifted_sources
        or targets != shifted_targets
        or truth != shifted_truth
    ):
        raise ValueError(
            "base and shifted datasets must share identical alignment scope"
        )
    if len(sources) < 12:
        raise ValueError("real validation requires at least 12 aligned queries")

    target_index = {target: index for index, target in enumerate(targets)}
    true_indices = [target_index[truth[source]] for source in sources]
    order = list(range(len(sources)))
    random.Random(seed).shuffle(order)
    temperature_count = max(4, len(order) // 4)
    conformal_count = max(4, len(order) // 3)
    temperature_indices = order[:temperature_count]
    calibration_indices = order[
        temperature_count : temperature_count + conformal_count
    ]
    test_indices = order[temperature_count + conformal_count :]
    if not test_indices:
        raise ValueError("split allocation left no test queries")

    temperature = fit_multiclass_temperature(
        [base_logits[index] for index in temperature_indices],
        [true_indices[index] for index in temperature_indices],
    )
    uncalibrated = [
        softmax_probabilities(row, 1.0) for row in base_logits
    ]
    calibrated = [
        softmax_probabilities(row, temperature) for row in base_logits
    ]
    shifted_calibrated = [
        softmax_probabilities(row, temperature) for row in shifted_logits
    ]

    base_test_rows = [calibrated[index] for index in test_indices]
    shift_test_rows = [shifted_calibrated[index] for index in test_indices]
    test_truth = [true_indices[index] for index in test_indices]
    degree_groups = {}
    all_degree_order = sorted(
        range(len(sources)), key=lambda index: degrees[sources[index]]
    )
    group_names = ("low", "medium", "high")
    for position, index in enumerate(all_degree_order):
        degree_groups[index] = group_names[
            min(2, position * 3 // len(all_degree_order))
        ]
    strata: dict[str, dict[str, float | int]] = {}
    degree_order = sorted(test_indices, key=lambda index: degrees[sources[index]])
    for position, name in enumerate(("low", "medium", "high")):
        start = position * len(degree_order) // 3
        end = (position + 1) * len(degree_order) // 3
        members = degree_order[start:end]
        metrics = _multiclass_metrics(
            [calibrated[index] for index in members],
            [true_indices[index] for index in members],
        )
        strata[name] = {
            "query_count": len(members),
            "minimum_source_degree": min(
                degrees[sources[index]] for index in members
            ),
            "maximum_source_degree": max(
                degrees[sources[index]] for index in members
            ),
            **metrics,
        }

    repeat_matched_coverages = []
    repeat_shifted_coverages = []
    repeat_matched_sizes = []
    repeat_shifted_sizes = []
    repeat_margin_matched_coverages = []
    repeat_margin_matched_sizes = []
    repeat_margin_shift_coverages = []
    repeat_margin_shift_sizes = []
    for repeat in range(repeat_count):
        repeat_order = list(range(len(sources)))
        random.Random(seed + 1009 * repeat).shuffle(repeat_order)
        temp = repeat_order[:temperature_count]
        conf = repeat_order[
            temperature_count : temperature_count + conformal_count
        ]
        test = repeat_order[temperature_count + conformal_count :]
        fitted = fit_multiclass_temperature(
            [base_logits[index] for index in temp],
            [true_indices[index] for index in temp],
        )
        base_rows = [
            softmax_probabilities(row, fitted) for row in base_logits
        ]
        shift_rows = [
            softmax_probabilities(row, fitted) for row in shifted_logits
        ]
        matched_report = _conformal_scenario(
            sources,
            targets,
            truth,
            base_rows,
            conf,
            test,
            alpha=alpha,
        )
        shifted_report = _conformal_scenario(
            sources,
            targets,
            truth,
            shift_rows,
            conf,
            test,
            alpha=alpha,
        )
        repeat_matched_coverages.append(
            float(matched_report["empirical_coverage"])
        )
        repeat_shifted_coverages.append(
            float(shifted_report["empirical_coverage"])
        )
        repeat_matched_sizes.append(
            float(matched_report["average_set_size"])
        )
        repeat_shifted_sizes.append(
            float(shifted_report["average_set_size"])
        )
        margin_matched = _margin_conformal_scenario(
            targets,
            true_indices,
            base_rows,
            base_rows,
            conf,
            test,
            alpha=alpha,
        )
        margin_shift = _margin_conformal_scenario(
            targets,
            true_indices,
            base_rows,
            shift_rows,
            conf,
            test,
            alpha=alpha,
        )
        repeat_margin_matched_coverages.append(
            float(margin_matched["empirical_coverage"])
        )
        repeat_margin_matched_sizes.append(
            float(margin_matched["average_set_size"])
        )
        repeat_margin_shift_coverages.append(
            float(margin_shift["empirical_coverage"])
        )
        repeat_margin_shift_sizes.append(
            float(margin_shift["average_set_size"])
        )

    result = {
        "dataset_dir": str(base),
        "shifted_dataset_dir": str(shifted),
        "scope": {
            "query_count": len(sources),
            "candidate_count": len(targets),
            "split": {
                "temperature_fit": len(temperature_indices),
                "conformal_calibration": len(calibration_indices),
                "test": len(test_indices),
                "query_disjoint": True,
            },
            "output_semantics": (
                "softmax-normalized alignment candidate scores; distinct "
                "from input triple confidence"
            ),
        },
        "input_confidence_audit": {
            "base": _input_confidence_distortion(base),
            "shifted": _input_confidence_distortion(shifted),
        },
        "temperature_scaling": {
            "temperature": temperature,
            "uncalibrated_test": _multiclass_metrics(
                [uncalibrated[index] for index in test_indices],
                test_truth,
            ),
            "calibrated_test": _multiclass_metrics(
                base_test_rows, test_truth
            ),
            "shifted_test_using_base_temperature": _multiclass_metrics(
                shift_test_rows, test_truth
            ),
        },
        "degree_stratified_calibration": strata,
        "conformal": {
            "alpha": alpha,
            "matched": _conformal_scenario(
                sources,
                targets,
                truth,
                calibrated,
                calibration_indices,
                test_indices,
                alpha=alpha,
            ),
            "shifted": _conformal_scenario(
                sources,
                targets,
                truth,
                shifted_calibrated,
                calibration_indices,
                test_indices,
                alpha=alpha,
            ),
            "degree_conditioned_matched": _grouped_conformal_scenario(
                sources,
                targets,
                truth,
                calibrated,
                calibration_indices,
                test_indices,
                degree_groups,
                alpha=alpha,
            ),
            "degree_conditioned_shifted": _grouped_conformal_scenario(
                sources,
                targets,
                truth,
                shifted_calibrated,
                calibration_indices,
                test_indices,
                degree_groups,
                alpha=alpha,
            ),
            "adaptive_prediction_sets": {
                "aps_matched": _adaptive_conformal_scenario(
                    targets,
                    true_indices,
                    calibrated,
                    calibrated,
                    calibration_indices,
                    test_indices,
                    alpha=alpha,
                    regularization=0.0,
                    regularization_rank=5,
                ),
                "aps_shifted_recalibrated": _adaptive_conformal_scenario(
                    targets,
                    true_indices,
                    shifted_calibrated,
                    shifted_calibrated,
                    calibration_indices,
                    test_indices,
                    alpha=alpha,
                    regularization=0.0,
                    regularization_rank=5,
                ),
                "aps_shifted_base_calibration": _adaptive_conformal_scenario(
                    targets,
                    true_indices,
                    calibrated,
                    shifted_calibrated,
                    calibration_indices,
                    test_indices,
                    alpha=alpha,
                    regularization=0.0,
                    regularization_rank=5,
                ),
                "raps_matched_fixed": _adaptive_conformal_scenario(
                    targets,
                    true_indices,
                    calibrated,
                    calibrated,
                    calibration_indices,
                    test_indices,
                    alpha=alpha,
                    regularization=0.01,
                    regularization_rank=5,
                ),
                "raps_shifted_base_calibration_fixed": (
                    _adaptive_conformal_scenario(
                        targets,
                        true_indices,
                        calibrated,
                        shifted_calibrated,
                        calibration_indices,
                        test_indices,
                        alpha=alpha,
                        regularization=0.01,
                        regularization_rank=5,
                    )
                ),
                "guarantee_boundary": (
                    "APS/RAPS marginal coverage requires exchangeability "
                    "between conformal calibration and test queries. The "
                    "base-calibration/shifted-test case is diagnostic only."
                ),
            },
            "margin_prediction_sets": {
                "matched": _margin_conformal_scenario(
                    targets,
                    true_indices,
                    calibrated,
                    calibrated,
                    calibration_indices,
                    test_indices,
                    alpha=alpha,
                ),
                "shifted_base_calibration": _margin_conformal_scenario(
                    targets,
                    true_indices,
                    calibrated,
                    shifted_calibrated,
                    calibration_indices,
                    test_indices,
                    alpha=alpha,
                ),
                "guarantee_boundary": (
                    "Matched marginal coverage uses disjoint exchangeable "
                    "calibration/test queries. Base-calibration/shifted-test "
                    "coverage is diagnostic and not guaranteed."
                ),
            },
            "strict_one_to_one_pressure": {
                "matched": _strict_assignment_metrics(
                    base_test_rows, test_truth
                ),
                "shifted": _strict_assignment_metrics(
                    shift_test_rows, test_truth
                ),
            },
            "split_sensitivity": {
                "repeat_count": repeat_count,
                "matched_coverage_mean": statistics.mean(
                    repeat_matched_coverages
                ),
                "matched_coverage_min": min(repeat_matched_coverages),
                "matched_coverage_max": max(repeat_matched_coverages),
                "shifted_coverage_mean": statistics.mean(
                    repeat_shifted_coverages
                ),
                "shifted_coverage_min": min(repeat_shifted_coverages),
                "shifted_coverage_max": max(repeat_shifted_coverages),
                "matched_average_set_size_mean": statistics.mean(
                    repeat_matched_sizes
                ),
                "shifted_average_set_size_mean": statistics.mean(
                    repeat_shifted_sizes
                ),
                "margin_matched_coverage_mean": statistics.mean(
                    repeat_margin_matched_coverages
                ),
                "margin_matched_coverage_min": min(
                    repeat_margin_matched_coverages
                ),
                "margin_matched_average_set_size_mean": statistics.mean(
                    repeat_margin_matched_sizes
                ),
                "margin_shifted_base_calibration_coverage_mean": (
                    statistics.mean(repeat_margin_shift_coverages)
                ),
                "margin_shifted_base_calibration_coverage_min": min(
                    repeat_margin_shift_coverages
                ),
                "margin_shifted_base_calibration_average_set_size_mean": (
                    statistics.mean(repeat_margin_shift_sizes)
                ),
            },
            "claim_boundary": (
                "Finite-sample marginal coverage requires exchangeability. "
                "The shifted result is a stress test, not a guaranteed regime."
            ),
        },
    }
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(
                f"Output already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result
