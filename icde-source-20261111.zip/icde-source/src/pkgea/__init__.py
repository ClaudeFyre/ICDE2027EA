"""Shared research infrastructure for probabilistic KG entity alignment."""

__version__ = "0.1.0"

