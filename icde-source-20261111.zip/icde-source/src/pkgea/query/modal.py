"""Conservative ModalTop1 pilot; inherits WSDM certification unchanged.

No cross-revision reuse or planner authorization is implemented here. The
scorer adapter must honor the declared snapshot and return original precision.
"""

from __future__ import annotations

import hashlib
import json
import math
from array import array
from collections import OrderedDict
from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict, dataclass

from pkgea.certified import PairwiseWinnerState
from pkgea.samplers import WorldSample


def identity(value: object) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(encoded.encode()).hexdigest()


@dataclass(frozen=True)
class ModalSnapshot:
    graph: str
    model: str
    probability: str
    factors: str
    schema: str
    code: str
    scorer: str

    def __post_init__(self) -> None:
        if any(not isinstance(v, str) or not v for v in asdict(self).values()):
            raise ValueError("all snapshot identities must be nonempty strings")

    @property
    def digest(self) -> str:
        return identity(asdict(self))


@dataclass(frozen=True)
class IIDWorldStream:
    """An adapter declaration of iid worlds, with unique draw positions.

    Equal graph states at distinct draw positions are legitimate iid outcomes.
    A repeated read of one position is never appended as a new observation.
    This class checks metadata, not the statistical truth of the declaration.
    """

    snapshot_digest: str
    seed: int
    worlds: tuple[WorldSample, ...]
    factor_law: tuple = ()

    def __post_init__(self) -> None:
        if type(self.worlds) is not tuple or not self.worlds or not self.snapshot_digest:
            raise ValueError("stream and snapshot must be nonempty")
        edge_count = len(self.worlds[0].state)
        for world in self.worlds:
            if world.origin != "S1_MC" or world.weight != self.worlds[0].weight:
                raise ValueError("only unweighted full iid MC is admitted to the CS pilot")
            if not math.isfinite(world.weight) or world.weight <= 0:
                raise ValueError("invalid world weight")
            if len(world.state) != edge_count or any(type(v) is not bool for v in world.state):
                raise ValueError("inconsistent world state")

    @property
    def digest(self) -> str:
        payload: dict[str, object] = {
            "snapshot": self.snapshot_digest,
            "seed": self.seed,
            "states": [w.state for w in self.worlds],
            "sampler": "S1_MC",
        }
        # Bind the shared-factor law only when it is non-trivial, so the v1
        # independent stream digest stays byte-identical.
        if self.factor_law:
            payload["factor_law"] = list(self.factor_law)
        return identity(payload)


@dataclass(frozen=True)
class ModalQuery:
    source: str
    candidates: tuple[str, ...]
    snapshot_digest: str
    budget: int = 256
    delta: float = 0.05

    def __post_init__(self) -> None:
        if (
            not isinstance(self.source, str)
            or not isinstance(self.snapshot_digest, str)
            or not self.source
            or not self.snapshot_digest
        ):
            raise ValueError("source and snapshot are required")
        if (
            type(self.candidates) is not tuple
            or not self.candidates
            or any(not isinstance(c, str) or not c for c in self.candidates)
        ):
            raise ValueError("nonempty string candidates are required")
        if len(set(self.candidates)) != len(self.candidates):
            raise ValueError("candidates must be unique")
        if type(self.budget) is not int or self.budget <= 0 or not 0 < self.delta < 1:
            raise ValueError("invalid budget or delta")


def world_winner(scores: Mapping[str, float], candidates: Sequence[str]) -> str:
    """Original-precision argmax, lexical-ID ties (inherited WSDM convention)."""
    if any(c not in scores or not math.isfinite(scores[c]) for c in candidates):
        raise ValueError("missing or nonfinite candidate score")
    return min(candidates, key=lambda c: (-scores[c], c))


class WinnerBlockCache:
    """LRU over immutable uint32 winner blocks; budget counts label payload only."""

    def __init__(self, capacity_bytes: int) -> None:
        if type(capacity_bytes) is not int or capacity_bytes < 0:
            raise ValueError("capacity must be a nonnegative integer")
        if array("I").itemsize != 4:
            raise ValueError("this pilot requires four-byte unsigned label storage")
        self.capacity_bytes = capacity_bytes
        self.payload_bytes = 0
        self.peak_payload_bytes = 0
        self.evictions = 0
        self._blocks: OrderedDict[tuple, bytes] = OrderedDict()

    def get(self, key: tuple) -> tuple[int, ...] | None:
        if key not in self._blocks:
            return None
        self._blocks.move_to_end(key)
        values = array("I")
        values.frombytes(self._blocks[key])
        return tuple(values)

    def put(self, key: tuple, labels: Sequence[int]) -> None:
        payload = array("I", labels).tobytes()
        if len(payload) > self.capacity_bytes:
            return
        previous = self._blocks.pop(key, None)
        if previous is not None:
            self.payload_bytes -= len(previous)
        while self.payload_bytes + len(payload) > self.capacity_bytes:
            _, removed = self._blocks.popitem(last=False)
            self.payload_bytes -= len(removed)
            self.evictions += 1
        self._blocks[key] = payload
        self.payload_bytes += len(payload)
        self.peak_payload_bytes = max(self.peak_payload_bytes, self.payload_bytes)


ScoreBatch = Callable[
    [tuple[bool, ...], tuple[str, ...], tuple[str, ...]], Mapping[tuple[str, str], float]
]


@dataclass(frozen=True)
class ModalScorer:
    snapshot_digest: str
    score_batch: ScoreBatch

    def __post_init__(self) -> None:
        if not self.snapshot_digest or not callable(self.score_batch):
            raise ValueError("scorer snapshot and callable are required")


def execute_modal_queries(
    queries: Sequence[ModalQuery],
    snapshot: ModalSnapshot,
    stream: IIDWorldStream,
    scorer: ModalScorer,
    *,
    cache: WinnerBlockCache | None = None,
    shared: bool = True,
    batch_size: int = 16,
    minimum_samples: int = 32,
) -> dict[str, object]:
    """Execute at a fixed checkpoint grid, caching labels without a dense tensor.

    Shared execution scores the missing source/candidate rectangle per world.
    Rectangle over-computation is charged as candidate evaluations. Cache keys
    include the entire snapshot, stream, source, candidate order and draw range.
    """
    if (
        not queries
        or type(batch_size) is not int
        or type(minimum_samples) is not int
        or batch_size <= 0
        or minimum_samples <= 0
    ):
        raise ValueError("queries and positive checkpoint settings are required")
    if stream.snapshot_digest != snapshot.digest:
        raise ValueError("stale world stream")
    if scorer.snapshot_digest != snapshot.digest:
        raise ValueError("stale scorer snapshot")
    for q in queries:
        if q.snapshot_digest != snapshot.digest:
            raise ValueError("stale query snapshot")
        if q.budget > len(stream.worlds):
            raise ValueError("stream shorter than query budget")
    stream_id = stream.digest
    states = [PairwiseWinnerState(q.source, q.candidates, delta=q.delta) for q in queries]
    histories: list[list[dict]] = [[] for _ in queries]
    consumed: list[list[str]] = [[] for _ in queries]
    work = {
        "scorer_calls": 0,
        "candidate_evaluations": 0,
        "cache_label_reads": 0,
        "computed_winner_labels": 0,
        "query_world_observations": 0,
        "ahead_worlds": 0,
    }
    for start in range(0, max(q.budget for q in queries), batch_size):
        blocks = {}
        misses = []
        keys = {}
        for i, (q, state) in enumerate(zip(queries, states, strict=True)):
            if state.stable or start >= q.budget:
                continue
            stop = min(start + batch_size, q.budget)
            key = (
                snapshot.digest,
                stream_id,
                q.source,
                q.candidates,
                start,
                stop,
                "original-precision-lexical-tie-v1",
            )
            keys[i] = key
            block = cache.get(key) if cache is not None else None
            if block is None:
                misses.append(i)
            else:
                blocks[i] = block
                work["cache_label_reads"] += len(block)
        groups = [misses] if shared and misses else [[i] for i in misses]
        for group in groups:
            sources = tuple(dict.fromkeys(queries[i].source for i in group))
            targets = tuple(dict.fromkeys(c for i in group for c in queries[i].candidates))
            labels: dict[int, list[int]] = {i: [] for i in group}
            stop = max(min(start + batch_size, queries[i].budget) for i in group)
            for position in range(start, stop):
                scores = scorer.score_batch(stream.worlds[position].state, sources, targets)
                work["scorer_calls"] += 1
                work["candidate_evaluations"] += len(sources) * len(targets)
                for i in group:
                    q = queries[i]
                    if position >= q.budget:
                        work["ahead_worlds"] += 1
                        continue
                    row = {c: scores[(q.source, c)] for c in q.candidates}
                    labels[i].append(q.candidates.index(world_winner(row, q.candidates)))
                    work["computed_winner_labels"] += 1
            for i in group:
                blocks[i] = tuple(labels[i])
                if cache is not None:
                    cache.put(keys[i], blocks[i])
        for i, block in blocks.items():
            q, state = queries[i], states[i]
            winners = [q.candidates[label] for label in block]
            state.update(
                winners, evaluate_certificate=state.samples + len(block) >= minimum_samples
            )
            consumed[i].extend(winners)
            work["query_world_observations"] += len(block)
            histories[i].append(
                {
                    "samples": state.samples,
                    "counts": dict(state.counts),
                    "stable": state.stable,
                    "winner": state.estimated_winner,
                }
            )
    results = []
    for q, state, history, winners in zip(queries, states, histories, consumed, strict=True):
        result = state.result(exhausted=True).as_dict()
        result.update(
            {
                "stable": state.stable,
                "snapshot": asdict(snapshot),
                "snapshot_digest": snapshot.digest,
                "stream_digest": stream_id,
                "candidate_order": q.candidates,
                "checkpoint_history": history,
                "counts": dict(state.counts),
                "evidence_digest": identity(
                    {
                        "query": asdict(q),
                        "stream": stream_id,
                        "batch_size": batch_size,
                        "minimum_samples": minimum_samples,
                        "draw_range": [0, state.samples],
                        "winners": winners,
                        "cs": result["confidence_sequence"],
                    }
                ),
            }
        )
        results.append(result)
    return {"format": "pkgea-modal-pilot-v1", "results": results, "work": work}
