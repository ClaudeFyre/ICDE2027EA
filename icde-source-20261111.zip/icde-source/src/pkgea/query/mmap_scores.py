"""Portable dense float32 score matrices with memory-mapped reads."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import gc
import hashlib
import json
import math
import os
import statistics
import tempfile
import time
from pathlib import Path
from typing import Hashable, Sequence

import numpy as np

from pkgea.query.engine import (
    CandidateInterval,
    ProgressiveQueryResult,
    ScoreCache,
    progressive_top_k_from_dense_scores,
    progressive_top_k_from_scores,
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class MemoryMappedScoreIndex:
    """Read-only world×source×target score tensor backed by ``.npy``."""

    FORMAT = "pkgea-memory-mapped-score-index-v1"

    def __init__(
        self,
        directory: Path,
        metadata: dict[str, object],
        scores: np.ndarray,
    ) -> None:
        self.directory = directory
        self.metadata = metadata
        self.scores = scores
        self.sources = tuple(str(value) for value in metadata["sources"])
        self.targets = tuple(str(value) for value in metadata["targets"])
        self._source_positions = {
            source: position for position, source in enumerate(self.sources)
        }
        self._target_positions = {
            target: position for position, target in enumerate(self.targets)
        }

    def close(self) -> None:
        """Release the OS mapping promptly (required before deletion on Windows)."""

        mapping = getattr(self.scores, "_mmap", None)
        if mapping is not None:
            mapping.close()

    def __enter__(self) -> "MemoryMappedScoreIndex":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    @classmethod
    def create_from_score_cache(
        cls,
        cache: ScoreCache,
        directory: str | Path,
        *,
        entry_index: int = 0,
    ) -> "MemoryMappedScoreIndex":
        output = Path(directory).resolve()
        if output.exists():
            raise ValueError(
                f"Memory-mapped score directory already exists: {output}"
            )
        entries = list(cache._cache.items())
        if not 0 <= entry_index < len(entries):
            raise ValueError("score cache entry_index is out of range")
        output.mkdir(parents=True)
        key, matrices = entries[entry_index]
        context_digest, world_digest, backbone_id, sources, targets = key
        shape = (len(matrices), len(sources), len(targets))
        score_path = output / "scores.npy"
        array = np.lib.format.open_memmap(
            score_path,
            mode="w+",
            dtype=np.float32,
            shape=shape,
        )
        for world_index, matrix in enumerate(matrices):
            for source_index, source in enumerate(sources):
                array[world_index, source_index, :] = [
                    matrix[(source, target)] for target in targets
                ]
        array.flush()
        del array
        metadata = {
            "format": cls.FORMAT,
            "dtype": "float32",
            "shape": list(shape),
            "context_digest": context_digest,
            "world_digest": world_digest,
            "backbone_id": backbone_id,
            "sources": list(sources),
            "targets": list(targets),
            "scores_file": "scores.npy",
            "scores_sha256": _sha256(score_path),
        }
        (output / "metadata.json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return cls.load(output, verify_checksum=False)

    @classmethod
    def load(
        cls,
        directory: str | Path,
        *,
        expected_context_digest: str | None = None,
        expected_world_digest: str | None = None,
        verify_checksum: bool = True,
    ) -> "MemoryMappedScoreIndex":
        root = Path(directory).resolve()
        metadata = json.loads(
            (root / "metadata.json").read_text(encoding="utf-8")
        )
        if metadata.get("format") != cls.FORMAT:
            raise ValueError("unsupported memory-mapped score index")
        if metadata.get("dtype") != "float32":
            raise ValueError("unsupported memory-mapped score dtype")
        if (
            expected_context_digest is not None
            and metadata.get("context_digest") != expected_context_digest
        ):
            raise ValueError("stale score index context revision")
        if (
            expected_world_digest is not None
            and metadata.get("world_digest") != expected_world_digest
        ):
            raise ValueError("stale score index world revision")
        score_path = root / str(metadata.get("scores_file"))
        if verify_checksum and _sha256(score_path) != metadata.get(
            "scores_sha256"
        ):
            raise ValueError("memory-mapped score checksum mismatch")
        scores = np.load(score_path, mmap_mode="r", allow_pickle=False)
        expected_shape = tuple(int(value) for value in metadata["shape"])
        if scores.dtype != np.float32 or scores.shape != expected_shape:
            raise ValueError("memory-mapped score tensor shape/dtype mismatch")
        if len(metadata["sources"]) != scores.shape[1] or len(
            metadata["targets"]
        ) != scores.shape[2]:
            raise ValueError("memory-mapped score scopes do not match shape")
        return cls(root, metadata, scores)

    def rectangle(
        self,
        sources: Sequence[Hashable],
        targets: Sequence[Hashable],
        *,
        world_start: int = 0,
        world_stop: int | None = None,
    ) -> np.ndarray:
        """Materialize only a requested world/query rectangle."""

        stop = self.scores.shape[0] if world_stop is None else world_stop
        if not 0 <= world_start <= stop <= self.scores.shape[0]:
            raise ValueError("invalid world slice")
        try:
            source_positions = [
                self._source_positions[str(source)] for source in sources
            ]
            target_positions = [
                self._target_positions[str(target)] for target in targets
            ]
        except KeyError as exc:
            raise ValueError(f"entity is outside score index scope: {exc}") from exc
        if not source_positions or not target_positions:
            raise ValueError("score rectangle scopes cannot be empty")
        view = self.scores[world_start:stop]
        return np.asarray(
            view[:, source_positions, :][:, :, target_positions]
        )

    def progressive_top_k(
        self,
        source: Hashable,
        candidates: Sequence[Hashable],
        *,
        k: int = 1,
        batch_size: int = 32,
        delta: float = 0.05,
        bound_method: str = "hoeffding",
    ) -> ProgressiveQueryResult:
        dense = self.rectangle((source,), candidates)[:, 0, :]
        if bound_method == "paired_empirical_bernstein":
            return progressive_top_k_from_dense_scores(
                dense,
                source,
                candidates,
                k=k,
                batch_size=batch_size,
                delta=delta,
                cache_reused=True,
                bound_method=bound_method,
            )
        if bound_method not in {"hoeffding", "empirical_bernstein"}:
            raise ValueError(f"Unsupported bound method: {bound_method}")
        if not 0 < k <= len(candidates):
            raise ValueError("k must be between 1 and the candidate count")
        if batch_size <= 0 or not 0.0 < delta < 1.0:
            raise ValueError("Invalid batch_size or delta")
        values = np.asarray(dense, dtype=np.float64)
        if values.shape[0] == 0 or values.shape[1] != len(candidates):
            raise ValueError("dense score tensor has the wrong shape")
        if not np.isfinite(values).all() or (values < 0.0).any() or (
            values > 1.0
        ).any():
            raise ValueError(
                "Progressive bounds require finite scores in [0, 1]"
            )
        cumulative = np.cumsum(values, axis=0)
        cumulative_squared = np.cumsum(values * values, axis=0)
        checkpoints = list(range(batch_size, len(values) + 1, batch_size))
        if not checkpoints or checkpoints[-1] != len(values):
            checkpoints.append(len(values))
        candidate_count = max(len(candidates), 1)
        stable = False
        intervals: list[CandidateInterval] = []
        used = 0
        for used in checkpoints:
            totals = cumulative[used - 1]
            estimates = totals / used
            if bound_method == "hoeffding":
                radii = np.full(
                    len(candidates),
                    math.sqrt(
                        math.log(2.0 * candidate_count / delta)
                        / (2.0 * used)
                    ),
                )
            elif used <= 1:
                radii = np.ones(len(candidates))
            else:
                variances = np.maximum(
                    (
                        cumulative_squared[used - 1]
                        - totals * totals / used
                    )
                    / (used - 1),
                    0.0,
                )
                log_term = math.log(3.0 * candidate_count / delta)
                radii = np.minimum(
                    np.sqrt(2.0 * variances * log_term / used)
                    + 3.0 * log_term / used,
                    1.0,
                )
            intervals = sorted(
                (
                    CandidateInterval(
                        candidate=candidate,
                        estimate=float(estimates[position]),
                        lower=max(
                            float(estimates[position] - radii[position]),
                            0.0,
                        ),
                        upper=min(
                            float(estimates[position] + radii[position]),
                            1.0,
                        ),
                    )
                    for position, candidate in enumerate(candidates)
                ),
                key=lambda item: (-item.estimate, str(item.candidate)),
            )
            kth_lower = min(item.lower for item in intervals[:k])
            outside_upper = max(
                (item.upper for item in intervals[k:]),
                default=float("-inf"),
            )
            if kth_lower > outside_upper:
                stable = True
                break
        kth_lower = min(item.lower for item in intervals[:k])
        return ProgressiveQueryResult(
            source=source,
            top_k=tuple(intervals[:k]),
            samples_used=used,
            stable=stable,
            pruned_candidates=sum(
                item.upper < kth_lower for item in intervals[k:]
            ),
            cache_reused=True,
            bound_method=bound_method,
        )


class MMapAutotunePolicy:
    """Revision-bound source-batch choices for a long-running mmap executor."""

    FORMAT = "pkgea-mmap-autotune-policy-v1"

    def __init__(self, payload: dict[str, object]) -> None:
        if payload.get("format") != self.FORMAT:
            raise ValueError("unsupported mmap autotune policy")
        entries = payload.get("entries")
        if not isinstance(entries, list) or not entries:
            raise ValueError("mmap autotune policy must contain entries")
        self.payload = payload
        self._entries = {
            int(entry["world_count"]): dict(entry) for entry in entries
        }
        if len(self._entries) != len(entries):
            raise ValueError("duplicate world_count in mmap autotune policy")

    @classmethod
    def load(
        cls, policy_path: str | Path, mmap_directory: str | Path
    ) -> "MMapAutotunePolicy":
        policy = cls(
            json.loads(Path(policy_path).read_text(encoding="utf-8"))
        )
        root = Path(mmap_directory).resolve()
        metadata_path = root / "metadata.json"
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        binding = policy.payload["binding"]
        if _sha256(metadata_path) != binding["metadata_sha256"]:
            raise ValueError("stale mmap autotune policy metadata revision")
        if metadata.get("scores_sha256") != binding["scores_sha256"]:
            raise ValueError("stale mmap autotune policy score revision")
        if list(metadata.get("shape", [])) != binding["tensor_shape"]:
            raise ValueError("stale mmap autotune policy tensor shape")
        return policy

    def select(self, world_count: int) -> dict[str, object]:
        if world_count <= 0:
            raise ValueError("world_count must be positive")
        entry = self._entries.get(world_count)
        if entry is None:
            return {
                "world_count": world_count,
                "source_batch_size": 1,
                "calibrated": False,
                "reason": "uncalibrated_world_count_safe_fallback",
            }
        return {
            "world_count": world_count,
            "source_batch_size": int(
                entry["recommended_source_batch_size"]
            ),
            "calibrated": True,
            "reason": "exact_shape_policy_hit",
            "calibration_queries_per_second": float(
                entry["recommended_queries_per_second"]
            ),
        }


def build_mmap_autotune_policy(
    mmap_directory: str | Path,
    tuning_artifacts: Sequence[str | Path],
    *,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    """Combine exact-shape tuning results into one revisioned executor policy."""

    if not tuning_artifacts:
        raise ValueError("at least one tuning artifact is required")
    root = Path(mmap_directory).resolve()
    metadata_path = root / "metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    if metadata.get("format") != MemoryMappedScoreIndex.FORMAT:
        raise ValueError("unsupported memory-mapped score index")
    entries = []
    for artifact_path in tuning_artifacts:
        artifact = json.loads(Path(artifact_path).read_text(encoding="utf-8"))
        if artifact.get("format") != "pkgea-mmap-source-batch-tuning-v1":
            raise ValueError("unsupported mmap tuning artifact")
        for field, expected in (
            ("tensor_shape", metadata["shape"]),
            ("dtype", metadata["dtype"]),
            ("context_digest", metadata["context_digest"]),
            ("world_digest", metadata["world_digest"]),
        ):
            if artifact.get(field) != expected:
                raise ValueError(f"mmap tuning artifact {field} mismatch")
        entries.append(
            {
                "world_count": int(artifact["world_count"]),
                "recommended_source_batch_size": int(
                    artifact["recommended_source_batch_size"]
                ),
                "recommended_queries_per_second": float(
                    artifact["recommended_queries_per_second"]
                ),
                "calibration_queries": int(artifact["calibration_queries"]),
                "repeats": int(artifact["repeats"]),
            }
        )
    entries.sort(key=lambda entry: entry["world_count"])
    policy = MMapAutotunePolicy(
        {
            "format": MMapAutotunePolicy.FORMAT,
            "binding": {
                "metadata_sha256": _sha256(metadata_path),
                "scores_sha256": metadata["scores_sha256"],
                "tensor_shape": metadata["shape"],
                "dtype": metadata["dtype"],
                "context_digest": metadata["context_digest"],
                "world_digest": metadata["world_digest"],
            },
            "entries": entries,
            "fallback_source_batch_size": 1,
            "fallback_reason": (
                "Only exact calibrated world counts may use a tuned batch; "
                "other shapes use batch 1."
            ),
        }
    )
    result = policy.payload
    if output_path is not None:
        output = Path(output_path).resolve()
        if output.exists():
            raise ValueError(f"Output already exists: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return result


def benchmark_score_cache_formats(
    score_cache_file: str | Path,
    mmap_directory: str | Path,
    *,
    repeats: int = 5,
) -> dict[str, object]:
    """Convert one cache entry and compare gzip cold load with mmap access."""

    if repeats <= 0:
        raise ValueError("repeats must be positive")
    cache_path = Path(score_cache_file).resolve()
    gzip_loads = []
    cache = None
    for _ in range(repeats):
        started = time.perf_counter()
        loaded = ScoreCache.load(cache_path)
        gzip_loads.append(time.perf_counter() - started)
        if cache is None:
            cache = loaded
        else:
            del loaded
    if cache is None:
        raise AssertionError("score cache load did not execute")

    started = time.perf_counter()
    index = MemoryMappedScoreIndex.create_from_score_cache(
        cache, mmap_directory
    )
    conversion_seconds = time.perf_counter() - started
    key, matrices = list(cache._cache.items())[0]
    sources = key[3]
    targets = key[4]
    source_subset = sources[: min(8, len(sources))]
    target_subset = targets[: min(32, len(targets))]
    expected = np.asarray(
        [
            [
                [matrix[(source, target)] for target in target_subset]
                for source in source_subset
            ]
            for matrix in matrices[: min(64, len(matrices))]
        ],
        dtype=np.float64,
    )
    observed = index.rectangle(
        source_subset,
        target_subset,
        world_stop=min(64, len(matrices)),
    )
    max_absolute_error = float(np.max(np.abs(expected - observed)))
    tensor_shape = list(index.scores.shape)
    started = time.perf_counter()
    mapping_results = [
        progressive_top_k_from_scores(
            matrices,
            source,
            targets,
            k=1,
            batch_size=16,
            bound_method="empirical_bernstein",
        )
        for source in source_subset
    ]
    mapping_query_seconds = time.perf_counter() - started
    started = time.perf_counter()
    mmap_results = [
        index.progressive_top_k(
            source,
            targets,
            k=1,
            batch_size=16,
            bound_method="empirical_bernstein",
        )
        for source in source_subset
    ]
    mmap_query_seconds = time.perf_counter() - started
    progressive_winner_agreement = sum(
        left.top_k[0].candidate == right.top_k[0].candidate
        for left, right in zip(mapping_results, mmap_results, strict=True)
    ) / len(mapping_results)
    progressive_stopping_agreement = sum(
        left.samples_used == right.samples_used
        and left.stable == right.stable
        for left, right in zip(mapping_results, mmap_results, strict=True)
    ) / len(mapping_results)
    del cache
    gc.collect()

    mmap_loads = []
    rectangle_reads = []
    for _ in range(repeats):
        started = time.perf_counter()
        loaded_index = MemoryMappedScoreIndex.load(
            mmap_directory, verify_checksum=False
        )
        mmap_loads.append(time.perf_counter() - started)
        started = time.perf_counter()
        rectangle = loaded_index.rectangle(
            source_subset,
            target_subset,
            world_stop=min(64, loaded_index.scores.shape[0]),
        )
        rectangle_reads.append(time.perf_counter() - started)
        if not np.isfinite(rectangle).all():
            raise ValueError("memory-mapped rectangle contains non-finite scores")
        loaded_index.close()

    mmap_root = Path(mmap_directory).resolve()
    mmap_bytes = sum(
        path.stat().st_size for path in mmap_root.iterdir() if path.is_file()
    )
    result = {
        "score_cache_file": str(cache_path),
        "mmap_directory": str(mmap_root),
        "shape": tensor_shape,
        "gzip_bytes": cache_path.stat().st_size,
        "mmap_bytes": mmap_bytes,
        "mmap_over_gzip_size_ratio": mmap_bytes / cache_path.stat().st_size,
        "conversion_seconds": conversion_seconds,
        "repeats": repeats,
        "median_gzip_cold_load_seconds": statistics.median(gzip_loads),
        "median_mmap_metadata_open_seconds": statistics.median(mmap_loads),
        "median_mmap_rectangle_read_seconds": statistics.median(
            rectangle_reads
        ),
        "cold_open_speedup": statistics.median(gzip_loads)
        / max(statistics.median(mmap_loads), 1e-12),
        "rectangle_shape": list(observed.shape),
        "float32_max_absolute_error": max_absolute_error,
        "progressive_query": {
            "source_count": len(source_subset),
            "candidate_count": len(targets),
            "bound_method": "empirical_bernstein",
            "mapping_seconds": mapping_query_seconds,
            "mmap_dense_seconds": mmap_query_seconds,
            "speedup": mapping_query_seconds
            / max(mmap_query_seconds, 1e-12),
            "winner_agreement": progressive_winner_agreement,
            "stopping_agreement": progressive_stopping_agreement,
        },
        "integrity": {
            "checksum_computed_at_creation": True,
            "benchmark_open_checksum": False,
            "context_digest": index.metadata["context_digest"],
            "world_digest": index.metadata["world_digest"],
            "scores_sha256": index.metadata["scores_sha256"],
        },
        "claim_boundary": (
            "mmap open defers score-page IO; checksum-disabled cold-open "
            "latency is not a full-file integrity scan."
        ),
    }
    report_path = mmap_root / "benchmark.json"
    descriptor, temporary_name = tempfile.mkstemp(
        dir=mmap_root,
        prefix=".benchmark.",
        suffix=".tmp",
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temporary_name, report_path)
    except BaseException:
        Path(temporary_name).unlink(missing_ok=True)
        raise
    index.close()
    return result


def benchmark_mmap_concurrency(
    mmap_directory: str | Path,
    *,
    reader_counts: Sequence[int] = (1, 2, 4, 8),
    world_counts: Sequence[int] = (16, 64, 256),
    query_count: int = 512,
    repeats: int = 5,
) -> dict[str, object]:
    """Measure warm-cache rectangle throughput with concurrent readers."""

    if query_count <= 0 or repeats <= 0:
        raise ValueError("query_count and repeats must be positive")
    if (
        not reader_counts
        or any(count <= 0 for count in reader_counts)
        or not world_counts
        or any(count <= 0 for count in world_counts)
    ):
        raise ValueError("reader/world counts must be positive")
    index = MemoryMappedScoreIndex.load(
        mmap_directory, verify_checksum=False
    )
    if max(world_counts) > index.scores.shape[0]:
        index.close()
        raise ValueError("world_count exceeds score index")

    results = []
    for world_count in world_counts:
        target_scope = index.targets
        maximum_start = index.scores.shape[0] - world_count
        tasks = [
            (
                index.sources[position % len(index.sources)],
                (position * 37) % (maximum_start + 1),
            )
            for position in range(query_count)
        ]

        def read(task: tuple[str, int]) -> float:
            source, start = task
            rectangle = index.rectangle(
                (source,),
                target_scope,
                world_start=start,
                world_stop=start + world_count,
            )
            return float(np.sum(rectangle, dtype=np.float64))

        for readers in reader_counts:
            # Warm the same mapping and force one materialized read first.
            read(tasks[0])
            executor = (
                ThreadPoolExecutor(max_workers=readers)
                if readers > 1
                else None
            )
            elapsed_runs = []
            checksum_runs = []
            try:
                for _ in range(repeats):
                    started = time.perf_counter()
                    if executor is None:
                        checksums = [read(task) for task in tasks]
                    else:
                        checksums = list(executor.map(read, tasks))
                    elapsed_runs.append(time.perf_counter() - started)
                    checksum_runs.append(sum(checksums))
            finally:
                if executor is not None:
                    executor.shutdown()
            elapsed = statistics.median(elapsed_runs)
            results.append(
                {
                    "world_count": world_count,
                    "readers": readers,
                    "query_count": query_count,
                    "rectangle_shape": [
                        world_count,
                        1,
                        len(target_scope),
                    ],
                    "elapsed_seconds": elapsed,
                    "elapsed_seconds_runs": elapsed_runs,
                    "queries_per_second": query_count / elapsed,
                    "scores_per_second": (
                        query_count
                        * world_count
                        * len(target_scope)
                        / elapsed
                    ),
                    "checksum": checksum_runs[0],
                    "checksum_consistent": len(set(checksum_runs)) == 1,
                }
            )
    baselines = {
        row["world_count"]: row["queries_per_second"]
        for row in results
        if row["readers"] == 1
    }
    for row in results:
        row["speedup_vs_one_reader"] = (
            row["queries_per_second"] / baselines[row["world_count"]]
        )
    source_batch_results = []
    for world_count in world_counts:
        maximum_start = index.scores.shape[0] - world_count
        for source_batch_size in (1, 2, 4, 8, 16, 32):
            if source_batch_size > len(index.sources):
                continue
            batch_count = math.ceil(query_count / source_batch_size)
            elapsed_runs = []
            checksum_runs = []
            for _ in range(repeats):
                checksum = 0.0
                started = time.perf_counter()
                for batch in range(batch_count):
                    sources = tuple(
                        index.sources[
                            (batch * source_batch_size + offset)
                            % len(index.sources)
                        ]
                        for offset in range(source_batch_size)
                    )
                    start = (batch * 37) % (maximum_start + 1)
                    rectangle = index.rectangle(
                        sources,
                        index.targets,
                        world_start=start,
                        world_stop=start + world_count,
                    )
                    checksum += float(np.sum(rectangle, dtype=np.float64))
                elapsed_runs.append(time.perf_counter() - started)
                checksum_runs.append(checksum)
            elapsed = statistics.median(elapsed_runs)
            source_batch_results.append(
                {
                    "world_count": world_count,
                    "source_batch_size": source_batch_size,
                    "logical_query_count": batch_count
                    * source_batch_size,
                    "rectangle_call_count": batch_count,
                    "elapsed_seconds": elapsed,
                    "logical_queries_per_second": (
                        batch_count * source_batch_size / elapsed
                    ),
                    "checksum_consistent": len(set(checksum_runs)) == 1,
                }
            )
    index.close()
    return {
        "mmap_directory": str(Path(mmap_directory).resolve()),
        "query_count_per_cell": query_count,
        "repeats_per_cell": repeats,
        "reader_counts": list(reader_counts),
        "world_counts": list(world_counts),
        "results": results,
        "source_batch_results": source_batch_results,
        "claim_boundary": (
            "Warm OS page-cache, single-process thread throughput; not cold "
            "page-fault or multi-process server throughput."
        ),
    }


def tune_mmap_source_batch(
    mmap_directory: str | Path,
    *,
    world_count: int,
    batch_sizes: Sequence[int] = (1, 2, 4, 8, 16, 32),
    calibration_queries: int = 256,
    repeats: int = 3,
) -> dict[str, object]:
    """Select a source batch size for one score-index rectangle shape.

    This is a warm-cache systems calibration.  It never changes score or
    statistical-bound semantics, and callers should key the result by the
    returned tensor shape/dtype and world count.
    """

    if world_count <= 0 or calibration_queries <= 0 or repeats <= 0:
        raise ValueError(
            "world_count, calibration_queries, and repeats must be positive"
        )
    if not batch_sizes or any(size <= 0 for size in batch_sizes):
        raise ValueError("batch_sizes must be positive")
    unique_sizes = tuple(dict.fromkeys(int(size) for size in batch_sizes))
    index = MemoryMappedScoreIndex.load(
        mmap_directory, verify_checksum=False
    )
    try:
        if world_count > index.scores.shape[0]:
            raise ValueError("world_count exceeds score index")
        eligible_sizes = tuple(
            size for size in unique_sizes if size <= len(index.sources)
        )
        if not eligible_sizes:
            raise ValueError("no batch_size fits the score index source scope")
        maximum_start = index.scores.shape[0] - world_count
        rows = []
        for batch_size in eligible_sizes:
            elapsed_runs = []
            checksum_runs = []
            # Warm one rectangle with the exact calibrated shape.
            index.rectangle(
                index.sources[:batch_size],
                index.targets,
                world_stop=world_count,
            )
            for _ in range(repeats):
                completed = 0
                call_index = 0
                checksum = 0.0
                started = time.perf_counter()
                while completed < calibration_queries:
                    current_size = min(
                        batch_size, calibration_queries - completed
                    )
                    sources = tuple(
                        index.sources[(completed + offset) % len(index.sources)]
                        for offset in range(current_size)
                    )
                    world_start = (call_index * 37) % (maximum_start + 1)
                    rectangle = index.rectangle(
                        sources,
                        index.targets,
                        world_start=world_start,
                        world_stop=world_start + world_count,
                    )
                    checksum += float(np.sum(rectangle, dtype=np.float64))
                    completed += current_size
                    call_index += 1
                elapsed_runs.append(time.perf_counter() - started)
                checksum_runs.append(checksum)
            elapsed = statistics.median(elapsed_runs)
            rows.append(
                {
                    "batch_size": batch_size,
                    "rectangle_call_count": math.ceil(
                        calibration_queries / batch_size
                    ),
                    "median_elapsed_seconds": elapsed,
                    "elapsed_seconds_runs": elapsed_runs,
                    "logical_queries_per_second": calibration_queries
                    / elapsed,
                    "checksum_consistent": len(set(checksum_runs)) == 1,
                }
            )
        winner = max(
            rows,
            key=lambda row: (
                row["logical_queries_per_second"],
                -row["batch_size"],
            ),
        )
        baseline = next(
            (row for row in rows if row["batch_size"] == 1), None
        )
        return {
            "format": "pkgea-mmap-source-batch-tuning-v1",
            "mmap_directory": str(Path(mmap_directory).resolve()),
            "tensor_shape": list(index.scores.shape),
            "dtype": str(index.scores.dtype),
            "context_digest": index.metadata["context_digest"],
            "world_digest": index.metadata["world_digest"],
            "world_count": world_count,
            "target_count": len(index.targets),
            "calibration_queries": calibration_queries,
            "repeats": repeats,
            "recommended_source_batch_size": winner["batch_size"],
            "recommended_queries_per_second": winner[
                "logical_queries_per_second"
            ],
            "speedup_vs_batch_one": (
                winner["logical_queries_per_second"]
                / baseline["logical_queries_per_second"]
                if baseline is not None
                else None
            ),
            "results": rows,
            "claim_boundary": (
                "Warm-cache shape calibration for execution only; it does "
                "not alter query correctness or statistical guarantees."
            ),
        }
    finally:
        index.close()
