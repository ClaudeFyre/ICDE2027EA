"""A transparent cost policy for exact, sampling, and distributional operators."""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class QueryWorkload:
    uncertain_edges: int
    candidate_count: int
    normalized_entropy: float
    latency_budget: float
    target_absolute_error: float
    delta: float = 0.05
    distributional_validation_error: float | None = None
    distributional_operator: str = "degree_diagonal"


@dataclass(frozen=True)
class ExecutionPlan:
    operator: str
    estimated_cost: float
    estimated_error: float
    rationale: str

    def as_dict(self) -> dict[str, str | float]:
        return {
            "operator": self.operator,
            "estimated_cost": self.estimated_cost,
            "estimated_error": self.estimated_error,
            "rationale": self.rationale,
        }


def choose_execution_plan(workload: QueryWorkload) -> ExecutionPlan:
    if workload.uncertain_edges <= 0 or workload.candidate_count <= 0:
        raise ValueError("Graph and candidate sizes must be positive")
    if not 0.0 <= workload.normalized_entropy <= 1.0:
        raise ValueError("normalized_entropy must be in [0, 1]")
    if workload.latency_budget <= 0 or workload.target_absolute_error <= 0:
        raise ValueError("Budgets and error target must be positive")
    if (
        workload.distributional_validation_error is not None
        and not 0.0 <= workload.distributional_validation_error <= 1.0
    ):
        raise ValueError(
            "distributional_validation_error must be in [0, 1]"
        )
    if workload.distributional_operator not in {
        "degree_diagonal",
        "learned_low_rank",
    }:
        raise ValueError("Unsupported distributional_operator")

    exact_cost = (
        2.0 ** workload.uncertain_edges * workload.candidate_count
        if workload.uncertain_edges <= 30
        else float("inf")
    )
    if exact_cost <= workload.latency_budget:
        return ExecutionPlan(
            "exact",
            exact_cost,
            0.0,
            "All possible worlds fit the declared latency budget.",
        )

    distributional_cost = workload.uncertain_edges * math.log2(
        workload.candidate_count + 1
    )
    distributional_entropy_proxy = 0.01 + 0.08 * workload.normalized_entropy
    distributional_error = workload.distributional_validation_error
    if (
        distributional_cost <= workload.latency_budget
        and distributional_error is not None
        and distributional_error <= workload.target_absolute_error
    ):
        return ExecutionPlan(
            (
                "distributional_low_rank"
                if workload.distributional_operator == "learned_low_rank"
                else "distributional"
            ),
            distributional_cost,
            distributional_error,
            (
                "Moment propagation meets the requested error using a supplied "
                f"{workload.distributional_operator} profile/operator "
                "validation error; entropy proxy="
                f"{distributional_entropy_proxy:.6g}."
            ),
        )

    required_samples = math.ceil(
        math.log(2.0 * workload.candidate_count / workload.delta)
        / (2.0 * workload.target_absolute_error**2)
    )
    sampling_cost = required_samples * max(
        1.0, math.sqrt(workload.uncertain_edges)
    )
    return ExecutionPlan(
        "adaptive_sampling",
        sampling_cost,
        workload.target_absolute_error,
        (
            "Exact enumeration is infeasible and the distributional entropy "
            "proxy alone is not accepted as a guarantee; profile/operator "
            "validation is missing or does not satisfy the error target."
        ),
    )
