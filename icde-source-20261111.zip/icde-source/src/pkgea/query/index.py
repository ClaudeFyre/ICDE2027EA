"""Static candidate bounds that are valid for every possible world."""

from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Hashable, Mapping, Sequence

from pkgea.backbones.attribute import AttributeStructuralBackbone
from pkgea.backbones.label_propagation import LabelPropagationBackbone


@dataclass(frozen=True)
class CandidateBound:
    candidate: Hashable
    lower: float
    upper: float


@dataclass(frozen=True)
class CandidateSelection:
    source: Hashable
    candidates: tuple[Hashable, ...]
    pruned: int
    kth_lower_bound: float


class StaticCandidateIndex:
    """Prune only when a candidate upper bound is below a top-k lower bound."""

    def __init__(
        self,
        bounds: Mapping[Hashable, Sequence[CandidateBound]],
    ) -> None:
        if not bounds:
            raise ValueError("candidate bounds cannot be empty")
        self._bounds = {
            source: tuple(items) for source, items in bounds.items()
        }
        for source, items in self._bounds.items():
            if not items:
                raise ValueError(f"source has no candidates: {source}")
            if any(
                not 0.0 <= item.lower <= item.upper <= 1.0
                for item in items
            ):
                raise ValueError("candidate bounds must satisfy 0 <= L <= U <= 1")

    def select(self, source: Hashable, k: int) -> CandidateSelection:
        items = self._bounds.get(source)
        if items is None:
            raise ValueError(f"unknown source: {source}")
        if not 0 < k <= len(items):
            raise ValueError("k must be within the candidate scope")
        kth_lower = sorted(
            (item.lower for item in items), reverse=True
        )[k - 1]
        survivors = tuple(
            item.candidate
            for item in sorted(
                items, key=lambda item: (-item.upper, str(item.candidate))
            )
            if item.upper >= kth_lower
        )
        return CandidateSelection(
            source=source,
            candidates=survivors,
            pruned=len(items) - len(survivors),
            kth_lower_bound=kth_lower,
        )

    @classmethod
    def from_attribute_backbone(
        cls, backbone: AttributeStructuralBackbone
    ) -> "StaticCandidateIndex":
        """Derive exact range bounds from attribute and degree-score ranges.

        The toy structural component is ``0.6 * lexical + 0.4 * structural``
        and the final structural term is always in ``[0, 1]``.  Therefore the
        resulting interval contains the score for every edge-existence world.
        """

        attribute_weight = backbone.attribute_weight
        structural_weight = 1.0 - attribute_weight
        labels = backbone.structural.labels
        bounds = {}
        for source in backbone.source_entities:
            items = []
            for target in backbone.target_entities:
                lexical = SequenceMatcher(
                    None,
                    labels[source].casefold(),
                    labels[target].casefold(),
                ).ratio()
                attribute = backbone.attribute_scores[(source, target)]
                lower = (
                    attribute_weight * attribute
                    + structural_weight * 0.6 * lexical
                )
                upper = lower + structural_weight * 0.4
                items.append(CandidateBound(target, lower, upper))
            bounds[source] = items
        return cls(bounds)

    @classmethod
    def from_label_propagation_backbone(
        cls, backbone: LabelPropagationBackbone
    ) -> "StaticCandidateIndex":
        """Derive world-uniform bounds for the non-negative propagation scorer.

        Seed labels, their propagated means, and their row-normalized vectors
        are non-negative, so propagation cosine lies in ``[0, 1]``.  The
        degree-local structural component contributes ``0.6 * lexical`` plus
        a term in ``[0, 0.4]``.  These facts give a safe scorer-specific gate
        without looking at a sampled world.
        """

        propagation_weight = (
            1.0 - backbone.attribute_weight - backbone.structural_weight
        )
        bounds = {}
        for source in backbone.source_entities:
            items = []
            for target in backbone.target_entities:
                attribute = backbone.attribute_scores[(source, target)]
                lexical = backbone.structural.lexical_scores[(source, target)]
                lower = (
                    backbone.attribute_weight * attribute
                    + backbone.structural_weight * 0.6 * lexical
                )
                upper = lower + propagation_weight + 0.4 * backbone.structural_weight
                items.append(CandidateBound(target, lower, min(1.0, upper)))
            bounds[source] = items
        return cls(bounds)
