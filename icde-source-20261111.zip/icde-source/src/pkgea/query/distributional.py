"""Analytic distributional execution operator for alignment queries."""

from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Hashable

import numpy as np

from pkgea.distributional import (
    GaussianMoments,
    aggregate_bernoulli_messages,
    diagonal_wasserstein_squared,
    gaussian_wasserstein_squared,
)
from pkgea.contracts import validate_dataset


@dataclass(frozen=True)
class DistributionalCandidate:
    candidate: Hashable
    distance: float
    similarity: float
    target_uncertainty_radius: float


@dataclass(frozen=True)
class DistributionalQueryResult:
    source: Hashable
    top_k: tuple[DistributionalCandidate, ...]
    candidate_count: int
    distance_margin: float
    source_uncertainty_radius: float

    def as_dict(self) -> dict[str, object]:
        return {
            "source": str(self.source),
            "top_k": [
                {
                    "candidate": str(item.candidate),
                    "distance": item.distance,
                    "similarity": item.similarity,
                    "target_uncertainty_radius": item.target_uncertainty_radius,
                }
                for item in self.top_k
            ],
            "candidate_count": self.candidate_count,
            "distance_margin": self.distance_margin,
            "source_uncertainty_radius": self.source_uncertainty_radius,
            "stable": None,
            "stability_semantics": (
                "No finite-sample Hoeffding claim; margin is an analytic "
                "distribution-distance diagnostic."
            ),
        }


class DistributionalDegreeIndex:
    """Index analytic in/out-degree distributions for all alignment entities."""

    def __init__(
        self,
        moments: dict[str, GaussianMoments],
        source_entities: tuple[str, ...],
        target_entities: tuple[str, ...],
        *,
        edge_passes: int,
        edge_dependence_assumption: str,
        common_shock_probability: float,
    ) -> None:
        self.moments = moments
        self.source_entities = source_entities
        self.target_entities = target_entities
        self.edge_passes = edge_passes
        self.edge_dependence_assumption = edge_dependence_assumption
        self.common_shock_probability = common_shock_probability

    @staticmethod
    def _radius(moments: GaussianMoments) -> float:
        return math.sqrt(sum(max(value, 0.0) for value in moments.variance))

    @classmethod
    def from_dataset(
        cls, dataset_dir: str | Path
    ) -> "DistributionalDegreeIndex":
        root = Path(dataset_dir).resolve()
        validate_dataset(root)
        with (root / "triples.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            triples = list(csv.DictReader(handle, delimiter="\t"))
        with (root / "alignments.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            alignments = list(csv.DictReader(handle, delimiter="\t"))
        metadata = json.loads(
            (root / "confidence_metadata.json").read_text(encoding="utf-8")
        )
        probabilities = [float(row["confidence"]) for row in triples]
        groups = [row["dependency_group"] for row in triples]
        dependence = metadata.get("edge_dependence", {})
        rho = (
            float(metadata.get("generation", {}).get("shared_strength", 0.0))
            if dependence.get("assumption") == "grouped_shared_latent"
            and any(groups)
            else 0.0
        )
        source_entities = tuple(
            dict.fromkeys(row["source_entity_id"] for row in alignments)
        )
        target_entities = tuple(
            dict.fromkeys(row["target_entity_id"] for row in alignments)
        )
        query_entities = (*source_entities, *target_entities)
        moments = {}
        edge_passes = 0
        for entity in query_entities:
            edge_indices = [
                index
                for index, triple in enumerate(triples)
                if triple["head_id"] == entity
                or triple["tail_id"] == entity
            ]
            edge_passes += len(edge_indices)
            if not edge_indices:
                moments[entity] = GaussianMoments(
                    (0.0, 0.0), ((0.0, 0.0), (0.0, 0.0))
                )
                continue
            messages = [
                (
                    float(triples[index]["head_id"] == entity),
                    float(triples[index]["tail_id"] == entity),
                )
                for index in edge_indices
            ]
            moments[entity] = aggregate_bernoulli_messages(
                messages,
                [probabilities[index] for index in edge_indices],
                dependency_groups=[groups[index] for index in edge_indices],
                common_shock_probability=rho,
            )
        return cls(
            moments,
            source_entities,
            target_entities,
            edge_passes=edge_passes,
            edge_dependence_assumption=str(
                dependence.get("assumption", "unspecified")
            ),
            common_shock_probability=rho,
        )

    def query(self, source: str, *, k: int = 1) -> DistributionalQueryResult:
        if source not in self.source_entities:
            raise ValueError(f"Unknown source entity: {source}")
        if not 0 < k <= len(self.target_entities):
            raise ValueError("k must be within the target candidate count")
        ranked = sorted(
            (
                DistributionalCandidate(
                    target,
                    diagonal_wasserstein_squared(
                        self.moments[source], self.moments[target]
                    ),
                    1.0
                    / (
                        1.0
                        + diagonal_wasserstein_squared(
                            self.moments[source], self.moments[target]
                        )
                    ),
                    self._radius(self.moments[target]),
                )
                for target in self.target_entities
            ),
            key=lambda item: (item.distance, str(item.candidate)),
        )
        margin = (
            ranked[k].distance - ranked[k - 1].distance
            if k < len(ranked)
            else float("inf")
        )
        return DistributionalQueryResult(
            source=source,
            top_k=tuple(ranked[:k]),
            candidate_count=len(ranked),
            distance_margin=margin,
            source_uncertainty_radius=self._radius(self.moments[source]),
        )


class LearnedLowRankCovarianceIndex:
    """Learned-hidden Gaussian index stored as low-rank plus diagonal."""

    def __init__(
        self,
        entities: tuple[str, ...],
        means: np.ndarray,
        factors: np.ndarray,
        diagonal_residuals: np.ndarray,
        metadata: dict[str, object],
    ) -> None:
        source_count = int(metadata["source_count"])
        if not 0 < source_count < len(entities):
            raise ValueError("Invalid learned covariance source_count")
        if means.ndim != 2:
            raise ValueError("Learned covariance means must be a matrix")
        dimension = means.shape[1]
        if means.shape != (len(entities), dimension):
            raise ValueError("Learned covariance mean shape mismatch")
        if (
            factors.ndim != 3
            or factors.shape[:2] != (len(entities), dimension)
        ):
            raise ValueError("Learned covariance factor shape mismatch")
        if diagonal_residuals.shape != (len(entities), dimension):
            raise ValueError("Learned covariance diagonal shape mismatch")
        if not (
            np.isfinite(means).all()
            and np.isfinite(factors).all()
            and np.isfinite(diagonal_residuals).all()
            and (diagonal_residuals >= 0.0).all()
        ):
            raise ValueError("Learned covariance artifact contains invalid values")
        self.entities = entities
        self.source_entities = entities[:source_count]
        self.target_entities = entities[source_count:]
        self.means = means
        self.factors = factors
        self.diagonal_residuals = diagonal_residuals
        self.metadata = metadata
        self.entity_index = {
            entity: index for index, entity in enumerate(entities)
        }
        self.covariances = np.stack(
            [
                factor @ factor.T + np.diag(residual)
                for factor, residual in zip(
                    factors, diagonal_residuals, strict=True
                )
            ]
        )

    @classmethod
    def from_artifact(
        cls, artifact_path: str | Path
    ) -> "LearnedLowRankCovarianceIndex":
        with np.load(Path(artifact_path).resolve(), allow_pickle=False) as data:
            metadata = json.loads(str(data["metadata"].item()))
            if (
                metadata.get("format")
                not in {
                    "pkgea-learned-low-rank-covariance-v1",
                    "pkgea-learned-low-rank-covariance-v2",
                }
            ):
                raise ValueError("Unsupported learned covariance artifact")
            return cls(
                tuple(str(entity) for entity in data["entities"]),
                np.asarray(data["means"], dtype=np.float64),
                np.asarray(data["factors"], dtype=np.float64),
                np.asarray(data["diagonal_residuals"], dtype=np.float64),
                metadata,
            )

    def query(self, source: str, *, k: int = 1) -> DistributionalQueryResult:
        if source not in self.source_entities:
            raise ValueError(f"Unknown source entity: {source}")
        if not 0 < k <= len(self.target_entities):
            raise ValueError("k must be within the target candidate count")
        source_index = self.entity_index[source]
        ranked = []
        for target in self.target_entities:
            target_index = self.entity_index[target]
            distance = gaussian_wasserstein_squared(
                self.means[source_index],
                self.covariances[source_index],
                self.means[target_index],
                self.covariances[target_index],
            )
            ranked.append(
                DistributionalCandidate(
                    target,
                    distance,
                    1.0 / (1.0 + distance),
                    math.sqrt(float(np.trace(self.covariances[target_index]))),
                )
            )
        ranked.sort(key=lambda item: (item.distance, str(item.candidate)))
        margin = (
            ranked[k].distance - ranked[k - 1].distance
            if k < len(ranked)
            else float("inf")
        )
        return DistributionalQueryResult(
            source=source,
            top_k=tuple(ranked[:k]),
            candidate_count=len(ranked),
            distance_margin=margin,
            source_uncertainty_radius=math.sqrt(
                float(np.trace(self.covariances[source_index]))
            ),
        )
