"""Progressive top-k alignment queries with reusable possible worlds."""

from __future__ import annotations

import gzip
import hashlib
import json
import math
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Hashable, Mapping, Sequence

from pkgea.samplers import WorldSample, monte_carlo_worlds


Candidate = tuple[Hashable, Hashable]
ScoreFunction = Callable[[tuple[bool, ...]], Mapping[Candidate, float]]


@dataclass(frozen=True)
class CandidateInterval:
    candidate: Hashable
    estimate: float
    lower: float
    upper: float


@dataclass(frozen=True)
class ProgressiveQueryResult:
    source: Hashable
    top_k: tuple[CandidateInterval, ...]
    samples_used: int
    stable: bool
    pruned_candidates: int
    cache_reused: bool
    bound_method: str = "hoeffding"

    def as_dict(self) -> dict[str, object]:
        return {
            "source": str(self.source),
            "top_k": [
                {
                    "candidate": str(item.candidate),
                    "estimate": item.estimate,
                    "lower": item.lower,
                    "upper": item.upper,
                }
                for item in self.top_k
            ],
            "samples_used": self.samples_used,
            "stable": self.stable,
            "pruned_candidates": self.pruned_candidates,
            "cache_reused": self.cache_reused,
            "bound_method": self.bound_method,
        }


class WorldCache:
    """Prefix cache enabling common random worlds across candidate queries."""

    def __init__(self) -> None:
        self._cache: dict[
            tuple[tuple[float, ...], int, tuple[str, ...], float],
            list[WorldSample],
        ] = {}

    def get(
        self,
        probabilities: Sequence[float],
        count: int,
        seed: int,
        *,
        dependency_groups: Sequence[str] | None = None,
        common_shock_probability: float = 0.0,
    ) -> tuple[list[WorldSample], bool]:
        groups = tuple(dependency_groups or ("",) * len(probabilities))
        key = (
            tuple(probabilities),
            seed,
            groups,
            common_shock_probability,
        )
        cached = self._cache.get(key)
        reused = cached is not None and len(cached) >= count
        if cached is None or len(cached) < count:
            # Regenerating from the same seed preserves prefixes and avoids
            # maintaining opaque RNG state in persisted caches.
            cached = monte_carlo_worlds(
                probabilities,
                count,
                seed,
                dependency_groups=groups,
                common_shock_probability=common_shock_probability,
            )
            self._cache[key] = cached
        return cached[:count], reused

    def save(
        self,
        path: str | Path,
        *,
        overwrite: bool = False,
    ) -> Path:
        """Persist reusable world prefixes with an atomic file replacement."""

        output = Path(path).resolve()
        if output.exists() and not overwrite:
            raise ValueError(f"Cache already exists; refusing to overwrite: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "entries": [
                {
                    "probabilities": list(key[0]),
                    "seed": key[1],
                    "dependency_groups": list(key[2]),
                    "common_shock_probability": key[3],
                    "worlds": [
                        {
                            "state": list(world.state),
                            "weight": world.weight,
                            "sampled_edge_count": world.sampled_edge_count,
                            "origin": world.origin,
                        }
                        for world in worlds
                    ],
                }
                for key, worlds in self._cache.items()
            ],
        }
        descriptor, temporary_name = tempfile.mkstemp(
            dir=output.parent,
            prefix=f".{output.name}.",
            suffix=".tmp",
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"))
                handle.write("\n")
            os.replace(temporary_name, output)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise
        return output

    @classmethod
    def load(cls, path: str | Path) -> "WorldCache":
        """Load and validate a persisted world-prefix index."""

        source = Path(path).resolve()
        with source.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if payload.get("version") != 1 or not isinstance(
            payload.get("entries"), list
        ):
            raise ValueError("Unsupported or malformed world cache")
        cache = cls()
        for entry in payload["entries"]:
            probabilities = tuple(float(value) for value in entry["probabilities"])
            groups = tuple(str(value) for value in entry["dependency_groups"])
            key = (
                probabilities,
                int(entry["seed"]),
                groups,
                float(entry["common_shock_probability"]),
            )
            worlds = [
                WorldSample(
                    tuple(bool(value) for value in world["state"]),
                    float(world["weight"]),
                    int(world["sampled_edge_count"]),
                    str(world["origin"]),
                )
                for world in entry["worlds"]
            ]
            if any(len(world.state) != len(probabilities) for world in worlds):
                raise ValueError("Persisted world state has the wrong edge count")
            cache._cache[key] = worlds
        return cache


class ScoreCache:
    """Validated persistent cache of complete world score matrices.

    Entries are bound to an ordered world-state digest, backbone identifier,
    and exact source/target scopes.  The JSON payload is gzip-compressed and
    never executes code when loaded.
    """

    def __init__(self) -> None:
        self._cache: dict[
            tuple[str, str, str, tuple[str, ...], tuple[str, ...]],
            list[dict[Candidate, float]],
        ] = {}

    @staticmethod
    def _world_digest(worlds: Sequence[WorldSample]) -> str:
        digest = hashlib.sha256()
        digest.update(len(worlds).to_bytes(8, "big"))
        for world in worlds:
            digest.update(len(world.state).to_bytes(8, "big"))
            accumulator = 0
            bits = 0
            for active in world.state:
                accumulator = (accumulator << 1) | int(active)
                bits += 1
                if bits == 8:
                    digest.update(bytes((accumulator,)))
                    accumulator = 0
                    bits = 0
            if bits:
                digest.update(bytes((accumulator << (8 - bits),)))
        return digest.hexdigest()

    def get(
        self,
        worlds: Sequence[WorldSample],
        backbone_id: str,
        sources: Sequence[Hashable],
        targets: Sequence[Hashable],
        score_function: ScoreFunction,
        *,
        context_digest: str = "unversioned",
    ) -> tuple[list[dict[Candidate, float]], bool]:
        if not context_digest:
            raise ValueError("context_digest cannot be empty")
        source_scope = tuple(str(value) for value in sources)
        target_scope = tuple(str(value) for value in targets)
        key = (
            context_digest,
            self._world_digest(worlds),
            backbone_id,
            source_scope,
            target_scope,
        )
        cached = self._cache.get(key)
        if cached is not None:
            return cached, True
        expected = {
            (source, target)
            for source in source_scope
            for target in target_scope
        }
        matrices = []
        for world in worlds:
            raw = score_function(world.state)
            matrix = {
                (str(source), str(target)): float(score)
                for (source, target), score in raw.items()
            }
            if set(matrix) != expected:
                raise ValueError(
                    "Backbone score matrix does not match cache scope"
                )
            if any(
                not math.isfinite(score) or not 0.0 <= score <= 1.0
                for score in matrix.values()
            ):
                raise ValueError(
                    "Cached progressive scores must be finite and in [0, 1]"
                )
            matrices.append(matrix)
        self._cache[key] = matrices
        return matrices, False

    def put(
        self,
        worlds: Sequence[WorldSample],
        backbone_id: str,
        sources: Sequence[Hashable],
        targets: Sequence[Hashable],
        matrices: Sequence[Mapping[Candidate, float]],
        *,
        context_digest: str,
        overwrite: bool = False,
    ) -> None:
        """Install a validated precomputed score rectangle."""

        if not context_digest:
            raise ValueError("context_digest cannot be empty")
        source_scope = tuple(str(value) for value in sources)
        target_scope = tuple(str(value) for value in targets)
        key = (
            context_digest,
            self._world_digest(worlds),
            backbone_id,
            source_scope,
            target_scope,
        )
        if key in self._cache and not overwrite:
            raise ValueError("Score cache entry already exists")
        if len(matrices) != len(worlds):
            raise ValueError("Score matrix count must match world count")
        expected = {
            (source, target)
            for source in source_scope
            for target in target_scope
        }
        normalized = []
        for raw in matrices:
            matrix = {
                (str(source), str(target)): float(score)
                for (source, target), score in raw.items()
            }
            if set(matrix) != expected:
                raise ValueError(
                    "Precomputed score matrix does not match cache scope"
                )
            if any(
                not math.isfinite(score) or not 0.0 <= score <= 1.0
                for score in matrix.values()
            ):
                raise ValueError(
                    "Precomputed scores must be finite and in [0, 1]"
                )
            normalized.append(matrix)
        self._cache[key] = normalized

    def save(
        self, path: str | Path, *, overwrite: bool = False
    ) -> Path:
        output = Path(path).resolve()
        if output.exists() and not overwrite:
            raise ValueError(
                f"Score cache already exists; refusing to overwrite: {output}"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        entries = []
        for key, matrices in self._cache.items():
            context_digest, digest, backbone_id, sources, targets = key
            entries.append(
                {
                    "context_digest": context_digest,
                    "world_digest": digest,
                    "backbone_id": backbone_id,
                    "sources": list(sources),
                    "targets": list(targets),
                    "matrices": [
                        [
                            matrix[(source, target)]
                            for source in sources
                            for target in targets
                        ]
                        for matrix in matrices
                    ],
                }
            )
        payload = {"version": 2, "entries": entries}
        descriptor, temporary_name = tempfile.mkstemp(
            dir=output.parent,
            prefix=f".{output.name}.",
            suffix=".tmp",
        )
        os.close(descriptor)
        try:
            with gzip.open(
                temporary_name, "wt", encoding="utf-8", compresslevel=6
            ) as handle:
                json.dump(
                    payload,
                    handle,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                handle.write("\n")
            os.replace(temporary_name, output)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise
        return output

    @classmethod
    def load(cls, path: str | Path) -> "ScoreCache":
        source = Path(path).resolve()
        with gzip.open(source, "rt", encoding="utf-8") as handle:
            payload = json.load(handle)
        if payload.get("version") not in {1, 2} or not isinstance(
            payload.get("entries"), list
        ):
            raise ValueError("Unsupported or malformed score cache")
        cache = cls()
        for entry in payload["entries"]:
            sources = tuple(str(value) for value in entry["sources"])
            targets = tuple(str(value) for value in entry["targets"])
            expected_size = len(sources) * len(targets)
            matrices = []
            for flat in entry["matrices"]:
                if len(flat) != expected_size:
                    raise ValueError(
                        "Persisted score matrix has the wrong shape"
                    )
                values = [float(value) for value in flat]
                if any(
                    not math.isfinite(value) or not 0.0 <= value <= 1.0
                    for value in values
                ):
                    raise ValueError(
                        "Persisted scores must be finite and in [0, 1]"
                    )
                matrices.append(
                    {
                        (source_id, target_id): values[
                            row * len(targets) + column
                        ]
                        for row, source_id in enumerate(sources)
                        for column, target_id in enumerate(targets)
                    }
                )
            key = (
                str(entry.get("context_digest", "unversioned")),
                str(entry["world_digest"]),
                str(entry["backbone_id"]),
                sources,
                targets,
            )
            cache._cache[key] = matrices
        return cache

    @property
    def context_digests(self) -> tuple[str, ...]:
        return tuple(sorted({key[0] for key in self._cache}))

    def invalidate_context(self, context_digest: str) -> int:
        """Remove all matrices derived from one dataset/model revision."""

        doomed = [
            key for key in self._cache if key[0] == context_digest
        ]
        for key in doomed:
            del self._cache[key]
        return len(doomed)


class StaleCacheRevisionError(ValueError):
    """Raised when a query attempts to use a non-active artifact revision."""


class VersionedScoreCache:
    """MVCC-style guard around :class:`ScoreCache`.

    Old revisions may remain retained for rollback, but normal reads must name
    the active revision.  This makes stale-cache use an explicit error rather
    than an accidental hit.
    """

    def __init__(
        self,
        cache: ScoreCache | None = None,
        *,
        active_revision: str,
    ) -> None:
        if not active_revision:
            raise ValueError("active_revision cannot be empty")
        self.cache = cache or ScoreCache()
        self.active_revision = active_revision

    def advance(self, revision: str) -> None:
        if not revision:
            raise ValueError("revision cannot be empty")
        self.active_revision = revision

    def get(
        self,
        revision: str,
        worlds: Sequence[WorldSample],
        backbone_id: str,
        sources: Sequence[Hashable],
        targets: Sequence[Hashable],
        score_function: ScoreFunction,
    ) -> tuple[list[dict[Candidate, float]], bool]:
        if revision != self.active_revision:
            raise StaleCacheRevisionError(
                "requested score revision is stale; refresh or explicitly "
                "roll back the active revision"
            )
        return self.cache.get(
            worlds,
            backbone_id,
            sources,
            targets,
            score_function,
            context_digest=revision,
        )

    def put(
        self,
        revision: str,
        worlds: Sequence[WorldSample],
        backbone_id: str,
        sources: Sequence[Hashable],
        targets: Sequence[Hashable],
        matrices: Sequence[Mapping[Candidate, float]],
    ) -> None:
        if revision != self.active_revision:
            raise StaleCacheRevisionError(
                "cannot install scores into a stale revision"
            )
        self.cache.put(
            worlds,
            backbone_id,
            sources,
            targets,
            matrices,
            context_digest=revision,
        )


def _intervals(
    sums: Mapping[Hashable, float],
    sample_count: int,
    delta: float,
    *,
    squared_sums: Mapping[Hashable, float] | None = None,
    bound_method: str = "hoeffding",
) -> list[CandidateInterval]:
    candidate_count = max(len(sums), 1)
    if bound_method not in {"hoeffding", "empirical_bernstein"}:
        raise ValueError(f"Unsupported bound method: {bound_method}")
    if bound_method == "empirical_bernstein" and squared_sums is None:
        raise ValueError("empirical Bernstein requires squared sums")
    hoeffding_radius = math.sqrt(
        math.log(2.0 * candidate_count / delta) / (2.0 * sample_count)
    )
    log_term = math.log(3.0 * candidate_count / delta)

    def radius(candidate: Hashable, total: float) -> float:
        if bound_method == "hoeffding":
            return hoeffding_radius
        if sample_count <= 1:
            return 1.0
        assert squared_sums is not None
        variance = max(
            (
                squared_sums[candidate]
                - total * total / sample_count
            )
            / (sample_count - 1),
            0.0,
        )
        return min(
            math.sqrt(2.0 * variance * log_term / sample_count)
            + 3.0 * log_term / sample_count,
            1.0,
        )

    return sorted(
        (
            CandidateInterval(
                candidate=candidate,
                estimate=total / sample_count,
                lower=max(
                    total / sample_count - radius(candidate, total), 0.0
                ),
                upper=min(
                    total / sample_count + radius(candidate, total), 1.0
                ),
            )
            for candidate, total in sums.items()
        ),
        key=lambda item: (-item.estimate, str(item.candidate)),
    )


def _paired_margin_stable(
    pair_sums: Mapping[tuple[int, int], float],
    pair_squared_sums: Mapping[tuple[int, int], float],
    candidate_positions: Mapping[Hashable, int],
    ranked: Sequence[CandidateInterval],
    k: int,
    delta: float,
    sample_count: int,
) -> bool:
    """Test top-k separation on common-world paired score differences.

    The empirical-Bernstein bound is applied to X_a-X_b in [-1, 1].
    At each evaluated checkpoint, a union bound covers every unordered
    candidate pair, so selecting the current empirical top-k does not silently
    discard comparison uncertainty. As with the other progressive bounds in
    this prototype, this is not an anytime confidence sequence.
    """

    if sample_count <= 1 or k == len(ranked):
        return k == len(ranked)
    pair_count = max(len(ranked) * (len(ranked) - 1) // 2, 1)
    log_term = math.log(3.0 * pair_count / delta)
    for inside in ranked[:k]:
        for outside in ranked[k:]:
            left = candidate_positions[inside.candidate]
            right = candidate_positions[outside.candidate]
            key = (min(left, right), max(left, right))
            sign = 1.0 if left < right else -1.0
            total = sign * pair_sums[key]
            mean = total / sample_count
            variance = max(
                (
                    pair_squared_sums[key]
                    - total * total / sample_count
                )
                / (sample_count - 1),
                0.0,
            )
            # The score difference has range width two.
            radius = min(
                math.sqrt(2.0 * variance * log_term / sample_count)
                + 6.0 * log_term / sample_count,
                2.0,
            )
            if mean - radius <= 0.0:
                return False
    return True


def progressive_top_k(
    probabilities: Sequence[float],
    score_function: ScoreFunction,
    source: Hashable,
    candidates: Sequence[Hashable],
    *,
    k: int,
    max_samples: int,
    batch_size: int = 32,
    delta: float = 0.05,
    seed: int = 17,
    dependency_groups: Sequence[str] | None = None,
    common_shock_probability: float = 0.0,
    cache: WorldCache | None = None,
    bound_method: str = "hoeffding",
) -> ProgressiveQueryResult:
    if not 0 < k <= len(candidates):
        raise ValueError("k must be between 1 and the candidate count")
    if max_samples <= 0 or batch_size <= 0:
        raise ValueError("Sampling budgets must be positive")
    if not 0.0 < delta < 1.0:
        raise ValueError("delta must be in (0, 1)")

    world_cache = cache or WorldCache()
    worlds, reused = world_cache.get(
        probabilities,
        max_samples,
        seed,
        dependency_groups=dependency_groups,
        common_shock_probability=common_shock_probability,
    )
    sums = {candidate: 0.0 for candidate in candidates}
    squared_sums = {candidate: 0.0 for candidate in candidates}
    candidate_positions = {
        candidate: index for index, candidate in enumerate(candidates)
    }
    pair_sums = {
        (left, right): 0.0
        for left in range(len(candidates))
        for right in range(left + 1, len(candidates))
    }
    pair_squared_sums = dict.fromkeys(pair_sums, 0.0)
    stable = False
    used = 0
    intervals: list[CandidateInterval] = []
    for world in worlds:
        scores = score_function(world.state)
        row_scores = []
        for candidate in candidates:
            score = scores[(source, candidate)]
            if not 0.0 <= score <= 1.0:
                raise ValueError("Progressive Hoeffding bounds require scores in [0, 1]")
            sums[candidate] += score
            squared_sums[candidate] += score * score
            row_scores.append(score)
        if bound_method == "paired_empirical_bernstein":
            for left in range(len(candidates)):
                for right in range(left + 1, len(candidates)):
                    difference = row_scores[left] - row_scores[right]
                    pair_sums[(left, right)] += difference
                    pair_squared_sums[(left, right)] += (
                        difference * difference
                    )
        used += 1
        if used % batch_size and used != max_samples:
            continue
        interval_method = (
            "empirical_bernstein"
            if bound_method == "paired_empirical_bernstein"
            else bound_method
        )
        intervals = _intervals(
            sums,
            used,
            delta,
            squared_sums=squared_sums,
            bound_method=interval_method,
        )
        if bound_method == "paired_empirical_bernstein":
            separated = _paired_margin_stable(
                pair_sums,
                pair_squared_sums,
                candidate_positions,
                intervals,
                k,
                delta,
                used,
            )
        else:
            kth_lower = min(item.lower for item in intervals[:k])
            outside_upper = max(
                (item.upper for item in intervals[k:]),
                default=float("-inf"),
            )
            separated = kth_lower > outside_upper
        if separated:
            stable = True
            break

    kth_lower = min(item.lower for item in intervals[:k])
    pruned = sum(item.upper < kth_lower for item in intervals[k:])
    return ProgressiveQueryResult(
        source=source,
        top_k=tuple(intervals[:k]),
        samples_used=used,
        stable=stable,
        pruned_candidates=pruned,
        cache_reused=reused,
        bound_method=bound_method,
    )


def progressive_top_k_from_scores(
    world_scores: Sequence[Mapping[Candidate, float]],
    source: Hashable,
    candidates: Sequence[Hashable],
    *,
    k: int,
    batch_size: int = 32,
    delta: float = 0.05,
    cache_reused: bool = True,
    bound_method: str = "hoeffding",
) -> ProgressiveQueryResult:
    """Execute one query from a score prefix shared across a batch."""

    if len(world_scores) == 0:
        raise ValueError("world_scores must be non-empty")
    if not 0 < k <= len(candidates):
        raise ValueError("k must be between 1 and the candidate count")
    if batch_size <= 0 or not 0.0 < delta < 1.0:
        raise ValueError("Invalid batch_size or delta")
    sums = {candidate: 0.0 for candidate in candidates}
    squared_sums = {candidate: 0.0 for candidate in candidates}
    candidate_positions = {
        candidate: index for index, candidate in enumerate(candidates)
    }
    pair_sums = {
        (left, right): 0.0
        for left in range(len(candidates))
        for right in range(left + 1, len(candidates))
    }
    pair_squared_sums = dict.fromkeys(pair_sums, 0.0)
    stable = False
    used = 0
    intervals: list[CandidateInterval] = []
    for scores in world_scores:
        row_scores = []
        for candidate in candidates:
            score = scores[(source, candidate)]
            if not 0.0 <= score <= 1.0:
                raise ValueError(
                    "Progressive Hoeffding bounds require scores in [0, 1]"
                )
            sums[candidate] += score
            squared_sums[candidate] += score * score
            row_scores.append(score)
        if bound_method == "paired_empirical_bernstein":
            for left in range(len(candidates)):
                for right in range(left + 1, len(candidates)):
                    difference = row_scores[left] - row_scores[right]
                    pair_sums[(left, right)] += difference
                    pair_squared_sums[(left, right)] += (
                        difference * difference
                    )
        used += 1
        if used % batch_size and used != len(world_scores):
            continue
        interval_method = (
            "empirical_bernstein"
            if bound_method == "paired_empirical_bernstein"
            else bound_method
        )
        intervals = _intervals(
            sums,
            used,
            delta,
            squared_sums=squared_sums,
            bound_method=interval_method,
        )
        if bound_method == "paired_empirical_bernstein":
            separated = _paired_margin_stable(
                pair_sums,
                pair_squared_sums,
                candidate_positions,
                intervals,
                k,
                delta,
                used,
            )
        else:
            kth_lower = min(item.lower for item in intervals[:k])
            outside_upper = max(
                (item.upper for item in intervals[k:]),
                default=float("-inf"),
            )
            separated = kth_lower > outside_upper
        if separated:
            stable = True
            break
    kth_lower = min(item.lower for item in intervals[:k])
    pruned = sum(item.upper < kth_lower for item in intervals[k:])
    return ProgressiveQueryResult(
        source=source,
        top_k=tuple(intervals[:k]),
        samples_used=used,
        stable=stable,
        pruned_candidates=pruned,
        cache_reused=cache_reused,
        bound_method=bound_method,
    )


def progressive_top_k_from_dense_scores(
    world_scores: Sequence[Sequence[float]],
    source: Hashable,
    candidates: Sequence[Hashable],
    *,
    k: int,
    batch_size: int = 32,
    delta: float = 0.05,
    cache_reused: bool = True,
    bound_method: str = "hoeffding",
) -> ProgressiveQueryResult:
    """Execute progressive top-k without materializing pair-keyed mappings."""

    if len(world_scores) == 0:
        raise ValueError("world_scores must be non-empty")
    if not 0 < k <= len(candidates):
        raise ValueError("k must be between 1 and the candidate count")
    if batch_size <= 0 or not 0.0 < delta < 1.0:
        raise ValueError("Invalid batch_size or delta")
    sums = {candidate: 0.0 for candidate in candidates}
    squared_sums = {candidate: 0.0 for candidate in candidates}
    candidate_positions = {
        candidate: index for index, candidate in enumerate(candidates)
    }
    pair_sums = {
        (left, right): 0.0
        for left in range(len(candidates))
        for right in range(left + 1, len(candidates))
    }
    pair_squared_sums = dict.fromkeys(pair_sums, 0.0)
    stable = False
    used = 0
    intervals: list[CandidateInterval] = []
    for row in world_scores:
        if len(row) != len(candidates):
            raise ValueError("dense score row does not match candidate scope")
        row_scores = [float(score) for score in row]
        if any(
            not math.isfinite(score) or not 0.0 <= score <= 1.0
            for score in row_scores
        ):
            raise ValueError(
                "Progressive bounds require finite scores in [0, 1]"
            )
        for candidate, score in zip(candidates, row_scores, strict=True):
            sums[candidate] += score
            squared_sums[candidate] += score * score
        if bound_method == "paired_empirical_bernstein":
            for left in range(len(candidates)):
                for right in range(left + 1, len(candidates)):
                    difference = row_scores[left] - row_scores[right]
                    pair_sums[(left, right)] += difference
                    pair_squared_sums[(left, right)] += (
                        difference * difference
                    )
        used += 1
        if used % batch_size and used != len(world_scores):
            continue
        interval_method = (
            "empirical_bernstein"
            if bound_method == "paired_empirical_bernstein"
            else bound_method
        )
        intervals = _intervals(
            sums,
            used,
            delta,
            squared_sums=squared_sums,
            bound_method=interval_method,
        )
        if bound_method == "paired_empirical_bernstein":
            separated = _paired_margin_stable(
                pair_sums,
                pair_squared_sums,
                candidate_positions,
                intervals,
                k,
                delta,
                used,
            )
        else:
            kth_lower = min(item.lower for item in intervals[:k])
            outside_upper = max(
                (item.upper for item in intervals[k:]),
                default=float("-inf"),
            )
            separated = kth_lower > outside_upper
        if separated:
            stable = True
            break
    kth_lower = min(item.lower for item in intervals[:k])
    pruned = sum(item.upper < kth_lower for item in intervals[k:])
    return ProgressiveQueryResult(
        source=source,
        top_k=tuple(intervals[:k]),
        samples_used=used,
        stable=stable,
        pruned_candidates=pruned,
        cache_reused=cache_reused,
        bound_method=bound_method,
    )
