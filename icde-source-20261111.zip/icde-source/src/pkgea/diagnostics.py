"""End-to-end exact-versus-sampling diagnostics on canonical toy datasets."""

from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
from pathlib import Path

from pkgea.backbones import ToyStructuralBackbone
from pkgea.evaluation import estimate_objectives, mae, rmse
from pkgea.samplers import (
    exact_worlds,
    monte_carlo_worlds,
    representative_worlds,
    stratified_worlds,
)


@dataclass(frozen=True)
class DiagnosticReport:
    sample_count: int
    exact_world_count: int
    mc_expected_score_mae: float
    mc_expected_score_rmse: float
    stratified_expected_score_mae: float
    representative_expected_score_mae: float
    exact_sampled_edge_evaluations: int
    mc_sampled_edge_evaluations: int

    def as_dict(self) -> dict[str, int | float]:
        return asdict(self)


def run_toy_diagnostic(
    dataset_dir: str | Path, sample_count: int = 256, seed: int = 17
) -> DiagnosticReport:
    root = Path(dataset_dir).resolve()
    with (root / "triples.tsv").open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        triples = list(csv.DictReader(handle, delimiter="\t"))
    if any(row["confidence_type"] != "calibrated_probability" for row in triples):
        raise ValueError("Diagnostic requires calibrated_probability triples")
    probabilities = [float(row["confidence"]) for row in triples]
    backbone = ToyStructuralBackbone.from_dataset(root)

    exact = estimate_objectives(exact_worlds(probabilities), backbone.score)
    mc = estimate_objectives(
        monte_carlo_worlds(probabilities, sample_count, seed), backbone.score
    )
    stratified = estimate_objectives(
        stratified_worlds(probabilities, sample_count, seed), backbone.score
    )
    representatives = estimate_objectives(
        representative_worlds(
            probabilities,
            representative_count=min(8, sample_count),
            candidate_count=max(sample_count, 8),
            seed=seed,
        ),
        backbone.score,
    )
    return DiagnosticReport(
        sample_count=sample_count,
        exact_world_count=exact.world_count,
        mc_expected_score_mae=mae(exact.expected_score, mc.expected_score),
        mc_expected_score_rmse=rmse(exact.expected_score, mc.expected_score),
        stratified_expected_score_mae=mae(
            exact.expected_score, stratified.expected_score
        ),
        representative_expected_score_mae=mae(
            exact.expected_score, representatives.expected_score
        ),
        exact_sampled_edge_evaluations=exact.sampled_edge_evaluations,
        mc_sampled_edge_evaluations=mc.sampled_edge_evaluations,
    )

