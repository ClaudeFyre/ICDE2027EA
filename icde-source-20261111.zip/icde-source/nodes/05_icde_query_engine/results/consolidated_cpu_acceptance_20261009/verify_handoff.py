"""Verify the consolidated extraction or its ZIP using the active manifest."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath


def unique(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError(f'duplicate JSON key: {key}')
        result[key] = value
    return result


def invalid_constant(value):
    raise ValueError(f'invalid JSON constant: {value}')


def read_json(raw):
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=invalid_constant)


def safe(name):
    path = PurePosixPath(name)
    return not path.is_absolute() and '..' not in path.parts and '\\' not in name


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--zip', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if args.zip:
        with zipfile.ZipFile(args.zip) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)) or not all(safe(n) for n in names):
                raise SystemExit('duplicate or unsafe archive path')
            manifest = read_json(archive.read('HANDOFF_MANIFEST.json'))
            if set(names) != set(manifest['files']) | {'HANDOFF_MANIFEST.json'}:
                raise SystemExit('archive file set mismatch')
            for name, meta in manifest['files'].items():
                if hashlib.sha256(archive.read(name)).hexdigest() != meta['sha256']:
                    raise SystemExit(f'hash mismatch: {name}')
            if archive.testzip() is not None:
                raise SystemExit('CRC failed')
    else:
        manifest = read_json((root / 'HANDOFF_MANIFEST.json').read_bytes())
        for name, meta in manifest['files'].items():
            path = root / name
            if not safe(name) or not path.resolve().is_relative_to(root):
                raise SystemExit('unsafe manifest path')
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != meta['sha256']:
                raise SystemExit(f'missing or hash mismatch: {name}')
    print(f"PASS: {len(manifest['files'])} files; research_acceptance=false")


if __name__ == '__main__':
    main()
