"""E1 verification."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "_common"))
import icde_paths  # noqa: E402
import exp_common  # noqa: E402

REPO = icde_paths.resolve_repo_root(__file__)
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e1_20261009"


def main() -> None:
    out = json.loads((OUT / "output.json").read_text(encoding="utf-8"))
    c = out["results"]["consistency"]
    r = out["results"]["rejections"]
    o = out["results"]["oracle"]

    checks = {}
    for name, ok, ev in [
        ("format_is_v1", out.get("format") == "icde-experiment-output-v1", out.get("format")),
        ("oracle_16_worlds", o["world_count"] == 16, o["world_count"]),
        ("mc_matches_oracle", out["results"]["empirical_matches_oracle"], out["results"]["mc_vs_oracle"]),
        ("path_count_ge5", c["path_count"] >= 5, c["path_count"]),
        ("zero_disagreement", c["disagreement_count"] == 0, c["disagreement_count"]),
        ("warm_big_cache_zero_calls", c["warm_scorer_calls"]["lru_big_warm"] == 0, c["warm_scorer_calls"]),
        ("snapshot_fields_reject", r["snapshot_rejections_ok"], list(r["snapshot_field_rejections"])),
        ("candidate_order_no_reuse", r["candidate_order_no_reuse"], True),
        ("stream_seed_no_reuse", r["stream_seed_no_reuse"], True),
        ("eviction_preserves_evidence", r["eviction_preserves_evidence"], r["eviction_count"]),
        ("same_seed_diff_prob_no_reuse", r["same_seed_diff_prob_no_reuse"], True),
        ("weighted_exact_rejected", r["weighted_exact_rejected"], True),
    ]:
        key, item = exp_common.check(name, ok, ev)
        checks[key] = item

    verification = exp_common.build_verification("E1", checks=checks)
    exp_common.write_json(OUT / "verification.json", verification)
    print(json.dumps({"passed": verification["passed"], "checks": {k: v["ok"] for k, v in checks.items()}}, indent=2))


if __name__ == "__main__":
    main()
