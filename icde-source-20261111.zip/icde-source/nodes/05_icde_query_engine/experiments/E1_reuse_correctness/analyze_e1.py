"""E1 analysis: render analysis.md."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "_common"))
import icde_paths  # noqa: E402

REPO = icde_paths.resolve_repo_root(__file__)
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e1_20261009"


def main() -> None:
    out = json.loads((OUT / "output.json").read_text(encoding="utf-8"))
    c = out["results"]["consistency"]
    r = out["results"]["rejections"]
    o = out["results"]["oracle"]
    mco = out["results"]["mc_vs_oracle"]

    L = []
    L.append("# E1 Reuse Correctness — analysis")
    L.append("")
    L.append(f"- status: **{out['status']}**  created: {out['created']}")
    L.append(f"- host: {out['host']['os']} / Python {out['host']['python']} ({out['host']['cpu_cores']} cores)")
    L.append("")
    L.append("## 1. Exhaustive worlds oracle")
    L.append("")
    L.append(f"- toy graph: 4 independent Bernoulli edges {PROBS if False else '(0.80,0.60,0.75,0.55)'}, {o['world_count']} worlds, 3 sources.")
    L.append(f"- weighted modal winner per source: `{o['weighted_modal_winner']}`")
    L.append(f"- iid MC empirical/certified vs weighted oracle:")
    L.append("")
    L.append("| source | oracle modal | MC empirical | MC certified |")
    L.append("| --- | --- | --- | --- |")
    for s, v in mco.items():
        L.append(f"| {s} | {v['oracle_modal']} | {v['mc_empirical']} | {v['mc_certified']} |")
    L.append("")
    L.append("Weights are never fed to the confidence sequence; the CS only consumes categorical iid winners.")
    L.append("")
    L.append("## 2. Same-stream item-by-item consistency")
    L.append("")
    L.append(f"- paths run: {c['path_count']} ({', '.join(c['paths'])})")
    L.append(f"- fields compared per result: status, estimated/certified winner, samples, counts, pairwise bounds, evidence digest.")
    L.append(f"- **disagreements: {c['disagreement_count']}**")
    L.append(f"- warm-cache scorer calls: `{c['warm_scorer_calls']}` (big-LRU and batched+LRU fully hit; 64-byte LRU still recomputes — the documented capacity-failure case).")
    L.append("")
    L.append("## 3. Rejection / invalid-reuse behavior")
    L.append("")
    L.append("| Rule | Result |")
    L.append("| --- | --- |")
    for label, key in [
        ("every snapshot field (graph/model/probability/factors/schema/code/scorer) rejects old stream/scorer/query", "snapshot_rejections_ok"),
        ("candidate-order change never hits old labels", "candidate_order_no_reuse"),
        ("stream seed change never hits old labels", "stream_seed_no_reuse"),
        ("eviction preserves evidence (results unchanged)", "eviction_preserves_evidence"),
        ("same seed but different probability not reused", "same_seed_diff_prob_no_reuse"),
        ("weighted exact (S0) worlds rejected from iid CS stream", "weighted_exact_rejected"),
    ]:
        L.append(f"| {label} | {r[key]} |")
    L.append("")
    L.append(f"- evictions observed in 64-byte cache: {r['eviction_count']}.")
    L.append("")
    L.append("## 4. Limitations")
    L.append("")
    L.append("- Single toy graph, one seed; correctness smoke, not a scale measurement.")
    L.append("- Batching reduces scorer calls (independent vs batched) but that is ordinary batching, not a new algorithm.")
    L.append("- Wall-clock timing not used; all numbers are exact counts / labels.")
    (OUT / "analysis.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print(f"wrote {OUT/'analysis.md'}")


if __name__ == "__main__":
    main()
