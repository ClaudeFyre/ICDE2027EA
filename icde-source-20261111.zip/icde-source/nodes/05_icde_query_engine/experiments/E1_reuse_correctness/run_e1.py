"""E1 reuse-correctness runner.

  A. Tiny exhaustive worlds oracle: 16 worlds / 4 uncertain edges / 3 toy sources.
     The weighted exact oracle is independent of the iid confidence sequence;
     weights are never fed to the CS.
  B. Same-stream item-by-item consistency across >=5 execution paths (cold +
     repeat): winner / status / samples / counts / pairwise bounds / evidence digest.
  C. Valid/invalid rejection for every snapshot identity field, candidate order,
     stream seed, eviction, same-seed/different-probability, and weighted worlds.

Runs without torch.
"""

from __future__ import annotations

import json
import sys
from dataclasses import replace
from pathlib import Path

EXPERIMENTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(EXPERIMENTS / "_common"))
import icde_paths  # noqa: E402  (portable repo/input resolver)

REPO = icde_paths.resolve_repo_root(__file__)
sys.path.insert(0, str(REPO / "src"))

import exp_common  # noqa: E402
from pkgea.backbones.toy import ToyStructuralBackbone  # noqa: E402
from pkgea.contracts import dataset_content_digest  # noqa: E402
from pkgea.query.modal import (  # noqa: E402
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    WinnerBlockCache,
    execute_modal_queries,
    world_winner,
)
from pkgea.samplers import exact_worlds, monte_carlo_worlds  # noqa: E402

# Resolve the frozen toy dataset via the portable resolver (digest-verified).
TOY = icde_paths.resolve_input("exact_world_minimal")
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e1_20261009"
RAW = OUT / "raw"

PROBS = (0.80, 0.60, 0.75, 0.55)
SEED = 17
BUDGET = 2048


def make_scorer(bb: ToyStructuralBackbone, snapshot_digest: str) -> ModalScorer:
    def score_batch(state, sources, targets):
        return bb.score_subset(state, sources, targets)

    return ModalScorer(snapshot_digest, score_batch)


def build():
    bb = ToyStructuralBackbone.from_dataset(TOY)
    snapshot = ModalSnapshot(
        graph=dataset_content_digest(TOY),
        model="no-trained-model",
        probability="independent:" + ",".join(f"{p:.4f}" for p in PROBS),
        factors="independent",
        schema="canonical-v1",
        code="toy-structural-original-float",
        scorer="toy-degree-lexical-original-float",
    )
    scorer = make_scorer(bb, snapshot.digest)
    stream = IIDWorldStream(
        snapshot.digest, SEED, tuple(monte_carlo_worlds(list(PROBS), BUDGET, SEED))
    )
    candidates = tuple(bb.target_entities)  # 3 targets
    queries = [
        ModalQuery(s, candidates, snapshot.digest, BUDGET) for s in bb.source_entities
    ]
    return bb, snapshot, scorer, stream, queries


def exhaustive_oracle(bb: ToyStructuralBackbone) -> dict[str, object]:
    worlds = exact_worlds(list(PROBS))
    sources = bb.source_entities
    targets = bb.target_entities
    winner_mass = {s: {t: 0.0 for t in targets} for s in sources}
    expected_score = {s: {t: 0.0 for t in targets} for s in sources}
    for w in worlds:
        scores = bb.score_subset(w.state, sources, targets)
        for s in sources:
            row = {t: scores[(s, t)] for t in targets}
            win = world_winner(row, targets)
            winner_mass[s][win] += w.weight
            for t in targets:
                expected_score[s][t] += w.weight * row[t]
    modal = {}
    means = {}
    for s in sources:
        modal[s] = min(winner_mass[s], key=lambda t: (-winner_mass[s][t], t))
        means[s] = min(expected_score[s], key=lambda t: (-expected_score[s][t], t))
    return {
        "world_count": len(worlds),
        "winner_mass": winner_mass,
        "weighted_modal_winner": modal,
        "weighted_mean_winner": means,
    }


def path_consistency(bb, snapshot, scorer, stream, queries) -> dict[str, object]:
    """Run >=5 execution paths; compare result dicts item-by-item."""
    reference = execute_modal_queries(queries, snapshot, stream, scorer, shared=False)
    paths = {"independent_cold": reference}

    # shared batched cold
    paths["batched_cold"] = execute_modal_queries(queries, snapshot, stream, scorer, shared=True)

    # large LRU cold + repeat warm
    big = WinnerBlockCache(16384)
    paths["lru_big_cold"] = execute_modal_queries(queries, snapshot, stream, scorer, cache=big)
    paths["lru_big_warm"] = execute_modal_queries(queries, snapshot, stream, scorer, cache=big)

    # batched + LRU cold + repeat warm (one shared cache)
    blcache = WinnerBlockCache(16384)
    paths["batched_lru_cold"] = execute_modal_queries(
        queries, snapshot, stream, scorer, cache=blcache
    )
    paths["batched_lru_warm"] = execute_modal_queries(
        queries, snapshot, stream, scorer, cache=blcache
    )

    # small 64-byte LRU cold + repeat warm (eviction forced)
    small = WinnerBlockCache(64)
    paths["lru_small64_cold"] = execute_modal_queries(queries, snapshot, stream, scorer, cache=small)
    paths["lru_small64_warm"] = execute_modal_queries(queries, snapshot, stream, scorer, cache=small)

    keys = ["status", "estimated_winner", "certified_winner", "samples_used",
            "counts", "pairwise_bounds", "evidence_digest"]
    disagreements = []
    ref = reference["results"]
    for name, res in paths.items():
        for i, r in enumerate(res["results"]):
            for k in keys:
                if r[k] != ref[i][k]:
                    disagreements.append({"path": name, "query": i, "field": k,
                                          "got": r[k], "ref": ref[i][k]})
    work = {name: res["work"] for name, res in paths.items()}
    return {
        "path_count": len(paths),
        "paths": list(paths),
        "disagreements": disagreements,
        "disagreement_count": len(disagreements),
        "work": work,
        "warm_scorer_calls": {
            "lru_big_warm": paths["lru_big_warm"]["work"]["scorer_calls"],
            "batched_lru_warm": paths["batched_lru_warm"]["work"]["scorer_calls"],
            "lru_small64_warm": paths["lru_small64_warm"]["work"]["scorer_calls"],
        },
    }


def rejection_tests(bb, snapshot, scorer, stream, queries) -> dict[str, object]:
    results = {}
    # 1. every snapshot field change rejects old stream / scorer / queries
    field_rejections = {}
    for field in ("graph", "model", "probability", "factors", "schema", "code", "scorer"):
        changed = replace(snapshot, **{field: "changed-" + field})
        cases = {}
        # stale world stream
        try:
            execute_modal_queries(queries, changed, stream, scorer)
            cases["stale_world"] = "NO_ERROR"
        except ValueError as exc:
            cases["stale_world"] = str(exc)
        new_stream = replace(stream, snapshot_digest=changed.digest)
        new_queries = [replace(q, snapshot_digest=changed.digest) for q in queries]
        try:
            execute_modal_queries(new_queries, changed, new_stream, scorer)
            cases["stale_scorer"] = "NO_ERROR"
        except ValueError as exc:
            cases["stale_scorer"] = str(exc)
        new_scorer = replace(scorer, snapshot_digest=changed.digest)
        try:
            execute_modal_queries(queries, changed, new_stream, new_scorer)
            cases["stale_query"] = "NO_ERROR"
        except ValueError as exc:
            cases["stale_query"] = str(exc)
        field_rejections[field] = cases
    results["snapshot_field_rejections"] = field_rejections
    results["snapshot_rejections_ok"] = all(
        "stale" in msg for cases in field_rejections.values() for msg in cases.values()
    )

    # 2. candidate order change never hits old labels
    cache = WinnerBlockCache(16384)
    execute_modal_queries(queries, snapshot, stream, scorer, cache=cache)
    reordered = [replace(q, candidates=tuple(reversed(q.candidates))) for q in queries]
    res = execute_modal_queries(reordered, snapshot, stream, scorer, cache=cache)
    results["candidate_order_no_reuse"] = res["work"]["cache_label_reads"] == 0

    # 3. stream seed change never hits old labels
    new_stream = replace(stream, seed=SEED + 1)
    cache2 = WinnerBlockCache(16384)
    execute_modal_queries(queries, snapshot, stream, scorer, cache=cache2)
    res2 = execute_modal_queries(queries, snapshot, new_stream, scorer, cache=cache2)
    results["stream_seed_no_reuse"] = res2["work"]["cache_label_reads"] == 0

    # 4. eviction does not change evidence (small cache repeated)
    small = WinnerBlockCache(64)
    expected = execute_modal_queries(queries, snapshot, stream, scorer)
    eviction_ok = True
    for _ in range(2):
        got = execute_modal_queries(queries, snapshot, stream, scorer, cache=small)
        if got["results"] != expected["results"]:
            eviction_ok = False
    results["eviction_preserves_evidence"] = eviction_ok
    results["eviction_count"] = small.evictions

    # 5. same seed but different probability must not reuse
    changed_snapshot = replace(snapshot, probability="independent:0.9,0.6,0.75,0.55")
    new_probs = (0.9, 0.60, 0.75, 0.55)
    new_stream2 = IIDWorldStream(
        changed_snapshot.digest, SEED,
        tuple(monte_carlo_worlds(list(new_probs), BUDGET, SEED)),
    )
    new_queries2 = [replace(q, snapshot_digest=changed_snapshot.digest) for q in queries]
    new_scorer2 = replace(scorer, snapshot_digest=changed_snapshot.digest)
    cache3 = WinnerBlockCache(16384)
    execute_modal_queries(queries, snapshot, stream, scorer, cache=cache3)
    res3 = execute_modal_queries(new_queries2, changed_snapshot, new_stream2, new_scorer2, cache=cache3)
    results["same_seed_diff_prob_no_reuse"] = res3["work"]["cache_label_reads"] == 0

    # 6. weighted exact worlds rejected from iid CS stream
    try:
        IIDWorldStream(snapshot.digest, SEED, tuple(exact_worlds(list(PROBS))))
        results["weighted_exact_rejected"] = False
    except ValueError:
        results["weighted_exact_rejected"] = True
    return results


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    RAW.mkdir(parents=True, exist_ok=True)
    bb, snapshot, scorer, stream, queries = build()

    oracle = exhaustive_oracle(bb)
    # iid MC run; compare empirical modal winner to weighted oracle
    mc = execute_modal_queries(queries, snapshot, stream, scorer)
    mc_winner = [r["estimated_winner"] for r in mc["results"]]
    mc_certified = [r["certified_winner"] for r in mc["results"]]
    sources = list(bb.source_entities)
    oracle_match = {
        s: {"oracle_modal": oracle["weighted_modal_winner"][s],
            "mc_empirical": mc_winner[i],
            "mc_certified": mc_certified[i]}
        for i, s in enumerate(sources)
    }
    empirical_matches_oracle = all(
        oracle["weighted_modal_winner"][s] == mc_winner[i]
        for i, s in enumerate(sources)
    )

    consistency = path_consistency(bb, snapshot, scorer, stream, queries)
    rejections = rejection_tests(bb, snapshot, scorer, stream, queries)

    gates = [
        {"id": "exhaustive_oracle_worlds", "passed": oracle["world_count"] == 16, "detail": oracle["world_count"]},
        {"id": "mc_empirical_matches_weighted_oracle", "passed": empirical_matches_oracle, "detail": oracle_match},
        {"id": "same_stream_zero_disagreement", "passed": consistency["disagreement_count"] == 0,
         "detail": f"paths={consistency['path_count']} disagreements={consistency['disagreement_count']}"},
        {"id": "snapshot_fields_reject", "passed": rejections["snapshot_rejections_ok"], "detail": "7 fields"},
        {"id": "candidate_order_no_reuse", "passed": rejections["candidate_order_no_reuse"], "detail": "cache_label_reads=0"},
        {"id": "stream_seed_no_reuse", "passed": rejections["stream_seed_no_reuse"], "detail": "cache_label_reads=0"},
        {"id": "eviction_preserves_evidence", "passed": rejections["eviction_preserves_evidence"], "detail": f"evictions={rejections['eviction_count']}"},
        {"id": "same_seed_diff_prob_no_reuse", "passed": rejections["same_seed_diff_prob_no_reuse"], "detail": "cache_label_reads=0"},
        {"id": "weighted_exact_rejected", "passed": rejections["weighted_exact_rejected"], "detail": "S0_exact origin rejected"},
    ]
    all_pass = all(g["passed"] for g in gates)
    status = "passed" if all_pass else "failed"

    inputs = {
        "src/pkgea/query/modal.py": exp_common.sha256_file(REPO / "src" / "pkgea" / "query" / "modal.py"),
        "src/pkgea/backbones/toy.py": exp_common.sha256_file(REPO / "src" / "pkgea" / "backbones" / "toy.py"),
        str(TOY): dataset_content_digest(TOY),
    }
    exp_common.write_json(RAW / "oracle.json", oracle)
    exp_common.write_json(RAW / "consistency.json", consistency)
    exp_common.write_json(RAW / "rejections.json", rejections)

    results = {
        "oracle": oracle,
        "mc_vs_oracle": oracle_match,
        "empirical_matches_oracle": empirical_matches_oracle,
        "consistency": consistency,
        "rejections": rejections,
    }
    output = exp_common.build_output(
        "E1", inputs=inputs, results=results, status=status, gates=gates,
        raw_files=[str(RAW / "oracle.json"), str(RAW / "consistency.json"), str(RAW / "rejections.json")],
        host_note="informal wall-clock (host may have parallel load); correctness/count metrics unaffected",
    )
    exp_common.write_json(OUT / "output.json", output)
    print(json.dumps({"status": status, "gates": [{"id": g["id"], "passed": g["passed"]} for g in gates]}, indent=2))


if __name__ == "__main__":
    main()
