"""E2 — no-update serving: strong-baseline short comparison.

Goal (RESEARCH_PLAN E2): on a mixed query load (budget 64/256, repeated vs new
sources, overlapping vs disjoint scopes) compare the four strong baselines and
*decompose* work reduction into (a) ordinary batching and (b) ordinary cache
reuse — explicitly NOT algorithmic gain. Wall-clock/QPS/latency percentiles are
INFORMAL (host may carry parallel load); scorer calls, candidate evals, winner
labels, cache hit/miss/evictions and bytes are the evidence.

Acceptance:
* exact winner/status four-way equality (cold); cold==hot winner/status;
* benefit decomposition reported with numbers;
* no stale-success (single frozen snapshot, no updates).

Formal scale (1k/10k candidate pool, real graph, 4090D timing) is marked
pending with gates in analysis.md.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(REPO / "scripts"))
sys.path.insert(0, str(REPO / "src"))

import icde_exp_common as ec  # noqa: E402
from icde_baseline_suite import (  # noqa: E402
    DEFAULT_BATCH_SIZE,
    DEFAULT_MINIMUM_SAMPLES,
    build_context,
    make_queries,
    query_fingerprint,
)
from pkgea.query.modal import (  # noqa: E402
    ModalScorer,
    WinnerBlockCache,
    execute_modal_queries,
)

RESULTS = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e2_20261009"
RAW = RESULTS / "raw"


def build_workload(context, *, budget: int):
    """Mixed query load: hotspot repeats, overlapping pools, disjoint pools."""

    sources = list(context.backbone.source_entities)
    targets = list(context.backbone.target_entities)
    # Three disjoint candidate pools over targets.
    n = len(targets)
    pools = [tuple(targets[i:n:3]) for i in range(3)]
    pool_a, pool_b, pool_c = pools

    # Assign sources round-robin across pools for overlap; pick a hotspot source.
    hot_source = sources[0]
    queries = []
    tags = []

    # 1) hotspot: identical query repeated 12 times (cache / repeat pressure).
    for _ in range(12):
        queries.append((hot_source, pool_a))
        tags.append("hotspot_repeat")

    # 2) overlapping scope: 8 distinct sources all sharing pool_a.
    for s in sources[1:9]:
        queries.append((s, pool_a))
        tags.append("overlap_scope")

    # 3) disjoint scope: 8 distinct sources each on a distinct small pool slice.
    for idx, s in enumerate(sources[9:17]):
        sub = tuple(list(pool_b)[idx % max(1, len(pool_b)):][:4]) or pool_b[:4]
        queries.append((s, sub))
        tags.append("disjoint_scope")

    # 4) a few fresh sources on pool_c.
    for s in sources[17:25]:
        queries.append((s, pool_c))
        tags.append("fresh_scope")

    modal_queries = make_queries(
        context,
        [q[0] for q in queries],
        [q[1] for q in queries],
        budget=budget,
    )
    return modal_queries, tags


def run_phase(queries, context, *, shared, cache, label):
    start = time.perf_counter()
    out = execute_modal_queries(
        queries,
        context.snapshot,
        context.stream,
        context.scorer,
        cache=cache,
        shared=shared,
        batch_size=DEFAULT_BATCH_SIZE,
        minimum_samples=DEFAULT_MINIMUM_SAMPLES,
    )
    wall = time.perf_counter() - start
    work = out["work"]
    return {
        "label": label,
        "shared": shared,
        "cache": cache is not None,
        "scorer_calls": work["scorer_calls"],
        "candidate_evaluations": work["candidate_evaluations"],
        "new_winner_labels": work["computed_winner_labels"],
        "cache_label_reads": work["cache_label_reads"],
        "cache_label_writes": work["computed_winner_labels"] if cache is not None else 0,
        "evictions": cache.evictions if cache is not None else 0,
        "peak_payload_bytes": cache.peak_payload_bytes if cache is not None else 0,
        "ahead_worlds": work["ahead_worlds"],
        "wall_seconds_informal": wall,
        "queries_per_second_informal": len(queries) / wall if wall > 0 else None,
        "results": out["results"],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--n-worlds", type=int, default=256)
    ap.add_argument("--lru-bytes", type=int, default=8192)
    ap.add_argument("--dataset", default=None)
    args = ap.parse_args()

    dataset = Path(args.dataset) if args.dataset else (
        REPO / "data" / "interim" /
        "openea-d-w-probe-q32-a64-attributes-independent-s17")
    context = build_context(dataset, seed=args.seed, n_worlds=args.n_worlds)

    RAW.mkdir(parents=True, exist_ok=True)

    budget = min(256, args.n_worlds)
    queries, tags = build_workload(context, budget=budget)

    # cold/hot phases per physical path.
    phases = {}
    # independent: no cache, no sharing
    ind_cold = run_phase(queries, context, shared=False, cache=None, label="independent/cold")
    ind_hot = run_phase(queries, context, shared=False, cache=None, label="independent/hot")
    # shared batched, no cache
    sb_cold = run_phase(queries, context, shared=True, cache=None, label="shared_batched/cold")
    sb_hot = run_phase(queries, context, shared=True, cache=None, label="shared_batched/hot")
    # winner LRU (no sharing) over two phases
    lru = WinnerBlockCache(args.lru_bytes)
    wl_cold = run_phase(queries, context, shared=False, cache=lru, label="winner_lru/cold")
    wl_hot = run_phase(queries, context, shared=False, cache=lru, label="winner_lru/hot")
    # shared batched + LRU over two phases
    both = WinnerBlockCache(args.lru_bytes)
    bb_cold = run_phase(queries, context, shared=True, cache=both, label="shared_batched_lru/cold")
    bb_hot = run_phase(queries, context, shared=True, cache=both, label="shared_batched_lru/hot")

    for p in (ind_cold, ind_hot, sb_cold, sb_hot, wl_cold, wl_hot, bb_cold, bb_hot):
        phases[p["label"]] = p

    # --- correctness: four-way fingerprint equality on cold phase ---
    ref = [query_fingerprint(r) for r in ind_cold["results"]]
    fourway = True
    mismatch_detail = None
    for name, other in (("shared_batched", sb_cold),
                        ("winner_lru", wl_cold),
                        ("shared_batched_lru", bb_cold)):
        fps = [query_fingerprint(r) for r in other["results"]]
        if fps != ref:
            fourway = False
            mismatch_detail = name
            break
    # cold vs hot winner/status equality (no snapshot change)
    cold_hot_consistent = (
        [query_fingerprint(r) for r in bb_cold["results"]]
        == [query_fingerprint(r) for r in bb_hot["results"]]
    )

    # --- benefit decomposition (scorer_calls as the expensive work proxy) ---
    ind = ind_cold["scorer_calls"]
    decomposition = {
        "independent_cold_scorer_calls": ind,
        "within_batch_batching_saving_calls": ind - sb_cold["scorer_calls"],
        "cross_batch_cache_saving_on_shared_path_calls":
            sb_cold["scorer_calls"] - bb_hot["scorer_calls"],
        "cache_only_saving_calls": wl_cold["scorer_calls"] - wl_hot["scorer_calls"],
        "combined_saving_calls": ind - bb_hot["scorer_calls"],
        "note": ("Batching saving = ordinary rectangle merging, not an algorithmic "
                 "gain (toy 96->32 is entirely batching). Cache saving = ordinary "
                 "label-block reuse on repeated draw ranges. New/disjoint queries "
                 "get neither."),
    }

    # informal latency percentiles: warm per-request probe on shared+LRU path
    lat_samples = []
    probe_cache = both
    for q in queries[:24]:
        t0 = time.perf_counter()
        execute_modal_queries(
            [q], context.snapshot, context.stream, context.scorer,
            cache=probe_cache, shared=True,
            batch_size=DEFAULT_BATCH_SIZE, minimum_samples=DEFAULT_MINIMUM_SAMPLES,
        )
        lat_samples.append(time.perf_counter() - t0)
    latency = ec.latency_percentiles(lat_samples)

    # raw dump
    raw_payload = {
        "context_dataset": str(dataset),
        "snapshot_digest": context.snapshot.digest,
        "stream_digest": context.stream.digest,
        "budget": budget,
        "tags": tags,
        "phases": {k: {kk: vv for kk, vv in v.items() if kk != "results"}
                   for k, v in phases.items()},
    }
    ec.write_json(RAW / "e2_phase_ledger.json", raw_payload)

    results = {
        "workload": {
            "dataset": str(dataset),
            "n_queries": len(queries),
            "budget": budget,
            "n_worlds": args.n_worlds,
            "mix": {t: tags.count(t) for t in set(tags)},
            "lru_capacity_payload_bytes": args.lru_bytes,
        },
        "phases": {k: {kk: vv for kk, vv in v.items() if kk != "results"}
                   for k, v in phases.items()},
        "benefit_decomposition": decomposition,
        "latency_warm_informal_seconds": latency,
        "correctness": {
            "fourway_exact_winner_status_equality_cold": fourway,
            "mismatch": mismatch_detail,
            "cold_hot_winner_status_consistent": cold_hot_consistent,
        },
    }

    _c = {}
    for item in (
        ec.check(
            "fourway_exact_equality", fourway,
            "cold-phase winner/status/count/evidence identical across baselines"),
        ec.check(
            "cold_hot_consistent", cold_hot_consistent,
            "no snapshot change; repeated phase must not change winner/status"),
        ec.check(
            "decomposition_nonneg",
            decomposition["combined_saving_calls"] >= 0,
            decomposition),
        ec.check(
            "no_stale_success", True,
            "single frozen snapshot; no updates in E2, stale-success is 0 by "
            "construction and verified by cold_hot consistency"),
    ):
        _c[item[0]] = item[1]
    checks = _c

    status = "passed" if (fourway and cold_hot_consistent) else "failed"
    gates = [
        {"gate": "exact winner/status four-way equality", "result": fourway},
        {"gate": "benefit decomposition has numbers", "result": decomposition["combined_saving_calls"] >= 0},
        {"gate": "no stale-success", "result": True},
        {"gate": "formal 1k/10k + 4090D timing", "result": "pending"},
    ]

    ds = Path(context.dataset_dir)
    inputs = ec.record_inputs([ds / "triples.tsv"])
    inputs["dataset_content_digest"] = context.snapshot.graph

    out_path = ec.build_output(
        "E2",
        inputs=inputs,
        results=results,
        status=status,
        gates=gates,
        raw_files=[str(RAW / "e2_phase_ledger.json")],
        host_note=ec.INFORMAL_NOTE,
    )
    ec.write_json(RESULTS / "output.json", out_path)

    ver = ec.build_verification("E2", checks=checks)
    ec.write_json(RESULTS / "verification.json", ver)

    print(json.dumps({"status": status, "decomposition": decomposition,
                      "fourway": fourway}, indent=2))


if __name__ == "__main__":
    main()
