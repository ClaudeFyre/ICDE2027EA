"""E6 reinforcement: concurrent-reader consistency during live publish switches.

N reader subprocesses continuously read the currently published snapshot
(root pointer -> committed manifest -> all blocks) while the parent publishes
v2 and v3 underneath them. Each sample is classified as:

  - consistent: manifest version == the singleton set of block versions;
  - torn: manifest version != block versions (e.g. new manifest + old blocks,
    or old manifest + new blocks);
  - error: any file missing / unreadable mid-switch.

Expectation: every sample is consistent, and readers collectively observe
versions 1, 2 and 3 (i.e. they sampled across the live switches), with zero
torn combinations. Read isolation is therefore *snapshot*: a reader always
sees one complete old or new version, never a mix.

Reuses publish_proto.PublishStore (import, unchanged) and run_e6.publish_snapshot.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

_HERE = Path(__file__).resolve()
EXPERIMENTS = _HERE.parents[1]
sys.path.insert(0, str(EXPERIMENTS / "_common"))
sys.path.insert(0, str(_HERE.parent))
import icde_paths  # noqa: E402  (portable repo resolver)

REPO = icde_paths.resolve_repo_root(__file__)

import exp_common  # noqa: E402
from publish_proto import PublishStore  # noqa: E402
from run_e6 import publish_snapshot  # noqa: E402

HERE = _HERE.parent
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e6_20261009" / "concurrent_readers_20261009"
RAW = OUT / "raw"
WORK = OUT / "_work"

N_READERS = 4
SAMPLES_PER_READER = 150
READER_SLEEP_S = 0.005

FACTS_TEMPLATE = [{"id": "f1", "gen": 1, "state": "present", "payload": "a"}]


def _extract_block_version(name: str, data: bytes) -> str:
    """Mirror run_e6.toy_blocks so a reader can name the version of a block."""
    if name == "graph":
        # b"toy-graph-v<N>"
        return data.decode("ascii").rsplit("-v", 1)[1]
    return json.loads(data.decode("utf-8"))["version"]


def _reader_sample(work: Path, i: int) -> dict:
    try:
        root = (work / "root").read_text(encoding="utf-8").strip()
        m = json.loads((work / "manifests" / "committed" / f"{root}.json").read_text(encoding="utf-8"))
        block_versions = {
            _extract_block_version(name, (work / "blocks" / f"{ref}.bin").read_bytes())
            for name, ref in m["blocks"].items()
        }
        consistent = block_versions == {m["version"]}
        return {
            "i": i, "root": root[:16], "manifest_version": m["version"],
            "block_versions": sorted(block_versions), "kind": "ok" if consistent else "torn",
        }
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        return {"i": i, "kind": "error"}


def _reader_main(work: Path, reader_id: int, samples: int, out_path: Path) -> None:
    observations: list[dict] = []
    for i in range(samples):
        observations.append(_reader_sample(work, i))
        time.sleep(READER_SLEEP_S)
    by_kind = Counter(o["kind"] for o in observations)
    by_version = Counter(o.get("manifest_version") for o in observations if o["kind"] == "ok")
    result = {
        "reader_id": reader_id,
        "samples": len(observations),
        "by_kind": dict(by_kind),
        "consistent_by_version": dict(by_version),
        "torn_examples": [o for o in observations if o["kind"] == "torn"][:5],
        "error_examples": [o for o in observations if o["kind"] == "error"][:5],
    }
    exp_common.write_json(out_path, result)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reader", action="store_true")
    parser.add_argument("--work", type=Path)
    parser.add_argument("--id", type=int, default=0)
    parser.add_argument("--samples", type=int, default=SAMPLES_PER_READER)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    if args.reader:
        _reader_main(args.work, args.id, args.samples, args.out)
        return

    OUT.mkdir(parents=True, exist_ok=True)
    RAW.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(WORK, ignore_errors=True)
    WORK.mkdir(parents=True, exist_ok=True)

    store = PublishStore(WORK, crash_at=None)
    v1 = publish_snapshot(store, "1", None, FACTS_TEMPLATE)
    store.close()

    procs: list[subprocess.Popen] = []
    reader_out_paths = []
    for k in range(N_READERS):
        rp = RAW / f"reader_{k}.json"
        reader_out_paths.append(rp)
        procs.append(subprocess.Popen(
            [sys.executable, str(Path(__file__).resolve()), "--reader",
             "--work", str(WORK), "--id", str(k),
             "--samples", str(SAMPLES_PER_READER), "--out", str(rp)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        ))

    # Live publish switches *while readers sample*.
    timeline: list[dict] = []
    time.sleep(0.15)
    store = PublishStore(WORK, crash_at=None)
    v2 = publish_snapshot(store, "2", v1, FACTS_TEMPLATE)
    timeline.append({"t": 0.15, "published": "2", "root": v2[:16]})
    time.sleep(0.45)
    v3 = publish_snapshot(store, "3", v2, FACTS_TEMPLATE)
    timeline.append({"t": 0.60, "published": "3", "root": v3[:16]})
    store.close()

    results_per_reader = []
    for k, p in enumerate(procs):
        out, err = p.communicate(timeout=60)
        p.wait(timeout=10)
        rec = json.loads(reader_out_paths[k].read_text(encoding="utf-8"))
        rec["proc_rc"] = p.returncode
        if p.returncode != 0:
            rec["stderr_tail"] = (err or b"").decode("utf-8", "replace")[-400:]
        results_per_reader.append(rec)

    total_samples = sum(r["samples"] for r in results_per_reader)
    total_torn = sum(r["by_kind"].get("torn", 0) for r in results_per_reader)
    total_errors = sum(r["by_kind"].get("error", 0) for r in results_per_reader)
    versions_seen = set()
    for r in results_per_reader:
        versions_seen |= set(r["consistent_by_version"].keys())
    versions_seen = {str(v) for v in versions_seen if v is not None}

    gates = [
        {"id": "zero_torn_reads", "passed": total_torn == 0,
         "detail": f"{total_torn} torn / {total_samples} samples"},
        {"id": "zero_mid_switch_read_errors", "passed": total_errors == 0,
         "detail": f"{total_errors} errors / {total_samples} samples"},
        {"id": "readers_sampled_across_switches",
         "passed": {"1", "2", "3"}.issubset(versions_seen),
         "detail": f"versions seen: {sorted(versions_seen)}"},
        {"id": "per_reader_sample_count",
         "passed": all(r["samples"] == SAMPLES_PER_READER for r in results_per_reader),
         "detail": f"target {SAMPLES_PER_READER} x {N_READERS} readers"},
        {"id": "all_reader_processes_exited_cleanly",
         "passed": all(r["proc_rc"] == 0 for r in results_per_reader),
         "detail": f"rcs: {[r['proc_rc'] for r in results_per_reader]}"},
    ]
    status = "partial" if (total_torn == 0 and total_errors == 0) else "failed"

    inputs = {
        "experiments/E6_recovery/publish_proto.py": exp_common.sha256_file(HERE / "publish_proto.py"),
        "experiments/E6_recovery/run_e6.py": exp_common.sha256_file(HERE / "run_e6.py"),
        "experiments/E6_recovery/run_e6_concurrent_readers.py": exp_common.sha256_file(Path(__file__)),
    }
    exp_common.write_json(RAW / "timeline.json", timeline)

    results = {
        "n_readers": N_READERS,
        "samples_per_reader": SAMPLES_PER_READER,
        "reader_sleep_seconds": READER_SLEEP_S,
        "total_samples": total_samples,
        "total_torn": total_torn,
        "total_mid_switch_errors": total_errors,
        "versions_seen_consistently": sorted(versions_seen),
        "publish_timeline": timeline,
        "per_reader": results_per_reader,
        "scope_note": (
            "Toy-graph blocks only. Snapshot read isolation here means: a concurrent reader "
            "always reads one complete old or new published snapshot, never a mix. This is "
            "not yet a claim about real score/embedding/evidence blocks (C3-unfinished; no "
            "torch/GPU on this host). E6 stays partial."
        ),
    }
    output = exp_common.build_output(
        "E6-concurrent-readers", inputs=inputs, results=results, status=status, gates=gates,
        raw_files=[str(p) for p in reader_out_paths] + [str(RAW / "timeline.json")],
        host_note="informal wall-clock (host may have parallel load); correctness/count metrics unaffected",
    )
    exp_common.write_json(OUT / "output.json", output)
    _postprocess(output)
    print(json.dumps({
        "status": status,
        "total_samples": total_samples, "torn": total_torn, "errors": total_errors,
        "versions_seen": sorted(versions_seen),
        "gates": {g["id"]: g["passed"] for g in gates},
    }, indent=2))


def _postprocess(output: dict) -> None:
    r = output["results"]
    checks: dict[str, dict[str, object]] = {}
    for name, ok, ev in [
        ("format_is_v1", output.get("format") == "icde-experiment-output-v1", output.get("format")),
        ("zero_torn", r["total_torn"] == 0, {"torn": r["total_torn"], "samples": r["total_samples"]}),
        ("zero_read_errors", r["total_mid_switch_errors"] == 0, r["total_mid_switch_errors"]),
        ("all_three_versions_observed",
         {"1", "2", "3"}.issubset(set(r["versions_seen_consistently"])),
         r["versions_seen_consistently"]),
        ("per_reader_counts",
         all(pr["by_kind"].get("torn", 0) == 0 and pr["by_kind"].get("error", 0) == 0
             for pr in r["per_reader"]),
         {pr["reader_id"]: pr["consistent_by_version"] for pr in r["per_reader"]}),
        ("status_partial_by_scope", output["status"] == "partial", output["status"]),
    ]:
        checks[name] = {"ok": bool(ok), "evidence": ev}
    verification = exp_common.build_verification("E6-concurrent-readers", checks=checks)
    exp_common.write_json(OUT / "verification.json", verification)

    L = []
    L.append("# E6 concurrent readers — analysis")
    L.append("")
    L.append(f"- status: **{output['status']}** (partial by scope)  created: {output['created']}")
    L.append(f"- host: {output['host']['os']} / Python {output['host']['python']}")
    L.append("")
    L.append("## 1. Method")
    L.append("")
    L.append(f"{r['n_readers']} reader subprocesses each took {r['samples_per_reader']} samples "
             f"(~{r['reader_sleep_seconds']*1000:.1f} ms apart). Between samples the parent "
             "published v2 at t=0.15s and v3 at t=0.60s. A sample reads the `root` pointer, the")
    L.append("committed manifest it names, and every block the manifest references; it is torn iff")
    L.append("the manifest version disagrees with the blocks' versions.")
    L.append("")
    L.append("## 2. Identity-combination statistics")
    L.append("")
    L.append("| reader | samples | consistent v1 | consistent v2 | consistent v3 | torn | errors |")
    L.append("| --- | --- | --- | --- | --- | --- | --- |")
    for pr in r["per_reader"]:
        cv = pr["consistent_by_version"]
        L.append(
            f"| {pr['reader_id']} | {pr['samples']} | {cv.get('1', 0)} | {cv.get('2', 0)} "
            f"| {cv.get('3', 0)} | {pr['by_kind'].get('torn', 0)} | {pr['by_kind'].get('error', 0)} |"
        )
    L.append("")
    L.append(f"- total samples: **{r['total_samples']}**; torn combinations: **{r['total_torn']}**; "
             f"mid-switch read errors: **{r['total_mid_switch_errors']}**")
    L.append(f"- versions seen consistently: {r['versions_seen_consistently']}")
    L.append("")
    L.append("Because blocks are written and durably renamed before the manifest is prepared, the")
    L.append("prepared manifest is moved to committed before the root pointer switches, and the root")
    L.append("switch itself is atomic (temp+rename), a reader following the `root` pointer always")
    L.append("resolves to one complete version — the old one until the switch lands, the new one")
    L.append("immediately after. No \"new manifest + old blocks\" or \"old manifest + new blocks\"")
    L.append("combination was observed in any of the samples.")
    L.append("")
    L.append("## 3. Limitations (must stay visible)")
    L.append("")
    L.append(f"- {r['scope_note']}")
    L.append("- Toy blocks; no real score/embedding/evidence blocks, no torch/GPU on this host.")
    L.append("- Reader sampling rate is small (ms-scale); a much higher read rate or a storage")
    L.append("  device with non-atomic rename semantics is not exercised.")
    L.append("- Wall-clock timings informal; counts/correctness do not depend on them.")
    (OUT / "analysis.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print(f"wrote {OUT / 'analysis.md'} and {OUT / 'verification.json'}")


if __name__ == "__main__":
    main()
