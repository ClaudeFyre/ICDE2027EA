"""E6 full-recovery runner.

Drives the minimal unified-publish prototype through:
  - crash injection at every stage (block write / prepared write / root publish /
    commit ack), restart, and recovery to the previously published snapshot;
  - event sequences: duplicate (dedup), conflicting payload (reject), late
    operation, delete/re-add generation, rollback to a published historical root.

Scope: engineering prototype on toy-graph blocks. Real score/embedding/evidence
blocks through this protocol is C3-unfinished, so E6 status is partial.
"""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

_HERE = Path(__file__).resolve()
EXPERIMENTS = _HERE.parents[1]
sys.path.insert(0, str(EXPERIMENTS / "_common"))
sys.path.insert(0, str(_HERE.parent))
import icde_paths  # noqa: E402  (portable repo resolver)

REPO = icde_paths.resolve_repo_root(__file__)

import exp_common  # noqa: E402
from publish_proto import PublishStore, SimulatedCrash  # noqa: E402

OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e6_20261009"
RAW = OUT / "raw"
WORK = OUT / "_work"

STAGES = [
    "before_block_write",
    "after_block_write",
    "before_prepared_write",
    "after_prepared_write",
    "before_root_publish",
    "after_root_publish",
    "before_commit_ack",
    "after_commit_ack",
]


def toy_blocks(version: str) -> dict[str, bytes]:
    return {
        "graph": f"toy-graph-v{version}".encode(),
        "probability": json.dumps({"p": [0.8, 0.6, 0.75, 0.55], "version": version}).encode(),
        "candidates": json.dumps({"sources": ["s:alice", "s:bob"], "version": version}).encode(),
    }


def publish_snapshot(store: PublishStore, version: str, parent: str | None, facts: list[dict]) -> str:
    digests = {name: store.write_block(data) for name, data in toy_blocks(version).items()}
    manifest = {
        "format": "pkgea-snapshot-manifest-v1",
        "version": version,
        "parent": parent,
        "blocks": digests,
        "facts": facts,
    }
    md = store.prepare_manifest(manifest)
    store.commit_manifest(md)
    return md


def crash_study() -> dict:
    results = []
    for stage in STAGES:
        work = WORK / f"crash_{stage}"
        shutil.rmtree(work, ignore_errors=True)
        # publish v1 cleanly
        s1 = PublishStore(work, crash_at=None)
        v1 = publish_snapshot(s1, "1", None, [{"id": "f1", "gen": 1, "state": "present", "payload": "a"}])
        s1.close()
        # attempt v2 with crash
        s2 = PublishStore(work, crash_at=stage)
        crashed = None
        try:
            publish_snapshot(s2, "2", v1, [{"id": "f1", "gen": 1, "state": "present", "payload": "a"}])
        except SimulatedCrash as exc:
            crashed = exc.stage
        s2.close()
        # restart
        s3 = PublishStore(work, crash_at=None)
        root = s3.published_root()
        v1_manifest = s3.read_manifest(v1)
        committed_ids = sorted(p.stem for p in (s3.root / "manifests" / "committed").glob("*.json"))
        gc_removed = s3.gc_sweep()
        # Atomicity invariant: root either stayed v1 (crash before pointer switch)
        # or advanced to v2 (crash after a fully durable pointer switch). In both
        # cases the pointed-to manifest must exist and its blocks must be readable
        # (no torn read).
        v2_digests = [d for d in committed_ids if d != v1]
        root_is_v1 = root == v1
        root_is_v2 = (root is not None) and v2_digests and root == v2_digests[0]
        root_valid = root_is_v1 or root_is_v2
        pointed_manifest_ok = False
        blocks_readable = False
        if root_valid and root is not None:
            try:
                m = s3.read_manifest(root)
                pointed_manifest_ok = True
                blocks_readable = all(s3.read_block(ref) for ref in m["blocks"].values())
            except FileNotFoundError:
                pointed_manifest_ok = False
        # v1 blocks always readable
        v1_blocks_ok = all(s3.read_block(ref) for ref in v1_manifest["blocks"].values())
        s3.close()
        recovered_what = "v2_published" if root_is_v2 else "v1_kept_v2_discarded"
        results.append({
            "stage": stage,
            "crashed_at": crashed,
            "root_after_restart": root,
            "v1_digest": v1,
            "committed_manifests": committed_ids,
            "root_points_to_valid_snapshot": root_valid,
            "pointed_manifest_readable": pointed_manifest_ok,
            "pointed_blocks_readable": blocks_readable,
            "v1_blocks_readable": v1_blocks_ok,
            "no_torn_read": pointed_manifest_ok and blocks_readable and root_valid,
            "recovered_to": recovered_what,
            "gc_removed_unreachable": gc_removed,
        })
    return results


def event_sequence_study() -> dict:
    work = WORK / "events"
    shutil.rmtree(work, ignore_errors=True)
    s = PublishStore(work, crash_at=None)
    out = {}

    # duplicate event
    out["dup1"] = s.apply_event("e1", "payload-x")
    out["dup2"] = s.apply_event("e1", "payload-x")  # no-op
    # conflicting event
    try:
        s.apply_event("e1", "payload-y")
        out["conflict"] = "NO_ERROR"
    except ValueError:
        out["conflict"] = "rejected"

    # version chain with delete / re-add generation
    v1 = publish_snapshot(s, "1", None, [{"id": "f1", "gen": 1, "state": "present", "payload": "a"}])
    # v2 tombstones f1
    v2 = publish_snapshot(s, "2", v1, [{"id": "f1", "gen": 1, "state": "tombstone", "payload": None}])
    # v3 re-adds f1 with new generation
    v3 = publish_snapshot(s, "3", v2, [{"id": "f1", "gen": 2, "state": "present", "payload": "b"}])

    m3 = s.read_manifest(v3)
    f1_v3 = [f for f in m3["facts"] if f["id"] == "f1"][0]
    out["readd_new_generation"] = (f1_v3["gen"] == 2 and f1_v3["state"] == "present")

    # late operation: apply an event after v3 published (does not rewrite history)
    out["late_event"] = s.apply_event("e2", "late")

    # rollback to v1 (published historical root); must not splice v2+v1
    s.db.execute(
        "INSERT OR REPLACE INTO meta (key,value) VALUES ('root', ?)", (v1,)
    )
    s.db.commit()
    # atomic pointer switch to v1
    (s.root / "root").write_text(v1, encoding="utf-8")
    root_after_rollback = s.published_root()
    m_rb = s.read_manifest(root_after_rollback)
    out["rollback_root"] = root_after_rollback
    out["rollback_is_v1"] = (root_after_rollback == v1)
    out["rollback_fact_state"] = m_rb["facts"][0]["state"]  # must be present gen1, not tombstone
    out["rollback_no_splice"] = (m_rb["version"] == "1" and m_rb["parent"] is None)
    s.close()
    return out


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    RAW.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)

    crashes = crash_study()
    events = event_sequence_study()

    crash_all_ok = all(
        c["no_torn_read"] and c["v1_blocks_readable"]
        for c in crashes
    )

    gates = [
        {"id": "crash_all_stages_recover", "passed": crash_all_ok,
         "detail": f"{sum(c['no_torn_read'] for c in crashes)}/{len(crashes)} stages no-torn"},
        {"id": "duplicate_event_dedup", "passed": events["dup2"] == "duplicate_noop", "detail": events["dup2"]},
        {"id": "conflicting_event_rejected", "passed": events["conflict"] == "rejected", "detail": events["conflict"]},
        {"id": "readd_new_generation", "passed": events["readd_new_generation"], "detail": "gen2 present"},
        {"id": "late_event_applied", "passed": events["late_event"] == "applied", "detail": events["late_event"]},
        {"id": "rollback_to_published_root", "passed": events["rollback_is_v1"] and events["rollback_no_splice"],
         "detail": f"root={events['rollback_root']} fact={events['rollback_fact_state']}"},
    ]
    # E6 is partial by scope: real evidence blocks not yet unified
    status = "partial" if crash_all_ok else "failed"

    inputs = {
        "experiments/E6_recovery/publish_proto.py": exp_common.sha256_file(
            REPO / "nodes" / "05_icde_query_engine" / "experiments" / "E6_recovery" / "publish_proto.py"
        ),
    }
    exp_common.write_json(RAW / "crash_study.json", {"stages": crashes})
    exp_common.write_json(RAW / "event_study.json", events)

    results = {
        "crash_study": crashes,
        "event_sequence": events,
        "scope_note": (
            "Engineering prototype on toy-graph blocks (graph/probability/candidates). "
            "Real score/embedding/evidence blocks through this manifest protocol is C3-unfinished. "
            "Existing DurableStreamingWorker only updates probability/moments and is not claimed durable here."
        ),
        "gate_to_full": "real query evidence blocks go through the same immutable-block + manifest + root-publish protocol",
    }
    output = exp_common.build_output(
        "E6", inputs=inputs, results=results, status=status, gates=gates,
        raw_files=[str(RAW / "crash_study.json"), str(RAW / "event_study.json")],
        host_note="informal wall-clock (host may have parallel load); correctness/count metrics unaffected",
    )
    exp_common.write_json(OUT / "output.json", output)
    print(json.dumps({"status": status, "gates": [{"id": g["id"], "passed": g["passed"]} for g in gates]}, indent=2))


if __name__ == "__main__":
    main()
