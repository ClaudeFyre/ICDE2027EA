"""E6 verification."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "_common"))
import icde_paths  # noqa: E402
import exp_common  # noqa: E402

REPO = icde_paths.resolve_repo_root(__file__)
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e6_20261009"


def main() -> None:
    out = json.loads((OUT / "output.json").read_text(encoding="utf-8"))
    crashes = out["results"]["crash_study"]
    ev = out["results"]["event_sequence"]

    checks = {}
    for name, ok, e in [
        ("format_is_v1", out.get("format") == "icde-experiment-output-v1", out.get("format")),
        ("all_8_stages_no_torn", all(c["no_torn_read"] for c in crashes),
         {c["stage"]: c["recovered_to"] for c in crashes}),
        ("pre_root_publish_keeps_v1",
         all(c["recovered_to"] == "v1_kept_v2_discarded"
             for c in crashes if c["stage"] in {
                 "before_block_write", "after_block_write",
                 "before_prepared_write", "after_prepared_write",
                 "before_root_publish"}),
         "crashes before pointer switch must keep v1"),
        ("post_root_publish_publishes_v2",
         all(c["recovered_to"] == "v2_published"
             for c in crashes if c["stage"] in {
                 "after_root_publish", "before_commit_ack", "after_commit_ack"}),
         "crashes after pointer switch must show v2 committed"),
        ("duplicate_dedup", ev["dup2"] == "duplicate_noop", ev["dup2"]),
        ("conflict_rejected", ev["conflict"] == "rejected", ev["conflict"]),
        ("readd_new_generation", ev["readd_new_generation"], True),
        ("late_event_applied", ev["late_event"] == "applied", ev["late_event"]),
        ("rollback_no_splice", ev["rollback_is_v1"] and ev["rollback_no_splice"],
         {"root": ev["rollback_root"], "fact": ev["rollback_fact_state"]}),
        ("status_partial_by_scope", out["status"] == "partial", out["status"]),
    ]:
        key, item = exp_common.check(name, ok, e)
        checks[key] = item

    verification = exp_common.build_verification("E6", checks=checks)
    exp_common.write_json(OUT / "verification.json", verification)
    print(json.dumps({"passed": verification["passed"], "checks": {k: v["ok"] for k, v in checks.items()}}, indent=2))


if __name__ == "__main__":
    main()
