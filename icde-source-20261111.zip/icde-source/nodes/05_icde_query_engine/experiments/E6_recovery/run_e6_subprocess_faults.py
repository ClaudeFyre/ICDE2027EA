"""E6 reinforcement: real subprocess forced-termination crash injection.

Extends the in-process SimulatedCrash study (run_e6.py) with *real* process
deaths at named publish stages:

  - os._exit(91)  : power-cut-style exit; skips finally / close / db commit.
  - taskkill /F   : Windows equivalent of POSIX SIGKILL (no POSIX SIGKILL
                    exists on Windows; /F terminates without giving the
                    process a chance to clean up).

Each run: publish v1 cleanly in the parent, spawn a worker subprocess that
attempts to publish v2 and dies hard at the chosen stage, then the parent
restarts a fresh PublishStore on the same directory and checks the recovery
invariants (root identity, no torn read, v1 blocks intact, GC sweep).

This script does NOT modify publish_proto.py / run_e6.py; it subclasses
PublishStore to turn the named crash points into a real process exit.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

_HERE = Path(__file__).resolve()
EXPERIMENTS = _HERE.parents[1]
sys.path.insert(0, str(EXPERIMENTS / "_common"))
sys.path.insert(0, str(_HERE.parent))
import icde_paths  # noqa: E402  (portable repo resolver)

REPO = icde_paths.resolve_repo_root(__file__)

import exp_common  # noqa: E402
from publish_proto import PublishStore  # noqa: E402
from run_e6 import publish_snapshot  # noqa: E402  (reused verbatim)

HERE = _HERE.parent
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e6_20261009" / "subprocess_faults_20261009"
RAW = OUT / "raw"
WORK = OUT / "_work"

# Injection points (task wording): after block write, after prepared manifest,
# before root publish, after root publish, after commit ack.
STAGES = [
    "after_block_write",
    "after_prepared_write",
    "before_root_publish",
    "after_root_publish",
    "after_commit_ack",
]
PRE_SWITCH = {"after_block_write", "after_prepared_write", "before_root_publish"}
POST_SWITCH = {"after_root_publish", "after_commit_ack"}
EXTERNAL_KILL = "taskkill" if os.name == "nt" else "sigkill"

V1_FACTS = [{"id": "f1", "gen": 1, "state": "present", "payload": "a"}]


# ---------------------------------------------------------------------------
# worker-side stores (subclassed; publish_proto untouched)
# ---------------------------------------------------------------------------
class HardExitStore(PublishStore):
    """At the named stage, exit the process immediately with code 91."""

    def _maybe_crash(self, stage: str) -> None:
        if self.crash_at == stage:
            os._exit(91)


class SentinelStore(PublishStore):
    """Touch the sentinel at the named stage, then block forever.

    The parent detects the sentinel and runs `taskkill /F /PID`, i.e. the
    Windows equivalent of SIGKILL (no POSIX SIGKILL on Windows).
    """

    def __init__(self, *args: object, sentinel: str | None = None, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)  # type: ignore[arg-type]
        self.sentinel = sentinel

    def _maybe_crash(self, stage: str) -> None:
        if self.crash_at == stage:
            Path(self.sentinel).touch()
            sys.stdout.flush()
            sys.stderr.flush()
            while True:
                time.sleep(1)


# ---------------------------------------------------------------------------
# worker entry points (invoked as subprocess by main)
# ---------------------------------------------------------------------------
def _hard_exit_worker(work: Path, stage: str, parent: str) -> None:
    store = HardExitStore(work, crash_at=stage)
    publish_snapshot(store, "2", parent, V1_FACTS)
    # must never reach here: os._exit fires inside the publish flow


def _sentinel_worker(work: Path, stage: str, parent: str, sentinel: Path) -> None:
    store = SentinelStore(work, crash_at=stage, sentinel=str(sentinel))
    publish_snapshot(store, "2", parent, V1_FACTS)


# ---------------------------------------------------------------------------
# parent helpers
# ---------------------------------------------------------------------------
def _spawn(extra: list[str]) -> subprocess.Popen:
    return subprocess.Popen(
        [sys.executable, str(Path(__file__).resolve()), *extra],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def _publish_v1(work: Path) -> str:
    s = PublishStore(work, crash_at=None)
    v1 = publish_snapshot(s, "1", None, V1_FACTS)
    s.close()
    return v1


def _recover_and_check(work: Path, v1: str, stage: str) -> dict:
    s = PublishStore(work, crash_at=None)
    root_after = s.published_root()
    committed = sorted(p.stem for p in (s.root / "manifests" / "committed").glob("*.json"))
    prepared_left = sorted(p.stem for p in (s.root / "manifests" / "prepared").glob("*.json"))
    v2_committed = [d for d in committed if d != v1]

    pointed_ok = False
    blocks_ok = False
    if root_after:
        try:
            m = s.read_manifest(root_after)
            pointed_ok = True
            blocks_ok = all(s.read_block(ref) for ref in m["blocks"].values())
        except (FileNotFoundError, KeyError):
            pointed_ok = False
            blocks_ok = False

    v1_m = s.read_manifest(v1)
    v1_blocks_ok = all(s.read_block(ref) for ref in v1_m["blocks"].values())
    gc_removed = s.gc_sweep()
    s.close()

    root_is_v1 = root_after == v1
    root_is_v2 = bool(root_after is not None and v2_committed and root_after == v2_committed[0])
    no_torn = (root_is_v1 or root_is_v2) and pointed_ok and blocks_ok
    if root_is_v2:
        recovered_to = "v2_published"
    elif root_is_v1:
        recovered_to = "v1_kept_v2_discarded"
    else:
        recovered_to = "UNEXPECTED"
    expected_to = "v1_kept_v2_discarded" if stage in PRE_SWITCH else "v2_published"
    return {
        "root_after_restart": root_after,
        "committed_manifests": committed,
        "prepared_left_after_gc": prepared_left,
        "v1_blocks_readable": v1_blocks_ok,
        "pointed_manifest_readable": pointed_ok,
        "pointed_blocks_readable": blocks_ok,
        "no_torn_read": no_torn,
        "recovered_to": recovered_to,
        "expected_recovered_to": expected_to,
        "recovery_matches_expected": recovered_to == expected_to,
        "gc_removed_unreachable": sorted(gc_removed),
    }


def _run_one(stage: str, method: str) -> dict:
    work = WORK / f"{stage}__{method}"
    shutil.rmtree(work, ignore_errors=True)
    v1 = _publish_v1(work)

    sentinel = work / "worker_sentinel.touch"
    record: dict = {
        "stage": stage,
        "kill_method": method,
        "kill_method_note": (
            "os._exit(91): in-process power-cut-style exit, skips finally/close"
            if method == "os_exit"
            else "Windows taskkill /F" if method == "taskkill" else "POSIX SIGKILL via Popen.kill()"
        ),
        "v1_digest": v1,
        "root_before_crash": v1,
    }

    proc = None
    try:
        if method == "os_exit":
            proc = _spawn(["--hard-exit-worker", "--work", str(work), "--stage", stage, "--parent", v1])
            record["sentinel_seen"] = False
            out, err = proc.communicate(timeout=60)
        else:
            if sentinel.exists():
                sentinel.unlink()
            proc = _spawn(["--sentinel-worker", "--work", str(work), "--stage", stage,
                           "--parent", v1, "--sentinel", str(sentinel)])
            deadline = time.monotonic() + 60.0
            while time.monotonic() < deadline and not sentinel.exists() and proc.poll() is None:
                time.sleep(0.02)
            record["sentinel_seen"] = sentinel.exists()
            if not record["sentinel_seen"]:
                raise RuntimeError("worker never reached the requested crash stage")
            if method == "taskkill":
                kill = subprocess.run(["taskkill", "/F", "/PID", str(proc.pid)],
                                      capture_output=True, text=True, timeout=30, check=True)
                record["taskkill_rc"] = kill.returncode
                record["taskkill_stdout"] = kill.stdout.strip()
            elif method == "sigkill":
                proc.kill()
            else:
                raise ValueError(method)
            out, err = proc.communicate(timeout=30)
        record["worker_exit_code"] = proc.returncode
        expected_exit = 91 if method == "os_exit" else -9 if method == "sigkill" else None
        record["forced_exit_verified"] = (proc.returncode == expected_exit
                                          if expected_exit is not None else proc.returncode != 0)
        if not record["forced_exit_verified"]:
            raise RuntimeError(f"unexpected worker exit: {proc.returncode}")
    finally:
        if proc is not None and proc.poll() is None:
            proc.kill()
            proc.communicate(timeout=10)

    record["worker_stdout_tail"] = (out or b"").decode("utf-8", "replace")[-200:]
    record["worker_stderr_tail"] = (err or b"").decode("utf-8", "replace")[-400:]

    rec = _recover_and_check(work, v1, stage)
    record.update(rec)
    return record


# ---------------------------------------------------------------------------
# main (parent)
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--hard-exit-worker", action="store_true")
    parser.add_argument("--sentinel-worker", action="store_true")
    parser.add_argument("--work", type=Path)
    parser.add_argument("--stage", type=str)
    parser.add_argument("--parent", type=str)
    parser.add_argument("--sentinel", type=Path)
    args = parser.parse_args()

    if args.hard_exit_worker:
        _hard_exit_worker(args.work, args.stage, args.parent)
        return
    if args.sentinel_worker:
        _sentinel_worker(args.work, args.stage, args.parent, args.sentinel)
        return

    OUT.mkdir(parents=True, exist_ok=True)
    RAW.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)

    runs = []
    for stage in STAGES:
        for method in ("os_exit", EXTERNAL_KILL):
            rec = _run_one(stage, method)
            runs.append(rec)
            print(f"[run] {stage:22s} {method:8s} exit={rec['worker_exit_code']:>4} "
                  f"recovered={rec['recovered_to']} no_torn={rec['no_torn_read']}")

    no_torn_all = all(r["no_torn_read"] for r in runs)
    v1_ok_all = all(r["v1_blocks_readable"] for r in runs)
    expected_all = all(r["recovery_matches_expected"] for r in runs)
    gc_pre_switch = [r for r in runs if r["stage"] in PRE_SWITCH]
    gc_removed_something = all(len(r["gc_removed_unreachable"]) > 0 for r in gc_pre_switch)

    gates = [
        {"id": "forced_exit_codes_verified", "passed": all(r["forced_exit_verified"] for r in runs),
         "detail": "91 for os._exit; -9 for POSIX SIGKILL; nonzero for taskkill"},
        {"id": "every_run_no_torn_read", "passed": no_torn_all,
         "detail": f"{sum(r['no_torn_read'] for r in runs)}/{len(runs)} runs"},
        {"id": "pre_switch_crashes_keep_v1",
         "passed": all(r["recovered_to"] == "v1_kept_v2_discarded" for r in gc_pre_switch),
         "detail": f"{len(gc_pre_switch)} runs (block/prep/before-root) both kill methods"},
        {"id": "post_switch_crashes_publish_v2",
         "passed": all(r["recovered_to"] == "v2_published"
                       for r in runs if r["stage"] in POST_SWITCH),
         "detail": "after_root_publish / after_commit_ack both kill methods"},
        {"id": "v1_blocks_always_readable_after_hard_crash", "passed": v1_ok_all,
         "detail": f"{sum(r['v1_blocks_readable'] for r in runs)}/{len(runs)} runs"},
        {"id": "half_written_v2_gced_pre_switch", "passed": gc_removed_something,
         "detail": "unreachable v2 blocks / prepared manifests removed"},
        {"id": "recovery_matches_expected_invariant", "passed": expected_all,
         "detail": "root either stays v1 or advances fully to v2"},
    ]

    status = "partial" if (no_torn_all and expected_all) else "failed"

    inputs = {
        "experiments/E6_recovery/publish_proto.py": exp_common.sha256_file(HERE / "publish_proto.py"),
        "experiments/E6_recovery/run_e6.py": exp_common.sha256_file(HERE / "run_e6.py"),
        "experiments/E6_recovery/run_e6_subprocess_faults.py": exp_common.sha256_file(Path(__file__)),
    }
    exp_common.write_json(RAW / "fault_runs.json", {"runs": runs})

    results = {
        "fault_runs": runs,
        "injection_stages": STAGES,
        "kill_methods": [
            "os._exit(91) — power-cut style, skips finally/close/commit",
            "taskkill /F /PID on Windows; SIGKILL on POSIX",
        ],
        "scope_note": (
            "Same toy-graph blocks as run_e6.py. Real score/embedding/evidence blocks "
            "through this manifest protocol remain C3-unfinished (no torch/GPU on this host). "
            "E6 stays partial; this study closes only the crash-semantics gap raised in review "
            "(SimulatedCrash -> real forced process termination)."
        ),
    }
    output = exp_common.build_output(
        "E6-subprocess-faults", inputs=inputs, results=results, status=status, gates=gates,
        raw_files=[str(RAW / "fault_runs.json")],
        host_note="informal wall-clock (host may have parallel load); correctness/count metrics unaffected",
    )
    exp_common.write_json(OUT / "output.json", output)
    _postprocess(output)
    print(json.dumps({"status": status,
                      "gates": {g["id"]: g["passed"] for g in gates}}, indent=2))


def _postprocess(output: dict) -> None:
    runs = output["results"]["fault_runs"]
    checks: dict[str, dict[str, object]] = {}
    for name, ok, ev in [
        ("format_is_v1", output.get("format") == "icde-experiment-output-v1", output.get("format")),
        ("every_run_no_torn_read",
         all(r["no_torn_read"] for r in runs),
         [{"stage": r["stage"], "method": r["kill_method"], "no_torn": r["no_torn_read"]} for r in runs]),
        ("os_exit_and_platform_force_kill_both_covered",
         all(any(r["kill_method"] == m for r in runs) for m in ("os_exit", EXTERNAL_KILL)),
         sorted({r["kill_method"] for r in runs})),
        ("pre_switch_keeps_v1",
         all(r["recovered_to"] == "v1_kept_v2_discarded"
             for r in runs if r["stage"] in PRE_SWITCH),
         {r["stage"] + "/" + r["kill_method"]: r["recovered_to"]
          for r in runs if r["stage"] in PRE_SWITCH}),
        ("post_switch_publishes_v2",
         all(r["recovered_to"] == "v2_published"
             for r in runs if r["stage"] in POST_SWITCH),
         {r["stage"] + "/" + r["kill_method"]: r["recovered_to"]
          for r in runs if r["stage"] in POST_SWITCH}),
        ("v1_blocks_intact_after_each_hard_crash",
         all(r["v1_blocks_readable"] for r in runs),
         f"{sum(r['v1_blocks_readable'] for r in runs)}/{len(runs)}"),
        ("status_partial_by_scope", output["status"] == "partial", output["status"]),
    ]:
        checks[name] = {"ok": bool(ok), "evidence": ev}
    verification = exp_common.build_verification("E6-subprocess-faults", checks=checks)
    exp_common.write_json(OUT / "verification.json", verification)

    L = []
    L.append("# E6 subprocess forced-termination faults — analysis")
    L.append("")
    L.append(f"- status: **{output['status']}** (partial by scope)  created: {output['created']}")
    L.append(f"- host: {output['host']['os']} / Python {output['host']['python']}")
    L.append("")
    L.append("## 1. Method")
    L.append("")
    L.append("Real process death instead of Python-level SimulatedCrash. v1 is published cleanly by")
    L.append("the parent; a worker subprocess attempts v2 and is killed hard at the chosen stage;")
    L.append("the parent restarts a fresh store on the same directory and checks invariants.")
    L.append("")
    L.append("- `os._exit(91)`: power-cut-style exit, skips `finally`/`close`/pending db commit.")
    L.append("- `taskkill /F /PID`: Windows has no POSIX SIGKILL; `/F` force-termination is the")
    L.append("  equivalent (worker touches a sentinel file at the stage, then blocks; the parent")
    L.append("  force-kills it exactly at that boundary).")
    L.append("")
    L.append("## 2. Injection-point results")
    L.append("")
    L.append("| stage | kill method | worker exit code | sentinel | root after restart | recovered to | no torn read | v1 blocks ok | GC removed |")
    L.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- |")
    for r in runs:
        L.append(
            f"| {r['stage']} | {r['kill_method']} | {r['worker_exit_code']} | {r['sentinel_seen']} "
            f"| {(r['root_after_restart'] or '')[:12]}… | {r['recovered_to']} "
            f"| {r['no_torn_read']} | {r['v1_blocks_readable']} | {len(r['gc_removed_unreachable'])} |"
        )
    L.append("")
    L.append("Crashes before the root-pointer switch keep v1 and the half-written v2 becomes")
    L.append("unreachable (GC-removable). Crashes after the atomic pointer switch find v2 fully")
    L.append("committed — including `after_root_publish`, where the SQLite `meta` row was never")
    L.append("committed but the on-disk `root` pointer already made v2 visible; the next SQLite")
    L.append("connection rolls the uncommitted row back automatically.")
    L.append("")
    L.append("## 3. Acceptance")
    L.append("")
    L.append(f"- runs: {len(runs)} = {len(STAGES)} injection stages x 2 kill methods")
    L.append(f"- no torn read in every run: **{all(r['no_torn_read'] for r in runs)}**")
    L.append(f"- recovery matches the expected pre/post-switch invariant: **{all(r['recovery_matches_expected'] for r in runs)}**")
    L.append(f"- v1 blocks readable after every hard crash: **{all(r['v1_blocks_readable'] for r in runs)}**")
    L.append("")
    L.append("## 4. Limitations (must stay visible)")
    L.append("")
    L.append(f"- {output['results']['scope_note']}")
    L.append("- Blocks are toy-graph (`graph`/`probability`/`candidates`). Real score/embedding/")
    L.append("  evidence blocks go through this protocol only after C3; this host has no torch/GPU.")
    L.append("- Wall-clock timings are informal (host may carry parallel load); correctness and")
    L.append("  count metrics do not depend on timing.")
    L.append("- Windows-specific: POSIX SIGKILL is simulated by `taskkill /F`; Linux/MAC semantics")
    L.append("  (core dump, signal disposition) are not exercised.")
    (OUT / "analysis.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print(f"wrote {OUT / 'analysis.md'} and {OUT / 'verification.json'}")


if __name__ == "__main__":
    main()
