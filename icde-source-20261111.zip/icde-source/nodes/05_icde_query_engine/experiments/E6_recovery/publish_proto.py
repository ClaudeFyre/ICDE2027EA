"""Minimal unified-publish prototype for E6 (engineering, not C3-complete).

On-disk layout::

    <store>/
      blocks/<sha256>.bin          # immutable, content-addressed data blocks
      manifests/prepared/<id>.json # prepared (not yet visible)
      manifests/committed/<id>.json # committed (visible)
      root                         # atomic pointer: current committed manifest id
      store.sqlite                 # event log (event-id dedup) + CAS meta

A snapshot manifest references immutable block digests plus a parent pointer.
Crash injection at named stages raises SimulatedCrash; the caller restarts the
store from disk and verifies the published root is still a consistent snapshot.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import tempfile
from pathlib import Path


class SimulatedCrash(Exception):
    stage: str

    def __init__(self, stage: str) -> None:
        super().__init__(f"simulated crash at {stage}")
        self.stage = stage


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class PublishStore:
    """A tiny content-addressed, root-published store with SQLite CAS."""

    def __init__(self, root_dir: str | Path, crash_at: str | None = None) -> None:
        self.root = Path(root_dir).resolve()
        self.crash_at = crash_at  # name of stage to crash at, or None
        (self.root / "blocks").mkdir(parents=True, exist_ok=True)
        (self.root / "manifests" / "prepared").mkdir(parents=True, exist_ok=True)
        (self.root / "manifests" / "committed").mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.root / "store.sqlite"))
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS events (event_id TEXT PRIMARY KEY, "
            "payload TEXT NOT NULL, received_at TEXT NOT NULL DEFAULT '')"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)"
        )
        self.db.commit()

    def _maybe_crash(self, stage: str) -> None:
        if self.crash_at == stage:
            raise SimulatedCrash(stage)

    # ---- blocks ----------------------------------------------------------
    def write_block(self, data: bytes) -> str:
        self._maybe_crash("before_block_write")
        digest = _sha(data)
        path = self.root / "blocks" / f"{digest}.bin"
        if not path.exists():
            # atomic write: temp file in same dir then rename
            fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
            with os.fdopen(fd, "wb") as h:
                h.write(data)
            os.replace(tmp, path)
        self._maybe_crash("after_block_write")
        return digest

    def read_block(self, digest: str) -> bytes:
        path = self.root / "blocks" / f"{digest}.bin"
        if not path.is_file():
            raise FileNotFoundError(digest)
        return path.read_bytes()

    # ---- events (event-id dedup + conflict rejection) --------------------
    def apply_event(self, event_id: str, payload: str) -> str:
        cur = self.db.execute("SELECT payload FROM events WHERE event_id=?", (event_id,))
        row = cur.fetchone()
        if row is not None:
            if row[0] != payload:
                raise ValueError(f"conflicting payload for event {event_id}")
            return "duplicate_noop"
        self.db.execute(
            "INSERT INTO events (event_id, payload) VALUES (?, ?)", (event_id, payload)
        )
        self.db.commit()
        return "applied"

    # ---- manifest prepare / commit --------------------------------------
    def prepare_manifest(self, manifest: dict) -> str:
        body = json.dumps(manifest, sort_keys=True).encode("utf-8")
        digest = _sha(body)
        self._maybe_crash("before_prepared_write")
        prep = self.root / "manifests" / "prepared" / f"{digest}.json"
        tmp = prep.with_suffix(".json.tmp")
        tmp.write_bytes(body)
        os.replace(tmp, prep)
        self._maybe_crash("after_prepared_write")
        return digest

    def commit_manifest(self, manifest_digest: str) -> None:
        src = self.root / "manifests" / "prepared" / f"{manifest_digest}.json"
        if not src.is_file():
            raise FileNotFoundError(f"prepared manifest {manifest_digest}")
        self._maybe_crash("before_root_publish")
        dst = self.root / "manifests" / "committed" / f"{manifest_digest}.json"
        os.replace(src, dst)
        # atomic pointer switch
        ptr = self.root / "root"
        tmp = ptr.with_suffix(".tmp")
        tmp.write_text(manifest_digest, encoding="utf-8")
        os.replace(tmp, ptr)
        self._maybe_crash("after_root_publish")
        # CAS: only advance root if it is still the expected parent
        self.db.execute(
            "INSERT INTO meta (key, value) VALUES ('root', ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (manifest_digest,),
        )
        self._maybe_crash("before_commit_ack")
        self.db.commit()
        self._maybe_crash("after_commit_ack")

    # ---- reads -----------------------------------------------------------
    def published_root(self) -> str | None:
        ptr = self.root / "root"
        if not ptr.is_file():
            return None
        return ptr.read_text(encoding="utf-8").strip() or None

    def read_manifest(self, digest: str) -> dict:
        path = self.root / "manifests" / "committed" / f"{digest}.json"
        if not path.is_file():
            raise FileNotFoundError(digest)
        return json.loads(path.read_text(encoding="utf-8"))

    # ---- GC --------------------------------------------------------------
    def reachable_blocks(self) -> set[str]:
        seen: set[str] = set()
        root = self.published_root()
        stack = [root] if root else []
        committed = self.root / "manifests" / "committed"
        while stack:
            d = stack.pop()
            if d is None or d in seen:
                continue
            seen.add(d)
            try:
                m = self.read_manifest(d)
            except FileNotFoundError:
                continue
            for ref in m.get("blocks", {}).values():
                if isinstance(ref, str):
                    seen.add(ref)
            if m.get("parent"):
                stack.append(m["parent"])
        # add all committed manifests themselves as reachable
        for p in committed.glob("*.json"):
            seen.add(p.stem)
        return seen

    def gc_sweep(self) -> list[str]:
        reachable = self.reachable_blocks()
        removed = []
        for p in (self.root / "blocks").glob("*.bin"):
            if p.stem not in reachable:
                p.unlink()
                removed.append(p.stem)
        # remove stale prepared manifests
        prep = self.root / "manifests" / "prepared"
        for p in prep.glob("*.json"):
            p.unlink()
        return removed

    def close(self) -> None:
        self.db.close()
