"""E6 analysis: render analysis.md."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "_common"))
import icde_paths  # noqa: E402

REPO = icde_paths.resolve_repo_root(__file__)
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e6_20261009"


def main() -> None:
    out = json.loads((OUT / "output.json").read_text(encoding="utf-8"))
    crashes = out["results"]["crash_study"]
    ev = out["results"]["event_sequence"]

    L = []
    L.append("# E6 Full Recovery — analysis")
    L.append("")
    L.append(f"- status: **{out['status']}** (partial by scope)  created: {out['created']}")
    L.append(f"- host: {out['host']['os']} / Python {out['host']['python']}")
    L.append("")
    L.append("## 1. Prototype")
    L.append("")
    L.append("Immutable content-addressed blocks (`blocks/<sha256>.bin`, temp+rename),")
    L.append("prepared/committed manifests, SQLite event log with event-id dedup, atomic root")
    L.append("pointer (temp+rename), and GC that removes unreachable blocks. Data layer is toy")
    L.append("graph blocks only.")
    L.append("")
    L.append("## 2. Crash injection and recovery")
    L.append("")
    L.append("| stage | recovered to | no torn read | unreachable blocks GC'd |")
    L.append("| --- | --- | --- | --- |")
    for c in crashes:
        L.append(f"| {c['stage']} | {c['recovered_to']} | {c['no_torn_read']} | {len(c['gc_removed_unreachable'])} |")
    L.append("")
    L.append("Crashes before the root-pointer switch keep v1 and discard/GC the half-written v2;")
    L.append("crashes after the atomic switch find v2 already fully committed. No torn read in any")
    L.append("stage.")
    L.append("")
    L.append("## 3. Event sequences")
    L.append("")
    L.append("| sequence | result |")
    L.append("| --- | --- |")
    L.append(f"| duplicate event (same id + payload) | {ev['dup2']} (dedup no-op) |")
    L.append(f"| conflicting payload (same id) | {ev['conflict']} |")
    L.append(f"| delete/re-add new generation | re-add carried gen2 present: {ev['readd_new_generation']} |")
    L.append(f"| late operation after publish | {ev['late_event']} (does not rewrite history) |")
    L.append(f"| rollback to published root | root={ev['rollback_root']} fact={ev['rollback_fact_state']} no-splice={ev['rollback_no_splice']} |")
    L.append("")
    L.append("## 4. Scope boundary (must stay visible)")
    L.append("")
    L.append(f"- {out['results']['scope_note']}")
    L.append(f"- Gate to full: {out['results']['gate_to_full']}.")
    L.append("- Status is intentionally **partial**: this is the engineering base for C3, not a")
    L.append("  durable real-query-state claim. The inherited DurableStreamingWorker crash test only")
    L.append("  covers probability/moments and does not close E6.")
    (OUT / "analysis.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print(f"wrote {OUT/'analysis.md'}")


if __name__ == "__main__":
    main()
