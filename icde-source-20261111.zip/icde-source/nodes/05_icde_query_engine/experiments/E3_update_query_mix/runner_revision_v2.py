"""E3 revision v2 reinforcement -- fixes the three review gaps in ``runner.py``.

Gap 1 (factor law was cosmetic): ``make_revision_safe`` always built the stream
with the fixed independent MC. Here each revision carries a real ``FactorLaw``;
an ``update_factor`` revision groups edges and the worlds are actually sampled
under the common-shock law, so the joint law changes (measured) and the factor
digest changes.

Gap 2 (stale-success was an initialized constant): we now actually issue a query
bound to an *old* snapshot against a freshly revised context and count how often
it is served. The contract requires it to be *rejected*, so stale_success must
be 0 and stale_rejected > 0.

Gap 3 (periodic refresh just skipped): an unpublished revision now enqueues the
incoming request into a backlog; when the period publishes, the queue is
CLEARED and the backlogged requests are REPLAYED on their original requested snapshots, and the
replayed answers are checked item-for-item against an independent recompute under those same snapshots.

Output: ``results/icde_e3_20261009/revision_v2_20261009/``.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(REPO / "scripts"))
sys.path.insert(0, str(REPO / "src"))

from icde_baseline_suite import (  # noqa: E402
    CODE_ID, SCORER_ID, DEFAULT_BATCH_SIZE, DEFAULT_MINIMUM_SAMPLES,
    build_context, query_fingerprint,
)
from pkgea.query.modal import (  # noqa: E402
    ModalQuery, ModalScorer, ModalSnapshot, execute_modal_queries, identity,
)
from pkgea.samplers import FactorLaw  # noqa: E402

OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e3_20261009" / "revision_v2_20261009"


def make_revision(graph_digest, model, schema, scorer_fn, probs, law, seed, n_worlds):
    """Build snapshot+stream+scorer under the ACTUAL factor law."""

    snapshot = ModalSnapshot(graph_digest, model, identity(list(probs)), law.identity(),
                             schema, CODE_ID, SCORER_ID)
    worlds = tuple(law.build_worlds(probs, n_worlds, seed))
    # import locally to keep the stream-digest binding explicit
    from pkgea.query.modal import IIDWorldStream
    stream = IIDWorldStream(snapshot.digest, seed, worlds, law.stream_config())
    scorer = ModalScorer(snapshot.digest, scorer_fn)
    return snapshot, stream, scorer


def serve(snapshot, stream, scorer, queries):
    out = execute_modal_queries(queries, snapshot, stream, scorer, cache=None,
                                shared=False, batch_size=DEFAULT_BATCH_SIZE,
                                minimum_samples=DEFAULT_MINIMUM_SAMPLES)
    return [query_fingerprint(r) for r in out["results"]], out["work"]


def main():
    seed = 17
    n_worlds = 128
    OUT.mkdir(parents=True, exist_ok=True)

    dataset = REPO / "data" / "toy" / "exact_world_minimal"
    base_ctx = build_context(dataset, seed=seed, n_worlds=n_worlds)
    backbone = base_ctx.backbone
    scorer_fn = backbone.score_subset
    graph_digest = base_ctx.snapshot.graph
    model = base_ctx.snapshot.model
    schema = base_ctx.snapshot.schema

    # Revision chain with REAL law changes.
    base = [0.8, 0.6, 0.75, 0.55]
    rev0 = (base, FactorLaw.independent(4))
    rev1 = ([0.2, 0.6, 0.75, 0.55], FactorLaw.independent(4))            # update_probability edge0
    rev2 = ([0.2, 0.6, 0.75, 0.55], FactorLaw(("g", "g", "", ""), 0.6))  # update_factor: group edges 0,1
    rev3 = ([0.2, 0.6, 0.30, 0.55], FactorLaw(("g", "g", "", ""), 0.6))   # update_probability edge2

    revisions = []
    for i, (probs, law) in enumerate((rev0, rev1, rev2, rev3)):
        s, st, sc = make_revision(graph_digest, model, schema, scorer_fn,
                                  probs, law, seed + i, n_worlds)
        revisions.append({"label": ["r0", "r1", "r2", "r3"][i], "probs": probs,
                          "law": law, "snapshot": s, "stream": st, "scorer": sc})

    source = backbone.source_entities[0]
    candidates = tuple(backbone.target_entities)

    # --- Evidence: factor law really changes the joint law -----------------
    p0, p1 = base[0], base[1]
    ind_worlds = FactorLaw.independent(4).build_worlds(base, 60000, seed)
    grp_worlds = FactorLaw(("g", "g", "", ""), 0.6).build_worlds(base, 60000, seed)
    joint_ind = sum(w.state[0] and w.state[1] for w in ind_worlds) / len(ind_worlds)
    joint_grp = sum(w.state[0] and w.state[1] for w in grp_worlds) / len(grp_worlds)
    analytic_grp = 0.6 * min(p0, p1) + 0.4 * p0 * p1

    # --- Gap 2: real stale probe ------------------------------------------
    # After r1 is published, issue a query that still references r0's digest.
    stale_attempts = 0
    stale_rejected = 0
    stale_success = 0
    stale_evidence = []
    q_on_r1 = ModalQuery(source, candidates, revisions[1]["snapshot"].digest, n_worlds)
    q_stale = ModalQuery(source, candidates, revisions[0]["snapshot"].digest, n_worlds)
    # serving r1 context but with the stale (r0) query:
    stale_attempts += 1
    try:
        serve(revisions[1]["snapshot"], revisions[1]["stream"], revisions[1]["scorer"],
              [q_stale])
        stale_success += 1  # contract violation: should never get here
    except ValueError as exc:
        stale_rejected += 1
        stale_evidence.append({"requested_snapshot": revisions[0]["snapshot"].digest,
                                "serving_snapshot": revisions[1]["snapshot"].digest,
                                "rejected_with": str(exc)})
    # sanity: a correctly-bound query on r1 does serve.
    ok_fp, _ = serve(revisions[1]["snapshot"], revisions[1]["stream"],
                     revisions[1]["scorer"], [q_on_r1])

    # Periodic publication delays requests; it never changes their snapshots.
    period_k = 2
    backlog = []
    backlog_depth_log = []
    skipped = 0
    published = set()
    served_fps = {}

    def replay_original(old_rev, old_q):
        published.add(old_rev["snapshot"].digest)
        fp, _ = serve(old_rev["snapshot"], old_rev["stream"], old_rev["scorer"], [old_q])
        index = revisions.index(old_rev)
        osnap, ostream, oscorer = make_revision(
            graph_digest, model, schema, scorer_fn, old_rev["probs"],
            old_rev["law"], seed + index, n_worlds)
        oracle, _ = serve(osnap, ostream, oscorer, [old_q])
        return {"backlogged_from": old_rev["label"],
                "replayed_on": old_rev["label"],
                "requested_snapshot": old_q.snapshot_digest,
                "served_snapshot": old_rev["snapshot"].digest,
                "matches_independent_recompute": fp == oracle}

    for i, rev in enumerate(revisions):
        q = ModalQuery(source, candidates, rev["snapshot"].digest, n_worlds)
        if i % period_k != 0:
            skipped += 1
            backlog.append((rev, q))
            backlog_depth_log.append({"revision": rev["label"], "backlog_depth": len(backlog),
                                      "requested_snapshot": q.snapshot_digest,
                                      "action": "enqueue_not_ready"})
            continue
        replay_results = [replay_original(old_rev, old_q) for old_rev, old_q in backlog]
        backlog.clear()
        published.add(rev["snapshot"].digest)
        fp, _ = serve(rev["snapshot"], rev["stream"], rev["scorer"], [q])
        served_fps[rev["label"]] = fp
        backlog_depth_log.append({"revision": rev["label"], "action": "publish_flush",
                                  "replayed": replay_results})
    # Publish the final requested revision before draining; no r3 -> r2 downgrade.
    final_replay = [replay_original(old_rev, old_q) for old_rev, old_q in backlog]
    backlog.clear()
    if final_replay:
        backlog_depth_log.append({"revision": revisions[-1]["label"], "action": "final_drain",
                                  "replayed": final_replay})
    all_replays = [r for event in backlog_depth_log for r in event.get("replayed", [])]
    backlog_replay_consistent = len(all_replays) == skipped and all(
        r["matches_independent_recompute"] and r["requested_snapshot"] == r["served_snapshot"]
        for r in all_replays)

    out = {
        "format": "icde-e3-revision-v2-20261009",
        "dataset": str(dataset),
        "revision_chain": [r["label"] for r in revisions],
        "factor_law_evidence": {
            "p_edge0": p0, "p_edge1": p1,
            "joint_both_edges_independent": joint_ind,
            "joint_both_edges_grouped_rho0.6": joint_grp,
            "analytic_grouped_joint": analytic_grp,
            "conclusion": "grouped law raises P(both active) above the product law",
        },
        "stale_probe": {
            "stale_attempts": stale_attempts,
            "stale_rejected": stale_rejected,
            "stale_success": stale_success,
            "evidence": stale_evidence,
        },
        "periodic_backlog": {
            "semantics": "exact requested snapshot; publish queued revisions before serving",
            "period_k": period_k,
            "skipped_unpublished": skipped,
            "backlog_log": backlog_depth_log,
            "backlog_replay_matches_independent_recompute": backlog_replay_consistent,
        },
        "revisions": [
            {"label": r["label"], "snapshot_digest": r["snapshot"].digest,
             "factors_identity": r["law"].identity(),
             "is_independent": r["law"].is_independent}
            for r in revisions
        ],
    }
    (OUT / "revision_v2_result.json").write_text(
        json.dumps(out, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")

    checks = {
        "factor_law_changes_joint_measurably": joint_grp > joint_ind + 0.02,
        "stale_success_real_probe_is_zero": stale_success == 0,
        "stale_attempt_rejected": stale_rejected == stale_attempts and stale_attempts > 0,
        "backlog_cleared_and_replayed_consistently": backlog_replay_consistent,
        "skipped_unpublished_greater_than_zero": skipped > 0,
    }
    status = "passed" if all(checks.values()) else "failed"
    (OUT / "revision_v2_checks.json").write_text(
        json.dumps({"checks": checks, "status": status}, indent=2,
                   ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": status, "checks": checks,
                      "joint_ind": round(joint_ind, 4), "joint_grp": round(joint_grp, 4),
                      "stale": (stale_attempts, stale_rejected, stale_success)}, indent=2))


if __name__ == "__main__":
    main()
