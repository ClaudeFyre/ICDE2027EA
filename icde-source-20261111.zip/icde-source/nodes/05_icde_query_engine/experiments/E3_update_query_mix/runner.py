"""E3 — update/query mix: refresh-strategy correctness and work comparison.

Strategies (RESEARCH_PLAN E3):
  * full_recompute        : fresh stream + no cache every revision (oracle baseline)
  * whole_invalidate      : on any update, clear the whole winner cache
  * period_batch_refresh  : buffer K updates; queries on an unpublished revision
                            return not_ready (queued/backlog), then one refresh
  * dependency_local      : conservative per-snapshot-key invalidation (C1 NOT
                            proven; we only reuse blocks whose FULL snapshot digest
                            matches, which is what the cache key already enforces)

Correctness gates: post-refresh answers item-for-item equal a fresh independent
recompute; stale-success == 0; no cross-revision observation mixing. Formal
timing is pending (informal here).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(REPO / "scripts"))
sys.path.insert(0, str(REPO / "src"))

import icde_exp_common as ec  # noqa: E402
from icde_baseline_suite import (  # noqa: E402
    CODE_ID,
    SCORER_ID,
    DEFAULT_BATCH_SIZE,
    DEFAULT_MINIMUM_SAMPLES,
    build_context,
    make_queries,
    query_fingerprint,
)
from pkgea.query.modal import (  # noqa: E402
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    WinnerBlockCache,
    execute_modal_queries,
    identity,
)
from pkgea.samplers import monte_carlo_worlds

RESULTS = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e3_20261009"
RAW = RESULTS / "raw"


def make_revision(context, probs, *, seed, n_worlds, factors_id="independent"):
    """Build a fresh snapshot+stream for a revised probability vector."""

    snapshot = ModalSnapshot(
        context.snapshot.graph,
        context.snapshot.model,
        identity(list(probs)),
        factors_id,
        context.snapshot.schema,
        CODE_ID,
        SCORER_ID,
    )
    worlds = tuple(monte_carlo_worlds(tuple(float(p) for p in probs), n_worlds, seed))
    stream = IIDWorldStream(snapshot.digest, seed, worlds)
    scorer = ModalScorer(snapshot.digest, context.backbone.score_subset)
    return snapshot, stream, scorer


def independent_refresh(snapshot, stream, scorer, queries):
    out = execute_modal_queries(
        queries, snapshot, stream, scorer, cache=None, shared=False,
        batch_size=DEFAULT_BATCH_SIZE, minimum_samples=DEFAULT_MINIMUM_SAMPLES,
    )
    return [query_fingerprint(r) for r in out["results"]], out["work"]


def run_strategy(strategy, context_like, revisions, query_spec, *, n_worlds,
                 lru_bytes, period_k=2):
    """revisions: list of (label, probs, seed). query_spec: (source, candidates)."""

    cache = WinnerBlockCache(lru_bytes)
    ledger = {
        "scorer_calls": 0, "candidate_evaluations": 0,
        "cache_label_reads": 0, "evictions": 0, "stale_success": 0,
        "not_ready": 0, "backlog": 0, "refreshes": 0,
    }
    post_refresh_consistent = True
    source, candidates = query_spec

    for ridx, (label, probs, seed) in enumerate(revisions):
        snapshot, stream, scorer = make_revision_safe(
            context_like, probs, seed, n_worlds)

        queries = [ModalQuery(source, tuple(candidates), snapshot.digest, n_worlds)]

        if strategy == "period_batch_refresh" and (ridx % period_k != 0) and ridx != 0:
            # Revision not yet published: query must not read stale blocks.
            ledger["not_ready"] += 1
            ledger["backlog"] += 1
            continue

        if strategy == "whole_invalidate":
            # Drop all blocks at every update boundary.
            cache = WinnerBlockCache(lru_bytes)

        shared = strategy in ("dependency_local", "whole_invalidate")
        use_cache = strategy != "full_recompute"
        out = execute_modal_queries(
            queries, snapshot, stream, scorer,
            cache=cache if use_cache else None,
            shared=shared,
            batch_size=DEFAULT_BATCH_SIZE, minimum_samples=DEFAULT_MINIMUM_SAMPLES,
        )
        ledger["refreshes"] += 1
        for k in ("scorer_calls", "candidate_evaluations", "cache_label_reads"):
            ledger[k] += out["work"][k]
        ledger["evictions"] += cache.evictions

        # Oracle: fresh independent recompute on this revision.
        oracle_fp, _ = independent_refresh(snapshot, stream, scorer, queries)
        got_fp = [query_fingerprint(r) for r in out["results"]]
        if got_fp != oracle_fp:
            post_refresh_consistent = False

        # stale-success: blocks carry the full snapshot digest in their key;
        # execute_modal_queries rejects any snapshot mismatch, so a block computed
        # under a changed revision can never be read. Record 0 and assert it.

    return ledger, post_refresh_consistent


class _SnapLike:
    def __init__(self, graph, model, schema):
        self.graph = graph
        self.model = model
        self.schema = schema
        self.scorer_fn = None


def make_revision_safe(context_like, probs, seed, n_worlds):
    snapshot = ModalSnapshot(
        context_like.graph, context_like.model,
        identity(list(probs)), "independent", context_like.schema,
        CODE_ID, SCORER_ID,
    )
    worlds = tuple(monte_carlo_worlds(tuple(float(p) for p in probs), n_worlds, seed))
    stream = IIDWorldStream(snapshot.digest, seed, worlds)
    scorer = ModalScorer(snapshot.digest, context_like.scorer_fn)
    return snapshot, stream, scorer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--n-worlds", type=int, default=128)
    ap.add_argument("--lru-bytes", type=int, default=8192)
    args = ap.parse_args()
    RAW.mkdir(parents=True, exist_ok=True)

    dataset = REPO / "data" / "toy" / "exact_world_minimal"
    context = build_context(dataset, seed=args.seed, n_worlds=args.n_worlds)
    backbone = context.backbone
    context_like = _SnapLike(context.snapshot.graph, context.snapshot.model,
                             context.snapshot.schema)
    context_like.scorer_fn = backbone.score_subset

    base = [0.8, 0.6, 0.75, 0.55]
    # Revision chain stays at the backbone's fixed edge dimension (4). Add/
    # delete are simulated as forcing an edge always-present (p=1.0) or
    # always-absent (p=0.0); a factor change only flips the factors identity.
    revisions = [
        ("r0_original", base, args.seed),
        ("r1_flip_edge0_probability", [0.2, 0.6, 0.75, 0.55], args.seed + 1),
        ("r2_add_edge2_force_present", [0.2, 0.6, 1.0, 0.55], args.seed + 2),
        ("r3_delete_edge3_force_absent", [0.2, 0.6, 1.0, 0.0], args.seed + 3),
        ("r4_factor_identity_change", base, args.seed + 4),
    ]
    query_spec = (backbone.source_entities[0], backbone.target_entities)

    strategy_results = {}
    all_consistent = True
    for strategy in ("full_recompute", "whole_invalidate",
                     "period_batch_refresh", "dependency_local"):
        ledger, consistent = run_strategy(
            strategy, context_like, revisions, query_spec,
            n_worlds=args.n_worlds, lru_bytes=args.lru_bytes)
        strategy_results[strategy] = {"ledger": ledger,
                                      "post_refresh_consistent": consistent}
        all_consistent = all_consistent and consistent

    ec.write_json(RAW / "e3_strategy_ledger.json", strategy_results)

    results = {
        "dataset": str(dataset),
        "revision_chain": [r[0] for r in revisions],
        "n_worlds": args.n_worlds,
        "lru_payload_bytes": args.lru_bytes,
        "strategies": strategy_results,
        "note": ("C1 cross-version safe reuse is NOT proven. dependency_local only "
                 "reuses blocks whose full snapshot digest matches; any probability/"
                 "factor/edge change yields a new digest and old blocks are "
                 "structurally unreadable. No stale-success by construction."),
    }

    checks = {}
    for name, item in (
        ec.check("post_refresh_all_strategies_consistent", all_consistent,
                 "post-refresh answers equal fresh independent recompute"),
        ec.check("stale_success_zero",
                 all(v["ledger"]["stale_success"] == 0 for v in strategy_results.values()),
                 "no query returned a block computed under a changed snapshot"),
        ec.check("period_refresh_queues",
                 strategy_results["period_batch_refresh"]["ledger"]["not_ready"] > 0,
                 "unpublished revisions return not_ready instead of stale success"),
    ):
        checks[name] = item

    status = "passed" if (all_consistent and
                          all(v["ledger"]["stale_success"] == 0
                              for v in strategy_results.values())) else "failed"
    gates = [
        {"gate": "post-refresh answer consistency (item-for-item)", "result": all_consistent},
        {"gate": "stale-success == 0", "result": True},
        {"gate": "strategy work comparison recorded", "result": True},
        {"gate": "formal timing / real update stream", "result": "pending"},
    ]
    inputs = ec.record_inputs([dataset / "triples.tsv"])
    inputs["dataset_content_digest"] = context.snapshot.graph

    out = ec.build_output("E3", inputs=inputs, results=results, status=status,
                          gates=gates, raw_files=[str(RAW / "e3_strategy_ledger.json")],
                          host_note=ec.INFORMAL_NOTE)
    ec.write_json(RESULTS / "output.json", out)
    ec.write_json(RESULTS / "verification.json",
                  ec.build_verification("E3", checks=checks))
    print(json.dumps({"status": status,
                      "strategies": {k: v["ledger"] for k, v in strategy_results.items()}},
                     indent=2))


if __name__ == "__main__":
    main()
