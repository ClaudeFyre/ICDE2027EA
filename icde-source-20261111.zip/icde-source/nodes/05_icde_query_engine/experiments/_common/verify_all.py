"""Shared verification script for E2/E3/E4/E5 result bundles.

Re-loads each experiment's output.json + verification.json and asserts the fixed
schema and that verification.passed is true. Run:

    python nodes/05_icde_query_engine/experiments/_common/verify_all.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
RESULTS = REPO / "nodes" / "05_icde_query_engine" / "results"

DIRS = {
    "E2": "icde_e2_20261009",
    "E3": "icde_e3_20261009",
    "E4": "icde_e4_20261009",
    "E5": "icde_e5_20261009",
}

OUTPUT_KEYS = {"format", "experiment", "created", "host", "inputs",
               "results", "status", "gates", "raw_files"}
VERIFY_KEYS = {"format", "experiment", "created", "checks", "passed"}


def main() -> int:
    failures = []
    for exp, d in DIRS.items():
        od = RESULTS / d
        out_p = od / "output.json"
        ver_p = od / "verification.json"
        for p, keys in ((out_p, OUTPUT_KEYS), (ver_p, VERIFY_KEYS)):
            if not p.is_file():
                failures.append(f"{exp}: missing {p}")
                continue
            data = json.loads(p.read_text(encoding="utf-8"))
            missing = keys - set(data)
            if missing:
                failures.append(f"{exp}: {p.name} missing keys {sorted(missing)}")
        if out_p.is_file():
            out = json.loads(out_p.read_text(encoding="utf-8"))
            if out.get("format") != "icde-experiment-output-v1":
                failures.append(f"{exp}: bad output format")
            if out.get("experiment") != exp:
                failures.append(f"{exp}: experiment field mismatch")
        if ver_p.is_file():
            ver = json.loads(ver_p.read_text(encoding="utf-8"))
            if ver.get("format") != "icde-experiment-verification-v1":
                failures.append(f"{exp}: bad verification format")
            if not ver.get("passed"):
                failures.append(f"{exp}: verification.passed is not true")
    print(json.dumps({"failures": failures, "ok": not failures}, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
