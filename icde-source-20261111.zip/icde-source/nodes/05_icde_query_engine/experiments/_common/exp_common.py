"""Shared helpers for the ICDE E0/E1/E6 experiment framework.

Fixed output schema (icde-experiment-output-v1) and verification schema
(icde-experiment-verification-v1) are produced here so all three runners emit
byte-compatible structures. All files are written UTF-8 without BOM.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: str | Path, payload: object) -> str:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
        encoding="utf-8",
    )
    return str(target)


def write_text(path: str | Path, text: str) -> str:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding="utf-8")
    return str(target)


def host_info(note: str) -> dict[str, object]:
    return {
        "os": f"{platform.system()} {platform.release()}",
        "python": sys.version.split()[0],
        "python_executable": sys.executable,
        "cpu_cores": os.cpu_count(),
        "machine": platform.machine(),
        "note": note,
    }


def build_output(
    experiment: str,
    *,
    inputs: dict[str, str],
    results: dict[str, object],
    status: str,
    gates: list[dict[str, object]],
    raw_files: list[str],
    host_note: str,
) -> dict[str, object]:
    return {
        "format": "icde-experiment-output-v1",
        "experiment": experiment,
        "created": utc_now_iso(),
        "host": host_info(host_note),
        "inputs": inputs,
        "results": results,
        "status": status,
        "gates": gates,
        "raw_files": raw_files,
    }


def build_verification(
    experiment: str,
    *,
    checks: dict[str, dict[str, object]],
) -> dict[str, object]:
    passed = all(item["ok"] for item in checks.values())
    return {
        "format": "icde-experiment-verification-v1",
        "experiment": experiment,
        "created": utc_now_iso(),
        "checks": checks,
        "passed": passed,
    }


def check(name: str, ok: bool, evidence: object) -> tuple[str, dict[str, object]]:
    return name, {"ok": bool(ok), "evidence": evidence}
