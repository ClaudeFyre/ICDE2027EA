"""Portable repository/input resolver for the ICDE experiment scripts.

Single source of truth for *where the repository root is* and *where frozen
input datasets live on the current host*. Nothing here hardcodes a Windows
drive letter; every path is derived from ``__file__`` and resolved relative to
the discovered repository root.

Why this module exists
----------------------
The 4090D independent review (``papers/icde/FULL_RETURN_REVIEW_20261009.md``
section 1) flagged that the E0/E1/E6 runners hard-coded ``REPO =
Path(r"E:\\pkgea")`` and that trace manifests recorded absolute Windows paths
(``graph_reference.dir`` / ``build_summary.output_root``) which do not exist on
any other host. This module fixes both:

  * :func:`resolve_repo_root` walks up from a caller file looking for the
    repository marker (``pyproject.toml`` + ``src/pkgea`` +
    ``nodes/05_icde_query_engine``).
  * :func:`resolve_input` locates a frozen dataset by its repo-relative ref
    and verifies its *machine-independent* content digest
    (``pkgea.contracts.dataset_content_digest``). A digest mismatch, or a
    missing file, raises a clear error instead of silently reading the wrong
    bytes.
  * ``windows_origin`` provenance is preserved verbatim inside result metadata
    so reviewers can see where an artifact was first generated, but it is
    NEVER used as an execution path on this host.

The module intentionally depends only on the standard library at import time;
the heavy ``pkgea.contracts`` digest function is imported lazily so this file
can be bootstrapped before ``src/`` is on ``sys.path``.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Repo-relative refs for the frozen synthetic datasets the E0/E5/P1 pipeline
# needs on a fresh host. Values are (repo-relative path, expected content
# digest). The digests are computed by pkgea.contracts.dataset_content_digest
# and were re-measured on 2026-10-09; they are NOT host/installation dependent.
KNOWN_INPUTS: dict[str, tuple[str, str]] = {
    "openea-d-w-probe-q32-a64-attributes-independent-s17": (
        "data/interim/openea-d-w-probe-q32-a64-attributes-independent-s17",
        "0ee6520679c463239312c3692a070866cf94475534b4df18ee01052339568337",
    ),
    "exact_world_minimal": (
        "data/toy/exact_world_minimal",
        "d256c6db47cfe065821af9a63b9f56bd346cf08243f2caf6edd5d041161054cd",
    ),
}

# Repository marker: a directory is the root only if all three exist.
_MARKER_DIRS = ("src/pkgea", "nodes/05_icde_query_engine")
_MARKER_FILES = ("pyproject.toml",)


def _is_repo_root(candidate: Path) -> bool:
    if not candidate.is_dir():
        return False
    for rel in _MARKER_DIRS:
        if not (candidate / rel).is_dir():
            return False
    for rel in _MARKER_FILES:
        if not (candidate / rel).is_file():
            return False
    return True


def resolve_repo_root(start: str | Path | None = None) -> Path:
    """Locate the repository root by walking up from ``start``.

    ``start`` defaults to this file's location. Raises ``FileNotFoundError`` if
    no directory carrying the ICDE repo markers is found. Never returns a
    hard-coded path.
    """
    origin = Path(start).resolve() if start is not None else Path(__file__).resolve()
    if origin.is_file():
        origin = origin.parent
    for cand in [origin, *origin.parents]:
        if _is_repo_root(cand):
            return cand
    raise FileNotFoundError(
        "Could not locate the pkgea repository root from "
        f"'{origin}'. Expected an ancestor directory containing "
        f"{list(_MARKER_FILES)} and {list(_MARKER_DIRS)}. "
        "Set it explicitly or run this script from inside the repo checkout."
    )


def _ensure_src_on_path(repo_root: Path) -> None:
    src = repo_root / "src"
    if str(src) not in sys.path:
        sys.path.insert(0, str(src))


def content_digest(dataset_dir: str | Path) -> str:
    """Machine-independent content digest of a dataset directory.

    Thin wrapper around pkgea.contracts.dataset_content_digest; imports pkgea
    lazily so this module works before src/ is on sys.path.
    """
    _ensure_src_on_path(resolve_repo_root())
    from pkgea.contracts import dataset_content_digest

    return dataset_content_digest(dataset_dir)


def _resolve_ref(repo_root: Path, name_or_relpath: str) -> Path:
    """Resolve a known-input name or a repo-relative path to an absolute path."""
    name = name_or_relpath.replace("\\", "/").strip("/")
    # 1) exact known-input alias
    if name in KNOWN_INPUTS:
        rel, _ = KNOWN_INPUTS[name]
        return repo_root / rel
    # 2) basename match against known inputs (e.g. a caller passes the tail dir)
    tail = name.rpartition("/")[2]
    for known_rel, _ in KNOWN_INPUTS.values():
        if known_rel.rpartition("/")[2] == tail:
            return repo_root / known_rel
    # 3) treat as repo-relative path
    candidate = repo_root / name
    if candidate.is_dir():
        return candidate
    # 4) last resort: name itself may already be absolute on this host
    as_is = Path(name_or_relpath)
    if as_is.is_dir():
        return as_is
    raise FileNotFoundError(
        f"Input '{name_or_relpath}' could not be located. Tried:\n"
        f"  - known-input alias/basename\n"
        f"  - repo-relative path '{candidate}'\n"
        f"On a fresh host the frozen dataset must be unpacked under the repo "
        f"at one of: {sorted(set(v[0] for v in KNOWN_INPUTS.values()))}."
    )


def resolve_input(
    name_or_relpath: str,
    expected_digest: str | None = None,
    *,
    repo_root: str | Path | None = None,
    verify: bool = True,
) -> Path:
    """Locate a frozen input dataset on this host and (optionally) verify it.

    Parameters
    ----------
    name_or_relpath:
        Either a known-input alias (see KNOWN_INPUTS), a basename, or a
        repo-relative path with forward slashes.
    expected_digest:
        The expected ``dataset_content_digest``. If omitted, the digest recorded
        in KNOWN_INPUTS for a known input is used. If ``verify`` is True the
        resolved directory's digest is recomputed and must match.
    repo_root:
        Override the discovered repository root.

    Returns the resolved absolute :class:`Path`. Raises FileNotFoundError or
    ValueError on a missing path / digest mismatch with an explicit message.
    """
    root = Path(repo_root) if repo_root is not None else resolve_repo_root()
    path = _resolve_ref(root, name_or_relpath)

    if expected_digest is None:
        name = name_or_relpath.replace("\\", "/").strip("/")
        if name in KNOWN_INPUTS:
            expected_digest = KNOWN_INPUTS[name][1]
        else:
            tail = name.rpartition("/")[2]
            for known_rel, known_digest in KNOWN_INPUTS.values():
                if known_rel.rpartition("/")[2] == tail:
                    expected_digest = known_digest
                    break

    if verify:
        actual = content_digest(path)
        if expected_digest is not None and actual != expected_digest:
            raise ValueError(
                f"Content digest mismatch for '{path}'.\n"
                f"  expected: {expected_digest}\n"
                f"  actual:   {actual}\n"
                "The frozen dataset was not unpacked intact (or the wrong "
                "directory was copied). Do not proceed on unverified bytes."
            )
    return path


def resolve_graph_reference(entry: dict, *, repo_root: str | Path | None = None) -> Path:
    """Resolve a trace manifest ``graph_reference`` block to a local dataset.

    The portable block shape is::

        {"kind": "probe"|"toy",
         "ref": "data/interim/...",          # repo-relative, forward slashes
         "content_digest": "<sha256>",        # machine-independent content digest
         "windows_origin": "E:\\pkgea\\...", # provenance only, NOT an exec path
         "snapshot_digest": "<sha256>"}

    The legacy ``dir`` field (an absolute Windows path) is never used for
    execution; it is treated purely as provenance. If ``ref`` is absent the
    function still resolves via digest from KNOWN_INPUTS when possible.
    """
    root = Path(repo_root) if repo_root is not None else resolve_repo_root()
    expected = entry.get("content_digest") or entry.get("content_sha256")
    ref = entry.get("ref")
    if ref:
        path = resolve_input(ref, expected_digest=expected, repo_root=root)
    else:
        # Legacy block without ref: fall back to digest-based lookup so old
        # manifests still work on the generating host, but warn that the block
        # should be re-emitted in portable form.
        matches = [
            rel for rel, dig in KNOWN_INPUTS.values() if expected and dig == expected
        ]
        if not matches:
            raise FileNotFoundError(
                "graph_reference has no portable 'ref' and its digest is not a "
                f"known frozen input: {entry!r}"
            )
        path = resolve_input(matches[0], expected_digest=expected, repo_root=root)
    return path


def trace_root_from_summary(summary_path: str | Path) -> Path:
    """Resolve the trace output root from build_summary.json.

    build_summary.json now stores ``output_root`` as a repo-relative path plus a
    ``windows_origin`` provenance field. The summary's own location anchors the
    trace root on a fresh host, so we return the summary file's directory
    (which IS the trace root) and only use the relative ``output_root`` to
    cross-check.
    """
    sp = Path(summary_path).resolve()
    if not sp.is_file():
        raise FileNotFoundError(f"build_summary.json not found at '{sp}'")
    return sp.parent


def trace_dirs_from_summary(summary_path: str | Path) -> list[Path]:
    """Return the per-trace directories listed in build_summary.json.

    Works whether each entry's ``dir`` is the repo-relative basename (portable
    form) or an absolute legacy path. Relative names resolve against the
    summary's directory; absolute paths are rejected on a non-generating host
    unless they actually exist here.
    """
    import json

    sp = Path(summary_path).resolve()
    summary = json.loads(sp.read_text(encoding="utf-8"))
    root = sp.parent
    out: list[Path] = []
    for t in summary.get("traces", []):
        d = t.get("dir")
        if not d:
            continue
        p = Path(d)
        if not p.is_absolute():
            out.append(root / d)
        else:
            # Legacy absolute path. Only honour it if it exists on THIS host;
            # otherwise fall back to <root>/<basename> so a copied bundle still
            # validates. This never trusts a Windows origin path blindly.
            out.append(p if p.is_dir() else root / Path(d).name)
    return out
