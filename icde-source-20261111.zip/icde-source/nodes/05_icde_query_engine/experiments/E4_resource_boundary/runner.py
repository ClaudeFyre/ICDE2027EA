"""E4 — resource boundary: cache budget x scale x cold/hot scan.

Small controlled scan on the probe structural scorer:
  * LRU payload budgets: 64, 256, 1024, 8192, 65536 bytes
  * world budgets: 64, 128, 256
  * cold (fresh empty cache) vs hot (reuse same cache on a repeat trace)

Reports scorer calls cold/hot, cache reads/writes, evictions, peak payload,
bytes, informal wall. Identifies:
  * the 64-byte capacity-failure case (blocks cannot be held -> full recompute)
  * the break-even budget where the working set fits and hot recompute -> 0
Workset>RAM I/O experiments are pending (need a real large graph).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(REPO / "scripts"))
sys.path.insert(0, str(REPO / "src"))

import icde_exp_common as ec  # noqa: E402
from icde_baseline_suite import (  # noqa: E402
    DEFAULT_BATCH_SIZE,
    DEFAULT_MINIMUM_SAMPLES,
    build_context,
    make_queries,
    query_fingerprint,
)
from pkgea.query.modal import (  # noqa: E402
    WinnerBlockCache,
    execute_modal_queries,
)

RESULTS = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e4_20261009"
RAW = RESULTS / "raw"


def run_trace(queries, context, cache, *, shared=True):
    start = time.perf_counter()
    out = execute_modal_queries(
        queries, context.snapshot, context.stream, context.scorer,
        cache=cache, shared=shared,
        batch_size=DEFAULT_BATCH_SIZE, minimum_samples=DEFAULT_MINIMUM_SAMPLES,
    )
    wall = time.perf_counter() - start
    w = out["work"]
    return {
        "scorer_calls": w["scorer_calls"],
        "candidate_evaluations": w["candidate_evaluations"],
        "cache_label_reads": w["cache_label_reads"],
        "new_winner_labels": w["computed_winner_labels"],
        "evictions": cache.evictions,
        "peak_payload_bytes": cache.peak_payload_bytes,
        "wall_seconds_informal": wall,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=17)
    args = ap.parse_args()
    RAW.mkdir(parents=True, exist_ok=True)

    dataset = (REPO / "data" / "interim" /
               "openea-d-w-probe-q32-a64-attributes-independent-s17")
    budgets = [64, 256, 1024, 8192, 65536]
    world_sizes = [64, 128, 256]

    rows = []
    for nw in world_sizes:
        context = build_context(dataset, seed=args.seed, n_worlds=nw)
        # A fixed small query mix: hotspot repeat + a few new sources.
        sources = list(context.backbone.source_entities)[:8]
        pool = context.backbone.target_entities[:8]
        qspec = [(sources[0], pool)] * 4 + [(s, pool) for s in sources[1:]]
        queries = make_queries(context, [q[0] for q in qspec],
                              [q[1] for q in qspec], budget=nw)
        for cap in budgets:
            cache = WinnerBlockCache(cap)
            cold = run_trace(queries, context, cache, shared=True)
            hot = run_trace(queries, context, cache, shared=True)
            row = {
                "n_worlds": nw, "budget_bytes": cap,
                "cold": cold, "hot": hot,
                "hot_recompute_calls": hot["scorer_calls"],
                "cache_hit_ratio": (
                    hot["cache_label_reads"] /
                    (hot["cache_label_reads"] + hot["new_winner_labels"])
                    if (hot["cache_label_reads"] + hot["new_winner_labels"]) > 0 else 0.0
                ),
            }
            rows.append(row)

    ec.write_json(RAW / "e4_scan.json", rows)

    # Identify boundary regions.
    capacity_failure = [r for r in rows if r["budget_bytes"] == 64
                        and r["hot"]["cache_label_reads"] == 0]
    break_even = []
    for nw in world_sizes:
        sub = [r for r in rows if r["n_worlds"] == nw]
        fitted = next((r for r in sub if r["hot_recompute_calls"] == 0), None)
        break_even.append({"n_worlds": nw,
                          "smallest_budget_with_zero_hot_recompute":
                              fitted["budget_bytes"] if fitted else None})

    results = {
        "dataset": str(dataset),
        "budgets_scanned": budgets,
        "world_sizes_scanned": world_sizes,
        "rows": rows,
        "boundary": {
            "capacity_failure_64byte_hot_reads_zero": len(capacity_failure) > 0,
            "capacity_failure_examples": [
                {"n_worlds": r["n_worlds"], "hot": r["hot"]} for r in capacity_failure
            ],
            "break_even_by_world_size": break_even,
        },
        "note": ("Payload-bytes budget only; not process RAM. Workset>RAM I/O "
                 "experiment pending (needs a real large graph). Wall informal."),
    }

    checks = {}
    for name, item in (
        ec.check("capacity_failure_case_reproduced",
                 results["boundary"]["capacity_failure_64byte_hot_reads_zero"],
                 "64-byte budget holds no useful block; hot phase fully recomputes"),
        ec.check("break_even_reported",
                 all(b["smallest_budget_with_zero_hot_recompute"] is not None
                     for b in break_even),
                 break_even),
        ec.check("peak_within_capacity",
                 all(r["cold"]["peak_payload_bytes"] <= r["budget_bytes"]
                     for r in rows),
                 "peak payload never exceeds admitted budget"),
    ):
        checks[name] = item

    status = "passed" if (checks["capacity_failure_case_reproduced"]["ok"]
                          and checks["break_even_reported"]["ok"]) else "failed"
    gates = [
        {"gate": "64-byte capacity failure reproduced", "result":
            results["boundary"]["capacity_failure_64byte_hot_reads_zero"]},
        {"gate": "break-even budget has numbers", "result":
            all(b["smallest_budget_with_zero_hot_recompute"] is not None
                for b in break_even)},
        {"gate": "workset>RAM I/O experiment", "result": "pending"},
    ]
    inputs = ec.record_inputs([dataset / "triples.tsv"])
    ctx = build_context(dataset, seed=args.seed, n_worlds=64)
    inputs["dataset_content_digest"] = ctx.snapshot.graph

    out = ec.build_output("E4", inputs=inputs, results=results, status=status,
                          gates=gates, raw_files=[str(RAW / "e4_scan.json")],
                          host_note=ec.INFORMAL_NOTE)
    ec.write_json(RESULTS / "output.json", out)
    ec.write_json(RESULTS / "verification.json",
                  ec.build_verification("E4", checks=checks))
    print(json.dumps({"status": status, "break_even": break_even,
                      "capacity_failure":
                          results["boundary"]["capacity_failure_64byte_hot_reads_zero"]},
                     indent=2))


if __name__ == "__main__":
    main()
