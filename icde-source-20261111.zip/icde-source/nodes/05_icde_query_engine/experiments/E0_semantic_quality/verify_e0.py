"""E0 verification: re-derive the acceptance gates from output.json."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "_common"))
import icde_paths  # noqa: E402
import exp_common  # noqa: E402

REPO = icde_paths.resolve_repo_root(__file__)
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e0_20261009"


def main() -> None:
    out = json.loads((OUT / "output.json").read_text(encoding="utf-8"))
    ce = out["results"]["counterexamples"]
    an = out["results"]["anchor_diagnosis"]

    checks = {}
    for name, ok, evidence in [
        ("format_is_v1", out.get("format") == "icde-experiment-output-v1", out.get("format")),
        ("CE1_holds", ce["CE1"]["holds"], {k: ce["CE1"][k] for k in ("modal_winner", "mean_score_winner")}),
        ("CE2_holds", ce["CE2"]["holds"], {k: ce["CE2"][k] for k in ("modal_winner", "gaussian_w2_winner")}),
        ("CE3_holds", ce["CE3"]["holds"], {k: ce["CE3"][k] for k in ("fp64_winner", "fp32_winner")}),
        ("anchor_digest_matches", an["digest_matches_declared"], an["anchor_content_digest"]),
        ("world_sensitivity_reported", an["world_sensitivity"]["total_test_sources"] == 32, an["world_sensitivity"]),
        ("top1_quality_reported", "accuracy" in an["labelled_top1"], an["labelled_top1"]),
        ("modal_vs_mean_reported", "fraction" in an["modal_vs_mean"], an["modal_vs_mean"]),
        ("gcn_explicitly_pending", an["gcn_learned_scorer"]["status"] == "pending", an["gcn_learned_scorer"]["gate"]),
        ("status_consistent", out["status"] in {"passed", "partial", "failed", "pending"}, out["status"]),
    ]:
        key, item = exp_common.check(name, ok, evidence)
        checks[key] = item

    verification = exp_common.build_verification("E0", checks=checks)
    exp_common.write_json(OUT / "verification.json", verification)
    print(json.dumps({"passed": verification["passed"], "checks": {k: v["ok"] for k, v in checks.items()}}, indent=2))


if __name__ == "__main__":
    main()
