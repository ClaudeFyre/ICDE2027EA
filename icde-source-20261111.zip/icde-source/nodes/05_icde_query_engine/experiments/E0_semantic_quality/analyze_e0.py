"""E0 analysis: render analysis.md from output.json."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "_common"))
import icde_paths  # noqa: E402

REPO = icde_paths.resolve_repo_root(__file__)
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e0_20261009"


def main() -> None:
    out = json.loads((OUT / "output.json").read_text(encoding="utf-8"))
    ce = out["results"]["counterexamples"]
    an = out["results"]["anchor_diagnosis"]
    top1 = an["labelled_top1"]
    ws = an["world_sensitivity"]
    mvm = an["modal_vs_mean"]
    gcn = an["gcn_learned_scorer"]

    lines = []
    lines.append("# E0 Semantic / Quality Acceptance — analysis")
    lines.append("")
    lines.append(f"- experiment: {out['experiment']}  status: **{out['status']}**")
    lines.append(f"- created (UTC): {out['created']}")
    lines.append(f"- host: {out['host']['os']} / Python {out['host']['python']} / {out['host']['cpu_cores']} cores; note: {out['host']['note']}")
    lines.append("")
    lines.append("## 1. Semantic counterexamples (toy, analytic)")
    lines.append("")
    lines.append("| Counterexample | Construction | modal winner | comparator winner | holds |")
    lines.append("| --- | --- | --- | --- | --- |")
    c1 = ce["CE1"]
    lines.append(f"| CE1 modal vs mean-score | {c1['construction']} | {c1['modal_winner']} | mean-score {c1['mean_score_winner']} | {c1['holds']} |")
    c2 = ce["CE2"]
    lines.append(f"| CE2 modal vs Gaussian-W2 | {c2['construction']} | {c2['modal_winner']} | W2 {c2['gaussian_w2_winner']} | {c2['holds']} |")
    c3 = ce["CE3"]
    lines.append(f"| CE3 FP64→FP32 flip | {c3['construction']} | FP64 {c3['fp64_winner']} | FP32 {c3['fp32_winner']} | {c3['holds']} |")
    lines.append("")
    lines.append(f"- CE1 winner mass: `{c1['winner_mass']}`; mean scores: `{c1['mean_scores']}`.")
    lines.append(f"- CE2 W2² to degenerate reference: `{c2['w2_squared_to_ref']}`; moments: `{c2['candidate_moments']}`.")
    lines.append(f"- CE3 FP64 scores `{c3['fp64_scores']}` round to FP32 `{c3['fp32_scores']}`; a 1e-8 margin flips the exact label.")
    lines.append("")
    lines.append("Conclusion: the world-modal winner, the mean-score winner and the Gaussian-W2 top-1 winner are three")
    lines.append("different estimands; embedding/mean tolerance cannot substitute for exact label/status comparison.")
    lines.append("")
    lines.append("## 2. Interpretable structural scorer on the frozen regression anchor")
    lines.append("")
    lines.append(f"- dataset: `{an['anchor_dataset']}`")
    lines.append(f"- content digest: `{an['anchor_content_digest']}` (matches declared: **{an['digest_matches_declared']}**)")
    lines.append(f"- edges: {an['edge_count']} (uncertain: {an['uncertain_edges']}); candidate pool: {an['candidate_pool_size']}; labelled test queries: {an['test_query_count']}")
    lines.append(f"- scorer: {an['structural_scorer']['definition']}")
    lines.append(f"- MC worlds: {an['mc_worlds']} (seed {an['seed']}).")
    lines.append("")
    lines.append("| Metric | Value |")
    lines.append("| --- | --- |")
    lines.append(f"| labelled top-1 accuracy (base world) | {top1['correct']}/{top1['total']} = {top1['accuracy']:.3f} |")
    lines.append(f"| sources with varying world winner | {ws['sources_with_varying_winner']}/{ws['total_test_sources']} = {ws['fraction']:.3f} |")
    lines.append(f"| winner-change events across MC worlds | {ws['winner_change_events_across_mc_worlds']} |")
    lines.append(f"| positive-mass winner count | {an['positive_mass_winner_count']} (of {an['candidate_pool_size']} pool) |")
    lines.append(f"| modal vs mean-score disagreement | {mvm['sources_disagreeing']}/{mvm['total']} = {mvm['fraction']:.3f} |")
    lines.append("")
    lines.append("Reading: the lexical+degree structural scorer is only ~9.4% top-1 (random over 96 is ~1.0%), i.e. it is NOT")
    lines.append("good enough to serve as the main EA scorer on this probe — entity short-IDs carry no lexical signal. The")
    lines.append("winner law is highly world-sensitive (every test source changes winner across MC worlds; all 96 candidates")
    lines.append("win somewhere), and modal vs mean disagree on 53% of sources. These are quantitative gates, not a claim of")
    lines.append("scorer quality.")
    lines.append("")
    lines.append("## 3. Learned GCN scorer")
    lines.append("")
    lines.append(f"- status: **{gcn['status']}**. reason: {gcn['reason']}")
    lines.append(f"- gate: {gcn['gate']}")
    lines.append("")
    lines.append("## 4. Limitations and next gate")
    lines.append("")
    lines.append("- Counterexamples are hand-built analytic probes, not real-domain quality evidence.")
    lines.append("- The structural scorer is a numpy oracle, not the production scorer; its poor accuracy is a negative result")
    lines.append("  that motivates (not substitutes for) a validated learned scorer.")
    lines.append("- Wall-clock timing was not used; counts are exact.")
    lines.append("- Next gate: train/validate a new-domain scorer, freeze its checkpoint sha256, and re-run section 2 with it.")
    (OUT / "analysis.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {OUT / 'analysis.md'}")


if __name__ == "__main__":
    main()
