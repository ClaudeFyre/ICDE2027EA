"""E0 semantic / quality acceptance runner.

Two parts:
  A. Semantic counterexample probes on hand-built analytic worlds:
     CE1 modal winner != mean-score winner
     CE2 modal winner != Gaussian-W2 top1 winner
     CE3 FP64 -> FP32 conversion flips the winner (exact label, not tolerance)
  B. Interpretable structural scorer diagnosis on the frozen regression anchor
     graph (content digest 0ee65206...). Reports labelled top-1 alignment
     quality, world-sensitivity, positive-mass winner count, and modal vs
     mean-score disagreement. The learned GCN scorer is marked pending.

Runs without torch.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

EXPERIMENTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(EXPERIMENTS / "_common"))
import icde_paths  # noqa: E402  (portable repo/input resolver)

REPO = icde_paths.resolve_repo_root(__file__)
sys.path.insert(0, str(REPO / "src"))

import exp_common  # noqa: E402
from pkgea.backbones.toy import ToyStructuralBackbone  # noqa: E402
from pkgea.contracts import dataset_content_digest  # noqa: E402
from pkgea.query.modal import world_winner  # noqa: E402

EXPECTED_DIGEST = "0ee6520679c463239312c3692a070866cf94475534b4df18ee01052339568337"
# Resolve the frozen anchor graph via the portable resolver and fail fast if its
# machine-independent content digest does not match the frozen value.
ANCHOR = icde_paths.resolve_input(
    "openea-d-w-probe-q32-a64-attributes-independent-s17",
    expected_digest=EXPECTED_DIGEST,
)
OUT = REPO / "nodes" / "05_icde_query_engine" / "results" / "icde_e0_20261009"
RAW = OUT / "raw"

SEED = 17
MC_WORLDS = 2000


# ---------------------------------------------------------------------------
# Part A: analytic counterexamples
# ---------------------------------------------------------------------------


def ce1_modal_vs_mean() -> dict[str, object]:
    """Two Bernoulli worlds. Modal=A (0.7) but mean-score=B."""
    # world True (p=0.7): A=1.0, B=0.0  -> winner A
    # world False (p=0.3): A=0.0, B=100.0 -> winner B
    p = 0.7
    scores = {
        "True": {"A": 1.0, "B": 0.0},
        "False": {"A": 0.0, "B": 100.0},
    }
    worlds = ("True", "False")
    probs = (p, 1.0 - p)
    modal_counts = {"A": 0.0, "B": 0.0}
    mean_scores = {"A": 0.0, "B": 0.0}
    for w, pr in zip(worlds, probs, strict=True):
        win = world_winner(scores[w], ("A", "B"))
        modal_counts[win] += pr
        for c in ("A", "B"):
            mean_scores[c] += pr * scores[w][c]
    modal_winner = min(modal_counts, key=lambda c: (-modal_counts[c], c))
    mean_winner = min(mean_scores, key=lambda c: (-mean_scores[c], c))
    return {
        "construction": "Bernoulli worlds: True(p=0.7)->A, False(p=0.3)->B with B magnitude 100x",
        "world_probabilities": {"True": p, "False": 1.0 - p},
        "winner_mass": modal_counts,
        "modal_winner": modal_winner,
        "mean_scores": mean_scores,
        "mean_score_winner": mean_winner,
        "holds": modal_winner != mean_winner,
    }


def ce2_modal_vs_gaussian_w2() -> dict[str, object]:
    """Modal=A but Gaussian-W2 top1 (closest to a degenerate reference)=B.

    W2^2 in 1-D between N(mu, sigma^2) and a degenerate reference N(0,0) is
    mu^2 + sigma^2 (mean offset squared plus variance).
    """
    # world True (p=0.7): ref=0, A=100, B=1 -> world winner A
    # world False (p=0.3): ref=0, A=-100, B=2 -> world winner B
    p = 0.7
    ref = {"True": 0.0, "False": 0.0}
    a = {"True": 100.0, "False": -100.0}
    b = {"True": 1.0, "False": 2.0}
    probs = (p, 1.0 - p)
    states = ("True", "False")
    # world modal winner over candidates {A,B}
    modal_counts = {"A": 0.0, "B": 0.0}
    for st, pr in zip(states, probs, strict=True):
        win = world_winner({"A": a[st], "B": b[st]}, ("A", "B"))
        modal_counts[win] += pr

    def moments(scores: dict[str, float]) -> tuple[float, float]:
        mu = sum(pr * scores[st] for st, pr in zip(states, probs, strict=True))
        var = sum(pr * (scores[st] - mu) ** 2 for st, pr in zip(states, probs, strict=True))
        return mu, var

    ref_mu, ref_var = moments(ref)
    a_mu, a_var = moments(a)
    b_mu, b_var = moments(b)

    def w2_to_ref(mu: float, var: float) -> float:
        # 1-D Gaussian W2^2 to reference N(ref_mu, ref_var)
        return (mu - ref_mu) ** 2 + (np.sqrt(var) - np.sqrt(ref_var)) ** 2

    a_w2 = w2_to_ref(a_mu, a_var)
    b_w2 = w2_to_ref(b_mu, b_var)
    w2_winner = "A" if a_w2 < b_w2 else "B"
    modal_winner = min(modal_counts, key=lambda c: (-modal_counts[c], c))
    return {
        "construction": "ref degenerate at 0; A wins 0.7 worlds but with 100/-100 swings; B wins 0.3 but clusters near ref",
        "world_probabilities": {"True": p, "False": 1.0 - p},
        "winner_mass": modal_counts,
        "modal_winner": modal_winner,
        "candidate_moments": {
            "ref": {"mu": ref_mu, "var": ref_var},
            "A": {"mu": a_mu, "var": a_var},
            "B": {"mu": b_mu, "var": b_var},
        },
        "w2_squared_to_ref": {"A": a_w2, "B": b_w2},
        "gaussian_w2_winner": w2_winner,
        "holds": modal_winner != w2_winner,
    }


def ce3_fp64_fp32_flip() -> dict[str, object]:
    """FP64 margin 1e-8 decides B; FP32 rounds both to 1.0 -> tie -> lexical A."""
    fp64 = {"A": 1.0, "B": 1.0 + 1e-8}
    fp32 = {c: float(np.float32(v)) for c, v in fp64.items()}
    winner64 = world_winner(fp64, ("A", "B"))
    winner32 = world_winner(fp32, ("A", "B"))
    return {
        "construction": "FP64 scores A=1.0, B=1.0+1e-8; cast both to float32",
        "fp64_scores": fp64,
        "fp32_scores": fp32,
        "fp64_winner": winner64,
        "fp32_winner": winner32,
        "delta_used": 1e-8,
        "holds": winner64 != winner32,
    }


# ---------------------------------------------------------------------------
# Part B: structural scorer diagnosis on the anchor graph
# ---------------------------------------------------------------------------


def build_vectorized_scorer(bb: ToyStructuralBackbone):
    """Return (sources, targets, lexical, out_inc, in_inc, probs).

    Degrees per world state are computed as boolean matrix products so the
    992-triple graph is scored over thousands of worlds in numpy.
    """
    entities = bb.all_entities
    index = {e: i for i, e in enumerate(entities)}
    n_ent = len(entities)
    n_edges = len(bb.triples)
    out_inc = np.zeros((n_ent, n_edges), dtype=np.float64)
    in_inc = np.zeros((n_ent, n_edges), dtype=np.float64)
    probs = np.zeros(n_edges, dtype=np.float64)
    for j, tr in enumerate(bb.triples):
        out_inc[index[tr["head_id"]], j] = 1.0
        in_inc[index[tr["tail_id"]], j] = 1.0
        probs[j] = float(tr["confidence"])
    # candidate pool = all target entities; sources = all source entities
    sources = bb.source_entities
    targets = bb.target_entities
    lexical = np.array(
        [[bb.lexical_scores[(s, t)] for t in targets] for s in sources],
        dtype=np.float64,
    )
    src_idx = np.array([index[s] for s in sources])
    tgt_idx = np.array([index[t] for t in targets])
    return {
        "src_idx": src_idx,
        "tgt_idx": tgt_idx,
        "out_inc": out_inc,
        "in_inc": in_inc,
        "probs": probs,
        "lexical": lexical,
        "sources": sources,
        "targets": targets,
    }


def scores_for_worlds(v: dict, worlds: np.ndarray) -> np.ndarray:
    """worlds: (n_worlds, n_edges) bool/float -> scores (n_worlds, n_sources, n_targets)."""
    W = worlds.astype(np.float64)
    out_deg = W @ v["out_inc"].T  # (n_worlds, n_ent)
    in_deg = W @ v["in_inc"].T
    src_out = out_deg[:, v["src_idx"]]  # (n_worlds, n_sources)
    src_in = in_deg[:, v["src_idx"]]
    tgt_out = out_deg[:, v["tgt_idx"]]  # (n_worlds, n_targets)
    tgt_in = in_deg[:, v["tgt_idx"]]
    # degree distance |out_s - out_t| + |in_s - in_t|
    dd = (
        np.abs(src_out[:, :, None] - tgt_out[:, None, :])
        + np.abs(src_in[:, :, None] - tgt_in[:, None, :])
    )
    structural = 1.0 / (1.0 + dd)
    return 0.6 * v["lexical"][None, :, :] + 0.4 * structural


def diagnose_anchor() -> dict[str, object]:
    digest = dataset_content_digest(ANCHOR)
    bb = ToyStructuralBackbone.from_dataset(ANCHOR)
    v = build_vectorized_scorer(bb)
    probs = v["probs"]
    n_edges = len(probs)

    # labelled test alignments
    import csv

    with (ANCHOR / "alignments.tsv").open(encoding="utf-8-sig", newline="") as h:
        alignments = list(csv.DictReader(h, delimiter="\t"))
    test = [r for r in alignments if r["split"] == "test"]
    src_list = list(v["sources"])
    tgt_list = list(v["targets"])
    src_pos = {s: i for i, s in enumerate(src_list)}
    tgt_pos = {t: i for i, t in enumerate(tgt_list)}
    test_sources = [r["source_entity_id"] for r in test]
    gold = {r["source_entity_id"]: r["target_entity_id"] for r in test}
    test_src_idx = np.array([src_pos[s] for s in test_sources])

    # base world = threshold p>=0.5
    base_world = (probs >= 0.5).astype(np.float64)[None, :]
    base_scores = scores_for_worlds(v, base_world)[0]  # (n_sources, n_targets)
    base_winners = base_scores[test_src_idx].argmax(axis=1)
    top1_correct = 0
    per_source = []
    for k, s in enumerate(test_sources):
        win = tgt_list[int(base_winners[k])]
        ok = win == gold[s]
        top1_correct += int(ok)
        per_source.append({"source": s, "gold": gold[s], "base_winner": win, "correct": ok})
    top1_accuracy = top1_correct / len(test_sources)

    # MC worlds
    rng = np.random.default_rng(SEED)
    mc = rng.random((MC_WORLDS, n_edges)) < probs[None, :]
    mc_scores = scores_for_worlds(v, mc)  # (n_worlds, n_sources, n_targets)
    mc_test = mc_scores[:, test_src_idx, :]  # (n_worlds, n_test_sources, n_targets)
    mc_winner_idx = mc_test.argmax(axis=2)  # (n_worlds, n_test_sources)

    # world-sensitivity: per source number of distinct winners; sources whose winner varies
    distinct_per_source = [len(np.unique(mc_winner_idx[:, k])) for k in range(len(test_sources))]
    varying_sources = sum(1 for d in distinct_per_source if d > 1)
    # winner-change events across consecutive worlds (informal, not a system metric)
    change_events = int(
        sum(
            int(mc_winner_idx[w, k] != mc_winner_idx[w - 1, k])
            for w in range(1, MC_WORLDS)
            for k in range(len(test_sources))
        )
    )
    # positive-mass winners
    positive_mass = len(np.unique(mc_winner_idx))

    # modal (empirical) vs mean-score winner per source
    modal_winner_idx = np.array(
        [
            np.bincount(mc_winner_idx[:, k], minlength=len(tgt_list)).argmax()
            for k in range(len(test_sources))
        ]
    )
    expected_scores = scores_for_worlds(v, probs[None, :])[0]
    mean_winner_idx = expected_scores[test_src_idx].argmax(axis=1)
    modal_mean_disagree = int(np.sum(modal_winner_idx != mean_winner_idx))

    return {
        "anchor_dataset": str(ANCHOR),
        "anchor_content_digest": digest,
        "digest_matches_declared": digest == EXPECTED_DIGEST,
        "edge_count": n_edges,
        "uncertain_edges": int(np.sum((probs > 0.0) & (probs < 1.0))),
        "candidate_pool_size": len(tgt_list),
        "test_query_count": len(test_sources),
        "structural_scorer": {
            "definition": "0.6*lexical(SequenceMatcher label ratio) + 0.4/(1+|out_s-out_t|+|in_s-in_t|) over thresholded/sampled adjacency; original float64; winner=argmax lexical tie-break",
            "source": "pkgea.backbones.toy.ToyStructuralBackbone (vectorized degree via incidence product)",
        },
        "seed": SEED,
        "mc_worlds": MC_WORLDS,
        "labelled_top1": {
            "world": "base threshold p>=0.5",
            "correct": top1_correct,
            "total": len(test_sources),
            "accuracy": top1_accuracy,
        },
        "world_sensitivity": {
            "sources_with_varying_winner": varying_sources,
            "total_test_sources": len(test_sources),
            "fraction": varying_sources / len(test_sources),
            "distinct_winners_per_source": distinct_per_source,
            "winner_change_events_across_mc_worlds": change_events,
        },
        "positive_mass_winner_count": positive_mass,
        "modal_vs_mean": {
            "sources_disagreeing": modal_mean_disagree,
            "total": len(test_sources),
            "fraction": modal_mean_disagree / len(test_sources),
        },
        "gcn_learned_scorer": {
            "status": "pending",
            "reason": "no torch/GPU on this host and the checkpoint is for the old 984-entity/992-edge probe; a new-domain trained+validated scorer is required",
            "gate": "train/validate on new domain, freeze checkpoint sha256, then re-run labelled top1 and world-sensitivity with it",
        },
        "per_source": per_source,
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    RAW.mkdir(parents=True, exist_ok=True)

    ce1 = ce1_modal_vs_mean()
    ce2 = ce2_modal_vs_gaussian_w2()
    ce3 = ce3_fp64_fp32_flip()
    anchor = diagnose_anchor()

    gates = [
        {"id": "CE1_modal_ne_mean", "passed": bool(ce1["holds"]), "detail": f"modal={ce1['modal_winner']} mean={ce1['mean_score_winner']}"},
        {"id": "CE2_modal_ne_gaussian_w2", "passed": bool(ce2["holds"]), "detail": f"modal={ce2['modal_winner']} w2={ce2['gaussian_w2_winner']}"},
        {"id": "CE3_fp64_fp32_flip", "passed": bool(ce3["holds"]), "detail": f"fp64={ce3['fp64_winner']} fp32={ce3['fp32_winner']}"},
        {"id": "anchor_digest_verified", "passed": bool(anchor["digest_matches_declared"]), "detail": anchor["anchor_content_digest"]},
        {"id": "world_sensitivity_reported", "passed": anchor["world_sensitivity"]["total_test_sources"] > 0, "detail": f"fraction={anchor['world_sensitivity']['fraction']:.3f}"},
        {"id": "gcn_scorer_pending_explicit", "passed": anchor["gcn_learned_scorer"]["status"] == "pending", "detail": "learned GCN scorer marked pending, not substituted"},
    ]
    all_pass = all(g["passed"] for g in gates)
    status = "passed" if all_pass else "failed"

    inputs = {
        "src/pkgea/query/modal.py": exp_common.sha256_file(REPO / "src" / "pkgea" / "query" / "modal.py"),
        "src/pkgea/backbones/toy.py": exp_common.sha256_file(REPO / "src" / "pkgea" / "backbones" / "toy.py"),
        str(ANCHOR): anchor["anchor_content_digest"],
    }

    # persist per-source raw
    exp_common.write_json(RAW / "anchor_per_source.json", {"per_source": anchor["per_source"]})
    exp_common.write_json(RAW / "counterexamples.json", {"CE1": ce1, "CE2": ce2, "CE3": ce3})

    results = {
        "counterexamples": {"CE1": ce1, "CE2": ce2, "CE3": ce3},
        "anchor_diagnosis": anchor,
    }
    output = exp_common.build_output(
        "E0",
        inputs=inputs,
        results=results,
        status=status,
        gates=gates,
        raw_files=[str(RAW / "anchor_per_source.json"), str(RAW / "counterexamples.json")],
        host_note="informal wall-clock (host may have parallel load); correctness/count metrics unaffected",
    )
    exp_common.write_json(OUT / "output.json", output)
    print(json.dumps({"status": status, "gates": gates}, indent=2))


if __name__ == "__main__":
    main()
