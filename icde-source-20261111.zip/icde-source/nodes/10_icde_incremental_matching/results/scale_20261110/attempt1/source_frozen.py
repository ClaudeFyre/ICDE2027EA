"""Full-competition, continuous-update and memory study for ICDE matching.

All complete-graph pricing is tiled. HiGHS models retain their actual simplex
bases between updates. Published native sparse JV and POT solvers provide
independent assignment checks under explicitly stated contracts.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback
import types
import zipfile

import numpy as np
import psutil
from scipy.optimize import linear_sum_assignment
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import min_weight_full_bipartite_matching

import icde_incremental_matching_pilot_20261109 as pilot


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "nodes/10_icde_incremental_matching/results/scale_20261110/attempt1"
RULES = ROOT / "papers/icde/INCREMENTAL_MATCHING_SCALE_PROTOCOL_20261110.md"
DEPS = ROOT / ".runtime/icde_incremental_deps_20261110"
sys.path.insert(0, str(DEPS))
import highspy

TOL = 1e-8
OBJ_TOL = 1e-6
TILE = 256
GRAPHS = ("dw", "enfr")
SIZES = (1024, 4096, 8192, 15000)
METHODS = ("dense_cold", "cache_warm", "stream_warm", "block_warm")
EVENTS = ("source_mix_1pct", "target_mix_1pct", "source_remove_1pct",
          "target_remove_1pct", "source_reinsert", "target_reinsert",
          "both_mix_10pct", "historical_edge_deletion")


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def save_npz(path, **values):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        np.savez_compressed(handle, **values)


def sha(path):
    return pilot.sha(path)


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def relative(path):
    return Path(path).relative_to(ROOT).as_posix()


def freeze():
    if OUT.exists():
        raise FileExistsError(OUT)
    parent = load(pilot.OUT / "protocol.json")
    files = [Path(__file__), ROOT / "scripts/icde_incremental_matching_pilot_20261109.py",
             ROOT / "scripts/www_quality_recovery_v13_common.py", ROOT / "scripts/safe_run.py",
             ROOT / "configs/resource_profiles.json", RULES]
    deps = sorted(p for p in DEPS.rglob("*") if p.is_file() and p.suffix in (".py", ".pyd", ".dll"))
    save(OUT / "protocol.json", {
        "kind": "authorized_full_competition_extension_not_confirmation",
        "date": "2026-11-10", "rules_sha256": sha(RULES),
        "input_sha256": parent["input_sha256"],
        "code_sha256": {relative(p): sha(p) for p in files},
        "dependency_sha256": {relative(p): sha(p) for p in deps},
        "highs_version": highspy.Highs().version(), "POT_version": "0.9.4",
        "graphs": GRAPHS, "source_sizes": SIZES, "target_count": 15000,
        "events": EVENTS, "methods": METHODS,
        "repeats": {"dense_cold": 1, "cache_warm": 3, "stream_warm": 3, "block_warm": 3},
        "tau": .4, "pricing_tolerance": TOL, "objective_tolerance": OBJ_TOL,
        "tile_rows": TILE, "lp_seconds_limit": 600, "maximum_pricing_rounds": 64,
        "whole_arrays_loaded": True, "labels_accessed": False,
        "decision": "complete all admitted cases, report effects; no 20pct early stopping",
    })
    (OUT / "source_frozen.py").write_bytes(Path(__file__).read_bytes())
    print("FROZEN full scale and continuous updates", flush=True)


def identities(crc=False):
    p = load(OUT / "protocol.json")
    checks = 0
    for category in ("input_sha256", "code_sha256", "dependency_sha256"):
        for name, expected in p[category].items():
            if sha(ROOT / name) != expected:
                raise AssertionError("frozen identity changed " + name)
            checks += 1
            if crc and name.endswith(".npz"):
                with zipfile.ZipFile(ROOT / name) as archive:
                    if archive.testzip() is not None:
                        raise AssertionError("NPZ CRC failed " + name)
                checks += 1
    return checks


def recover():
    save(OUT / "recovery.json", {"status": "PASS", "checks": identities(crc=True),
        "scope": "all consumed input, source and native dependencies, four NPZ CRC checks"})
    print("RECOVERY PASS", flush=True)


def new_highs():
    h = highspy.Highs()
    for key, value in (("output_flag", False), ("threads", 1), ("solver", "simplex"),
                       ("primal_feasibility_tolerance", 1e-9),
                       ("dual_feasibility_tolerance", 1e-9), ("time_limit", 600.0)):
        status = h.setOptionValue(key, value)
        if status != highspy.HighsStatus.kOk:
            raise RuntimeError("unsupported HiGHS option " + key)
    return h


class MatchingModel:
    def __init__(self, n, m):
        self.n, self.m = n, m
        self.h = new_highs()
        self.h.addRows(n + m, np.full(n + m, -highspy.kHighsInf), np.ones(n + m),
            0, np.zeros(n + m + 1, dtype=np.int32), np.array([], dtype=np.int32), np.array([], dtype=float))
        self.rows = np.array([], dtype=np.int32)
        self.cols = np.array([], dtype=np.int32)
        self.values = np.array([], dtype=float)
        self.keys = set()
        self.aq = np.ones(n, dtype=bool)
        self.at = np.ones(m, dtype=bool)

    def add(self, rows, cols, values):
        keys = np.asarray(rows, dtype=np.int64) * self.m + cols
        positions = [i for i, key in enumerate(keys) if int(key) not in self.keys]
        if not positions:
            return 0
        positions = np.asarray(positions, dtype=int)
        keys = keys[positions]
        _, first = np.unique(keys, return_index=True)
        positions = positions[np.sort(first)]
        row = np.asarray(rows, dtype=np.int32)[positions]
        col = np.asarray(cols, dtype=np.int32)[positions]
        value = np.asarray(values, dtype=float)[positions]
        count = len(row)
        indices = np.column_stack([row, self.n + col]).astype(np.int32).ravel()
        status = self.h.addCols(count, -value, np.zeros(count), np.full(count, highspy.kHighsInf),
            2 * count, np.arange(count + 1, dtype=np.int32) * 2, indices, np.ones(2 * count))
        if status != highspy.HighsStatus.kOk:
            raise RuntimeError("cannot add matching columns")
        self.rows = np.r_[self.rows, row]
        self.cols = np.r_[self.cols, col]
        self.values = np.r_[self.values, value]
        self.keys.update(int(i) * self.m + int(j) for i, j in zip(row, col))
        return count

    def update(self, provider, changed_q, changed_t, active_q, active_t):
        qmask = np.zeros(self.n, dtype=bool)
        tmask = np.zeros(self.m, dtype=bool)
        qmask[changed_q] = True
        tmask[changed_t] = True
        changed = np.flatnonzero(qmask[self.rows] | tmask[self.cols]).astype(np.int32)
        if len(changed):
            values = provider.edge_values(self.rows[changed], self.cols[changed])
            self.h.changeColsCost(len(changed), changed, -values)
            self.values[changed] = values
        for i in np.flatnonzero(active_q != self.aq):
            self.h.changeRowBounds(int(i), -highspy.kHighsInf, float(active_q[i]))
        for j in np.flatnonzero(active_t != self.at):
            self.h.changeRowBounds(self.n + int(j), -highspy.kHighsInf, float(active_t[j]))
        self.aq, self.at = active_q.copy(), active_t.copy()
        return len(changed)

    def run(self):
        start = time.perf_counter()
        self.h.run()
        if self.h.getModelStatus() != highspy.HighsModelStatus.kOptimal:
            raise RuntimeError("LP not optimal " + self.h.modelStatusToString(self.h.getModelStatus()))
        solution = self.h.getSolution()
        x = np.asarray(solution.col_value)
        dual = np.maximum(-np.asarray(solution.row_dual), 0)
        selected = x > .5
        if len(x) and np.max(np.minimum(abs(x), abs(x - 1))) > OBJ_TOL:
            raise AssertionError("fractional matching LP")
        assigned = np.full(self.n, -1, dtype=np.int32)
        assigned[self.rows[selected]] = self.cols[selected]
        if len(np.unique(self.cols[selected])) != np.count_nonzero(selected):
            raise AssertionError("duplicate matched target")
        if np.any(~self.aq[self.rows[selected]]) or np.any(~self.at[self.cols[selected]]):
            raise AssertionError("matching uses inactive entity")
        objective = float(self.values[selected].sum())
        dual_objective = float(dual[:self.n][self.aq].sum() + dual[self.n:][self.at].sum())
        if abs(objective - dual_objective) > OBJ_TOL:
            raise AssertionError("restricted primal-dual objective gap")
        return dual[:self.n], dual[self.n:], assigned, objective, {
            "seconds": time.perf_counter() - start,
            "simplex_iterations": int(self.h.getInfo().simplex_iteration_count),
            "primal_dual_gap": objective - dual_objective}

    def persist(self, path):
        basis = self.h.getBasis()
        save_npz(path, rows=self.rows, cols=self.cols, values=self.values,
            basis_cols=np.array([int(s) for s in basis.col_status], dtype=np.int32),
            basis_rows=np.array([int(s) for s in basis.row_status], dtype=np.int32),
            n=np.array(self.n), m=np.array(self.m))

    @classmethod
    def restore(cls, path):
        with np.load(path, allow_pickle=False) as data:
            result = cls(int(data["n"]), int(data["m"]))
            result.add(data["rows"], data["cols"], data["values"])
            basis = highspy.HighsBasis()
            basis.col_status = [highspy.HighsBasisStatus(int(x)) for x in data["basis_cols"]]
            basis.row_status = [highspy.HighsBasisStatus(int(x)) for x in data["basis_rows"]]
            result.h.setBasis(basis)
        return result


class Scores:
    def __init__(self, q, targets, matrix=None):
        self.q, self.targets, self.matrix = q, targets, matrix
        self.pairs = 0

    def tile(self, start, stop):
        if self.matrix is not None:
            return np.asarray(self.matrix[start:stop])
        self.pairs += (stop - start) * len(self.targets)
        return self.q[start:stop] @ self.targets.T - .4

    def edge_values(self, rows, cols):
        if self.matrix is not None:
            return np.asarray(self.matrix[rows, cols])
        values = np.empty(len(rows))
        for start in range(0, len(rows), 2048):
            end = start + 2048
            values[start:end] = np.einsum("ij,ij->i", self.q[rows[start:end]], self.targets[cols[start:end]]) - .4
        self.pairs += len(rows)
        return values

    def top(self, k, aq=None, at=None):
        n = len(self.q)
        columns = np.empty((n, k), dtype=np.int32)
        values = np.empty((n, k))
        for start in range(0, n, TILE):
            stop = min(n, start + TILE)
            block = self.tile(start, stop)
            if at is not None:
                block = block.copy()
                block[:, ~at] = -1e6
            pos = np.argpartition(block, -k, axis=1)[:, -k:]
            columns[start:stop] = pos
            values[start:stop] = np.take_along_axis(block, pos, axis=1)
        return np.repeat(np.arange(n), k), columns.ravel(), values.ravel()

    def price(self, a, b, aq, at):
        n = len(self.q)
        best, target = np.zeros(n), np.full(n, -1, dtype=np.int32)
        for start in range(0, n, TILE):
            stop = min(n, start + TILE)
            block = self.tile(start, stop) - b[None, :]
            block[:, ~at] = -1e6
            pos = np.argmax(block, axis=1)
            violation = block[np.arange(stop - start), pos] - a[start:stop]
            positive = (violation > TOL) & aq[start:stop]
            best[start:stop] = np.where(positive, violation, 0)
            target[start:stop] = np.where(positive, pos, -1)
        return best, target


def initial_model(provider, active_q=None, active_t=None):
    n, m = len(provider.q), len(provider.targets)
    model = MatchingModel(n, m)
    aq = np.ones(n, dtype=bool) if active_q is None else active_q
    at = np.ones(m, dtype=bool) if active_t is None else active_t
    rows, cols, values = provider.top(16, aq, at)
    keep = (values > 0) & aq[rows] & at[cols]
    model.add(rows[keep], cols[keep], values[keep])
    model.update(provider, [], [], aq, at)
    return model


def complete(model, provider, index=None):
    lp_seconds = pricing_seconds = 0.0
    simplex_iterations = added = 0
    for iteration in range(64):
        a, b, assigned, objective, info = model.run()
        lp_seconds += info["seconds"]
        simplex_iterations += info["simplex_iterations"]
        begin = time.perf_counter()
        if index is None:
            violation, target = provider.price(a, b, model.aq, model.at)
        else:
            aa, bb = a.copy(), b.copy()
            aa[~model.aq] = 1e6
            bb[~model.at] = 1e6
            violation, target, cost = index.price(provider.q, provider.targets, aa, bb)
            provider.pairs += cost["exact_pairs"]
        pricing_seconds += time.perf_counter() - begin
        rows = np.flatnonzero(violation > TOL)
        if not len(rows):
            return {"a": a, "b": b, "assigned": assigned, "objective": objective,
                "rounds": iteration + 1, "lp_seconds": lp_seconds,
                "pricing_seconds": pricing_seconds, "simplex_iterations": simplex_iterations,
                "added_edges": added, "support_edges": len(model.rows),
                "score_pairs": provider.pairs}
        values = provider.edge_values(rows, target[rows])
        count = model.add(rows, target[rows], values)
        if count == 0:
            raise AssertionError("pricing violates existing LP support")
        added += count
    raise RuntimeError("maximum column-generation rounds")


def sparse_jv(rows, cols, values, n, m, aq, at):
    keep = aq[rows] & at[cols]
    rr = np.r_[rows[keep], np.arange(n)]
    cc = np.r_[cols[keep], m + np.arange(n)]
    costs = np.r_[2 - values[keep], np.full(n, 2.0)]
    matrix = coo_matrix((costs, (rr, cc)), shape=(n, m + n)).tocsr()
    ri, ci = min_weight_full_bipartite_matching(matrix)
    real = ci < m
    objective = float((2 - matrix[ri[real], ci[real]].A.ravel()).sum())
    return objective


def validate(model, provider, result):
    begin = time.perf_counter()
    oracle = Scores(provider.q, provider.targets)
    violation, _ = oracle.price(result["a"], result["b"], model.aq, model.at)
    maximum = float(np.max(violation))
    if maximum > TOL:
        raise AssertionError("global dual violation " + str(maximum))
    independent = sparse_jv(model.rows, model.cols, model.values, model.n, model.m, model.aq, model.at)
    if abs(independent - result["objective"]) > OBJ_TOL:
        raise AssertionError("independent native JV disagrees")
    return {"status": "PASS", "full_pair_checks": int(model.aq.sum()) * int(model.at.sum()),
        "max_global_violation": maximum, "independent_sparse_JV_objective": independent,
        "seconds": time.perf_counter() - begin}


def data_for(graph, n):
    original, perturbed, order, ti, ids, basis = pilot.graph_inputs(graph)
    qi = order[:n]
    q, targets = original[qi].copy(), original[ti].copy()
    pq, pt = perturbed[qi].copy(), perturbed[ti].copy()
    return q, targets, pq, pt, ids[qi], ids[ti], basis


def score_matrix(path, q, targets):
    if path.exists():
        raise FileExistsError(path)
    matrix = np.lib.format.open_memmap(path, mode="w+", dtype=np.float64,
        shape=(len(q), len(targets)))
    for start in range(0, len(q), TILE):
        stop = min(start + TILE, len(q))
        matrix[start:stop] = q[start:stop] @ targets.T - .4
    matrix.flush()
    return matrix


def compact(result):
    return {k: value for k, value in result.items() if k not in ("a", "b", "assigned")}


def run_scale(graph, n):
    identities()
    out = OUT / "scale" / f"{graph}_{n}"
    out.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    q, targets, pq, pt, qids, tids, basis = data_for(graph, n)
    loaded = time.perf_counter()
    matrix = score_matrix(out / "scores.npy", q, targets)
    computed = time.perf_counter()
    provider = Scores(q, targets, matrix)
    model = initial_model(provider)
    result = complete(model, provider)
    solved = time.perf_counter()
    check = validate(model, provider, result)
    topk = {}
    for k in (1, 4, 16, 64):
        begin = time.perf_counter()
        rows, cols, values = provider.top(k)
        objective = sparse_jv(rows, cols, values, n, len(targets), model.aq, model.at)
        topk[str(k)] = {"objective": objective, "loss": result["objective"] - objective,
            "seconds": time.perf_counter() - begin}
    model.persist(out / "initial_model.npz")
    save_npz(out / "initial_solution.npz", a=result["a"], b=result["b"], assigned=result["assigned"])
    topone = np.empty(n, dtype=int)
    for start in range(0, n, TILE):
        topone[start:start + TILE] = np.argmax(matrix[start:start + TILE], axis=1)
    row = {"status": "PASS", "graph": graph, "sources": n, "targets": len(targets),
        "source_target_ratio": n / len(targets), "dimension": 600,
        "load_seconds": loaded - started, "score_matrix_seconds": computed - loaded,
        "matching_seconds": solved - computed, "validation": check,
        "score_cache_bytes": int(matrix.nbytes), "top1_duplicate_excess": n - len(np.unique(topone)),
        "matched_sources": int(np.count_nonzero(result["assigned"] >= 0)), "topk": topk,
        "score_sha256": sha(out / "scores.npy"), "source_id_sha256": hashlib.sha256(qids.tobytes()).hexdigest(),
        "result": compact(result), "total_seconds": time.perf_counter() - started,
        "rss_end_bytes": psutil.Process().memory_info().rss,
        "cache_admission_MiB": {str(b): matrix.nbytes <= b * 2**20 for b in (64, 128, 256, 512, 1024, 2048)}}
    save(out / "result.json", row)
    print(json.dumps(row, ensure_ascii=False, indent=2), flush=True)


def workload(q, targets, pq, pt, graph, qids, tids):
    q, targets = q.copy(), targets.copy()
    aq, at = np.ones(len(q), dtype=bool), np.ones(len(targets), dtype=bool)
    removed_q = removed_t = None
    empty = np.array([], dtype=int)
    for step, name in enumerate(EVENTS):
        cq, ct = empty, empty
        if step in (0, 6):
            order = pilot.ordered_ids(qids, graph, f"scale_q_{step}")
            count = math.ceil(len(q) * (.1 if step == 6 else .01))
            cq = order[:count]
            donor = order[1:count + 1]
            q[cq] = pilot.normalized(.85 * q[cq] + .15 * q[donor])
        if step in (1, 6):
            order = pilot.ordered_ids(tids, graph, f"scale_t_{step}")
            count = math.ceil(len(targets) * (.1 if step == 6 else .01))
            ct = order[:count]
            donor = order[1:count + 1]
            targets[ct] = pilot.normalized(.85 * targets[ct] + .15 * targets[donor])
        if step == 2:
            removed_q = pilot.ordered_ids(qids, graph, "scale_remove_q")[:math.ceil(.01 * len(q))]
            aq[removed_q] = False
        if step == 3:
            removed_t = pilot.ordered_ids(tids, graph, "scale_remove_t")[:math.ceil(.01 * len(targets))]
            at[removed_t] = False
        if step == 4:
            aq[removed_q] = True
        if step == 5:
            at[removed_t] = True
        if step == 7:
            cq = np.flatnonzero(np.any(q != pq, axis=1))
            ct = np.flatnonzero(np.any(targets != pt, axis=1))
            q[:] = pq
            targets[:] = pt
        yield step, name, q, targets, cq, ct, aq.copy(), at.copy()


def update_cache(matrix, q, targets, cq, ct):
    if len(cq):
        for start in range(0, len(cq), TILE):
            rows = cq[start:start + TILE]
            matrix[rows] = q[rows] @ targets.T - .4
    if len(ct):
        remaining = np.setdiff1d(np.arange(len(q)), cq)
        for start in range(0, len(remaining), TILE):
            rows = remaining[start:start + TILE]
            matrix[np.ix_(rows, ct)] = q[rows] @ targets[ct].T - .4
    return len(cq) * len(targets) + (len(q) - len(cq)) * len(ct)


def run_trace(graph, method, repeat):
    identities()
    n = 15000
    initial = OUT / "scale" / f"{graph}_{n}"
    load(initial / "result.json")
    out = OUT / "traces" / f"{graph}_{method}_r{repeat}"
    out.mkdir(parents=True, exist_ok=False)
    q, targets, pq, pt, qids, tids, basis = data_for(graph, n)
    setup_start = time.perf_counter()
    model = MatchingModel.restore(initial / "initial_model.npz") if method != "dense_cold" else None
    matrix = np.load(initial / "scores.npy", mmap_mode="c") if method == "cache_warm" else None
    index = pilot.BlockIndex(q, targets, basis, "cap", 256) if method == "block_warm" else None
    setup_seconds = time.perf_counter() - setup_start
    with np.load(initial / "initial_solution.npz", allow_pickle=False) as values:
        previous = values["assigned"].copy()
    records = []
    for step, name, qnew, tnew, cq, ct, aq, at in workload(q, targets, pq, pt, graph, qids, tids):
        begin = time.perf_counter()
        scores_seconds = 0.0
        pairs = 0
        if method == "dense_cold":
            matrix = np.empty((n, len(tnew)))
            for start in range(0, n, TILE):
                stop = min(start + TILE, n)
                matrix[start:stop] = qnew[start:stop] @ tnew.T - .4
            pairs = n * len(tnew)
        elif method == "cache_warm":
            pairs = update_cache(matrix, qnew, tnew, cq, ct)
        elif method == "block_warm":
            index.update(qnew, tnew, cq, ct)
        scores_seconds = time.perf_counter() - begin
        provider = Scores(qnew, tnew, matrix if method in ("cache_warm", "dense_cold") else None)
        if method == "dense_cold":
            model = initial_model(provider, aq, at)
            changed_edges = len(model.rows)
        else:
            changed_edges = model.update(provider, cq, ct, aq, at)
        result = complete(model, provider, index)
        elapsed = time.perf_counter() - begin
        check = validate(model, provider, result)
        changed_assignment = result["assigned"] != previous
        direct = np.zeros(n, dtype=bool)
        direct[cq] = True
        if step in (2, 4):
            direct[pilot.ordered_ids(qids, graph, "scale_remove_q")[:150]] = True
        if len(ct):
            direct |= np.isin(previous, ct)
        if step in (3, 5):
            direct |= np.isin(previous, pilot.ordered_ids(tids, graph, "scale_remove_t")[:150])
        record = {"status": "PASS", "graph": graph, "method": method, "repeat": repeat,
            "step": step, "event": name, "changed_sources": len(cq), "changed_targets": len(ct),
            "active_sources": int(aq.sum()), "active_targets": int(at.sum()),
            "seconds": elapsed, "score_or_index_update_seconds": scores_seconds,
            "changed_candidate_costs": changed_edges, "matrix_update_score_pairs": pairs,
            "matching_changed_sources": int(changed_assignment.sum()),
            "changed_outside_direct_sources": int(np.count_nonzero(changed_assignment & ~direct)),
            "matched_sources": int(np.count_nonzero(result["assigned"] >= 0)),
            "result": compact(result), "validation": check,
            "rss_end_bytes": psutil.Process().memory_info().rss}
        save(out / f"event_{step:02d}.json", record)
        save_npz(out / f"solution_{step:02d}.npz", assigned=result["assigned"], a=result["a"], b=result["b"])
        records.append(record)
        previous = result["assigned"].copy()
        print(graph, method, repeat, step, name, f"{elapsed:.3f}s", f"obj={result['objective']:.9f}", flush=True)
        if method == "dense_cold":
            model.h.clear()
            del matrix, model
            matrix = None
            gc.collect()
    total = sum(r["seconds"] for r in records)
    save(out / "result.json", {"status": "PASS", "graph": graph, "method": method,
        "repeat": repeat, "setup_seconds": setup_seconds, "maintenance_seconds": total,
        "setup_plus_8_requests_seconds": setup_seconds + total, "records": records,
        "basis_retained_across_events": method != "dense_cold", "cache_bytes": n * 15000 * 8 if method == "cache_warm" else 0,
        "scope": "from supplied changed vectors through complete matching; encoder execution and validation separately reported"})


def pot_native():
    for backend in ("PYTORCH", "TENSORFLOW", "JAX", "CUPY"):
        os.environ["POT_BACKEND_DISABLE_" + backend] = "1"
    root = DEPS / "ot"
    package = types.ModuleType("ot")
    package.__path__ = [str(root)]
    sys.modules["ot"] = package
    lp = types.ModuleType("ot.lp")
    lp.__path__ = [str(root / "lp")]
    sys.modules["ot.lp"] = lp
    from ot.lp.emd_wrap import emd_c
    return emd_c


def run_pot(graph, n):
    identities()
    out = OUT / "pot" / f"{graph}_{n}"
    out.mkdir(parents=True, exist_ok=False)
    estimate = 40 * n * n + 512 * 2**20
    if estimate > 7 * 2**30:
        save(out / "result.json", {"status": "NOT_ADMITTED", "graph": graph, "n": n,
            "estimated_bytes": estimate, "job_limit_bytes": 7 * 2**30,
            "reason": "frozen conservative admission estimate; not a measured memory lower bound"})
        return
    q, targets, pq, pt, qids, tids, basis = data_for(graph, n)
    order = pilot.ordered_ids(tids, graph, "POT_balanced_target")[:n]
    targets = targets[order]
    started = time.perf_counter()
    costs = np.empty((n, n))
    for start in range(0, n, TILE):
        stop = min(n, start + TILE)
        costs[start:stop] = 1 - q[start:stop] @ targets.T
    constructed = time.perf_counter()
    function = pot_native()
    masses = np.ones(n)
    begin = time.perf_counter()
    gamma, cost, u, v, code = function(masses, masses, costs, 10000000, 1)
    solver_seconds = time.perf_counter() - begin
    if int(code) != 1:
        raise RuntimeError("POT network simplex result code " + str(code))
    rr, cc = linear_sum_assignment(costs)
    independent = float(costs[rr, cc].sum())
    if abs(float(cost) - independent) > OBJ_TOL:
        raise AssertionError("POT vs dense JV objective mismatch")
    if np.max(abs(gamma.sum(0) - 1)) > OBJ_TOL or np.max(abs(gamma.sum(1) - 1)) > OBJ_TOL:
        raise AssertionError("POT marginals")
    max_violation = 0.0
    for start in range(0, n, TILE):
        stop = min(n, start + TILE)
        max_violation = max(max_violation, float(np.max(u[start:stop, None] + v[None, :] - costs[start:stop])))
    if max_violation > TOL:
        raise AssertionError("POT global dual feasibility")
    save(out / "result.json", {"status": "PASS", "graph": graph, "n": n,
        "contract": "balanced mandatory complete assignment; cost 1-cosine, unit masses",
        "software": "POT 0.9.4 original emd_c network simplex", "threads": 1,
        "score_seconds": constructed - started, "POT_seconds": solver_seconds,
        "objective": float(cost), "independent_dense_JV_objective": independent,
        "global_dual_violation": max_violation, "rss_end_bytes": psutil.Process().memory_info().rss,
        "conservative_admission_bytes": estimate,
        "total_seconds": time.perf_counter() - started})
    print("POT", graph, n, "PASS", solver_seconds, flush=True)


def self_check():
    identities()
    rng = np.random.default_rng(2026111011)
    checks = 0
    for trial in range(8):
        q = pilot.normalized(rng.normal(size=(12, 80)))
        targets = pilot.normalized(rng.normal(size=(19, 80)))
        targets[:8] = q[:8]
        provider = Scores(q, targets)
        model = initial_model(provider)
        result = complete(model, provider)
        validate(model, provider, result)
        basis_before = model.h.getBasis()
        for step in range(4):
            q[0] = pilot.normalized((q[0] + .15)[None])[0]
            aq, at = np.ones(12, dtype=bool), np.ones(19, dtype=bool)
            if step in (1, 2):
                at[0] = False
            if step == 2:
                aq[1] = False
            provider = Scores(q, targets)
            model.update(provider, [0], [], aq, at)
            result = complete(model, provider)
            validate(model, provider, result)
            augmented = np.c_[q @ targets.T - .4, np.zeros((12, 12))]
            augmented[:, :19][:, ~at] = -1e6
            augmented[~aq, :19] = -1e6
            rows, cols = linear_sum_assignment(augmented, maximize=True)
            if abs(float(augmented[rows, cols].sum()) - result["objective"]) > OBJ_TOL:
                raise AssertionError("warm updates differ from dense reference")
            checks += 12 * 19
        if not basis_before.valid:
            raise AssertionError("simplex basis not valid")
        model.h.clear()
    # Exercise the unchanged published native POT binary on a tiny reference.
    function = pot_native()
    cost = np.array([[0., 2., 3.], [3., 0., 2.], [2., 3., 0.]])
    result = function(np.ones(3), np.ones(3), cost, 10000, 1)
    if abs(result[1]) > OBJ_TOL or int(result[4]) != 1:
        raise AssertionError("POT native self check")
    save(OUT / "self_check.json", {"status": "PASS", "full_pair_checks": checks,
        "warm_source_updates": 32, "target_remove_reinsert": True,
        "source_remove_reinsert": True, "actual_valid_simplex_basis": True,
        "independent_dense_JV": True, "POT_native_test": True})
    print("SELF CHECK PASS", checks, flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("freeze", "recover", "self_check", "scale", "trace", "pot"))
    parser.add_argument("--graph", choices=GRAPHS)
    parser.add_argument("--n", type=int)
    parser.add_argument("--method", choices=METHODS)
    parser.add_argument("--repeat", type=int, default=0)
    args = parser.parse_args()
    if args.phase == "freeze":
        freeze()
    elif args.phase == "recover":
        recover()
    elif args.phase == "self_check":
        self_check()
    elif args.phase == "scale":
        run_scale(args.graph, args.n)
    elif args.phase == "trace":
        run_trace(args.graph, args.method, args.repeat)
    elif args.phase == "pot":
        run_pot(args.graph, args.n)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
