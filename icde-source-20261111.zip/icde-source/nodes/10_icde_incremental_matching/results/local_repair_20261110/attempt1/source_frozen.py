"""Finite validation of region LP against specialized dynamic assignment."""
from __future__ import annotations

import argparse
import gc
import json
from pathlib import Path
import time
import traceback

import numpy as np
import psutil
from scipy.optimize import linear_sum_assignment

import icde_incremental_matching_scale_20261110 as prior
from icde_dynamic_hungarian_20261110 import DynamicHungarian, prepare


ROOT = prior.ROOT
OUT = ROOT / "nodes/10_icde_incremental_matching/results/local_repair_20261110/attempt1"
RULES = ROOT / "papers/icde/LOCAL_REPAIR_VALIDATION_PROTOCOL_20261110.md"
METHODS = ("highs_warm", "dense_jv", "dynamic_hungarian", "region_lp")
TOL, GAP = 1e-8, 1e-6


def save(path, value):
    prior.save(path, value)


def identities():
    prior.identities()
    protocol = prior.load(OUT / "protocol.json")
    for name, expected in protocol["sha256"].items():
        if prior.sha(ROOT / name) != expected:
            raise AssertionError("frozen identity changed " + name)


def freeze():
    files = [Path(__file__), ROOT / "scripts/icde_dynamic_hungarian_20261110.py", RULES,
        ROOT / ".runtime/icde_local_repair_deps_20261110/wheel_sources.jsonl"]
    deps = ROOT / ".runtime/icde_local_repair_deps_20261110"
    files += sorted(p for p in deps.rglob("*") if p.suffix in (".py", ".pyd", ".dll"))
    for graph in prior.GRAPHS:
        initial = prior.OUT / "scale" / (graph + "_15000")
        files += [initial / name for name in ("scores.npy", "initial_model.npz", "initial_solution.npz", "result.json")]
        files.append(prior.OUT / "traces" / (graph + "_dense_cold_r0") / "result.json")
    files.append(prior.OUT / "protocol.json")
    checks = sorted((OUT.parent / "development").glob("self_check_*.json"))
    if not checks or prior.load(checks[-1])["status"] != "PASS":
        raise AssertionError("passing micro check required before freeze")
    files.append(checks[-1])
    save(OUT / "protocol.json", {"status": "FROZEN", "methods": METHODS,
        "graphs": prior.GRAPHS, "repeats": 3, "steps": prior.EVENTS,
        "sha256": {p.relative_to(ROOT).as_posix(): prior.sha(p) for p in files},
        "parent_protocol_sha256": prior.sha(prior.OUT / "protocol.json"),
        "labels_accessed": False, "scope": "historical development inputs, controlled trace"})
    (OUT / "source_frozen.py").write_bytes(Path(__file__).read_bytes())
    (OUT / "kernel_frozen.py").write_bytes((ROOT / "scripts/icde_dynamic_hungarian_20261110.py").read_bytes())
    print("FROZEN", len(files), flush=True)


def dense_solution(scores, aq, at, costs=None):
    n, m = scores.shape
    if costs is None:
        costs = np.zeros((n, m + n))
    np.negative(scores, out=costs[:, :m])
    costs[~aq, :m] = 2.0
    costs[:, np.flatnonzero(~at)] = 2.0
    rows, cols = linear_sum_assignment(costs)
    assigned = np.full(n, -1, dtype=np.int64)
    real = cols < m
    assigned[rows[real]] = cols[real]
    return assigned


def objective(scores, assigned):
    real = assigned >= 0
    return float(scores[np.flatnonzero(real), assigned[real]].sum())


def solve_region(q, targets, matrix):
    n, m = matrix.shape
    if n == 0 or m == 0:
        return np.full(n, -1, dtype=np.int64), np.zeros(n), np.zeros(m), {
            "objective": 0., "lp_seconds": 0., "pricing_seconds": 0., "rounds": 0}
    provider = prior.Scores(q, targets, matrix)
    rows, cols, values = provider.top(min(16, m))
    positive = values > 0
    if not np.any(positive):
        return np.full(n, -1, dtype=np.int64), np.zeros(n), np.zeros(m), {
            "objective": 0., "lp_seconds": 0., "pricing_seconds": 0., "rounds": 0}
    model = prior.MatchingModel(n, m)
    model.add(rows[positive], cols[positive], values[positive])
    result = prior.complete(model, provider)
    assigned, a, b = result["assigned"].copy(), result["a"].copy(), result["b"].copy()
    info = prior.compact(result)
    model.h.clear()
    return assigned, a, b, info


def region_repair(q, targets, matrix, previous, old_a, old_b, cq, ct, old_aq, old_at, aq, at):
    n, m = matrix.shape
    dirty_q = np.union1d(cq, np.flatnonzero(aq != old_aq))
    dirty_t = np.union1d(ct, np.flatnonzero(at != old_at))
    if len(dirty_q) + len(dirty_t) == 0:
        return previous.copy(), old_a.copy(), old_b.copy(), {"region_rounds": [], "fallback": False,
            "boundary_scans": 0, "lp_seconds": 0., "pricing_seconds": 0.}
    valid = previous.copy()
    valid[~aq] = -1
    real = valid >= 0
    valid[np.flatnonzero(real)[~at[valid[real]]]] = -1
    owner = np.full(m, -1, dtype=np.int64)
    real = valid >= 0
    owner[valid[real]] = np.flatnonzero(real)
    region = np.zeros(n, dtype=bool)
    region[dirty_q] = True
    region |= np.isin(previous, dirty_t)
    a, b = old_a.copy(), old_b.copy()
    a[~aq | (aq != old_aq)] = 0
    b[~at | (at != old_at)] = 0
    provider = prior.Scores(q, targets, matrix)
    begin = time.perf_counter()
    violation, target = provider.price(a, b, aq, at)
    boundary_seconds = time.perf_counter() - begin
    seeds = np.flatnonzero(violation > TOL)
    region[seeds] = True
    partners = owner[target[seeds]]
    region[partners[partners >= 0]] = True
    rounds, lp_seconds, pricing_seconds = [], 0., 0.
    for iteration in range(8):
        rr = np.flatnonzero(region & aq)
        occupied_outside = valid[(~region) & (valid >= 0)]
        available = at.copy()
        available[occupied_outside] = False
        cc = np.flatnonzero(available)
        local_matrix = np.asarray(matrix[np.ix_(rr, cc)])
        assignment, local_a, local_b, info = solve_region(q[rr], targets[cc], local_matrix)
        del local_matrix
        lp_seconds += info["lp_seconds"]
        pricing_seconds += info["pricing_seconds"]
        assigned = valid.copy()
        assigned[rr] = -1
        matched = assignment >= 0
        assigned[rr[matched]] = cc[assignment[matched]]
        a[rr], b[cc] = local_a, local_b
        begin = time.perf_counter()
        violation, target = provider.price(a, b, aq, at)
        boundary_seconds += time.perf_counter() - begin
        bad = np.flatnonzero(violation > TOL)
        rounds.append({"sources": len(rr), "available_targets": len(cc),
            "violating_sources": len(bad), "LP_rounds": info["rounds"]})
        if not len(bad):
            return assigned, a, b, {"region_rounds": rounds, "fallback": False,
                "boundary_scans": iteration + 2, "lp_seconds": lp_seconds,
                "pricing_seconds": pricing_seconds, "boundary_seconds": boundary_seconds}
        before = int(region.sum())
        region[bad] = True
        partners = owner[target[bad]]
        region[partners[partners >= 0]] = True
        if int(region.sum()) == before:
            raise AssertionError("boundary violation without an external owner")
    rr, cc = np.flatnonzero(aq), np.flatnonzero(at)
    local_matrix = np.asarray(matrix[np.ix_(rr, cc)])
    assignment, local_a, local_b, info = solve_region(q[rr], targets[cc], local_matrix)
    assigned = np.full(n, -1, dtype=np.int64)
    matched = assignment >= 0
    assigned[rr[matched]] = cc[assignment[matched]]
    a, b = np.zeros(n), np.zeros(m)
    a[rr], b[cc] = local_a, local_b
    rounds.append({"sources": len(rr), "available_targets": len(cc),
        "violating_sources": 0, "LP_rounds": info["rounds"], "full_fallback": True})
    return assigned, a, b, {"region_rounds": rounds, "fallback": True, "boundary_scans": 9,
        "lp_seconds": lp_seconds + info["lp_seconds"],
        "pricing_seconds": pricing_seconds + info["pricing_seconds"], "boundary_seconds": boundary_seconds}


def validate(q, targets, scores, assigned, a, b, aq, at, reference):
    begin = time.perf_counter()
    real = assigned >= 0
    rows, cols = np.flatnonzero(real), assigned[real]
    if len(np.unique(cols)) != len(cols) or np.any(~aq[rows]) or np.any(~at[cols]):
        raise AssertionError("invalid matching capacity")
    value = objective(scores, assigned)
    actual = float((np.einsum("ij,ij->i", q[rows], targets[cols]) - .4).sum())
    if abs(value - actual) > GAP or abs(value - reference) > GAP:
        raise AssertionError("independent matching objective")
    result = {"status": "PASS", "objective": value, "actual_vector_objective": actual,
        "reference_objective": reference, "full_pair_checks": 0}
    if a is not None:
        violation, _ = prior.Scores(q, targets).price(a, b, aq, at)
        gap = float(a[aq].sum() + b[at].sum() - value)
        if np.max(violation) > TOL or abs(gap) > GAP or min(a.min(), b.min()) < -TOL:
            raise AssertionError("global optimality certificate " + str((violation.max(), gap)))
        result.update(max_global_violation=float(violation.max()), primal_dual_gap=gap,
            full_pair_checks=int(aq.sum()) * int(at.sum()))
    result["seconds"] = time.perf_counter() - begin
    return result


def self_check(attempt):
    begin = time.perf_counter()
    prepare()
    checks = 0
    for seed in range(10):
        rng = np.random.default_rng(seed)
        for n, m in ((1, 1), (3, 5), (5, 3), (10, 10)):
            matrix = rng.uniform(-.4, .6, (n, m))
            if seed == 0:
                matrix[:] = -.2
            if seed == 1:
                matrix[:] = 0
            aq, at = np.ones(n, dtype=bool), np.ones(m, dtype=bool)
            q, targets = np.zeros((n, 1)), np.zeros((m, 1))
            assigned, a, b, _ = solve_region(q, targets, matrix)
            dynamic = DynamicHungarian(assigned, a, b)
            for step in range(9):
                old_aq, old_at = aq.copy(), at.copy()
                cq, ct = np.array([], dtype=int), np.array([], dtype=int)
                if step in (1, 7, 8):
                    cq = np.array([step % n])
                    matrix[cq] = rng.uniform(-.4, .6, (1, m))
                if step in (2, 7, 8):
                    ct = np.array([step % m])
                    matrix[:, ct] = rng.uniform(-.4, .6, (n, 1))
                if step in (3, 5):
                    aq[0] = step == 5
                if step in (4, 6):
                    at[0] = step == 6
                changed_q = np.union1d(cq, np.flatnonzero(aq != old_aq))
                changed_t = np.union1d(ct, np.flatnonzero(at != old_at))
                expected_assignment = dense_solution(matrix, aq, at)
                expected = objective(matrix, expected_assignment)
                result = dynamic.update(matrix, aq, at, changed_q, changed_t)
                local = region_repair(q, targets, matrix, assigned, a, b, cq, ct, old_aq, old_at, aq, at)
                for matching, da, db, info in (result, local):
                    real = matching >= 0
                    assert len(np.unique(matching[real])) == int(real.sum())
                    assert np.all(aq[np.flatnonzero(real)]) and np.all(at[matching[real]])
                    assert abs(objective(matrix, matching) - expected) <= GAP
                    assert abs(float(da[aq].sum() + db[at].sum()) - expected) <= GAP
                    residual = matrix - da[:, None] - db[None, :]
                    if aq.any() and at.any():
                        assert np.max(residual[np.ix_(aq, at)]) <= TOL
                    checks += 5
                assigned, a, b, _ = local
    save(OUT.parent / "development" / f"self_check_{attempt:02d}.json", {"status": "PASS",
        "assertions": checks, "sequential_cases": 360, "seconds": time.perf_counter() - begin,
        "main_sha256": prior.sha(Path(__file__)),
        "kernel_sha256": prior.sha(ROOT / "scripts/icde_dynamic_hungarian_20261110.py")})
    print("SELF_CHECK PASS", checks, flush=True)


def run_trace(graph, method, repeat):
    identities()
    out = OUT / "traces" / f"{graph}_{method}_r{repeat}"
    out.mkdir(parents=True, exist_ok=False)
    initial = prior.OUT / "scale" / (graph + "_15000")
    q, targets, pq, pt, qids, tids, basis = prior.data_for(graph, 15000)
    reference = prior.load(prior.OUT / "traces" / (graph + "_dense_cold_r0") / "result.json")
    with np.load(initial / "initial_solution.npz", allow_pickle=False) as state:
        assigned, a, b = state["assigned"].copy(), state["a"].copy(), state["b"].copy()
    setup = time.perf_counter()
    scores = np.load(initial / "scores.npy", mmap_mode="c")
    model = prior.MatchingModel.restore(initial / "initial_model.npz") if method == "highs_warm" else None
    dynamic = None
    if method == "dynamic_hungarian":
        prepare()
        dynamic = DynamicHungarian(assigned, a, b)
    costs = np.zeros((len(q), len(targets) + len(q))) if method == "dense_jv" else None
    setup_seconds = time.perf_counter() - setup
    old_aq, old_at = np.ones(len(q), dtype=bool), np.ones(len(targets), dtype=bool)
    records = []
    for step, name, qnew, tnew, cq, ct, aq, at in prior.workload(q, targets, pq, pt, graph, qids, tids):
        begin = time.perf_counter()
        pairs = prior.update_cache(scores, qnew, tnew, cq, ct)
        updated = time.perf_counter()
        previous = assigned.copy()
        if method == "highs_warm":
            provider = prior.Scores(qnew, tnew, scores)
            model.update(provider, cq, ct, aq, at)
            result = prior.complete(model, provider)
            assigned, a, b, info = result["assigned"], result["a"], result["b"], prior.compact(result)
        elif method == "dense_jv":
            assigned = dense_solution(scores, aq, at, costs)
            a, b, info = None, None, {"native": "SciPy 1.10.1 dense JV", "same_partial_matching_contract": True}
        elif method == "dynamic_hungarian":
            dirty_q = np.union1d(cq, np.flatnonzero(aq != old_aq))
            dirty_t = np.union1d(ct, np.flatnonzero(at != old_at))
            assigned, a, b, info = dynamic.update(scores, aq, at, dirty_q, dirty_t)
        else:
            assigned, a, b, info = region_repair(qnew, tnew, scores, assigned, a, b, cq, ct, old_aq, old_at, aq, at)
        elapsed = time.perf_counter() - begin
        check = validate(qnew, tnew, scores, assigned, a, b, aq, at,
            reference["records"][step]["result"]["objective"])
        record = {"status": "PASS", "step": step, "event": name, "seconds": elapsed,
            "score_update_seconds": updated - begin, "updated_score_pairs": pairs,
            "changed_sources": len(cq), "changed_targets": len(ct),
            "active_sources": int(aq.sum()), "active_targets": int(at.sum()),
            "matched_sources": int(np.count_nonzero(assigned >= 0)),
            "matching_changed_sources": int(np.count_nonzero(assigned != previous)),
            "solver": info, "validation": check,
            "rss_end_bytes": psutil.Process().memory_info().rss}
        save(out / f"event_{step:02d}.json", record)
        arrays = {"assigned": assigned}
        if a is not None:
            arrays.update(a=a, b=b)
        prior.save_npz(out / f"solution_{step:02d}.npz", **arrays)
        records.append(record)
        old_aq, old_at = aq.copy(), at.copy()
        print(graph, method, repeat, step, name, f"{elapsed:.3f}s", flush=True)
    save(out / "result.json", {"status": "PASS", "graph": graph, "method": method,
        "repeat": repeat, "setup_seconds": setup_seconds,
        "maintenance_seconds": sum(r["seconds"] for r in records), "records": records,
        "setup_plus_8_seconds": setup_seconds + sum(r["seconds"] for r in records)})
    if model is not None:
        model.h.clear()
    del scores, costs, model, dynamic
    gc.collect()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("self_check", "freeze", "trace"))
    parser.add_argument("--graph", choices=prior.GRAPHS)
    parser.add_argument("--method", choices=METHODS)
    parser.add_argument("--repeat", type=int, default=0)
    parser.add_argument("--attempt", type=int, default=1)
    args = parser.parse_args()
    if args.phase == "self_check":
        self_check(args.attempt)
    elif args.phase == "freeze":
        freeze()
    else:
        run_trace(args.graph, args.method, args.repeat)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
