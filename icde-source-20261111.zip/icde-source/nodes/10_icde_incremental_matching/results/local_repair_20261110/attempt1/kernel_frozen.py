"""Compiled reference implementation of standard batch dynamic Hungarian repair.

The algorithm follows Mills-Tettey, Stentz and Dias (2007), Fig. 5 and its
multiple-row/column extension. This is a reimplementation, not author software.
Dummy vertices reduce maximum-weight partial matching to perfect assignment.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / ".runtime/icde_local_repair_deps_20261110"))
from numba import njit


@njit(inline="always")
def edge_cost(scores, active_q, active_t, row, col):
    if row < scores.shape[0] and col < scores.shape[1]:
        if active_q[row] and active_t[col]:
            return -scores[row, col]
        return 2.0
    return 0.0


@njit(cache=True)
def repair(scores, active_q, active_t, changed_rows, changed_cols, assigned, inverse, u, v):
    size = len(assigned)
    for row in changed_rows:
        col = assigned[row]
        if col >= 0:
            inverse[col] = -1
            assigned[row] = -1
    for col in changed_cols:
        row = inverse[col]
        if row >= 0:
            assigned[row] = -1
            inverse[col] = -1
    for row in changed_rows:
        value = np.inf
        for col in range(size):
            value = min(value, edge_cost(scores, active_q, active_t, row, col) - v[col])
        u[row] = value
    for col in changed_cols:
        value = np.inf
        for row in range(size):
            value = min(value, edge_cost(scores, active_q, active_t, row, col) - u[row])
        v[col] = value

    roots = np.flatnonzero(assigned < 0)
    scanned_rows = 0
    explored = np.zeros(size, dtype=np.bool_)
    for root in roots:
        used = np.zeros(size, dtype=np.bool_)
        tree_rows = np.empty(size, dtype=np.int64)
        tree_rows[0] = root
        tree_count = 1
        slack = np.empty(size, dtype=np.float64)
        parent = np.full(size, root, dtype=np.int64)
        for col in range(size):
            slack[col] = edge_cost(scores, active_q, active_t, root, col) - u[root] - v[col]
        explored[root] = True
        scanned_rows += 1
        while True:
            best_col = -1
            delta = np.inf
            for col in range(size):
                if not used[col]:
                    value = slack[col]
                    if value < delta or (value == delta and inverse[col] < 0):
                        delta = value
                        best_col = col
            if best_col < 0 or delta < -1e-7:
                raise ValueError("dynamic Hungarian lost dual feasibility")
            for position in range(tree_count):
                u[tree_rows[position]] += delta
            for col in range(size):
                if used[col]:
                    v[col] -= delta
                else:
                    slack[col] -= delta
            used[best_col] = True
            if inverse[best_col] < 0:
                col = best_col
                while col >= 0:
                    row = parent[col]
                    previous_col = assigned[row]
                    assigned[row] = col
                    inverse[col] = row
                    col = previous_col
                break
            row = inverse[best_col]
            tree_rows[tree_count] = row
            tree_count += 1
            explored[row] = True
            scanned_rows += 1
            for col in range(size):
                if not used[col]:
                    value = edge_cost(scores, active_q, active_t, row, col) - u[row] - v[col]
                    if value < slack[col]:
                        slack[col] = value
                        parent[col] = row
    return len(roots), scanned_rows, int(explored[:scores.shape[0]].sum())


class DynamicHungarian:
    def __init__(self, assigned, a, b):
        self.n, self.m = len(a), len(b)
        size = self.n + self.m
        self.assigned = np.full(size, -1, dtype=np.int64)
        self.inverse = np.full(size, -1, dtype=np.int64)
        used_targets = np.zeros(self.m, dtype=bool)
        for row, col in enumerate(assigned):
            if col >= 0:
                self.assigned[row] = col
                self.assigned[self.n + col] = self.m + row
                used_targets[col] = True
            else:
                self.assigned[row] = self.m + row
        for col in np.flatnonzero(~used_targets):
            self.assigned[self.n + col] = col
        self.inverse[self.assigned] = np.arange(size)
        self.u = np.r_[-np.asarray(a), np.zeros(self.m)]
        self.v = np.r_[-np.asarray(b), np.zeros(self.n)]

    def update(self, scores, active_q, active_t, changed_rows, changed_cols):
        roots, scans, explored = repair(scores, active_q, active_t,
            np.asarray(changed_rows, dtype=np.int64), np.asarray(changed_cols, dtype=np.int64),
            self.assigned, self.inverse, self.u, self.v)
        assigned = self.assigned[:self.n].copy()
        assigned[assigned >= self.m] = -1
        real = assigned >= 0
        objective = float(scores[np.flatnonzero(real), assigned[real]].sum())
        if np.any(real):
            dummy_u = float(np.max(self.u[self.n:]))
            dummy_v = float(np.max(self.v[self.m:]))
            if abs(dummy_u + dummy_v) > 1e-7:
                raise AssertionError("dummy potential normalization")
            a = np.maximum(-self.u[:self.n] - dummy_v, 0)
            b = np.maximum(-self.v[:self.m] - dummy_u, 0)
        else:
            a, b = np.zeros(self.n), np.zeros(self.m)
        a[~active_q], b[~active_t] = 0, 0
        return assigned, a, b, {"objective": objective, "unmatched_roots": roots,
            "scanned_rows_with_repetitions": scans, "distinct_explored_real_rows": explored,
            "implicit_edge_relaxations": scans * (self.n + self.m)}


def prepare():
    scores = np.ones((2, 3), dtype=np.float64)
    solver = DynamicHungarian(np.array([0, 1]), np.ones(2), np.zeros(3))
    solver.update(scores, np.ones(2, dtype=bool), np.ones(3, dtype=bool), np.array([0]), np.array([1]))
