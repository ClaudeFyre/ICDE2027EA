"""Executable query-algebra and planner-contract glue (ICDE manuscript Sec. 3-4).

This module is the code form of ``papers/icde/QUERY_ALGEBRA_CONTRACT.md``.
It deliberately adds *only thin adapters* over the existing operators:

* :class:`VersionedQueryRecord` -- the frozen versioned result record (Sec. 4.2);
* :class:`QueryContract` -- the query contract that drives planning (Sec. 4.2);
* :func:`threshold_query` -- the ``Threshold(tau, theta)`` physical operator;
* :func:`risk_aware_top_k` -- the ``RiskAwareTopK(k, alpha)`` physical operator;
* :func:`batch_alignment` -- the ``BatchAlignment(S, k, tau, budget)`` operator;
* :func:`distributional_eligibility` -- the four-gate planner decision
  (revision -> validation -> cost -> fallback) for the inherited
  distributional operator.

It does **not** reimplement the Hoeffding / empirical-Bernstein bounds
(``pkgea.query.engine``), the progressive top-k loop, the mmap storage layer
(``pkgea.query.mmap_scores``), or the planner cost model
(``pkgea.query.planner``). Those are reused verbatim.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Hashable, Mapping, Sequence

import numpy as np

from pkgea.query.engine import (
    CandidateInterval,
    ProgressiveQueryResult,
    _intervals,
    progressive_top_k_from_dense_scores,
)

# Planner cost model shared with pkgea.query.planner.choose_execution_plan:
#   distributional_cost(uncertain_edges, candidate_count)
# This is the single cost formula the manuscript quotes as 6,547.11 units
# (992 uncertain edges * log2(97 candidates) on the seed-17 OpenEA probe).
DISTRIBUTIONAL_OPERATOR = "distributional_low_rank"
FALLBACK_OPERATOR = "adaptive_sampling"


def distributional_cost(uncertain_edges: int, candidate_count: int) -> float:
    """Abstract cost units for the inherited distributional operator."""

    if uncertain_edges <= 0 or candidate_count <= 0:
        raise ValueError("uncertain_edges and candidate_count must be positive")
    return float(uncertain_edges) * math.log2(candidate_count + 1)


# ---------------------------------------------------------------------------
# Frozen query contract and versioned result record (Sec. 4.2)
# ---------------------------------------------------------------------------

_ALLOWED_STATUS = {"stable", "unstable", "budget_exhausted"}


@dataclass(frozen=True)
class QueryContract:
    """The contract that drives planning, verbatim from Sec. 4.2."""

    query_entity: Hashable
    frozen_candidate_set: tuple[Hashable, ...]
    latency_budget: float
    accuracy_target: float
    resource_limit: float
    allowed_operator_set: frozenset[str]

    def __post_init__(self) -> None:
        if self.latency_budget <= 0 or self.accuracy_target <= 0:
            raise ValueError("latency_budget and accuracy_target must be positive")
        if self.resource_limit <= 0:
            raise ValueError("resource_limit must be positive")
        if not self.frozen_candidate_set:
            raise ValueError("frozen_candidate_set must be non-empty")


@dataclass(frozen=True)
class VersionedQueryRecord:
    """The single versioned record every operator returns (Sec. 4.2)."""

    winner: Hashable | None
    status: str
    confidence_evidence: float
    estimated_error: float
    world_count: int
    edge_count: int
    encoder_evaluations: int
    wall_time: float
    peak_ram_bytes: int
    peak_vram_bytes: int
    operator_version: str
    probability_model_version: str
    dataset_revision: str

    def __post_init__(self) -> None:
        if self.status not in _ALLOWED_STATUS:
            raise ValueError(f"status must be one of {sorted(_ALLOWED_STATUS)}")

    def as_dict(self) -> dict[str, object]:
        return {
            "winner": str(self.winner) if self.winner is not None else None,
            "status": self.status,
            "confidence_evidence": self.confidence_evidence,
            "estimated_error": self.estimated_error,
            "world_count": self.world_count,
            "edge_count": self.edge_count,
            "encoder_evaluations": self.encoder_evaluations,
            "wall_time": self.wall_time,
            "peak_ram_bytes": self.peak_ram_bytes,
            "peak_vram_bytes": self.peak_vram_bytes,
            "operator_version": self.operator_version,
            "probability_model_version": self.probability_model_version,
            "dataset_revision": self.dataset_revision,
        }

    @staticmethod
    def from_progressive(
        result: ProgressiveQueryResult,
        *,
        dataset_revision: str,
        edge_count: int,
        wall_time: float,
        peak_ram_bytes: int = 0,
        peak_vram_bytes: int = 0,
        operator_version: str = "progressive-sampling-v1",
        probability_model_version: str = "hoeffding-eb-v1",
    ) -> "VersionedQueryRecord":
        """Project a progressive result onto the frozen versioned record.

        ``stable`` is preserved verbatim; a non-stable run that exhausted the
        world prefix is reported as ``budget_exhausted`` (a legitimate result,
        never relabelled ``stable``).
        """

        winner = result.top_k[0].candidate if result.top_k else None
        kth_lower = result.top_k[-1].lower if result.top_k else 0.0
        outside_best = 1.0
        status = "stable" if result.stable else "budget_exhausted"
        estimated_error = float(
            np.mean(
                [
                    interval.upper - interval.estimate
                    for interval in result.top_k
                ]
            )
        )
        return VersionedQueryRecord(
            winner=winner,
            status=status,
            confidence_evidence=float(kth_lower),
            estimated_error=estimated_error,
            world_count=int(result.samples_used),
            edge_count=int(edge_count),
            encoder_evaluations=int(result.samples_used),
            wall_time=float(wall_time),
            peak_ram_bytes=int(peak_ram_bytes),
            peak_vram_bytes=int(peak_vram_bytes),
            operator_version=operator_version,
            probability_model_version=probability_model_version,
            dataset_revision=dataset_revision,
        )


# ---------------------------------------------------------------------------
# Threshold(tau, theta) -- q(c; tau) = Pr_w[S_w(c) >= tau]
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ThresholdResult:
    accepted: tuple[CandidateInterval, ...]
    rejected_certified: tuple[CandidateInterval, ...]
    inconclusive: tuple[CandidateInterval, ...]
    theta: float

    def as_dict(self) -> dict[str, object]:
        return {
            "theta": self.theta,
            "accepted": [item.candidate for item in self.accepted],
            "rejected_certified": [
                item.candidate for item in self.rejected_certified
            ],
            "inconclusive": [item.candidate for item in self.inconclusive],
        }


def threshold_query(
    world_scores: np.ndarray | Sequence[Sequence[float]],
    candidates: Sequence[Hashable],
    *,
    tau: float,
    theta: float,
    delta: float = 0.05,
    bound_method: str = "empirical_bernstein",
) -> ThresholdResult:
    """Accept candidates whose estimated pass-probability q-hat >= theta.

    Guarantee (Table I): a candidate whose (1-delta) CI *upper* bound is below
    theta is certified rejected and never returned as accepted. This is a
    thin wrapper: the per-world threshold indicator 1{S_w(c) >= tau} is fed to
    the same interval machinery as the progressive bounds.
    """

    matrix = np.asarray(world_scores, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[1] != len(candidates):
        raise ValueError("world_scores must be [worlds, candidates]")
    if not 0.0 <= tau <= 1.0 or not 0.0 < theta <= 1.0:
        raise ValueError("tau in [0,1] and theta in (0,1] required")
    indicator = (matrix >= tau).astype(np.float64)
    sums = {
        candidate: float(indicator[:, position].sum())
        for position, candidate in enumerate(candidates)
    }
    squared_sums = {
        candidate: float((indicator[:, position] ** 2).sum())
        for position, candidate in enumerate(candidates)
    }
    intervals = _intervals(
        sums,
        int(matrix.shape[0]),
        delta,
        squared_sums=squared_sums,
        bound_method=bound_method,
    )
    accepted = tuple(item for item in intervals if item.estimate >= theta)
    rejected = tuple(item for item in intervals if item.upper < theta)
    inconclusive = tuple(
        item for item in intervals if item not in accepted and item not in rejected
    )
    return ThresholdResult(
        accepted=accepted,
        rejected_certified=rejected,
        inconclusive=inconclusive,
        theta=theta,
    )


# ---------------------------------------------------------------------------
# RiskAwareTopK(k, alpha) -- R(c; alpha) = CVaR_alpha(rank_w(c))
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RiskAwareCandidate:
    candidate: Hashable
    cvar_rank: float
    mean_rank: float


@dataclass(frozen=True)
class RiskAwareTopKResult:
    top_k: tuple[RiskAwareCandidate, ...]
    alpha: float

    def as_dict(self) -> dict[str, object]:
        return {
            "alpha": self.alpha,
            "top_k": [
                {
                    "candidate": str(item.candidate),
                    "cvar_rank": item.cvar_rank,
                    "mean_rank": item.mean_rank,
                }
                for item in self.top_k
            ],
        }


def risk_aware_top_k(
    world_scores: np.ndarray | Sequence[Sequence[float]],
    candidates: Sequence[Hashable],
    *,
    k: int,
    alpha: float = 0.95,
) -> RiskAwareTopKResult:
    """Rank candidates by tail-risk R(c; alpha) = mean of the worst (1-alpha) ranks.

    rank_w(c) = 1 + #{c' : S_w(c') > S_w(c)} per world; R is the average of the
    top (1-alpha) fraction of observed ranks (largest = worst). Returns the k
    candidates minimizing R (risk-averse ordering on the observed prefix).
    """

    matrix = np.asarray(world_scores, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[1] != len(candidates):
        raise ValueError("world_scores must be [worlds, candidates]")
    if not 0 < k <= len(candidates):
        raise ValueError("k must be in [1, len(candidates)]")
    if not 0.0 <= alpha < 1.0:
        raise ValueError("alpha must be in [0, 1)")
    # Strict per-world rank: 1 + number of candidates strictly better.
    ranks = 1.0 + (matrix[:, None, :] > matrix[:, :, None]).sum(axis=2)
    mean_rank = ranks.mean(axis=0)
    worst_count = max(1, int(math.ceil((1.0 - alpha) * matrix.shape[0])))
    # CVaR = average of the largest worst_count ranks per candidate.
    partitioned = np.partition(ranks, kth=matrix.shape[0] - worst_count, axis=0)
    cvar_rank = partitioned[matrix.shape[0] - worst_count :, :].mean(axis=0)
    order = sorted(
        range(len(candidates)),
        key=lambda position: (cvar_rank[position], str(candidates[position])),
    )
    top = tuple(
        RiskAwareCandidate(
            candidate=candidates[position],
            cvar_rank=float(cvar_rank[position]),
            mean_rank=float(mean_rank[position]),
        )
        for position in order[:k]
    )
    return RiskAwareTopKResult(top_k=top, alpha=alpha)


# ---------------------------------------------------------------------------
# BatchAlignment(S, k, tau, budget) -- shared world matrix across sources
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class BatchAlignmentResult:
    per_source: tuple[ProgressiveQueryResult, ...]
    stable_count: int
    budget_exhausted_count: int
    total_samples_used: int

    def as_dict(self) -> dict[str, object]:
        return {
            "per_source": [item.as_dict() for item in self.per_source],
            "stable_count": self.stable_count,
            "budget_exhausted_count": self.budget_exhausted_count,
            "total_samples_used": self.total_samples_used,
        }


def batch_alignment(
    dense_by_source: Mapping[Hashable, np.ndarray | Sequence[Sequence[float]]],
    candidates: Sequence[Hashable],
    *,
    k: int,
    delta: float = 0.05,
    batch_size: int = 32,
    bound_method: str = "empirical_bernstein",
) -> BatchAlignmentResult:
    """Run progressive TopK for a source set over one shared world-score matrix.

    Each source slice is [worlds, candidates]; the world prefix (and therefore
    the backbone cost) is shared across sources. This is the physical
    BatchAlignment operator guarantee from Table I.
    """

    results = []
    for source, matrix in dense_by_source.items():
        results.append(
            progressive_top_k_from_dense_scores(
                matrix,
                source,
                candidates,
                k=k,
                batch_size=batch_size,
                delta=delta,
                cache_reused=True,
                bound_method=bound_method,
            )
        )
    stable = sum(1 for item in results if item.stable)
    exhausted = len(results) - stable
    return BatchAlignmentResult(
        per_source=tuple(results),
        stable_count=stable,
        budget_exhausted_count=exhausted,
        total_samples_used=sum(item.samples_used for item in results),
    )


# ---------------------------------------------------------------------------
# Four-gate distributional eligibility (revision -> validation -> cost -> fallback)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EligibilityDecision:
    authorized: bool
    operator: str
    estimated_cost: float
    estimated_error: float
    failed_gate: str | None
    reason: str

    def as_dict(self) -> dict[str, object]:
        return {
            "authorized": self.authorized,
            "operator": self.operator,
            "estimated_cost": self.estimated_cost,
            "estimated_error": self.estimated_error,
            "failed_gate": self.failed_gate,
            "reason": self.reason,
        }


def load_artifact_metadata(artifact_path: str | Path) -> dict[str, object]:
    """Read the stored validation metadata of a learned low-rank artifact."""

    with np.load(Path(artifact_path).resolve(), allow_pickle=False) as data:
        metadata = json.loads(str(data["metadata"].item()))
    required = ("dataset_id", "validation_mean_relative_distance_error")
    missing = [key for key in required if key not in metadata]
    if missing:
        raise ValueError(f"artifact metadata missing fields: {missing}")
    return metadata


def distributional_eligibility(
    *,
    artifact_metadata: Mapping[str, object],
    expected_dataset_revision: str,
    accuracy_target: float,
    latency_budget: float,
    uncertain_edges: int,
    candidate_count: int,
) -> EligibilityDecision:
    """Decide whether the inherited distributional operator may be used.

    Gates are evaluated in order; the first failure routes to the fallback.
    The stored validation error is read *from the artifact* -- a caller cannot
    override artifact evidence with a smaller error.

    1. **revision** -- ``dataset_id`` must equal the query's expected revision.
    2. **validation** -- stored ``validation_mean_relative_distance_error`` must
       be within ``accuracy_target``.
    3. **cost** -- :func:`distributional_cost` must not exceed ``latency_budget``.
    4. **fallback** -- any failed gate routes to ``adaptive_sampling``.
    """

    error = float(artifact_metadata["validation_mean_relative_distance_error"])
    cost = distributional_cost(uncertain_edges, candidate_count)

    observed_revision = str(artifact_metadata.get("dataset_id", ""))
    if observed_revision != expected_dataset_revision:
        return EligibilityDecision(
            authorized=False,
            operator=FALLBACK_OPERATOR,
            estimated_cost=cost,
            estimated_error=error,
            failed_gate="revision",
            reason=(
                f"artifact dataset revision {observed_revision!r} != expected "
                f"{expected_dataset_revision!r}; stale artifact rejected."
            ),
        )
    if not (0.0 <= error <= accuracy_target):
        return EligibilityDecision(
            authorized=False,
            operator=FALLBACK_OPERATOR,
            estimated_cost=cost,
            estimated_error=error,
            failed_gate="validation",
            reason=(
                f"stored validation error {error:.6g} exceeds accuracy target "
                f"{accuracy_target:.6g}; caller cannot override artifact evidence."
            ),
        )
    if cost > latency_budget:
        return EligibilityDecision(
            authorized=False,
            operator=FALLBACK_OPERATOR,
            estimated_cost=cost,
            estimated_error=error,
            failed_gate="cost",
            reason=(
                f"estimated cost {cost:.2f} units exceeds latency budget "
                f"{latency_budget:.2f}; validation alone cannot waive budget."
            ),
        )
    return EligibilityDecision(
        authorized=True,
        operator=DISTRIBUTIONAL_OPERATOR,
        estimated_cost=cost,
        estimated_error=error,
        failed_gate=None,
        reason=(
            f"revision matches, stored error {error:.6g} <= target "
            f"{accuracy_target:.6g}, cost {cost:.2f} <= budget "
            f"{latency_budget:.2f}."
        ),
    )
