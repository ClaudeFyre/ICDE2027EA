"""Multi-scale end-to-end workload evaluation (ICDE node-05, batch 1).

Runs through scripts/safe_run.py. Reuses the persisted OpenEA probe32
score tensor ``openea_probe32_score_cache_2048_s17.mmap-v3`` (2048 x 32 x 32,
float32) as its input -- it does NOT retrain the backbone or score new worlds.

Feasible scale grid (bounded by the persisted tensor):
  world prefixes  = {512, 1024, 2048}   (tensor max world height is 2048)
  candidate scope = {8, 16, 32}         (tensor has 32 targets)
  sources         = first 8 (probe convention)
  bound families  = {hoeffding, empirical_bernstein}

For each (worlds x candidates) cell x family we measure end-to-end per-query
latency (median, p95), warm throughput (queries/s), Python-heap peak RAM
(tracemalloc), winner agreement against a high-budget full-2048-world Monte
Carlo reference, the budget_exhausted (unstable) ratio, tensor construction cost
(dense materialization), and update cost (stale-digest rejection + rebuild).

cold = first load / first rectangle materialization in this process; the OS page
cache is NOT dropped, so this is not a true OS cold-page-fault test (that is the
separate planned experiment in manuscript Sec. 7.2).
"""

from __future__ import annotations

import json
import statistics
import time
import tracemalloc
from pathlib import Path

import numpy as np

from pkgea.query import (
    MemoryMappedScoreIndex,
    progressive_top_k_from_dense_scores,
)

ROOT = Path(__file__).resolve().parents[1]
MMAP_DIR = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "openea_probe32_score_cache_2048_s17.mmap-v3"
)
OUTPUT = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "icde_workload_e2e_2026-10-08.json"
)

WORLD_SCALES = [512, 1024, 2048]
CANDIDATE_SCALES = [8, 16, 32]
FAMILIES = ["hoeffding", "empirical_bernstein"]
SOURCE_COUNT = 8
WARM_REPEATS = 3
K = 1
DELTA = 0.05
BATCH = 32


def pct(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, int(round(q * (len(ordered) - 1)))))
    return ordered[idx]


def main() -> int:
    started_all = time.perf_counter()
    index = MemoryMappedScoreIndex.load(MMAP_DIR, verify_checksum=False)
    good_world = index.metadata["world_digest"]
    total_worlds, n_sources, n_targets = index.scores.shape
    sources = list(index.sources[:SOURCE_COUNT])
    targets_all = list(index.targets)

    report: dict[str, object] = {
        "format": "pkgea-icde-workload-e2e-v1",
        "date": "2026-10-08",
        "input_mmap_directory": str(MMAP_DIR),
        "input_shape": [int(total_worlds), int(n_sources), int(n_targets)],
        "reused_input": (
            "Reuses persisted 2048x32x32 float32 mmap score tensor; no new "
            "backbone scoring / no new worlds computed. World dims are prefixes "
            "of the 2048-world prefix; candidate dims are prefixes of the 32 "
            "targets. Scales 64 candidates and 4096 worlds are NOT reachable "
            "from this probe tensor (honest limitation)."
        ),
        "cold_definition": (
            "First load / first rectangle materialization in-process; OS page "
            "cache not dropped (true cold page-fault is a separate planned "
            "experiment, manuscript Sec. 7.2)."
        ),
        "world_scales": WORLD_SCALES,
        "candidate_scales": CANDIDATE_SCALES,
        "families": FAMILIES,
        "source_count": SOURCE_COUNT,
        "k": K,
        "delta": DELTA,
        "cells": [],
    }

    # High-budget reference winner per (candidate_scale): argmax of the full
    # 2048-world mean over the candidate prefix, for every source.
    reference_winner: dict[int, dict[str, int]] = {}
    for c_scale in CANDIDATE_SCALES:
        candidates = targets_all[:c_scale]
        full = index.rectangle(sources, candidates)  # [2048, 8, C]
        means = full.mean(axis=0)  # [8, C]
        reference_winner[c_scale] = {
            source: int(np.argmax(means[s]))
            for s, source in enumerate(sources)
        }

    for c_scale in CANDIDATE_SCALES:
        candidates = targets_all[:c_scale]
        for w_scale in WORLD_SCALES:
            # ---- construction cost: cold dense materialization for the cell --
            t0 = time.perf_counter()
            cold_dense = index.rectangle(sources, candidates, world_stop=w_scale)
            cold_build_seconds = time.perf_counter() - t0
            cold_dense = np.asarray(cold_dense, dtype=np.float64)

            # ---- update cost: stale-digest rejection latency + rebuild -------
            t0 = time.perf_counter()
            try:
                MemoryMappedScoreIndex.load(
                    MMAP_DIR, expected_world_digest="0" * 64,
                    verify_checksum=False,
                )
                stale_rejection_seconds = float("nan")
            except ValueError:
                stale_rejection_seconds = time.perf_counter() - t0
            t0 = time.perf_counter()
            rebuild = np.asarray(
                index.rectangle(sources, candidates, world_stop=w_scale)
            )
            rebuild_seconds = time.perf_counter() - t0
            del rebuild, cold_dense

            for family in FAMILIES:
                per_query_latencies: list[float] = []
                stable_count = 0
                query_count = 0
                winner_hits = 0
                tracemalloc.start()
                peak_python_bytes = 0
                for rep in range(WARM_REPEATS):
                    for s, source in enumerate(sources):
                        dense = np.asarray(
                            index.rectangle(
                                (source,), candidates, world_stop=w_scale
                            )[:, 0, :],
                            dtype=np.float64,
                        )
                        t0 = time.perf_counter()
                        res = progressive_top_k_from_dense_scores(
                            dense,
                            source,
                            candidates,
                            k=K,
                            batch_size=BATCH,
                            delta=DELTA,
                            cache_reused=True,
                            bound_method=family,
                        )
                        per_query_latencies.append(time.perf_counter() - t0)
                        if rep == 0:
                            query_count += 1
                            if res.stable:
                                stable_count += 1
                            top_idx = candidates.index(res.top_k[0].candidate)
                            if top_idx == reference_winner[c_scale][source]:
                                winner_hits += 1
                        cur_peak = tracemalloc.get_traced_memory()[1]
                        peak_python_bytes = max(peak_python_bytes, cur_peak)
                tracemalloc.stop()

                median_lat = statistics.median(per_query_latencies)
                p95_lat = pct(per_query_latencies, 0.95)
                total_rep_seconds = sum(per_query_latencies)
                n_measurements = len(per_query_latencies)
                throughput = n_measurements / total_rep_seconds
                cell = {
                    "worlds": w_scale,
                    "candidates": c_scale,
                    "family": family,
                    "median_query_latency_seconds": median_lat,
                    "p95_query_latency_seconds": p95_lat,
                    "min_query_latency_seconds": min(per_query_latencies),
                    "throughput_queries_per_second": throughput,
                    "peak_python_heap_bytes": int(peak_python_bytes),
                    "stable_queries": stable_count,
                    "budget_exhausted_queries": query_count - stable_count,
                    "budget_exhausted_ratio": (query_count - stable_count)
                    / max(query_count, 1),
                    "winner_agreement_vs_full2048_ref": winner_hits
                    / max(query_count, 1),
                    "construction_dense_build_seconds": cold_build_seconds,
                    "update_stale_rejection_seconds": stale_rejection_seconds,
                    "update_rebuild_seconds": rebuild_seconds,
                    "query_measurements": n_measurements,
                }
                report["cells"].append(cell)
                print(
                    f"w={w_scale:5d} c={c_scale:2d} {family:18s} "
                    f"median={median_lat*1e3:8.3f}ms p95={p95_lat*1e3:8.3f}ms "
                    f"qps={throughput:9.1f} agree={winner_hits}/{query_count} "
                    f"exhausted={query_count-stable_count}/{query_count}"
                )

    index.close()
    report["total_elapsed_seconds"] = time.perf_counter() - started_all
    if OUTPUT.exists():
        raise SystemExit(f"refusing to overwrite existing output: {OUTPUT}")
    OUTPUT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"wrote {OUTPUT} in {report['total_elapsed_seconds']:.1f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
