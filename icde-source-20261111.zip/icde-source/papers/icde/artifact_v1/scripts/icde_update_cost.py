"""Update-cost ladder: digest rejection vs cache rebuild vs backbone re-score.

ICDE node-05, round-2 batch, task E. Launched via scripts/safe_run.py.

After one real revision (a fact / confidence change invalidates the cached
score tensor), serving a query can fail at three very different cost points:

  (a) **digest rejection** -- opening the mmap with a wrong expected world
      digest raises before any score page is read;
  (b) **cache rebuild** -- re-materializing the dense working rectangle from
      the (still valid) mmap tensor;
  (c) **backbone full re-score** -- the inherited attribute+structure backbone
      must re-evaluate its score function for every possible world, because the
      graph itself changed.

This script measures all three on the seed-17 OpenEA probe (32 sources x
32 targets, 256 uncertain edges, 2048 Monte-Carlo worlds). The backbone
recompute path is verified to reproduce the persisted mmap scores (max abs
error ~ float32 rounding), so the measured time is a genuine re-score, not a
stub.

Output: nodes/05_icde_query_engine/results/icde_update_cost_2026-10-08.json
"""

from __future__ import annotations

import json
import statistics
import time
import tracemalloc
from pathlib import Path

import numpy as np

from pkgea.backbones.attribute import AttributeStructuralBackbone
from pkgea.query.engine import WorldCache
from pkgea.query.mmap_scores import MemoryMappedScoreIndex

ROOT = Path(__file__).resolve().parents[1]
MMAP_DIR = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "openea_probe32_score_cache_2048_s17.mmap-v3"
)
WORLD_CACHE = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "openea_probe32_world_cache_2048_s17.json"
)
# Canonical probe dataset that produced the persisted score tensor (32x32,
# 256 edges, attribute backbone). Verified: recomputed scores match mmap.
DATASET_DIR = ROOT / "data" / "interim" / "openea-d-w-15k-probe32-attributes-s17"
OUTPUT = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "icde_update_cost_2026-10-08.json"
)

REPEATS = 5


def median_ms(values: list[float]) -> float:
    return statistics.median(values) * 1e3


def main() -> int:
    started_all = time.perf_counter()
    index = MemoryMappedScoreIndex.load(MMAP_DIR, verify_checksum=False)
    good_world_digest = index.metadata["world_digest"]
    sources = list(index.sources)
    targets = list(index.targets)
    total_worlds = index.scores.shape[0]

    # ---- (a) stale-digest rejection ---------------------------------------
    reject_lat: list[float] = []
    for _ in range(REPEATS):
        t0 = time.perf_counter()
        try:
            MemoryMappedScoreIndex.load(
                MMAP_DIR,
                expected_world_digest="0" * 64,
                verify_checksum=False,
            )
            raise AssertionError("stale digest was not rejected")
        except ValueError:
            reject_lat.append(time.perf_counter() - t0)

    # ---- (b) cache rebuild: re-materialize the dense rectangle ------------
    rebuild_lat: list[float] = []
    for _ in range(REPEATS):
        t0 = time.perf_counter()
        dense = np.asarray(
            index.rectangle(sources, targets), dtype=np.float64
        )
        rebuild_lat.append(time.perf_counter() - t0)
        del dense

    # ---- (c) backbone full re-score --------------------------------------
    # Load worlds (the exact 2048-world prefix the tensor was built from).
    world_cache = WorldCache.load(WORLD_CACHE)
    worlds = world_cache._cache[list(world_cache._cache.keys())[0]]
    if len(worlds) != total_worlds:
        raise RuntimeError("world cache length does not match tensor")

    # Timing and tracemalloc are kept SEPARATELY: tracemalloc adds ~10-15x
    # overhead to allocation-heavy Python loops (verified on the progressive
    # loop: 4 ms -> 48 ms), so the timed rescore must run with tracemalloc OFF.
    t0 = time.perf_counter()
    backbone = AttributeStructuralBackbone.from_dataset(DATASET_DIR)
    backbone_build_seconds = time.perf_counter() - t0

    # Verify recompute fidelity against the persisted tensor.
    row0 = backbone.score(worlds[0].state)
    mm_row0 = index.scores[0]
    maxerr = max(
        abs(row0[(s, t)] - float(mm_row0[si, ti]))
        for si, s in enumerate(sources)
        for ti, t in enumerate(targets)
    )

    # Warmup (untimed) so the timed loop is not cold.
    for world in worlds:
        backbone.score(world.state)

    # Timed rescore (no tracemalloc running).
    t0 = time.perf_counter()
    checksum = 0.0
    for world in worlds:
        matrix = backbone.score(world.state)
        checksum += sum(matrix.values())
    backbone_rescore_seconds = time.perf_counter() - t0

    # Peak memory measured in a SEPARATE traced pass (untimed).
    tracemalloc.start()
    for world in worlds:
        backbone.score(world.state)
    rescore_peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    build_peak = rescore_peak  # backbone is already built; same heap order

    index.close()

    reject_ms = median_ms(reject_lat)
    rebuild_ms = median_ms(rebuild_lat)
    rescore_ms = backbone_rescore_seconds * 1e3
    build_ms = backbone_build_seconds * 1e3

    report = {
        "format": "pkgea-icde-update-cost-v1",
        "date": "2026-10-08",
        "mmap_directory": str(MMAP_DIR),
        "dataset_dir": str(DATASET_DIR),
        "probe_scope": {
            "worlds": total_worlds,
            "sources": len(sources),
            "targets": len(targets),
            "edges": len(worlds[0].state),
            "backbone": "attribute",
        },
        "fidelity_check": {
            "max_abs_error_recomputed_vs_mmap": float(maxerr),
            "note": "float32 rounding; recomputed backbone scores reproduce the persisted tensor.",
        },
        "stale_digest_rejection": {
            "median_ms": reject_ms,
            "all_reject_latencies_ms": [v * 1e3 for v in reject_lat],
            "meaning": "expected_world_digest mismatch raises before any score page is read.",
        },
        "cache_rebuild_materialize": {
            "median_ms": rebuild_ms,
            "all_rebuild_latencies_ms": [v * 1e3 for v in rebuild_lat],
            "meaning": "np.asarray(index.rectangle(full 2048x32x32)) from the warm mmap.",
        },
        "backbone_full_rescore": {
            "backbone_construction_ms": build_ms,
            "full_2048_worlds_rescore_ms": rescore_ms,
            "per_world_us": rescore_ms * 1e3 / total_worlds,
            "peak_python_heap_bytes": int(rescore_peak),
            "construction_peak_python_heap_bytes": int(build_peak),
            "checksum": checksum,
        },
        "comparison": {
            "rescore_over_rebuild_x": (
                backbone_rescore_seconds / statistics.median(rebuild_lat)
            ),
            "rescore_over_reject_x": (
                backbone_rescore_seconds / statistics.median(reject_lat)
            ),
        },
        "extrapolation_caveat": (
            "These are probe-scale numbers (32x32, 256 edges, 2048 worlds). "
            "Backbone re-score cost scales with (edges x worlds x source-target "
            "pairs); at full OpenEA 15K/100K scale the recompute is expected to "
            "be many seconds to minutes, not 0.7s. The cache rebuild and digest "
            "rejection costs are memory-bound and scale far more gently with "
            "tensor bytes than with graph size."
        ),
        "total_elapsed_seconds": time.perf_counter() - started_all,
    }
    print(
        f"digest reject median={reject_ms:.3f}ms  rebuild median={rebuild_ms:.3f}ms  "
        f"backbone rescore={rescore_ms:.1f}ms ({build_ms:.1f}ms build, "
        f"{rescore_ms*1e3/total_worlds:.1f} us/world)  maxerr={maxerr:.2e}"
    )
    if OUTPUT.exists():
        raise SystemExit(f"refusing to overwrite existing output: {OUTPUT}")
    OUTPUT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"wrote {OUTPUT} in {report['total_elapsed_seconds']:.1f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
