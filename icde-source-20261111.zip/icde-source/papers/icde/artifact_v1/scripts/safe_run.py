"""Run exactly one task with Windows memory, disk, and concurrency guards."""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / ".runtime"
LOCK_PATH = RUNTIME / "safe-run.lock"


class MemoryStatusEx(ctypes.Structure):
    _fields_ = [
        ("dwLength", wintypes.DWORD),
        ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


class JobObjectBasicLimitInformation(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_longlong),
        ("PerJobUserTimeLimit", ctypes.c_longlong),
        ("LimitFlags", wintypes.DWORD),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", wintypes.DWORD),
        ("SchedulingClass", wintypes.DWORD),
    ]


class IoCounters(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_ulonglong),
        ("WriteOperationCount", ctypes.c_ulonglong),
        ("OtherOperationCount", ctypes.c_ulonglong),
        ("ReadTransferCount", ctypes.c_ulonglong),
        ("WriteTransferCount", ctypes.c_ulonglong),
        ("OtherTransferCount", ctypes.c_ulonglong),
    ]


class JobObjectExtendedLimitInformation(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", JobObjectBasicLimitInformation),
        ("IoInfo", IoCounters),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


JOB_OBJECT_EXTENDED_LIMIT_INFORMATION = 9
JOB_OBJECT_LIMIT_JOB_MEMORY = 0x00000200
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def system_memory() -> tuple[int, int]:
    if os.name != "nt":
        raise RuntimeError("safe_run currently requires Windows")
    status = MemoryStatusEx()
    status.dwLength = ctypes.sizeof(status)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise ctypes.WinError()
    return int(status.ullTotalPhys), int(status.ullAvailPhys)


def process_exists(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        process_query_limited_information = 0x1000
        still_active = 259
        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.restype = wintypes.HANDLE
        handle = kernel32.OpenProcess(
            process_query_limited_information, False, pid
        )
        if not handle:
            return False
        try:
            exit_code = wintypes.DWORD()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                raise ctypes.WinError()
            return int(exit_code.value) == still_active
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_lock(task_id: str) -> int:
    RUNTIME.mkdir(parents=True, exist_ok=True)
    for _ in range(2):
        try:
            descriptor = os.open(
                LOCK_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY
            )
            os.write(
                descriptor,
                json.dumps(
                    {"pid": os.getpid(), "task_id": task_id, "started": utc_now()}
                ).encode("utf-8"),
            )
            return descriptor
        except FileExistsError:
            try:
                owner = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
                owner_pid = int(owner["pid"])
            except (OSError, ValueError, KeyError, json.JSONDecodeError):
                owner_pid = -1
            if owner_pid > 0 and process_exists(owner_pid):
                raise RuntimeError(
                    f"another safe task is active: pid={owner_pid}"
                )
            LOCK_PATH.unlink(missing_ok=True)
    raise RuntimeError("could not acquire the single-task lock")


def release_lock(descriptor: int) -> None:
    os.close(descriptor)
    LOCK_PATH.unlink(missing_ok=True)


def create_memory_job(limit_bytes: int) -> int:
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateJobObjectW.restype = wintypes.HANDLE
    handle = kernel32.CreateJobObjectW(None, None)
    if not handle:
        raise ctypes.WinError()
    limits = JobObjectExtendedLimitInformation()
    limits.BasicLimitInformation.LimitFlags = (
        JOB_OBJECT_LIMIT_JOB_MEMORY | JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    )
    limits.JobMemoryLimit = limit_bytes
    if not kernel32.SetInformationJobObject(
        handle,
        JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
        ctypes.byref(limits),
        ctypes.sizeof(limits),
    ):
        kernel32.CloseHandle(handle)
        raise ctypes.WinError()
    return int(handle)


def assign_to_job(job_handle: int, process: subprocess.Popen[bytes]) -> None:
    if not ctypes.windll.kernel32.AssignProcessToJobObject(
        wintypes.HANDLE(job_handle), wintypes.HANDLE(process._handle)
    ):
        raise ctypes.WinError()


def query_peak_job_memory(job_handle: int) -> int:
    limits = JobObjectExtendedLimitInformation()
    if not ctypes.windll.kernel32.QueryInformationJobObject(
        wintypes.HANDLE(job_handle),
        JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
        ctypes.byref(limits),
        ctypes.sizeof(limits),
        None,
    ):
        raise ctypes.WinError()
    return int(limits.PeakJobMemoryUsed)


def close_job(job_handle: int) -> None:
    ctypes.windll.kernel32.CloseHandle(wintypes.HANDLE(job_handle))


def write_json_atomic(path: Path, value: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        dir=path.parent, prefix=f".{path.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temporary, path)
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def load_profile(name: str) -> dict[str, float | int | str]:
    profiles = json.loads(
        (ROOT / "configs" / "resource_profiles.json").read_text(
            encoding="utf-8"
        )
    )
    if name not in profiles:
        raise ValueError(f"unknown resource profile: {name}")
    return profiles[name]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument(
        "--profile", choices=("local16", "cpu64", "gpu32"), required=True
    )
    parser.add_argument("--expected-output", action="append", default=[])
    parser.add_argument("--max-runtime-minutes", type=float, default=720.0)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        raise ValueError("one command is required after --")
    if args.max_runtime_minutes <= 0:
        raise ValueError("max-runtime-minutes must be positive")
    task_id = args.task_id
    if not task_id.replace("-", "").replace("_", "").isalnum():
        raise ValueError("task-id must contain only letters, digits, - or _")

    expected = [(ROOT / path).resolve() for path in args.expected_output]
    if expected and all(path.exists() for path in expected):
        print(
            json.dumps(
                {
                    "task_id": task_id,
                    "status": "skipped_existing_outputs",
                    "outputs": [str(path) for path in expected],
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0
    existing = [path for path in expected if path.exists()]
    if existing:
        raise ValueError(
            "partial expected outputs exist; audit before rerun: "
            + ", ".join(str(path) for path in existing)
        )

    profile = load_profile(args.profile)
    gibibyte = 1024**3
    max_job_bytes = int(float(profile["max_job_memory_gb"]) * gibibyte)
    min_memory_bytes = int(
        float(profile["minimum_free_memory_gb"]) * gibibyte
    )
    min_disk_bytes = int(float(profile["minimum_free_disk_gb"]) * gibibyte)
    total_memory, free_memory = system_memory()
    free_disk = shutil.disk_usage(ROOT).free
    if free_memory < min_memory_bytes:
        raise RuntimeError(
            f"preflight free memory {free_memory / gibibyte:.2f} GB is below "
            f"{min_memory_bytes / gibibyte:.2f} GB"
        )
    if free_disk < min_disk_bytes:
        raise RuntimeError(
            f"preflight free disk {free_disk / gibibyte:.2f} GB is below "
            f"{min_disk_bytes / gibibyte:.2f} GB"
        )

    lock_descriptor = acquire_lock(task_id)
    log_path = RUNTIME / "logs" / f"{task_id}.log"
    run_path = RUNTIME / "runs" / f"{task_id}.json"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    existing_python_path = environment.get("PYTHONPATH", "")
    environment["PYTHONPATH"] = str(ROOT / "src") + (
        os.pathsep + existing_python_path if existing_python_path else ""
    )
    threads = str(int(profile["threads"]))
    for name in (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
    ):
        environment[name] = threads
    environment["TOKENIZERS_PARALLELISM"] = "false"
    environment.setdefault(
        "PYTORCH_CUDA_ALLOC_CONF",
        "expandable_segments:True,max_split_size_mb:128",
    )
    started = time.monotonic()
    started_at = utc_now()
    job_handle = 0
    process: subprocess.Popen[bytes] | None = None
    reason = "process_exit"
    minimum_observed_free_memory = free_memory
    minimum_observed_free_disk = free_disk
    try:
        job_handle = create_memory_job(max_job_bytes)
        with log_path.open("wb") as log:
            process = subprocess.Popen(
                command,
                cwd=ROOT,
                env=environment,
                stdout=log,
                stderr=subprocess.STDOUT,
            )
            try:
                assign_to_job(job_handle, process)
            except BaseException:
                process.kill()
                process.wait()
                raise
            deadline = started + args.max_runtime_minutes * 60.0
            while process.poll() is None:
                time.sleep(float(profile["poll_seconds"]))
                _, free_memory = system_memory()
                free_disk = shutil.disk_usage(ROOT).free
                minimum_observed_free_memory = min(
                    minimum_observed_free_memory, free_memory
                )
                minimum_observed_free_disk = min(
                    minimum_observed_free_disk, free_disk
                )
                if free_memory < min_memory_bytes:
                    reason = "free_memory_floor"
                    process.terminate()
                    break
                if free_disk < min_disk_bytes:
                    reason = "free_disk_floor"
                    process.terminate()
                    break
                if time.monotonic() > deadline:
                    reason = "runtime_limit"
                    process.terminate()
                    break
            try:
                return_code = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                return_code = process.wait()
                reason += "_forced_kill"
        peak_job_memory = query_peak_job_memory(job_handle)
        missing_outputs = [str(path) for path in expected if not path.exists()]
        status = (
            "completed"
            if return_code == 0 and not missing_outputs and reason == "process_exit"
            else "failed"
        )
        record: dict[str, object] = {
            "format": "pkgea-safe-run-v1",
            "task_id": task_id,
            "profile": args.profile,
            "profile_values": profile,
            "status": status,
            "reason": reason,
            "command": command,
            "started_at": started_at,
            "finished_at": utc_now(),
            "elapsed_seconds": time.monotonic() - started,
            "return_code": return_code,
            "total_physical_memory_gb": total_memory / gibibyte,
            "peak_job_memory_gb": peak_job_memory / gibibyte,
            "minimum_observed_free_memory_gb": (
                minimum_observed_free_memory / gibibyte
            ),
            "minimum_observed_free_disk_gb": (
                minimum_observed_free_disk / gibibyte
            ),
            "expected_outputs": [str(path) for path in expected],
            "missing_outputs": missing_outputs,
            "log_path": str(log_path),
        }
        write_json_atomic(run_path, record)
        print(json.dumps(record, ensure_ascii=False, indent=2))
        return 0 if status == "completed" else 1
    finally:
        if job_handle:
            close_job(job_handle)
        release_lock(lock_descriptor)


if __name__ == "__main__":
    sys.exit(main())
