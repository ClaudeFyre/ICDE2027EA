"""Build the 64-candidate x 4096-world score tensor for the ICDE full grid.

ICDE node-05, task 1. Launched via scripts/safe_run.py.

Design (honest provenance):
  * The world stream is extended from the EXISTING seed-17 OpenEA probe
    (2048 worlds, 256 uncertain edges). We reload the exact probability vector,
    seed=17, independent edges (shock=0) that produced the persisted world cache,
    then call monte_carlo_worlds(..., 4096). The first 2048 states are byte-identical
    to the persisted 2048-world prefix (verified: world digest f98d8c...); the last
    2048 (worlds index 2048..4095) are newly sampled from the same generator.
  * The graph stays d1's 256-edge graph, so the structural (degree) scores for the
    original 32x32 block are unchanged. We extend the TARGET (candidate) side from
    32 to 64 by grafting 32 real wikidata train-anchor targets (with attributes)
    from the sibling seed-17 probe `openea-d-w-probe-q32-a64-attributes`. The
    first 32 targets are d1's original test targets in original order; sources are
    d1's original 32 test sources in original order.
  * Known effect (measured & reported): recomputing the TF-IDF attribute vector
    pool over 96 query entities (vs 64 in d1) shifts the attribute component of
    the original 32x32 block slightly. The structural component is identical.
    This drift is quantified against the persisted mmap-v3 block and recorded.

Outputs:
  * dataset: data/interim/openea-d-w-probe64-ext4096-s17/  (new, does not touch d1)
  * mmap:    nodes/05_icde_query_engine/results/openea_probe64_score_cache_4096_s17.mmap-v1/
  * report:  nodes/05_icde_query_engine/results/icde_probe64_tensor_build_2026-10-08.json
"""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pkgea.backbones.attribute import AttributeStructuralBackbone  # noqa: E402
from pkgea.contracts import validate_dataset  # noqa: E402
from pkgea.query.engine import WorldCache, ScoreCache  # noqa: E402
from pkgea.query.mmap_scores import MemoryMappedScoreIndex  # noqa: E402
from pkgea.samplers import monte_carlo_worlds  # noqa: E402

D1 = ROOT / "data/interim/openea-d-w-15k-probe32-attributes-s17"
D2 = ROOT / "data/interim/openea-d-w-probe-q32-a64-attributes"
EXT = ROOT / "data/interim/openea-d-w-probe64-ext4096-s17"
WC2048 = ROOT / "nodes/05_icde_query_engine/results/openea_probe32_world_cache_2048_s17.json"
OLD_MMAP = ROOT / "nodes/05_icde_query_engine/results/openea_probe32_score_cache_2048_s17.mmap-v3"
OUT_MMAP = ROOT / "nodes/05_icde_query_engine/results/openea_probe64_score_cache_4096_s17.mmap-v1"
OUT_REPORT = ROOT / "nodes/05_icde_query_engine/results/icde_probe64_tensor_build_2026-10-08.json"

NEW_TARGET_COUNT = 32
TOTAL_WORLDS = 4096
EXPECTED_OLD_WORLD_DIGEST = "f98d8c024771d8f63502cc8b9e27fa369003931e17daf375d314b02e3222980d"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as h:
        return list(csv.DictReader(h, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as h:
        w = csv.DictWriter(h, delimiter="\t", fieldnames=fieldnames, lineterminator="\n")
        w.writeheader()
        for row in rows:
            w.writerow(row)


def sha256_file(path: Path) -> str:
    d = hashlib.sha256()
    with path.open("rb") as h:
        for chunk in iter(lambda: h.read(1 << 20), b""):
            d.update(chunk)
    return d.hexdigest()


def build_extended_probe() -> dict:
    if EXT.exists():
        raise SystemExit(f"refusing to overwrite existing probe dir: {EXT}")
    EXT.mkdir(parents=True)

    # Verbatim structural files from d1 (keeps the 256-edge world graph identical).
    for name in ("triples.tsv", "relations.tsv"):
        shutil.copyfile(D1 / name, EXT / name)

    d1_entities = read_tsv(D1 / "entities.tsv")
    d1_attributes = read_tsv(D1 / "attributes.tsv")
    d1_alignments = read_tsv(D1 / "alignments.tsv")

    d2_entities = read_tsv(D2 / "entities.tsv")
    d2_attributes = read_tsv(D2 / "attributes.tsv")
    d2_alignments = read_tsv(D2 / "alignments.tsv")

    d1_target_ids = [r["target_entity_id"] for r in d1_alignments]
    d1_source_ids = [r["source_entity_id"] for r in d1_alignments]

    # Choose NEW_TARGET_COUNT train-anchor wikidata targets from d2 that are not
    # already d1's test targets and carry attributes.
    train_targets = []
    seen = set()
    for r in d2_alignments:
        if r["split"] != "train":
            continue
        tid = r["target_entity_id"]
        if tid in set(d1_target_ids) or tid in seen:
            continue
        seen.add(tid)
        train_targets.append(tid)
    extra = train_targets[:NEW_TARGET_COUNT]
    assert len(extra) == NEW_TARGET_COUNT, f"only {len(extra)} extra targets available"

    d2_entity_rows = {r["entity_id"]: r for r in d2_entities}
    d2_attr_by_entity: dict[str, list[dict[str, str]]] = {}
    for r in d2_attributes:
        d2_attr_by_entity.setdefault(r["entity_id"], []).append(r)

    # Entities: d1's + 32 new target entities (graph_id=target).
    new_entity_rows = []
    for tid in extra:
        src = d2_entity_rows[tid]
        new_entity_rows.append({
            "graph_id": "target",
            "entity_id": tid,
            "label": src["label"],
        })
    all_entities = d1_entities + new_entity_rows
    write_tsv(EXT / "entities.tsv", all_entities,
              ["graph_id", "entity_id", "label"])

    # Attributes: d1's + the new targets' attributes (graph_id=target).
    new_attr_rows = []
    for tid in extra:
        for r in d2_attr_by_entity.get(tid, []):
            new_attr_rows.append({
                "graph_id": "target",
                "entity_id": tid,
                "attribute_id": r["attribute_id"],
                "value": r["value"],
            })
    all_attributes = d1_attributes + new_attr_rows
    write_tsv(EXT / "attributes.tsv", all_attributes,
              ["graph_id", "entity_id", "attribute_id", "value"])

    # Alignments: d1's 32 rows verbatim + 32 rows pairing new targets with the
    # existing 32 sources (cycling). This keeps source_entities = d1's 32.
    new_alignment_rows = []
    for i, tid in enumerate(extra):
        new_alignment_rows.append({
            "source_entity_id": d1_source_ids[i % len(d1_source_ids)],
            "target_entity_id": tid,
            "split": "train",
            "confidence": "1",
        })
    all_alignments = d1_alignments + new_alignment_rows
    write_tsv(EXT / "alignments.tsv", all_alignments,
              ["source_entity_id", "target_entity_id", "split", "confidence"])

    # Metadata: adapt d1's.
    meta = json.loads((D1 / "confidence_metadata.json").read_text(encoding="utf-8"))
    meta["dataset_id"] = "openea-d-w-probe64-ext4096-s17"
    meta["generation"]["note"] = (
        "Extended target side from 32 to 64 by grafting 32 seed-17 train-anchor "
        "wikidata targets; triples/world graph identical to the 256-edge "
        "probe32 seed-17 probe; worlds extended 2048->4096 with the same seed."
    )
    (EXT / "confidence_metadata.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    report = validate_dataset(EXT)
    return {
        "validation": report.as_dict(),
        "extra_targets": extra,
        "new_attribute_rows": len(new_attr_rows),
        "source_count": len(set(r["source_entity_id"] for r in all_alignments)),
        "target_count": len([r for r in all_entities if r["graph_id"] == "target"]),
    }


def main() -> int:
    t_all = time.perf_counter()
    built = build_extended_probe()

    # ---- World stream: reload exact (prob, seed, groups, shock) from d1 cache.
    wc = WorldCache.load(WC2048)
    key = list(wc._cache.keys())[0]
    probabilities, seed, groups, shock = key
    persisted_2048 = wc._cache[key]
    assert len(probabilities) == 256 and seed == 17

    regen_2048 = monte_carlo_worlds(probabilities, 2048, seed, dependency_groups=groups,
                                    common_shock_probability=shock)
    new_worlds = monte_carlo_worlds(probabilities, TOTAL_WORLDS, seed,
                                    dependency_groups=groups,
                                    common_shock_probability=shock)
    d_persist = ScoreCache._world_digest(persisted_2048)
    d_regen2048 = ScoreCache._world_digest(regen_2048)
    d_4096 = ScoreCache._world_digest(new_worlds)
    if d_regen2048 != EXPECTED_OLD_WORLD_DIGEST or d_persist != EXPECTED_OLD_WORLD_DIGEST:
        raise SystemExit(f"world-prefix digest mismatch: {d_regen2048}")
    prefix_ok = all(a.state == b.state for a, b in zip(new_worlds, regen_2048))
    if not prefix_ok:
        raise SystemExit("first-2048-of-4096 does not match persisted prefix")

    # ---- Backbone over the extended probe.
    t0 = time.perf_counter()
    backbone = AttributeStructuralBackbone.from_dataset(EXT)
    build_s = time.perf_counter() - t0
    sources = backbone.source_entities
    targets = backbone.target_entities
    if len(sources) != 32 or len(targets) != 64:
        raise SystemExit(f"unexpected scope: {len(sources)} sources, {len(targets)} targets")

    # ---- Score all worlds into the tensor.
    shape = (TOTAL_WORLDS, len(sources), len(targets))
    score_path = OUT_MMAP / "scores.npy"
    if OUT_MMAP.exists():
        raise SystemExit(f"refusing to overwrite existing mmap dir: {OUT_MMAP}")
    OUT_MMAP.mkdir(parents=True)
    array = np.lib.format.open_memmap(score_path, mode="w+", dtype=np.float32,
                                      shape=shape)
    t0 = time.perf_counter()
    for wi, world in enumerate(new_worlds):
        matrix = backbone.score(world.state)
        for si, s in enumerate(sources):
            for ti, t in enumerate(targets):
                array[wi, si, ti] = matrix[(s, t)]
    array.flush()
    score_seconds = time.perf_counter() - t0
    npy_digest_before = sha256_file(score_path)
    del array

    # ---- Write metadata first, then open the read-only index for verification.
    metadata = {
        "format": MemoryMappedScoreIndex.FORMAT,
        "dtype": "float32",
        "shape": list(shape),
        "context_digest": "unversioned",
        "world_digest": d_4096,
        "backbone_id": "attribute",
        "sources": list(sources),
        "targets": list(targets),
        "scores_file": "scores.npy",
        "scores_sha256": npy_digest_before,
    }
    (OUT_MMAP / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    # ---- Fidelity check: independent recompute on a sampled subset of cells.
    index = MemoryMappedScoreIndex.load(OUT_MMAP, verify_checksum=False)
    rng = np.random.default_rng(123)
    check_cells = rng.integers(0, TOTAL_WORLDS, size=40)
    max_err = 0.0
    for wi in check_cells:
        recomputed = backbone.score(new_worlds[wi].state)
        for si, s in enumerate(sources):
            for ti, t in enumerate(targets):
                err = abs(recomputed[(s, t)] - float(index.scores[wi, si, ti]))
                max_err = max(max_err, err)

    # ---- Drift check vs old mmap-v3 block on the original 32x32, first 2048.
    old = MemoryMappedScoreIndex.load(OLD_MMAP, verify_checksum=False)
    old_sources = list(old.sources)
    old_targets = list(old.targets)
    # Old scope must match the first-32 of the new scope.
    sources_match = [str(s) for s in sources[:32]] == old_sources
    targets_match = [str(t) for t in targets[:32]] == old_targets
    drift_max = None
    if sources_match and targets_match:
        old_block = np.asarray(old.scores[:2048, :, :32], dtype=np.float64)
        new_block = np.asarray(index.scores[:2048, :32, :32], dtype=np.float64)
        drift_max = float(np.max(np.abs(old_block - new_block)))
    old.close()

    report = {
        "format": "pkgea-icde-probe64-tensor-build-v1",
        "date": "2026-10-08",
        "output_mmap_dir": str(OUT_MMAP),
        "shape": list(shape),
        "dtype": "float32",
        "context_digest": "unversioned",
        "world_digest_4096": d_4096,
        "old_2048_world_digest": EXPECTED_OLD_WORLD_DIGEST,
        "world_prefix_verified": d_regen2048 == EXPECTED_OLD_WORLD_DIGEST and prefix_ok,
        "new_worlds_range": [2048, 4096],
        "extended_probe_dir": str(EXT),
        "extended_probe_validation": built["validation"],
        "extra_targets_grafted": built["extra_targets"],
        "source_count": built["source_count"],
        "target_count": built["target_count"],
        "fidelity_recomputed_vs_written": {
            "sampled_worlds": 40,
            "max_abs_error": float(max_err),
            "note": "independent backbone.score() recompute on sampled cells vs stored float32.",
        },
        "drift_vs_old_mmap_v3": {
            "sources_match_first32": sources_match,
            "targets_match_first32": targets_match,
            "max_abs_error_first2048_first32x32_block": drift_max,
            "note": ("Original 32x32 block after re-pooling TF-IDF over 96 entities "
                     "vs the persisted 64-entity mmap-v3. Structural component unchanged."),
        },
        "build_timing": {
            "backbone_construction_seconds": build_s,
            "score_all_worlds_seconds": score_seconds,
            "per_world_ms": score_seconds / TOTAL_WORLDS * 1e3,
        },
        "total_elapsed_seconds": time.perf_counter() - t_all,
    }
    index.close()
    if OUT_REPORT.exists():
        raise SystemExit(f"refusing to overwrite existing report: {OUT_REPORT}")
    OUT_REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n",
                          encoding="utf-8")
    print(json.dumps({k: report[k] for k in (
        "shape", "world_digest_4096", "world_prefix_verified",
        "fidelity_recomputed_vs_written", "drift_vs_old_mmap_v3",
        "build_timing", "total_elapsed_seconds")}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
