"""Full-grid clean end-to-end workload (ICDE node-05, task 2).

Grid: worlds {512,1024,2048,4096} x candidates {8,16,32,64} x bound
{hoeffding, empirical_bernstein}, on the rebuilt 64-candidate x 4096-world
score tensor ``openea_probe64_score_cache_4096_s17.mmap-v1``.

CLEAN measurement (no tracemalloc):
  * timing uses time.perf_counter, median/p95 over repeated warm queries;
  * memory uses ctypes GetProcessMemoryInfo -> WorkingSetSize delta
    (process working-set growth, NOT tracemalloc traced heap). This is the
    honest, non-instrumented number. The prior ``icde_workload_e2e_2026-10-08``
    run kept tracemalloc on, which inflated per-query latency ~10x (verified
    4.08ms -> 48.2ms); relative conclusions are unchanged.

Per cell: e2e per-query latency (median, p95, min), warm throughput (queries/s),
peak working-set delta (bytes), winner agreement vs the high-budget full-4096
reference, median query-world observations consumed (samples_used), and the
stable / budget-exhausted ratio.

Output: nodes/05_icde_query_engine/results/icde_workload_e2e_fullgrid_2026-10-08.{json,md}
Launched via scripts/safe_run.py.
"""

from __future__ import annotations

import ctypes
import json
import statistics
import time
from ctypes import wintypes
from pathlib import Path

import numpy as np

from pkgea.query import MemoryMappedScoreIndex, progressive_top_k_from_dense_scores

ROOT = Path(__file__).resolve().parents[1]
MMAP_DIR = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "openea_probe64_score_cache_4096_s17.mmap-v1"
)
OUT_JSON = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "icde_workload_e2e_fullgrid_2026-10-08.json"
)
OUT_MD = OUT_JSON.with_suffix(".md")

WORLD_SCALES = [512, 1024, 2048, 4096]
CANDIDATE_SCALES = [8, 16, 32, 64]
FAMILIES = ["hoeffding", "empirical_bernstein"]
SOURCE_COUNT = 8
WARM_REPEATS = 5
K = 1
DELTA = 0.05
BATCH = 32


# ---- Working-set (RSS) measurement -------------------------------------------
class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def working_set_bytes() -> int:
    counters = PROCESS_MEMORY_COUNTERS()
    counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS)
    kernel32 = ctypes.windll.kernel32
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    handle = kernel32.GetCurrentProcess()
    psapi = ctypes.windll.psapi
    psapi.GetProcessMemoryInfo.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
    ]
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    ok = psapi.GetProcessMemoryInfo(
        handle, ctypes.byref(counters), counters.cb
    )
    if not ok:
        raise ctypes.WinError()
    return int(counters.WorkingSetSize)


def pct(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, int(round(q * (len(ordered) - 1)))))
    return ordered[idx]


def main() -> int:
    started_all = time.perf_counter()
    index = MemoryMappedScoreIndex.load(MMAP_DIR, verify_checksum=False)
    total_worlds, n_sources, n_targets = index.scores.shape
    sources_all = list(index.sources)
    targets_all = list(index.targets)
    sources = sources_all[:SOURCE_COUNT]
    assert total_worlds == 4096 and n_targets == 64 and n_sources == 32

    ws_baseline = working_set_bytes()

    # High-budget reference winner per candidate scale: argmax over the FULL
    # 4096-world mean, for each of the 8 sources.
    reference_winner: dict[int, dict[str, int]] = {}
    for c_scale in CANDIDATE_SCALES:
        candidates = targets_all[:c_scale]
        full = index.rectangle(sources, candidates)  # [4096, 8, C]
        means = full.mean(axis=0)  # [8, C]
        reference_winner[c_scale] = {
            source: int(np.argmax(means[s]))
            for s, source in enumerate(sources)
        }
        del full, means

    report: dict[str, object] = {
        "format": "pkgea-icde-workload-e2e-fullgrid-v1",
        "date": "2026-10-08",
        "input_mmap_directory": str(MMAP_DIR),
        "input_shape": [int(total_worlds), int(n_sources), int(n_targets)],
        "measurement_basis": (
            "CLEAN: no tracemalloc. Timing via time.perf_counter over repeated "
            "warm queries; median/p95/min. Memory via ctypes "
            "GetProcessMemoryInfo WorkingSetSize growth (process working-set "
            "delta, NOT tracemalloc traced heap)."
        ),
        "world_scales": WORLD_SCALES,
        "candidate_scales": CANDIDATE_SCALES,
        "families": FAMILIES,
        "source_count": SOURCE_COUNT,
        "k": K,
        "delta": DELTA,
        "batch_size": BATCH,
        "warm_repeats": WARM_REPEATS,
        "reference": "argmax over full 4096-world mean per (candidate_scale, source)",
        "cells": [],
    }

    for c_scale in CANDIDATE_SCALES:
        candidates = targets_all[:c_scale]
        for w_scale in WORLD_SCALES:
            # Warm the rectangle for this cell (page-cache warm).
            warm = np.asarray(
                index.rectangle(sources, candidates, world_stop=w_scale)
            )
            del warm

            for family in FAMILIES:
                ws_cell_start = working_set_bytes()
                ws_peak = ws_cell_start
                latencies: list[float] = []
                stable_count = 0
                query_count = 0
                winner_hits = 0
                observations: list[int] = []
                pruned_total = 0

                for rep in range(WARM_REPEATS):
                    for s, source in enumerate(sources):
                        dense = np.asarray(
                            index.rectangle(
                                (source,), candidates, world_stop=w_scale
                            )[:, 0, :],
                            dtype=np.float64,
                        )
                        t0 = time.perf_counter()
                        res = progressive_top_k_from_dense_scores(
                            dense,
                            source,
                            candidates,
                            k=K,
                            batch_size=BATCH,
                            delta=DELTA,
                            cache_reused=True,
                            bound_method=family,
                        )
                        lat = time.perf_counter() - t0
                        latencies.append(lat)
                        # Sample working set during the timed loop.
                        ws_now = working_set_bytes()
                        if ws_now > ws_peak:
                            ws_peak = ws_now
                        if rep == 0:
                            query_count += 1
                            if res.stable:
                                stable_count += 1
                            observations.append(res.samples_used)
                            pruned_total += res.pruned_candidates
                            top_idx = candidates.index(res.top_k[0].candidate)
                            if top_idx == reference_winner[c_scale][source]:
                                winner_hits += 1
                        del dense

                median_lat = statistics.median(latencies)
                p95_lat = pct(latencies, 0.95)
                total_rep = sum(latencies)
                n_meas = len(latencies)
                throughput = n_meas / total_rep
                ws_delta = ws_peak - ws_cell_start
                cell = {
                    "worlds": w_scale,
                    "candidates": c_scale,
                    "family": family,
                    "median_query_latency_seconds": median_lat,
                    "p95_query_latency_seconds": p95_lat,
                    "min_query_latency_seconds": min(latencies),
                    "throughput_queries_per_second": throughput,
                    "peak_workingset_delta_bytes": int(ws_delta),
                    "stable_queries": stable_count,
                    "budget_exhausted_queries": query_count - stable_count,
                    "budget_exhausted_ratio": (query_count - stable_count)
                    / max(query_count, 1),
                    "winner_agreement_vs_full4096_ref": winner_hits
                    / max(query_count, 1),
                    "median_observations_used": statistics.median(observations),
                    "mean_observations_used": statistics.mean(observations),
                    "max_observations_used": max(observations),
                    "query_measurements": n_meas,
                }
                report["cells"].append(cell)
                print(
                    f"w={w_scale:5d} c={c_scale:2d} {family:18s} "
                    f"med={median_lat*1e3:8.3f}ms p95={p95_lat*1e3:8.3f}ms "
                    f"qps={throughput:9.1f} agree={winner_hits}/{query_count} "
                    f"obs={statistics.median(observations):6.0f} "
                    f"stale={query_count-stable_count}/{query_count}"
                )

    index.close()
    report["peak_workingset_observed_delta_bytes"] = working_set_bytes() - ws_baseline
    report["total_elapsed_seconds"] = time.perf_counter() - started_all

    if OUT_JSON.exists():
        raise SystemExit(f"refusing to overwrite existing output: {OUT_JSON}")
    OUT_JSON.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    write_markdown(report)
    print(f"wrote {OUT_JSON} and {OUT_MD} in {report['total_elapsed_seconds']:.1f}s")
    return 0


def write_markdown(report: dict) -> None:
    lines: list[str] = []
    lines.append("# Full-grid clean e2e workload — ICDE node-05\n")
    lines.append(f"Date: {report['date']}. Machine: i9-14900K / 32 GB / 4090D, "
                 "launched via `scripts/safe_run.py`.\n")
    lines.append("## Measurement basis\n")
    lines.append(report["measurement_basis"] + "\n")
    lines.append(
        "\n**Relationship to the prior instrumented run "
        "(`icde_workload_e2e_2026-10-08`).** That run kept `tracemalloc` on "
        "through the timed loop, which inflated per-query latency ~10x "
        "(verified 4.08 ms -> 48.2 ms). The absolute latencies here are the "
        "CLEAN, un-instrumented numbers; the old file is retained as a "
        "historical instrumented run. The relative conclusions — empirical-"
        "Bernstein (EB) vs Hoeffding query-world observations saved, and "
        "winner fidelity — are expected to agree across both runs. Memory here "
        "is process WorkingSetSize growth, not the tracemalloc heap number "
        "reported before.\n")
    lines.append("\n## Input tensor\n")
    lines.append(f"- mmap dir: `{report['input_mmap_directory']}`\n")
    lines.append(f"- shape (worlds x sources x targets): {report['input_shape']}\n")
    lines.append(f"- world scales {report['world_scales']}, candidate scales "
                 f"{report['candidate_scales']}, families {report['families']}\n")
    lines.append("\n## Grid summary\n")
    lines.append("| worlds | cands | bound | median ms | p95 ms | qps | WS delta MB | winner agr | med obs | stable |\n")
    lines.append("|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|\n")
    for c in report["cells"]:
        lines.append(
            f"| {c['worlds']} | {c['candidates']} | {c['family']} | "
            f"{c['median_query_latency_seconds']*1e3:.3f} | "
            f"{c['p95_query_latency_seconds']*1e3:.3f} | "
            f"{c['throughput_queries_per_second']:.1f} | "
            f"{c['peak_workingset_delta_bytes']/1e6:.2f} | "
            f"{c['winner_agreement_vs_full4096_ref']:.2f} | "
            f"{c['median_observations_used']:.0f} | "
            f"{c['stable_queries']}/{8} |\n"
        )
    lines.append(f"\nTotal elapsed: {report['total_elapsed_seconds']:.1f} s.\n")
    OUT_MD.write_text("".join(lines), encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
