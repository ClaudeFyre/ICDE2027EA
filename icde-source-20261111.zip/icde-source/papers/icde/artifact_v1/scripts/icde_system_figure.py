"""Reproducible system-architecture figure for the ICDE PKG-EA manuscript (Fig. 1).

Renders the layered query engine from manuscript_v1.md Sec. 5 and the frozen
QUERY_ALGEBRA_CONTRACT.md:
  top        : four query interfaces (TopK / Threshold / RiskAwareTopK /
               BatchAlignment) wrapped in a QueryContract
  planner    : four gates in order (revision -> validation -> cost -> fallback);
               fallback routes to CertifiedLocalMCOperator (adaptive sampling)
  operators  : all eight frozen physical operators; DistributionalOperator is
               dashed, marked inherited (WWW companion), and drawn gated by the
               validation gate
  storage    : float32 mmap score tensor S[w,s,c], digest binding, rectangle read
  infra      : possible-world generator + backbone scorer; versioned-record loop

Layout is fully hard-coded (no auto-layout, no randomness) -> deterministic SVG+PNG.

Reproduce:
    python scripts/icde_system_figure.py
Outputs:
    papers/icde/figures/system_architecture.svg
    papers/icde/figures/system_architecture.png
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless, deterministic
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

# ---------------------------------------------------------------- reproducible
FIG_W_IN = 7.0   # IEEE double-column width (\textwidth)
FIG_H_IN = 7.6
DPI = 300        # >= 200 dpi print resolution

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 7.0,
    "svg.fonttype": "path",   # embed outlines -> portable SVG for IEEE
    "figure.facecolor": "white",
    "axes.facecolor": "white",
})

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "papers" / "icde" / "figures"
OUT_DIR.mkdir(parents=True, exist_ok=True)

fig = plt.figure(figsize=(FIG_W_IN, FIG_H_IN))
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 108)
ax.set_ylim(4, 100)
ax.set_axis_off()

# ------------------------------------------------------------------ palette
C_BOX_FC = "white"
C_BOX_EC = "#333333"
C_PLANNER_FC = "#E9EEF5"
C_STORE_FC = "#F0F0F0"
C_DIST_FC = "#FCF3DC"   # amber: flags the inherited operator
C_TEXT = "#111111"


def box(x, y, w, h, fc=C_BOX_FC, ec=C_BOX_EC, lw=0.9, dashed=False, title=None,
        title_size=7.2, sub_lines=None, sub_size=7.0, sub_gap=1.9):
    p = FancyBboxPatch((x, y), w, h,
                       boxstyle="round,pad=0.25,rounding_size=0.6",
                       fc=fc, ec=ec, lw=lw,
                       linestyle=(0, (4, 2)) if dashed else "solid")
    ax.add_patch(p)
    cx = x + w / 2
    if title is not None:
        ax.text(cx, y + h - 1.5, title, ha="center", va="center",
                fontsize=title_size, fontweight="bold", color=C_TEXT)
    if sub_lines:
        # stack sub lines downward from just under the title
        ly = y + h - 3.4
        for line in sub_lines:
            ax.text(cx, ly, line, ha="center", va="center",
                    fontsize=sub_size, color=C_TEXT)
            ly -= sub_gap
    return p


def container(x, y, w, h, fc, title_text, title_dy=1.7, title_size=7.6):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.2,rounding_size=0.8",
                       fc=fc, ec="#555555", lw=1.1)
    ax.add_patch(p)
    if title_text:
        ax.text(x + w / 2, y + h - title_dy, title_text, ha="center", va="center",
                fontsize=title_size, fontweight="bold", color=C_TEXT)


def arrow(x0, y0, x1, y1, dashed=False, lw=1.0, color="#1a1a1a"):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", lw=lw, color=color,
                                linestyle=(0, (4, 2)) if dashed else "solid",
                                shrinkA=0, shrinkB=0))


def hline(x0, x1, y, dashed=False, lw=1.0, color="#1a1a1a"):
    ax.plot([x0, x1], [y, y], lw=lw, color=color,
            linestyle=(0, (4, 2)) if dashed else "solid")


# ============================================================ LAYER 1: interfaces
box(4.0, 91.5, 21.5, 5.6, title="TopK", sub_lines=["μ̂, π̂ ranking"])
box(27.0, 91.5, 21.5, 5.6, title="Threshold", sub_lines=["(τ, θ); q̂ pass prob."])
box(50.0, 91.5, 21.5, 5.6, title="RiskAwareTopK",
    sub_lines=["(k, α); R̂ = CVaRα(rank)"])
box(73.0, 91.5, 21.5, 5.6, title="BatchAlignment", sub_lines=["(S, k, τ, budget)"])
ax.text(0.9, 94.3, "interfaces", ha="center", va="center", fontsize=7.0,
        style="italic", color="#444444", rotation=90)

# ------------------------------------------------------------ QueryContract
box(4.0, 85.4, 90.5, 5.4,
    title="QueryContract", title_size=7.8,
    sub_lines=["{ query_entity · frozen_candidate_set · latency_budget",
               "· accuracy_target · resource_limit · allowed_operator_set }"],
    sub_gap=1.7)
arrow(49.0, 91.5, 49.0, 90.9)

# ============================================================ LAYER 2: planner
container(4.0, 68.5, 90.5, 16.0, C_PLANNER_FC,
          "PLANNER — four gates in order; first failure routes to fallback")
arrow(49.0, 85.4, 49.0, 84.6)

box(4.0, 69.8, 21.5, 10.0, fc="white", title="① revision gate",
    sub_lines=["context / world digests", "must match expected", "revision;",
               "stale -> rejected"])
box(27.0, 69.8, 21.5, 10.0, fc="white", title="② validation gate",
    sub_lines=["stored val. error ≤", "accuracy_target;", "low-rank path",
               "eligible only here"])
box(50.0, 69.8, 21.5, 10.0, fc="white", title="③ cost gate",
    sub_lines=["cost = |E|·log₂(|C|+1)", "≤ latency_budget;",
               "budget cannot waive", "validation"])
box(73.0, 69.8, 21.5, 10.0, fc="white", title="④ fallback",
    sub_lines=["any gate failure ->", "CertifiedLocalMCOp.",
               "(adaptive candidate-", "wise MC sampling)"])
# gate chain
arrow(25.5, 75.2, 26.9, 75.2)
arrow(48.5, 75.2, 49.9, 75.2)
arrow(71.5, 75.2, 72.9, 75.2)
# fallback -> adaptive sampling (= ProgressiveSampling path)
arrow(84.0, 69.8, 84.0, 61.3)
ax.text(83.5, 62.6, "fallback -> adaptive sampling", fontsize=6.9, ha="right",
        va="center", color="#333333")

# ====================================================== LAYER 3: physical ops
container(4.0, 33.0, 90.5, 33.0, "white",
          "PHYSICAL OPERATOR LAYER — eight frozen operators (contract Table I)")
ax.text(0.9, 49.5, "operators", ha="center", va="center", fontsize=7.0,
        style="italic", color="#444444", rotation=90)

# Row A: data path chain
box(4.0, 54.5, 21.5, 6.6, title="ScanRectangle", title_size=7.0,
    sub_lines=["handle, ω,σ,γ ->", "dense ndarray[ω,σ,γ]"], sub_gap=1.8)
box(27.0, 54.5, 21.5, 6.6, title="MaterializePrefix(W_n)", title_size=7.0,
    sub_lines=["backbone rows w≤n,", "bound to world_digest"], sub_gap=1.8)
box(50.0, 54.5, 21.5, 6.6, title="RevisionBoundCacheLookup", title_size=7.0,
    sub_lines=["tensor handle or `stale`;", "no result on mismatch"], sub_gap=1.8)
box(73.0, 54.5, 21.5, 6.6, title="ProgressiveSampling", title_size=7.0,
    sub_lines=["(k, δ, emp.-Bernstein);", "exhausted ≠ stable"],
    sub_gap=1.8)
arrow(25.5, 57.8, 26.9, 57.8)
arrow(48.5, 57.8, 49.9, 57.8)
arrow(71.5, 57.8, 72.9, 57.8)

# Row B: terminal / alternative operators
box(4.0, 40.5, 21.5, 6.6, title="Threshold(τ, θ)",
    sub_lines=["reject if CI upper", "bound < θ"], sub_gap=1.8)
box(27.0, 40.5, 21.5, 6.6, fc=C_DIST_FC, dashed=True,
    title="DistributionalOperator",
    sub_lines=["inherited (WWW companion):", "low-rank / analytic index"],
    sub_gap=1.8)
box(50.0, 40.5, 21.5, 6.6, title="RiskAwareTopK(k, α)",
    sub_lines=["k smallest R̂ =", "CVaRα(rank)"], sub_gap=1.8)
box(73.0, 40.5, 21.5, 6.6, title="BatchAlignment",
    sub_lines=["(S, k, τ, budget);", "one matrix shared"], sub_gap=1.8)

# ProgressiveSampling fan-out to its three children
arrow(84.0, 54.5, 84.0, 51.6)
hline(84.0, 14.75, 51.6)
arrow(14.75, 51.4, 14.75, 47.3)   # Threshold
arrow(60.75, 51.4, 60.75, 47.3)   # RiskAwareTopK
arrow(84.0, 51.4, 84.0, 47.3)     # BatchAlignment

# validation gate -> DistributionalOperator (dashed, routed through the gap
# between the leftmost and second column so it crosses no box)
hline(28.0, 26.25, 69.8, dashed=True)
hline(26.25, 26.25, 43.8, dashed=True)
arrow(26.25, 43.8, 27.1, 43.8, dashed=True)
ax.text(26.25, 52.6, "gated", fontsize=6.9,
        ha="center", va="center", color="#7a5b00")

# ============================================================ LAYER 4: storage
container(4.0, 20.0, 90.5, 10.0, C_STORE_FC, "")
ax.text(5.6, 27.6,
        "SCORE-TENSOR STORAGE — float32 memory-mapped S[w, s, c], shape (W×S×C)",
        ha="left", va="center", fontsize=7.4, fontweight="bold")
ax.text(5.6, 24.9,
        "revision binding: context_digest · ordered world_digest list · scores_sha256 · "
        "backbone_id · scope",
        ha="left", va="center", fontsize=6.9)
ax.text(5.6, 22.4,
        "rectangle read rect(ω, σ, γ) · single-reader policy · shape-aware source batching",
        ha="left", va="center", fontsize=6.9)

# operators -> storage
for cx in (14.75, 37.75, 60.75, 84.0):
    arrow(cx, 40.5, cx, 30.3)

# ====================================================== LAYER 5: infrastructure
box(4.0, 8.0, 42.0, 7.0, fc=C_STORE_FC, title="Possible-world generator",
    sub_lines=["frozen Monte-Carlo prefix W", "(revisions change world_digest list)"])
box(52.5, 8.0, 42.0, 7.0, fc=C_STORE_FC, title="Backbone scorer",
    sub_lines=["attribute backbone;", "OpenEA D-W 15k probe"])
arrow(25.0, 15.0, 25.0, 19.8)
arrow(73.5, 15.0, 73.5, 19.8)
ax.text(30.0, 17.3, "MaterializePrefix(W_n) fills rows w≤n", fontsize=6.9,
        ha="left", va="center")

# ======================================== versioned-record loop (right margin)
hline(94.5, 99.0, 50.0, dashed=True)
hline(99.0, 99.0, 87.9, dashed=True)
arrow(99.0, 87.9, 94.8, 87.9, dashed=True)
ax.text(102.0, 66.0,
        "VersionedQueryRecord → caller\n"
        "winner · status ∈ {stable, unstable,\n"
        "budget_exhausted} · CI · samples\n"
        "wall_time · operator / model / revision",
        fontsize=6.9, ha="center", va="center", rotation=90, color="#333333",
        linespacing=1.5)

# ------------------------------------------------------------------ save
png_path = OUT_DIR / "system_architecture.png"
svg_path = OUT_DIR / "system_architecture.svg"
fig.savefig(png_path, dpi=DPI)
fig.savefig(svg_path)
print(f"PNG: {png_path}")
print(f"SVG: {svg_path}")
print(f"size: {FIG_W_IN}x{FIG_H_IN} in @ {DPI} dpi "
      f"= {int(FIG_W_IN*DPI)}x{int(FIG_H_IN*DPI)} px")
