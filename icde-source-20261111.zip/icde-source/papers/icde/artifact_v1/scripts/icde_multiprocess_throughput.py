"""Multi-process server throughput over one shared mmap score tensor.

ICDE node-05, round-2 batch, task D. Launched via scripts/safe_run.py (this
is itself one single experiment task; it internally spawns worker processes).

N in {1,2,4,8} worker processes (multiprocessing spawn) each independently
opens its OWN MemoryMappedScoreIndex handle to the SAME on-disk mmap tensor and
serves the same progressive top-k query loop. We measure aggregate throughput
(queries/s over the whole N-worker wall), per-worker median latency, the
speedup curve vs N=1, and peak process memory.

Honest expectation recorded in the output: on a single Windows host with one
shared page cache and a small 8 MB tensor, concurrency may give no speedup or
even negative speedup (GIL-free multiprocessing still contends on the shared
page cache / memory bus). The existing single-process reader-thread negative
result (0.25-0.35x) is cited as a cross-check.

Output: nodes/05_icde_query_engine/results/icde_multiprocess_throughput_2026-10-08.json
"""

from __future__ import annotations

import json
import multiprocessing as mp
import statistics
import time
import tracemalloc
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MMAP_DIR = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "openea_probe32_score_cache_2048_s17.mmap-v3"
)
OUTPUT = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "icde_multiprocess_throughput_2026-10-08.json"
)

WORKER_COUNTS = [1, 2, 4, 8]
WORLDS = 1024
CANDIDATES = 16
SOURCES = 8
QUERY_COUNT_PER_WORKER = 30
K = 1
DELTA = 0.05
BATCH = 32
FAMILY = "hoeffding"


def worker(
    rank: int,
    barrier: "mp.synchronize.Barrier",
    result_queue: "mp.Queue",
    mmap_dir: str,
    worlds: int,
    candidates: int,
    sources: int,
    query_count: int,
) -> None:
    """One spawned server worker: load mmap, warm up, then run timed queries."""
    import numpy as np  # noqa: PLC0415

    from pkgea.query.engine import progressive_top_k_from_dense_scores  # noqa
    from pkgea.query.mmap_scores import MemoryMappedScoreIndex  # noqa

    index = MemoryMappedScoreIndex.load(mmap_dir, verify_checksum=False)
    source_names = list(index.sources[:sources])
    candidate_names = list(index.targets[:candidates])

    # Warm-up (not timed): one materialize + progressive per worker.
    warm_dense = np.asarray(
        index.rectangle(
            (source_names[0],), candidate_names, world_stop=worlds
        )[:, 0, :],
        dtype=np.float64,
    )
    progressive_top_k_from_dense_scores(
        warm_dense,
        source_names[0],
        candidate_names,
        k=K,
        batch_size=BATCH,
        delta=DELTA,
        bound_method=FAMILY,
    )

    barrier.wait()  # all workers start their timed loop together
    latencies: list[float] = []
    winners: list[str] = []
    for i in range(query_count):
        source = source_names[i % len(source_names)]
        t0 = time.perf_counter()
        dense = np.asarray(
            index.rectangle(
                (source,), candidate_names, world_stop=worlds
            )[:, 0, :],
            dtype=np.float64,
        )
        res = progressive_top_k_from_dense_scores(
            dense,
            source,
            candidate_names,
            k=K,
            batch_size=BATCH,
            delta=DELTA,
            bound_method=FAMILY,
        )
        latencies.append(time.perf_counter() - t0)
        winners.append(str(res.top_k[0].candidate))
    index.close()
    result_queue.put(
        {
            "rank": rank,
            "latencies": latencies,
            "median_latency": statistics.median(latencies),
            "winners": winners,
        }
    )


def run_cell(n_workers: int) -> dict[str, object]:
    ctx = mp.get_context("spawn")
    barrier = ctx.Barrier(n_workers)
    queue: "mp.Queue" = ctx.Queue()
    started = time.perf_counter()
    procs = [
        ctx.Process(
            target=worker,
            args=(
                rank,
                barrier,
                queue,
                str(MMAP_DIR),
                WORLDS,
                CANDIDATES,
                SOURCES,
                QUERY_COUNT_PER_WORKER,
            ),
        )
        for rank in range(n_workers)
    ]
    for proc in procs:
        proc.start()
    results = [queue.get() for _ in range(n_workers)]
    for proc in procs:
        proc.join()
    wall = time.perf_counter() - started

    total_queries = n_workers * QUERY_COUNT_PER_WORKER
    all_latencies = [lat for r in results for lat in r["latencies"]]
    return {
        "workers": n_workers,
        "wall_seconds_including_worker_boot": wall,
        "total_queries": total_queries,
        "aggregate_queries_per_second": total_queries / wall,
        "per_worker_median_latency_seconds": [
            float(r["median_latency"]) for r in results
        ],
        "all_median_latency_seconds": statistics.median(all_latencies),
        "all_p95_latency_seconds": _pct(all_latencies, 0.95),
        "winner_fingerprint_consistent": len(
            {tuple(r["winners"]) for r in results}
        )
        == 1,
    }


def _pct(values: list[float], q: float) -> float:
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, int(round(q * (len(ordered) - 1)))))
    return ordered[idx]


def main() -> int:
    started_all = time.perf_counter()
    tracemalloc.start()
    report: dict[str, object] = {
        "format": "pkgea-icde-multiprocess-throughput-v1",
        "date": "2026-10-08",
        "mmap_directory": str(MMAP_DIR),
        "query_cell": {
            "worlds": WORLDS,
            "candidates": CANDIDATES,
            "sources": SOURCES,
            "bound_method": FAMILY,
            "k": K,
            "delta": DELTA,
            "queries_per_worker": QUERY_COUNT_PER_WORKER,
        },
        "note": (
            "Each worker opens its own mmap handle to the SAME on-disk tensor. "
            "Wall time includes multiprocessing spawn boot + mmap open. The "
            "per-query timed region covers rectangle materialization + "
            "progressive top-k."
        ),
        "expected_negative_bias": (
            "Single host, one OS page cache, small 8 MB tensor; expect little "
            "or negative speedup. Existing single-process reader-thread result "
            "was 0.25-0.35x (also a negative)."
        ),
        "cells": [],
    }

    baselines: dict[int, float] = {}
    for n in WORKER_COUNTS:
        cell = run_cell(n)
        baselines[n] = cell["aggregate_queries_per_second"]
        report["cells"].append(cell)
        print(
            f"workers={n} wall={cell['wall_seconds_including_worker_boot']:.2f}s "
            f"agg_qps={cell['aggregate_queries_per_second']:.2f} "
            f"median_lat={cell['all_median_latency_seconds']*1e3:.2f}ms"
        )

    base = baselines[WORKER_COUNTS[0]]
    for cell in report["cells"]:
        cell["speedup_vs_1_worker"] = cell["aggregate_queries_per_second"] / base
        cell["efficiency_percent"] = 100.0 * cell["speedup_vs_1_worker"] / cell["workers"]
    report["peak_python_heap_bytes"] = int(tracemalloc.get_traced_memory()[1])
    tracemalloc.stop()
    report["total_elapsed_seconds"] = time.perf_counter() - started_all
    if OUTPUT.exists():
        raise SystemExit(f"refusing to overwrite existing output: {OUTPUT}")
    OUTPUT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"wrote {OUTPUT} in {report['total_elapsed_seconds']:.1f}s")
    return 0


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)
    raise SystemExit(main())
