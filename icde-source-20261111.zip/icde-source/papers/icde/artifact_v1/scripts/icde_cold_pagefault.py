"""Cold page-fault vs warm re-touch latency for the mmap score tensor.

ICDE node-05, round-2 batch, task C. Launched via scripts/safe_run.py.

Windows has no safe user-mode way to drop the OS file cache (we deliberately do
NOT use RAMMap / NtSetSystemFileCacheSize), so "cold" here means: a FRESH
process opens the mmap and first-touches the requested rectangle. The backing
file may already be resident in the OS file cache, so the measured faults are
predominantly *soft* faults (mapping already-cached pages into the fresh
process's working set), not hard faults from disk. This limitation is recorded
in the output.

Method:
  * The parent (this script when run without --child) spawns N fresh
    ``python.exe`` child processes via subprocess (each is a brand-new
    process).
  * Each child imports numpy, takes a PageFaultCount baseline, opens the mmap
    (metadata only, checksum disabled), first-touches a rectangle (forces a
    read over every touched element), records the fault delta and latency,
    then touches the SAME rectangle again (warm) and records those.
  * Children print one JSON line; the parent aggregates median / p95 and the
    page-fault deltas.

Output: nodes/05_icde_query_engine/results/icde_cold_pagefault_2026-10-08.json
"""

from __future__ import annotations

import argparse
import ctypes
import json
import statistics
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MMAP_DIR = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "openea_probe32_score_cache_2048_s17.mmap-v3"
)
OUTPUT = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "icde_cold_pagefault_2026-10-08.json"
)

# Rectangle configs: world_stop prefix of the 2048x32x32 float32 tensor.
RECTS = {
    "full_2048x32x32": 2048,
    "half_1024x32x32": 1024,
    "quarter_512x32x32": 512,
}
FRESH_CHILD_RUNS = 5


class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def read_mem_counters() -> dict[str, int]:
    ctypes.windll.kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    ctypes.windll.psapi.GetProcessMemoryInfo.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(PROCESS_MEMORY_COUNTERS),
        wintypes.DWORD,
    ]
    ctypes.windll.psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    handle = ctypes.windll.kernel32.GetCurrentProcess()
    counters = PROCESS_MEMORY_COUNTERS()
    counters.cb = ctypes.sizeof(counters)
    if not ctypes.windll.psapi.GetProcessMemoryInfo(
        handle, ctypes.byref(counters), counters.cb
    ):
        raise ctypes.WinError()
    return {
        "page_fault_count": int(counters.PageFaultCount),
        "working_set_bytes": int(counters.WorkingSetSize),
        "peak_working_set_bytes": int(counters.PeakWorkingSetSize),
    }


def child(world_stop: int) -> int:
    """Fresh-process measurement for one rectangle; print one JSON line."""
    import numpy as np  # noqa: PLC0415  (import counted BEFORE baseline)

    from pkgea.query.mmap_scores import MemoryMappedScoreIndex  # noqa: PLC0415

    base = read_mem_counters()
    t0 = time.perf_counter()
    index = MemoryMappedScoreIndex.load(MMAP_DIR, verify_checksum=False)
    open_seconds = time.perf_counter() - t0

    # First touch: force a read over every touched element.
    t0 = time.perf_counter()
    checksum_first = float(index.scores[:world_stop].sum(dtype=np.float64))
    first_seconds = time.perf_counter() - t0
    mid = read_mem_counters()

    # Warm: same rectangle again in this process.
    t0 = time.perf_counter()
    checksum_warm = float(index.scores[:world_stop].sum(dtype=np.float64))
    warm_seconds = time.perf_counter() - t0
    end = read_mem_counters()
    index.close()

    row = {
        "world_stop": world_stop,
        "tensor_shape": [int(v) for v in index.scores.shape],
        "bytes_touched": int(world_stop * index.scores.shape[1] * index.scores.shape[2] * 4),
        "open_seconds": open_seconds,
        "first_touch_seconds": first_seconds,
        "warm_seconds": warm_seconds,
        "page_faults_baseline": base["page_fault_count"],
        "page_faults_after_first": mid["page_fault_count"],
        "page_faults_after_warm": end["page_fault_count"],
        "page_faults_first_delta": mid["page_fault_count"] - base["page_fault_count"],
        "page_faults_warm_delta": end["page_fault_count"] - mid["page_fault_count"],
        "working_set_after_warm_bytes": end["working_set_bytes"],
        "peak_working_set_bytes": end["peak_working_set_bytes"],
        "checksum_match": checksum_first == checksum_warm,
    }
    print("CHILD_RESULT " + json.dumps(row))
    return 0


def pct(values: list[float], q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return float("nan")
    idx = min(len(ordered) - 1, max(0, int(round(q * (len(ordered) - 1)))))
    return ordered[idx]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", type=int, default=None)
    args = parser.parse_args()
    if args.child is not None:
        return child(args.child)

    started = time.perf_counter()
    report: dict[str, object] = {
        "format": "pkgea-icde-cold-pagefault-v1",
        "date": "2026-10-08",
        "mmap_directory": str(MMAP_DIR),
        "method": (
            "Fresh python.exe child process per measurement; PageFaultCount "
            "read via ctypes GetProcessMemoryInfo after numpy import; first "
            "touch = sum() over the rectangle, warm = same sum() again."
        ),
        "cold_definition": (
            "cold = a brand-new process first-touch of the mmap pages. The OS "
            "file cache was NOT dropped (no safe user-mode way on Windows; we "
            "deliberately avoided RAMMap / NtSetSystemFileCacheSize), so "
            "measured faults are predominantly soft faults mapping already-"
            "cached pages into the fresh process, not hard disk faults."
        ),
        "fresh_child_runs": FRESH_CHILD_RUNS,
        "rectangles": {},
    }

    for label, world_stop in RECTS.items():
        runs: list[dict[str, object]] = []
        for _ in range(FRESH_CHILD_RUNS):
            proc = subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).resolve()),
                    "--child",
                    str(world_stop),
                ],
                capture_output=True,
                text=True,
                cwd=str(ROOT),
                env={
                    "PATH": __import__("os").environ.get("PATH", ""),
                    "PYTHONPATH": str(ROOT / "src"),
                },
            )
            line = next(
                (
                    part
                    for part in proc.stdout.splitlines()
                    if part.startswith("CHILD_RESULT ")
                ),
                None,
            )
            if line is None:
                raise RuntimeError(
                    f"child produced no result: rc={proc.returncode} "
                    f"stdout={proc.stdout[-500:]} stderr={proc.stderr[-500:]}"
                )
            runs.append(json.loads(line[len("CHILD_RESULT "):]))

        first_lat = [float(r["first_touch_seconds"]) for r in runs]
        warm_lat = [float(r["warm_seconds"]) for r in runs]
        open_lat = [float(r["open_seconds"]) for r in runs]
        report["rectangles"][label] = {
            "world_stop": world_stop,
            "bytes_touched": runs[0]["bytes_touched"],
            "runs": runs,
            "open_metadata_median_seconds": statistics.median(open_lat),
            "first_touch_median_seconds": statistics.median(first_lat),
            "first_touch_p95_seconds": pct(first_lat, 0.95),
            "warm_median_seconds": statistics.median(warm_lat),
            "warm_p95_seconds": pct(warm_lat, 0.95),
            "first_to_warm_speedup": statistics.median(first_lat)
            / max(statistics.median(warm_lat), 1e-12),
            "page_faults_first_median": statistics.median(
                [r["page_faults_first_delta"] for r in runs]
            ),
            "page_faults_warm_median": statistics.median(
                [r["page_faults_warm_delta"] for r in runs]
            ),
            "peak_working_set_median_bytes": statistics.median(
                [r["peak_working_set_bytes"] for r in runs]
            ),
            "all_checksums_match": all(r["checksum_match"] for r in runs),
        }
        agg = report["rectangles"][label]
        print(
            f"{label:22s} first={agg['first_touch_median_seconds']*1e3:8.3f}ms "
            f"warm={agg['warm_median_seconds']*1e3:8.3f}ms "
            f"faults_first={agg['page_faults_first_median']:.0f} "
            f"faults_warm={agg['page_faults_warm_median']:.0f}"
        )

    report["total_elapsed_seconds"] = time.perf_counter() - started
    if OUTPUT.exists():
        raise SystemExit(f"refusing to overwrite existing output: {OUTPUT}")
    OUTPUT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"wrote {OUTPUT} in {report['total_elapsed_seconds']:.1f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
