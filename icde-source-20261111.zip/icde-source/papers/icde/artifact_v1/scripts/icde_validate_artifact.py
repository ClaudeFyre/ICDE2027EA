"""Verify the ICDE single-blind reproducible artifact package.

Checks, and reports PASS/FAIL with the list of every problem found:
  1. every entry in MANIFEST.sha256 exists and its SHA-256 matches;
  2. the two score-tensor metadata.json carry the required digest/checksum fields;
  3. the README reproduction steps map to shipped result files;
  4. no local-path / identity forbidden string remains in any text file.

Exit code 0 = PASS, 1 = FAIL. Run from anywhere; the package root is derived
from this script's location (scripts/ is one level below the root).
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT_SUFFIXES = {".json", ".md", ".py", ".txt", ".sha256"}

# metadata files that must carry these keys.
METADATA_FILES = [
    "nodes/05_icde_query_engine/results/openea_probe32_score_cache_2048_s17.mmap-v3/metadata.json",
    "nodes/05_icde_query_engine/results/openea_probe64_score_cache_4096_s17.mmap-v1/metadata.json",
]
REQUIRED_META_KEYS = {"format", "dtype", "shape", "world_digest", "scores_file", "scores_sha256"}

# README reproduction step (verbatim heading) -> shipped result product.
README_STEP_PRODUCTS = {
    "Build / verify the probe tensors":
        "nodes/05_icde_query_engine/results/icde_probe64_tensor_build_2026-10-08.json",
    "Contract smoke":
        "nodes/05_icde_query_engine/results/icde_contract_smoke_2026-10-08.json",
    "Clean full-grid e2e":
        "nodes/05_icde_query_engine/results/icde_workload_e2e_fullgrid_2026-10-08.md",
    "Cold vs warm page fault":
        "nodes/05_icde_query_engine/results/icde_cold_pagefault_2026-10-08.md",
    "Multi-process throughput":
        "nodes/05_icde_query_engine/results/icde_multiprocess_throughput_2026-10-08.md",
    "Update-cost ladder":
        "nodes/05_icde_query_engine/results/icde_update_cost_2026-10-08.md",
    "Baselines + ablation":
        "nodes/05_icde_query_engine/results/icde_baselines_ablation_2026-10-08.md",
}

FORBIDDEN = {
    "drive-local-pkgea": re.compile(r"[A-Za-z]:[\\/]+pkgea", re.IGNORECASE),
    "users-path": re.compile(r"[A-Za-z]:[\\/]+Users[\\/]", re.IGNORECASE),
    # split so the workstation username literal does not appear in this file.
    "workstation-user": re.compile(r"Admin" "istrator", re.IGNORECASE),
    "codex-path": re.compile(r"\.codex[\\/]", re.IGNORECASE),
    "email": re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
}


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def main() -> int:
    problems: list[str] = []

    # --- 1. MANIFEST existence + hash --------------------------------------
    manifest = ROOT / "MANIFEST.sha256"
    if not manifest.is_file():
        print("FAIL: MANIFEST.sha256 missing")
        return 1
    entries: list[tuple[str, str]] = []
    for line in manifest.read_text(encoding="ascii").splitlines():
        line = line.strip()
        if not line:
            continue
        digest, _, rel = line.partition("  ")
        entries.append((digest.strip(), rel.strip()))

    if not entries:
        problems.append("MANIFEST.sha256 has no entries")

    manifested = set()
    for expected, rel in entries:
        manifested.add(rel)
        p = ROOT / rel
        if not p.is_file():
            problems.append(f"missing file: {rel}")
            continue
        actual = sha256(p)
        if actual != expected:
            problems.append(f"hash mismatch: {rel}\n  expected {expected}\n  actual   {actual}")

    # every shipped file must be covered by the manifest (except the manifest).
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT).as_posix()
        if rel == "MANIFEST.sha256":
            continue
        if rel not in manifested:
            problems.append(f"shipped file not listed in MANIFEST: {rel}")

    # --- 2. metadata fields ----------------------------------------------
    for rel in METADATA_FILES:
        p = ROOT / rel
        if not p.is_file():
            problems.append(f"metadata missing: {rel}")
            continue
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            problems.append(f"metadata not valid JSON: {rel} ({exc!r})")
            continue
        missing = REQUIRED_META_KEYS - set(data)
        if missing:
            problems.append(f"metadata {rel} missing keys: {sorted(missing)}")

    # --- 3. README steps -> shipped products ------------------------------
    readme = ROOT / "README.md"
    if not readme.is_file():
        problems.append("README.md missing")
    else:
        text = readme.read_text(encoding="utf-8")
        for step, rel in README_STEP_PRODUCTS.items():
            if step not in text:
                problems.append(f"README does not mention reproduction step: {step!r}")
            if not (ROOT / rel).is_file():
                problems.append(f"README step {step!r} product not shipped: {rel}")

    # --- 4. forbidden-string scan ----------------------------------------
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES:
            continue
        t = p.read_text(encoding="utf-8", errors="replace")
        rel = p.relative_to(ROOT).as_posix()
        for label, pat in FORBIDDEN.items():
            if pat.search(t):
                problems.append(f"identity/path leak [{label}] in {rel}")

    # --- report -----------------------------------------------------------
    n_files = sum(1 for p in ROOT.rglob("*") if p.is_file())
    total = sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())
    print(f"package_root = {ROOT}")
    print(f"manifested entries = {len(entries)}")
    print(f"shipped files = {n_files}")
    print(f"total bytes  = {total}")
    if problems:
        print(f"\nFAIL: {len(problems)} problem(s):")
        for prob in problems:
            print(f"  - {prob}")
        return 1
    print("\nPASS: all files present, hashes match, metadata complete, "
          "README steps map to shipped products, no identity/path leaks.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
