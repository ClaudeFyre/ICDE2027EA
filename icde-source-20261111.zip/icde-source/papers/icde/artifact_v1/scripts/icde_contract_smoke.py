"""ICDE contract smoke test: the four planner gates, end to end.

Run through scripts/safe_run.py. Exits non-zero if any gate assertion fails.
Writes a machine-readable summary to nodes/05_icde_query_engine/results/.

Gates exercised:
  1. revision  -- mmap index loaded with a tampered world digest raises;
                   distributional artifact with mismatched dataset_id is denied.
  2. validation -- stored artifact error 3.432e-4 is rejected at target 1e-4;
  3. cost       -- 6547.11 units rejected at budget 5000, authorized at 10000
                   (with validation passing at target 1e-3);
  4. fallback   -- every denied decision routes to adaptive_sampling.
Also prints a fully populated VersionedQueryRecord from a real progressive query.
"""

from __future__ import annotations

import json
import time
import traceback
from pathlib import Path

from pkgea.query import (
    MemoryMappedScoreIndex,
    VersionedScoreCache,
    ScoreCache,
    StaleCacheRevisionError,
    VersionedQueryRecord,
    distributional_eligibility,
    load_artifact_metadata,
)

ROOT = Path(__file__).resolve().parents[1]
MMAP_DIR = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "openea_probe32_score_cache_2048_s17.mmap-v3"
)
ARTIFACT = (
    ROOT
    / "nodes"
    / "04_www_distributional"
    / "operators"
    / "openea_torch_gcn_lowrank_w64_d16_r4_s17.npz"
)
OUTPUT = (
    ROOT
    / "nodes"
    / "05_icde_query_engine"
    / "results"
    / "icde_contract_smoke_2026-10-08.json"
)

# Probe constants taken from the measured artifacts (not recomputed here).
UNCERTAIN_EDGES = 992
CANDIDATE_COUNT = 96
STORED_VALIDATION_ERROR = 3.432e-4
EXPECTED_COST = 6547.11


def main() -> int:
    results: dict[str, object] = {"checks": [], "failures": []}

    def record(name: str, ok: bool, detail: object = None) -> None:
        results["checks"].append({"name": name, "ok": ok, "detail": detail})
        print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")
        if not ok:
            results["failures"].append(name)

    # --- Gate 1a: mmap revision gate rejects a tampered world digest ----------
    good_meta = json.loads((MMAP_DIR / "metadata.json").read_text(encoding="utf-8"))
    good_world = good_meta["world_digest"]
    tampered = "0" * 64
    try:
        MemoryMappedScoreIndex.load(
            MMAP_DIR,
            expected_world_digest=tampered,
            verify_checksum=False,
        )
        record("gate_revision_mmap_tampered_digest", False, "no error raised")
    except ValueError as exc:
        record(
            "gate_revision_mmap_tampered_digest",
            "stale" in str(exc) or "revision" in str(exc),
            str(exc),
        )

    # Gate 1b: an mmap load matching the real digest opens cleanly.
    try:
        index = MemoryMappedScoreIndex.load(
            MMAP_DIR,
            expected_world_digest=good_world,
            verify_checksum=False,
        )
        record("gate_revision_mmap_matching_digest", True, index.scores.shape)
        index.close()
    except Exception as exc:  # noqa: BLE001
        record("gate_revision_mmap_matching_digest", False, repr(exc))

    # Gate 1c: VersionedScoreCache raises StaleCacheRevisionError on old revision.
    try:
        vcache = VersionedScoreCache(ScoreCache(), active_revision="rev-A")
        try:
            vcache.get("rev-B", [], "att", ["s"], ["t"], lambda state: {})
            record("gate_revision_versioned_cache_stale", False, "no error")
        except StaleCacheRevisionError as exc:
            record("gate_revision_versioned_cache_stale", True, str(exc)[:60])
    except Exception as exc:  # noqa: BLE001
        record("gate_revision_versioned_cache_stale", False, repr(exc))

    # --- Distributional eligibility gates ------------------------------------
    meta = load_artifact_metadata(ARTIFACT)
    good_revision = str(meta["dataset_id"])

    # Gate 1d: artifact with mismatched dataset revision is denied at revision.
    d_rev = distributional_eligibility(
        artifact_metadata=meta,
        expected_dataset_revision="totally-different-revision",
        accuracy_target=1e-3,
        latency_budget=10000,
        uncertain_edges=UNCERTAIN_EDGES,
        candidate_count=CANDIDATE_COUNT,
    )
    record(
        "gate_revision_artifact_mismatch",
        (not d_rev.authorized)
        and d_rev.failed_gate == "revision"
        and d_rev.operator == "adaptive_sampling",
        d_rev.as_dict(),
    )

    # Gate 2: stored error 3.432e-4 > target 1e-4 -> denied at validation.
    d_val = distributional_eligibility(
        artifact_metadata=meta,
        expected_dataset_revision=good_revision,
        accuracy_target=1e-4,
        latency_budget=10000,  # generous budget must NOT waive validation
        uncertain_edges=UNCERTAIN_EDGES,
        candidate_count=CANDIDATE_COUNT,
    )
    record(
        "gate_validation_error_exceeds_target",
        (not d_val.authorized)
        and d_val.failed_gate == "validation"
        and d_val.operator == "adaptive_sampling",
        d_val.as_dict(),
    )

    # Gate 3a: budget 5000 < cost 6547.11 -> denied at cost (validation passes).
    d_cost_deny = distributional_eligibility(
        artifact_metadata=meta,
        expected_dataset_revision=good_revision,
        accuracy_target=1e-3,
        latency_budget=5000.0,
        uncertain_edges=UNCERTAIN_EDGES,
        candidate_count=CANDIDATE_COUNT,
    )
    record(
        "gate_cost_budget_5000_rejected",
        (not d_cost_deny.authorized)
        and d_cost_deny.failed_gate == "cost"
        and d_cost_deny.operator == "adaptive_sampling",
        d_cost_deny.as_dict(),
    )

    # Gate 3b: budget 10000 >= cost 6547.11, validation passes -> authorized.
    d_ok = distributional_eligibility(
        artifact_metadata=meta,
        expected_dataset_revision=good_revision,
        accuracy_target=1e-3,
        latency_budget=10000.0,
        uncertain_edges=UNCERTAIN_EDGES,
        candidate_count=CANDIDATE_COUNT,
    )
    record(
        "gate_cost_budget_10000_authorized",
        d_ok.authorized
        and d_ok.failed_gate is None
        and d_ok.operator == "distributional_low_rank"
        and abs(d_ok.estimated_cost - EXPECTED_COST) < 1.0,
        d_ok.as_dict(),
    )

    # --- Real progressive query -> fully populated versioned record ----------
    record_version = None
    try:
        index = MemoryMappedScoreIndex.load(
            MMAP_DIR, expected_world_digest=good_world, verify_checksum=False
        )
        source = index.sources[0]
        candidates = list(index.targets[:8])
        started = time.perf_counter()
        result = index.progressive_top_k(
            source,
            candidates,
            k=1,
            batch_size=32,
            delta=0.05,
            bound_method="empirical_bernstein",
        )
        elapsed = time.perf_counter() - started
        index.close()
        record_version = VersionedQueryRecord.from_progressive(
            result,
            dataset_revision=good_world[:16],
            edge_count=UNCERTAIN_EDGES,
            wall_time=elapsed,
            operator_version="progressive-sampling-v1",
            probability_model_version="empirical-bernstein-v1",
        ).as_dict()
        record(
            "versioned_record_populated",
            record_version["winner"] is not None
            and record_version["status"] in {"stable", "budget_exhausted"},
            record_version,
        )
    except Exception as exc:  # noqa: BLE001
        record("versioned_record_populated", False, repr(exc))
        traceback.print_exc()

    results["versioned_record_example"] = record_version
    results["ok"] = not results["failures"]
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists():
        raise SystemExit(f"refusing to overwrite existing output: {OUTPUT}")
    OUTPUT.write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(results, ensure_ascii=False, indent=2))
    return 0 if results["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
