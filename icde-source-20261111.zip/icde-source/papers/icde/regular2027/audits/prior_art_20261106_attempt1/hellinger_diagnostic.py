"""Read-only reclassification of archived RREA gaps using a standard TV bound.

This is a post-hoc literature-audit diagnostic. It does not run the scorer,
generate worlds, alter archived experiments, or establish a new algorithm.
"""

import argparse
import hashlib
import json
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from pathlib import Path

import numpy as np


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect_graph(base, graph):
    folder = base / graph
    law_path = folder / "law_masks_before_draws.npz"
    progress_path = folder / "progress.json"
    with np.load(law_path, allow_pickle=False) as law:
        q_values = np.unique(law["nominal_optional"])
        low_values = np.unique(law["full_box_low_optional"])
        high_values = np.unique(law["full_box_high_optional"])
        # These archived workloads are homogeneous products. Fail rather than
        # silently applying the homogeneous shortcut to another workload.
        assert len(q_values) == len(low_values) == len(high_values) == 1
        count = len(law["nominal_optional"])
        assert count == len(law["optional_original_indices"])
        pinned_count = int(np.count_nonzero(law["pinned"]))
        with localcontext() as context:
            context.prec = 100
            context.rounding = ROUND_FLOOR
            q = Decimal.from_float(float(q_values[0]))
            low = Decimal.from_float(float(low_values[0]))
            high = Decimal.from_float(float(high_values[0]))
            assert 0 < low <= q <= high < 1
            guard = Decimal("1e-65")
            affinities = [
                (q * p).sqrt() + ((1 - q) * (1 - p)).sqrt()
                for p in (low, high)
            ]
            # The extra guard dwarfs the 100-digit arithmetic error. The
            # endpoint minimum is valid by concavity in the varied parameter.
            one_coordinate_lower = min(affinities).quantize(
                guard, rounding=ROUND_FLOOR
            ) - guard
            product_lower = (one_coordinate_lower ** count).quantize(
                guard, rounding=ROUND_FLOOR
            ) - guard
            squared_lower = (product_lower * product_lower).quantize(
                guard, rounding=ROUND_FLOOR
            ) - guard
            epsilon = (1 - squared_lower).sqrt().quantize(
                Decimal("0.00000001"), rounding=ROUND_CEILING
            )
    progress = json.loads(progress_path.read_text(encoding="utf-8"))
    checks = {}
    for look in ("256", "512"):
        snapshot = progress["snapshots"][look]["numerical_lower_gaps"]
        for rule in ("normal", "empirical_bernstein"):
            gaps = [Decimal.from_float(float(value)) for value in snapshot[rule]]
            accepted = [index for index, gap in enumerate(gaps) if gap > 2 * epsilon]
            checks[f"{look}_{rule}"] = {
                "query_count": len(gaps),
                "pass_count": len(accepted),
                "passing_query_positions": accepted,
                "maximum_archived_lower_gap": str(max(gaps)),
                "minimum_positive_margin": str(
                    min(gaps[index] - 2 * epsilon for index in accepted)
                ) if accepted else None,
            }
    return {
        "graph": graph,
        "varied_coordinate_count": count,
        "pinned_coordinate_count": pinned_count,
        "q_from_archived_float": str(q),
        "box_low_from_archived_float": str(low),
        "box_high_from_archived_float": str(high),
        "standard_hellinger_tv_upper_rounded_up": str(epsilon),
        "required_lower_gap_strictly_greater_than": str(2 * epsilon),
        "sources": {
            str(law_path): digest(law_path),
            str(progress_path): digest(progress_path),
        },
        "checks": checks,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    output = args.output.resolve()
    assert output.is_relative_to(workspace)
    base = workspace / "nodes/09_vldb_query_certification/results/icde_gate_rrea_20261105_attempt1"
    result = {
        "status": "POSTHOC_DIAGNOSTIC_COMPLETE_NOT_A_MAIN_EXPERIMENT",
        "date_asia_shanghai": "2026-11-06",
        "method": "standard product affinity bound followed by TV <= sqrt(1-affinity^2)",
        "changed_objects": "none of scorer, law, edge universe, world stream, or archived gaps",
        "main_look": 256,
        "diagnostic_look": 512,
        "numerical_policy": "Decimal100, guarded downward affinity, upward TV at 1e-8",
        "graphs": {graph: inspect_graph(base, graph) for graph in ("dw", "enfr")},
        "limitations": [
            "Post-hoc deterministic reclassification, not independent stochastic replication.",
            "No speedup or primary-budget improvement is established.",
            "Uses the archived nominal inference contracts and product-law independence premise.",
        ],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({
        "status": result["status"],
        "output": str(output),
        "epsilon": {key: value["standard_hellinger_tv_upper_rounded_up"] for key, value in result["graphs"].items()},
        "primary256_pass_total": sum(value["checks"]["256_empirical_bernstein"]["pass_count"] for value in result["graphs"].values()),
        "diagnostic512_EB_pass_total": sum(value["checks"]["512_empirical_bernstein"]["pass_count"] for value in result["graphs"].values()),
    }))


if __name__ == "__main__":
    main()
