"""Finite exact-arithmetic audit of a research design, not a graph experiment.

Standard library only. Does not import or mutate any frozen experiment code.
"""

from collections import Counter, defaultdict
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from math import comb
from pathlib import Path
import hashlib
import json


COUNTS = Counter()


def check(condition, group):
    if not condition:
        raise AssertionError(group)
    COUNTS[group] += 1


@lru_cache(None)
def wealth(a, b):
    n = a + b
    return Q(sum(comb(n + 1, j) for j in range(a + 1)),
             (n + 1) * comb(n, a))


def polynomial_integral(a, b):
    # Independent expansion of the defining integral.
    return sum((Q(comb(a, i) * comb(b, j) * (-1) ** j, i + j + 1)
                for i in range(a + 1) for j in range(b + 1)), Q(0))


def lower(mask, w, d):
    return int(mask == 1 << w) - int(bool(mask & (1 << d)))


def stats(sequence, k):
    a = [sum(mask == 1 << w for mask in sequence) for w in range(k)]
    b = [sum(bool(mask & (1 << d)) for mask in sequence) for d in range(k)]
    return a, b


def pair_wealth(sequence, w, d):
    vals = [lower(mask, w, d) for mask in sequence]
    return wealth(vals.count(1), vals.count(-1))


def verify():
    for a in range(25):
        for b in range(25 - a):
            check(wealth(a, b) == polynomial_integral(a, b), "integral_identity")
            check(wealth(a + 1, b) >= wealth(a, b), "wealth_monotone")
            check(wealth(a, b + 1) <= wealth(a, b), "wealth_monotone")

    for k in range(2, 5):
        masks = range(1, 1 << k)
        for outer in masks:
            for inner in masks:
                if inner & outer != inner:
                    continue
                for w in range(k):
                    for d in range(k):
                        if w == d:
                            continue
                        lo = lower(outer, w, d)
                        exact = lower(inner, w, d)
                        check(lo <= exact, "refinement_monotone")
                        for y in range(k):
                            if inner & (1 << y):
                                check(lo <= int(y == w) - int(y == d),
                                      "sound_directional_lower_bound")

        for n in range(4):
            for sequence in product(masks, repeat=n):
                a, b = stats(sequence, k)
                scores = [min(wealth(a[w], b[d]) for d in range(k) if d != w)
                          for w in range(k)]
                d0 = max(range(k), key=lambda d: b[d])
                other = max((w for w in range(k) if w != d0), key=lambda w: a[w])
                check(max(scores) == max(scores[d0], scores[other]),
                      "two_candidate_reduction")
                for w in range(k):
                    for d in range(k):
                        if w != d:
                            check(wealth(a[w], b[d]) == pair_wealth(sequence, w, d),
                                  "count_compression")

    k = 3
    nested = [(outer, inner) for outer in range(1, 1 << k)
              for inner in range(1, 1 << k) if inner & outer == inner]
    for observations in product(nested, repeat=2):
        outer = tuple(item[0] for item in observations)
        inner = tuple(item[1] for item in observations)
        for w in range(k):
            for d in range(k):
                if w != d:
                    check(pair_wealth(outer, w, d) <= pair_wealth(inner, w, d),
                          "pathwise_wealth_domination")

    # Exact finite-horizon crossing probability under a two-candidate null.
    # Set probabilities .3 singleton-0, .5 singleton-1, .2 ambiguous.
    # Both candidates fail robust uniqueness: E psi_01=-.4, E psi_10=0.
    delta, threshold = Q(1, 4), Q(8)
    states = {(0, 0, 0, False): Q(1)}
    crossing = []
    for n in range(1, 13):
        updated = defaultdict(Q)
        for (a0, a1, amb, crossed), mass in states.items():
            for category, probability in enumerate((Q(3, 10), Q(1, 2), Q(1, 5))):
                counts = [a0, a1, amb]
                counts[category] += 1
                x, y, z = counts
                hit = wealth(x, y + z) >= threshold or wealth(y, x + z) >= threshold
                updated[x, y, z, crossed or hit] += mass * probability
        states = updated
        probability = sum((mass for state, mass in states.items() if state[3]), Q(0))
        check(sum(states.values(), Q(0)) == 1, "finite_null_mass")
        check(probability <= delta, "finite_null_crossing_bound")
        crossing.append({"horizon": n, "exact_crossing_probability": str(probability)})

    # Positive scalar-information separation, all exact.
    check(Q(3, 5) - Q(1, 5) == 2 * Q(1, 5), "separation_example")
    check(Q(3, 5) - Q(2, 5) == Q(1, 5) > 0, "separation_example")
    # Whole family from the counterexample: both endpoint models have .6 vs .4;
    # their mixtures do too, while the pointwise infimum mean is negative.
    for theta in (Q(0), Q(1, 4), Q(1, 2), Q(3, 4), Q(1)):
        pw = Q(1, 5) + Q(2, 5) * (1 - theta) + Q(2, 5) * theta
        check(pw == Q(3, 5), "incompleteness_example")
    check(Q(1, 5) - Q(4, 5) == -Q(3, 5), "incompleteness_example")

    # Grouped four-dimensional state DP agrees with brute-force Boolean states
    # for several shared-degree coefficient patterns. This is not a scorer audit.
    patterns = [
        [(1, 0, 1, 0)] * 4,
        [(1, 0, 1, 0), (0, 1, 0, 1), (-1, 0, 0, 0), (0, 0, -1, 0)],
        [(1, 0, 1, 0)] * 3 + [(0, -1, 0, 0)] * 2 + [(0, 0, 0, -1)],
    ]
    for vectors in patterns:
        brute = {tuple(sum(z * v[j] for z, v in zip(bits, vectors)) for j in range(4))
                 for bits in product((0, 1), repeat=len(vectors))}
        reachable = {(0, 0, 0, 0)}
        for vector, count in Counter(vectors).items():
            reachable = {tuple(old[j] + amount * vector[j] for j in range(4))
                         for old in reachable for amount in range(count + 1)}
        check(brute == reachable, "grouped_state_dp")

    return {
        "status": "PASS",
        "kind": "finite_exact_arithmetic_research_design_audit",
        "date": "2026-11-07",
        "checks": dict(COUNTS),
        "total_checks": sum(COUNTS.values()),
        "finite_null_crossing": crossing,
        "scope": {
            "integral_identity": "all nonnegative a,b with a+b<=24",
            "candidate_count_checks": "all nonempty-set sequences with K=2,3,4 and n<=3",
            "refinement_domination": "all nested nonempty set pairs for K=3, n=2",
            "finite_null": "one declared two-candidate set law, horizons 1..12",
        },
        "limitations": [
            '[说明文本已清理]',
            "No real-graph algorithm, timing, probability-calibration or label-accuracy claim.",
            "No frozen experimental code or result files were imported or modified.",
        ],
        "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }


if __name__ == "__main__":
    result = verify()
    destination = Path(__file__).with_name("checks.json")
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "checks": result["total_checks"],
                      "output": str(destination)}, ensure_ascii=False))
