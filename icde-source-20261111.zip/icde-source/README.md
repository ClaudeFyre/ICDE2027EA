# ICDE 研究源码

2026-11-11 源码汇集。

## 文件目录

- `src/` 包含项目 Python 模块。
- `scripts/` 包含 ICDE 实验入口、数值实现、检查及共享依赖。
- `tests/` 包含项目测试代码。
- `nodes/` 包含 ICDE 实验入口及历史源码快照。
- `papers/icde/` 包含既有代码附件中的源码。
- `configs/` 包含脚本参数配置。

## 使用

Python 包入口采用 `pyproject.toml`。匹配实验的参考依赖见 `requirements-matching.txt`。
实验输入位置由对应脚本常量、配置和命令行参数指定。实验执行入口位于 `scripts/`，历史快照按原相对路径保存。

```sh
python -m pip install -e .
python -m compileall -q src scripts tests
```

## 公开导出说明

部分结论性注释和预置评述文案已清理，本机绝对路径采用 `PROJECT_ROOT` 与 `C:/Users/USER` 占位。
`MANIFEST.json` 记录文件路径、大小、SHA-256 及文本处理数量。
