from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.contracts import validate_dataset
from pkgea.data import convert_openea


class OpenEAConversionTests(unittest.TestCase):
    def test_minimal_conversion(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "D_W_15K_V1"
            split = source / "721_5fold" / "1"
            split.mkdir(parents=True)
            (source / "rel_triples_1").write_text(
                "http://db/a\thttp://db/r\thttp://db/b\n", encoding="utf-8"
            )
            (source / "rel_triples_2").write_text(
                "http://wd/a\thttp://wd/r\thttp://wd/b\n", encoding="utf-8"
            )
            (source / "ent_links").write_text(
                "http://db/a\thttp://wd/a\n", encoding="utf-8"
            )
            (source / "attr_triples_1").write_text(
                "http://db/a\thttp://db/name\tAlice\n", encoding="utf-8"
            )
            (source / "attr_triples_2").write_text(
                "http://wd/a\thttp://wd/label\tAlice\n", encoding="utf-8"
            )
            (split / "train_links").write_text(
                "http://db/a\thttp://wd/a\n", encoding="utf-8"
            )
            (split / "valid_links").write_text(
                "http://db/b\thttp://wd/b\n", encoding="utf-8"
            )
            (split / "test_links").write_text("", encoding="utf-8")
            output = convert_openea(source, Path(temp_dir) / "canonical")
            report = validate_dataset(output)
            self.assertEqual(report.triple_count, 2)
            self.assertEqual(report.alignment_count, 2)
            self.assertEqual(report.entity_count, 4)
            self.assertTrue((output / "attributes.tsv").is_file())
            self.assertEqual(
                len((output / "attributes.tsv").read_text(encoding="utf-8").splitlines()),
                3,
            )
            metadata = json.loads(
                (output / "confidence_metadata.json").read_text(encoding="utf-8")
            )
            self.assertIn("CC BY 4.0", metadata["license_status"])
            self.assertEqual(metadata["generation"]["attribute_triples"], 2)


if __name__ == "__main__":
    unittest.main()
