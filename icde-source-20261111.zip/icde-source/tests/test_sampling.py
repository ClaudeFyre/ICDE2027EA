from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import ToyStructuralBackbone
from pkgea.diagnostics import run_toy_diagnostic
from pkgea.evaluation import estimate_objectives
from pkgea.samplers import (
    exact_worlds,
    importance_worlds,
    monte_carlo_worlds,
    representative_worlds,
    stratified_worlds,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"
PROBABILITIES = [0.8, 0.6, 0.75, 0.55]


class SamplingTests(unittest.TestCase):
    def test_s0_mass_is_one(self) -> None:
        worlds = exact_worlds(PROBABILITIES)
        self.assertEqual(len(worlds), 16)
        self.assertTrue(math.isclose(sum(world.weight for world in worlds), 1.0))

    def test_s1_is_reproducible(self) -> None:
        first = monte_carlo_worlds(PROBABILITIES, 32, 17)
        second = monte_carlo_worlds(PROBABILITIES, 32, 17)
        self.assertEqual(first, second)

    def test_local_sampling_preserves_selected_shared_latent_distribution(self) -> None:
        probabilities = [0.2, 0.5, 0.8]
        worlds = monte_carlo_worlds(
            probabilities,
            20_000,
            17,
            dependency_groups=["shared", "shared", "shared"],
            common_shock_probability=0.55,
            local_edge_indices={0, 2},
        )
        first_mean = sum(world.state[0] for world in worlds) / len(worlds)
        third_mean = sum(world.state[2] for world in worlds) / len(worlds)
        joint_mean = sum(
            world.state[0] and world.state[2] for world in worlds
        ) / len(worlds)
        expected_joint = 0.55 * 0.2 + (1.0 - 0.55) * 0.2 * 0.8
        self.assertAlmostEqual(first_mean, 0.2, delta=0.015)
        self.assertAlmostEqual(third_mean, 0.8, delta=0.015)
        self.assertAlmostEqual(joint_mean, expected_joint, delta=0.015)
        self.assertTrue(all(world.state[1] for world in worlds))
        self.assertTrue(all(world.sampled_edge_count == 2 for world in worlds))

    def test_s3_and_s5_have_normalized_weights(self) -> None:
        stratified = stratified_worlds(PROBABILITIES, 32, 17)
        importance = importance_worlds(PROBABILITIES, [0.5] * 4, 64, 17)
        representatives = representative_worlds(PROBABILITIES, 4, 64, 17)
        self.assertTrue(math.isclose(sum(x.weight for x in stratified), 1.0))
        self.assertTrue(math.isclose(sum(x.weight for x in importance), 1.0))
        self.assertTrue(math.isclose(sum(x.weight for x in representatives), 1.0))

    def test_four_objectives_are_computed(self) -> None:
        backbone = ToyStructuralBackbone.from_dataset(TOY)
        estimate = estimate_objectives(exact_worlds(PROBABILITIES), backbone.score)
        self.assertEqual(len(estimate.expected_score), 9)
        self.assertEqual(len(estimate.threshold_probability), 9)
        self.assertEqual(len(estimate.rank_cvar), 9)
        self.assertTrue(estimate.winner_probability)

    def test_end_to_end_diagnostic(self) -> None:
        report = run_toy_diagnostic(TOY, sample_count=128, seed=17)
        self.assertEqual(report.exact_world_count, 16)
        self.assertGreaterEqual(report.mc_expected_score_mae, 0.0)
        self.assertGreater(report.mc_sampled_edge_evaluations, 0)


if __name__ == "__main__":
    unittest.main()
