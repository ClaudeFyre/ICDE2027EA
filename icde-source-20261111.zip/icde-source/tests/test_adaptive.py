from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.wsdm import run_toy_adaptive_sampling
from pkgea.generators import BenchmarkGeneratorConfig, generate_benchmark


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class AdaptiveSamplingTests(unittest.TestCase):
    def test_budget_is_allocated_and_never_exceeded(self) -> None:
        report = run_toy_adaptive_sampling(
            TOY, total_budget=192, seed=17, measure_latency=True
        )
        self.assertEqual(report["total_allocated_worlds"], 192)
        self.assertLessEqual(report["total_used_worlds"], 192)
        self.assertEqual(len(report["sources"]), 3)
        self.assertEqual(report["ground_truth_top1_accuracy"], 1.0)
        self.assertEqual(report["ranking_metrics"]["hits_at_1"], 1.0)
        self.assertEqual(report["ranking_metrics"]["mrr"], 1.0)
        self.assertGreater(report["latency"]["total_seconds"], 0.0)
        self.assertIn("candidate_local_subgraphs", report)
        self.assertTrue(report["sources"][0]["sampled_edge_indices"])

    def test_run_is_reproducible(self) -> None:
        first = run_toy_adaptive_sampling(TOY, total_budget=192, seed=29)
        second = run_toy_adaptive_sampling(TOY, total_budget=192, seed=29)
        self.assertEqual(first, second)

    def test_correlated_metadata_reaches_world_sampler(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            dataset = Path(temp_dir) / "correlated"
            generate_benchmark(
                TOY,
                dataset,
                BenchmarkGeneratorConfig(
                    mechanism="structural_correlated",
                    shared_strength=0.55,
                    seed=17,
                ),
            )
            report = run_toy_adaptive_sampling(
                dataset, total_budget=48, seed=17
            )
            self.assertEqual(
                report["edge_dependence_assumption"],
                "grouped_shared_latent",
            )
            self.assertEqual(report["common_shock_probability"], 0.55)

    def test_model_decision_bound_drives_local_edge_union(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            dataset = Path(temp_dir) / "attributed"
            dataset.mkdir()
            for filename in (
                "entities.tsv",
                "relations.tsv",
                "triples.tsv",
                "alignments.tsv",
                "confidence_metadata.json",
            ):
                (dataset / filename).write_bytes((TOY / filename).read_bytes())
            (dataset / "attributes.tsv").write_text(
                "graph_id\tentity_id\tattribute_id\tvalue\n"
                "source\ts:alice\tkey\tidentity-a\n"
                "target\tt:alice\tkey\tidentity-a\n"
                "source\ts:bob\tkey\tidentity-b\n"
                "target\tt:bob\tkey\tidentity-b\n"
                "source\ts:city\tkey\tidentity-c\n"
                "target\tt:city\tkey\tidentity-c\n",
                encoding="utf-8",
            )
            unpruned = run_toy_adaptive_sampling(
                dataset,
                total_budget=192,
                seed=17,
                backbone_name="attribute",
            )
            pruned = run_toy_adaptive_sampling(
                dataset,
                total_budget=192,
                seed=17,
                backbone_name="attribute",
                candidate_top_k=1,
            )
        self.assertTrue(pruned["candidate_pruning"]["enabled"])
        self.assertGreater(
            pruned["candidate_pruning"]["total_pruned_candidates"], 0
        )
        self.assertLessEqual(
            pruned["total_sampled_edges"], unpruned["total_sampled_edges"]
        )
        self.assertEqual(pruned["ground_truth_top1_accuracy"], 1.0)


if __name__ == "__main__":
    unittest.main()
