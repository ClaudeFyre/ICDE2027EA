from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

from safe_run import process_exists


class SafeRunWindowsTests(unittest.TestCase):
    def test_current_process_exists(self) -> None:
        self.assertTrue(process_exists(os.getpid()))

    def test_impossible_pid_does_not_exist(self) -> None:
        self.assertFalse(process_exists(2_147_483_647))


if __name__ == "__main__":
    unittest.main()
