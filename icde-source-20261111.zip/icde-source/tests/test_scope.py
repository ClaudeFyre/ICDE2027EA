from __future__ import annotations

import csv
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import AttributeStructuralBackbone
from pkgea.contracts import dataset_revision_digest
from pkgea.scope import (
    build_incident_degree_certificate,
    build_message_passing_certificate,
    influence_edge_indices,
    validate_full_local_score_equivalence,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class ScopeCertificateTests(unittest.TestCase):
    def test_message_passing_scope_includes_complete_depth_frontier(self) -> None:
        triples = [
            {"head_id": "a", "tail_id": "b", "evidence_id": "0", "dependency_group": ""},
            {"head_id": "b", "tail_id": "c", "evidence_id": "1", "dependency_group": "g"},
            {"head_id": "c", "tail_id": "d", "evidence_id": "2", "dependency_group": "g"},
            {"head_id": "d", "tail_id": "e", "evidence_id": "3", "dependency_group": ""},
            {"head_id": "x", "tail_id": "y", "evidence_id": "4", "dependency_group": ""},
        ]
        self.assertEqual(
            influence_edge_indices(triples, ("a",), message_passing_steps=2),
            {0, 1},
        )
        certificate, selected = build_message_passing_certificate(
            triples,
            dataset_revision="0" * 64,
            query_id="a",
            candidates=("b",),
            message_passing_steps=2,
            scorer_id="message-passing",
            scorer_version="1",
            global_state_dependencies=("frozen-features:abc",),
            normalization_scope=("node-local-weighted-mean",),
        )
        self.assertEqual(selected, {0, 1, 2})
        self.assertIn("U:dependency_group:g", certificate.dependency_factor_ids)
        self.assertIn("frozen-features:abc", certificate.global_state_dependencies)
        certificate.validate()

    def test_certificate_binds_dependency_factors_and_hash(self) -> None:
        with (TOY / "triples.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            triples = list(csv.DictReader(handle, delimiter="\t"))
        triples[0]["dependency_group"] = "shared-a"
        certificate, selected = build_incident_degree_certificate(
            triples,
            dataset_revision=dataset_revision_digest(TOY),
            query_id="s:alice",
            candidates=("t:alice",),
            scorer_id="attribute-structural",
            scorer_version="1",
        )
        certificate.validate()
        self.assertTrue(certificate.exact)
        self.assertIn("U:dependency_group:shared-a", certificate.dependency_factor_ids)
        self.assertEqual(len(certificate.edge_ids), len(selected))

    def test_full_local_all_candidate_scores_are_exact(self) -> None:
        backbone = AttributeStructuralBackbone.from_dataset(TOY)
        with (TOY / "triples.tsv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            triples = list(csv.DictReader(handle, delimiter="\t"))
        candidates = backbone.target_entities
        certificate, selected = build_incident_degree_certificate(
            triples,
            dataset_revision=dataset_revision_digest(TOY),
            query_id="s:alice",
            candidates=candidates,
            scorer_id="attribute-structural",
            scorer_version="1",
        )
        full_states = [
            (False, False, False, False),
            (True, False, True, False),
            (True, True, False, True),
            (False, True, True, True),
        ]
        probabilities = [float(row["confidence"]) for row in triples]
        local_states = [
            tuple(
                active if index in selected else probabilities[index] >= 0.5
                for index, active in enumerate(state)
            )
            for state in full_states
        ]
        result = validate_full_local_score_equivalence(
            certificate,
            full_states,
            local_states,
            lambda state: {
                candidate: score
                for (_, candidate), score in backbone.score_subset(
                    state, ("s:alice",), candidates
                ).items()
            },
        )
        self.assertTrue(result.exact)
        self.assertEqual(result.maximum_absolute_error, 0.0)


if __name__ == "__main__":
    unittest.main()
