from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import RelationTranslationBackbone


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class TranslationBackboneTests(unittest.TestCase):
    def test_complete_bounded_and_world_sensitive_scores(self) -> None:
        backbone = RelationTranslationBackbone.from_dataset(
            TOY, dimension=16
        )
        state = (True,) * len(backbone.triples)
        scores = backbone.score(state)
        self.assertEqual(
            len(scores),
            len(backbone.source_entities)
            * len(backbone.target_entities),
        )
        self.assertTrue(
            all(math.isfinite(value) and 0.0 <= value <= 1.0 for value in scores.values())
        )
        changed = list(state)
        changed[0] = False
        perturbed = backbone.score(tuple(changed))
        self.assertTrue(
            any(abs(scores[key] - perturbed[key]) > 1e-12 for key in scores)
        )

    def test_margin_refinement_is_deterministic_and_reported(self) -> None:
        first = RelationTranslationBackbone.from_dataset(
            TOY,
            dimension=16,
            margin_epochs=3,
            seed=23,
        )
        second = RelationTranslationBackbone.from_dataset(
            TOY,
            dimension=16,
            margin_epochs=3,
            seed=23,
        )
        self.assertEqual(
            first.training_summary["mode"],
            "hard_negative_margin",
        )
        self.assertEqual(first.training_summary, second.training_summary)
        self.assertTrue(np.allclose(first.mapping, second.mapping))


if __name__ == "__main__":
    unittest.main()
