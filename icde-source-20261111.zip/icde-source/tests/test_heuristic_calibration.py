from __future__ import annotations

import csv
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.data import (
    map_heuristic_confidences,
    mask_cross_graph_entity_labels,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class HeuristicCalibrationTests(unittest.TestCase):
    def test_mapping_is_explicit_and_rank_preserving(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "source"
            shutil.copytree(TOY, source)
            path = source / "triples.tsv"
            with path.open(
                "r", encoding="utf-8-sig", newline=""
            ) as handle:
                reader = csv.DictReader(handle, delimiter="\t")
                fields = list(reader.fieldnames or [])
                rows = list(reader)
            for row in rows:
                row["confidence_type"] = "normalized_heuristic_weight"
            with path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=fields,
                    delimiter="\t",
                    lineterminator="\n",
                )
                writer.writeheader()
                writer.writerows(rows)
            output = map_heuristic_confidences(
                source,
                Path(temp_dir) / "mapped",
                temperature=2.0,
            )
            with (output / "triples.tsv").open(
                "r", encoding="utf-8-sig", newline=""
            ) as handle:
                mapped = list(csv.DictReader(handle, delimiter="\t"))
            self.assertEqual(
                {row["confidence_type"] for row in mapped},
                {"assumed_probability_mapping"},
            )
            self.assertEqual(
                sorted(range(len(rows)), key=lambda i: float(rows[i]["confidence"])),
                sorted(
                    range(len(mapped)),
                    key=lambda i: float(mapped[i]["confidence"]),
                ),
            )
            metadata = json.loads(
                (output / "confidence_metadata.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertFalse(
                metadata["confidence_mapping"]["supervised_calibration"]
            )

    def test_label_mask_breaks_cross_graph_identity(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output = mask_cross_graph_entity_labels(
                TOY,
                Path(temp_dir) / "masked",
            )
            with (output / "entities.tsv").open(
                "r", encoding="utf-8-sig", newline=""
            ) as handle:
                rows = list(csv.DictReader(handle, delimiter="\t"))
            labels = {row["entity_id"]: row["label"] for row in rows}
            self.assertNotEqual(labels["s:alice"], labels["t:alice"])


if __name__ == "__main__":
    unittest.main()
