"""Finite exact counterexamples and transfer checks; no external inputs/files."""

from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import vldb_exact_robustness_v0 as exact


class ProductLawTests(unittest.TestCase):
    def test_bit_order_and_normalization(self):
        self.assertEqual(exact.product_masses((F(1, 4), F(2, 3))),
                         (F(1, 4), F(1, 12), F(1, 2), F(1, 6)))
        for p in product((F(0), F(1, 3), F(1)), repeat=3):
            self.assertEqual(sum(exact.product_masses(p)), 1)

    def test_tv_is_half_l1_and_symmetric(self):
        self.assertEqual(exact.product_tv(("0.2",), ("0.8",)), F(3, 5))
        self.assertEqual(exact.product_tv((0, 1), (1, 0)), 1)
        self.assertEqual(exact.product_tv(("0.2", "0.7"), ("0.5", "0.8")),
                         exact.product_tv(("0.5", "0.8"), ("0.2", "0.7")))

    def test_scope_detects_global_omission(self):
        mapping = (0, 0, 1, 1)
        self.assertFalse(exact.scope_audit(mapping, 2, (0,))["complete"])
        self.assertTrue(exact.scope_audit(mapping, 2, (1,))["minimal"])
        self.assertFalse(exact.scope_audit(mapping, 2, (0, 1))["minimal"])
        with self.assertRaises(ValueError):
            exact.sensitivity_bounds(("0.5", "0.2"), ("0.5", "0.8"), mapping, 2, (0,))

    def test_every_boolean_event_changes_at_most_tv(self):
        grid = (F(0), F(1, 2), F(1))
        laws = tuple(product(grid, repeat=2))
        # Enumerate every binary winner function on all four two-bit worlds.
        for binary_function in range(16):
            mapping = tuple((binary_function >> mask) & 1 for mask in range(4))
            for p in laws:
                old = exact.winner_distribution(p, mapping, 2)
                for q in laws:
                    new = exact.winner_distribution(q, mapping, 2)
                    self.assertLessEqual(abs(old[0] - new[0]), exact.product_tv(p, q))


class SensitivityTests(unittest.TestCase):
    def test_path_is_telescoping_not_old_point_influence(self):
        parity = (0, 1, 1, 0)
        p, q = (F(1, 2), F(1, 2)), (F(3, 5), F(3, 5))
        bounds = exact.sensitivity_bounds(p, q, parity, 2, (0, 1))
        self.assertEqual(bounds["path"][0], F(1, 50))
        self.assertEqual(bounds["box"][0], F(1, 5))
        self.assertEqual(bounds["path_details"]["signed_derivative_expectations"][0][0]["fraction"], "0")
        self.assertEqual(bounds["path_details"]["signed_derivative_expectations"][1][0]["fraction"], "1/5")

    def test_uniform_pivotal_box_supremum_is_at_vertices(self):
        and_map = (1, 1, 1, 0)
        p, q = (F(1, 5), F(3, 10)), (F(2, 5), F(1, 2))
        bounds = exact.sensitivity_bounds(p, q, and_map, 2, (0, 1))
        self.assertTrue(bounds["box_details"]["exact_pivotal_supremum"])
        # |delta0| sup r1 + |delta1| sup r0 = .2*.5+.2*.4.
        self.assertEqual(bounds["box"][0], F(9, 50))
        old = exact.winner_distribution(p, and_map, 2)
        # Independently include interior points, not only the implementation's vertices.
        for x in (F(1, 5), F(3, 10), F(2, 5)):
            for y in (F(3, 10), F(2, 5), F(1, 2)):
                new = exact.winner_distribution((x, y), and_map, 2)
                self.assertLessEqual(abs(new[0] - old[0]), bounds["box"][0])

    def test_large_scope_fallback_is_marked_and_valid(self):
        mapping = tuple(mask.bit_count() % 2 for mask in range(8))
        bounds = exact.sensitivity_bounds(("0.2",) * 3, ("0.3",) * 3, mapping, 2,
                                          (0, 1, 2), exact_box_scope_limit=2)
        self.assertFalse(bounds["box_details"]["exact_pivotal_supremum"])
        self.assertEqual(bounds["box"][0], F(3, 10))

    def test_multicandidate_event_bounds(self):
        mapping = (0, 1, 2, 0)
        p, q = (F(1, 5), F(3, 10)), (F(2, 5), F(1, 2))
        bounds = exact.sensitivity_bounds(p, q, mapping, 3, (0, 1))
        old, new = exact.winner_distribution(p, mapping, 3), exact.winner_distribution(q, mapping, 3)
        for c in range(3):
            self.assertLessEqual(abs(old[c] - new[c]), bounds["path"][c])
            self.assertLessEqual(abs(old[c] - new[c]), bounds["box"][c])


class CertificateTests(unittest.TestCase):
    def test_strict_2epsilon_excludes_new_tie(self):
        mapping = (1, 0)
        p, q = (F(3, 5),), (F(1, 2),)
        old, new = exact.winner_distribution(p, mapping, 2), exact.winner_distribution(q, mapping, 2)
        bounds = exact.sensitivity_bounds(p, q, mapping, 2, (0,))
        checks = exact.transfer_checks(old, new, F(1, 10), F(1, 10), F(1, 10), bounds, F(1))
        self.assertFalse(any(checks["certified"].values()))
        self.assertEqual(checks["violations"], [])

    def test_local_scope_can_save_certificate_full_tv_cannot(self):
        model = next(m for m in exact.built_in_models() if m.name == "single_bit_near")
        q = exact.perturb(model, F(1, 20), "outside_only")
        self.assertGreater(exact.product_tv(model.base, q), F(1, 100))
        p_local, q_local = (model.base[0],), (q[0],)
        self.assertEqual(exact.product_tv(p_local, q_local), 0)
        old = exact.winner_distribution(model.base, model.mapping, 2)
        new = exact.winner_distribution(q, model.mapping, 2)
        bounds = exact.sensitivity_bounds(model.base, q, model.mapping, 2, model.scope)
        checks = exact.transfer_checks(old, new, exact.product_tv(model.base, q), F(0), F(0), bounds, F(1))
        self.assertFalse(checks["certified"]["full_TV"])
        self.assertTrue(checks["certified"]["scope_TV"])
        self.assertEqual(checks["violations"], [])

    def test_pivotal_bound_can_save_certificate_scope_tv_cannot(self):
        mapping = (1, 1, 1, 0)  # A iff both bits are one.
        p, q = (F(7, 10), F(7, 10)), (F(71, 100), F(7, 10))
        old, new = exact.winner_distribution(p, mapping, 2), exact.winner_distribution(q, mapping, 2)
        bounds = exact.sensitivity_bounds(p, q, mapping, 2, (0, 1))
        tv = exact.product_tv(p, q)
        checks = exact.transfer_checks(old, new, tv, tv, tv, bounds, F(1))
        self.assertEqual(old[1] - old[0], 2 * tv)
        self.assertFalse(checks["certified"]["scope_TV"])
        self.assertTrue(checks["certified"]["event_path"])
        self.assertTrue(checks["certified"]["event_uniform_box"])
        self.assertEqual(checks["violations"], [])

    def test_all_small_boolean_transfers_are_safe(self):
        laws = tuple(product((F(1, 4), F(1, 2), F(3, 4)), repeat=2))
        for binary_function in range(16):
            mapping = tuple((binary_function >> mask) & 1 for mask in range(4))
            for p in laws:
                old = exact.winner_distribution(p, mapping, 2)
                for q in laws:
                    new = exact.winner_distribution(q, mapping, 2)
                    bounds = exact.sensitivity_bounds(p, q, mapping, 2, (0, 1))
                    tv = exact.product_tv(p, q)
                    checked = exact.transfer_checks(old, new, tv, tv, tv, bounds, F(1))
                    self.assertEqual(checked["violations"], [])

    def test_counterexamples_are_real_and_explicit(self):
        examples = exact.counterexamples()
        self.assertTrue(examples["same_marginals_different_dependence"]["winner_reversed"])
        self.assertTrue(examples["omitted_global_dependency"]["false_scope_would_certify"])
        self.assertTrue(examples["omitted_global_dependency"]["winner_reversed"])
        self.assertEqual(examples["old_point_influence_not_uniform"]["actual_event_probability_change"]["fraction"], "1/50")

    def test_smoke_report_is_exact_json_and_tie_has_no_certificate(self):
        report = exact.run_exact_validation({"models": ["single_bit_near", "single_bit_tie"],
                                             "perturbation_steps": ["0", "0.05"],
                                             "patterns": ["outside_only", "inside_all_down"]})
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["summary"]["violations"], 0)
        self.assertGreater(report["summary"]["extra_certified_over_full_TV"]["scope_TV"], 0)
        for case in report["cases"]:
            if case["model"] == "single_bit_tie":
                self.assertTrue(all(not any(check["certified"].values()) for check in case["certificate_checks"]))
        json.dumps(report, allow_nan=False)

    def test_invalid_input_fails_closed(self):
        with self.assertRaises(ValueError):
            exact.product_masses((F(2),))
        with self.assertRaises(ValueError):
            exact.run_exact_validation({"max_variables": 11})
        with self.assertRaises(ValueError):
            exact.run_exact_validation({"certificate_factors": ["1.1"]})


class CommonShockTests(unittest.TestCase):
    def test_exact_shared_uniform_law_and_rho_endpoints(self):
        p = (F(1, 5), F(7, 10))
        self.assertEqual(exact.common_uniform_masses(p), (F(3, 10), F(0), F(1, 2), F(1, 5)))
        self.assertEqual(exact.mixed_common_shock_masses(p, 0), exact.product_masses(p))
        self.assertEqual(exact.mixed_common_shock_masses(p, 1), exact.common_uniform_masses(p))
        mixture = exact.mixed_common_shock_masses(p, F(11, 20))
        self.assertEqual(sum(mixture), 1)
        self.assertEqual(mixture[1] + mixture[3], p[0])
        self.assertEqual(mixture[2] + mixture[3], p[1])
        with self.assertRaises(ValueError):
            exact.mixed_common_shock_masses(p, F(6, 5))

    def test_frozen_gamma_bounds_joint_tv_and_interval_union(self):
        report = exact.run_common_shock_validation()
        self.assertEqual(report["joint_law_pair_checks"], 36)
        self.assertEqual(report["violations"], 0)
        for row in report["cases"]:
            self.assertLessEqual(F(row["exact_joint_TV"]["fraction"]), F(row["gamma"]["fraction"]))
        bound = exact.common_shock_coupling_bound(("0.2", "0.7"), ("0.4", "0.6"), 1, 1)
        self.assertEqual(bound["d_shock"]["fraction"], "3/10")
        self.assertEqual(bound["d_ind"]["fraction"], "7/25")
        overlapping = exact.common_shock_coupling_bound(("0.2", "0.3"), ("0.5", "0.6"), 1, 1)
        self.assertEqual(overlapping["d_shock"]["fraction"], "2/5")

    def test_common_shock_box_corner_minimum_misses_internal_breakpoint(self):
        witness = exact.run_common_shock_validation()["interior_breakpoint_counterexample"]
        self.assertEqual(witness["corner_minimum"]["fraction"], "1/5")
        self.assertEqual(witness["interior_xor_probability"]["fraction"], "0")
        self.assertTrue(witness["corner_only_minimum_is_invalid"])


if __name__ == "__main__":
    unittest.main()
