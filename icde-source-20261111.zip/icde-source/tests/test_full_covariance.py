from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.distributional import (
    approximate_covariance,
    gaussian_wasserstein_squared,
    low_rank_plus_diagonal,
)


class FullCovarianceTests(unittest.TestCase):
    def test_approximations_are_psd_and_preserve_diagonal(self) -> None:
        covariance = np.array(
            [[2.0, 0.8, 0.4], [0.8, 1.0, 0.2], [0.4, 0.2, 0.5]]
        )
        for mode in ("diagonal", "block", "low_rank"):
            result = approximate_covariance(
                covariance,
                mode,
                block_size=2,
                rank=1,
            )
            self.assertGreaterEqual(np.linalg.eigvalsh(result).min(), -1e-10)
            self.assertTrue(
                np.allclose(np.diag(result), np.diag(covariance))
            )
        factor, residual = low_rank_plus_diagonal(covariance, rank=1)
        reconstructed = factor @ factor.T + np.diag(residual)
        self.assertTrue(
            np.allclose(np.diag(reconstructed), np.diag(covariance))
        )

    def test_gaussian_wasserstein_is_zero_for_identical_inputs(self) -> None:
        mean = np.array([0.2, -0.4])
        covariance = np.array([[1.0, 0.3], [0.3, 0.7]])
        self.assertAlmostEqual(
            gaussian_wasserstein_squared(
                mean,
                covariance,
                mean,
                covariance,
            ),
            0.0,
            places=9,
        )


if __name__ == "__main__":
    unittest.main()
