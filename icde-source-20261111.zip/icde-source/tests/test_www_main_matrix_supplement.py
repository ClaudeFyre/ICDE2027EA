from scripts.run_www_main_matrix import CELLS
from scripts.run_www_main_matrix_supplement import REPRESENTATIVE, task

def test_supplement_closes_mrr_for_all_cells_and_limits_adaptive_claims():
    tasks=[task(g,f,d) for g,f,d,_ in CELLS]
    assert len(tasks)==8
    assert sum(t["adaptive_serving_representative"] for t in tasks)==3
    assert REPRESENTATIVE=={("dw","gcn","independent"),("dw","relation","structural"),("enfr","relation","structural")}
    for item in tasks:
        command=item["command"]
        assert command[command.index("--budgets")+1]=="2048"
        assert command[command.index("--test-seeds")+1:command.index("--test-seeds")+3]==["59","71"]
        assert command[command.index("--query-limit")+1]=="500"
