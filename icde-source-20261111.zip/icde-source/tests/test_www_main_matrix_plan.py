from scripts.run_www_main_matrix import CELLS, BUDGET_SWEEP, GATE_ONLY, TEST_SEEDS, task


def test_scheme_b_matrix_is_frozen() -> None:
    tasks = [task(*cell) for cell in CELLS]
    assert len(tasks) == 8
    assert sum(item["representative_budget_sweep"] for item in tasks) == 2
    assert tasks[0]["budgets"] == list(BUDGET_SWEEP)
    assert tasks[1]["budgets"] == list(BUDGET_SWEEP)
    assert all(item["budgets"] == list(GATE_ONLY) for item in tasks[2:])


def test_every_invocation_explicitly_uses_frozen_seeds_and_scale() -> None:
    assert TEST_SEEDS == (59, 71)
    for item in [task(*cell) for cell in CELLS]:
        command = item["command"]
        index = command.index("--test-seeds")
        assert command[index + 1:index + 3] == ["59", "71"]
        assert command[command.index("--query-limit") + 1] == "500"
        assert command[command.index("--candidate-limit") + 1] == "1012"


def test_plan_builds_without_checkpoint_weights() -> None:
    """The plan must be inspectable on a clean clone.

    Weights are untracked, so digest() returns None when they are absent; the
    existence requirement belongs to preflight, not to plan construction.  A
    test that only passes on the machine holding the weights is not a guard.
    """

    for item in [task(*cell) for cell in CELLS]:
        assert item["checkpoint_sha256"] is None or len(str(item["checkpoint_sha256"])) == 64
