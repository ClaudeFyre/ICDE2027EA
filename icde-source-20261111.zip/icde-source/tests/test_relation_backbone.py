from __future__ import annotations

import unittest

import torch

from scripts.backbones.torch_relation_align import (
    RelationAwareAlign,
    build_input_features,
    ranking_metrics,
)


class RelationAwareBackboneTests(unittest.TestCase):
    def setUp(self) -> None:
        self.entity_ids = ["s1", "s2", "t1", "t2"]
        self.entities = [
            {"graph_id": "source", "entity_id": "s1", "label": "alpha"},
            {"graph_id": "source", "entity_id": "s2", "label": "beta"},
            {"graph_id": "target", "entity_id": "t1", "label": "alpha"},
            {"graph_id": "target", "entity_id": "t2", "label": "beta"},
        ]
        self.triples = [
            {
                "head_id": "s1",
                "relation_id": "rs",
                "tail_id": "s2",
                "confidence": "1",
            },
            {
                "head_id": "t1",
                "relation_id": "rt",
                "tail_id": "t2",
                "confidence": "1",
            },
        ]
        self.entity_index = {
            entity: position for position, entity in enumerate(self.entity_ids)
        }
        self.relation_index = {"rs": 0, "rt": 0}

    def features(self, mode: str) -> torch.Tensor:
        return build_input_features(
            self.entity_ids,
            self.entities,
            self.triples,
            ["rs", "rt"],
            ["friend"],
            self.entity_index,
            self.relation_index,
            dimension=32,
            feature_mode=mode,
        )

    def test_structural_features_match_mirrored_views_without_entity_labels(self) -> None:
        features = self.features("structural")
        torch.testing.assert_close(features[0], features[2])
        torch.testing.assert_close(features[1], features[3])

    def test_opaque_features_do_not_reuse_cross_graph_lexical_identity(self) -> None:
        features = self.features("opaque")
        self.assertFalse(torch.equal(features[0], features[2]))
        self.assertFalse(torch.equal(features[1], features[3]))

    def test_relation_encoder_is_world_sensitive_and_metrics_are_ranked(self) -> None:
        torch.manual_seed(3)
        features = self.features("structural")
        model = RelationAwareAlign(32, 16, 1)
        heads = torch.tensor([0, 2])
        tails = torch.tensor([1, 3])
        relations = torch.tensor([0, 0])
        with torch.no_grad():
            present = model(features, heads, tails, relations, torch.ones(2))
            absent = model(features, heads, tails, relations, torch.zeros(2))
        self.assertFalse(torch.allclose(present, absent))
        metrics = ranking_metrics(
            present,
            [(0, 2), (1, 3)],
            torch.tensor([2, 3]),
        )
        self.assertEqual(metrics["hits_at_1"], 1.0)
        self.assertEqual(metrics["mrr"], 1.0)


if __name__ == "__main__":
    unittest.main()
