from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.experiments import (
    run_multi_seed_budget_curve,
    run_sampler_comparison,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class SamplerComparisonTests(unittest.TestCase):
    def test_equal_draw_comparison(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            reference = Path(temp_dir) / "reference.json"
            run_multi_seed_budget_curve(
                TOY,
                [64],
                [11, 17, 23],
                backbone_name="toy",
                early_stopping=False,
                output_path=reference,
            )
            result = run_sampler_comparison(
                TOY,
                reference,
                sample_count=32,
                seeds=[11, 17, 23],
                representative_count=8,
                backbone_name="toy",
            )
            self.assertEqual(len(result["aggregate"]), 3)
            self.assertEqual(len(result["runs"]), 9)
            self.assertTrue(
                all(item["sampled_edge_draws"] == 128 for item in result["runs"])
            )
            s5 = next(
                item
                for item in result["aggregate"]
                if item["method"] == "S5_representative"
            )
            self.assertLessEqual(s5["scored_world_count_mean"], 8)


if __name__ == "__main__":
    unittest.main()
