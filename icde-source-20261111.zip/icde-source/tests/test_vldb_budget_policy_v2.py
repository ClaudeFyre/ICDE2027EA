"""Verify protected prefix use and the paid-work certification boundary."""

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from vldb_budget_policy_v2 import run_budget_policy


class BudgetPolicyTests(unittest.TestCase):
    def settings(self):
        return {
            "delta_total": .05, "delta_nominal": .025, "beta_total": .025,
            "tau_grid": [.001, .01], "event_checkpoints": [96, 224, 480, 992],
            "budget_fractions": [1.0], "interval_work_weights": [1.0],
            "nominal": {"rho": 64.0, "minimum_samples": 32, "check_every": 64},
            "work_model": {"nominal_candidate_units": 16,
                           "interval_candidate_units": 64,
                           "conditioned_candidate_units": 64},
        }

    def query(self, *, flags=False, free=False, scope=1.0):
        return {
            "graph": "toy", "query_id": "q", "nominal_seed": 41,
            "candidate_count": 2, "scope_edge_count": 1,
            "winner_indices": [0] * 1024,
            "cost_model": {"original_incidence_entries": 1,
                           "interval_incidence_entries": 1,
                           "source_incidence_entries": 1},
            "tau_records": [{"tau": tau, "epsilon_scope_upper": scope,
                             "h_difference": [flags] * 1024,
                             "h_source_conditioned": [flags] * 1024,
                             "free_flags": [free] * 1024,
                             "conditioning_degree_rows": [0] * 1024,
                             "conditioning_assignment_counts": [0] * 1024}
                            for tau in (.001, .01)],
        }

    def test_scope_branch_pays_no_event_work_and_uses_declared_risk(self):
        rows = run_budget_policy(self.query(scope=0.0), self.settings())
        self.assertTrue(all(row["stable"] for row in rows))
        self.assertTrue(all(row["event_samples_used"] == 0 for row in rows))
        self.assertEqual({row["nominal_delta"] for row in rows}, {.025, .05})

    def test_shared_prefix_can_certify_without_any_new_uniform_draws(self):
        rows = run_budget_policy(self.query(), self.settings())
        event = [row for row in rows if row["policy"].endswith("lazy")]
        self.assertTrue(all(row["stable"] for row in event))
        for row in event:
            self.assertIn(row["event_samples_used"], self.settings()["event_checkpoints"])
            self.assertLessEqual(row["event_samples_used"], row["samples_used"])
            self.assertLessEqual(row["work_used"], row["work_budget"])
            self.assertEqual(row["event_bernoulli_uniforms_added"], 0)
        self.assertTrue(all(not row["stable"] for row in rows if row["policy"].startswith("scope_")))

    def test_event_block_finishing_after_budget_cannot_issue_certificate(self):
        settings = self.settings()
        settings["interval_work_weights"] = [100000.0]
        rows = run_budget_policy(self.query(free=True), settings)
        event = [row for row in rows if row["policy"].endswith("lazy")]
        self.assertTrue(all(not row["stable"] for row in event))
        self.assertTrue(all(row["work_overshoot"] > 0 for row in event))
        self.assertTrue(all(row["status"] == "event_block_past_budget" for row in event))

    def test_uncalculated_or_bad_event_samples_are_never_implicitly_zero(self):
        rows = run_budget_policy(self.query(flags=True, free=True), self.settings())
        self.assertTrue(all(not row["stable"] for row in rows))
        self.assertTrue(all(row["event_ambiguity_upper"] == 1 for row in rows))

    def test_single_candidate_has_a_structural_certificate_with_no_worlds(self):
        query = self.query()
        query["candidate_count"] = 1
        rows = run_budget_policy(query, self.settings())
        self.assertTrue(all(row["stable"] and row["samples_used"] == 0 for row in rows))

    def test_missing_prefix_or_invalid_refinement_fails_closed(self):
        query = self.query()
        query["tau_records"][0]["h_difference"].pop()
        with self.assertRaisesRegex(ValueError, "prefixes"):
            run_budget_policy(query, self.settings())
        query = self.query()
        query["tau_records"][0]["h_source_conditioned"][0] = True
        with self.assertRaisesRegex(ValueError, "refine"):
            run_budget_policy(query, self.settings())


if __name__ == "__main__":
    unittest.main()
