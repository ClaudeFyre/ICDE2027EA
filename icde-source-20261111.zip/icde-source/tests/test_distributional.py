from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.distributional import (
    GaussianMoments,
    aggregate_bernoulli_messages,
    diagonal_bhattacharyya,
    diagonal_wasserstein_squared,
    degree_normalized_message_delta_mean,
    linear_gaussian_moments,
    propagate_relu_network,
    relu_gaussian_moments,
)
from pkgea.www import (
    run_real_distributional_validation,
    run_hidden_representation_validation,
    run_toy_moment_validation,
    run_toy_multilayer_validation,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class DistributionalTests(unittest.TestCase):
    def test_delta_correction_reduces_degree_normalization_bias(self) -> None:
        result = degree_normalized_message_delta_mean(
            [[0.0], [1.0]],
            [0],
            [1],
            [0.5],
            [0],
        )
        exact_mean = 0.25
        plugin_error = abs(float(result.plugin_mean[0, 0]) - exact_mean)
        delta_error = abs(float(result.delta_mean[0, 0]) - exact_mean)
        self.assertLess(delta_error, plugin_error)
        self.assertEqual(result.local_edge_counts, (1,))

    def test_independent_moments(self) -> None:
        moments = aggregate_bernoulli_messages(
            [(1.0, 0.0), (0.0, 2.0)], [0.25, 0.5]
        )
        self.assertEqual(moments.mean, (0.25, 1.0))
        self.assertTrue(math.isclose(moments.covariance[0][0], 0.1875))
        self.assertTrue(math.isclose(moments.covariance[1][1], 1.0))

    def test_common_shock_adds_positive_covariance(self) -> None:
        independent = aggregate_bernoulli_messages(
            [(1.0,), (1.0,)], [0.4, 0.7], dependency_groups=["g", "g"]
        )
        correlated = aggregate_bernoulli_messages(
            [(1.0,), (1.0,)],
            [0.4, 0.7],
            dependency_groups=["g", "g"],
            common_shock_probability=0.8,
        )
        self.assertGreater(
            correlated.covariance[0][0], independent.covariance[0][0]
        )

    def test_relu_and_matching(self) -> None:
        left = GaussianMoments((0.0,), ((1.0,),))
        transformed = relu_gaussian_moments(left)
        self.assertGreater(transformed.mean[0], 0.0)
        self.assertEqual(diagonal_wasserstein_squared(left, left), 0.0)
        self.assertEqual(diagonal_bhattacharyya(left, left), 0.0)

    def test_real_validation_runs_on_toy(self) -> None:
        result = run_real_distributional_validation(
            TOY, sample_count=256, seed=17
        )
        self.assertEqual(result["entity_count"], 6)
        self.assertIn("wasserstein", result["matching"])
        self.assertEqual(
            result["complexity"]["mc_sampled_edge_evaluations"],
            1024,
        )

    def test_hidden_representation_depth_report_runs_on_toy(self) -> None:
        result = run_hidden_representation_validation(
            TOY,
            sample_count=128,
            seed=17,
            dimension=4,
            depth=2,
        )
        self.assertEqual(len(result["layers"]), 3)
        self.assertEqual(result["layers"][0]["depth"], 0)
        self.assertTrue(
            all(layer["mean_rmse"] >= 0.0 for layer in result["layers"])
        )
        self.assertEqual(
            result["complexity"]["mc_sampled_edge_evaluations"],
            512,
        )

    def test_linear_and_multilayer_shapes(self) -> None:
        initial = GaussianMoments((1.0, 2.0), ((1.0, 0.25), (0.25, 2.0)))
        linear = linear_gaussian_moments(initial, [[1.0, 2.0]], [0.5])
        self.assertEqual(linear.mean, (5.5,))
        self.assertEqual(linear.covariance, ((10.0,),))
        layers = propagate_relu_network(
            initial,
            [
                ([[1.0, 0.0], [0.0, 1.0]], [0.0, 0.0]),
                ([[1.0, 1.0]], [0.0]),
            ],
        )
        self.assertEqual(len(layers), 2)
        self.assertEqual(len(layers[-1].mean), 1)

    def test_analytic_toy_matches_exact(self) -> None:
        report = run_toy_moment_validation(TOY)
        self.assertLess(report["max_mean_error"], 1e-12)
        self.assertLess(report["max_covariance_error"], 1e-12)
        self.assertLess(report["analytic_edge_passes"], report["exact_edge_passes"])

    def test_multilayer_report_exposes_approximation_error(self) -> None:
        report = run_toy_multilayer_validation(TOY)
        self.assertEqual(len(report["layers"]), 2)
        self.assertTrue(
            all(layer["max_mean_error"] >= 0.0 for layer in report["layers"])
        )
        self.assertLess(report["analytic_edge_passes"], report["exact_edge_passes"])


if __name__ == "__main__":
    unittest.main()
