from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import math
import sys
import threading
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.extensions import (
    run_hop_invalidation_audit,
    run_snapshot_isolation_audit,
    run_streaming_batch_toy,
    run_streaming_query_trace,
    run_streaming_toy,
)
from pkgea.distributional import aggregate_bernoulli_messages
from pkgea.persistent_stream import SQLiteSnapshotStore
from pkgea.stream_worker import DurableStreamingWorker
from pkgea.streaming import (
    calibrate_local_embedding_refresh,
    FactEvent,
    IncrementalMomentIndex,
    LocalEmbeddingRefreshPolicy,
    RevisionConflictError,
    VersionedStreamingMomentIndex,
    propagation_affected_entities,
)
from pkgea.trustworthy import (
    adaptive_conformal_candidate_set,
    brier_score,
    conformal_candidate_set,
    expected_calibration_error,
    evaluate_conformal_coverage,
    fit_multiclass_temperature,
    fit_temperature,
    margin_conformal_candidate_set,
    multiclass_brier_score,
    multiclass_log_loss,
    maximum_weight_injective_assignment,
    prune_to_injective_assignment_support,
    softmax_probabilities,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class ExtensionTests(unittest.TestCase):
    def test_local_embedding_refresh_policy_uses_conservative_cutoff(
        self,
    ) -> None:
        policy = calibrate_local_embedding_refresh(
            ((3, 4.0), (12, 1.2), (40, 1.1), (100, 0.8)),
            total_entities=200,
            minimum_speedup=1.05,
        )
        self.assertEqual(policy.max_local_entities, 40)
        self.assertEqual(policy.choose(40), "local_recompute")
        self.assertEqual(policy.choose(41), "full_forward")
        self.assertAlmostEqual(policy.as_dict()["max_local_fraction"], 0.2)

    def test_sqlite_snapshot_store_cas_is_durable_and_conflict_safe(
        self,
    ) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "stream.sqlite"
            initial = IncrementalMomentIndex(((1.0,),), (0.2,))
            winner = IncrementalMomentIndex(((1.0,),), (0.8,))
            loser = IncrementalMomentIndex(((1.0,),), (0.4,))
            with SQLiteSnapshotStore(path) as first:
                self.assertTrue(first.initialize("test", initial.snapshot()))
                self.assertEqual(
                    first.compare_and_swap(
                        "test",
                        expected_version=0,
                        snapshot=winner.snapshot(),
                        event_id="winner",
                    ),
                    1,
                )
            with SQLiteSnapshotStore(path) as second:
                with self.assertRaises(RevisionConflictError):
                    second.compare_and_swap(
                        "test",
                        expected_version=0,
                        snapshot=loser.snapshot(),
                        event_id="loser",
                    )
                restored = second.read("test")
                self.assertEqual(restored.version, 1)
                self.assertEqual(restored.state.probabilities, (0.8,))
                self.assertEqual(second.history_versions("test"), (0, 1))

    def test_durable_worker_combines_refresh_policy_and_idempotent_cas(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as temp_dir:
            database = Path(temp_dir) / "worker.sqlite"
            policy = LocalEmbeddingRefreshPolicy(
                total_entities=4,
                max_local_entities=2,
                minimum_observed_speedup=1.1,
                calibration_points=3,
            )
            worker = DurableStreamingWorker(
                database,
                "stream",
                (("a", "b"), ("b", "c"), ("c", "d")),
                policy,
                propagation_depth=1,
            )
            initial = IncrementalMomentIndex(
                ((1.0,), (2.0,), (3.0,)),
                (0.2, 0.3, 0.4),
                dependency_groups=("", "wide", "wide"),
                common_shock_probability=0.55,
            )
            self.assertTrue(worker.initialize(initial))
            local = worker.apply_probability_update(0, 0.8, "local")
            self.assertEqual(local.refresh_action, "local_recompute")
            full = worker.apply_probability_update(1, 0.7, "full")
            self.assertEqual(full.refresh_action, "full_forward")
            duplicate = worker.apply_probability_update(1, 0.7, "full")
            self.assertTrue(duplicate.duplicate)
            self.assertEqual(duplicate.version, full.version)
            with SQLiteSnapshotStore(database) as store:
                self.assertEqual(store.history_versions("stream"), (0, 1, 2))
                self.assertEqual(
                    store.read("stream").state.common_shock_probability,
                    0.55,
                )

    def test_hop_aware_invalidation_expands_with_model_depth(self) -> None:
        endpoints = [("a", "b"), ("b", "c"), ("c", "d")]
        self.assertEqual(
            propagation_affected_entities(endpoints, [0], 1),
            frozenset({"a", "b"}),
        )
        self.assertEqual(
            propagation_affected_entities(endpoints, [0], 2),
            frozenset({"a", "b", "c"}),
        )
        self.assertEqual(
            propagation_affected_entities(endpoints, [0], 3),
            frozenset({"a", "b", "c", "d"}),
        )
        self.assertEqual(
            propagation_affected_entities(
                endpoints,
                [0],
                1,
                normalization_hops=1,
            ),
            frozenset({"a", "b", "c"}),
        )
        with self.assertRaises(ValueError):
            propagation_affected_entities(endpoints, [0], 0)
        with self.assertRaises(IndexError):
            propagation_affected_entities(endpoints, [3], 1)
        with self.assertRaises(ValueError):
            propagation_affected_entities(
                endpoints, [0], 1, normalization_hops=-1
            )

    def test_hop_invalidation_audit_is_monotone(self) -> None:
        report = run_hop_invalidation_audit(TOY, max_depth=3)
        counts = [
            row["invalidating_edge_updates"] for row in report["depths"]
        ]
        self.assertEqual(counts, sorted(counts))
        self.assertEqual(report["depths"][0]["missed_by_endpoint_rule"], 0)

    def test_snapshot_isolation_audit_has_no_torn_reads(self) -> None:
        report = run_snapshot_isolation_audit(
            update_count=40, reader_count=2
        )
        self.assertGreater(report["snapshot_reads"], 0)
        self.assertEqual(report["commit_consistency_violations"], 0)
        self.assertEqual(report["final_version"], 40)
        self.assertTrue(report["held_old_snapshot"]["still_immutable"])

    def test_incremental_update_matches_rebuild(self) -> None:
        report = run_streaming_toy(TOY, edge_index=0, new_probability=0.4)
        self.assertLess(report["max_rebuild_mean_error"], 1e-12)
        self.assertLess(report["max_rebuild_covariance_error"], 1e-12)

    def test_grouped_incremental_update(self) -> None:
        index = IncrementalMomentIndex(
            [(1.0,), (2.0,)],
            [0.4, 0.7],
            dependency_groups=["g", "g"],
            common_shock_probability=0.5,
        )
        update = index.update(0, 0.6)
        self.assertEqual(update.affected_edges, (0, 1))

    def test_batch_add_update_delete_matches_rebuild(self) -> None:
        report = run_streaming_batch_toy(TOY)
        self.assertEqual(
            [event["action"] for event in report["events"]],
            ["update", "add", "delete"],
        )
        self.assertLess(report["max_rebuild_mean_error"], 1e-12)
        self.assertLess(report["max_rebuild_covariance_error"], 1e-12)

    def test_grouped_add_tracks_affected_edges(self) -> None:
        index = IncrementalMomentIndex(
            [(1.0,)],
            [0.4],
            dependency_groups=["g"],
            common_shock_probability=0.5,
        )
        result = index.apply_events(
            [
                FactEvent(
                    "add",
                    probability=0.6,
                    message=(2.0,),
                    dependency_group="g",
                )
            ]
        )
        self.assertEqual(result[0].affected_edges, (0, 1))

    def test_versioned_stream_distinguishes_event_and_observation_time(self) -> None:
        base = IncrementalMomentIndex([(1.0,), (2.0,)], [0.4, 0.7])
        stream = VersionedStreamingMomentIndex(
            base, allowed_lateness=1.0, max_history=4
        )
        stream.put_cached("left", object(), depends_on_edges=[0])
        stream.put_cached("right", object(), depends_on_edges=[1])
        first = stream.apply_event(
            FactEvent(
                "update",
                edge_index=0,
                probability=0.6,
                event_time=4.0,
                observation_time=5.0,
                event_id="first",
            )
        )
        self.assertEqual(first.lateness, 1.0)
        self.assertEqual(first.invalidated_cache_keys, ("left",))
        self.assertIsNotNone(stream.get_cached("right"))
        stream.apply_event(
            FactEvent(
                "update",
                edge_index=1,
                probability=0.5,
                event_time=1.0,
                observation_time=6.0,
                event_id="late",
            )
        )
        self.assertTrue(stream.records[-1].late_beyond_watermark)

    def test_versioned_stream_rollback_restores_exact_state(self) -> None:
        base = IncrementalMomentIndex([(1.0,)], [0.4])
        stream = VersionedStreamingMomentIndex(base, max_history=4)
        stream.apply_event(
            FactEvent(
                "update",
                edge_index=0,
                probability=0.8,
                event_time=1.0,
                observation_time=1.0,
            )
        )
        stream.rollback(0)
        self.assertEqual(base.probabilities, [0.4])
        self.assertEqual(stream.version, 0)

    def test_concurrent_read_snapshots_are_commit_consistent(self) -> None:
        messages = [(1.0, 0.0), (0.0, 2.0)]
        base = IncrementalMomentIndex(messages, [0.4, 0.7])
        stream = VersionedStreamingMomentIndex(base, max_history=64)
        held_old = stream.read_snapshot()
        finished = threading.Event()

        def writer() -> None:
            for position in range(40):
                stream.apply_event(
                    FactEvent(
                        "update",
                        edge_index=position % 2,
                        probability=0.2 + 0.1 * (position % 7),
                        event_time=float(position + 1),
                        observation_time=float(position + 1),
                    )
                )
            finished.set()

        def reader() -> list[int]:
            violations = []
            while not finished.is_set():
                snapshot = stream.read_snapshot()
                rebuilt = aggregate_bernoulli_messages(
                    snapshot.state.messages,
                    snapshot.state.probabilities,
                    dependency_groups=snapshot.state.dependency_groups,
                )
                error = max(
                    abs(left - right)
                    for left, right in zip(
                        rebuilt.mean,
                        snapshot.state.moments.mean,
                        strict=True,
                    )
                )
                if error > 1e-12:
                    violations.append(snapshot.version)
            return violations

        with ThreadPoolExecutor(max_workers=4) as executor:
            readers = [executor.submit(reader) for _ in range(3)]
            writer_future = executor.submit(writer)
            writer_future.result()
            violations = [
                version
                for future in readers
                for version in future.result()
            ]

        self.assertEqual(violations, [])
        self.assertEqual(held_old.version, 0)
        self.assertEqual(held_old.state.probabilities, (0.4, 0.7))
        self.assertEqual(stream.read_snapshot().version, 40)

    def test_compare_and_swap_rejects_one_stale_writer(self) -> None:
        stream = VersionedStreamingMomentIndex(
            IncrementalMomentIndex([(1.0,)], [0.4]),
            max_history=4,
        )
        barrier = threading.Barrier(2)

        def writer(probability: float) -> str:
            barrier.wait()
            try:
                stream.apply_event_if_version(
                    FactEvent(
                        "update",
                        edge_index=0,
                        probability=probability,
                        event_time=1.0,
                        observation_time=1.0,
                    ),
                    expected_version=0,
                )
                return "committed"
            except RevisionConflictError:
                return "conflict"

        with ThreadPoolExecutor(max_workers=2) as executor:
            outcomes = sorted(
                future.result()
                for future in (
                    executor.submit(writer, 0.6),
                    executor.submit(writer, 0.8),
                )
            )
        self.assertEqual(outcomes, ["committed", "conflict"])
        self.assertEqual(stream.version, 1)
        self.assertIn(
            stream.read_snapshot().state.probabilities[0],
            {0.6, 0.8},
        )

    def test_streaming_query_trace_blocks_stale_scores(self) -> None:
        report = run_streaming_query_trace(
            TOY, event_count=4, world_budget=4, seed=17
        )
        self.assertEqual(report["trace"]["stale_reads_blocked"], 4)
        self.assertEqual(report["trace"]["same_revision_hits"], 4)
        self.assertTrue(
            report["rollback"]["retained_revision_cache_hit"]
        )
        self.assertTrue(
            report["rollback"]["local_retained_revision_cache_hit"]
        )
        self.assertLess(
            report["local_refresh"]["max_score_error_vs_full_recompute"],
            1e-12,
        )

    def test_calibration_metrics(self) -> None:
        probabilities = [0.9, 0.8, 0.2, 0.1]
        labels = [1, 1, 0, 0]
        self.assertTrue(math.isclose(brier_score(probabilities, labels), 0.025))
        self.assertGreaterEqual(
            expected_calibration_error(probabilities, labels, bins=2), 0.0
        )
        self.assertGreater(fit_temperature(probabilities, labels), 0.0)

    def test_multiclass_temperature_and_scores(self) -> None:
        logits = [(4.0, 1.0), (0.5, 2.0)]
        labels = [0, 1]
        temperature = fit_multiclass_temperature(logits, labels)
        rows = [
            softmax_probabilities(row, temperature) for row in logits
        ]
        self.assertAlmostEqual(sum(rows[0]), 1.0)
        self.assertLess(multiclass_log_loss(rows, labels), 0.1)
        self.assertLess(multiclass_brier_score(rows, labels), 0.1)

    def test_maximum_weight_assignment_is_injective_and_optimal(self) -> None:
        assignment = maximum_weight_injective_assignment(
            [
                [9.0, 8.0, 1.0],
                [9.0, 2.0, 1.0],
            ]
        )
        self.assertEqual(assignment, (1, 0))
        self.assertEqual(len(set(assignment)), 2)

    def test_assignment_support_prunes_impossible_edges(self) -> None:
        result = prune_to_injective_assignment_support(
            [{0}, {0, 1}], column_count=2
        )
        self.assertTrue(result.feasible)
        self.assertEqual(result.candidate_sets, (frozenset({0}), frozenset({1})))
        self.assertEqual(result.removed_edges, 1)
        infeasible = prune_to_injective_assignment_support(
            [{0}, {0}], column_count=2
        )
        self.assertFalse(infeasible.feasible)
        self.assertEqual(infeasible.removed_edges, 0)

    def test_conformal_candidate_set(self) -> None:
        result = conformal_candidate_set(
            [0.9, 0.8, 0.85, 0.75],
            {"a": 0.88, "b": 0.7, "c": 0.2},
            alpha=0.2,
        )
        self.assertIn("a", result.candidates)
        self.assertNotIn("c", result.candidates)

    def test_adaptive_conformal_set_uses_ranked_probability_mass(self) -> None:
        result = adaptive_conformal_candidate_set(
            [(0.8, 0.15, 0.05)] * 8,
            [0] * 8,
            {"a": 0.75, "b": 0.2, "c": 0.05},
            alpha=0.2,
        )
        self.assertEqual(result.candidates, ("a",))
        self.assertLessEqual(result.quantile, 0.8)

    def test_margin_conformal_set_is_query_relative(self) -> None:
        result = margin_conformal_candidate_set(
            [(0.8, 0.15, 0.05)] * 8,
            [0] * 8,
            {"a": 0.6, "b": 0.3, "c": 0.1},
            alpha=0.2,
        )
        self.assertEqual(result.candidates, ("a",))
        self.assertEqual(result.quantile, 0.0)

    def test_conformal_coverage_uses_disjoint_queries(self) -> None:
        report = evaluate_conformal_coverage(
            [0.9, 0.8, 0.85, 0.75],
            [
                ("a", {"a": 0.88, "b": 0.7}),
                ("b", {"a": 0.2, "b": 0.82}),
            ],
            alpha=0.2,
        )
        self.assertEqual(report.test_queries, 2)
        self.assertEqual(report.empirical_coverage, 1.0)
        self.assertGreaterEqual(report.average_set_size, 1.0)


if __name__ == "__main__":
    unittest.main()
