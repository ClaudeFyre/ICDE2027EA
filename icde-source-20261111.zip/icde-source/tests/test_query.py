from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import AttributeStructuralBackbone, ToyStructuralBackbone
from pkgea.contracts import dataset_revision_digest
from pkgea.icde import (
    run_batch_queries,
    run_distributional_queries,
    run_learned_covariance_queries,
    run_planned_batch_queries,
    run_query_operator_comparison,
    run_toy_query,
)
from pkgea.query import (
    MMapAutotunePolicy,
    QueryWorkload,
    LearnedLowRankCovarianceIndex,
    MemoryMappedScoreIndex,
    ScoreCache,
    StaleCacheRevisionError,
    StaticCandidateIndex,
    VersionedScoreCache,
    WorldCache,
    choose_execution_plan,
    benchmark_mmap_concurrency,
    build_mmap_autotune_policy,
    tune_mmap_source_batch,
    progressive_top_k_from_scores,
    progressive_top_k_from_dense_scores,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class QueryTests(unittest.TestCase):
    def test_learned_low_rank_covariance_artifact_is_queryable(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            artifact = Path(temp_dir) / "operator.npz"
            entities = np.asarray(["s", "good", "bad"])
            means = np.asarray([[0.0, 0.0], [0.1, 0.0], [2.0, 2.0]])
            factors = np.zeros((3, 2, 1))
            residuals = np.full((3, 2), 0.1)
            metadata = {
                "format": "pkgea-learned-low-rank-covariance-v1",
                "source_count": 1,
            }
            np.savez_compressed(
                artifact,
                entities=entities,
                means=means,
                factors=factors,
                diagonal_residuals=residuals,
                metadata=np.asarray(json.dumps(metadata)),
            )
            index = LearnedLowRankCovarianceIndex.from_artifact(artifact)
            result = index.query("s")
            self.assertEqual(result.top_k[0].candidate, "good")
            self.assertEqual(result.candidate_count, 2)

    def test_planner_executes_validated_low_rank_artifact(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            artifact = Path(temp_dir) / "operator.npz"
            metadata = json.loads(
                (TOY / "confidence_metadata.json").read_text(encoding="utf-8")
            )
            operator_metadata = {
                "format": "pkgea-learned-low-rank-covariance-v2",
                "dataset_id": metadata["dataset_id"],
                "dataset_revision": dataset_revision_digest(TOY),
                "checkpoint_sha256": "a" * 64,
                "source_count": 1,
                "validation_mean_relative_distance_error": 0.01,
                "validation_winner_agreement": 1.0,
            }
            np.savez_compressed(
                artifact,
                entities=np.asarray(
                    ["s:alice", "t:alice", "t:bob", "t:city"]
                ),
                means=np.asarray(
                    [[0.0, 0.0], [0.1, 0.0], [1.0, 1.0], [2.0, 2.0]]
                ),
                factors=np.zeros((4, 2, 1)),
                diagonal_residuals=np.full((4, 2), 0.1),
                metadata=np.asarray(json.dumps(operator_metadata)),
            )
            report = run_planned_batch_queries(
                TOY,
                ["s:alice"],
                latency_budget=20.0,
                target_absolute_error=0.02,
                distributional_validation_error=0.01,
                distributional_operator="learned_low_rank",
                distributional_artifact=artifact,
            )
            self.assertEqual(
                report["executed_operator"],
                "distributional_low_rank",
            )
            self.assertTrue(report["planner_matches_executed_operator"])
            self.assertEqual(
                report["queries"][0]["top_k"][0]["candidate"],
                "t:alice",
            )

    def test_learned_operator_rejects_stale_dataset_revision(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            artifact = Path(temp_dir) / "stale.npz"
            dataset_metadata = json.loads(
                (TOY / "confidence_metadata.json").read_text(encoding="utf-8")
            )
            np.savez_compressed(
                artifact,
                entities=np.asarray(["s:alice", "t:alice"]),
                means=np.asarray([[0.0, 0.0], [0.0, 0.0]]),
                factors=np.zeros((2, 2, 1)),
                diagonal_residuals=np.full((2, 2), 0.1),
                metadata=np.asarray(
                    json.dumps(
                        {
                            "format": (
                                "pkgea-learned-low-rank-covariance-v2"
                            ),
                            "dataset_id": dataset_metadata["dataset_id"],
                            "dataset_revision": "0" * 64,
                            "checkpoint_sha256": "a" * 64,
                            "source_count": 1,
                        }
                    )
                ),
            )
            with self.assertRaisesRegex(ValueError, "stale"):
                run_learned_covariance_queries(
                    TOY,
                    artifact,
                    ["s:alice"],
                )

    def test_static_attribute_bounds_never_prune_world_winner(self) -> None:
        import itertools

        backbone = AttributeStructuralBackbone.from_dataset(TOY)
        index = StaticCandidateIndex.from_attribute_backbone(backbone)
        for source in backbone.source_entities:
            selection = index.select(source, 1)
            for state in itertools.product(
                (False, True), repeat=len(backbone.triples)
            ):
                scores = backbone.score(state)
                winner = min(
                    backbone.target_entities,
                    key=lambda target: (-scores[(source, target)], target),
                )
                self.assertIn(winner, selection.candidates)

    def test_progressive_query_returns_expected_winner(self) -> None:
        report = run_toy_query(TOY, "s:alice", k=1, max_samples=256, seed=17)
        self.assertEqual(
            report["query"]["top_k"][0]["candidate"], "t:alice"
        )
        self.assertLessEqual(report["query"]["samples_used"], 256)

    def test_distributional_operator_returns_risk_metadata(self) -> None:
        report = run_distributional_queries(
            TOY, ["s:alice", "s:bob"], k=1
        )
        self.assertEqual(report["executed_operator"], "distributional")
        self.assertIn("distance_margin", report["queries"][0])
        self.assertGreater(report["analytic_incident_edge_passes"], 0)

    def test_planner_executes_distributional_choice(self) -> None:
        report = run_planned_batch_queries(
            TOY,
            ["s:alice"],
            k=1,
            max_samples=64,
            backbone_name="toy",
            target_absolute_error=0.1,
            latency_budget=20.0,
            distributional_validation_error=0.02,
        )
        self.assertEqual(report["planner"]["operator"], "distributional")
        self.assertEqual(report["executed_operator"], "distributional")
        self.assertTrue(report["planner_matches_executed_operator"])

    def test_planner_executes_sampling_choice(self) -> None:
        report = run_planned_batch_queries(
            TOY,
            ["s:alice"],
            k=1,
            max_samples=32,
            backbone_name="toy",
            target_absolute_error=0.01,
            latency_budget=20.0,
        )
        self.assertEqual(report["planner"]["operator"], "adaptive_sampling")
        self.assertEqual(report["executed_operator"], "adaptive_sampling")
        self.assertTrue(report["planner_matches_executed_operator"])

    def test_entropy_proxy_alone_cannot_authorize_distributional(self) -> None:
        plan = choose_execution_plan(
            QueryWorkload(
                uncertain_edges=100,
                candidate_count=1000,
                normalized_entropy=0.1,
                latency_budget=5000,
                target_absolute_error=0.1,
            )
        )
        self.assertEqual(plan.operator, "adaptive_sampling")

    def test_operator_comparison_reports_distinct_guarantees(self) -> None:
        report = run_query_operator_comparison(
            TOY,
            ["s:alice", "s:bob"],
            max_samples=32,
            backbone_name="toy",
        )
        self.assertGreaterEqual(report["winner_agreement"], 0.0)
        self.assertIn("distributional", report["guarantee_boundary"])
        self.assertIn("sampling", report["guarantee_boundary"])

    def test_world_cache_reuses_prefix(self) -> None:
        cache = WorldCache()
        probabilities = [0.8, 0.6]
        first, reused_first = cache.get(probabilities, 32, 17)
        second, reused_second = cache.get(probabilities, 16, 17)
        self.assertFalse(reused_first)
        self.assertTrue(reused_second)
        self.assertEqual(first[:16], second)

    def test_world_cache_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "worlds.json"
            cache = WorldCache()
            first, _ = cache.get([0.8, 0.6], 32, 17)
            cache.save(path)
            loaded = WorldCache.load(path)
            second, reused = loaded.get([0.8, 0.6], 16, 17)
            self.assertTrue(reused)
            self.assertEqual(first[:16], second)

    def test_score_cache_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "scores.json.gz"
            backbone = ToyStructuralBackbone.from_dataset(TOY)
            worlds = WorldCache().get([0.8, 0.6, 0.7, 0.9], 8, 17)[0]
            cache = ScoreCache()
            first, reused_first = cache.get(
                worlds,
                "toy",
                backbone.source_entities,
                backbone.target_entities,
                backbone.score,
            )
            cache.save(path)
            loaded = ScoreCache.load(path)
            second, reused_second = loaded.get(
                worlds,
                "toy",
                backbone.source_entities,
                backbone.target_entities,
                backbone.score,
            )
            self.assertFalse(reused_first)
            self.assertTrue(reused_second)
            self.assertEqual(first, second)

    def test_memory_mapped_score_index_reads_exact_rectangle(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            backbone = ToyStructuralBackbone.from_dataset(TOY)
            worlds = WorldCache().get([0.8, 0.6, 0.7, 0.9], 8, 17)[0]
            cache = ScoreCache()
            matrices, _ = cache.get(
                worlds,
                "toy",
                backbone.source_entities,
                backbone.target_entities,
                backbone.score,
                context_digest="revision-1",
            )
            directory = Path(temp_dir) / "mmap"
            index = MemoryMappedScoreIndex.create_from_score_cache(
                cache, directory
            )
            rectangle = index.rectangle(
                backbone.source_entities[:1],
                backbone.target_entities[:2],
                world_start=1,
                world_stop=4,
            )
            self.assertEqual(rectangle.shape, (3, 1, 2))
            for world_offset, world_index in enumerate(range(1, 4)):
                for target_index, target in enumerate(
                    backbone.target_entities[:2]
                ):
                    self.assertAlmostEqual(
                        float(rectangle[world_offset, 0, target_index]),
                        matrices[world_index][
                            (backbone.source_entities[0], target)
                        ],
                        places=6,
                    )
            mapping_query = progressive_top_k_from_scores(
                matrices,
                backbone.source_entities[0],
                backbone.target_entities,
                k=1,
                batch_size=2,
                bound_method="empirical_bernstein",
            )
            mmap_query = index.progressive_top_k(
                backbone.source_entities[0],
                backbone.target_entities,
                k=1,
                batch_size=2,
                bound_method="empirical_bernstein",
            )
            self.assertEqual(
                mapping_query.top_k[0].candidate,
                mmap_query.top_k[0].candidate,
            )
            self.assertEqual(mapping_query.samples_used, mmap_query.samples_used)
            self.assertEqual(mapping_query.stable, mmap_query.stable)
            with self.assertRaisesRegex(ValueError, "stale"):
                MemoryMappedScoreIndex.load(
                    directory,
                    expected_context_digest="revision-2",
                    verify_checksum=False,
                )
            index.close()

    def test_mmap_concurrency_benchmark_keeps_index_open_for_batches(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            backbone = ToyStructuralBackbone.from_dataset(TOY)
            worlds = WorldCache().get([0.8, 0.6, 0.7, 0.9], 4, 17)[0]
            cache = ScoreCache()
            cache.get(
                worlds,
                "toy",
                backbone.source_entities,
                backbone.target_entities,
                backbone.score,
                context_digest="revision-1",
            )
            directory = Path(temp_dir) / "mmap"
            index = MemoryMappedScoreIndex.create_from_score_cache(
                cache, directory
            )
            index.close()

            result = benchmark_mmap_concurrency(
                directory,
                reader_counts=(1, 2),
                world_counts=(2,),
                query_count=4,
                repeats=1,
            )

            self.assertEqual(len(result["results"]), 2)
            self.assertTrue(
                all(row["checksum_consistent"] for row in result["results"])
            )
            self.assertGreaterEqual(len(result["source_batch_results"]), 1)
            self.assertTrue(
                all(
                    row["checksum_consistent"]
                    for row in result["source_batch_results"]
                )
            )

    def test_mmap_source_batch_autotuning_returns_a_valid_choice(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            backbone = ToyStructuralBackbone.from_dataset(TOY)
            worlds = WorldCache().get([0.8, 0.6, 0.7, 0.9], 4, 17)[0]
            cache = ScoreCache()
            cache.get(
                worlds,
                "toy",
                backbone.source_entities,
                backbone.target_entities,
                backbone.score,
                context_digest="revision-1",
            )
            directory = Path(temp_dir) / "mmap"
            index = MemoryMappedScoreIndex.create_from_score_cache(
                cache, directory
            )
            index.close()

            result = tune_mmap_source_batch(
                directory,
                world_count=2,
                batch_sizes=(1, 2, 99),
                calibration_queries=5,
                repeats=1,
            )

            self.assertIn(result["recommended_source_batch_size"], (1, 2))
            self.assertEqual(
                [row["batch_size"] for row in result["results"]], [1, 2]
            )
            self.assertTrue(
                all(row["checksum_consistent"] for row in result["results"])
            )

    def test_mmap_autotune_policy_is_revision_bound_and_shape_exact(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            backbone = ToyStructuralBackbone.from_dataset(TOY)
            worlds = WorldCache().get([0.8, 0.6, 0.7, 0.9], 4, 17)[0]
            cache = ScoreCache()
            cache.get(
                worlds,
                "toy",
                backbone.source_entities,
                backbone.target_entities,
                backbone.score,
                context_digest="revision-1",
            )
            directory = root / "mmap"
            index = MemoryMappedScoreIndex.create_from_score_cache(
                cache, directory
            )
            index.close()
            tuning = tune_mmap_source_batch(
                directory,
                world_count=2,
                batch_sizes=(1, 2),
                calibration_queries=4,
                repeats=1,
            )
            tuning_path = root / "tuning.json"
            tuning_path.write_text(json.dumps(tuning), encoding="utf-8")
            policy_path = root / "policy.json"
            build_mmap_autotune_policy(
                directory, [tuning_path], output_path=policy_path
            )
            policy = MMapAutotunePolicy.load(policy_path, directory)
            self.assertTrue(policy.select(2)["calibrated"])
            self.assertIn(policy.select(2)["source_batch_size"], (1, 2))
            self.assertFalse(policy.select(3)["calibrated"])
            self.assertEqual(policy.select(3)["source_batch_size"], 1)

    def test_versioned_score_cache_rejects_stale_revision(self) -> None:
        backbone = ToyStructuralBackbone.from_dataset(TOY)
        worlds = WorldCache().get([0.8, 0.6, 0.7, 0.9], 4, 17)[0]
        guarded = VersionedScoreCache(active_revision="revision-1")
        _, reused = guarded.get(
            "revision-1",
            worlds,
            "toy",
            backbone.source_entities,
            backbone.target_entities,
            backbone.score,
        )
        self.assertFalse(reused)
        guarded.advance("revision-2")
        with self.assertRaises(StaleCacheRevisionError):
            guarded.get(
                "revision-1",
                worlds,
                "toy",
                backbone.source_entities,
                backbone.target_entities,
                backbone.score,
            )
        _, reused_new = guarded.get(
            "revision-2",
            worlds,
            "toy",
            backbone.source_entities,
            backbone.target_entities,
            backbone.score,
        )
        self.assertFalse(reused_new)

    def test_precomputed_scores_are_shared(self) -> None:
        backbone = ToyStructuralBackbone.from_dataset(TOY)
        scores = [backbone.score((True, True, True, True))] * 16
        result = progressive_top_k_from_scores(
            scores,
            "s:alice",
            backbone.target_entities,
            k=1,
            batch_size=8,
        )
        self.assertEqual(result.top_k[0].candidate, "t:alice")

    def test_dense_progressive_scores_match_mapping_path(self) -> None:
        candidates = ("a", "b", "c")
        mappings = [
            {
                ("s", "a"): 0.8 + 0.01 * (index % 2),
                ("s", "b"): 0.4,
                ("s", "c"): 0.2,
            }
            for index in range(128)
        ]
        dense = [
            [row[("s", candidate)] for candidate in candidates]
            for row in mappings
        ]
        mapping_result = progressive_top_k_from_scores(
            mappings,
            "s",
            candidates,
            k=1,
            batch_size=16,
            bound_method="empirical_bernstein",
        )
        dense_result = progressive_top_k_from_dense_scores(
            dense,
            "s",
            candidates,
            k=1,
            batch_size=16,
            bound_method="empirical_bernstein",
        )
        self.assertEqual(mapping_result, dense_result)

    def test_empirical_bernstein_bound_uses_same_score_prefix(self) -> None:
        scores = [
            {
                ("s", "a"): 0.9,
                ("s", "b"): 0.1,
            }
            for _ in range(128)
        ]
        result = progressive_top_k_from_scores(
            scores,
            "s",
            ("a", "b"),
            k=1,
            batch_size=16,
            bound_method="empirical_bernstein",
        )
        self.assertEqual(result.top_k[0].candidate, "a")
        self.assertEqual(result.bound_method, "empirical_bernstein")
        self.assertTrue(result.stable)

    def test_paired_margin_exploits_common_world_correlation(self) -> None:
        scores = []
        for index in range(2048):
            shared = 0.4 if index % 2 else 0.0
            scores.append(
                {
                    ("s", "a"): 0.55 + shared,
                    ("s", "b"): 0.45 + shared,
                }
            )
        marginal = progressive_top_k_from_scores(
            scores,
            "s",
            ("a", "b"),
            k=1,
            batch_size=16,
            bound_method="empirical_bernstein",
        )
        paired = progressive_top_k_from_scores(
            scores,
            "s",
            ("a", "b"),
            k=1,
            batch_size=16,
            bound_method="paired_empirical_bernstein",
        )
        self.assertTrue(paired.stable)
        self.assertLess(paired.samples_used, marginal.samples_used)
        self.assertEqual(paired.top_k[0].candidate, "a")

    def test_batch_queries_share_and_persist_cache(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "worlds.json"
            score_path = Path(temp_dir) / "scores.json.gz"
            first = run_batch_queries(
                TOY,
                ["s:alice", "s:bob"],
                max_samples=64,
                cache_path=path,
                score_cache_path=score_path,
            )
            second = run_batch_queries(
                TOY,
                ["s:city"],
                max_samples=64,
                cache_path=path,
                score_cache_path=score_path,
            )
            self.assertEqual(first["cache_hits"], 1)
            self.assertEqual(second["cache_hits"], 1)
            self.assertIn("mean_query_elapsed_seconds", first)
            self.assertEqual(first["common_shock_probability"], 0.0)
            self.assertFalse(first["persistent_score_cache_hit"])
            self.assertTrue(second["persistent_score_cache_hit"])

    def test_planner_selects_exact_when_feasible(self) -> None:
        plan = choose_execution_plan(
            QueryWorkload(
                uncertain_edges=4,
                candidate_count=3,
                normalized_entropy=0.7,
                latency_budget=1000,
                target_absolute_error=0.01,
            )
        )
        self.assertEqual(plan.operator, "exact")

    def test_planner_can_select_distributional(self) -> None:
        plan = choose_execution_plan(
            QueryWorkload(
                uncertain_edges=100,
                candidate_count=1000,
                normalized_entropy=0.1,
                latency_budget=5000,
                target_absolute_error=0.05,
                distributional_validation_error=0.02,
            )
        )
        self.assertEqual(plan.operator, "distributional")


if __name__ == "__main__":
    unittest.main()
