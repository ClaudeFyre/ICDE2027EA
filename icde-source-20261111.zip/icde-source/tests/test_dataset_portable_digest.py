"""Cross-machine reproducibility of dataset digests.

These reproduce, without a second machine, the two ways a dataset built on
Windows differed from the same dataset built on macOS: an absolute source path
in ``confidence_metadata.json`` and CRLF line endings from a text-mode write.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from pkgea.contracts import (
    dataset_content_digest,
    dataset_revision_digest,
    provenance_path,
)


ROOT = Path(__file__).resolve().parents[1]


def write_dataset(directory: Path, *, base_dataset: str, crlf: bool) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    rows = {
        "entities.tsv": "graph_id\tentity_id\tlabel\nsource\te1\tAlpha\n",
        "relations.tsv": "graph_id\trelation_id\tlabel\nsource\tr1\tlinks\n",
        "triples.tsv": (
            "graph_id\thead_id\trelation_id\ttail_id\tconfidence\tconfidence_type"
            "\tconfidence_source\tnormalization_method\ttimestamp"
            "\tdependency_group\tevidence_id\n"
            "source\te1\tr1\te1\t0.5\tcalibrated_probability\tsynthetic\tnone\t\t\t\n"
        ),
        "alignments.tsv": (
            "source_entity_id\ttarget_entity_id\tsplit\tconfidence\ne1\te1\ttest\t1.0\n"
        ),
    }
    for name, text in rows.items():
        (directory / name).write_text(text, encoding="utf-8", newline="\n")
    metadata = {
        "dataset_id": "portability-probe",
        "version": "0.1.0",
        "base_dataset": base_dataset,
        "probability_semantics": "synthetic",
    }
    body = json.dumps(metadata, ensure_ascii=False, indent=2) + "\n"
    (directory / "confidence_metadata.json").write_text(
        body.replace("\n", "\r\n") if crlf else body, encoding="utf-8", newline=""
    )
    return directory


def test_content_digest_survives_both_machine_differences(tmp_path: Path) -> None:
    posix_host = write_dataset(
        tmp_path / "posix",
        base_dataset="/Users/someone/pkgea/data/interim/base",
        crlf=False,
    )
    windows_host = write_dataset(
        tmp_path / "windows",
        base_dataset=r"E:\pkgea\data\interim\base",
        crlf=True,
    )
    assert dataset_content_digest(posix_host) == dataset_content_digest(windows_host)


@pytest.mark.parametrize(
    ("base_dataset", "crlf"),
    [(r"E:\pkgea\data\interim\base", False), ("/Users/someone/pkgea/base", True)],
)
def test_revision_digest_is_machine_specific_by_construction(
    tmp_path: Path, base_dataset: str, crlf: bool
) -> None:
    """The old digest still differs; that is why it is not the portable gate."""

    reference = write_dataset(
        tmp_path / "reference", base_dataset="/Users/someone/pkgea/base", crlf=False
    )
    other = write_dataset(tmp_path / "other", base_dataset=base_dataset, crlf=crlf)
    assert dataset_revision_digest(reference) != dataset_revision_digest(other)


def test_content_digest_still_tracks_real_content_changes(tmp_path: Path) -> None:
    original = write_dataset(tmp_path / "a", base_dataset="base", crlf=False)
    edited = write_dataset(tmp_path / "b", base_dataset="base", crlf=False)
    (edited / "triples.tsv").write_text(
        (edited / "triples.tsv").read_text(encoding="utf-8").replace("0.5", "0.6"),
        encoding="utf-8",
        newline="\n",
    )
    assert dataset_content_digest(original) != dataset_content_digest(edited)


def test_content_digest_covers_latent_truth(tmp_path: Path) -> None:
    original = write_dataset(tmp_path / "a", base_dataset="base", crlf=False)
    baseline = dataset_content_digest(original)
    (original / "latent_truth.tsv").write_text(
        "graph_id\thead_id\trelation_id\ttail_id\trealized\nsource\te1\tr1\te1\t1\n",
        encoding="utf-8",
        newline="\n",
    )
    assert dataset_content_digest(original) != baseline


def test_provenance_path_is_repo_relative_and_never_absolute() -> None:
    inside = provenance_path(ROOT / "data" / "interim" / "example")
    assert inside == "data/interim/example"
    outside = provenance_path(Path("/tmp/somewhere/else/example"))
    assert outside == "example"
    assert not Path(inside).is_absolute() and not Path(outside).is_absolute()


def test_generator_writes_host_neutral_metadata(tmp_path: Path) -> None:
    """The fixed writers must not put this machine into a generated dataset."""

    from pkgea.generators.uncertainty import (
        BenchmarkGeneratorConfig,
        generate_benchmark,
    )

    output = tmp_path / "generated"
    generate_benchmark(
        ROOT / "data" / "toy" / "exact_world_minimal",
        output,
        BenchmarkGeneratorConfig(mechanism="independent", seed=17),
    )
    raw = (output / "confidence_metadata.json").read_bytes()
    assert b"\r\n" not in raw
    base = json.loads(raw.decode("utf-8"))["base_dataset"]
    assert base == "data/toy/exact_world_minimal"
    assert not Path(base).is_absolute()
