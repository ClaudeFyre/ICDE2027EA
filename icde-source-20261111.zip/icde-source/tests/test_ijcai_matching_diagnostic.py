"""Counterexamples and isolation checks using only stdlib unittest and NumPy."""

import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import ijcai_matching_diagnostic as diagnostic


class MatchingDiagnosticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repository = Path(__file__).resolve().parents[1]
        cls.temp_root = (repository / "tmp" / "ijcai-unit").resolve()
        cls.temp_root.relative_to(repository)
        cls.temp_root.mkdir(parents=True, exist_ok=True)

    def test_global_matching_can_correct_a_collision_and_has_negative_margin(self):
        # Row 1 needs target 0 much more; sacrificing row 0's local winner is right.
        scores = np.array([[10.0, 9.0, 0.0], [9.0, 0.0, 0.0]])
        result = diagnostic.analyze_score_matrix(scores, np.array([1, 0]))
        matching = result["methods"]["hungarian_assigned_margin"]
        self.assertEqual(matching["prediction_columns_by_validation_row"], [1, 0])
        self.assertEqual(matching["confidence_by_validation_row"], [-1.0, 9.0])
        self.assertEqual(matching["eligible_rows_in_confidence_order"], [1, 0])
        self.assertEqual(result["hungarian_changes_vs_point"]["corrected_errors"], 1)
        self.assertEqual(result["hungarian_changes_vs_point"]["introduced_errors"], 0)
        self.assertEqual(result["point_target_conflicts"]["all_validation_rows"]["conflicting_row_pairs"], 1)
        self.assertEqual(result["methods"]["margin_skip_conflicts"]["eligible_rows_in_confidence_order"], [1])

    def test_maximum_total_score_can_introduce_a_truth_error(self):
        # The objective never sees labels: the same unique optimum can be harmful.
        scores = np.array([[10.0, 9.0, 0.0], [9.0, 0.0, 0.0]])
        result = diagnostic.analyze_score_matrix(scores, np.array([0, 1]))
        self.assertEqual(result["hungarian_changes_vs_point"]["introduced_errors"], 1)
        self.assertEqual(result["hungarian_changes_vs_point"]["corrected_errors"], 0)

    def test_point_ties_use_candidate_order_and_confidence_ties_use_row_order(self):
        scores = np.array([[5.0, 5.0, 0.0], [0.0, 4.0, 4.0]])
        result = diagnostic.analyze_score_matrix(scores, np.array([0, 1]))
        point = result["methods"]["point_margin"]
        self.assertEqual(point["prediction_columns_by_validation_row"], [0, 1])
        self.assertEqual(point["confidence_by_validation_row"], [0.0, 0.0])
        self.assertEqual(point["eligible_rows_in_confidence_order"], [0, 1])

    def test_empirical_envelope_can_recover_after_a_bad_earlier_prefix(self):
        value = diagnostic._summarize_method(
            np.array([0, 0, 2, 3]), np.array([4.0, 3.0, 2.0, 1.0]),
            np.array([0, 1, 2, 3]), np.arange(4), (0.25, 0.1),
        )
        self.assertEqual(value["curve"][2]["empirical_risk"], 0.5)
        self.assertEqual(value["empirical_maximum_prefix"]["0.25"]["accepted"], 4)
        self.assertEqual(value["empirical_maximum_prefix"]["0.1"]["accepted"], 1)
        self.assertIn("no risk guarantee", value["empirical_maximum_prefix"]["0.25"]["selection_role"])

    def test_all_wrong_predictions_have_empty_admissible_prefix(self):
        value = diagnostic._summarize_method(
            np.array([1, 0]), np.array([2.0, 1.0]), np.array([0, 1]), np.arange(2), (0.1,),
        )
        self.assertEqual(value["empirical_maximum_prefix"]["0.1"]["accepted"], 0)
        self.assertIsNone(value["empirical_maximum_prefix"]["0.1"]["empirical_risk"])

    def test_capture_stops_before_even_malformed_test_pairs(self):
        prefix = '{\n  "graph": "dw",\n  "model_seed": 17,\n'
        prefix += '  "validation_queries": 128,\n  "test_queries": 256,\n  "pairs": [\n'
        for row in range(128):
            prefix += f'    [\n      {row},\n      {1000 + row}\n    ],\n'
        tail = 'THIS_IS_NOT_JSON_AND_MUST_NOT_BE_PARSED_AS_TEST_LABELS\n'
        with tempfile.TemporaryDirectory(dir=self.temp_root) as directory:
            path = Path(directory) / "capture.json"
            path.write_bytes((prefix + tail).encode())
            metadata, pairs, manifest = diagnostic.read_validation_capture(path)
        self.assertEqual(metadata["graph"], "dw")
        self.assertEqual(pairs.shape, (128, 2))
        self.assertEqual(pairs[-1].tolist(), [127, 1127])
        self.assertEqual(manifest["bytes_read"], len(prefix.encode()))
        self.assertEqual(manifest["test_pairs_parsed"], 0)

    def test_npy_prefix_does_not_materialize_nonfinite_tail_or_open_worlds(self):
        array = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [np.nan] * 3, [np.nan] * 3])
        opened = []
        original_open = zipfile.ZipFile.open

        def recorded_open(archive, name, *args, **kwargs):
            opened.append(name)
            return original_open(archive, name, *args, **kwargs)

        with tempfile.TemporaryDirectory(dir=self.temp_root) as directory:
            archive_path = Path(directory) / "arrays.npz"
            np.savez_compressed(archive_path, point_scores=array, winners=np.full((5, 4), 65535))
            with patch.object(zipfile.ZipFile, "open", recorded_open):
                with zipfile.ZipFile(archive_path) as archive:
                    value, manifest = diagnostic.read_npy_prefix(
                        archive, "point_scores", expected_shape=(4, 3),
                        expected_dtype=np.dtype("float64"), prefix_rows=2,
                    )
        self.assertTrue(np.array_equal(value, array[:2]))
        self.assertTrue(np.isfinite(value).all())
        self.assertEqual(opened, ["point_scores.npy"])
        self.assertEqual(manifest["payload_bytes_returned"], 2 * 3 * 8)
        self.assertEqual(manifest["tail_array_elements_materialized"], 0)

    def test_cell_rejects_any_other_validation_row_count_without_reading_files(self):
        for validation_rows in (0, 64, 127, 129, 384):
            with self.subTest(validation_rows=validation_rows):
                with self.assertRaisesRegex(ValueError, "128"):
                    diagnostic.diagnose_cell("nonexistent", validation_rows=validation_rows)

    def test_validation_identity_rejects_duplicate_candidates_and_noninjective_truth(self):
        scores = np.zeros((128, 130))
        sources = np.arange(128, dtype=np.int64)
        targets = np.arange(1000, 1130, dtype=np.int64)
        pairs = np.column_stack((sources, targets[:128]))
        self.assertTrue(np.array_equal(diagnostic.validate_inputs(scores, sources, targets, pairs), np.arange(128)))
        duplicated_targets = targets.copy()
        duplicated_targets[-1] = duplicated_targets[0]
        with self.assertRaisesRegex(ValueError, "target IDs must be unique"):
            diagnostic.validate_inputs(scores, sources, duplicated_targets, pairs)
        repeated_truth = pairs.copy()
        repeated_truth[-1, 1] = repeated_truth[0, 1]
        with self.assertRaisesRegex(ValueError, "truth must be injective"):
            diagnostic.validate_inputs(scores, sources, targets, repeated_truth)
        with self.assertRaisesRegex(ValueError, "pair order"):
            diagnostic.validate_inputs(scores, sources[::-1], targets, pairs)

    def test_npy_reader_rejects_wrong_dtype_and_fortran_layout(self):
        variants = (
            ("float32", np.zeros((4, 3), dtype=np.float32)),
            ("fortran", np.asfortranarray(np.zeros((4, 3)))),
        )
        for name, array in variants:
            with self.subTest(layout=name):
                with tempfile.TemporaryDirectory(dir=self.temp_root) as directory:
                    path = Path(directory) / "wrong.npz"
                    np.savez_compressed(path, point_scores=array)
                    with zipfile.ZipFile(path) as archive:
                        with self.assertRaisesRegex(ValueError, "dtype or array order"):
                            diagnostic.read_npy_prefix(
                                archive, "point_scores", expected_shape=(4, 3),
                                expected_dtype=np.dtype("float64"), prefix_rows=2,
                            )

    def test_missing_truth_candidate_and_nonfinite_validation_are_rejected(self):
        scores = np.zeros((128, 130))
        sources = np.arange(128, dtype=np.int64)
        targets = np.arange(1000, 1130, dtype=np.int64)
        pairs = np.column_stack((sources, targets[:128]))
        missing = pairs.copy()
        missing[-1, 1] = 999999
        with self.assertRaisesRegex(ValueError, "missing from candidate"):
            diagnostic.validate_inputs(scores, sources, targets, missing)
        scores[0, 0] = np.nan
        with self.assertRaisesRegex(ValueError, "finite"):
            diagnostic.validate_inputs(scores, sources, targets, pairs)

    def test_aggregation_preserves_graph_groups_and_labels_descriptive_role(self):
        scores = np.array([[10.0, 9.0, 0.0], [9.0, 0.0, 0.0]])
        corrected = diagnostic.analyze_score_matrix(scores, np.array([1, 0]))
        harmed = diagnostic.analyze_score_matrix(scores, np.array([0, 1]))
        cells = [
            {"cell_id": "dw_s17", "graph": "dw", **corrected},
            {"cell_id": "enfr_s17", "graph": "enfr", **harmed},
        ]
        summary = diagnostic.aggregate_cells(cells)
        self.assertFalse(summary["risk_guarantee"])
        self.assertEqual(summary["per_graph"]["dw"]["cell_count"], 1)
        self.assertEqual(summary["per_graph"]["enfr"]["cell_count"], 1)
        self.assertEqual(summary["overall_unweighted_cells"]["cell_count"], 2)
        matching = summary["overall_unweighted_cells"]["methods"]["hungarian_assigned_margin"]["0.05"]
        self.assertEqual(matching["mean_coverage"], 0.5)
        self.assertEqual(matching["mean_paired_coverage_gain_vs_point"], 0.25)
        with self.assertRaisesRegex(ValueError, "uniquely"):
            diagnostic.aggregate_cells([cells[0], cells[0]])


if __name__ == "__main__":
    unittest.main()
