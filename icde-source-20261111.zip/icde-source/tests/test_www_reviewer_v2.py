"""Regression checks for missing matching time and rounded high-precision winners."""
import sys
import time
from pathlib import Path
import mpmath as mp
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(ROOT/'src'))
import www_highprecision_reference_v2 as hp
import run_www_reviewer_e3_v2 as timing
import run_www_reviewer_stress_v2 as stress


def test_high_precision_subtraction_and_winner_survive_float_rounding():
    with mp.workdps(60):
        value=hp.w2([1.],[[0.]],[1e16],[[0.]])
        assert value==mp.mpf(10)**16-1
        distances,winner,gap=hp.distances_and_winner([2**-54],[[0.]],[[-1.],[1.]],[[[0.]],[[0.]]])
        assert float(distances[0])==float(distances[1])
        assert winner==1 and gap==mp.mpf(2)**-53


def test_end_to_end_timer_includes_matching(monkeypatch):
    def matcher(*args):
        time.sleep(.02)
        return np.array([[1.,4.]])
    monkeypatch.setattr(timing,'gaussian_distance_matrix',matcher)
    row=timing.timed_query(np.ones(2),np.eye(2),np.zeros((2,2)),np.stack([np.eye(2)]*2),None,None,reference=True)
    assert row['served_answer']==0 and row['state']=='full_reference'
    assert row['phases']['compressed_match']>=.018
    assert row['phases']['total']>=row['phases']['compressed_match']


def test_fp16_stress_refines_against_full_means(tmp_path,monkeypatch):
    # Preserve module global directories after the synthetic stress helper.
    for name in ('PAYLOAD_DIR','BOUNDS_DIR','BACKING_DIR'):
        monkeypatch.setattr(stress.srv,name,getattr(stress.srv,name))
    case=next(c for c in stress.cases() if c[0]=='fp16_mean_flip')
    row=stress.execute_case(*case,tmp_path)
    assert row['serving']['compressed_winner']==0
    assert row['numeric_reference_winner']==1
    assert row['serving']['state']=='refined'
    assert row['serving']['served_answer']==1
    assert len(row['inputs']['query_mean'])==16
    assert row['bounds_cover_distortion_plus_observed_runtime_error']


def test_timed_refinement_matches_real_contract(tmp_path,monkeypatch):
    from run_www_equal_budget import full_payload,load_full_payload
    from www_budget_frontier import target_distortions
    for name in ('PAYLOAD_DIR','BOUNDS_DIR','BACKING_DIR'):
        monkeypatch.setattr(stress.srv,name,tmp_path/name)
    tm=np.zeros((3,16));tm[:,0]=[1.0004,1.0002,3.]
    tc=np.zeros((3,16,16));qm=np.zeros(16);qc=np.zeros((16,16))
    full=full_payload(tm,tc,dtype=np.float32);fm,fc=load_full_payload(full)
    front=full_payload(fm,fc,dtype=np.float16);im,ic=load_full_payload(front)
    info=stress.srv.build_backing(cell='cell',full_payload=full,targets=('0','1','2'),extra_metadata={})
    store=stress.srv.open_backing('cell',body_sha256=info['body_sha256'])
    deltas=stress.srv.outward_float32(target_distortions(fm,fc,im,ic)).astype(np.float64)
    result=timing.timed_query(qm,qc,im,ic,deltas,store)
    assert result['state']=='refined' and result['served_answer']==1
    assert result['records_read']==2 and store.bytes_read==2*612
    assert result['phases']['total']>=sum(v for k,v in result['phases'].items() if k!='total')
