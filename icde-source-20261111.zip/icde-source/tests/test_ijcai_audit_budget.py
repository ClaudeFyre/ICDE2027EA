"""Finite-population checks using only the standard-library test runner."""

from __future__ import annotations

import itertools
import sys
import unittest
from fractions import Fraction
from math import comb
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.ijcai_audit_budget import (
    allocate_label_budget,
    as_fraction,
    build_budget_report,
    minimum_bad_errors,
    minimum_fixed_time_audit,
    run_budget_precheck,
    scan_audit_budget,
    zero_error_pvalue,
)


class AuditBudgetTests(unittest.TestCase):
    def test_decimal_risk_boundary_is_exact(self) -> None:
        self.assertEqual(as_fraction(0.1), Fraction(1, 10))
        self.assertEqual(minimum_bad_errors(100, 0.1), 11)
        self.assertEqual(minimum_bad_errors(60, "0.05"), 4)

    def test_pvalue_matches_all_small_population_sample_subsets(self) -> None:
        for population in range(2, 9):
            for audited in range(population):
                for alpha in (Fraction(1, 4), Fraction(1, 2)):
                    with self.subTest(population=population, audited=audited, alpha=alpha):
                        errors = minimum_bad_errors(population - audited, alpha)
                        subsets = tuple(itertools.combinations(range(population), audited))
                        zero_count = sum(
                            not any(index < errors for index in sample) for sample in subsets
                        )
                        enumerated = Fraction(zero_count, len(subsets))
                        self.assertEqual(zero_error_pvalue(population, audited, alpha), enumerated)

    def test_small_population_fixed_time_bad_release_probability_is_controlled(self) -> None:
        # Enumerate audit subsets for each fixed truth error count.  Errors are
        # fixed on the first K identities; labels need not be i.i.d.
        delta = Fraction(1, 5)
        for population in range(2, 9):
            for audited in range(1, population):
                for alpha in (Fraction(1, 4), Fraction(1, 2)):
                    if zero_error_pvalue(population, audited, alpha) > delta:
                        continue
                    for errors in range(population + 1):
                        with self.subTest(
                            population=population, audited=audited, alpha=alpha, errors=errors
                        ):
                            bad_releases = 0
                            for sample in itertools.combinations(range(population), audited):
                                observed = sum(index < errors for index in sample)
                                remaining_errors = errors - observed
                                bad = Fraction(remaining_errors, population - audited) > alpha
                                bad_releases += int(observed == 0 and bad)
                            self.assertLessEqual(
                                Fraction(bad_releases, comb(population, audited)), delta
                            )

    def test_128_reference_first_pass_is_67_and_feasibility_is_not_monotone(self) -> None:
        reference = minimum_fixed_time_audit(128)
        self.assertEqual(reference["first_feasible_audit_n"], 67)
        self.assertEqual(reference["auto_remaining"], 61)
        report = scan_audit_budget(128, 127)
        self.assertEqual(report["scanned_n_count"], 127)
        self.assertEqual(report["first_feasible_audit_n"], 67)
        self.assertEqual(report["maximum_certifiable_auto_remaining"], 61)
        self.assertIn(67, report["feasible_audit_ns"])
        self.assertIn(68, report["feasible_audit_ns"])
        self.assertNotIn(69, report["feasible_audit_ns"])
        self.assertIn(
            {"from_audit_n": 68, "to_audit_n": 69}, report["pass_to_fail_transitions"]
        )
        self.assertGreater(
            zero_error_pvalue(128, 69, "0.05"), zero_error_pvalue(128, 68, "0.05")
        )

    def test_budget_and_epoch_costs_count_all_queried_identities(self) -> None:
        allocation = allocate_label_budget(128, "0.1", "0.25", epochs=2)
        self.assertEqual(allocation["total_label_budget"], 13)
        self.assertEqual(allocation["repair_label_budget"], 3)
        self.assertEqual(allocation["audit_label_budget_total"], 10)
        self.assertEqual(allocation["audit_label_budget_by_epoch"], [5, 5])
        self.assertEqual(allocation["population_after_repair"], 125)
        self.assertEqual(allocation["minimum_remaining_if_all_budget_spent"], 115)
        odd = allocate_label_budget(128, "0.02", 0, epochs=2)
        self.assertEqual(odd["total_label_budget"], 3)
        self.assertEqual(odd["audit_label_budget_by_epoch"], [2, 1])

    def test_bonferroni_protects_family_inspection_times_and_epochs(self) -> None:
        result = scan_audit_budget(128, 10, policy_count=4, protect_all_checks=True, epochs=2)
        self.assertEqual(Fraction(result["per_test_delta"]["fraction"]), Fraction(1, 1600))
        self.assertEqual(result["protected_check_count"], 10)
        fixed = scan_audit_budget(128, 10, policy_count=4, epochs=2)
        self.assertEqual(Fraction(fixed["per_test_delta"]["fraction"]), Fraction(1, 160))
        self.assertEqual(fixed["protected_check_count"], 1)

    def test_empty_release_and_zero_budget_never_count_as_certified(self) -> None:
        empty = scan_audit_budget(2, 2)
        self.assertEqual(empty["empty_release_audit_n"], 2)
        self.assertEqual(empty["scanned_n_count"], 1)
        self.assertEqual(empty["maximum_certifiable_auto_remaining"], 0)
        zero = scan_audit_budget(128, 0)
        self.assertFalse(zero["feasible"])
        self.assertIsNone(zero["first_feasible_audit_n"])
        self.assertEqual(zero["scanned_n_count"], 0)
        with self.assertRaisesRegex(ValueError, "nonempty"):
            zero_error_pvalue(2, 2, "0.05")

    def test_report_epochs_remove_prior_paid_labels_and_share_total_delta(self) -> None:
        plan = {
            "stages": [{
                "id": "B0", "batch_sizes": [128], "policy_family_sizes": [1],
                "budget_fractions": [0.1],
            }],
            "decision_contract": {"exploratory_alpha": [0.05], "delta": 0.05},
        }
        report = build_budget_report(plan)
        self.assertEqual(report["summary"]["rows"], 16)
        chosen = next(
            row for row in report["rows"]
            if row["epochs"] == 2 and row["repair_share"] == "0"
            and row["inspection_mode"] == "all_budgeted_looks_bonferroni"
        )
        first, second = chosen["epoch_summaries"]
        self.assertEqual(chosen["audit_label_budget_by_epoch"], [7, 6])
        self.assertEqual(first["population_before_current_audit"], 128)
        self.assertEqual(second["population_before_current_audit"], 121)
        self.assertEqual(second["prior_audit_labels_removed"], 7)
        self.assertEqual(Fraction(first["per_test_delta"]["fraction"]), Fraction(1, 280))
        self.assertEqual(Fraction(second["per_test_delta"]["fraction"]), Fraction(1, 240))
        self.assertEqual(first["scanned_n_count"], 7)
        self.assertEqual(second["scanned_n_count"], 6)
        self.assertNotIn("n_scan", second)

    def test_frozen_driver_protocol_interface_honors_its_grid(self) -> None:
        report = run_budget_precheck({
            "batch_sizes": [128],
            "policy_family_sizes": [1],
            "risk_levels": ["0.05"],
            "delta": "0.05",
            "total_label_budget_fractions": ["0.1"],
            "repair_budget_fractions": ["0.25"],
            "epochs": [2],
            "inspection_modes": ["single_fixed_look"],
        })
        self.assertEqual(len(report["rows"]), 1)
        row = report["rows"][0]
        self.assertEqual(row["repair_label_budget"], 3)
        self.assertEqual(row["audit_label_budget_by_epoch"], [5, 5])
        self.assertEqual(row["inspection_mode"], "single_fixed_look")
        self.assertFalse(row["final_epoch_feasible"])
        self.assertEqual(
            report["minimum_fixed_time_references"][0]["first_feasible_audit_n"], 67
        )

    def test_invalid_population_audit_or_risk_is_rejected(self) -> None:
        for arguments in ((0, 0, ".05"), (3, -1, ".05"), (3, 1, 0), (3, 1, 1)):
            with self.subTest(arguments=arguments):
                with self.assertRaises(ValueError):
                    zero_error_pvalue(*arguments)


if __name__ == "__main__":
    unittest.main()
