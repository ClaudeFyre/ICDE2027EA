from __future__ import annotations

import sys
import unittest
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "src", ROOT / "scripts", ROOT / "scripts" / "backbones"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from www_encoder_adapters import (
    load_distributional_encoder,
    registered_checkpoint_formats,
)


class WWWEncoderAdapterTests(unittest.TestCase):
    def test_registered_formats_are_explicit(self) -> None:
        self.assertEqual(
            registered_checkpoint_formats(),
            (
                "pkgea-torch-gcn-align-v1",
                "pkgea-torch-relation-contrastive-v1",
            ),
        )

    def test_unknown_format_fails_with_expected_formats(self) -> None:
        with self.assertRaisesRegex(ValueError, "unregistered.*expected one of"):
            load_distributional_encoder({"format": "unknown-silent-fallback"})

    def test_real_relation_checkpoint_loads_and_encodes(self) -> None:
        checkpoint = torch.load(
            ROOT / "nodes/03_wsdm/checkpoints/relation_align_dw_s17.pt",
            map_location="cpu",
            weights_only=False,
        )
        adapter = load_distributional_encoder(checkpoint)
        self.assertEqual(
            adapter.descriptor_adapter_id,
            "pkgea/torch-relation-contrastive-v1",
        )
        self.assertEqual(
            adapter.normalization_family,
            "active_edge_weighted_node_mean_plus_row_l2",
        )
        weights = torch.tensor(checkpoint["probabilities"], dtype=torch.float32)
        with torch.no_grad():
            embeddings = adapter.encode(weights)
        self.assertEqual(embeddings.shape[0], len(checkpoint["entity_ids"]))
        self.assertEqual(embeddings.shape[1], checkpoint["dimension"])
        self.assertTrue(torch.isfinite(embeddings).all())


if __name__ == "__main__":
    unittest.main()
