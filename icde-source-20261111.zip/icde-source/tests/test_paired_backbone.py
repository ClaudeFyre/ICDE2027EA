from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.experiments import run_paired_backbone_comparison
from pkgea.generators import BenchmarkGeneratorConfig, generate_benchmark


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class PairedBackboneTests(unittest.TestCase):
    def test_common_random_number_report(self) -> None:
        result = run_paired_backbone_comparison(
            TOY,
            sample_count=32,
            seeds=[11, 17],
        )
        self.assertEqual(len(result["runs"]), 2)
        self.assertIn("paired_standard_error", result["aggregate"])
        self.assertGreaterEqual(
            result["aggregate"]["variance_ratio_paired_over_unpaired"], 0.0
        )

    def test_correlated_metadata_reaches_paired_world_stream(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            dataset = Path(temp_dir) / "correlated"
            generate_benchmark(
                TOY,
                dataset,
                BenchmarkGeneratorConfig(
                    mechanism="structural_correlated",
                    shared_strength=0.55,
                    seed=17,
                ),
            )
            result = run_paired_backbone_comparison(
                dataset, sample_count=16, seeds=[17]
            )
            self.assertEqual(result["common_shock_probability"], 0.55)
            self.assertEqual(
                result["edge_dependence_assumption"], "grouped_shared_latent"
            )


if __name__ == "__main__":
    unittest.main()
