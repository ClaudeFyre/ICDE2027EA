"""Regression for the received comparator's dictionary/string hash mix-up."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path


SPEC = importlib.util.spec_from_file_location(
    "handoff_comparison", Path(__file__).resolve().parents[1] / "scripts/check_icde_handoff_vs_repo.py"
)
MOD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)


def test_metadata_hash_and_newline_categories_are_distinct(tmp_path):
    bundle = tmp_path / "bundle"
    repo = tmp_path / "repo"
    bundle.mkdir()
    repo.mkdir()
    references = {"same.py": b"x=1\n", "crlf.py": b"x=1\n", "changed.py": b"x=1\n", "missing.py": b"x=1\n"}
    files = {}
    for name, raw in references.items():
        (bundle / name).write_bytes(raw)
        files[name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
    (bundle / "HANDOFF_MANIFEST.json").write_text(json.dumps({"files": files}))
    (repo / "same.py").write_bytes(b"x=1\n")
    (repo / "crlf.py").write_bytes(b"x=1\r\n")
    (repo / "changed.py").write_bytes(b"x=2\n")
    out = MOD.compare(bundle, repo)
    assert out["counts"] == {"byte_equal": 1, "newline_only": 1, "content_different": 1, "missing": 1}
    assert all(isinstance(r["expected_sha256"], str) for r in out["files"])


def test_binary_bytes_are_never_newline_normalized():
    assert MOD.classify(b"a\n", b"a\r\n", "block.bin") == "content_different"
