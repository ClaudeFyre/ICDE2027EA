from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import AttributeStructuralBackbone


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class AttributeBackboneTests(unittest.TestCase):
    def test_matching_attributes_override_encoded_labels(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            dataset = Path(temp_dir) / "dataset"
            dataset.mkdir()
            for filename in (
                "entities.tsv",
                "relations.tsv",
                "triples.tsv",
                "alignments.tsv",
                "confidence_metadata.json",
            ):
                (dataset / filename).write_bytes((TOY / filename).read_bytes())
            (dataset / "attributes.tsv").write_text(
                "graph_id\tentity_id\tattribute_id\tvalue\n"
                "source\ts:alice\tname\tAlice Example\n"
                "target\tt:alice\tlabel\tAlice Example\n"
                "target\tt:bob\tlabel\tDifferent Person\n",
                encoding="utf-8",
            )
            backbone = AttributeStructuralBackbone.from_dataset(dataset)
            scores = backbone.score(tuple(True for _ in backbone.triples))
            self.assertGreater(
                scores[("s:alice", "t:alice")],
                scores[("s:alice", "t:bob")],
            )


if __name__ == "__main__":
    unittest.main()
