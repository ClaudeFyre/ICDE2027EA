"""Safety and mathematical checks for the saved-stream feasibility module."""

import json
import math
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import vldb_stream_frontier_v0 as frontier


class StreamFrontierTests(unittest.TestCase):
    def test_product_bound_tracks_scope_and_preserves_zero_cases(self):
        self.assertEqual(frontier.independent_product_tv_bound(0, 100), 0)
        self.assertEqual(frontier.independent_product_tv_bound(0.2, 0), 0)
        self.assertEqual(frontier.independent_product_tv_bound(1, 5), 1)
        self.assertAlmostEqual(frontier.independent_product_tv_bound(0.1, 2), 0.19)
        local = frontier.independent_product_tv_bound(1e-7, 100)
        full = frontier.independent_product_tv_bound(1e-7, 10_000)
        self.assertGreater(full, local)
        self.assertGreater(local, 0)
        self.assertLessEqual(full, 10_000 * 1e-7)

    def test_invalid_assumed_error_or_scope_is_rejected(self):
        for tau, size in ((-0.1, 4), (1.1, 4), (math.nan, 4), (0.1, -1), (0.1, True)):
            with self.subTest(tau=tau, size=size):
                with self.assertRaises(ValueError):
                    frontier.independent_product_tv_bound(tau, size)

    def test_larger_epsilon_cannot_certify_earlier(self):
        settings = frontier._settings({"epsilon_grid": [0, 0.1, 0.25, 0.5], "tau_grid": [0.001]})
        query = {"query_id": "q", "candidate_ids": ["a", "b"], "scope_edge_count": 2, "winner_indices": [0] * 512}
        result = frontier.replay_query(query, 100, settings, independent=True)
        rows = [row for row in result["normal_mixture_frontier"] if row["scenario"] == "epsilon"]
        self.assertTrue(rows[0]["stable"])
        self.assertFalse(rows[-1]["stable"])
        self.assertEqual(rows[-1]["samples_used"], 512)
        self.assertEqual(sorted(row["samples_used"] for row in rows), [row["samples_used"] for row in rows])
        for row in rows:
            if row["stable"]:
                self.assertGreater(row["lower_gap_at_stop"], 2 * row["assumed_tv_epsilon"])

    def test_balanced_stream_does_not_become_certified_from_reference_gap(self):
        settings = frontier._settings({})
        query = {
            "query_id": "q", "candidate_ids": ["a", "b"], "scope_edge_count": 1,
            "winner_indices": [0, 1] * 256, "reference_gap": 1.0,
        }
        result = frontier.replay_query(query, 10, settings, independent=False)
        self.assertFalse(any(row["stable"] for row in result["normal_mixture_frontier"]))
        self.assertFalse(result["nominal_betting"]["stable"])
        self.assertFalse(any(row["scenario"].startswith("tau") for row in result["normal_mixture_frontier"]))

    def test_full_bound_uses_same_sampling_budget_and_is_more_conservative(self):
        settings = frontier._settings({"tau_grid": [0.01]})
        query = {"query_id": "q", "candidate_ids": ["a", "b"], "scope_edge_count": 1, "winner_indices": [0] * 512}
        result = frontier.replay_query(query, 100, settings, independent=True)
        local = next(row for row in result["normal_mixture_frontier"] if row["scenario"] == "tau_scope")
        full = next(row for row in result["normal_mixture_frontier"] if row["scenario"] == "tau_full_bound_same_budget")
        self.assertTrue(local["stable"])
        self.assertFalse(full["stable"])
        self.assertEqual(full["samples_used"], result["world_cap"])
        self.assertEqual(local["logical_scope_edge_cost"], local["samples_used"])
        self.assertEqual(full["logical_scope_edge_cost"], full["samples_used"])

    def test_out_of_pool_winner_and_duplicate_candidates_are_rejected(self):
        settings = frontier._settings({})
        base = {"query_id": "q", "candidate_ids": ["a", "b"], "scope_edge_count": 1, "winner_indices": [0] * 32}
        with self.assertRaisesRegex(ValueError, "indices"):
            frontier.replay_query({**base, "winner_indices": [2] * 32}, 2, settings, independent=True)
        with self.assertRaisesRegex(ValueError, "unique"):
            frontier.replay_query({**base, "candidate_ids": ["a", "a"]}, 2, settings, independent=True)

    def test_scope_certificate_binds_candidate_order_and_edge_count(self):
        manifest = {
            "dataset_revision": "rev", "scorer": {"id": "fixed", "version": "1"},
            "world_law": {"dependence": "independent"},
        }
        query = {"query_id": "q", "candidate_ids": ["a", "b"], "scope_edge_count": 1}
        payload = {
            "exact": True, "dataset_revision": "rev", "query_id": "q",
            "scorer_id": "fixed", "scorer_version": "1",
            "candidate_set_sha256": frontier._json_digest(["a", "b"]),
            "edge_ids": ["edge0"], "edge_variable_ids": ["var0"],
        }
        query["scope_certificate"] = {**payload, "certificate_sha256": frontier._json_digest(payload)}
        frontier._verify_scope(query, manifest)
        with self.assertRaisesRegex(ValueError, "candidate order"):
            frontier._verify_scope({**query, "candidate_ids": ["b", "a"]}, manifest)
        with self.assertRaisesRegex(ValueError, "edge count"):
            frontier._verify_scope({**query, "scope_edge_count": 2}, manifest)
        with self.assertRaisesRegex(ValueError, "digest"):
            frontier._verify_scope({**query, "scope_certificate": {**query["scope_certificate"], "exact": False}}, manifest)

    def test_frozen_manifest_rejects_hash_and_dataset_identity_changes(self):
        # All temporary files stay inside repository/tmp, including on Windows.
        with tempfile.TemporaryDirectory(dir=ROOT / "tmp") as directory:
            root = Path(directory)
            dataset = root / "data"
            dataset.mkdir()
            (dataset / "triples.tsv").write_text("head_id\ttail_id\na\tb\n", encoding="utf-8")
            revision = frontier.dataset_revision(dataset)
            manifest = {
                "schema_version": frontier.STREAM_SCHEMA,
                "dataset_path": "data", "dataset_revision": revision,
                "full_edge_count": 1, "world_law": {"semantics": "declared", "dependence": "independent"},
                "scorer": {"id": "fixed", "version": "1"}, "queries": [],
            }
            path = root / "stream.json"
            path.write_text(json.dumps(manifest), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "SHA-256"):
                frontier.replay_manifest({"path": "stream.json", "sha256": "bad"}, root, frontier._settings({}))
            specification = {"path": "stream.json", "sha256": frontier.file_sha256(path)}
            (dataset / "triples.tsv").write_text("head_id\ttail_id\na\tc\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "revision mismatch"):
                frontier.replay_manifest(specification, root, frontier._settings({}))

    def test_old_absolute_host_paths_are_not_silently_rebound(self):
        with self.assertRaises(ValueError):
            frontier._relative_path(ROOT, "E:\\pkgea\\data\\anything")
        with self.assertRaises(ValueError):
            frontier._relative_path(ROOT, "../outside")

    def test_summary_only_inputs_return_nonreplayable_without_fabricated_curve(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "tmp") as directory:
            root = Path(directory)
            for name in ("independent", "shared"):
                dataset = root / "data" / name
                dataset.mkdir(parents=True)
                (dataset / "triples.tsv").write_text("head_id\ttail_id\na\tb\n", encoding="utf-8")
            profile_path = root / "nodes/03_wsdm/configs/scale500_datasets.json"
            profile_path.parent.mkdir(parents=True)
            profile = {"profiles": [{
                "graph": "D-W", "independent": "data/independent", "shared": "data/shared",
                "dataset_revisions": {
                    name: frontier.dataset_revision(root / "data" / name)
                    for name in ("independent", "shared")
                },
            }]}
            profile_path.write_text(json.dumps(profile), encoding="utf-8")
            contract = {"profile_config_sha256": frontier.file_sha256(profile_path)}
            run = {
                "graph": "D-W", "dependence_profile": "independent", "scorer": "propagation",
                "mc_seed": 17, "training_seed": None, "query_count": 2,
                "full_edges": 1, "mean_scope_edges": 1, "candidate_count_mean": 2,
                "dataset_revision": profile["profiles"][0]["dataset_revisions"]["independent"],
                "main_world_stream_sha256": "a_hash_is_not_an_ordered_stream",
                "schedule_runs": [],
            }
            saved = {"contract": contract, "contract_sha256": frontier._json_digest(contract), "run": run}
            partial = root / "nodes/03_wsdm/results/scale500_crn/partial_runs/run.json"
            partial.parent.mkdir(parents=True)
            partial.write_text(json.dumps(saved), encoding="utf-8")
            for relative in (
                "nodes/03_wsdm/results/scale500_attribute/real_attribute_frontier.json",
                "nodes/03_wsdm/results/scale500_evidence/scale500_evidence.json",
            ):
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps({"schema_version": "summary_only"}), encoding="utf-8")
            result = frontier.run_stream_frontier({}, root)
            self.assertEqual(result["status"], "not_replayable")
            self.assertEqual(result["frontiers"], [])
            self.assertFalse(result["nominal_cs_replayed"])
            self.assertFalse(result["robust_cs_replayed"])
            self.assertTrue(result["legacy_input_audit"]["dataset_and_crn_contract_identity_verified"])
            self.assertEqual(result["new_worlds_generated"], 0)


if __name__ == "__main__":
    unittest.main()
