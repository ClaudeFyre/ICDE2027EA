from __future__ import annotations

import csv
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.audit_nl27k import audit_nl27k_replicas


class NL27KAuditTests(unittest.TestCase):
    def test_replica_mismatch_is_classified(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            ukge = root / "ukge"
            unkr = root / "unkr"
            beurre = root / "beurre"
            for directory in (ukge, unkr, beurre):
                directory.mkdir()
            rows = {
                "train.tsv": "h\tr1\tt\t0.8\n",
                "val.tsv": "h\tr2\tt\t0.7\n",
                "test.tsv": "h\tr3\tt\t0.6\n",
            }
            for filename, text in rows.items():
                (ukge / filename).write_text(text, encoding="utf-8")
                (unkr / filename).write_text(text, encoding="utf-8")
            with (beurre / "relation_id.csv").open(
                "w", encoding="utf-8", newline=""
            ) as handle:
                writer = csv.writer(handle)
                writer.writerow(["rid", "relation"])
                for index in range(417):
                    writer.writerow([index, f"r{index}"])
            report = audit_nl27k_replicas(ukge, unkr, beurre)
            self.assertEqual(report["classification"], "unresolved-replica-disagreement")
            self.assertTrue(
                all(report["unkr"]["byte_identical_to_ukge"].values())
            )
            self.assertEqual(report["heldout_only_relation_count"], 2)


if __name__ == "__main__":
    unittest.main()
