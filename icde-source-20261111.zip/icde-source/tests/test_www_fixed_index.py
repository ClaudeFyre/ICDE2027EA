"""Controls for the fixed-index experiment, including negative outcomes."""
import sys
from pathlib import Path
import numpy as np
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from www_fixed_index_audit import threshold_map, match_bytes, passes, digest
from run_www_equal_budget import representation_payload, load_representation_payload


def test_threshold_respects_zero_margin_and_cheapest_admissible():
    scores=np.array([[np.inf,np.inf,np.inf,np.inf],[0,0,0,0],[5,3,1,0.1]])
    assert threshold_map(scores,1)==['full','diagonal','rank_2']


def test_serialized_index_roundtrip_and_hash_detect_mutation():
    means=np.zeros((2,4)); cov=np.stack([np.eye(4),np.diag([1,2,3,4])])
    payload,_=representation_payload(means,cov,['full','diagonal'],{})
    m,c=load_representation_payload(payload)
    np.testing.assert_array_equal(m,means)
    np.testing.assert_allclose(c,cov)
    assert digest(payload)!=digest(payload+b'changed')
    assert passes({'flipped_query_count':0,'mean_relative_distance_error':0.001},0.0025)
    assert not passes({'flipped_query_count':1,'mean_relative_distance_error':0.0},0.0025)


def test_byte_match_impossible_budget_stops():
    with pytest.raises(RuntimeError,match='budget'):
        match_bytes(np.zeros((2,4)),np.stack([np.eye(4)]*2),np.zeros((2,4)),{},1)
