from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import LabelPropagationBackbone


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class LabelPropagationTests(unittest.TestCase):
    def test_score_matrix_is_complete_and_reproducible(self) -> None:
        backbone = LabelPropagationBackbone.from_dataset(TOY)
        state = (True, False, True, False)
        first = backbone.score(state)
        second = backbone.score(state)
        self.assertEqual(first, second)
        self.assertEqual(len(first), 9)


if __name__ == "__main__":
    unittest.main()
