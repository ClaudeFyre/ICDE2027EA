from __future__ import annotations

import csv
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import ToyStructuralBackbone
from pkgea.contracts import validate_dataset
from pkgea.data import extract_aligned_probe


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class ProbeTests(unittest.TestCase):
    def test_probe_preserves_selected_query_pair(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output = extract_aligned_probe(
                TOY,
                Path(temp_dir) / "probe",
                pair_count=1,
                max_edges_per_graph=2,
                split="test",
                seed=17,
            )
            report = validate_dataset(output)
            self.assertEqual(report.alignment_count, 1)
            backbone = ToyStructuralBackbone.from_dataset(output)
            self.assertEqual(len(backbone.source_entities), 1)
            self.assertEqual(len(backbone.target_entities), 1)

    def test_probe_preserves_optional_attributes(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "source"
            source.mkdir()
            for filename in (
                "entities.tsv",
                "relations.tsv",
                "triples.tsv",
                "alignments.tsv",
                "confidence_metadata.json",
            ):
                (source / filename).write_bytes((TOY / filename).read_bytes())
            (source / "attributes.tsv").write_text(
                "graph_id\tentity_id\tattribute_id\tvalue\n"
                "source\ts:alice\tname\tAlice\n"
                "target\tt:alice\tlabel\tAlice\n"
                "source\ts:bob\tname\tBob\n",
                encoding="utf-8",
            )
            output = extract_aligned_probe(
                source,
                Path(temp_dir) / "probe",
                pair_count=1,
                max_edges_per_graph=2,
                split="test",
                seed=17,
            )
            text = (output / "attributes.tsv").read_text(encoding="utf-8")
            self.assertIn("s:alice", text)
            self.assertIn("t:alice", text)
            with (output / "entities.tsv").open(
                encoding="utf-8-sig", newline=""
            ) as handle:
                entity_ids = {
                    row["entity_id"]
                    for row in csv.DictReader(handle, delimiter="\t")
                }
            with (output / "attributes.tsv").open(
                encoding="utf-8-sig", newline=""
            ) as handle:
                attribute_ids = {
                    row["entity_id"]
                    for row in csv.DictReader(handle, delimiter="\t")
                }
            self.assertLessEqual(attribute_ids, entity_ids)

    def test_probe_can_include_disjoint_training_anchors(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output = extract_aligned_probe(
                TOY,
                Path(temp_dir) / "probe",
                pair_count=1,
                max_edges_per_graph=4,
                split="test",
                anchor_count=1,
                anchor_split="train",
                seed=17,
            )
            with (output / "alignments.tsv").open(
                encoding="utf-8-sig", newline=""
            ) as handle:
                rows = list(csv.DictReader(handle, delimiter="\t"))
            self.assertEqual(
                {row["split"] for row in rows},
                {"train", "test"},
            )

    def test_probe_can_preserve_query_to_anchor_paths(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output = extract_aligned_probe(
                TOY,
                Path(temp_dir) / "connected-probe",
                pair_count=1,
                max_edges_per_graph=4,
                split="test",
                anchor_count=1,
                anchor_split="train",
                anchor_selection="nearest_joint",
                connection_hops=2,
                seed=17,
            )
            with (output / "triples.tsv").open(
                encoding="utf-8-sig", newline=""
            ) as handle:
                triples = list(csv.DictReader(handle, delimiter="\t"))
            self.assertEqual(len(triples), 4)
            metadata = (output / "confidence_metadata.json").read_text(
                encoding="utf-8"
            )
            self.assertIn('"anchor_selection": "nearest_joint"', metadata)
            self.assertIn('"required_connection_edges": 2', metadata)


if __name__ == "__main__":
    unittest.main()
