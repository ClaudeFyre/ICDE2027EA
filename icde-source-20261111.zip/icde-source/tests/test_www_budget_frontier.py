"""The budget-frontier path, proven on synthetic data.

The compute host has no interactive assistance, so every part of this run that
can be exercised without a checkpoint or a licensed dataset is exercised here
first: the orchestration end to end, the slack statistic, budget validation,
and the refusal to continue when a frozen plan changes.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "src", ROOT / "scripts", ROOT / "scripts/backbones"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from www_budget_frontier import (  # noqa: E402
    RULES, certificate_report, certify, decision_slack, run_frontier,
    summarize_slack, target_distortions,
)


def synthetic_case(rng, sources=60, targets=300, dimension=8):
    """A small but structurally faithful cell: distinct means, PSD covariances.

    The dimension must exceed rank 4, since rank_4 is one of the representations
    the allocator may choose; production runs at d=16.
    """

    total = sources + targets
    means = rng.normal(size=(total, dimension)) * 3.0
    covariances = np.empty((total, dimension, dimension))
    for index in range(total):
        factor = rng.normal(size=(dimension, dimension))
        covariances[index] = factor @ factor.T + np.eye(dimension) * 0.5
    return means, covariances


def test_decision_slack_is_negative_exactly_when_the_winner_changes():
    reference = np.array([[0.1, 0.9, 0.5], [0.7, 0.2, 0.4]])
    agreeing = np.array([[0.1, 0.9, 0.5], [0.7, 0.2, 0.4]])
    flipping = np.array([[0.9, 0.1, 0.5], [0.7, 0.2, 0.4]])
    assert np.all(decision_slack(reference, agreeing) > 0)
    slack = decision_slack(reference, flipping)
    assert slack[0] < 0 and slack[1] > 0


def test_summarize_slack_reports_the_negative_tail():
    values = np.array([-0.2, 0.1, 0.4, 0.9])
    summary = summarize_slack(values)
    assert summary["negative_count"] == 1
    assert summary["min"] == pytest.approx(-0.2)
    assert summary["median"] == pytest.approx(0.25)
    assert summarize_slack(np.array([])) == {}


def test_frontier_runs_end_to_end_and_records_every_budget(tmp_path):
    rng = np.random.default_rng(20260920)
    sources, targets, dimension = 60, 300, 8
    means, covariances = synthetic_case(rng, sources, targets, dimension)
    splits = {
        "selection": slice(0, 30),
        "authorization": slice(30, 45),
        "final_test": slice(45, 60),
    }
    timing = {"total_seconds": 0.0}

    def moments(seed, label):
        # Held-out streams perturb the queries but never the frozen target index.
        noise = np.random.default_rng(seed).normal(scale=0.01, size=means.shape)
        return means + noise, covariances, dict(timing)

    output = tmp_path / "cell.json"
    budgets = (0.5, 0.8)
    run_frontier(
        output=output, cell="synthetic", means=means, covariances=covariances,
        selection_timing=dict(timing), moments=moments, splits=splits,
        sources=tuple(f"s{i}" for i in range(sources)),
        targets=tuple(f"t{i}" for i in range(targets)),
        truth_positions=np.zeros(sources, dtype=int),
        metadata={"cell": "synthetic"}, max_error=0.0025,
        budget_fractions=budgets,
    )

    result = json.loads(output.read_text(encoding="utf-8"))
    assert result["schema_version"] == "www-budget-frontier-v1"
    assert result["protocol"]["budget_fractions"] == list(budgets)
    assert result["protocol"]["query_split"] == {
        "selection": 30, "authorization": 15, "final_test": 15,
    }

    floor = result["protocol"]["diagonal_floor_fraction"]
    assert 0.0 < floor < 1.0
    feasible = [f for f in budgets if f >= floor]
    assert feasible, "synthetic case should leave at least one reachable budget"

    for stage in ("authorization", "final_test"):
        rows = result["stages"][stage]["methods"]
        for fraction in feasible:
            for rule in (*RULES, "margin_fp16"):
                row = rows[f"{fraction:g}:{rule}"]
                assert row["budget_fraction"] == fraction
                assert row["query_count"] == 15
                assert "slack" in row and "negative_count" in row["slack"]
                assert row["artifact_bytes"] > 0
        # Nothing below the floor is silently reported as a result.
        for entry in result["protocol"]["infeasible_budgets"]:
            assert f"{entry['budget_fraction']:g}:{entry['rule']}" not in rows


def test_a_tighter_budget_never_buys_more_bytes(tmp_path):
    rng = np.random.default_rng(7)
    means, covariances = synthetic_case(rng)
    splits = {"selection": slice(0, 30), "authorization": slice(30, 45),
              "final_test": slice(45, 60)}

    def moments(seed, label):
        return means, covariances, {"total_seconds": 0.0}

    output = tmp_path / "cell.json"
    run_frontier(
        output=output, cell="synthetic", means=means, covariances=covariances,
        selection_timing={"total_seconds": 0.0}, moments=moments, splits=splits,
        sources=tuple(f"s{i}" for i in range(60)),
        targets=tuple(f"t{i}" for i in range(300)),
        truth_positions=np.zeros(60, dtype=int), metadata={}, max_error=0.0025,
        budget_fractions=(0.8, 0.95),
    )
    rows = json.loads(output.read_text(encoding="utf-8"))["stages"]["final_test"]["methods"]
    for rule in RULES:
        low, high = f"0.8:{rule}", f"0.95:{rule}"
        if low in rows and high in rows:
            assert rows[low]["artifact_bytes"] <= rows[high]["artifact_bytes"]


def test_a_budget_below_the_floor_is_recorded_not_raised(tmp_path):
    """An unattended sweep must survive a budget the format cannot reach."""

    rng = np.random.default_rng(11)
    means, covariances = synthetic_case(rng)
    splits = {"selection": slice(0, 30), "authorization": slice(30, 45),
              "final_test": slice(45, 60)}

    def moments(seed, label):
        return means, covariances, {"total_seconds": 0.0}

    output = tmp_path / "cell.json"
    run_frontier(
        output=output, cell="synthetic", means=means, covariances=covariances,
        selection_timing={"total_seconds": 0.0}, moments=moments, splits=splits,
        sources=tuple(f"s{i}" for i in range(60)),
        targets=tuple(f"t{i}" for i in range(300)),
        truth_positions=np.zeros(60, dtype=int), metadata={}, max_error=0.0025,
        budget_fractions=(0.05, 0.9),
    )
    result = json.loads(output.read_text(encoding="utf-8"))
    recorded = result["protocol"]["infeasible_budgets"]
    assert any(entry["budget_fraction"] == 0.05 for entry in recorded)
    assert all("0.05:" not in key for key in result["stages"]["final_test"]["methods"])


def test_matrix_driver_rejects_out_of_range_budgets():
    import run_www_budget_frontier_matrix as driver
    assert driver.BUDGETS[0] < driver.BUDGETS[-1] <= 1.0
    assert driver.SMOKE_CELL in driver.CELLS
    # The frozen namespaces must not be the frontier's output root.
    assert "fixed_index_v1" not in str(driver.RESULTS)
    assert "main_matrix" not in str(driver.RESULTS)

def test_smoke_output_never_collides_with_the_full_run(tmp_path):
    """The smoke cell is a real cell, so its artifact must not block the run."""

    import run_www_budget_frontier_matrix as driver
    full = driver.plan([driver.SMOKE_CELL], (0.5, 0.8), smoke=False)[0]["output"]
    smoke = driver.plan([driver.SMOKE_CELL], (0.5, 0.8), smoke=True)[0]["output"]
    assert full != smoke
    assert Path(smoke).name.startswith("smoke_")


def test_summarizer_refuses_to_pool_disagreeing_budgets(tmp_path):
    import json as _json
    import subprocess
    import sys as _sys

    for name, budgets in (("a.json", [0.5, 0.8]), ("b.json", [0.3, 0.9])):
        (tmp_path / name).write_text(_json.dumps({
            "cell": name, "protocol": {"budget_fractions": budgets},
            "stages": {"final_test": {"methods": {}}},
        }), encoding="utf-8")
    result = subprocess.run(
        [_sys.executable, str(ROOT / "scripts/summarize_www_budget_frontier.py"),
         "--results", str(tmp_path)],
        capture_output=True, text=True,
    )
    assert result.returncode != 0
    assert "disagree on budgets" in result.stderr + result.stdout

def test_certificate_is_sound_on_random_problems():
    """Soundness is a theorem; assert it over many random instances.

    If a query is certified, the compressed winner must equal the winner the
    full index would have elected -- no exceptions, no tolerance.
    """

    rng = np.random.default_rng(4)
    total = certified = 0
    for _ in range(300):
        q, c = 12, 20
        true = rng.gamma(2.0, 1.0, size=(q, c))
        deltas = rng.uniform(0.0, 0.35, size=c)
        # Any perturbation within +/- delta_c is admissible under the bound.
        noise = (rng.uniform(-1.0, 1.0, size=(q, c))) * deltas[None, :]
        estimate = true + noise
        ok, winner = certify(estimate, deltas)
        truth = np.argmin(true, axis=1)
        assert np.all(winner[ok] == truth[ok]), "certified query elected the wrong candidate"
        total += q; certified += int(ok.sum())
    assert certified > 0, "the certificate never fires; the test proves nothing"
    print(f"coverage on random instances: {certified/total:.2f}")


def test_certificate_refuses_when_bounds_overlap():
    # One clear winner, huge uncertainty on the runner-up: must not certify.
    estimate = np.array([[1.0, 1.2, 5.0]])
    assert not certify(estimate, np.array([0.0, 0.5, 0.0]))[0][0]
    # Same gap, negligible uncertainty: must certify.
    assert certify(estimate, np.array([0.0, 0.01, 0.0]))[0][0]


def test_certificate_report_counts_and_flags_violations():
    reference = np.array([[0.1, 0.5], [0.5, 0.1]])
    estimate = np.array([[0.1, 0.5], [0.5, 0.1]])
    r = certificate_report(reference, estimate, np.array([0.0, 0.0]))
    assert r["queries"] == 2 and r["certified"] == 2
    assert r["certified_disagreeing_with_full_index"] == 0
    assert r["coverage"] == 1.0


def test_distortion_is_measured_against_the_artifact_not_the_format(tmp_path):
    """FP16 perturbs means and covariance beyond the format choice.

    Reading delta from the selection score table would understate it and make
    the bound unsafe, so the exact measurement must see the quantization.
    """

    rng = np.random.default_rng(9)
    d = 8
    means = rng.normal(size=(5, d))
    covs = np.stack([(lambda f: f @ f.T + np.eye(d))(rng.normal(size=(d, d)))
                     for _ in range(5)])
    from www_budget_frontier import NUMERICAL_GUARD
    exact = target_distortions(means, covs, means, covs)
    # Never below the guard, and never far above it for an identical artifact.
    assert np.all(exact >= NUMERICAL_GUARD)
    assert np.all(exact < 10 * NUMERICAL_GUARD)
    quantized_m = means.astype(np.float16).astype(float)
    quantized_c = covs.astype(np.float16).astype(float)
    fp16 = target_distortions(means, covs, quantized_m, quantized_c)
    assert np.all(fp16 > 0), "FP16 distortion must be visible to the certificate"


def test_frontier_records_certificates_when_asked(tmp_path):
    rng = np.random.default_rng(31)
    means, covariances = synthetic_case(rng)
    splits = {"selection": slice(0, 30), "authorization": slice(30, 45),
              "final_test": slice(45, 60)}

    def moments(seed, label):
        noise = np.random.default_rng(seed).normal(scale=0.01, size=means.shape)
        return means + noise, covariances, {"total_seconds": 0.0}

    output = tmp_path / "cell.json"
    run_frontier(
        output=output, cell="synthetic", means=means, covariances=covariances,
        selection_timing={"total_seconds": 0.0}, moments=moments, splits=splits,
        sources=tuple(f"s{i}" for i in range(60)),
        targets=tuple(f"t{i}" for i in range(300)),
        truth_positions=np.zeros(60, dtype=int), metadata={}, max_error=0.0025,
        budget_fractions=(0.6, 0.9), certify_queries=True,
    )
    result = json.loads(output.read_text(encoding="utf-8"))
    assert result["schema_version"] == "www-budget-frontier-v2"
    assert result["protocol"]["per_query_certificate"] is True
    seen = 0
    for stage in ("authorization", "final_test"):
        for key, row in result["stages"][stage]["methods"].items():
            c = row["certificate"]
            assert c["certified_disagreeing_with_full_index"] == 0
            assert 0.0 <= c["coverage"] <= 1.0
            assert c["certified"] + c["uncertified_that_were_correct_anyway"] \
                + c["uncertified_that_would_have_been_wrong"] == c["queries"]
            seen += 1
    assert seen > 0
