from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.contracts import validate_dataset
from pkgea.data import convert_scored_ukg_to_views


class UKGViewConversionTests(unittest.TestCase):
    def test_dual_view_preserves_score_semantics_and_identity(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            source = root / "input"
            output = root / "output"
            source.mkdir()
            (source / "entities.csv").write_text(
                "label,id\nalpha,0\nbeta,1\ngamma,2\n",
                encoding="utf-8",
            )
            (source / "relations.csv").write_text(
                "label,id\nrelated,0\n",
                encoding="utf-8",
            )
            (source / "train.tsv").write_text(
                "0\t0\t1\t0.8\n1\t0\t2\t0.6\n",
                encoding="utf-8",
            )
            (source / "val.tsv").write_text("", encoding="utf-8")
            (source / "test.tsv").write_text(
                "2\t0\t0\t0.7\n", encoding="utf-8"
            )
            convert_scored_ukg_to_views(
                source,
                output,
                entity_map_name="entities.csv",
                relation_map_name="relations.csv",
                dataset_id="tiny",
                source_retention=1.0,
                target_retention=1.0,
            )
            report = validate_dataset(output)
            self.assertEqual(report.triple_count, 6)
            self.assertEqual(report.alignment_count, 3)
            self.assertEqual(
                report.confidence_types,
                ("normalized_heuristic_weight",),
            )
            with (output / "triples.tsv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                triples = list(csv.DictReader(handle, delimiter="\t"))
            self.assertTrue(
                all(row["dependency_group"] for row in triples)
            )
            metadata = json.loads(
                (output / "confidence_metadata.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertIn(
                "no calibrated-probability claim",
                metadata["probability_semantics"],
            )
            self.assertIn("Unresolved", metadata["license_status"])


if __name__ == "__main__":
    unittest.main()

