"""Contract checks for the ICDE modal execution pilot."""

from dataclasses import replace

import numpy as np
import pytest

from pkgea.certified import certify_winner_sequence
from pkgea.query.modal import (
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    WinnerBlockCache,
    execute_modal_queries,
    world_winner,
)
from pkgea.samplers import exact_worlds, monte_carlo_worlds


def fixture(probability=0.8, budget=512):
    snapshot = ModalSnapshot("g", "m", str(probability), "independent", "s", "c", "toy")
    stream = IIDWorldStream(
        snapshot.digest, 17, tuple(monte_carlo_worlds([probability], budget, 17))
    )
    queries = [ModalQuery(s, ("b", "a"), snapshot.digest, budget) for s in ("s1", "s2")]

    def score(state, sources, targets):
        return {(s, t): float(state[0] == (t == "a")) for s in sources for t in targets}

    return snapshot, stream, queries, ModalScorer(snapshot.digest, score)


def test_checkpoint_evidence_matches_scalar_batch_and_lru():
    snapshot, stream, queries, score = fixture()
    cache = WinnerBlockCache(4096)
    scalar = execute_modal_queries(queries, snapshot, stream, score, shared=False)
    batched = execute_modal_queries(queries, snapshot, stream, score)
    cold = execute_modal_queries(queries, snapshot, stream, score, cache=cache)
    warm = execute_modal_queries(queries, snapshot, stream, score, cache=cache)
    assert scalar["results"] == batched["results"] == cold["results"] == warm["results"]
    assert warm["work"]["scorer_calls"] == 0
    assert batched["work"]["scorer_calls"] * 2 == scalar["work"]["scorer_calls"]
    assert cache.peak_payload_bytes <= cache.capacity_bytes
    sequence = ["a" if w.state[0] else "b" for w in stream.worlds]
    reference = certify_winner_sequence("s1", queries[0].candidates, sequence).as_dict()
    assert all(scalar["results"][0][key] == value for key, value in reference.items())


@pytest.mark.parametrize(
    "field", ["graph", "model", "probability", "factors", "schema", "code", "scorer"]
)
def test_each_snapshot_change_rejects_old_queries_and_worlds(field):
    snapshot, stream, queries, score = fixture()
    changed = replace(snapshot, **{field: "changed"})
    with pytest.raises(ValueError, match="stale world"):
        execute_modal_queries(queries, changed, stream, score)
    new_stream = replace(stream, snapshot_digest=changed.digest)
    new_queries = [replace(q, snapshot_digest=changed.digest) for q in queries]
    with pytest.raises(ValueError, match="stale scorer"):
        execute_modal_queries(new_queries, changed, new_stream, score)
    score = replace(score, snapshot_digest=changed.digest)
    with pytest.raises(ValueError, match="stale query"):
        execute_modal_queries(queries, changed, new_stream, score)


def test_changed_revision_candidate_order_and_stream_never_hit_old_labels():
    snapshot, stream, queries, score = fixture()
    cache = WinnerBlockCache(16384)
    execute_modal_queries(queries, snapshot, stream, score, cache=cache)
    for changed_queries, changed_snapshot, changed_stream in (
        ([replace(q, candidates=("a", "b")) for q in queries], snapshot, stream),
        (queries, snapshot, replace(stream, seed=18)),
    ):
        result = execute_modal_queries(
            changed_queries, changed_snapshot, changed_stream, score, cache=cache
        )
        assert result["work"]["cache_label_reads"] == 0
    new_snapshot, new_stream, new_queries, score = fixture(0.2)
    refreshed = execute_modal_queries(new_queries, new_snapshot, new_stream, score, cache=cache)
    reference = execute_modal_queries(new_queries, new_snapshot, new_stream, score, shared=False)
    assert refreshed["work"]["cache_label_reads"] == 0
    assert refreshed["results"] == reference["results"]
    assert refreshed["results"][0]["certified_winner"] == "b"


def test_eviction_preserves_evidence_and_capacity():
    snapshot, stream, queries, score = fixture()
    cache = WinnerBlockCache(64)
    expected = execute_modal_queries(queries, snapshot, stream, score)
    for _ in range(2):
        actual = execute_modal_queries(queries, snapshot, stream, score, cache=cache)
        assert actual["results"] == expected["results"]
    assert cache.evictions > 0
    assert cache.peak_payload_bytes <= 64


def test_repeated_iid_states_are_samples_but_cache_reread_is_not_extra_samples():
    snapshot, stream, queries, score = fixture(1.0)
    cache = WinnerBlockCache(4096)
    first = execute_modal_queries(queries, snapshot, stream, score, cache=cache)
    second = execute_modal_queries(queries, snapshot, stream, score, cache=cache)
    assert first["results"] == second["results"]
    assert first["results"][0]["samples_used"] < queries[0].budget
    assert second["work"]["cache_label_reads"] == second["work"]["query_world_observations"]


def test_exhaustion_and_unequal_budget_charge_overcomputed_rectangle():
    snapshot, stream, queries, score = fixture(0.5, 37)
    queries[0] = replace(queries[0], budget=33)
    result = execute_modal_queries(queries, snapshot, stream, score)
    assert [r["samples_used"] for r in result["results"]] == [33, 37]
    assert all(r["status"] == "budget_exhausted" for r in result["results"])
    assert result["work"]["ahead_worlds"] == 4
    assert result["work"]["candidate_evaluations"] == 37 * 4


def test_weighted_enumeration_must_not_enter_iid_confidence_sequence():
    snapshot, _, _, _ = fixture()
    with pytest.raises(ValueError, match="iid MC"):
        IIDWorldStream(snapshot.digest, 17, tuple(exact_worlds([0.8])))


def test_ties_precision_and_invalid_scores():
    assert world_winner({"a": 1.0, "b": 1.0}, ("b", "a")) == "a"
    # Conversion can change a winner even with tiny absolute score error.
    scores = {"a": 1.0, "b": 1.0 + 1e-8}
    assert world_winner(scores, ("a", "b")) == "b"
    assert world_winner({c: float(np.float32(v)) for c, v in scores.items()}, ("a", "b")) == "a"
    for scores in ({"a": float("nan"), "b": 1.0}, {"a": float("inf"), "b": 1.0}, {"a": 1.0}):
        with pytest.raises(ValueError):
            world_winner(scores, ("a", "b"))


def test_duplicate_candidates_short_stream_and_invalid_budget():
    snapshot, stream, queries, score = fixture()
    with pytest.raises(ValueError):
        replace(queries[0], candidates=("a", "a"))
    with pytest.raises(ValueError):
        replace(queries[0], budget=0)
    with pytest.raises(ValueError, match="shorter"):
        execute_modal_queries([replace(queries[0], budget=513)], snapshot, stream, score)
