from __future__ import annotations

import random
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.certified import (
    CertifiedSchedulerConfig,
    PairwiseBettingWinnerState,
    PairwiseWinnerState,
    categorical_betting_log_evalue,
    certify_winner_sequence,
    normal_mixture_radius,
    schedule_certified_winner_streams,
)


class CertifiedWinnerTests(unittest.TestCase):
    def test_normal_mixture_radius_shrinks(self) -> None:
        self.assertGreater(
            normal_mixture_radius(64, 0.05),
            normal_mixture_radius(4096, 0.05),
        )

    def test_clear_winner_is_certified(self) -> None:
        result = certify_winner_sequence(
            "q",
            ("a", "b", "c"),
            ["a"] * 512,
            minimum_samples=32,
            batch_size=16,
        )
        self.assertTrue(result.stable)
        self.assertEqual(result.certified_winner, "a")
        self.assertLess(result.samples_used, 512)
        self.assertTrue(all(bound.lower > 0.0 for bound in result.pairwise_bounds))

    def test_exact_tie_is_not_certified(self) -> None:
        result = certify_winner_sequence(
            "q",
            ("a", "b"),
            ["a", "b"] * 512,
            minimum_samples=32,
            batch_size=16,
        )
        self.assertFalse(result.stable)
        self.assertEqual(result.status, "budget_exhausted")

    def test_minimum_samples_delays_an_early_certificate(self) -> None:
        result = certify_winner_sequence(
            "q",
            ("a", "b"),
            ["a"] * 256,
            minimum_samples=128,
            batch_size=16,
            rho=0.01,
        )
        self.assertTrue(result.stable)
        self.assertGreaterEqual(result.samples_used, 128)

    def test_all_pairs_receive_simultaneous_alpha(self) -> None:
        state = PairwiseWinnerState("q", ("a", "b", "c", "d"), delta=0.06)
        state.update(["a"] * 64)
        self.assertAlmostEqual(state.pair_alpha, 0.01)
        self.assertEqual(len(state.leader_bounds()), 3)

    def test_betting_evalue_favors_repeated_leader(self) -> None:
        self.assertGreater(
            categorical_betting_log_evalue(100, 10),
            categorical_betting_log_evalue(10, 100),
        )

    def test_betting_state_certifies_clear_winner_not_tie(self) -> None:
        clear = PairwiseBettingWinnerState("clear", ("a", "b", "c"))
        clear.update(["a"] * 128)
        self.assertTrue(clear.stable)
        self.assertEqual(clear.certified_winner, "a")
        self.assertTrue(
            all(item.rejects_nonpositive_gap for item in clear.leader_evidence())
        )

        tied = PairwiseBettingWinnerState("tie", ("a", "b"))
        tied.update(["a", "b"] * 256)
        self.assertFalse(tied.stable)

    def test_scheduler_respects_budget_and_certificates(self) -> None:
        rng = random.Random(17)
        streams = {
            "cheap_easy": ["a" if rng.random() < 0.9 else "b" for _ in range(512)],
            "costly_tie": ["a" if rng.random() < 0.5 else "b" for _ in range(512)],
        }
        result = schedule_certified_winner_streams(
            streams,
            {query: ("a", "b") for query in streams},
            {"cheap_easy": 1.0, "costly_tie": 4.0},
            CertifiedSchedulerConfig(
                global_budget=800.0,
                pilot_samples_per_query=32,
                batch_size=16,
                strategy="gap_cost",
            ),
        )
        self.assertLessEqual(result.total_cost, 800.0 + 1e-9)
        self.assertGreaterEqual(result.stable_queries, 1)
        stable = [item for item in result.queries if item.stable]
        self.assertTrue(all(item.certified_winner == "a" for item in stable))

    def test_known_gap_matches_gap_cost_when_estimate_equals_gap(self) -> None:
        streams = {
            "cheap": ["a", "a", "a", "b"] * 64,
            "costly": ["a", "a", "a", "b"] * 64,
        }
        candidates = {query: ("a", "b") for query in streams}
        costs = {"cheap": 1.0, "costly": 2.0}
        common = dict(
            global_budget=240.0,
            pilot_samples_per_query=4,
            batch_size=4,
            maximum_samples_per_query=256,
        )
        estimated = schedule_certified_winner_streams(
            streams,
            candidates,
            costs,
            CertifiedSchedulerConfig(strategy="gap_cost", **common),
        )
        known = schedule_certified_winner_streams(
            streams,
            candidates,
            costs,
            CertifiedSchedulerConfig(strategy="gap_cost_known_gap", **common),
            generating_gaps={"cheap": 0.5, "costly": 0.5},
        )
        self.assertEqual(estimated.total_cost, known.total_cost)
        self.assertEqual(estimated.total_worlds, known.total_worlds)
        self.assertEqual(estimated.queries, known.queries)
        self.assertEqual(estimated.allocation_trace, known.allocation_trace)


if __name__ == "__main__":
    unittest.main()
