"""The actual OAEI files use an Alignment namespace without a trailing #."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from audit_icde_oaei_intake import parse_reference


@pytest.mark.parametrize("suffix", ["", "#"])
def test_supported_namespace_and_separate_schema(suffix):
    raw = f"""<rdf:RDF xmlns="http://knowledgeweb.semanticweb.org/heterogeneity/alignment{suffix}"
        xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><Alignment><map><Cell>
        <entity1 rdf:resource="http://wiki/resource/a"/><entity2 rdf:resource="http://wiki2/resource/b"/>
        <relation>=</relation></Cell></map></Alignment></rdf:RDF>"""
    result = parse_reference(raw.encode())
    assert result["cells"] == result["unique_pairs"] == 1
    assert result["schema_uri_cells"] == 0


def test_empty_or_wrong_namespace_is_rejected():
    with pytest.raises(ValueError):
        parse_reference(b"<RDF><Alignment/></RDF>")
