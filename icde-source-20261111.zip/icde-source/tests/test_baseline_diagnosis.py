from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import ToyStructuralBackbone
from pkgea.experiments import (
    diagnose_deterministic_baselines,
    run_multi_seed_budget_curve,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class BaselineDiagnosisTests(unittest.TestCase):
    def test_expected_score_accepts_probabilities(self) -> None:
        backbone = ToyStructuralBackbone.from_dataset(TOY)
        scores = backbone.score_expected((0.8, 0.6, 0.75, 0.55))
        self.assertEqual(len(scores), 9)

    def test_diagnosis_ranks_all_sources_and_edges(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            reference = Path(temp_dir) / "reference.json"
            output = Path(temp_dir) / "diagnosis.json"
            run_multi_seed_budget_curve(
                TOY,
                [64],
                [11, 17, 23],
                backbone_name="toy",
                early_stopping=False,
                output_path=reference,
            )
            result = diagnose_deterministic_baselines(
                TOY,
                reference,
                backbone_name="toy",
                top_edge_count=3,
                output_path=output,
            )
            self.assertTrue(output.is_file())
            self.assertEqual(len(result["source_difficulty"]), 3)
            self.assertEqual(len(result["top_edge_variance_proxies"]), 3)
            self.assertIn(
                "expected_adjacency_confidence_as_weight",
                result["baselines"],
            )


if __name__ == "__main__":
    unittest.main()
