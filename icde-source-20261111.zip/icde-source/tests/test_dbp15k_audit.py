from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.audit_dbp15k import audit_dbp15k


class DBP15KAuditTests(unittest.TestCase):
    def test_split_coverage_and_references_are_checked(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for pair in ("zh_en", "ja_en", "fr_en"):
                pair_dir = root / pair
                split = pair_dir / "0_3"
                split.mkdir(parents=True)
                (pair_dir / "s_triples").write_text(
                    "s1\tr1\ts2\n", encoding="utf-8"
                )
                (pair_dir / "t_triples").write_text(
                    "t1\tr2\tt2\n", encoding="utf-8"
                )
                (pair_dir / "ent_ILLs").write_text(
                    "s1\tt1\ns2\tt2\n", encoding="utf-8"
                )
                (split / "ent_ids_1").write_text(
                    "0\ts1\n1\ts2\n", encoding="utf-8"
                )
                (split / "ent_ids_2").write_text(
                    "0\tt1\n2\tt2\n", encoding="utf-8"
                )
                (split / "rel_ids_1").write_text(
                    "0\tr1\n", encoding="utf-8"
                )
                (split / "rel_ids_2").write_text(
                    "1\tr2\n", encoding="utf-8"
                )
                (split / "triples_1").write_text(
                    "0\t0\t1\n", encoding="utf-8"
                )
                (split / "triples_2").write_text(
                    "0\t1\t2\n", encoding="utf-8"
                )
                (split / "sup_ent_ids").write_text(
                    "0\t0\n", encoding="utf-8"
                )
                (split / "ref_ent_ids").write_text(
                    "1\t2\n", encoding="utf-8"
                )
            report = audit_dbp15k(root)
        self.assertTrue(report["all_pairs_valid"])
        self.assertEqual(report["pairs"][0]["selected"]["support_pairs"], 1)
        self.assertEqual(
            report["pairs"][0]["selected"]["support_reference_overlap"],
            0,
        )


if __name__ == "__main__":
    unittest.main()
