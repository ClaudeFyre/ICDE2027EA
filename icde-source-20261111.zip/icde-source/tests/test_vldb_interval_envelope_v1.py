"""Small exhaustive containment tests for the V1 interval event envelope."""

from dataclasses import dataclass, replace
from itertools import product
import math
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import vldb_interval_envelope_v1 as envelope


@dataclass(frozen=True)
class ToyKernel:
    candidates: tuple
    edge_indices: tuple
    incidence_positions: tuple
    attribute: np.ndarray
    lexical: np.ndarray
    attribute_weight: float

    def scores(self, states):
        if states.dtype != np.bool_:
            raise ValueError("Boolean states required")
        degrees = np.empty((len(states), len(self.incidence_positions)), dtype=np.float64)
        for column, positions in enumerate(self.incidence_positions):
            degrees[:, column] = np.sum(states[:, positions], axis=1, dtype=np.float64)
        distance = (np.abs(degrees[:, 0, None] - degrees[:, 2::2])
                    + np.abs(degrees[:, 1, None] - degrees[:, 3::2]))
        dynamic = 1.0 / (1.0 + distance)
        structural = 0.6 * self.lexical[None, :] + 0.4 * dynamic
        return self.attribute_weight * self.attribute[None, :] + (1.0 - self.attribute_weight) * structural


def kernel(attribute=(.1, .2), lexical=(.3, .25), weight=.6):
    # Three uncertain edges, including shared incidence: source out 0,1;
    # source in 2; A out0/in2; B out1/in0.  Independent degree intervals
    # are deliberately an over-approximation of shared-edge completions.
    return ToyKernel(("a", "b"), (0, 1, 2),
                     tuple(np.array(p, dtype=np.intp) for p in ((0, 1), (2,), (0,), (2,), (1,), (0,))),
                     np.array(attribute, dtype=np.float64), np.array(lexical, dtype=np.float64), float(weight))


class IntervalEnvelopeTests(unittest.TestCase):
    def test_every_three_bit_interval_contains_every_completion(self):
        scorer = kernel()
        for statuses in product((0, 1, 2), repeat=3):
            low = np.array([[value == 1 for value in statuses]], dtype=np.bool_)
            high = np.array([[value != 0 for value in statuses]], dtype=np.bool_)
            lower, upper = envelope.score_intervals(scorer, low, high)
            for bits in product((False, True), repeat=3):
                state = np.array([bits], dtype=np.bool_)
                if np.all(low <= state) and np.all(state <= high):
                    scores = scorer.scores(state)
                    self.assertTrue(np.all(lower <= scores), (statuses, bits, lower, scores))
                    self.assertTrue(np.all(scores <= upper), (statuses, bits, scores, upper))

    def test_static_extreme_weights_and_near_ties_stay_enclosed(self):
        low = np.zeros((2, 3), dtype=np.bool_)
        high = np.ones((2, 3), dtype=np.bool_)
        for weight in (0., 1., np.nextafter(1., 0.)):
            scorer = kernel((.1, np.nextafter(.1, np.inf)), (.2, np.nextafter(.2, -np.inf)), weight)
            lower, upper = envelope.score_intervals(scorer, low, high)
            for bits in product((False, True), repeat=3):
                scores = scorer.scores(np.array([bits, bits], dtype=np.bool_))
                self.assertTrue(np.all(lower <= scores))
                self.assertTrue(np.all(scores <= upper))

    def test_zero_width_with_ties_needs_no_separation(self):
        scorer = kernel((.2, .2), (.4, .4), 1.)
        q = np.array([.2, .5, .8], dtype=np.float64)
        uniforms = np.array([[.1, .5, .9], [.2, .4, .8]], dtype=np.float64)
        flags = envelope.ambiguity_indicators(scorer, q, q.copy(), q.copy(), uniforms)
        self.assertEqual(flags.dtype, np.bool_)
        self.assertFalse(np.any(flags))

    def test_all_fixed_under_positive_width_is_safe(self):
        scorer = kernel()
        q = np.full(3, .5, dtype=np.float64)
        flags = envelope.ambiguity_indicators(scorer, q, q - .1, q + .1,
                                              np.array([[.1, .9, .1]], dtype=np.float64))
        self.assertFalse(flags[0])

    def test_actual_counterfactual_crossing_is_always_flagged(self):
        scorer = kernel((0., 0.), (.0, .0), 0.)
        q = np.full(3, .5, dtype=np.float64)
        low, high = np.zeros(3, dtype=np.float64), np.ones(3, dtype=np.float64)
        uniforms = np.array([[.25, .75, .25], [.75, .25, .75]], dtype=np.float64)
        flags = envelope.ambiguity_indicators(scorer, q, low, high, uniforms)
        nominal = np.argmax(scorer.scores(uniforms < q), axis=1)
        saw_crossing = False
        for parameters in product((0., 1.), repeat=3):
            states = uniforms < np.array(parameters, dtype=np.float64)[None, :]
            winners = np.argmax(scorer.scores(states), axis=1)
            flips = winners != nominal
            saw_crossing |= bool(np.any(flips))
            self.assertTrue(np.all(~flips | flags))
        self.assertTrue(saw_crossing)

    def test_free_states_with_strong_static_winner_can_be_certified(self):
        scorer = kernel((1., 0.), (.5, .5), .99)
        q = np.full(3, .5, dtype=np.float64)
        flags = envelope.ambiguity_indicators(scorer, q, np.zeros(3, dtype=np.float64),
                                              np.ones(3, dtype=np.float64), np.full((2, 3), .5, dtype=np.float64))
        self.assertFalse(np.any(flags))

    def test_single_candidate_always_has_same_winner(self):
        scorer = replace(kernel(), candidates=("a",), incidence_positions=kernel().incidence_positions[:4],
                         attribute=np.array([.1], dtype=np.float64), lexical=np.array([.3], dtype=np.float64))
        q = np.full(3, .5, dtype=np.float64)
        self.assertFalse(np.any(envelope.ambiguity_indicators(scorer, q, np.zeros(3, dtype=np.float64),
                                                             np.ones(3, dtype=np.float64), np.full((1, 3), .5, dtype=np.float64))))

    def test_wrong_dtypes_invalid_boxes_and_invalid_incidence_fail_closed(self):
        scorer = kernel()
        states = np.zeros((1, 3), dtype=np.bool_)
        with self.assertRaises(ValueError):
            envelope.score_intervals(scorer, states.astype(np.float32), states)
        with self.assertRaises(ValueError):
            envelope.score_intervals(replace(scorer, attribute=scorer.attribute.astype(np.float32)), states, states)
        q = np.full(3, .5, dtype=np.float64)
        with self.assertRaises(ValueError):
            envelope.ambiguity_indicators(scorer, q.astype(np.float32), q, q, q[None, :])
        with self.assertRaises(ValueError):
            envelope.ambiguity_indicators(scorer, q, q + .1, q + .2, q[None, :])
        with self.assertRaises(ValueError):
            envelope.score_intervals(scorer, np.ones((1, 3), dtype=np.bool_), states)
        broken = replace(scorer, incidence_positions=(np.array([3], dtype=np.intp),) + scorer.incidence_positions[1:])
        with self.assertRaises(ValueError):
            envelope.score_intervals(broken, states, states)

    def test_hoeffding_fixed_n_upper_is_outward_and_clipped(self):
        for n in (1, 17, 4096):
            for count in (0, n // 2, n):
                direct = min(1., count / n + math.sqrt(math.log(1 / .0125) / (2 * n)))
                actual = envelope.confidence_upper(count, n, .0125)
                self.assertGreaterEqual(actual, direct)
                self.assertLessEqual(actual, 1.)
        self.assertEqual(envelope.confidence_upper(10, 10, .0125), 1.)
        for values in ((-1, 10, .1), (11, 10, .1), (0, 0, .1), (0, 10, 0.), (0, 10, 1.)):
            with self.assertRaises(ValueError):
                envelope.confidence_upper(*values)


if __name__ == "__main__":
    unittest.main()
