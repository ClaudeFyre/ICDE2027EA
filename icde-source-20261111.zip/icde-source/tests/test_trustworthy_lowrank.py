from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.trustworthy_lowrank import (
    _coverage_summary,
    _uncertainty_mondrian_margin,
)


class TrustworthyLowRankTests(unittest.TestCase):
    def test_mondrian_boundary_reports_observed_group_sizes(self) -> None:
        score_rows = [[0.9, 0.1] for _ in range(9)]
        report = _uncertainty_mondrian_margin(
            list(range(6)),
            [6, 7, 8],
            score_rows,
            [0] * 9,
            ("a", "b"),
            [0.0, 0.1, 1.0, 1.1, 2.0, 2.1, 0.05, 1.05, 2.05],
            alpha=0.5,
        )
        self.assertIn(
            "range from 1 to 3", report["guarantee_boundary"]
        )

    def test_margin_coverage_summary_uses_disjoint_indices(self) -> None:
        report = _coverage_summary(
            [0, 1],
            [2, 3],
            [
                [0.9, 0.1],
                [0.2, 0.8],
                [0.7, 0.3],
                [0.4, 0.6],
            ],
            [0, 1, 0, 1],
            ("a", "b"),
            alpha=0.5,
            method="margin",
        )
        self.assertEqual(report["calibration_queries"], 2)
        self.assertEqual(report["test_queries"], 2)
        self.assertEqual(report["empirical_coverage"], 1.0)
        self.assertEqual(report["average_set_size"], 1)


if __name__ == "__main__":
    unittest.main()
