from __future__ import annotations

import csv
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.data import convert_jape_dbp15k


class JAPEConversionTests(unittest.TestCase):
    def test_converter_preserves_split_without_translated_label_leak(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "zh_en"
            split = source / "0_3"
            split.mkdir(parents=True)
            fixtures = {
                "s_triples": "s:a\tr:left\ts:b\n",
                "t_triples": "t:a\tr:right\tt:b\n",
                "s_labels": "s:a\t中文名\tEnglish leak\n",
                "t_labels": "t:a\tEnglish name\t中文翻译\n",
                "training_attrs_1": "s:a\ta:left\n",
                "training_attrs_2": "t:a\ta:right\n",
            }
            for name, content in fixtures.items():
                (source / name).write_text(content, encoding="utf-8")
            split_fixtures = {
                "ent_ids_1": "0\ts:a\n1\ts:b\n",
                "ent_ids_2": "0\tt:a\n2\tt:b\n",
                "sup_ent_ids": "0\t0\n",
                "ref_ents": "s:b\tt:b\n",
            }
            for name, content in split_fixtures.items():
                (split / name).write_text(content, encoding="utf-8")
            output = root / "canonical"
            convert_jape_dbp15k(source, output)
            with (output / "entities.tsv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                entities = list(csv.DictReader(handle, delimiter="\t"))
            with (output / "alignments.tsv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                alignments = list(csv.DictReader(handle, delimiter="\t"))
        labels = {row["entity_id"]: row["label"] for row in entities}
        self.assertEqual(labels["s:a"], "中文名")
        self.assertNotIn("English leak", labels.values())
        self.assertEqual(
            {row["split"] for row in alignments},
            {"train", "test"},
        )


if __name__ == "__main__":
    unittest.main()
