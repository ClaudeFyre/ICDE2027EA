from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "src", ROOT / "scripts", ROOT / "scripts" / "backbones"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from run_www_equal_budget import (
    RESUME_FORMAT,
    adaptive_payload,
    atomic_write_json,
    load_adaptive_payload,
    full_payload,
    load_full_payload,
    load_representation_payload,
    load_resume_state,
    project_and_summarize,
    representation_payload,
    truth_mrr,
)
from pkgea.www_fsl import apply_entity_representations, empirical_gaussian


class WWWRunnerEngineeringTests(unittest.TestCase):
    def test_truth_mrr_uses_frozen_order_for_ties(self) -> None:
        distances = np.asarray([[0.1, 0.2, 0.3], [0.1, 0.1, 0.2]])
        truth = np.asarray([1, 1])
        self.assertAlmostEqual(truth_mrr(distances, truth), 0.5)

    def test_adaptive_payload_round_trip(self) -> None:
        rng = np.random.default_rng(71)
        means = rng.normal(size=(4, 4))
        raw = rng.normal(size=(4, 4, 4))
        covariances = np.einsum("eik,ejk->eij", raw, raw)
        payload, _ = adaptive_payload(
            means, covariances, [0, 1, 2, 4], {"test": True}
        )
        loaded_means, loaded_covariances = load_adaptive_payload(payload)
        np.testing.assert_allclose(loaded_means, means, rtol=1e-6, atol=1e-6)
        self.assertEqual(loaded_covariances.shape, covariances.shape)
        np.testing.assert_allclose(
            loaded_covariances[0], covariances[0], rtol=1e-6, atol=1e-6
        )
        self.assertGreater(len(payload), 0)

    def test_chunked_projected_moments_match_in_memory_reference(self) -> None:
        rng = np.random.default_rng(17)
        hidden = rng.normal(size=(37, 11, 8)).astype(np.float32)
        projection = rng.normal(size=(8, 4))
        actual_means, actual_covariances, _ = project_and_summarize(
            hidden, projection
        )
        expected_means, expected_covariances = empirical_gaussian(
            hidden.astype(np.float64) @ projection
        )
        np.testing.assert_allclose(actual_means, expected_means, rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(
            actual_covariances, expected_covariances, rtol=1e-12, atol=1e-12
        )

    def test_atomic_resume_round_trip_has_no_temporary_file(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.resume.json"
            payload = {
                "schema_version": RESUME_FORMAT,
                "checkpoint_sha256": "checkpoint-a",
                "dataset_revisions": {"structural": "revision-a"},
                "adapter_format_id": "adapter-a",
                "checkpoint_execution_format": "format-a",
                "protocol_digest": "protocol-a",
                "completed_units": {},
            }
            atomic_write_json(path, payload)
            self.assertEqual(json.loads(path.read_text(encoding="utf-8")), payload)
            self.assertFalse(path.with_name(path.name + ".partial.tmp").exists())

    def test_resume_rejects_dataset_revision_change(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.resume.json"
            original = {
                "schema_version": RESUME_FORMAT,
                "checkpoint_sha256": "checkpoint-a",
                "dataset_revisions": {"structural": "revision-a"},
                "adapter_format_id": "adapter-a",
                "checkpoint_execution_format": "format-a",
                "protocol_digest": "protocol-a",
                "completed_units": {},
            }
            atomic_write_json(path, original)
            changed_identity = {
                key: value
                for key, value in original.items()
                if key not in {"schema_version", "completed_units"}
            }
            changed_identity["dataset_revisions"] = {
                "structural": "revision-b"
            }
            with self.assertRaisesRegex(ValueError, "dataset_revisions"):
                load_resume_state(path, expected_identity=changed_identity)

    def test_atomic_json_rejects_nonfinite_values(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "invalid.json"
            with self.assertRaises(ValueError):
                atomic_write_json(path, {"value": float("nan")})
            self.assertFalse(path.exists())
            self.assertFalse(path.with_name(path.name + ".partial.tmp").exists())

    def test_full_fp16_and_mixed_payload_round_trip(self) -> None:
        means = np.asarray([[0.25, -0.5], [1.0, 2.0], [-1.0, 0.5]])
        covariances = np.asarray([
            [[1.0, 0.2], [0.2, 0.5]],
            [[0.8, 0.1], [0.1, 0.3]],
            [[0.6, -0.2], [-0.2, 0.9]],
        ])
        fp16 = full_payload(means, covariances, dtype=np.dtype(np.float16))
        loaded_means, loaded_covariances = load_full_payload(fp16)
        np.testing.assert_allclose(loaded_means, means, atol=5e-4)
        np.testing.assert_allclose(loaded_covariances, covariances, atol=5e-4)

        representations = ["diagonal", "rank_1", "full"]
        payload, _ = representation_payload(
            means, covariances, representations, {"workload_digest": "abc"}
        )
        mixed_means, mixed_covariances = load_representation_payload(payload)
        expected = apply_entity_representations(covariances, representations)
        np.testing.assert_allclose(mixed_means, means, atol=1e-6)
        np.testing.assert_allclose(mixed_covariances, expected, atol=1e-6)

        fp16_mixed, _ = representation_payload(
            means,
            covariances,
            representations,
            {"workload_digest": "abc"},
            dtype=np.dtype(np.float16),
        )
        fp16_mixed_means, fp16_mixed_covariances = load_representation_payload(
            fp16_mixed
        )
        np.testing.assert_allclose(fp16_mixed_means, means, atol=5e-4)
        np.testing.assert_allclose(fp16_mixed_covariances, expected, atol=2e-3)
        self.assertLess(len(fp16_mixed), len(payload))


if __name__ == "__main__":
    unittest.main()
