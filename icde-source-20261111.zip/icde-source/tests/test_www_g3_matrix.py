from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import run_www_g3_matrix as runner
import run_www_margin_selection as frozen


PYTHON = Path("python")


def plan(stage: str) -> list[dict[str, object]]:
    return [runner.task(stage, PYTHON, cell) for cell in runner.CELLS]


def test_cells_cover_both_families_and_both_dependence_profiles() -> None:
    assert len(runner.CELLS) == 4
    assert {cell[1] for cell in runner.CELLS} == {"gcn", "relation"}
    assert {cell[2] for cell in runner.CELLS} == {"independent", "structural"}
    assert runner.SWEEP_CELLS <= set(runner.CELLS)


def test_stage_seeds_match_the_frozen_matrix() -> None:
    assert runner.STAGE_SEEDS["main"] == (59, 71)
    assert runner.STAGE_SEEDS["margin-a"] == frozen.STAGE_SEEDS["a"]
    assert runner.STAGE_SEEDS["margin-b"] == frozen.STAGE_SEEDS["b"]
    assert {17, 1017}.isdisjoint(
        {seed for seeds in runner.STAGE_SEEDS.values() for seed in seeds}
    )


def test_estimator_contract_is_copied_verbatim_from_the_frozen_cells() -> None:
    for stage in runner.STAGE_SEEDS:
        for item in plan(stage):
            command = item["command"]
            assert command[command.index("--query-limit") + 1] == "500"
            assert command[command.index("--candidate-limit") + 1] == "1012"
            assert command[command.index("--gate-budget") + 1] == "2048"
            assert command[command.index("--reference-samples") + 1] == "4096"
            assert command[command.index("--selection-seed") + 1] == "17"
            assert command[command.index("--reference-seed") + 1] == "1017"
            seed_start = command.index("--test-seeds") + 1
            seed_end = command.index("--reference-seed")
            assert tuple(map(int, command[seed_start:seed_end])) == (
                runner.STAGE_SEEDS[stage]
            )


def test_margin_mode_is_set_for_margin_stages_only() -> None:
    assert all("--margin-aware-experiment" not in i["command"] for i in plan("main"))
    for stage in ("margin-a", "margin-b"):
        assert all("--margin-aware-experiment" in i["command"] for i in plan(stage))


def test_budget_sweep_is_limited_to_the_two_representative_main_cells() -> None:
    sweeps = [item for item in plan("main") if item["representative_budget_sweep"]]
    assert len(sweeps) == 2
    assert all(item["budgets"] == [64, 128, 256, 512, 2048] for item in sweeps)
    for stage in ("margin-a", "margin-b"):
        assert all(item["budgets"] == [2048] for item in plan(stage))


def test_results_stay_inside_the_g3_namespace() -> None:
    frozen_roots = (
        ROOT / "nodes/04_www_distributional/results/main_matrix",
        ROOT / "nodes/04_www_distributional/results/margin_selection",
        ROOT / "nodes/03_wsdm",
    )
    for stage in runner.STAGE_SEEDS:
        for item in plan(stage):
            output = Path(str(item["output"]))
            assert runner.RESULTS in output.parents
            for root in frozen_roots:
                assert root not in output.parents
            # G3 owns both encoder families; nothing is read from the WSDM tree.
            assert "03_wsdm" not in str(item["checkpoint"])


def test_g3_dataset_config_matches_the_frozen_probe_contract() -> None:
    profile = runner.dataset_profile()
    assert profile["split_counts"] == {"train": 512, "test": 500}
    assert set(profile["dataset_content_digests"]) == {"probe", "independent", "shared"}
    assert len(set(profile["dataset_content_digests"].values())) == 3


def test_the_cross_host_gate_uses_the_portable_digest_only() -> None:
    """The revision digest differs between hosts; it must not be the gate."""

    profile = runner.dataset_profile()
    assert "local_dataset_revisions" in profile
    source = Path(runner.__file__).read_text(encoding="utf-8")
    assert "dataset_content_digest" in source
    assert "dataset_revision_digest" not in source
