"""Checks for paired U reuse, independent runs and structural overlap evidence."""

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
for name in (ROOT / "scripts", ROOT / "src"):
    if str(name) not in sys.path:
        sys.path.insert(0, str(name))

from run_vldb_budget_gate_v2 import (
    _settings, aggregate_policy_rows, capture_paired_stream, source_candidate_overlap,
)


class CountingKernel:
    edge_indices = (0, 1)
    candidates = ("a", "b")

    def __init__(self):
        self.score_calls = 0
        self.score_objects = []

    def scores(self, states):
        self.score_calls += 1
        scores = np.column_stack((states[:, 0], states[:, 1])).astype(np.float64)
        self.score_objects.append(scores)
        return scores

    def ambiguity_indicators(self, q, low, high, uniforms, nominal_scores=None):
        if nominal_scores is not self.score_objects[-1]:
            raise AssertionError("nominal scores were recomputed or not cached")
        return np.any((uniforms < low) != (uniforms < high), axis=1)


def source_stub(compiled, q, low, high, uniforms, *, nominal_scores, difference_flags, max_source_assignments):
    if nominal_scores is not compiled.score_objects[-1]:
        raise AssertionError("source core did not receive the shared score matrix")
    n = len(uniforms)
    return difference_flags.copy(), {
        "free_flags": difference_flags.copy(),
        "conditioning_assignment_counts": np.zeros(n, dtype=np.int64),
        "conditioning_degree_rows": np.zeros(n, dtype=np.int64),
    }


class BudgetGateDriverTests(unittest.TestCase):
    def boxes(self):
        return [{"tau": value, "low": np.array([0.4, 0.4], dtype=np.float64),
                 "high": np.array([0.6, 0.6], dtype=np.float64),
                 "epsilon_scope_upper": 0.36, "epsilon_full_graph_upper": 0.8,
                 "endpoint_audit": {"fixture": True}}
                for value in (0.001, 0.01)]

    def test_one_uniform_matrix_and_one_nominal_evaluation_per_chunk(self):
        kernel = CountingKernel()
        result = capture_paired_stream(kernel, np.array([0.5, 0.5]), self.boxes(), seed=41,
                                       sample_count=17, chunk_size=5, source_indicator=source_stub)
        self.assertEqual(kernel.score_calls, 4)
        self.assertEqual(result["nominal_score_rows_evaluated"], 17)
        self.assertEqual(result["random_uniform_draws"], 34)
        self.assertEqual(result["additional_event_random_draws"], 0)
        self.assertEqual(len(result["winner_indices"]), 17)
        for row in result["tau_records"]:
            self.assertEqual(row["h_difference"], row["h_source_conditioned"])
            self.assertEqual(len(row["conditioning_degree_rows"]), 17)

    def test_chunking_preserves_same_uniform_hash_winners_and_flags(self):
        one = capture_paired_stream(CountingKernel(), np.array([0.5, 0.5]), self.boxes(), seed=41,
                                    sample_count=32, chunk_size=5, source_indicator=source_stub)
        two = capture_paired_stream(CountingKernel(), np.array([0.5, 0.5]), self.boxes(), seed=41,
                                    sample_count=32, chunk_size=8, source_indicator=source_stub)
        self.assertEqual(one["uniform_sha256"], two["uniform_sha256"])
        self.assertEqual(one["winner_indices"], two["winner_indices"])
        self.assertEqual(one["tau_records"][0]["h_difference"], two["tau_records"][0]["h_difference"])
        independent = capture_paired_stream(CountingKernel(), np.array([0.5, 0.5]), self.boxes(), seed=53,
                                            sample_count=32, chunk_size=8, source_indicator=source_stub)
        self.assertNotEqual(one["uniform_sha256"], independent["uniform_sha256"])

    def test_malformed_source_work_ledger_is_rejected(self):
        def invalid_source(*args, **kwargs):
            flags, metadata = source_stub(*args, **kwargs)
            metadata["conditioning_assignment_counts"] = np.full(len(flags), -1, dtype=np.int64)
            return flags, metadata
        with self.assertRaisesRegex(ValueError, "nonnegative integer"):
            capture_paired_stream(CountingKernel(), np.array([0.5, 0.5]), self.boxes(), seed=41,
                                  sample_count=8, chunk_size=8, source_indicator=invalid_source)

    def test_cross_graph_disjoint_and_shared_directed_incidence_are_distinguished(self):
        disjoint = SimpleNamespace(candidates=("a",), incidence_positions=(
            np.array([0]), np.array([1]), np.array([2]), np.array([3])))
        self.assertEqual(source_candidate_overlap(disjoint)["pairs_with_shared_incident_edge"], 0)
        shared = SimpleNamespace(candidates=("a",), incidence_positions=(
            np.array([0]), np.array([1]), np.array([0]), np.array([3])))
        audit = source_candidate_overlap(shared)
        self.assertEqual(audit["source_out_target_out"], 1)
        self.assertEqual(audit["pairs_with_shared_incident_edge"], 1)

    def test_default_fresh_seeds_and_invalid_seed_reuse(self):
        settings = _settings({"tau_grid": [0.001, 0.01]})
        self.assertEqual(settings["fresh_nominal_seeds"], (41, 53))
        self.assertEqual(settings["seed_purpose"], "v2_budget_worlds")
        with self.assertRaisesRegex(ValueError, "distinct"):
            _settings({"tau_grid": [0.001], "fresh_nominal_seeds": [41, 41]})

    def test_policy_aggregation_keeps_budget_and_policy_separate(self):
        rows = []
        for seed, stable in ((41, True), (53, False)):
            rows.append({"graph": "D-W", "query_id": "q", "nominal_seed": seed,
                         "candidate_count": 2, "tau": 0.001, "budget_fraction": 1.0,
                         "interval_work_weight": 1.0,
                         "policy": "scope", "stable": stable, "samples_used": 32,
                         "event_samples_used": 0, "work_used": 100, "work_budget": 120,
                         "status": "stable" if stable else "budget_exhausted"})
        result = aggregate_policy_rows(rows)
        self.assertEqual(result[0]["unique_queries"], 1)
        self.assertEqual(result[0]["query_seed_cases"], 2)
        self.assertEqual(result[0]["coverage"], 0.5)
        self.assertEqual(result[0]["certified_past_budget_cases"], 0)
        extra = {**rows[0], "interval_work_weight": 4.0, "stable": False}
        self.assertEqual(len(aggregate_policy_rows([*rows, extra])), 2)


if __name__ == "__main__":
    unittest.main()
