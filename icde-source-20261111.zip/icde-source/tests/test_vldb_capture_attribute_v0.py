"""Small deterministic capture checks; no real WSDM capture is started here."""

from __future__ import annotations

import itertools
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
for entry in (ROOT, ROOT / "src"):
    if str(entry) not in sys.path:
        sys.path.insert(0, str(entry))

from pkgea.backbones.attribute import AttributeStructuralBackbone
from pkgea.backbones.toy import ToyStructuralBackbone
from scripts.vldb_capture_attribute_v0 import (
    audit_coupled_scores,
    build_degree_kernel,
    capture_attribute,
    generate_winner_indices,
    select_queries,
    stream_seed,
)


class AttributeCaptureTests(unittest.TestCase):
    def setUp(self) -> None:
        (ROOT / "tmp").mkdir(exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(
            prefix="vldb-attribute-test-", dir=ROOT / "tmp"
        )
        self.addCleanup(self.temporary.cleanup)
        self.workspace = Path(self.temporary.name)
        self.dataset = self.workspace / "data"
        shutil.copytree(ROOT / "data/toy/exact_world_minimal", self.dataset)

    def test_hash_query_selection_is_order_independent_and_seeded_by_identity(self) -> None:
        sources = ["source-a", "source-b", "source-c", "source-d"]
        self.assertEqual(select_queries(sources, 2), select_queries(list(reversed(sources)), 2))
        self.assertNotEqual(stream_seed("g", "r", "a", 11, "stream"),
                            stream_seed("g", "r", "a", 17, "stream"))
        self.assertNotEqual(stream_seed("g", "r", "a", 11, "stream"),
                            stream_seed("g", "r", "a", 11, "audit"))
        with self.assertRaises(ValueError):
            select_queries(["a", "a"], 1)

    def test_float64_kernel_matches_backbone_for_every_toy_world(self) -> None:
        backbone = AttributeStructuralBackbone.from_dataset(self.dataset)
        candidates = tuple(sorted(backbone.target_entities))
        kernel = build_degree_kernel(
            backbone, "s:bob", candidates, tuple(range(len(backbone.triples)))
        )
        states = np.asarray(list(itertools.product((False, True), repeat=4)), dtype=np.bool_)
        observed = kernel.scores(states)
        expected = np.asarray([
            [backbone.score_subset(tuple(state), ("s:bob",), candidates)["s:bob", candidate]
             for candidate in candidates]
            for state in states
        ], dtype=np.float64)
        self.assertEqual(observed.dtype, np.float64)
        np.testing.assert_array_equal(observed, expected)
        audit = audit_coupled_scores(backbone, kernel, states)
        self.assertEqual(audit["maximum_absolute_score_error"], 0.0)
        self.assertTrue(audit["full_pool_winner_equal"])

    def test_empty_scope_uses_fixed_lexical_tie_and_missing_dependency_is_rejected(self) -> None:
        structural = ToyStructuralBackbone(
            triples=[{"head_id": "s", "tail_id": "other"}],
            source_entities=("s",), target_entities=("a", "b"),
            all_entities=("s", "other", "a", "b"),
            labels={"s": "s", "other": "other", "a": "a", "b": "b"},
            lexical_scores={("s", "a"): 0.0, ("s", "b"): 0.0},
        )
        backbone = AttributeStructuralBackbone(
            structural, {("s", "a"): 0.0, ("s", "b"): 0.0}, 0.8,
        )
        incomplete = build_degree_kernel(backbone, "s", ("a", "b"), ())
        scores = incomplete.scores(np.zeros((3, 0), dtype=np.bool_))
        self.assertEqual(np.argmax(scores, axis=1).tolist(), [0, 0, 0])
        with self.assertRaisesRegex(AssertionError, "full/local"):
            audit_coupled_scores(backbone, incomplete, np.asarray([[True]], dtype=np.bool_))

    def test_stream_prefix_and_chunking_are_reproducible(self) -> None:
        backbone = AttributeStructuralBackbone.from_dataset(self.dataset)
        kernel = build_degree_kernel(backbone, "s:bob", tuple(sorted(backbone.target_entities)),
                                     tuple(range(4)))
        probabilities = np.asarray([0.8, 0.6, 0.75, 0.55], dtype=np.float64)
        one, cost = generate_winner_indices(kernel, probabilities, 32, 11, 8)
        two, _ = generate_winner_indices(kernel, probabilities, 32, 11, 5)
        prefix, _ = generate_winner_indices(kernel, probabilities, 10, 11, 3)
        self.assertEqual(one, two)
        self.assertEqual(one[:10], prefix)
        self.assertEqual(cost["sampled_edge_variables"], 128)
        self.assertFalse(cost["early_stopping_speedup_claim"])

    def _config(self) -> dict:
        return {
            "profiles": [{"graph": "toy", "dataset_path": "data"}],
            "query_count": 2, "expected_query_pool": 2,
            "seeds": [11, 17], "sample_count": 32, "chunk_size": 8,
            "audit_worlds": 8, "required_pythonhashseed": None,
        }

    def test_capture_writes_replay_schema_complete_candidates_scopes_and_order(self) -> None:
        report = capture_attribute(self._config(), self.workspace, Path("out_a"))
        repeat = capture_attribute(self._config(), self.workspace, Path("out_b"))
        self.assertEqual(report["status"], "ATTRIBUTE_CAPTURE_COMPLETE")
        self.assertEqual(len(report["manifest_paths"]), 2)
        self.assertFalse(report["ea_accuracy_evaluated"])
        for first_path, second_path in zip(report["manifest_paths"], repeat["manifest_paths"]):
            first = json.loads((self.workspace / first_path).read_text("utf-8"))
            second = json.loads((self.workspace / second_path).read_text("utf-8"))
            self.assertEqual(first["schema_version"], "vldb-categorical-stream-v1")
            self.assertEqual(first["world_law"]["semantics"], "declared")
            self.assertFalse(first["world_law"]["real_probability_calibration_claim"])
            for row, repeated in zip(first["queries"], second["queries"]):
                self.assertEqual(row["winner_indices"], repeated["winner_indices"])
                self.assertEqual(len(row["winner_indices"]), 32)
                self.assertEqual(row["candidate_ids"], sorted(row["candidate_ids"]))
                self.assertEqual(row["scope_edge_count"], len(row["scope_edge_indices"]))
                self.assertEqual(row["scope_edge_count"],
                                 len(row["scope_certificate"]["edge_ids"]))
                self.assertTrue(row["scope_certificate"]["exact"])
                self.assertEqual(row["coupled_audit"]["worlds"], 8)
                self.assertNotIn("truth", row)
        with self.assertRaises(FileExistsError):
            capture_attribute(self._config(), self.workspace, Path("out_a"))

    def test_correlated_input_and_external_paths_are_rejected(self) -> None:
        metadata_path = self.dataset / "confidence_metadata.json"
        metadata = json.loads(metadata_path.read_text("utf-8"))
        metadata["edge_dependence"]["assumption"] = "grouped_shared_latent"
        metadata_path.write_text(json.dumps(metadata), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "independent"):
            capture_attribute(self._config(), self.workspace, Path("out"))
        failure = json.loads((self.workspace / "out/capture_failure.json").read_text("utf-8"))
        self.assertEqual(failure["status"], "ATTRIBUTE_CAPTURE_STOP")
        config = self._config()
        config["profiles"][0]["dataset_path"] = "../outside"
        with self.assertRaises(ValueError):
            capture_attribute(config, self.workspace, Path("escaped"))


if __name__ == "__main__":
    unittest.main()
