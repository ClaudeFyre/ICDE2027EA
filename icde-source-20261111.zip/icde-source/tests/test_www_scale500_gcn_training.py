import json
import tempfile
import unittest
from pathlib import Path

from scripts.run_www_scale500_gcn_training import artifact_paths, completed


class WWWScale500GCNTrainingTest(unittest.TestCase):
    def test_namespaces_standard_gcn_away_from_wsdm_checkpoints(self) -> None:
        checkpoint, descriptor, log = artifact_paths("dw", 17)
        self.assertIn("04_www_distributional", checkpoint.parts)
        self.assertIn("checkpoints", checkpoint.parts)
        self.assertEqual(checkpoint.name, "gcn_align_dw_scale500_s17.pt")
        self.assertEqual(descriptor.suffixes, [".descriptor", ".json"])
        self.assertEqual(log.name, "train_dw_s17.log")

    def test_completed_requires_matching_digest_adapter_and_seed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            checkpoint = root / "checkpoint.pt"
            descriptor = root / "checkpoint.descriptor.json"
            checkpoint.write_bytes(b"frozen")
            import hashlib
            descriptor.write_text(json.dumps({
                "adapter_id": "pkgea/torch-gcn-align-v1",
                "seed": 17,
                "checkpoint_sha256": hashlib.sha256(b"frozen").hexdigest(),
            }), encoding="utf-8")
            self.assertTrue(completed(checkpoint, descriptor, seed=17))
            checkpoint.write_bytes(b"changed")
            self.assertFalse(completed(checkpoint, descriptor, seed=17))


if __name__ == "__main__":
    unittest.main()
