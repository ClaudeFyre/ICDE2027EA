from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import run_www_margin_selection as runner
import summarize_www_margin_selection as summary


def test_stage_seed_roles_are_preregistered_and_disjoint() -> None:
    assert runner.STAGE_SEEDS == {"a": (59, 71), "b": (83, 97, 103)}
    assert {17, 1017}.isdisjoint(
        set(runner.STAGE_SEEDS["a"]) | set(runner.STAGE_SEEDS["b"])
    )


def test_all_tasks_explicitly_enable_margin_mode_and_test_seeds() -> None:
    for stage in ("a", "b"):
        tasks = [runner.task(stage, *cell) for cell in runner.CELLS]
        assert len(tasks) == 8
        for item in tasks:
            command = item["command"]
            assert "--margin-aware-experiment" in command
            seed_position = command.index("--test-seeds") + 1
            reference_position = command.index("--reference-seed")
            assert tuple(map(int, command[seed_position:reference_position])) == (
                runner.STAGE_SEEDS[stage]
            )
            assert command[command.index("--query-limit") + 1] == "500"
            assert command[command.index("--candidate-limit") + 1] == "1012"
            assert command[command.index("--gate-budget") + 1] == "2048"
            assert command[command.index("--reference-samples") + 1] == "4096"


def test_slack_relation_is_predeclared_and_lexicographic() -> None:
    def gate(flips: int, minimum: float, tau: float = 1e-12) -> dict:
        return {
            "slack_diagnostics": {
                "authoritative_flipped_source_count": flips,
                "tau_slack": tau,
                "minimum_slack_summary": {"min": minimum},
            }
        }

    assert summary.slack_relation(gate(2, -1.0), gate(1, -2.0)) == "improved"
    assert summary.slack_relation(gate(1, -1.0), gate(2, 1.0)) == "worsened"
    assert summary.slack_relation(gate(1, -1.0), gate(1, -0.5)) == "improved"
    assert summary.slack_relation(gate(1, -1.0), gate(1, -1.0)) == "unchanged"


def test_wilson_interval_contains_observed_rate() -> None:
    low, high = summary.wilson(3, 5)
    assert low < 0.6 < high


def test_stage_b_robustness_wording_threshold_is_frozen() -> None:
    assert summary.robustness_label(40) == "robust_all_tested_units"
    assert summary.robustness_label(39) == "mostly_robust_name_failed_units"
    assert summary.robustness_label(38) == "mostly_robust_name_failed_units"
    assert summary.robustness_label(37) == "stage_a_16of16_contains_seed_luck"
