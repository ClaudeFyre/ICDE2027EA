import json
import subprocess
import sys
import unittest
from pathlib import Path, PurePosixPath

from scripts.verify_recovery import is_sqlite_sidecar
from scripts.package_handoff import artifact_files


ROOT = Path(__file__).resolve().parents[1]
PLAN = ROOT / "configs" / "handoff_experiments.json"


class HandoffPlanTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.payload = json.loads(PLAN.read_text(encoding="utf-8"))
        cls.tasks = cls.payload["tasks"]

    def test_task_ids_and_outputs_are_unique(self):
        ids = [task["id"] for task in self.tasks]
        self.assertEqual(len(ids), len(set(ids)))
        outputs = [path for task in self.tasks for path in task["expected_outputs"]]
        self.assertEqual(len(outputs), len(set(outputs)))

    def test_paths_are_portable_and_relative(self):
        for task in self.tasks:
            for value in (*task["requires"], *task["expected_outputs"]):
                path = PurePosixPath(value)
                self.assertFalse(path.is_absolute(), (task["id"], value))
                self.assertNotIn("..", path.parts, (task["id"], value))
                self.assertNotIn("\\", value, (task["id"], value))

    def test_ready_tasks_have_one_safe_command(self):
        for task in self.tasks:
            self.assertIn(task["host"], ("local16", "cpu64", "gpu32"))
            if task["status"] == "deferred_code":
                self.assertEqual(task["command"], [])
                continue
            self.assertIn(task["status"], ("ready", "optional", "completed"))
            self.assertGreater(task["max_runtime_minutes"], 0)
            self.assertTrue(task["command"])
            self.assertEqual(task["command"][0], "{python}")
            self.assertFalse(any(part in (";", "&&", "|") for part in task["command"]))
            if task["status"] == "completed":
                for output in task["expected_outputs"]:
                    self.assertTrue((ROOT / output).exists(), (task["id"], output))

    def test_sqlite_wal_and_shm_are_not_classified_as_partial_outputs(self):
        self.assertTrue(is_sqlite_sidecar(Path("snapshots.sqlite-wal")))
        self.assertTrue(is_sqlite_sidecar(Path("snapshots.sqlite-shm")))
        self.assertFalse(is_sqlite_sidecar(Path("snapshots.sqlite.part")))
        self.assertFalse(is_sqlite_sidecar(Path("unrelated-wal")))

    def test_pkgea_handoff_subcommands_exist(self):
        commands = {
            task["command"][3]
            for task in self.tasks
            if task["command"][:3] == ["{python}", "-m", "pkgea"]
        }
        help_result = subprocess.run(
            [sys.executable, "-m", "pkgea", "--help"],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        for command in commands:
            self.assertIn(command, help_result.stdout)

    def test_handoff_excludes_restricted_cn15k_checkpoints(self):
        for path in artifact_files():
            relative = path.relative_to(ROOT).as_posix()
            self.assertFalse(
                relative.startswith("nodes/01_benchmark/checkpoints/"),
                relative,
            )


if __name__ == "__main__":
    unittest.main()
