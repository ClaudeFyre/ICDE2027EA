"""Hard admission counterexamples using only saved-prefix fixtures."""

from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from vldb_budget_policy_v2_hard import EVENT_FIELDS, run_hard_budget_policy
from vldb_event_bound_v2 import fixed_n_binomial_upper, validate_risk_plan


class GuardedPrefix:
    """Expose length freely but fail if a replay peeks beyond paid evidence."""

    def __init__(self, values, limit=0):
        self.values = values
        self.limit = limit
        self.reads = []

    def __len__(self):
        return len(self.values)

    def __iter__(self):
        raise AssertionError("unadmitted event prefix was scanned")

    def __getitem__(self, key):
        if not isinstance(key, slice) or key.step not in (None, 1):
            raise AssertionError("event evidence must be revealed as a contiguous block")
        start = 0 if key.start is None else key.start
        stop = len(self.values) if key.stop is None else key.stop
        if not 0 <= start <= stop <= self.limit:
            raise AssertionError("unadmitted event prefix was read")
        self.reads.append((start, stop))
        return self.values[key]


class HardBudgetPolicyTests(unittest.TestCase):
    def settings(self, weight=1.0):
        return {
            "delta_total": .05, "delta_nominal": .025, "beta_total": .025,
            "tau_grid": [.001, .01], "event_checkpoints": [96, 224, 480, 992],
            "budget_fractions": [1.0], "interval_work_weights": [weight],
            "max_source_assignments": 4,
            "nominal": {"rho": 64., "minimum_samples": 32, "check_every": 64},
            "work_model": {"nominal_candidate_units": 16,
                           "interval_candidate_units": 64,
                           "conditioned_candidate_units": 64},
        }

    def query(self, *, flags=False, free=False, scope=1.0):
        return {
            "graph": "toy", "query_id": "q", "nominal_seed": 41,
            "candidate_count": 2, "scope_edge_count": 1,
            "winner_indices": [0] * 1024,
            "cost_model": {"original_incidence_entries": 1,
                           "interval_incidence_entries": 1,
                           "source_incidence_entries": 1},
            "tau_records": [{
                "tau": tau, "epsilon_scope_upper": scope,
                "h_difference": [flags] * 1024,
                "h_source_conditioned": [flags] * 1024,
                "free_flags": [free] * 1024,
                "conditioning_degree_rows": [0] * 1024,
                "conditioning_assignment_counts": [0] * 1024,
            } for tau in (.001, .01)],
        }

    def guard(self, query, limit=0):
        for tau in query["tau_records"]:
            for field in EVENT_FIELDS:
                tau[field] = GuardedPrefix(tau[field], limit)

    def assert_hard_caps(self, rows):
        self.assertTrue(rows)
        for row in rows:
            self.assertEqual(row["admission"], "conservative_preexecution")
            self.assertLessEqual(row["work_used"], row["work_budget"])
            self.assertEqual(row["work_overshoot"], 0.)
            self.assertTrue(all(t["work_completed"] <= row["work_budget"]
                                for t in row["trace"]))

    def test_scope_certification_never_reveals_any_event_values(self):
        query = self.query(scope=0.)
        self.guard(query)
        rows = run_hard_budget_policy(query, self.settings())
        self.assert_hard_caps(rows)
        self.assertTrue(all(row["stable"] for row in rows))
        self.assertEqual({row["nominal_delta"] for row in rows}, {.025, .05})
        for row in rows:
            self.assertEqual(row["event_samples_used"], 0)
            self.assertEqual(row["work_used"], (row["samples_used"] + 1)
                             * row["nominal_unit_work"])

    def test_single_candidate_has_initial_charge_and_no_worlds_or_event_reads(self):
        query = self.query()
        query["candidate_count"] = 1
        self.guard(query)
        settings = self.settings()
        settings["budget_fractions"] = [.0001]
        rows = run_hard_budget_policy(query, settings)
        self.assert_hard_caps(rows)
        for row in rows:
            self.assertTrue(row["stable"])
            self.assertEqual(row["samples_used"], 0)
            self.assertEqual(row["event_samples_used"], 0)
            self.assertEqual(row["work_used"], row["nominal_unit_work"])

    def test_impossible_upgrade_does_not_peek_and_nominal_sampling_continues(self):
        query = self.query(flags=True, free=True)
        for tau in query["tau_records"]:
            tau["conditioning_degree_rows"] = [1] * 1024
            tau["conditioning_assignment_counts"] = [4] * 1024
        self.guard(query)
        rows = run_hard_budget_policy(query, self.settings(weight=100000.))
        self.assert_hard_caps(rows)
        for row in rows:
            self.assertFalse(row["stable"])
            self.assertEqual(row["samples_used"], 1024)
            self.assertEqual(row["event_samples_used"], 0)
            self.assertEqual(row["event_ambiguity_upper"], 1.)
            if not row["policy"].startswith("scope_"):
                self.assertGreater(row["event_admission_rejections"], 1)
                attempts = [t for t in row["trace"] if t["event_upgrade_to"]]
                self.assertTrue(all(t["event_admission"] == "rejected_budget"
                                    and t["event_actual_charge"] == 0 for t in attempts))
                self.assertTrue(all(t["event_upgrade_to"] == 96 for t in attempts))

    def test_unaffordable_static_bound_rejects_even_when_hidden_actual_cost_is_cheap(self):
        query = self.query()
        self.guard(query)
        settings = self.settings()
        settings["budget_fractions"] = [.1]
        rows = run_hard_budget_policy(query, settings)
        self.assert_hard_caps(rows)
        eager = [r for r in rows if r["policy"] == "difference_eager"]
        for row in eager:
            first = next(t for t in row["trace"] if t["event_upgrade_to"] is not None)
            # At n=96 the hidden all-fixed event block costs 192, which fits
            # the 204 remaining units.  It must still be rejected because
            # finding that out would inspect an unadmitted block.
            self.assertLessEqual(192, row["work_budget"] - first["work_completed"])
            self.assertEqual(first["event_admission"], "rejected_budget")
            self.assertEqual(row["samples_used"], 102)
            self.assertEqual(row["event_samples_used"], 0)

    def test_complete_paid_prefix_reuses_the_unchanged_protected_binomial_bound(self):
        query = self.query(free=True)
        for tau in query["tau_records"]:
            tau["h_difference"][:2] = [True, True]
            tau["h_source_conditioned"][:2] = [True, True]
        self.guard(query, limit=96)
        settings = self.settings(weight=.1)
        rows = run_hard_budget_policy(query, settings)
        self.assert_hard_caps(rows)
        plan = validate_risk_plan(settings)
        expected = fixed_n_binomial_upper(2, 96, plan["alpha_per_checkpoint"])
        events = [r for r in rows if not r["policy"].startswith("scope_")]
        self.assertTrue(all(row["stable"] for row in events))
        for row in events:
            self.assertEqual(row["event_samples_used"], 96)
            self.assertEqual(row["event_ambiguity_upper"], expected)
            self.assertEqual(row["event_bernoulli_uniforms_added"], 0)
            self.assertLessEqual(row["event_samples_used"], row["samples_used"])
            self.assertEqual(row["event_upgrades_admitted"], 1)
        for tau in query["tau_records"]:
            self.assertTrue(tau["h_difference"].reads)
            self.assertTrue(all(stop == 96 for _, stop in tau["h_difference"].reads))

    def test_maximum_source_work_is_admitted_without_overshoot_using_configured_units(self):
        query = self.query(flags=True, free=True)
        settings = self.settings(weight=.125)
        settings["max_source_assignments"] = 3
        settings["work_model"] = {"nominal_candidate_units": 31,
                                  "interval_candidate_units": 7,
                                  "conditioned_candidate_units": 11}
        for tau in query["tau_records"]:
            tau["conditioning_degree_rows"] = [1] * 1024
            tau["conditioning_assignment_counts"] = [3] * 1024
        rows = run_hard_budget_policy(query, settings)
        self.assert_hard_caps(rows)
        for row in rows:
            self.assertFalse(row["stable"])
            for step in row["trace"]:
                self.assertLessEqual(step["event_samples"], step["nominal_samples"])
                self.assertIn(step["event_samples"], [0, *settings["event_checkpoints"]])
            if row["policy"] == "source_conditioned_lazy":
                paid = [t for t in row["trace"] if t["event_admission"] == "approved"]
                self.assertTrue(paid)
                for step in paid:
                    self.assertEqual(step["event_actual_charge"], step["event_upper_charge"])
                # Maximal nonstandard counters cost 88 units per event row
                # before the 1/8 weight.  This detects hidden 64-unit constants.
                self.assertEqual(paid[0]["event_actual_charge"], 96 * 11.)

    def test_expensive_unresolved_runs_obey_caps_for_every_weight_and_fraction(self):
        query = self.query(flags=True, free=True)
        for tau in query["tau_records"]:
            tau["conditioning_degree_rows"] = [1] * 1024
            tau["conditioning_assignment_counts"] = [4] * 1024
        settings = self.settings()
        settings["budget_fractions"] = [.25, 1.]
        settings["interval_work_weights"] = [.5, 1., 2., 100000.]
        rows = run_hard_budget_policy(query, settings)
        self.assert_hard_caps(rows)
        self.assertTrue(all(not row["stable"] for row in rows))

    def test_incomplete_prefix_rejected_without_reading_event_values(self):
        query = self.query()
        query["tau_records"][0]["free_flags"].pop()
        self.guard(query)
        with self.assertRaisesRegex(ValueError, "prefixes"):
            run_hard_budget_policy(query, self.settings())

    def test_invalid_paid_refinement_and_excess_partition_count_fail_closed(self):
        query = self.query(free=True)
        query["tau_records"][0]["h_source_conditioned"][0] = True
        with self.assertRaisesRegex(ValueError, "refine"):
            run_hard_budget_policy(query, self.settings(weight=.1))
        query = self.query(flags=True, free=True)
        query["tau_records"][0]["conditioning_assignment_counts"][0] = 5
        with self.assertRaisesRegex(ValueError, "assignment count"):
            run_hard_budget_policy(query, self.settings(weight=.1))

    def test_negative_static_cost_and_overspent_risk_plan_are_rejected(self):
        query = self.query()
        query["cost_model"]["interval_incidence_entries"] = -1
        with self.assertRaisesRegex(ValueError, "interval_incidence_entries"):
            run_hard_budget_policy(query, self.settings())
        settings = self.settings()
        settings["delta_nominal"] = .04
        with self.assertRaisesRegex(ValueError, "risk exceeds"):
            run_hard_budget_policy(self.query(), settings)


if __name__ == "__main__":
    unittest.main()
