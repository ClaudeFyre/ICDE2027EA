from __future__ import annotations

import csv
import json
import math
import tempfile
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.cli import ALLOWED_NODE_STATUSES, check_layout
from pkgea.contracts import validate_dataset
from pkgea.generators import BenchmarkGeneratorConfig, generate_benchmark
from pkgea.worlds import enumerate_independent_worlds


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class ContractTests(unittest.TestCase):
    def test_repository_layout_is_complete(self) -> None:
        report = check_layout(ROOT)
        self.assertTrue(report["ok"], [*report["missing"], *report["errors"]])
        self.assertEqual(report["node_statuses"]["00_audit"], "blocked")
        self.assertEqual(report["node_statuses"]["03_wsdm"], "completed")
        # Every node must carry one of the four statuses defined in
        # nodes/README.md.  Pinning the set to {blocked, completed} contradicted
        # that contract and failed as soon as a node moved to in_progress.
        self.assertLessEqual(
            set(report["node_statuses"].values()),
            ALLOWED_NODE_STATUSES,
        )

    def test_toy_dataset_matches_contract(self) -> None:
        report = validate_dataset(TOY)
        self.assertEqual(report.entity_count, 6)
        self.assertEqual(report.relation_count, 2)
        self.assertEqual(report.triple_count, 4)
        self.assertEqual(report.alignment_count, 3)
        self.assertEqual(report.confidence_types, ("calibrated_probability",))

    def test_exact_world_probability_mass(self) -> None:
        summary = enumerate_independent_worlds(TOY)
        self.assertEqual(summary.uncertain_edge_count, 4)
        self.assertEqual(summary.world_count, 16)
        self.assertTrue(math.isclose(summary.total_probability_mass, 1.0))
        self.assertTrue(math.isclose(summary.expected_active_edges, 2.7))

    def test_benchmark_generation_is_reproducible(self) -> None:
        config = BenchmarkGeneratorConfig(
            mechanism="cross_kg_correlated", seed=29, shared_strength=0.8
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            first = generate_benchmark(TOY, Path(temp_dir) / "first", config)
            second = generate_benchmark(TOY, Path(temp_dir) / "second", config)
            self.assertEqual(
                (first / "triples.tsv").read_text(encoding="utf-8"),
                (second / "triples.tsv").read_text(encoding="utf-8"),
            )
            report = validate_dataset(first)
            self.assertEqual(report.triple_count, 4)
            text = (first / "triples.tsv").read_text(encoding="utf-8")
            self.assertIn("aligned-neighborhood", text)
            with (first / "triples.tsv").open(
                encoding="utf-8-sig", newline=""
            ) as handle:
                groups = {
                    row["dependency_group"]
                    for row in csv.DictReader(handle, delimiter="\t")
                    if row["dependency_group"]
                }
            metadata = json.loads(
                (first / "confidence_metadata.json").read_text(encoding="utf-8")
            )
            self.assertEqual(
                metadata["edge_dependence"]["realized_group_count"],
                len(groups),
            )
            self.assertEqual(
                metadata["edge_dependence"]["assumption"],
                (
                    "grouped_shared_latent"
                    if groups
                    else "independent_no_realized_groups"
                ),
            )

    def test_calibration_distortion_preserves_latent_truth(self) -> None:
        config = BenchmarkGeneratorConfig(
            mechanism="calibration_distortion",
            seed=43,
            distortion="overconfidence",
            temperature=0.5,
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            generated = generate_benchmark(TOY, Path(temp_dir) / "distorted", config)
            report = validate_dataset(generated)
            self.assertEqual(
                report.confidence_types, ("normalized_heuristic_weight",)
            )
            self.assertTrue((generated / "latent_truth.tsv").is_file())


if __name__ == "__main__":
    unittest.main()
