"""Tests for the winner-only union bound and the informative-subsequence clock."""

from __future__ import annotations

import math

import numpy as np
import pytest

from pkgea.certified import (
    CertifiedSchedulerConfig,
    PairwiseWinnerState,
    certify_winner_sequence,
    informative_subsequence_radius,
    normal_mixture_radius,
    pairwise_alpha,
    schedule_certified_winner_streams,
)


def test_pairwise_alpha_defaults_to_the_frozen_all_pairs_rule():
    # 8 candidates -> 28 unordered pairs; this is what the submitted runs used.
    assert pairwise_alpha(8, 0.05) == pytest.approx(0.05 / 28)
    assert pairwise_alpha(8, 0.05, directed=True) == pytest.approx(0.05 / 56)


def test_winner_pairs_rule_splits_over_candidates_only():
    assert pairwise_alpha(8, 0.05, union_bound="winner_pairs") == pytest.approx(0.05 / 7)
    # The directed flag is irrelevant once only winner pairs are protected.
    assert pairwise_alpha(
        8, 0.05, union_bound="winner_pairs", directed=True
    ) == pytest.approx(0.05 / 7)


def test_winner_pairs_is_never_more_conservative():
    for candidates in (2, 4, 16, 1024):
        assert pairwise_alpha(candidates, 0.05, union_bound="winner_pairs") >= (
            pairwise_alpha(candidates, 0.05)
        )


def test_single_candidate_alpha_is_well_defined():
    assert pairwise_alpha(1, 0.05) == pytest.approx(0.05)
    assert pairwise_alpha(1, 0.05, union_bound="winner_pairs") == pytest.approx(0.05)


def test_rejects_unknown_modes():
    with pytest.raises(ValueError):
        pairwise_alpha(4, 0.05, union_bound="nonsense")
    with pytest.raises(ValueError):
        PairwiseWinnerState(query_id="q", candidates=("a", "b"), clock="nonsense")
    with pytest.raises(ValueError):
        PairwiseWinnerState(query_id="q", candidates=("a", "b"), union_bound="nonsense")


def test_informative_radius_matches_the_mixture_at_its_own_clock():
    assert informative_subsequence_radius(100, 0.01) == pytest.approx(
        normal_mixture_radius(100, 0.01)
    )
    with pytest.raises(ValueError):
        informative_subsequence_radius(0, 0.01)


def test_informative_clock_reads_the_conditional_gap():
    state = PairwiseWinnerState(
        query_id="q",
        candidates=("a", "b", "c"),
        clock="informative",
        union_bound="winner_pairs",
    )
    # Leader "a" wins 50 of 100; the a-vs-b pair is informative on 60 of them.
    state.update(["a"] * 50 + ["b"] * 10 + ["c"] * 40, evaluate_certificate=False)
    bound = next(b for b in state.leader_bounds() if b.competitor == "b")
    # Conditional gap is (50-10)/60, not the marginal (50-10)/100.
    assert bound.estimate == pytest.approx(40 / 60)
    assert bound.upper - bound.lower > 0.0


def test_all_worlds_clock_reads_the_marginal_gap():
    state = PairwiseWinnerState(query_id="q", candidates=("a", "b", "c"))
    state.update(["a"] * 50 + ["b"] * 10 + ["c"] * 40, evaluate_certificate=False)
    bound = next(b for b in state.leader_bounds() if b.competitor == "b")
    assert bound.estimate == pytest.approx(40 / 100)


def test_informative_clock_certifies_a_spread_winner_sooner():
    # Winner law spread over many candidates is exactly where sigma^2 = 1 is
    # worst, so the informative clock should stop strictly earlier.
    rng = np.random.default_rng(11)
    probabilities = np.full(16, 0.05)
    probabilities[0] = 1.0 - probabilities[1:].sum()
    stream = rng.choice(16, size=8192, p=probabilities)

    frozen = certify_winner_sequence(
        "q", tuple(range(16)), stream, delta=0.05, batch_size=64, minimum_samples=32
    )
    informative = certify_winner_sequence(
        "q",
        tuple(range(16)),
        stream,
        delta=0.05,
        batch_size=64,
        minimum_samples=32,
        union_bound="winner_pairs",
        clock="informative",
    )
    assert informative.stable
    assert informative.certified_winner == 0
    if frozen.stable:
        assert informative.samples_used <= frozen.samples_used
    assert informative.confidence_sequence.endswith("-v2")


def test_frozen_defaults_keep_their_artifact_label():
    rng = np.random.default_rng(3)
    stream = rng.choice(4, size=1024, p=[0.55, 0.15, 0.15, 0.15])
    result = certify_winner_sequence("q", tuple(range(4)), stream)
    assert result.confidence_sequence == "normal-mixture-hoeffding-pairwise-v1"
    assert result.pair_alpha == pytest.approx(0.05 / 6)


def test_scheduler_accepts_and_propagates_the_new_modes():
    rng = np.random.default_rng(5)
    streams = {
        f"q{index}": list(
            rng.choice(8, size=2048, p=[0.30] + [0.10] * 7).astype(int)
        )
        for index in range(4)
    }
    candidates = {query: tuple(range(8)) for query in streams}
    costs = {query: 1.0 + index for index, query in enumerate(streams)}
    result = schedule_certified_winner_streams(
        streams,
        candidates,
        costs,
        CertifiedSchedulerConfig(
            global_budget=1e6,
            strategy="gap_cost",
            pilot_samples_per_query=32,
            batch_size=64,
            maximum_samples_per_query=2048,
            union_bound="winner_pairs",
            clock="informative",
            record_allocation_trace=False,
        ),
    )
    assert result.stable_queries >= 1
    for query in result.queries:
        assert query.pair_alpha == pytest.approx(0.05 / 7)


def test_scheduler_rejects_unknown_modes():
    with pytest.raises(ValueError):
        CertifiedSchedulerConfig(global_budget=10.0, clock="nonsense").validate(1, 1.0)
    with pytest.raises(ValueError):
        CertifiedSchedulerConfig(global_budget=10.0, union_bound="nonsense").validate(
            1, 1.0
        )


def test_error_control_holds_on_an_adversarial_near_null():
    # Loser must almost never be certified.  delta = .05 with 400 replicates
    # leaves ample room; this is a regression guard, not a calibration study.
    rng = np.random.default_rng(23)
    wrong = 0
    for _ in range(400):
        stream = rng.choice(2, size=4096, p=[0.47, 0.53])
        result = certify_winner_sequence(
            "q",
            (0, 1),
            stream,
            delta=0.05,
            batch_size=64,
            minimum_samples=32,
            union_bound="winner_pairs",
            clock="informative",
        )
        if result.stable and result.certified_winner != 1:
            wrong += 1
    assert wrong / 400 <= 0.05


def test_informative_clock_abstains_without_informative_worlds():
    state = PairwiseWinnerState(
        query_id="q", candidates=("a", "b", "c"), clock="informative"
    )
    state.update(["a"] * 8, evaluate_certificate=True)
    # "b" and "c" never won, so their pair against the leader is informative and
    # certification is possible; the degenerate case is a pair with no data at
    # all, which must stay uncertified rather than divide by zero.
    empty = state._bound("b", "c")
    assert math.isclose(empty.lower, -1.0)
    assert math.isclose(empty.upper, 1.0)
