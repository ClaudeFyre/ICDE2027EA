"""Data reconstruction and conservative numerical checks for the V1 driver."""

import itertools
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
for directory in (ROOT / "scripts", ROOT / "src"):
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))

from pkgea.backbones.attribute import AttributeStructuralBackbone
from run_vldb_interval_gate_v1 import (
    _validate_config, audit_candidate_preservation, build_selected_backbone,
    clipped_box, conservative_scope_tv, outward_score_range,
)
from vldb_capture_attribute_v0 import build_degree_kernel


class IntervalGateDriverTests(unittest.TestCase):
    def setUp(self):
        (ROOT / "tmp").mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="vldb-v1-driver-", dir=ROOT / "tmp")
        self.addCleanup(self.temp.cleanup)
        self.dataset = Path(self.temp.name) / "data"
        shutil.copytree(ROOT / "data/toy/exact_world_minimal", self.dataset)

    def test_selected_pair_reconstruction_preserves_complete_corpus_and_scores(self):
        original = AttributeStructuralBackbone.from_dataset(self.dataset)
        source = original.source_entities[0]
        rebuilt, cost = build_selected_backbone(self.dataset, (source,))
        self.assertEqual(rebuilt.source_entities, original.source_entities)
        self.assertEqual(rebuilt.target_entities, original.target_entities)
        self.assertEqual(cost["computed_pair_count"], len(original.target_entities))
        self.assertFalse(cost["full_pair_matrix_constructed"])
        for target in original.target_entities:
            self.assertEqual(rebuilt.attribute_scores[source, target], original.attribute_scores[source, target])
            self.assertEqual(rebuilt.structural.lexical_scores[source, target], original.structural.lexical_scores[source, target])
        candidates = tuple(sorted(original.target_entities))
        indices = tuple(range(len(original.triples)))
        first = build_degree_kernel(original, source, candidates, indices)
        second = build_degree_kernel(rebuilt, source, candidates, indices)
        worlds = np.asarray(list(itertools.product((False, True), repeat=len(indices))), dtype=np.bool_)
        np.testing.assert_array_equal(first.scores(worlds), second.scores(worlds))

    def test_outward_ranges_cover_all_toy_world_scores(self):
        backbone = AttributeStructuralBackbone.from_dataset(self.dataset)
        for state in itertools.product((False, True), repeat=len(backbone.triples)):
            scores = backbone.score(tuple(state))
            for (source, target), score in scores.items():
                low, high = outward_score_range(backbone.attribute_scores[source, target], backbone.structural.lexical_scores[source, target], backbone.attribute_weight)
                self.assertLessEqual(low, score)
                self.assertGreaterEqual(high, score)

    def test_pruning_audit_fails_when_a_potential_winner_is_removed(self):
        backbone = AttributeStructuralBackbone.from_dataset(self.dataset)
        source = backbone.source_entities[0]
        targets = backbone.target_entities
        for target in targets:
            backbone.attribute_scores[source, target] = 0.5
            backbone.structural.lexical_scores[source, target] = 0.5
        result = audit_candidate_preservation(backbone, source, (targets[0],))
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(len(result["failed_removed_candidates"]), len(targets) - 1)
        self.assertEqual(audit_candidate_preservation(backbone, source, targets)["status"], "PASS")

    def test_clipped_box_is_outward_and_deterministic_product_is_conservative(self):
        q = np.asarray([0.0, 0.2, 0.9, 1.0], dtype=np.float64)
        low, high = clipped_box(q, 0.01)
        self.assertEqual(low[0], 0)
        self.assertEqual(high[-1], 1)
        self.assertLess(low[1], q[1] - 0.01)
        self.assertGreater(high[1], q[1] + 0.01)
        bound, audit = conservative_scope_tv(q, low, high)
        self.assertGreaterEqual(bound, 1 - (1 - 0.01) ** len(q))
        self.assertLessEqual(bound, 1)
        self.assertTrue(audit["is_conservative_upper_bound"])
        self.assertFalse(audit["bitwise_exact_tv_claim"])
        zero_low, zero_high = clipped_box(q, 0)
        self.assertEqual(conservative_scope_tv(q, zero_low, zero_high)[0], 0)

    def test_scope_product_increases_when_more_nontrivial_coordinates_are_used(self):
        q = np.asarray([0.3, 0.7], dtype=np.float64)
        low, high = clipped_box(q, 0.1)
        full = conservative_scope_tv(q, low, high)[0]
        local = conservative_scope_tv(q[:1], low[:1], high[:1])[0]
        self.assertGreater(full, local)

    def test_delta_split_cannot_silently_exceed_total_risk(self):
        config = {"tau_grid": [0.001, 0.01], "primary_tau": 0.001,
                  "sample_count": 4096, "chunk_size": 256, "delta_nominal": 0.025,
                  "beta_per_tau": 0.0125, "delta_total": 0.05, "beta_total": 0.025}
        _validate_config(config)
        with self.assertRaisesRegex(ValueError, "risk budgets"):
            _validate_config({**config, "delta_nominal": 0.05})


if __name__ == "__main__":
    unittest.main()
