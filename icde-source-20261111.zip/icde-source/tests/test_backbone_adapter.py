from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.backbones import CheckpointDescriptor, SubprocessBackboneAdapter


class BackboneAdapterTests(unittest.TestCase):
    def test_descriptor_and_subprocess_matrix_are_validated(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            checkpoint = root / "checkpoint.bin"
            checkpoint.write_bytes(b"immutable checkpoint")
            scorer = root / "scorer.py"
            scorer.write_text(
                "import json, sys\n"
                "r=json.loads(sys.stdin.readline())\n"
                "def scores(k=0): return "
                "[{'source':s,'target':t,'score':float(i+j+k)} "
                "for i,s in enumerate(r['sources']) "
                "for j,t in enumerate(r['targets'])]\n"
                "if r['protocol_version']=='pkgea-backbone-v2':\n"
                " print(json.dumps({'protocol_version':'pkgea-backbone-v2',"
                "'score_batches':[{'world_index':k,'scores':scores(k)} "
                "for k,_ in enumerate(r['states'])]}))\n"
                "else:\n"
                " print(json.dumps({'protocol_version':'pkgea-backbone-v1',"
                "'scores':scores()}))\n",
                encoding="utf-8",
            )
            descriptor_path = root / "descriptor.json"
            descriptor_path.write_text(
                json.dumps(
                    {
                        "adapter_id": "test/v1",
                        "method_family": "test",
                        "framework": "stdlib",
                        "source_commit": "abcdef1",
                        "checkpoint_path": "checkpoint.bin",
                        "checkpoint_sha256": hashlib.sha256(
                            checkpoint.read_bytes()
                        ).hexdigest(),
                        "dataset_id": "toy",
                        "train_split_checksum": "a" * 64,
                        "seed": 17,
                        "device": "cpu",
                        "probability_handling": "sampled_world",
                        "score_semantics": "higher",
                        "code_license": "MIT",
                        "artifact_license": "CC0-1.0",
                        "command": [sys.executable, str(scorer)],
                    }
                ),
                encoding="utf-8",
            )
            descriptor = CheckpointDescriptor.load(descriptor_path)
            adapter = SubprocessBackboneAdapter(
                descriptor,
                source_entities=("s1", "s2"),
                target_entities=("t1", "t2"),
                edge_count=2,
            )
            scores = adapter.score((True, False))
            self.assertEqual(len(scores), 4)
            self.assertEqual(scores[("s2", "t2")], 2.0)
            batches = adapter.score_batch(
                [(True, False), (False, True)]
            )
            self.assertEqual(len(batches), 2)
            self.assertEqual(batches[1][("s2", "t2")], 3.0)

    def test_unresolved_license_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            checkpoint = root / "checkpoint.bin"
            checkpoint.write_bytes(b"x")
            descriptor = {
                "adapter_id": "bad/v1",
                "method_family": "test",
                "framework": "none",
                "source_commit": "abcdef1",
                "checkpoint_path": "checkpoint.bin",
                "checkpoint_sha256": hashlib.sha256(b"x").hexdigest(),
                "dataset_id": "toy",
                "train_split_checksum": "a" * 64,
                "seed": 17,
                "device": "cpu",
                "probability_handling": "ignored",
                "score_semantics": "higher",
                "code_license": "unresolved",
                "artifact_license": "CC0-1.0",
                "command": [sys.executable, "-c", "pass"],
            }
            path = root / "descriptor.json"
            path.write_text(json.dumps(descriptor), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "license"):
                CheckpointDescriptor.load(path)


if __name__ == "__main__":
    unittest.main()
