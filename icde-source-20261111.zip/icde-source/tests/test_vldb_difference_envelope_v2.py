"""Exhaustive small-cube tests for a precompiled strong interval baseline."""

from dataclasses import dataclass, replace
from itertools import product
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import vldb_interval_envelope_v1 as v1
import vldb_difference_envelope_v2 as v2


@dataclass
class OriginalKernel:
    source: str
    candidates: tuple
    edge_indices: tuple
    incidence_positions: tuple
    attribute: np.ndarray
    lexical: np.ndarray
    attribute_weight: float

    def scores(self, states):
        degrees = np.empty((len(states), len(self.incidence_positions)), dtype=np.float64)
        for column, positions in enumerate(self.incidence_positions):
            degrees[:, column] = np.sum(states[:, positions], axis=1, dtype=np.float64)
        distance = (np.abs(degrees[:, 0, None] - degrees[:, 2::2])
                    + np.abs(degrees[:, 1, None] - degrees[:, 3::2]))
        dynamic = 1.0 / (1.0 + distance)
        structural = 0.6 * self.lexical[None, :] + 0.4 * dynamic
        return self.attribute_weight * self.attribute[None, :] + (1.0 - self.attribute_weight) * structural


def make_kernel(incidence=((0, 1), (2,), (0,), (2,), (1,), (0,)), m=3,
                attribute=(.1, .2), lexical=(.3, .25), weight=.6):
    return OriginalKernel("s", ("a", "b"), tuple(range(m)),
                          tuple(np.array(p, dtype=np.intp) for p in incidence),
                          np.array(attribute, dtype=np.float64), np.array(lexical, dtype=np.float64), float(weight))


class DifferenceEnvelopeTests(unittest.TestCase):
    def test_every_cube_is_sound_and_no_looser_than_v1(self):
        original = make_kernel()
        compiled = v2.compile_difference_kernel(original)
        for statuses in product((0, 1, 2), repeat=3):
            low = np.array([[x == 1 for x in statuses]], dtype=np.bool_)
            high = np.array([[x != 0 for x in statuses]], dtype=np.bool_)
            lower, upper = compiled.score_intervals(low, high)
            old_lower, old_upper = v1.score_intervals(original, low, high)
            self.assertTrue(np.all(lower >= old_lower), statuses)
            self.assertTrue(np.all(upper <= old_upper), statuses)
            for bits in product((False, True), repeat=3):
                states = np.array([bits], dtype=np.bool_)
                if np.all(low <= states) and np.all(states <= high):
                    scores = original.scores(states)
                    self.assertTrue(np.array_equal(compiled.scores(states), scores))
                    self.assertTrue(np.all(lower <= scores), (statuses, bits))
                    self.assertTrue(np.all(scores <= upper), (statuses, bits))

    def test_shared_source_candidate_incidents_cancel_exactly(self):
        compiled = v2.compile_difference_kernel(make_kernel())
        low, high = np.zeros((1, 3), dtype=np.bool_), np.ones((1, 3), dtype=np.bool_)
        dlow, dhigh = compiled.difference_intervals(low, high)
        self.assertEqual(dlow[0, 0, 0], 0)  # (x0+x1)-x0=x1.
        self.assertEqual(dhigh[0, 0, 0], 1)
        self.assertEqual(dlow[0, 1, 0], 0)  # x2-x2=0.
        self.assertEqual(dhigh[0, 1, 0], 0)
        self.assertGreater(compiled.compilation_summary["shared_coordinate_cancellations"], 0)

    def test_source_equals_candidate_with_selfloop_has_zero_difference(self):
        original = make_kernel(((0, 1), (0, 2), (0, 1), (0, 2), (1,), (2,)),
                               attribute=(0., 0.), lexical=(.5, 0.), weight=0.)
        original = replace(original, source="a")
        compiled = v2.compile_difference_kernel(original)
        low, high = np.zeros((1, 3), dtype=np.bool_), np.ones((1, 3), dtype=np.bool_)
        dlow, dhigh = compiled.difference_intervals(low, high)
        self.assertTrue(np.array_equal(dlow[0, :, 0], [0, 0]))
        self.assertTrue(np.array_equal(dhigh[0, :, 0], [0, 0]))
        q, uniforms = np.full(3, .5, dtype=np.float64), np.full((1, 3), .5, dtype=np.float64)
        flags = compiled.ambiguity_indicators(q, np.zeros(3, dtype=np.float64), np.ones(3, dtype=np.float64), uniforms)
        old_flags = v1.ambiguity_indicators(original, q, np.zeros(3, dtype=np.float64), np.ones(3, dtype=np.float64), uniforms)
        self.assertFalse(flags[0])
        self.assertTrue(old_flags[0])

    def test_disjoint_support_gives_v1_identical_ranges(self):
        original = make_kernel(((0,), (1,), (2,), (3,), (2, 3), ()), m=4)
        compiled = v2.compile_difference_kernel(original)
        self.assertEqual(compiled.shared_coordinate_cancellations, 0)
        summary = compiled.compilation_summary
        self.assertEqual(summary["interval_incidence_entries"], summary["original_incidence_entries"])
        self.assertEqual(summary["interval_evaluation"], "shared_source_degree_fastpath")
        for statuses in product((0, 1, 2), repeat=4):
            low = np.array([[x == 1 for x in statuses]], dtype=np.bool_)
            high = np.array([[x != 0 for x in statuses]], dtype=np.bool_)
            new = compiled.score_intervals(low, high)
            old = v1.score_intervals(original, low, high)
            self.assertTrue(np.array_equal(new[0], old[0]))
            self.assertTrue(np.array_equal(new[1], old[1]))

    def test_flags_are_no_larger_and_dominate_all_counterfactual_flips(self):
        original = make_kernel(weight=0.)
        compiled = v2.compile_difference_kernel(original)
        q = np.full(3, .5, dtype=np.float64)
        uniforms = np.array(list(product((.25, .5, .75), repeat=3)), dtype=np.float64)
        low, high = np.full(3, .2, dtype=np.float64), np.full(3, .8, dtype=np.float64)
        nominal = original.scores(uniforms < q)
        flags = compiled.ambiguity_indicators(q, low, high, uniforms)
        reused = compiled.ambiguity_indicators(q, low, high, uniforms, nominal_scores=nominal)
        old_flags = v1.ambiguity_indicators(original, q, low, high, uniforms)
        self.assertTrue(np.array_equal(flags, reused))
        self.assertTrue(np.all(~flags | old_flags))
        nominal_winners = np.argmax(nominal, axis=1)
        for parameters in product((.2, .5, .8), repeat=3):
            winners = np.argmax(original.scores(uniforms < np.array(parameters, dtype=np.float64)), axis=1)
            self.assertTrue(np.all((winners == nominal_winners) | flags))

    def test_frozen_snapshot_preserves_scores_after_original_mutates(self):
        original = make_kernel()
        states = np.array([[True, False, True]], dtype=np.bool_)
        expected = original.scores(states).copy()
        compiled = v2.compile_difference_kernel(original)
        original.attribute[:] = .99
        original.lexical[:] = .01
        original.incidence_positions[0][:] = 2
        self.assertTrue(np.array_equal(compiled.scores(states), expected))
        with self.assertRaises(ValueError):
            compiled.attribute[0] = .5
        with self.assertRaises(ValueError):
            compiled.positive_positions[0][0] = 2

    def test_zero_width_ties_all_fixed_and_single_candidate(self):
        original = make_kernel(attribute=(.2, .2), lexical=(.3, .3), weight=1.)
        compiled = v2.compile_difference_kernel(original)
        q = np.full(3, .5, dtype=np.float64)
        uniforms = np.array([[.1, .9, .1], [.5, .5, .5]], dtype=np.float64)
        self.assertFalse(np.any(compiled.ambiguity_indicators(q, q, q, uniforms)))
        self.assertFalse(compiled.ambiguity_indicators(q, q - .1, q + .1, uniforms)[0])
        single = replace(original, candidates=("a",), incidence_positions=original.incidence_positions[:4],
                         attribute=original.attribute[:1], lexical=original.lexical[:1])
        self.assertFalse(np.any(v2.compile_difference_kernel(single).ambiguity_indicators(
            q, np.zeros(3, dtype=np.float64), np.ones(3, dtype=np.float64), uniforms)))

    def test_no_edges_and_reusable_degree_intervals(self):
        original = make_kernel(((), (), (), (), (), ()), m=0)
        compiled = v2.compile_difference_kernel(original)
        low = high = np.zeros((2, 0), dtype=np.bool_)
        degrees = compiled.degree_intervals(low, high)
        self.assertEqual(degrees[0].shape, (2, 6))
        self.assertFalse(np.any(degrees[0]))
        self.assertFalse(np.any(compiled.ambiguity_indicators(
            np.zeros(0, dtype=np.float64), np.zeros(0, dtype=np.float64),
            np.zeros(0, dtype=np.float64), np.zeros((2, 0), dtype=np.float64))))

    def test_dtypes_bad_incidence_and_optional_score_shape_fail_closed(self):
        original = make_kernel()
        with self.assertRaises(ValueError):
            v2.compile_difference_kernel(replace(original, attribute=original.attribute.astype(np.float32)))
        with self.assertRaises(ValueError):
            v2.compile_difference_kernel(replace(original, incidence_positions=(np.array([0, 0]),) + original.incidence_positions[1:]))
        compiled = v2.compile_difference_kernel(original)
        states = np.zeros((1, 3), dtype=np.bool_)
        with self.assertRaises(ValueError):
            compiled.score_intervals(states.astype(np.int8), states)
        q, uniforms = np.full(3, .5, dtype=np.float64), np.full((1, 3), .5, dtype=np.float64)
        with self.assertRaises(ValueError):
            compiled.ambiguity_indicators(q.astype(np.float32), q, q, uniforms)
        with self.assertRaises(ValueError):
            compiled.ambiguity_indicators(q, q - .1, q + .1, uniforms,
                                          nominal_scores=np.zeros((1, 1), dtype=np.float64))


if __name__ == "__main__":
    unittest.main()
