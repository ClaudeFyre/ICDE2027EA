"""Exact small-binomial coverage checks for the guarded V2 event bound."""

from __future__ import annotations

from decimal import Decimal
from fractions import Fraction
from math import comb
from pathlib import Path
import sys
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

import vldb_event_bound_v2 as event_bound


def exact_binomial_cdf(k: int, n: int, p: Fraction) -> Fraction:
    return sum((Fraction(comb(n, j)) * p ** j * (1 - p) ** (n - j)
                for j in range(k + 1)), Fraction(0))


class EventBoundTests(unittest.TestCase):
    def test_outward_cdf_contains_exact_small_binomial_tail(self) -> None:
        for n in range(1, 9):
            for k in range(n + 1):
                for p in (0.0, 0.125, 0.5, 0.875, 1.0):
                    with self.subTest(n=n, k=k, p=p):
                        upper = event_bound.binomial_cdf_upper(k, n, p)
                        exact = exact_binomial_cdf(k, n, Fraction.from_float(p))
                        self.assertGreaterEqual(Fraction(upper), exact)
                        self.assertLessEqual(upper, Decimal(1))

    def test_small_n_coverage_enumerates_all_binomial_outcomes(self) -> None:
        # All k outcomes are summed exactly at a fixed grid of true p values;
        # the proof covering continuous p is CP tail monotonicity, not this grid.
        for n in range(1, 9):
            for alpha in (Fraction(1, 20), Fraction(1, 5)):
                bounds = [event_bound.fixed_n_binomial_upper(k, n, alpha)
                          for k in range(n + 1)]
                for p in (Fraction(j, 20) for j in range(21)):
                    with self.subTest(n=n, alpha=alpha, p=p):
                        failure = sum((Fraction(comb(n, k)) * p ** k * (1 - p) ** (n - k)
                                       for k in range(n + 1)
                                       if Fraction.from_float(bounds[k]) < p), Fraction(0))
                        self.assertLessEqual(failure, alpha)

    def test_zero_success_closed_form_and_verified_tail(self) -> None:
        for n, alpha, exact_upper in (
            (1, Fraction(1, 8), Fraction(7, 8)),
            (4, Fraction(1, 16), Fraction(1, 2)),
            (6, Fraction(1, 64), Fraction(1, 2)),
        ):
            with self.subTest(n=n, alpha=alpha):
                detail = event_bound.fixed_n_binomial_details(0, n, alpha)
                bound = detail["upper"]
                self.assertGreaterEqual(Fraction.from_float(bound), exact_upper)
                self.assertLess(bound - float(exact_upper), 1e-14)
                self.assertTrue(detail["tail_verified"])
                self.assertFalse(detail["fallback"])
                self.assertLessEqual(
                    Fraction(event_bound.binomial_cdf_upper(0, n, bound)), alpha
                )

    def test_count_n_is_one_and_regular_cp_is_monotone(self) -> None:
        for n in (1, 8, 32):
            bounds = [event_bound.fixed_n_binomial_upper(k, n, Fraction(1, 20))
                      for k in range(n + 1)]
            self.assertEqual(bounds[-1], 1.0)
            self.assertEqual(bounds, sorted(bounds))
        fixed_count = [event_bound.fixed_n_binomial_upper(0, n, Fraction(1, 480))
                       for n in (96, 224, 480, 992, 2016, 4096)]
        self.assertEqual(fixed_count, sorted(fixed_count, reverse=True))

    def test_bad_scipy_proposal_is_verified_or_falls_back_safely(self) -> None:
        event_bound._bound_details.cache_clear()
        try:
            with patch.object(event_bound, "_scipy_proposal", return_value=0.0):
                detail = event_bound.fixed_n_binomial_details(1, 31, Fraction(1, 37))
            self.assertTrue(detail["fallback"])
            self.assertEqual(detail["method"], "hoeffding_fallback_outward")
            self.assertLessEqual(
                Fraction(event_bound.binomial_cdf_upper(1, 31, detail["upper"])),
                Fraction(1, 37),
            )
        finally:
            event_bound._bound_details.cache_clear()

    def test_accepted_scipy_quantile_has_independently_bounded_tail(self) -> None:
        for n, k in ((12, 1), (96, 2), (224, 4)):
            with self.subTest(n=n, k=k):
                detail = event_bound.fixed_n_binomial_details(k, n, Fraction(1, 480))
                if detail["tail_verified"]:
                    self.assertLessEqual(
                        Fraction(event_bound.binomial_cdf_upper(k, n, detail["upper"])),
                        Fraction(1, 480),
                    )
                else:
                    self.assertTrue(detail["fallback"])
                    self.assertEqual(detail["method"], "hoeffding_fallback_outward")

    def test_risk_grid_uses_exact_split_and_downward_float_alpha(self) -> None:
        config = {
            "tau_grid": [0.001, 0.01],
            "event_checkpoints": [96, 224, 480, 992, 2016, 4096],
            "delta_nominal": "0.025", "beta_total": "0.025", "delta_total": "0.05",
            "max_samples_per_query": 4096,
        }
        plan = event_bound.validate_risk_plan(config)
        self.assertEqual(plan["protected_box_count"], 2)
        self.assertEqual(plan["protected_checkpoint_count"], 6)
        self.assertEqual(Fraction(plan["alpha_per_checkpoint_exact"]), Fraction(1, 480))
        self.assertLessEqual(Fraction.from_float(plan["alpha_per_checkpoint"]), Fraction(1, 480))
        self.assertLessEqual(Fraction(plan["allocated_total_risk_exact"]), Fraction(1, 20))
        self.assertEqual(event_bound.require_checkpoint(96, plan, computed_prefix_length=96),
                         plan["alpha_per_checkpoint"])
        with self.assertRaises(ValueError):
            event_bound.require_checkpoint(97, plan)
        with self.assertRaisesRegex(ValueError, "complete nominal prefix"):
            event_bound.require_checkpoint(96, plan, computed_prefix_length=95)
        with self.assertRaisesRegex(ValueError, "exceeds"):
            event_bound.validate_risk_plan({**config, "delta_nominal": "0.05"})
        with self.assertRaises(ValueError):
            event_bound.validate_risk_plan({**config, "event_checkpoints": [96, 96]})
        with self.assertRaises(ValueError):
            event_bound.validate_risk_plan({**config, "max_samples_per_query": 2016})

    def test_alpha_monotonicity_and_invalid_inputs(self) -> None:
        self.assertGreaterEqual(event_bound.fixed_n_binomial_upper(2, 96, 0.01),
                                event_bound.fixed_n_binomial_upper(2, 96, 0.1))
        for values in ((-1, 10, .1), (11, 10, .1), (0, 0, .1),
                       (True, 10, .1), (0, 10, 0), (0, 10, 1), (0, 10, float("nan"))):
            with self.subTest(values=values):
                with self.assertRaises(ValueError):
                    event_bound.fixed_n_binomial_upper(*values)


if __name__ == "__main__":
    unittest.main()
