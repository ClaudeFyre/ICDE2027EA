from __future__ import annotations

from pathlib import Path

import pytest

from scripts.prepare_wsdm_external_validation import build_plan
from scripts.run_real_attribute_certified import _scope_accounting_cost
from scripts.run_wsdm_external_validation import _public_profile_summary, _surrogate_summary
from scripts.summarize_wsdm_external_validation import (
    _find_forbidden_keys,
    build_summary,
)


def test_external_plan_is_wsdm_scoped_and_bounded() -> None:
    plan = build_plan("nl27k", 128)
    assert plan.layer == 2
    assert plan.anchors == 256
    assert plan.max_edges_per_graph == 2048
    assert len(plan.profiles) == 3
    assert all("nodes/04" not in path and "nodes/05" not in path for _, path in plan.profiles)


def test_external_plan_rejects_unapproved_scale() -> None:
    with pytest.raises(ValueError, match="q128 or q256"):
        build_plan("nl27k", 500)


def test_zero_scope_cost_floor_is_conservative() -> None:
    assert _scope_accounting_cost(set()) == 1.0
    assert _scope_accounting_cost({2, 7, 9}) == 3.0


def test_public_summary_strips_per_query_identifiers(monkeypatch: pytest.MonkeyPatch) -> None:
    profile = {
        "dataset_revision": "abc",
        "queries": 1,
        "full_edges": 2,
        "mean_scope_edges": 1.0,
        "mean_scope_edge_fraction": 0.5,
        "truth_candidate_recall": 1.0,
        "seed_runs": [
            {
                "seed": 11,
                "strategy": "high_budget_reference",
                "hits_at_1": 1.0,
                "per_query": [
                    {
                        "query_id": "restricted-id",
                        "reference_winner": "restricted-target",
                        "reference_gap": 0.2,
                    }
                ],
            },
            {
                "seed": 11,
                "strategy": "gap_cost",
                "post_pilot_budget_fraction": 0.2,
                "stable_coverage": 1.0,
                "wrong_and_stable_vs_reference_rate": 0.0,
                "reference_winner_agreement_all": 1.0,
                "hits_at_1_all": 1.0,
                "hits_at_1_stable": 1.0,
                "certified_correct_rate": 1.0,
                "worlds": 10,
                "sampled_edges": 20.0,
                "budget_utilization": 1.0,
                "scheduler_seconds": 0.1,
                "stream_generation_seconds": 0.2,
                "per_query": [{"query_id": "restricted-id"}],
            },
        ],
    }
    monkeypatch.setattr(
        "scripts.run_wsdm_external_validation._surrogate_summary",
        lambda path, value: {},
    )
    public = _public_profile_summary("t1", object(), profile)  # type: ignore[arg-type]
    rendered = repr(public)
    assert "restricted-id" not in rendered
    assert "restricted-target" not in rendered
    assert public["certification"][0]["wrong_and_stable_count"] == 0


def test_surrogate_summary_excludes_training_anchors(
    monkeypatch: pytest.MonkeyPatch, tmp_path
) -> None:
    (tmp_path / "triples.tsv").write_text(
        "confidence\n0.7\n", encoding="utf-8"
    )

    class FakeBackbone:
        source_entities = ("query", "train-anchor")

        def score_expected(self, weights):
            return {("query", "target"): 1.0}

    class Selection:
        candidates = ("target",)

    class FakeIndex:
        def select(self, source, k):
            assert source == "query"
            return Selection()

    monkeypatch.setattr(
        "scripts.run_wsdm_external_validation.validate_dataset", lambda path: None
    )
    monkeypatch.setattr(
        "scripts.run_wsdm_external_validation.AttributeStructuralBackbone.from_dataset",
        lambda path: FakeBackbone(),
    )
    monkeypatch.setattr(
        "scripts.run_wsdm_external_validation.StaticCandidateIndex.from_attribute_backbone",
        lambda backbone: FakeIndex(),
    )
    profile = {
        "seed_runs": [
            {
                "seed": 11,
                "strategy": "high_budget_reference",
                "per_query": [
                    {"query_id": "query", "reference_winner": "target"}
                ],
            }
        ]
    }
    result = _surrogate_summary(tmp_path, profile)
    assert result["expected_adjacency"]["winner_agreement_mean"] == 1.0


def test_external_combined_summary_validates_eight_frozen_aggregates() -> None:
    summary, validation = build_summary(
        Path("nodes/03_wsdm/results/external_validation")
    )
    assert validation["status"] == "pass"
    assert validation["validated_aggregate_count"] == 8
    assert summary["headline"]["wrong_and_stable_count_total_at_20pct"] == 0
    assert summary["headline"]["contains_per_query_identifiers"] is False


def test_external_summary_identifier_scan_rejects_nested_ids() -> None:
    assert _find_forbidden_keys({"rows": [{"query_id": "restricted"}]}) == [
        "$.rows[0].query_id"
    ]
