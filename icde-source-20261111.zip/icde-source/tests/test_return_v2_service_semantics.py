"""Regression probes for observed return-v2 identity and service failures."""
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'scripts')]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT / path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def test_factor_stream_config_is_immutable():
    from pkgea.samplers import FactorLaw
    law = FactorLaw(('g', 'g'), 0.6)
    config = law.stream_config()
    assert isinstance(config[1], tuple)
    assert hash(config)


def test_old_revision_scorer_survives_graph_and_factor_updates():
    e5 = load('return_v2_e5', 'scripts/icde_e5_rebuild_v2.py')
    traces = ROOT / 'nodes/05_icde_query_engine/results/icde_traces_v2_20261009'
    trace = next(p for p in sorted(traces.iterdir()) if p.name.startswith('hub_factor_updates__blind') and p.name.endswith('b64'))
    runner = e5.TraceRunner.open_trace(trace)
    initial = runner.initial_context()
    event = next(e for e in runner.events if e['kind'] == 'query')
    q = e5.ModalQuery(event['source'], tuple(event['ordered_candidates']), initial.snapshot.digest, event['world_budget'], event['delta'])
    expected = e5._serve_batch([q], initial, shared=True, cache=None)['results']
    updates = []
    for event in runner.events:
        if event['kind'] == 'query':
            continue
        runner.apply_update(event)
        updates.append(event['kind'])
        actual = e5._serve_batch([q], initial, shared=True, cache=None)['results']
        assert actual == expected
    assert set(updates) == {'update_probability', 'add', 'delete', 'update_factor'}


def test_backlog_drains_exact_requested_revisions(tmp_path):
    e3 = load('return_v2_e3', 'nodes/05_icde_query_engine/experiments/E3_update_query_mix/runner_revision_v2.py')
    e3.OUT = tmp_path
    e3.main()
    result = json.loads((tmp_path / 'revision_v2_result.json').read_text())
    backlog = result['periodic_backlog']
    rows = [r for event in backlog['backlog_log'] for r in event.get('replayed', [])]
    assert len(rows) == backlog['skipped_unpublished'] == 2
    assert {r['backlogged_from'] for r in rows} == {'r1', 'r3'}
    assert all(r['backlogged_from'] == r['replayed_on'] and r['requested_snapshot'] == r['served_snapshot'] and r['matches_independent_recompute'] for r in rows)
