"""Tests for the shared-factor (common-shock) factor-law extension.

Covers the three acceptance properties from the P1 review:
  1. no factor law => v1 independent product law (identity "independent",
     joint law factorizes);
  2. a shared factor law => within-group edges are measurably correlated
     (the joint law really changes, not just a relabelled identity string);
  3. changing the factor law changes the snapshot digest (and the stream
     digest), so an old snapshot/stream is refused rather than reused.
"""

from __future__ import annotations

import pytest

from pkgea.query.modal import (
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    execute_modal_queries,
)
from pkgea.samplers import FactorLaw, monte_carlo_worlds

PROBS = (0.2, 0.8)  # two edges that can be put in one shared group.
N = 200_000
SEED = 17


def _empirical_joint(worlds):
    n11 = sum(w.state[0] and w.state[1] for w in worlds)
    n10 = sum(w.state[0] and not w.state[1] for w in worlds)
    n01 = sum(not w.state[0] and w.state[1] for w in worlds)
    return n11 / N, n10 / N, n01 / N


def test_independent_law_is_v1_byte_compatible():
    law = FactorLaw.independent(len(PROBS))
    assert law.is_independent
    assert law.identity() == "independent"
    assert law.stream_config() == ()
    # v1 direct call must equal the law's independent build.
    direct = monte_carlo_worlds(PROBS, N, SEED)
    via_law = law.build_worlds(PROBS, N, SEED)
    assert direct == via_law


def test_independent_joint_factorizes():
    law = FactorLaw.independent(len(PROBS))
    p11, _, _ = _empirical_joint(law.build_worlds(PROBS, N, SEED))
    assert abs(p11 - PROBS[0] * PROBS[1]) < 0.005


def test_shared_factor_law_creates_positive_within_group_correlation():
    law = FactorLaw(("hub", "hub"), common_shock_probability=1.0)
    assert not law.is_independent
    worlds = law.build_worlds(PROBS, N, SEED)
    p11, p10, p01 = _empirical_joint(worlds)
    # rho=1 => both edges read ONE uniform U: edge0 active iff U<0.2,
    # edge1 iff U<0.8. P(both)=P(U<0.2)=0.2, not the product 0.16.
    assert abs(p11 - 0.2) < 0.01
    # Cross cells under a shared uniform must be nearly deterministic ordering.
    assert p10 < 1e-3            # U in [0.2,0.8): edge0 off, edge1 on
    assert abs(p01 - (0.8 - 0.2)) < 0.01
    # The correlation must clearly exceed the independent product 0.16.
    assert p11 > PROBS[0] * PROBS[1] + 0.02


def test_partial_shock_matches_analytic_joint():
    rho = 0.5
    law = FactorLaw(("hub", "hub"), common_shock_probability=rho)
    p11, _, _ = _empirical_joint(law.build_worlds(PROBS, N, SEED))
    expected = rho * min(PROBS[0], PROBS[1]) + (1 - rho) * PROBS[0] * PROBS[1]
    assert abs(p11 - expected) < 0.01


def test_factor_law_change_changes_snapshot_digest_and_refuses_old_state():
    base = FactorLaw.independent(len(PROBS))
    grouped = FactorLaw(("hub", "hub"), common_shock_probability=0.5)
    assert grouped.identity() != "independent"

    snap0 = ModalSnapshot("g", "m", "p", base.identity(), "s", "c", "toy")
    snap1 = ModalSnapshot("g", "m", "p", grouped.identity(), "s", "c", "toy")
    assert snap0.digest != snap1.digest

    w0 = tuple(base.build_worlds(PROBS, 64, SEED))
    w1 = tuple(grouped.build_worlds(PROBS, 64, SEED))
    stream0 = IIDWorldStream(snap0.digest, SEED, w0, base.stream_config())
    stream1 = IIDWorldStream(snap1.digest, SEED, w1, grouped.stream_config())
    # Same seed, different law => different stream digest (old blocks unreadable).
    assert stream0.digest != stream1.digest

    def score(state, sources, targets):
        return {(s, t): float(state[0]) for s in sources for t in targets}

    queries = [ModalQuery("s", ("a",), snap0.digest, 64)]
    scorer0 = ModalScorer(snap0.digest, score)
    # Feeding the grouped stream with the independent snapshot must be rejected
    # ("stale world stream"), proving the law change is bound into identity.
    with pytest.raises(ValueError, match="stale world"):
        execute_modal_queries(queries, snap0, stream1, scorer0)


def test_trivial_group_label_with_zero_shock_is_independent():
    law = FactorLaw(("hub", "hub"), common_shock_probability=0.0)
    assert law.is_independent
    assert law.identity() == "independent"
    p11, _, _ = _empirical_joint(law.build_worlds(PROBS, N, SEED))
    assert abs(p11 - PROBS[0] * PROBS[1]) < 0.005
