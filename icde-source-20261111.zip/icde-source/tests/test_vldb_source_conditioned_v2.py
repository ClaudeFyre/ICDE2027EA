"""Small-cube safety and precision tests for shared-source conditioning.

These are exact finite fixtures of the frozen float64 score mapping.  They do
not establish novelty, real-data speed, or effectiveness of any query policy.
No external data, random generators, or temporary files are used.
"""

from dataclasses import replace
from itertools import product
from pathlib import Path
from types import SimpleNamespace
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from vldb_difference_envelope_v2 import compile_difference_kernel
from vldb_source_conditioned_v2 import source_conditioned_indicators


def fixture(incidence=((0,), (), (), (), (), ()), m=1,
            attribute=(0., 0.), lexical=(.1, 0.), weight=0.):
    original = SimpleNamespace(
        source="s", candidates=("a", "b"), edge_indices=tuple(range(m)),
        incidence_positions=tuple(np.array(indices, dtype=np.intp) for indices in incidence),
        attribute=np.array(attribute, dtype=np.float64),
        lexical=np.array(lexical, dtype=np.float64), attribute_weight=float(weight),
    )
    return compile_difference_kernel(original)


def cube_parameters(statuses):
    # U=.5 gives fixed-false, fixed-true, or free state coordinates, while
    # q is inside every parameter interval.  Endpoints realize every cube
    # completion because the free coordinates span U=.5.
    low = np.array([.0 if value == 0 else .8 if value == 1 else .2 for value in statuses], dtype=np.float64)
    high = np.array([.2 if value == 0 else 1. if value == 1 else .8 for value in statuses], dtype=np.float64)
    q = np.array([.1 if value == 0 else .9 if value == 1 else .5 for value in statuses], dtype=np.float64)
    return q, low, high, np.full((1, len(statuses)), .5, dtype=np.float64)


class SourceConditionedTests(unittest.TestCase):
    def assert_metadata(self, metadata, n):
        self.assertIsInstance(metadata, dict)
        self.assertEqual(metadata["free_flags"].shape, (n,))
        self.assertEqual(metadata["free_flags"].dtype, np.bool_)
        for field in ("conditioning_assignment_counts", "conditioning_degree_rows"):
            values = metadata[field]
            self.assertEqual(values.shape, (n,))
            self.assertIn(values.dtype.kind, "iu")
            self.assertTrue(np.all(values >= 0))

    def test_common_source_motion_resolves_overlapping_marginal_score_ranges(self):
        compiled = fixture()
        q = np.array([.5], dtype=np.float64)
        low, high = np.array([0.], dtype=np.float64), np.array([1.], dtype=np.float64)
        uniforms = np.array([[.25], [.5], [.75]], dtype=np.float64)
        base = compiled.ambiguity_indicators(q, low, high, uniforms)
        self.assertTrue(np.all(base))
        flags, metadata = source_conditioned_indicators(compiled, q, low, high, uniforms,
                                                        max_source_assignments=2)
        self.assertFalse(np.any(flags))
        self.assert_metadata(metadata, len(uniforms))
        self.assertTrue(np.all(metadata["free_flags"]))
        self.assertTrue(np.all(metadata["conditioning_assignment_counts"] == 2))
        for p in (0., .25, .5, .75, 1.):
            winner = np.argmax(compiled.scores(uniforms < np.array([p], dtype=np.float64)), axis=1)
            self.assertTrue(np.all(winner == 0))

    def test_cap_fallback_reproduces_base_flags(self):
        compiled = fixture()
        q, low, high, uniforms = cube_parameters((2,))
        base = compiled.ambiguity_indicators(q, low, high, uniforms)
        flags, metadata = source_conditioned_indicators(compiled, q, low, high, uniforms,
                                                        max_source_assignments=1)
        self.assertTrue(np.array_equal(flags, base))
        self.assert_metadata(metadata, 1)

    def test_every_partial_cube_and_completion_is_safe_with_shared_edges(self):
        kernels = (
            fixture(((0, 1), (2,), (0,), (2,), (1,), (0,)), m=3,
                    attribute=(.1, .2), lexical=(.3, .25), weight=.6),
            # Edge0 is a self-loop at source, also present in A's directed
            # incidence.  Conditioning target degrees independently remains
            # conservative even though source/target states are dependent.
            fixture(((0, 1), (0,), (0,), (0,), (1,), ()), m=2,
                    attribute=(0., 0.), lexical=(.2, .1), weight=0.),
        )
        for compiled in kernels:
            m = len(compiled.edge_indices)
            for statuses in product((0, 1, 2), repeat=m):
                q, low, high, uniforms = cube_parameters(statuses)
                nominal = compiled.scores(uniforms < q)
                nominal_winner = np.argmax(nominal, axis=1)
                base = compiled.ambiguity_indicators(q, low, high, uniforms)
                for cap in (1, 2, 4):
                    flags, metadata = source_conditioned_indicators(
                        compiled, q, low, high, uniforms, nominal_scores=nominal,
                        difference_flags=base, max_source_assignments=cap,
                    )
                    self.assert_metadata(metadata, 1)
                    self.assertEqual(flags.dtype, np.bool_)
                    self.assertTrue(np.all(~flags | base), (statuses, cap))
                    for endpoints in product((0, 1), repeat=m):
                        parameters = np.where(np.array(endpoints, dtype=np.bool_), high, low)
                        counterfactual = np.argmax(compiled.scores(uniforms < parameters), axis=1)
                        self.assertTrue(np.all((counterfactual == nominal_winner) | flags),
                                        (statuses, endpoints, cap, flags))

    def test_reused_nominal_scores_and_flags_match_fresh_evaluation(self):
        compiled = fixture()
        q = np.array([.5], dtype=np.float64)
        low, high = np.array([.2], dtype=np.float64), np.array([.8], dtype=np.float64)
        uniforms = np.array([[.1], [.5], [.9]], dtype=np.float64)
        nominal = compiled.scores(uniforms < q)
        base = compiled.ambiguity_indicators(q, low, high, uniforms, nominal_scores=nominal)
        fresh, _ = source_conditioned_indicators(compiled, q, low, high, uniforms)
        reused, metadata = source_conditioned_indicators(compiled, q, low, high, uniforms,
                                                         nominal_scores=nominal, difference_flags=base)
        self.assertTrue(np.array_equal(fresh, reused))
        self.assertTrue(np.array_equal(metadata["free_flags"], [False, True, False]))
        self.assertFalse(np.any(reused))

    def test_ties_in_free_worlds_are_not_cleared_by_strict_comparison(self):
        compiled = fixture(lexical=(0., 0.))
        q, low, high, uniforms = cube_parameters((2,))
        base = compiled.ambiguity_indicators(q, low, high, uniforms)
        self.assertTrue(base[0])
        flags, _ = source_conditioned_indicators(compiled, q, low, high, uniforms)
        self.assertTrue(flags[0])

    def test_zero_width_all_fixed_and_one_candidate_keep_safe_special_cases(self):
        compiled = fixture(lexical=(0., 0.))
        q = np.array([.5], dtype=np.float64)
        uniforms = np.array([[.1], [.5], [.9]], dtype=np.float64)
        zero, metadata = source_conditioned_indicators(compiled, q, q, q, uniforms)
        self.assertFalse(np.any(zero))
        self.assert_metadata(metadata, 3)
        low, high = np.array([.2], dtype=np.float64), np.array([.8], dtype=np.float64)
        fixed, _ = source_conditioned_indicators(compiled, q, low, high, uniforms[[0, 2]])
        self.assertFalse(np.any(fixed))
        single = replace(compiled, candidates=("a",), incidence_positions=compiled.incidence_positions[:4],
                         attribute=compiled.attribute[:1], lexical=compiled.lexical[:1],
                         positive_positions=compiled.positive_positions[:1] + compiled.positive_positions[2:3],
                         negative_positions=compiled.negative_positions[:1] + compiled.negative_positions[2:3])
        one, _ = source_conditioned_indicators(single, q, low, high, uniforms)
        self.assertFalse(np.any(one))

    def test_wrong_dtypes_or_provided_flag_shape_fail_closed(self):
        compiled = fixture()
        q, low, high, uniforms = cube_parameters((2,))
        with self.assertRaises(ValueError):
            source_conditioned_indicators(compiled, q.astype(np.float32), low, high, uniforms)
        with self.assertRaises(ValueError):
            source_conditioned_indicators(compiled, q, low, high, uniforms,
                                           difference_flags=np.zeros(2, dtype=np.bool_))


if __name__ == "__main__":
    unittest.main()
