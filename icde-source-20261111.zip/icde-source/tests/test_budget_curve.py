from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.experiments import run_budget_curve, run_multi_seed_budget_curve


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class BudgetCurveTests(unittest.TestCase):
    def test_curve_can_limit_evaluation_to_one_alignment_split(self) -> None:
        report = run_budget_curve(
            TOY,
            [32],
            seed=17,
            backbone_name="toy",
            evaluation_split="test",
        )
        self.assertEqual(report["evaluation_split"], "test")
        self.assertEqual(
            len(report["points"][0]["source_winners"]),
            2,
        )

    def test_curve_is_persisted(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "curve.json"
            result = run_budget_curve(
                TOY,
                [48, 64],
                seed=17,
                backbone_name="toy",
                output_path=output,
            )
            self.assertTrue(output.is_file())
            self.assertEqual(
                [point["budget"] for point in result["points"]],
                [48, 64],
            )

    def test_budgets_must_be_unique_and_increasing(self) -> None:
        with self.assertRaises(ValueError):
            run_budget_curve(TOY, [64, 48], seed=17)

    def test_multi_seed_curve_aggregates_stability(self) -> None:
        result = run_multi_seed_budget_curve(
            TOY,
            [48, 64],
            [11, 17, 23],
            backbone_name="toy",
        )
        self.assertEqual(len(result["runs"]), 3)
        self.assertEqual(len(result["aggregate"]), 2)
        self.assertEqual(result["aggregate"][0]["source_count"], 3)
        self.assertTrue(
            0.0 <= result["aggregate"][0]["winner_consensus_mean"] <= 1.0
        )

    def test_no_early_stopping_uses_full_allocation(self) -> None:
        result = run_budget_curve(
            TOY,
            [64],
            seed=17,
            backbone_name="toy",
            early_stopping=False,
        )
        point = result["points"][0]
        self.assertEqual(point["allocated_worlds"], point["used_worlds"])


if __name__ == "__main__":
    unittest.main()
