from __future__ import annotations

import csv
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.generators import (
    BenchmarkGeneratorConfig,
    build_benchmark_preset_manifest,
    generate_benchmark,
)


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class BenchmarkPresetTests(unittest.TestCase):
    def test_frozen_matrix_has_expected_dimensions(self) -> None:
        manifest = build_benchmark_preset_manifest()
        dimensions = manifest["dimensions"]
        self.assertEqual(manifest["profile_count"], 135)
        self.assertEqual(len(dimensions["entropy"]), 5)
        self.assertEqual(len(dimensions["missingness"]), 3)
        self.assertEqual(len(dimensions["correlation"]), 3)
        self.assertEqual(len(dimensions["seed_ratio"]), 3)
        self.assertEqual(
            len({profile["id"] for profile in manifest["profiles"]}), 135
        )

    def test_entropy_levels_are_strictly_increasing(self) -> None:
        entropy = build_benchmark_preset_manifest()["dimensions"]["entropy"]
        values = [item["expected_normalized_binary_entropy"] for item in entropy]
        self.assertEqual(values, sorted(values))
        self.assertEqual(len(values), len(set(values)))
        self.assertTrue(all(0.0 < value < 1.0 for value in values))

    def test_seed_ratio_repartitions_alignments_reproducibly(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            first = Path(temp_dir) / "first"
            second = Path(temp_dir) / "second"
            config = BenchmarkGeneratorConfig(
                mechanism="independent",
                seed=17,
                seed_ratio=0.5,
                validation_ratio=0.1,
            )
            generate_benchmark(TOY, first, config)
            generate_benchmark(TOY, second, config)
            self.assertEqual(
                (first / "alignments.tsv").read_bytes(),
                (second / "alignments.tsv").read_bytes(),
            )
            with (first / "alignments.tsv").open(
                "r", encoding="utf-8", newline=""
            ) as handle:
                counts = {"train": 0, "validation": 0, "test": 0}
                for row in csv.DictReader(handle, delimiter="\t"):
                    counts[row["split"]] += 1
            self.assertEqual(counts, {"train": 2, "validation": 0, "test": 1})
            metadata = (first / "confidence_metadata.json").read_text(
                encoding="utf-8"
            )
            self.assertIn("-split2-0-1", metadata)


if __name__ == "__main__":
    unittest.main()
