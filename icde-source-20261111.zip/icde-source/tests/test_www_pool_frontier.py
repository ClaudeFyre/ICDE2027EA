"""The candidate-pool sweep, proven on synthetic data before it ships.

The compute host has no assistance, so everything that can be exercised without
a checkpoint is exercised here: nesting, truth preservation, soundness at every
pool size, and the full-FP16 path that this run certifies for the first time.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT / "src", ROOT / "scripts", ROOT / "scripts/backbones"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from www_pool_frontier import run_pool_frontier, truth_positions_for  # noqa: E402
from run_www_fixed_index_audit import (  # noqa: E402
    projection_fit_rows, project_pool_moments,
)
from run_www_equal_budget import project_and_summarize  # noqa: E402
from summarize_www_pool_frontier import (  # noqa: E402
    check_baseline, check_baseline_selection,
)
import run_www_pool_matrix as pool_matrix  # noqa: E402


def synthetic(rng, sources=60, pool=400, dimension=8):
    total = sources + pool
    means = rng.normal(size=(total, dimension)) * 3.0
    covs = np.stack([
        (lambda f: f @ f.T + np.eye(dimension))(rng.normal(size=(dimension, dimension)))
        for _ in range(total)
    ])
    return means, covs


def run(tmp_path, limits, sources=60, pool=400):
    rng = np.random.default_rng(5)
    means, covs = synthetic(rng, sources, pool)
    targets = tuple(f"t{i}" for i in range(pool))
    srcs = tuple(f"s{i}" for i in range(sources))
    # Every source's truth lies in the first 40 targets, so even the smallest
    # pool can preserve it.
    truth = {s: targets[i % 40] for i, s in enumerate(srcs)}
    splits = {"selection": slice(0, 30), "authorization": slice(30, 45),
              "final_test": slice(45, 60)}

    def moments(seed, label):
        noise = np.random.default_rng(seed).normal(scale=0.01, size=means.shape)
        return means + noise, covs, {"total_seconds": 0.0}

    output = tmp_path / "cell.json"
    run_pool_frontier(
        output=output, cell="synthetic", means=means, covariances=covs,
        selection_timing={"total_seconds": 0.0}, moments=moments, splits=splits,
        sources=srcs, full_targets=targets, truth=truth, metadata={},
        max_error=0.0025, budget_fraction=0.8, candidate_limits=limits,
    )
    return json.loads(output.read_text(encoding="utf-8"))


def test_pools_are_nested_and_truth_preserving(tmp_path):
    result = run(tmp_path, [60, 120, 400])
    assert result["schema_version"] == "www-pool-frontier-v1"
    assert result["protocol"]["pools_are_nested"] is True
    for key in ("60", "120", "400"):
        assert result["pools"][key]["candidate_count"] == int(key)
    # Larger pool means at least as many bytes for the same rule.
    small = result["pools"]["60"]["stages"]["final_test"]["methods"]["full_fp16"]
    large = result["pools"]["400"]["stages"]["final_test"]["methods"]["full_fp16"]
    assert small["artifact_bytes"] < large["artifact_bytes"]


def test_certificate_stays_sound_at_every_pool_size(tmp_path):
    result = run(tmp_path, [60, 120, 400])
    checked = 0
    for pool in result["pools"].values():
        for stage in pool["stages"].values():
            for row in stage["methods"].values():
                assert row["certificate"]["certified_disagreeing_with_full_index"] == 0
                checked += 1
    assert checked > 0


def test_full_fp16_is_certified_too(tmp_path):
    """The point of adding it: the certificate is compression-agnostic."""

    result = run(tmp_path, [120])
    rows = result["pools"]["120"]["stages"]["final_test"]["methods"]
    assert "full_fp16" in rows
    certificate = rows["full_fp16"]["certificate"]
    assert 0.0 <= certificate["coverage"] <= 1.0
    assert certificate["certified_disagreeing_with_full_index"] == 0
    assert "full_fp16" in result["protocol"]["rules"]


def test_truth_positions_track_the_pool(tmp_path):
    targets = ("a", "b", "c")
    positions = truth_positions_for(targets, ("s0", "s1"), {"s0": "c", "s1": "a"})
    assert list(positions) == [2, 0]


def test_a_pool_too_small_for_truth_is_refused(tmp_path):
    with pytest.raises(RuntimeError, match="truth"):
        run(tmp_path, [20])


def test_a_pool_larger_than_the_graph_is_refused(tmp_path):
    with pytest.raises(RuntimeError, match="exceeds"):
        run(tmp_path, [10_000])


def test_pool_distractors_do_not_refit_the_frozen_projection():
    rng = np.random.default_rng(19)
    sources = rng.normal(size=(8, 6))
    aligned = rng.normal(size=(12, 6))
    distractors = rng.normal(loc=20, size=(15, 6))
    baseline = np.concatenate((sources, aligned))
    expanded = np.concatenate((sources, aligned, distractors))
    rows = projection_fit_rows(selection_queries=5, source_count=8,
                               fit_target_count=12)
    assert rows.max() < len(baseline)
    _, _, first = np.linalg.svd(baseline[rows] - baseline[rows].mean(axis=0),
                                full_matrices=False)
    _, _, second = np.linalg.svd(expanded[rows] - expanded[rows].mean(axis=0),
                                 full_matrices=False)
    np.testing.assert_allclose(abs(first), abs(second), atol=1e-12)


def test_pool_moments_replay_the_original_prefix_bit_for_bit():
    rng = np.random.default_rng(73)
    hidden = rng.normal(size=(33, 42, 12)).astype(np.float32)
    projection = rng.normal(size=(12, 6))
    baseline = np.ascontiguousarray(hidden[:, :20, :])
    old_means, old_covariances, _ = project_and_summarize(baseline, projection)
    means, covariances, _ = project_pool_moments(hidden, projection, 20)
    np.testing.assert_array_equal(means[:20], old_means)
    np.testing.assert_array_equal(covariances[:20], old_covariances)
    assert means.shape == (42, 6)
    assert covariances.shape == (42, 6, 6)


def test_baseline_replay_guard_rejects_a_changed_decision():
    frozen_path = (ROOT / "nodes/04_www_distributional/results/certificate_v1/"
                   "dw_gcn_independent.json")
    frozen = json.loads(frozen_path.read_text(encoding="utf-8"))
    row = frozen["stages"]["authorization"]["methods"]["0.8:uniform_w2"]
    observed = json.loads(json.dumps(row))
    check_baseline("dw_gcn_independent", "authorization", "uniform_w2",
                   observed, row)
    observed["certificate"]["certified"] -= 1
    with pytest.raises(RuntimeError, match="1,012 baseline mismatch"):
        check_baseline("dw_gcn_independent", "authorization", "uniform_w2",
                       observed, row)


def test_baseline_replay_guard_checks_the_index_itself():
    frozen_path = (ROOT / "nodes/04_www_distributional/results/certificate_v1/"
                   "dw_gcn_independent.json")
    frozen = json.loads(frozen_path.read_text(encoding="utf-8"))
    row = frozen["stages"]["authorization"]["methods"]["0.8:frob"]
    observed = json.loads(json.dumps(row))
    observed["artifact_sha256"] = "0" * 64
    with pytest.raises(RuntimeError, match="artifact_sha256"):
        check_baseline("dw_gcn_independent", "authorization", "frob",
                       observed, row)
    pool = {"selection": {
        name: frozen["selection"][f"0.8:{name}"]
        for name in ("frob", "uniform_w2", "margin_w2")
    }}
    check_baseline_selection("dw_gcn_independent", pool, frozen)
    pool = json.loads(json.dumps(pool))
    pool["selection"]["frob"]["representations"][0] = "diagonal"
    with pytest.raises(RuntimeError, match="representation map"):
        check_baseline_selection("dw_gcn_independent", pool, frozen)


def test_smoke_stays_at_two_small_pools(tmp_path, monkeypatch):
    checkpoint = tmp_path / "checkpoint.pt"
    checkpoint.write_bytes(b"synthetic checkpoint")
    profile = tmp_path / "profile"
    profile.mkdir()
    (profile / "entities.tsv").write_text(
        "entity_id\tgraph_id\n" + "".join(
            f"t{i}\ttarget\n" for i in range(4069)
        ), encoding="utf-8",
    )
    monkeypatch.setattr(pool_matrix, "ROOT", tmp_path)
    monkeypatch.setattr(pool_matrix, "RESULTS", tmp_path / "results")
    monkeypatch.setattr(pool_matrix, "checkpoint", lambda *_: checkpoint)
    monkeypatch.setattr(pool_matrix, "profile", lambda *_: profile)
    monkeypatch.setattr(pool_matrix, "dataset_content_digest", lambda *_: "digest")
    monkeypatch.setattr(pool_matrix, "sha256", lambda *_: "hash")
    task = pool_matrix.plan([pool_matrix.SMOKE_CELL], (512, 1012), smoke=True)[0]
    assert task["target_pool_size"] == 4069
    assert task["candidate_limits"] == [512, 1012]
    candidate_limit = task["command"][task["command"].index("--candidate-limit") + 1]
    assert candidate_limit == "1012"
