from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.experiments import run_experiment_matrix


TOY = ROOT / "data" / "toy" / "exact_world_minimal"


class ExperimentMatrixTests(unittest.TestCase):
    def test_matrix_expands_seeds_and_resumes_exact_tasks(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            manifest = root / "matrix.json"
            manifest.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "output_dir": "results",
                        "jobs": [
                            {
                                "id": "toy",
                                "runner": "formal_crn",
                                "dataset_dir": str(TOY),
                                "seeds": [11, 17],
                                "sample_count": 4,
                                "split": "test",
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            first = run_experiment_matrix(manifest)
            second = run_experiment_matrix(manifest)
            self.assertEqual(first["counts"]["completed"], 2)
            self.assertEqual(second["counts"]["skipped_existing"], 2)
            self.assertEqual(second["counts"]["failed"], 0)
            self.assertEqual(
                second["job_aggregates"]["toy"]["world_observation_count"],
                8,
            )

    def test_matrix_rejects_duplicate_or_unsafe_job_ids(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            manifest = Path(temporary) / "matrix.json"
            manifest.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "jobs": [
                            {
                                "id": "../unsafe",
                                "runner": "formal_crn",
                                "dataset_dir": str(TOY),
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaises(ValueError):
                run_experiment_matrix(manifest)
