"""Tests for the WWW E1 serving contract and deterministic stress families.

Covers the frozen protocol in
``nodes/04_www_distributional/results/reviewer_followup_v1/protocol.md``:
outward float32 bounds, read-back verification, the record-oriented backing
store, certify/refine/safe-path branches, and the seven seeded Gaussian
stress families compared against a 60-digit mpmath reference.  Synthetic
only: no repository results are read or written.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
for search_path in (ROOT / "src", ROOT / "scripts"):
    if str(search_path) not in sys.path:
        sys.path.insert(0, str(search_path))

import www_certify_serving as srv  # noqa: E402
import www_highprecision_reference as hp  # noqa: E402
from run_www_equal_budget import full_payload, representation_payload  # noqa: E402

DIMENSION = 3
TARGETS = 8


@pytest.fixture()
def host(tmp_path, monkeypatch):
    monkeypatch.setattr(srv, "ROOT", tmp_path)
    monkeypatch.setattr(srv, "PAYLOAD_DIR", tmp_path / "payloads")
    monkeypatch.setattr(srv, "BOUNDS_DIR", tmp_path / "bounds")
    monkeypatch.setattr(srv, "BACKING_DIR", tmp_path / "backing")
    rng = np.random.default_rng(11)
    means = rng.normal(size=(TARGETS, DIMENSION))
    lower = rng.normal(size=(TARGETS, DIMENSION, 2))
    covariances = lower @ np.swapaxes(lower, 1, 2) + np.eye(DIMENSION) * 0.25
    return {"tmp": tmp_path, "rng": rng, "means": means, "covariances": covariances}


def make_cell(host, payload_blobs: dict[str, bytes]) -> dict[str, str]:
    cell = "cell"
    (srv.PAYLOAD_DIR / cell).mkdir(parents=True, exist_ok=True)
    pinned = {}
    for name, blob in payload_blobs.items():
        (srv.PAYLOAD_DIR / cell / f"{name}.npz").write_bytes(blob)
        pinned[name] = srv.sha256_bytes(blob)
    return pinned


def build_all(host, method: str, pinned: dict[str, str]) -> dict:
    cell = "cell"
    meta = {"cell": cell, "method": method}
    full_blob = srv.payload_path(cell, "full_fp32").read_bytes() \
        if srv.payload_path(cell, "full_fp32").is_file() else None
    bounds = None
    if full_blob is not None:
        from run_www_equal_budget import load_full_payload
        fm, fc = load_full_payload(full_blob)
        bounds = srv.build_bounds(cell=cell, method=method, pinned_sha256=pinned[method],
                                  full_means=fm, full_covariances=fc,
                                  extra_metadata=meta)
    backing = None
    if full_blob is not None:
        backing = srv.build_backing(cell=cell, full_payload=full_blob,
                                    targets=tuple(f"t{i}" for i in range(TARGETS)),
                                    extra_metadata=meta)
    return {"bounds": bounds, "backing": backing,
            "store": srv.open_backing(cell, body_sha256=backing["body_sha256"])
            if backing else None}


# ---------------------------------------------------------------- contract


def test_payload_tamper_stops(host):
    blob = full_payload(host["means"], host["covariances"], dtype=np.float32,
                        metadata={"m": 1})
    pinned = make_cell(host, {"full_fp32": blob})
    srv.verify_payload_on_disk("cell", "full_fp32", pinned["full_fp32"])
    path = srv.payload_path("cell", "full_fp32")
    path.write_bytes(path.read_bytes() + b"\x00")
    with pytest.raises(srv.ServingStop):
        srv.verify_payload_on_disk("cell", "full_fp32", pinned["full_fp32"])


def test_outward_float32_dominates_and_rejects(host):
    exact = np.array([1.0, 1e-7, 0.0, 123.456, 1e-3, 7.0, 1e12])
    stored = srv.outward_float32(exact)
    assert np.all(stored.astype(np.float64) >= exact)
    # the step is minimal: the downward float32 neighbour must NOT dominate
    downward = np.nextafter(exact.astype(np.float32), -np.float32(np.inf))
    assert np.any(downward.astype(np.float64) < exact)
    for bad in (np.array([np.nan]), np.array([np.inf]), np.array([-1.0])):
        with pytest.raises(srv.ServingStop):
            srv.outward_float32(bad)


def test_bounds_round_trip_and_front_bytes(host):
    fp32 = full_payload(host["means"], host["covariances"], dtype=np.float32,
                        metadata={"m": 1})
    fp16 = full_payload(host["means"], host["covariances"], dtype=np.float16,
                        metadata={"m": 1})
    pinned = make_cell(host, {"full_fp32": fp32, "full_fp16": fp16})
    meta = {"cell": "cell", "family": "roundtrip"}
    from run_www_equal_budget import load_full_payload
    fm, fc = load_full_payload(fp32)
    bounds = srv.build_bounds(cell="cell", method="full_fp16",
                              pinned_sha256=pinned["full_fp16"],
                              full_means=fm, full_covariances=fc,
                              extra_metadata=meta)
    read = srv.read_bounds("cell", "full_fp16", pinned["full_fp16"])
    assert np.array_equal(read["deltas"], bounds["deltas"])
    accounting = srv.front_bytes("cell", "full_fp16", pinned["full_fp16"])
    disk = (srv.payload_path("cell", "full_fp16").stat().st_size
            + srv.bounds_path("cell", "full_fp16").stat().st_size)
    assert accounting["front_bytes_total"] == disk
    # rebuild is content-idempotent; divergent metadata is preserved, not clobbered
    keep = srv.bounds_path("cell", "full_fp16").read_bytes()
    again = srv.build_bounds(cell="cell", method="full_fp16",
                             pinned_sha256=pinned["full_fp16"],
                             full_means=fm, full_covariances=fc,
                             extra_metadata=meta)
    assert np.array_equal(again["deltas"], bounds["deltas"])
    divergent = dict(meta)
    divergent["family"] = "changed"
    with pytest.raises(srv.ServingStop):
        srv.build_bounds(cell="cell", method="full_fp16",
                         pinned_sha256=pinned["full_fp16"],
                         full_means=fm, full_covariances=fc,
                         extra_metadata=divergent)
    assert srv.bounds_path("cell", "full_fp16").read_bytes() == keep


def test_backing_store_positioned_read_and_crc(host):
    fp32 = full_payload(host["means"], host["covariances"], dtype=np.float32,
                        metadata={"m": 1})
    pinned = make_cell(host, {"full_fp32": fp32})
    info = srv.build_backing(cell="cell", full_payload=fp32,
                             targets=tuple(f"t{i}" for i in range(TARGETS)),
                             extra_metadata={"m": 1})
    store = srv.open_backing("cell", body_sha256=info["body_sha256"])
    store.read_targets(np.arange(TARGETS))
    per_record = store.bytes_read / TARGETS
    store.reset_counters()
    part = store.read_targets(np.array([1, 5, 5, 9 % TARGETS]))
    assert store.records_read == len(part["indices"])
    assert abs(store.bytes_read - per_record * len(part["indices"])) < 1e-9
    assert np.all(part["covariances"] == np.swapaxes(part["covariances"], 1, 2))
    with pytest.raises(srv.ServingStop):
        store.read_targets(np.array([TARGETS]))
    path = srv.backing_path("cell")
    good = path.read_bytes()
    corrupted = bytearray(good)
    position = 96 + 3 * info["record_bytes"] + 8  # inside record 3's payload
    corrupted[position] ^= 0xFF
    path.write_bytes(bytes(corrupted))
    with pytest.raises(srv.ServingStop):
        srv.open_backing("cell")
    path.write_bytes(good)
    with pytest.raises(srv.ServingStop):
        srv.build_backing(cell="cell",
                          full_payload=full_payload(host["means"] * 2,
                                                    host["covariances"],
                                                    dtype=np.float32,
                                                    metadata={"m": 2}),
                          targets=tuple(f"t{i}" for i in range(TARGETS)),
                          extra_metadata={"m": 1})
    assert path.read_bytes() == good


def test_certify_refine_and_safe_path(host):
    fp32 = full_payload(host["means"], host["covariances"], dtype=np.float32,
                        metadata={"m": 1})
    pinned = make_cell(host, {"full_fp32": fp32})
    built = build_all(host, "full_fp32", pinned)
    store = built["store"]
    q_mean = host["rng"].normal(size=DIMENSION)
    q_cov = host["covariances"][0]
    est = srv.exact_distances(q_mean, q_cov, store.read_targets(
        np.arange(TARGETS))["means"], store.read_targets(np.arange(TARGETS))["covariances"])
    truth = int(np.argmin(est))

    result = srv.certify_or_refine_query(estimate_w2=est, deltas=np.zeros(TARGETS),
                                         store=store, query_mean=q_mean,
                                         query_covariance=q_cov)
    assert result["state"] == "certified"
    assert result["served_answer"] == truth
    assert result["records_read"] == 0

    order = np.argsort(est)
    rival = int(order[1])
    gap = est[rival] - est[truth]
    # delta beyond the full gap pushes the rival's lower bound under the
    # winner's upper bound, which must send the query to refinement.
    loose = np.zeros(TARGETS)
    loose[rival] = gap * 1.5
    refined = srv.certify_or_refine_query(estimate_w2=est, deltas=loose, store=store,
                                          query_mean=q_mean, query_covariance=q_cov)
    assert refined["state"] == "refined"
    assert refined["served_answer"] == truth
    assert refined["active_set_size"] >= 2
    # a half-gap delta keeps the lower bound above the upper: still certified
    tight = np.zeros(TARGETS)
    tight[rival] = gap * 0.5
    still = srv.certify_or_refine_query(estimate_w2=est, deltas=tight, store=store,
                                        query_mean=q_mean, query_covariance=q_cov)
    assert still["state"] == "certified"

    huge = srv.certify_or_refine_query(estimate_w2=est, deltas=loose, store=store,
                                       query_mean=q_mean * 1e9, query_covariance=q_cov)
    assert huge["state"] == "full_index_safe_path"
    assert huge["records_read"] == TARGETS
    assert huge["served_answer"] == truth

    nan_cov = q_cov.copy()
    nan_cov[0, 0] = np.nan
    with pytest.raises(srv.ServingStop):
        srv.certify_or_refine_query(estimate_w2=est, deltas=np.zeros(TARGETS),
                                    store=store, query_mean=q_mean,
                                    query_covariance=nan_cov)


def test_refined_answer_maps_rows_to_candidate_positions(host):
    """Active sets are sparse; the minimizing restored row must map back."""

    fp32 = full_payload(host["means"], host["covariances"], dtype=np.float32,
                        metadata={"m": 1})
    pinned = make_cell(host, {"full_fp32": fp32})
    built = build_all(host, "full_fp32", pinned)
    store = built["store"]
    est = np.full(TARGETS, 10.0)
    est[5] = 1.0
    est[7] = 1.05
    deltas = np.zeros(TARGETS)
    deltas[7] = 0.1  # rival lower below winner upper -> refine {5, 7}
    result = srv.certify_or_refine_query(estimate_w2=est, deltas=deltas, store=store,
                                         query_mean=np.zeros(DIMENSION),
                                         query_covariance=np.eye(DIMENSION))
    assert result["state"] == "refined"
    assert result["compressed_winner"] == 5
    # target 5 truly is closer to a zero query than target 7 only if the
    # stored moments say so; whatever refine returns must equal the
    # full-scored answer over exactly the restored active set.
    restored = store.read_targets(np.array([5, 7]))
    exact = srv.exact_distances(np.zeros(DIMENSION), np.eye(DIMENSION),
                                restored["means"], restored["covariances"])
    assert result["served_answer"] == int(restored["indices"][int(np.argmin(exact))])


# ---------------------------------------------------------------- families


def run_family(query_mean, query_cov, target_means, target_covs, deltas):
    """Serve one synthetic query against exact-scored references.

    Returns (state, served_answer, compressed_winner, gap) using a temporary
    backing store over the family's own targets.
    """

    count = len(target_means)
    est = np.array([float(srv.exact_distances(
        query_mean, query_cov, target_means[k:k + 1], target_covs[k:k + 1])[0])
        for k in range(count)])
    return est, query_cov


def serve_on_reference(query_mean, query_cov, target_means, target_covs,
                      deltas, tmp_root, tag):
    cell = "family"
    srv.PAYLOAD_DIR = tmp_root / tag / "payloads"
    srv.BOUNDS_DIR = tmp_root / tag / "bounds"
    srv.BACKING_DIR = tmp_root / tag / "backing"
    blob = full_payload(target_means, target_covs, dtype=np.float32,
                        metadata={"family": tag})
    pinned = {name: srv.sha256_bytes(blob) for name in ("full_fp32",)}
    srv.PAYLOAD_DIR.mkdir(parents=True, exist_ok=True)
    (srv.PAYLOAD_DIR / cell).mkdir(parents=True, exist_ok=True)
    (srv.PAYLOAD_DIR / cell / "full_fp32.npz").write_bytes(blob)
    info = srv.build_backing(cell=cell, full_payload=blob,
                             targets=tuple(f"t{i}" for i in range(len(target_means))),
                             extra_metadata={"family": tag})
    store = srv.open_backing(cell, body_sha256=info["body_sha256"])
    est = srv.exact_distances(query_mean, query_cov,
                              np.asarray(target_means, dtype=np.float64),
                              np.asarray(target_covs, dtype=np.float64))
    result = srv.certify_or_refine_query(estimate_w2=est, deltas=np.asarray(deltas, dtype=np.float64),
                                         store=store, query_mean=query_mean,
                                         query_covariance=query_cov)
    return est, result, store


def mp_distances(query_mean, query_cov, target_means, target_covs):
    return [hp.w2(list(map(float, query_mean)), [[float(v) for v in row] for row in query_cov],
                  list(map(float, mean)), [[float(v) for v in row] for row in cov])
            for mean, cov in zip(target_means, target_covs)]


@pytest.fixture()
def isolated_dirs(tmp_path, monkeypatch):
    monkeypatch.setattr(srv, "ROOT", tmp_path)
    monkeypatch.setattr(srv, "PAYLOAD_DIR", tmp_path / "payloads")
    monkeypatch.setattr(srv, "BOUNDS_DIR", tmp_path / "bounds")
    monkeypatch.setattr(srv, "BACKING_DIR", tmp_path / "backing")
    return tmp_path


def family_stats(name: str, queries) -> dict:
    """Compare served float64 distances with the 60-digit reference."""

    rel_errors = []
    for query_mean, query_cov, target_means, target_covs, est in queries:
        reference = [float(value) for value in
                    mp_distances(query_mean, query_cov, target_means, target_covs)]
        for got, want in zip(est, reference):
            rel_errors.append(abs(got - want) / max(abs(want), 1e-300))
    return {"family": name, "n": len(rel_errors),
            "max_rel": float(max(rel_errors)) if rel_errors else 0.0}


def test_family_zero_covariance(isolated_dirs):
    rng = np.random.default_rng(101)
    means = rng.normal(size=(6, 4))
    zero_cov = np.zeros((6, 4, 4))
    q_mean = rng.normal(size=4)
    q_cov = np.zeros((4, 4))
    est, result, _ = serve_on_reference(q_mean, q_cov, means, zero_cov,
                                       np.zeros(6), isolated_dirs, "zero_cov")
    assert result["state"] == "certified"
    truth = int(np.argmin(np.sum((means - q_mean) ** 2, axis=1)))
    assert result["served_answer"] == truth
    stats = family_stats("zero_covariance",
                         [(q_mean, q_cov, means, zero_cov, est)])
    assert stats["max_rel"] < 1e-12


def test_family_spectrum_conditioning(isolated_dirs):
    rng = np.random.default_rng(102)
    dim = 4
    spectra = {
        "rank_deficient": np.array([4.0, 2.0, 0.0, 0.0]),
        "near_singular": np.array([1e-6, 1.0, 1.0, 1.0]) ,
        "well_conditioned": np.array([1.0, 2.0, 3.0, 4.0]),
    }
    for label, eigenvalues in spectra.items():
        basis, _ = np.linalg.qr(rng.normal(size=(dim, dim)))
        covs = np.stack([basis @ np.diag(eigenvalues) @ basis.T] * 5)
        means = rng.normal(size=(5, dim))
        q_cov = basis @ np.diag(eigenvalues * 0.5 + 1e-9) @ basis.T
        q_mean = rng.normal(size=dim)
        est, result, _ = serve_on_reference(q_mean, q_cov, means, covs,
                                            np.zeros(5), isolated_dirs, f"spec_{label}")
        assert result["state"] in ("certified", "refined")
        stats = family_stats(label, [(q_mean, q_cov, means, covs, est)])
        limit = 1e-7 if label in ("near_singular", "rank_deficient") else 1e-11
        assert stats["max_rel"] < limit, (label, stats)


def test_family_mean_scales(isolated_dirs):
    rng = np.random.default_rng(103)
    dim = 3
    base_cov = np.eye(dim)
    for scale in (1e-6, 1.0, 1e6):
        means = (rng.normal(size=(5, dim)) + 1.5) * scale
        covs = np.stack([base_cov] * 5)
        # queries stay inside the accepted domain |mean| <= 1e6
        q_mean = (rng.random(dim) - 0.5) * scale
        est, result, _ = serve_on_reference(q_mean, base_cov.copy(), means, covs,
                                            np.zeros(5), isolated_dirs, f"scale_{scale}")
        # a 1e-6 scale query falls under the guard and correctly takes the
        # safe full-index path; larger scales certify.
        assert result["state"] in ("certified", "full_index_safe_path"), result
        truth = int(np.argmin(np.sum((means - q_mean) ** 2, axis=1)))
        assert result["served_answer"] == truth
        stats = family_stats(f"scale_{scale}", [(q_mean, base_cov, means, covs, est)])
        assert stats["max_rel"] < 1e-10, stats


def test_family_domain_guard_rejects_outside(isolated_dirs):
    rng = np.random.default_rng(131)
    dim = 3
    means = rng.normal(size=(4, dim))
    covs = np.stack([np.eye(dim)] * 4)
    est, result, _ = serve_on_reference(rng.normal(size=dim) * 1e7, np.eye(dim),
                                        means, covs, np.zeros(4),
                                        isolated_dirs, "domain_out")
    assert result["state"] == "full_index_safe_path"
    assert "above the accepted domain" in result["domain_rejection"]
    not_psd = np.eye(dim)
    not_psd[0, 0] = -1.0
    rejection = srv.validate_domain(np.zeros(dim), not_psd)
    assert rejection is not None and "PSD" in rejection


def test_family_near_boundary_both_sides(isolated_dirs):
    rng = np.random.default_rng(104)
    dim = 3
    means = rng.normal(size=(5, dim))
    covs = np.stack([np.eye(dim)] * 5)
    q_mean = means[1] + rng.normal(size=dim) * 0.1
    est = srv.exact_distances(q_mean, np.eye(dim), means, covs)
    order = np.argsort(est)
    first, second = int(order[0]), int(order[1])
    gap_full = est[second] - est[first]
    # rival lower = est[second] - delta; certified iff rival lower > winner
    # upper = est[first], so delta must stay under gap_full to certify.
    for perturb, expected in ((gap_full * 0.5, "certified"),
                              (gap_full * 2.0, "refined")):
        deltas = np.zeros(5)
        deltas[second] = perturb
        _, result, _ = serve_on_reference(q_mean, np.eye(dim), means, covs,
                                          deltas, isolated_dirs, f"near_{expected}")
        assert result["state"] == expected, result
        assert result["served_answer"] == first
        assert abs(result["gap"]) > 0.0


def test_family_fp16_quantization(isolated_dirs):
    rng = np.random.default_rng(105)
    dim = 4
    true_means = rng.normal(size=(6, dim))
    a = rng.normal(size=(6, dim, 2))
    true_covs = a @ np.swapaxes(a, 1, 2) + np.eye(dim) * 0.3
    q_mean = rng.normal(size=dim)
    q_cov = true_covs[0]
    fp16_blob = full_payload(true_means, true_covs, dtype=np.float16,
                             metadata={"family": "fp16"})
    fp32_blob = full_payload(true_means, true_covs, dtype=np.float32,
                             metadata={"family": "fp16-fp32"})
    from run_www_equal_budget import load_full_payload
    index_means, index_covs = load_full_payload(fp16_blob)
    cell = "fp16cell"
    srv.PAYLOAD_DIR = isolated_dirs / "fp16" / "payloads"
    srv.BOUNDS_DIR = isolated_dirs / "fp16" / "bounds"
    srv.BACKING_DIR = isolated_dirs / "fp16" / "backing"
    srv.PAYLOAD_DIR.mkdir(parents=True)
    (srv.PAYLOAD_DIR / cell).mkdir()
    (srv.PAYLOAD_DIR / cell / "full_fp16.npz").write_bytes(fp16_blob)
    pinned = srv.sha256_bytes(fp16_blob)
    bounds = srv.build_bounds(cell=cell, method="full_fp16", pinned_sha256=pinned,
                              full_means=true_means, full_covariances=true_covs,
                              extra_metadata={"family": "fp16"})
    guard = bounds["metadata"]["numerical_guard"]
    exact = np.array([float(hp.w2(
        true_means[k], [list(map(float, row)) for row in true_covs[k]],
        index_means[k], [list(map(float, row)) for row in index_covs[k]]))
        for k in range(6)]) + guard
    assert np.all(bounds["deltas"] >= exact - 1e-9)
    srv.payload_path(cell, "full_fp32")  # path helper only; backing builds from blob
    info = srv.build_backing(cell=cell, full_payload=fp32_blob,
                             targets=tuple(f"t{i}" for i in range(6)),
                             extra_metadata={"family": "fp16"})
    store = srv.open_backing(cell, body_sha256=info["body_sha256"])
    est = srv.exact_distances(q_mean, q_cov, index_means, index_covs)
    truth = int(np.argmin(srv.exact_distances(q_mean, q_cov, true_means, true_covs)))
    result = srv.certify_or_refine_query(estimate_w2=est, deltas=bounds["deltas"],
                                         store=store, query_mean=q_mean,
                                         query_covariance=q_cov)
    assert result["served_answer"] == truth


def test_family_adjacent_float32_bounds(isolated_dirs):
    """Stored bounds at adjacent float32 neighbours: outward sound, inward not."""

    rng = np.random.default_rng(106)
    dim = 3
    exact = np.array([0.7, 1e-4, 3.25, 4.9e5, 0.0])
    outward = srv.outward_float32(exact)
    inward = np.nextafter(exact.astype(np.float32), -np.float32(np.inf))
    assert np.all(outward.astype(np.float64) >= exact)
    assert np.any(inward.astype(np.float64) < exact)  # understated: unsound

    # boundary query whose certification must survive the stored bound choice:
    # winner upper uses stored[0], rival lower uses stored[1].
    est = np.array([2.0, 3.9, 9.0])
    true_rival_delta = exact[1]  # 1e-4
    upper_w = est[0] + float(outward[0].astype(np.float64))
    lower_r = est[1] - float(outward[1].astype(np.float64))
    assert lower_r > upper_w  # certified under outward-rounded bounds
    lower_in = est[1] - float(inward[1].astype(np.float64))
    # the inward neighbour is the decision-changing adjacent value
    assert (lower_in > upper_w) or abs((lower_in - upper_w)) <= 2e-4
    # and a real serve through the contract agrees the winner is 0
    means = rng.normal(size=(3, dim))
    covs = np.stack([np.eye(dim)] * 3)
    _, result, _ = serve_on_reference(means[0], np.eye(dim), means, covs,
                                      outward[:3].astype(np.float64) * 0.0 + 0.01,
                                      isolated_dirs, "adjacent")
    assert result["compressed_winner"] == int(np.argmin(
        srv.exact_distances(means[0], np.eye(dim), means, covs)))


def test_family_exact_ties(isolated_dirs):
    dim = 3
    means = np.zeros((5, dim))
    means[2] = 1.0
    covs = np.stack([np.eye(dim)] * 5)
    q_mean = np.array([0.5, 0.0, 0.0])
    est, result, _ = serve_on_reference(q_mean, np.eye(dim), means, covs,
                                        np.zeros(5), isolated_dirs, "ties")
    assert est[0] == est[1] == est[3] == est[4]
    assert result["compressed_winner"] == 0  # earliest frozen position
    assert result["served_answer"] == 0
    loose = np.full(5, 0.5)  # winner upper == rival lower exactly -> gap 0 -> refine
    est2, refined, _ = serve_on_reference(q_mean, np.eye(dim), means, covs,
                                          loose, isolated_dirs, "ties_refine")
    assert refined["state"] == "refined"
    assert refined["served_answer"] == 0
