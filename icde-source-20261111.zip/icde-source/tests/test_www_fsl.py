from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from pkgea.distributional import gaussian_wasserstein_squared
from pkgea.www_fsl import (
    apply_entity_representations,
    classify_covariance_residual,
    build_two_layer_gcn_scope,
    empirical_gaussian,
    gaussian_distance_matrix,
    margin_criticalities,
    select_entity_adaptive_ranks,
    select_margin_aware_representations,
    serving_workload_digest,
    slack_diagnostics,
    stored_scalars_per_entity,
    truth_preserving_candidate_subset,
)


class WWWFidelityStorageLatencyTests(unittest.TestCase):
    def test_scope_includes_normalization_boundary_edges(self) -> None:
        # Requested node 0 needs hidden rows 0/1, degrees 0/1/2, and therefore
        # the boundary edge 2--3 even though node 3 is outside the two-hop set.
        scope = build_two_layer_gcn_scope(
            4,
            [0, 1, 2],
            [1, 2, 3],
            [0],
        )
        self.assertEqual(scope.layer1_positions, (0, 1))
        self.assertEqual(scope.degree_positions, (0, 1, 2))
        self.assertEqual(scope.sampled_edge_indices, (0, 1, 2))
        self.assertEqual(scope.layer2_edge_indices, (0,))

    def test_vectorized_gaussian_distances_match_scalar_reference(self) -> None:
        means = np.array([[0.0, 0.2], [0.8, -0.1], [0.1, 0.3]])
        covariances = np.array(
            [
                [[0.5, 0.1], [0.1, 0.7]],
                [[0.2, 0.0], [0.0, 0.4]],
                [[0.8, -0.2], [-0.2, 0.6]],
            ]
        )
        observed = gaussian_distance_matrix(means, covariances, 1)
        expected = np.array(
            [
                [
                    gaussian_wasserstein_squared(
                        means[0], covariances[0], means[target], covariances[target]
                    )
                    for target in (1, 2)
                ]
            ]
        )
        self.assertTrue(np.allclose(observed, expected, atol=1e-10))

    def test_empirical_gaussian_and_storage_contract(self) -> None:
        samples = np.array(
            [
                [[0.0, 1.0], [1.0, 0.0]],
                [[1.0, 2.0], [2.0, 1.0]],
                [[2.0, 3.0], [3.0, 2.0]],
            ]
        )
        means, covariances = empirical_gaussian(samples)
        self.assertEqual(means.shape, (2, 2))
        self.assertEqual(covariances.shape, (2, 2, 2))
        self.assertTrue(np.allclose(np.diag(covariances[0]), [1.0, 1.0]))
        self.assertEqual(stored_scalars_per_entity(16, "full"), 152)
        self.assertEqual(
            stored_scalars_per_entity(16, "low_rank", rank=2), 64
        )
        self.assertEqual(
            stored_scalars_per_entity(16, "low_rank", rank=8), 160
        )
        self.assertGreater(
            stored_scalars_per_entity(16, "low_rank", rank=8),
            stored_scalars_per_entity(16, "full"),
        )

    def test_candidate_limit_retains_truth_and_frozen_order(self) -> None:
        targets = ("a", "b", "c", "d", "e")
        sources = ("s1", "s2")
        truth = {"s1": "e", "s2": "c"}
        observed = truth_preserving_candidate_subset(
            targets, sources, truth, 3
        )
        self.assertEqual(observed, ("a", "c", "e"))
        self.assertTrue(all(truth[source] in observed for source in sources))
        self.assertEqual(
            truth_preserving_candidate_subset(targets, sources, truth, None),
            targets,
        )
        self.assertEqual(
            truth_preserving_candidate_subset(
                targets, sources, truth, len(targets)
            ),
            targets,
        )
        smaller = truth_preserving_candidate_subset(
            targets, sources, truth, 2
        )
        self.assertTrue(set(smaller).issubset(observed))

    def test_candidate_limit_rejects_out_of_bounds(self) -> None:
        targets = ("a", "b", "c")
        sources = ("s1", "s2")
        truth = {"s1": "a", "s2": "b"}
        with self.assertRaisesRegex(ValueError, "at least the source count"):
            truth_preserving_candidate_subset(targets, sources, truth, 1)
        with self.assertRaisesRegex(ValueError, "exceeds"):
            truth_preserving_candidate_subset(targets, sources, truth, 4)

    def test_workload_digest_binds_order_and_ranking_operation(self) -> None:
        first = serving_workload_digest(("s1", "s2"), ("t1", "t2"))
        self.assertEqual(
            first,
            serving_workload_digest(("s1", "s2"), ("t1", "t2")),
        )
        self.assertNotEqual(
            first,
            serving_workload_digest(("s2", "s1"), ("t1", "t2")),
        )
        self.assertNotEqual(
            first,
            serving_workload_digest(
                ("s1", "s2"), ("t1", "t2"), ranking_operation="top_k"
            ),
        )

    def test_zero_covariance_selects_rank_one_without_nan(self) -> None:
        result = select_entity_adaptive_ranks(
            np.zeros((1, 2, 2)), candidate_ranks=(1,)
        )
        self.assertEqual(result["selected_ranks"], [1])
        self.assertEqual(result["degenerate_entity_count"], 1)
        residual = result["entities"][0]["residuals"][0]
        self.assertEqual(residual["status"], "degenerate")
        self.assertEqual(residual["relative_residual"], 0.0)

    def test_residual_three_way_boundary_contract(self) -> None:
        self.assertEqual(
            classify_covariance_residual(2e-12, 1e-12),
            ("ok", 0.5),
        )
        self.assertEqual(
            classify_covariance_residual(1e-13, 1e-13),
            ("degenerate", 0.0),
        )
        self.assertEqual(
            classify_covariance_residual(1e-13, 2e-12),
            ("anomalous", None),
        )

    def test_multiple_zero_slack_uses_original_candidate_order(self) -> None:
        full = np.array([[1.0, 1.0, 1.0]])
        approximate = np.array([[1.0, 1.0, 1.0]])
        result = slack_diagnostics(full, approximate)
        row = result["sources"][0]
        self.assertEqual(row["zero_slack_count"], 2)
        self.assertFalse(row["authoritative_flipped"])
        self.assertTrue(row["diagnostic_matches_authoritative"])

    def test_zero_distance_scale_keeps_nonzero_slack_tolerance(self) -> None:
        full = np.zeros((2, 3))
        approximate = np.zeros((2, 3))
        result = slack_diagnostics(full, approximate)
        self.assertEqual(result["median_absolute_winner_distance"], 0.0)
        self.assertEqual(result["tau_slack"], 1e-12)
        self.assertTrue(result["absolute_floor_triggered"])

    def test_margin_criticality_covers_sources_and_every_target(self) -> None:
        # W2 distances are [[1, 2, 5], [4, 1, 3]].  Target 2 is never in a
        # top-two pair for source 0, but it must still receive a finite margin.
        result = margin_criticalities(
            np.square(np.array([[1.0, 2.0, 5.0], [4.0, 1.0, 3.0]]))
        )
        self.assertEqual(result["source_criticalities"], [1.0, 2.0])
        self.assertEqual(result["target_criticalities"], [1.0, 1.0, 2.0])
        self.assertEqual(len(result["entity_criticalities"]), 5)

    def test_margin_selection_is_storage_neutral_and_uses_diagonal(self) -> None:
        covariances = np.array(
            [
                [[2.0, 0.4], [0.4, 1.0]],
                [[1.5, 0.2], [0.2, 0.8]],
                [[0.9, 0.1], [0.1, 0.7]],
            ]
        )
        means = np.array([[0.0, 0.0], [1.0, 0.0], [3.0, 0.0]])
        distances = gaussian_distance_matrix(means, covariances, 1)
        result = select_margin_aware_representations(
            covariances,
            distances,
            source_count=1,
            # Three diagonal representations cost 4 scalars each at d=2.
            target_storage_scalars=12,
        )
        self.assertTrue(result["storage_neutrality_passes"])
        self.assertEqual(result["selected_storage_scalars"], 12)
        self.assertEqual(result["representation_counts"]["diagonal"], 3)
        applied = apply_entity_representations(
            covariances, result["selected_representations"]
        )
        self.assertTrue(
            np.allclose(applied, np.array([np.diag(np.diag(x)) for x in covariances]))
        )

    def test_zero_margin_entities_cannot_be_relaxed_by_positive_distortion(self) -> None:
        covariances = np.array(
            [
                [[1.0, 0.5], [0.5, 1.0]],
                [[1.0, 0.5], [0.5, 1.0]],
                [[1.0, 0.5], [0.5, 1.0]],
            ]
        )
        # Exact tie between both targets forces zero source/winner criticality.
        result = select_margin_aware_representations(
            covariances,
            np.array([[1.0, 1.0]]),
            source_count=1,
            target_storage_scalars=18,
        )
        selected = result["selected_representations"]
        self.assertEqual(selected[0], "full")
        self.assertEqual(selected[1], "full")


if __name__ == "__main__":
    unittest.main()
    margin_criticalities,
    select_margin_aware_representations,
