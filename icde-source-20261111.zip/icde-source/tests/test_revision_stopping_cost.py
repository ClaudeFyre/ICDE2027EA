"""Regression: the cost ledger must charge ACTUAL adaptive stopping, not the
base revision / budget.

Counterexample from the 4090D review (``full_return_audit_20261009/
revision_stopping_counterexample.json``): one edge, source ``s``, candidates
``a,b``, budget=256, seed=17, delta=0.05.

  * p = 0.9  -> winner stabilizes at 48 worlds  -> scorer calls = 48
  * p = 0.5  -> winner never stabilizes         -> budget exhausted, scorer calls = 256

A planner that books cost by the base revision (or by budget for every query)
would charge 256 in both cases and miss this. The ledger must charge
``samples_used`` (i.e. ``work["scorer_calls"]``) per revision. Raw values are
asserted exactly so a future engine change that alters stopping is caught.
"""

from pkgea.query.modal import (
    IIDWorldStream,
    ModalQuery,
    ModalScorer,
    ModalSnapshot,
    execute_modal_queries,
    identity,
)
from pkgea.samplers import monte_carlo_worlds


def _score_factory():
    def score(state, sources, targets):
        # candidate "a" wins when the single edge is True, "b" when False.
        on = bool(state[0])
        return {
            (s, t): (1.0 if on else 0.0) if t == "a" else (0.0 if on else 1.0)
            for s in sources for t in targets
        }
    return score


def _run(p):
    worlds = tuple(monte_carlo_worlds([p], 256, 17))
    snap = ModalSnapshot(
        "one-edge", "fixed-boolean-scorer", identity([p]),
        "independent", "toy-v1", "frozen-v1", "exact-bool",
    )
    stream = IIDWorldStream(snap.digest, 17, worlds)
    scorer = ModalScorer(snap.digest, _score_factory())
    q = ModalQuery("s", ("a", "b"), snap.digest, 256, 0.05)
    out = execute_modal_queries(
        [q], snap, stream, scorer, cache=None, shared=True,
        batch_size=16, minimum_samples=32,
    )
    return out["work"]["scorer_calls"], out["results"][0]


def test_revision_stopping_charges_actual_samples_used():
    calls_09, res_09 = _run(0.9)
    calls_05, res_05 = _run(0.5)

    # The ledger charges exactly what was actually scored.
    assert calls_09 == res_09["samples_used"]
    assert calls_05 == res_05["samples_used"]

    # The two revisions diverge purely by stopping behaviour:
    #   p=0.9  -> certified early at 48 worlds
    #   p=0.5  -> runs out the 256-world budget
    assert calls_09 == 48, f"expected early-stop at 48, got {calls_09}"
    assert res_09["status"] == "stable"
    assert calls_05 == 256, f"expected budget exhaustion at 256, got {calls_05}"
    assert res_05["status"] == "budget_exhausted"
